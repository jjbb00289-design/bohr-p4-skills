# 语言识别、术语与跨语言对齐规则

## 语言识别（脚本启发式，detect_language）

- 含 CJK（\u4e00-\u9fff）且含假名（\u3040-\u30ff）→ `ja`；否则 `zh`。
- 拉丁文：按功能词频率区分 `en/pt/es/de`。词表（en: the/and/of/with/for/from/that/this/are/was/not/have；pt: de/da/do/em/com/uma/um/para/que/na/no/não；es: el/la/de/en/con/una/un/que/y/por/para；de: der/die/das/und/mit/für/von/ist/nicht/ein）。
- 无有效词 → `unknown`，置信度 0.0；置信度输出 = 该语种功能词占比（上限 0.95）。
- 超出题面语种（unseen language）不声称识别；Agent 复核时写入 `language_overrides`。

## 已知边界（本题 3 作品 / 6 视图）

题目给定真实材料边界：原始葡萄牙语正文、原始英语正文、出版社全文翻译、仅英语摘要（正文仍为原文语种）、显式完全重复；每条记录的 source/DOI/version/body language/attribution 均保留在材料中。目标语种为 `pt`（葡萄牙语）与 `en`（英语）；不虚构实时覆盖率、不声称"最新文献"、不提出新研究结论。

## 术语对齐（terminology）

- 术语表由同 DOI 作品的不同语种标题自动生成：`language_pairs = {语种: 标题}`，`evidence` 指向该标题所在记录的 source+locator+quote。
- Agent 增补概念级术语（同义词、缩写、音译、本地译名）时，必须把每对映射落到材料原文 quote；翻译服务一律记 `model-internal`（无外部 API），不凭记忆补造 DOI/作者/年份。

## 查询计划（query_plan）

- 第 1 条恒为原问题逐字（截断 400 字符），`rationale=orig`。
- 每个 named DOI 生成 DOI 精确查询（rationale=DOI lookup）；每个 named title 生成标题查询（rationale=title）。
- 术语表里每种语言的标题生成跨语言变体查询（rationale=variant），使 pt 标题能召回 en 版本、反之亦然。
- 无结果的查询保留在 query_plan 并写入 `coverage_gaps`（type=query_no_result）。

## 排序与评测思路

`relevance_score = DOI 精确命中*10 + 标题重叠*5 + 查询命中*1 + 元数据完整度*0.01`（降序）。`ranking.precision_recall` 给出相对 named items（DOI/title）的 precision@k、recall@k：precision 计相关记录占比，recall 计去重后命中的 named 作品占比（gold_hit/gold_count）。

# result.json 契约与证据规范

## 顶层结构

result.json 必须**原样回填** case.json `output_contract` 的每一个键（键名不改、不漏），并额外保证以下键存在：

- `case_id`：来自 case.json（`case_id`/`caseId`/`id`，缺失为 null）。
- `status`：`complete` / `partial` / `insufficient_evidence` / `input_error`。
- `sources`：每条材料文件 {file, kind, records, needs_ocr, error}。
- `uncertainty`：缺 quote、版本未知、语种未知等不确定性条目。
- `change_records`：处理步骤与 finalize 状态（确定性，无时间戳/随机）。

此外附加标准成分：`research_question`、`terminology`、`query_plan`、`candidates`、`deduplication`、`ranking`、`coverage_gaps`、`errors`、`degradations`、`summary`。缺值用 null/[]，禁止占位字符串（"array"/"object"）。

## 候选记录字段

`candidates[]` 每条：`record_id`、`title`、`authors`、`year`、`venue`、`doi`、`language`（检出语种）、`lang_conf`、`version_type`、`ver_conf`、`version_reason`、`body_language`、`source_file`（相对 /input 路径）、`locator`（JSON 路径如 `message.items[0]`）、`quote`（材料原文逐字片段）、`relevance_score`、`reasons`、`rank`。

## 证据红线

- 每条候选必须有 `source_file` + `locator` + 逐字 `quote`；quote 必须在源文件原文中命中（JSON 值、文本行或抽取文本）。脚本用 JSON 字段原值做包含校验，命中失败置 `quote: null` 并记入 uncertainty。
- 术语表 `terminology[]` 的 language_pairs 与 evidence 必须来自同 DOI 作品的不同语言标题（quote 指向标题字段原文）。
- 不编造 DOI、作者、年份、期刊、全文；无外部翻译/检索接口，翻译记录为 `translation_service: model-internal; n/a`。

## 版本分类（version_type）

- `original_body`：声明/检出的正文语言与记录语种一致，且无翻译标记。
- `full_translation`：存在 translation/translated 字段或正文语言与记录语种不一致。
- `abstract_only`：摘要语种与正文语种不一致，或含 "abstract only / english abstract" 等标记。
- `duplicate`：同 DOI + 同归一化标题 + 同语种 + 同版本的重复导入（首条保留，其余标 duplicate）。
- `unknown`：无信号，交 Agent 用 version_overrides 复核。

## 去重（works）

作品按 DOI 归并（无 DOI 时按归一化标题），同 DOI 的不同语言/版本视图计入同一 `view_ids`；`view_count` 与 `languages` 反映去重后的语种集合。跨语言且 DOI 缺失的归并由 Agent 通过 `dedup_overrides` 手工合并（confidence=manual_merge）。

## 状态判定

- case.json 缺失/坏 JSON → `input_error`。
- 无记录 → `insufficient_evidence`。
- 无 named targets → `partial`。
- 所有 named item 命中且候选均带 quote → `complete`；否则 `partial`。

## check 校验

`check` 输出：result_exists、json_valid、case_id_present、contract_keys_ok、quote_hit_rate（对 candidates 非空 quote 在源文件中的命中比例，目标 ≥0.95）、status、notes。

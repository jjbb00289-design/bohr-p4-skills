---
name: cross-language-literature-search
description: Offline, source-bound cross-language literature retrieval. Given a research question and local bibliographic material (Crossref/EuropePMC/publisher responses, reference graphs, import-state files, PDF/text), it discovers materials recursively, extracts candidate records with verbatim evidence, detects language and version (original body / full translation / abstract-only / exact duplicate), builds a terminology table and per-language query plan, deduplicates multilingual versions of the same work, ranks by relevance, and writes an evidence-backed result.json. Use for known-item or topic retrieval where materials are local files and no live search or translation API is available.
version: 1.0.0
---

# 跨语言文献检索（离线、source-bound）

## 用途

在**只有本地材料、无实时联网检索、无外部翻译接口**的条件下完成跨语言文献检索：从科研问题出发确定目标语种，建立术语表，生成逐语种查询，取回候选文献，对齐到原文证据，并把同一论文的不同语言版本去重后计数。核心问题：非英语文献是否被真实找回、术语对齐能否人工核对、每条命中能否说清来自哪个语种和哪个版本。

适用场景：已知条目（known-item）检索或主题检索；材料为本地文件（Crossref / EuropePMC / publisher 响应、reference graph、组织方增量导入状态、PDF/文本）。**不负责**整篇翻译、写作润色、联网抓取、声称"实时/最新文献"。

## 触发条件

当任务要求"检索文献并保留筛选依据"，且输入目录存在本地材料文件时触发。若材料目录为空、case.json 缺失或坏 JSON，仍必须产出合法的 result.json（见"三态"）。

## 调用方式

脚本位于 `scripts/main.py`，纯 Python 标准库，不联网，不依赖 CWD（内部用 `Path(__file__).resolve().parent` 定位）。

```bash
# 默认完整流程：材料发现→解析→术语/查询→去重/版本→排序→result.json
python scripts/main.py
# 环境变量或参数覆盖目录（默认 /input /app/work /app/output）
python scripts/main.py --input DIR --work DIR --output DIR
# 分步（Agent 增量工作流）
python scripts/main.py init    # 生成工作稿 work-draft.json + records.json + partial result.json
python scripts/main.py show    # 打印工作稿摘要与记录数
python scripts/main.py check   # 校验契约键齐全、quote 命中率、三态合法性
python scripts/main.py build   # 读工作稿，应用人工覆盖，finalize result.json
```

`INPUT_DIR`/`WORK_DIR`/`OUTPUT_DIR` 环境变量与 `--input/--work/--output` 参数均可覆盖默认路径。所有异常被捕获并写入 `errors`/`degradations`，退出码恒为 0。

## 输入输出

**输入**：`/input/case.json`（含 `case_id`、`task_instruction`、`output_contract`，字段名可能为 camelCase 变体）+ `/input/task.md` + 材料文件（任意嵌套子目录）。材料按真实文件读取：JSON 按结构解析，PDF 尽力抽取文本（无文本层则标记需 OCR），文本按 UTF-8 后回退 latin-1。

**输出**：
- `/app/work/records.json`：解析出的候选记录（键：id、title、authors、year、venue、doi、doi0、abstract、lang、body、tl、tlc、abl、src、loc、q、qf、fl；其中 tl=检出语种、tlc=语种置信度、src=来源文件、loc=定位、q=逐字 quote、qf=quote 字段、fl=版本/翻译标记）。
- `/app/work/work-draft.json`：工作稿（Agent 可编辑）。
- `/app/output/result.json`：最终结构化结果，**必须**原样回填 case.json `output_contract` 的每一个字段 + `case_id`，并带 `status`、`sources`（证据定位）、`uncertainty`、`change_records`；缺失值用 `null`/`[]`，不改名、不漏键。

result.json 关键成分（标准键，若契约未声明也附加）：
- `research_question`：问题原文、源语言、目标语种。
- `terminology`：术语表（概念、各语种对应写法、来源+定位+逐字 quote）。
- `query_plan`：逐轮逐语种查询式（含同义词/缩写/跨语言扩展、命中记录 id）。
- `candidates`：候选集，每条带 record_id/title/authors/year/venue/doi/language/lang_conf/version_type/ver_conf/version_reason/body_language/source_file/locator/quote/relevance_score/rank。
- `deduplication`：作品及其各语言版本视图归并。
- `ranking`：排序方法与 precision@k / recall@k（相对 named items）。
- `coverage_gaps`：无结果查询、遗漏、缺失元数据、冲突。

## 工作稿 schema（work-draft.json）

```json
{
  "schema_version": 1,
  "case_id": "str",
  "research_question": {"text": "str", "source_language": "str", "target_languages": ["str"]},
  "target_items": [{"type": "doi|title|author", "value": "str", "source": "str"}],
  "terminology": [{"concept": "str", "language_pairs": {"pt": "str", "en": "str"}, "evidence": {"source": "str", "locator": "str", "quote": "str"}}],
  "query_plan": [{"id": "q1", "language": "str", "query": "str", "rationale": "str", "matched_record_ids": ["str"]}],
  "language_overrides": {"<record_id>": {"language": "str", "confidence": 0.9, "reason": "str", "evidence_quote": "str"}},
  "version_overrides": {"<record_id>": {"version_type": "str", "confidence": 0.9, "evidence": "str"}},
  "dedup_overrides": {"<work_id>": {"merge": ["<record_id>"], "split": ["<record_id>"]}},
  "notes": ["str"],
  "errors": [], "degradations": []
}
```

Agent 增量工作流：`init` → `show` 读记录与目标 → 用自身多语种知识核对语言/版本/术语对齐，编辑工作稿的 overrides/terminology/query_plan（每条判断必须带 `evidence`/`quote`）→ `build` finalize。翻译服务一律记录为 `translation_service: "model-internal"`（无外部 API），版本 `n/a`，术语映射必须引用材料原文，不得凭记忆补造。

## 证据规范（硬约束）

每条候选/每条术语/每个页面结论必须能指回 `source_file`（相对 /input 的路径）+ `locator`（JSON 路径如 `message.items[3].title[0]`、文本行号、PDF 页码）+ 逐字 `quote`，且 quote 必须在材料原文中命中。脚本默认用 JSON 字段原值作为 quote 并在原始文本中做包含校验；文本/PDF 抽取同理。命中失败时标 `quote: null` 并记入 `uncertainty`。禁止 placeholder / "array" / "object" / 空契约键。不编造 DOI、作者、年份、期刊或全文。

## 语言与版本识别（本脚本能做的确定性部分）

- 语言识别（脚本启发式）：CJK→zh；假名→ja；谚文→ko；西里尔→ru；拉丁文用功能词频率区分 en/pt/es/de/fr/it，输出语言+置信度。
- 版本分类：`original_body` / `full_translation` / `abstract_only` / `duplicate` / `unknown`，依据材料显式字段（language、body_language、abstract_language、translation 标记、DOI 相同但语种不同、同 DOI 同标题同语种重复导入）。低置信度交 Agent 用 `version_overrides` 复核。

Agent 必须补充脚本无法可靠判断的部分：葡萄牙语/英语（及题目出现的 zh/ja/de 等）标题语义对齐、正文语言 vs 摘要语言、译文与原文是否为同一语义（回译/抽检），并把判断依据写成逐字 quote。

## 降级表

| 情况 | status | 动作 |
|-|-|-|
| case.json 缺失/坏 JSON | input_error | result.json 全字段 null/[]，errors 记录，exit 0 |
| 材料为空/无记录/无目标 | insufficient_evidence | candidates=[]，coverage_gaps 说明，exit 0 |
| 部分目标未命中/低置信/缺 quote | partial | 已命中部分正常输出，uncertainty 列缺口 |
| 全部目标命中且有 quote 证据 | complete | 完整输出 |

材料冲突（同 DOI 不同元数据）写入 `uncertainty` 与 `coverage_gaps`，保留两种来源与 quote，不静默取舍。

## 自检

`python scripts/main.py check`：校验 result.json 可解析、契约键与 case_id 齐全、status 合法、candidates 非空时 quote 命中率 ≥ 0.95（在材料原文可读时）。自检不过不阻断 finalize，仅在 errors/degradations 中如实记录。

## 限制

无外部翻译/检索接口，跨语言扩展仅依赖材料内已有的多语种标题/术语与 Agent 的多语种知识，且必须落在材料证据上；无法覆盖题目未给语种（unseen language）。PDF 若为扫描件且无文本层，脚本只标记需 OCR，不做 OCR。不做实时覆盖率、不声称"最新文献"、不提出新研究结论。

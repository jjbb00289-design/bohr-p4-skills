#!/usr/bin/env python3
import argparse
import json
import os
import sys
from pathlib import Path
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import clx
_DOI_RE = clx._DOI_RE
def resolve_dirs(args):
    input_dir = Path(args.input) if getattr(args, "input", None) else Path(os.environ.get("INPUT_DIR", "/input"))
    work_dir = Path(args.work) if getattr(args, "work", None) else Path(os.environ.get("WORK_DIR", "/app/work"))
    output_dir = Path(args.output) if getattr(args, "output", None) else Path(os.environ.get("OUTPUT_DIR", "/app/output"))
    return input_dir, work_dir, output_dir
def load_case(input_dir):
    case = {"_input_error": False, "case_id": None, "task_instruction": None,
            "output_contract": None, "_task_text": "", "_errors": []}
    cj = input_dir / "case.json"
    if cj.exists():
        try:
            data = json.loads(cj.read_text(encoding="utf-8", errors="replace"))
            if isinstance(data, dict):
                f = lambda ks: next((data.get(k) for k in ks if data.get(k)), None)
                case["case_id"] = f(("case_id", "caseId", "id"))
                ti = f(("task_instruction", "taskInstruction", "instruction", "prompt", "question", "task"))
                if ti is None and isinstance(data.get("input"), dict):
                    ti = next((data["input"].get(k) for k in ("task_instruction", "instruction", "question")
                               if data["input"].get(k)), None)
                if ti is None and isinstance(data.get("input"), str):
                    ti = data["input"]
                case["task_instruction"] = ti
                case["output_contract"] = f(("output_contract", "outputContract", "outputs", "result_schema", "contract"))
        except Exception as e:
            case["_input_error"] = True
            case["_errors"].append("case.json parse: %s" % e)
    else:
        case["_input_error"] = True
        case["_errors"].append("case.json missing")
    tm = input_dir / "task.md"
    if tm.exists():
        try:
            case["_task_text"] = tm.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            case["_errors"].append("task.md read: %s" % e)
    if not case["task_instruction"]:
        case["task_instruction"] = case["_task_text"] or ""
    return case
def _dedupe_items(items):
    out, seen = [], set()
    for it in items:
        key = json.dumps(it, ensure_ascii=False, sort_keys=True)
        if key not in seen:
            seen.add(key)
            out.append(it)
    return out
def rematch(query_plan, records):
    for q in query_plan:
        query = q.get("query") or ""
        ids = []
        for r in records:
            if _DOI_RE.match(query.strip()):
                if r["doi"] and r["doi"] == clx._norm_doi(query.strip()):
                    ids.append(r["id"])
            else:
                rt = clx.normalize_title(r["title"] or "")
                qt = clx.normalize_title(query)
                if qt and (qt in rt or rt in qt):
                    ids.append(r["id"])
        q["matched_record_ids"] = ids
    return query_plan
def merge_terminology(derived, extra):
    merged = list(derived)
    have = {(t.get("work_id"), t.get("doi")) for t in derived if t.get("work_id")}
    for t in extra:
        key = (t.get("work_id"), t.get("doi"))
        if key not in have:
            merged.append(t)
            have.add(key)
    return merged
def run_pipeline(input_dir, work_dir, output_dir, overrides=None, write_partial=True):
    overrides = overrides or {}
    changes, degradations = [], []
    case = load_case(input_dir)
    changes.append({"step": "load_case",
                    "detail": "input_error=%s" % case["_input_error"]})
    files = clx.discover_files(str(input_dir))
    changes.append({"step": "discover", "detail": "%d files" % len(files)})
    parsed = []
    for rel in files:
        if rel in ("case.json", "task.md") or rel.endswith("/case.json"):
            continue
        parsed.append(clx.parse_material(rel, os.path.join(str(input_dir), rel)))
    for p in parsed:
        if p["error"]:
            degradations.append({"file": p["rel"], "detail": p["error"]})
    records = clx.extract_records(parsed)
    changes.append({"step": "parse", "detail": "%d records" % len(records)})
    case_text = (case["task_instruction"] or "") + "\n" + (case["_task_text"] or "")
    targets = clx.extract_targets(case_text)
    targets = _dedupe_items(targets + (overrides.get("target_items") or []))
    # language overrides before version detection
    lang_ov = overrides.get("language_overrides") or {}
    for rid, ov in lang_ov.items():
        for r in records:
            if r["id"] == rid:
                if ov.get("language"):
                    r["tl"] = ov["language"]
                if ov.get("confidence") is not None:
                    r["tlc"] = float(ov["confidence"])
                if ov.get("body_language"):
                    r["body"] = ov["body_language"]
    works = clx.build_works(records, overrides.get("dedup_overrides"))
    version_map = clx.detect_version(records)
    for rid, ov in (overrides.get("version_overrides") or {}).items():
        if rid in version_map or True:
            version_map[rid] = (ov.get("version_type", "unknown"),
                                float(ov.get("confidence", 0.0)),
                                ov.get("evidence", "agent override"))
    query_plan = clx.build_query_plan(case_text, records, targets, works)
    if overrides.get("query_plan"):
        query_plan = rematch(list(overrides["query_plan"]), records)
    scored = clx.score_records(records, targets, query_plan)
    comp = clx.build_components(case, records, works, targets, query_plan, scored,
                                parsed, version_map, "partial", degradations)
    comp["errors"] = list(case.get("_errors", [])) + list(comp["errors"])
    comp["terminology"] = merge_terminology(
        comp["terminology"], overrides.get("terminology") or [])
    status = clx.classify_status(case, records, targets, comp["candidates"])
    comp["summary"]["status"] = status
    comp["change_records"] = changes + [
        {"step": "finalize", "detail": "status=%s" % status}]
    result = clx.assemble_result(case, comp)
    work_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    if write_partial:
        partial = dict(result)
        partial["status"] = ("partial" if status not in
                             ("input_error", "insufficient_evidence") else status)
        (work_dir / "result.partial.json").write_text(
            json.dumps(partial, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"case": case, "records": records, "works": works,
            "targets": targets, "query_plan": query_plan, "result": result,
            "parsed": parsed, "version_map": version_map,
            "changes": changes, "degradations": degradations}
def _draft_from(pipe):
    case = pipe["case"]
    return {
        "schema_version": 1,
        "case_id": case.get("case_id"),
        "research_question": {
            "text": (case.get("task_instruction") or "")[:2000],
            "source_language": clx.detect_language(case.get("task_instruction") or "")[0],
            "target_languages": sorted({r["tl"] for r in pipe["records"]
                                        if r["tl"] != "unknown"}),
        },
        "target_items": pipe["targets"],
        "terminology": pipe["result"].get("terminology", []),
        "query_plan": pipe["query_plan"],
        "language_overrides": {},
        "version_overrides": {},
        "dedup_overrides": {},
        "notes": [],
        "errors": case.get("_errors", []),
        "degradations": pipe["degradations"],
    }
def _save_draft(draft, work_dir):
    work_dir.mkdir(parents=True, exist_ok=True)
    (work_dir / "work-draft.json").write_text(
        json.dumps(draft, ensure_ascii=False, indent=2), encoding="utf-8")
def _save_records(records, work_dir):
    work_dir.mkdir(parents=True, exist_ok=True)
    (work_dir / "records.json").write_text(
        json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
def cmd_init(input_dir, work_dir, output_dir):
    pipe = run_pipeline(input_dir, work_dir, output_dir, overrides=None)
    _save_records(pipe["records"], work_dir)
    _save_draft(_draft_from(pipe), work_dir)
    return pipe
def cmd_build(input_dir, work_dir, output_dir):
    draft_path = work_dir / "work-draft.json"
    overrides = {}
    if draft_path.exists():
        try:
            overrides = json.loads(draft_path.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            overrides = {}
    if not isinstance(overrides, dict):
        overrides = {}
    pipe = run_pipeline(input_dir, work_dir, output_dir, overrides=overrides)
    return pipe
def cmd_check(input_dir, work_dir, output_dir):
    rp = output_dir / "result.json"
    report = {"result_exists": False, "json_valid": False, "case_id_present": False,
              "contract_keys_ok": None, "quote_hit_rate": None, "status": None,
              "notes": []}
    if not rp.exists():
        report["notes"].append("result.json missing")
        return report
    report["result_exists"] = True
    try:
        result = json.loads(rp.read_text(encoding="utf-8", errors="replace"))
        report["json_valid"] = True
    except Exception as e:
        report["notes"].append("result.json invalid: %s" % e)
        return report
    report["case_id_present"] = "case_id" in result
    report["status"] = result.get("status")
    case = load_case(input_dir)
    if isinstance(case.get("output_contract"), dict):
        missing = [k for k in case["output_contract"] if k not in result]
        report["contract_keys_ok"] = (len(missing) == 0)
        if missing:
            report["notes"].append("missing keys: %s" % missing[:10])
    cands = result.get("candidates") or []
    hits = 0
    total = 0
    for c in cands:
        if not c.get("quote"):
            continue
        total += 1
        src = os.path.join(str(input_dir), c.get("source_file") or "")
        if os.path.exists(src):
            try:
                text = clx._decode(open(src, "rb").read())
                if c["quote"] in text or json.dumps(c["quote"])[1:-1] in text:
                    hits += 1
            except Exception:
                pass
    report["quote_hit_rate"] = round(hits / total, 4) if total else None
    return report
def _write_error_result(case, output_dir, work_dir, msg):
    comp = {
        "research_question": {"text": case.get("task_instruction") or "",
                              "source_language": "unknown",
                              "target_languages": [],
                              "translation_service": "model-internal; n/a"},
        "terminology": [], "query_plan": [], "candidates": [],
        "deduplication": [], "ranking": {"method": "none", "precision_recall": None},
        "coverage_gaps": [], "sources": [], "uncertainty": [],
        "change_records": [{"step": "fatal", "detail": msg}],
        "errors": [msg], "degradations": [],
        "summary": {"records_total": 0, "works_total": 0, "candidates_total": 0,
                    "languages_seen": [], "status": "input_error"},
    }
    result = clx.assemble_result(case, comp)
    output_dir.mkdir(parents=True, exist_ok=True)
    work_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
def main(argv=None):
    ap = argparse.ArgumentParser(prog="main.py",
                                 description="Cross-language literature search")
    ap.add_argument("--input", help="input dir")
    ap.add_argument("--work", help="work dir")
    ap.add_argument("--output", help="output dir")
    sub = ap.add_subparsers(dest="cmd")
    for name in ("init", "show", "check", "build"):
        sub.add_parser(name)
    args = ap.parse_args(argv)
    input_dir, work_dir, output_dir = resolve_dirs(args)
    try:
        if args.cmd == "init":
            pipe = cmd_init(input_dir, work_dir, output_dir)
            print("init: %s rec=%d works=%d" % (
                pipe["result"]["status"], len(pipe["records"]), len(pipe["works"])))
        elif args.cmd == "show":
            draft_path = work_dir / "work-draft.json"
            rec_path = work_dir / "records.json"
            if not draft_path.exists():
                pipe = cmd_init(input_dir, work_dir, output_dir)
            try:
                draft = json.loads(draft_path.read_text(encoding="utf-8", errors="replace"))
                recs = json.loads(rec_path.read_text(encoding="utf-8", errors="replace")) if rec_path.exists() else []
            except Exception as e:
                print("show: bad draft: %s" % e)
                return 0
            print("case_id=%s" % draft.get("case_id"))
            print("targets=%d" % len(draft.get("target_items", [])))
            print("records=%d" % len(recs))
            print("term=%d qplan=%d" % (
                len(draft.get("terminology", [])), len(draft.get("query_plan", []))))
            for r in recs[:20]:
                print("  %s | %s | %s | %s" % (r.get("id"), r.get("tl"),
                                               r.get("doi"), (r.get("title") or "")[:60]))
        elif args.cmd == "check":
            report = cmd_check(input_dir, work_dir, output_dir)
            print(json.dumps(report, ensure_ascii=False, indent=2))
        elif args.cmd == "build":
            pipe = cmd_build(input_dir, work_dir, output_dir)
            print("build: %s cands=%d" % (
                pipe["result"]["status"], len(pipe["result"].get("candidates", []))))
        else:
            pipe = run_pipeline(input_dir, work_dir, output_dir)
            print("run: %s records=%d works=%d cands=%d" % (
                pipe["result"]["status"], len(pipe["records"]),
                len(pipe["works"]), len(pipe["result"].get("candidates", []))))
    except SystemExit:
        raise
    except Exception as e:
        try:
            _write_error_result(load_case(input_dir), output_dir, work_dir, "unhandled: %s" % e)
        except Exception:
            pass
        print("err(0): %s" % e)
    return 0
if __name__ == "__main__":
    sys.exit(main())
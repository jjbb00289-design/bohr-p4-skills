import json, os, re
def discover_files(root):
    out = []
    root = os.path.abspath(root)
    for dp, dn, fn in os.walk(root):
        dn.sort(); fn.sort()
        for f in fn:
            if not f.endswith(".pyc"):
                out.append(os.path.relpath(os.path.join(dp, f), root).replace("\\", "/"))
    return sorted(out)
def _decode(data):
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            return data.decode(enc)
        except Exception:
            continue
    return data.decode("utf-8", errors="replace")
def parse_material(rel, ap):
    ext = os.path.splitext(ap)[1].lower()
    r = {"rel": rel, "kind": "other", "text": "", "json_value": None, "error": None, "needs_ocr": False}
    try:
        data = open(ap, "rb").read()
        if ext == ".json" or (not ext and b"{" in data[:200]):
            r["kind"] = "json"; r["text"] = _decode(data)
            try:
                r["json_value"] = json.loads(r["text"])
            except Exception as e:
                r["error"] = "json: %s" % e
        elif ext == ".pdf" or data.startswith(b"%PDF"):
            r["kind"] = "pdf"; r["needs_ocr"] = True
        elif ext == ".docx":
            r["kind"] = "docx"; r["error"] = "docx: use platform tool"
        elif ext in (".sqlite", ".db", ".sqlite3"):
            r["kind"] = "sqlite"; r["error"] = "sqlite: use platform tool"
        elif ext in (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff"):
            r["kind"] = "image"; r["needs_ocr"] = True
        else:
            r["kind"] = "text"; r["text"] = _decode(data)
    except Exception as e:
        r["error"] = "read: %s" % e
    return r
_SIG = ("title", "doi", "author", "authors", "creator", "container-title", "journal",
        "year", "pubyear", "abstract", "abstracttext", "label", "name")
def _is_bib(d):
    if not isinstance(d, dict):
        return False
    n = 0
    for k in d:
        if k.lower().replace("_", "").replace("-", "") in _SIG:
            n += 1
            if n >= 2:
                return True
    return False
def _pick(d, keys):
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    return None
def _str(v):
    if v is None:
        return None
    if isinstance(v, list):
        return " ".join(x for x in (_str(x) for x in v) if x) or None
    if isinstance(v, dict):
        for k in ("#text", "value", "name", "title"):
            if k in v and v[k] is not None:
                return _str(v[k])
        return None
    return str(v).strip() or None
def _year(node):
    if isinstance(node, dict):
        dp = node.get("date-parts")
        if isinstance(dp, list) and dp:
            f = dp[0]
            if isinstance(f, list) and f and isinstance(f[0], int):
                return str(f[0])
            if isinstance(f, int):
                return str(f)
        if node.get("year") is not None:
            return str(node["year"])
    if isinstance(node, str):
        m = re.search(r"(18|19|20)\d{2}", node)
        return m.group(0) if m else None
    return None
def _norm_doi(v):
    if v is None:
        return None
    return re.sub(r"^(https?://)?(dx\.)?doi\.org/", "", str(v).strip().lower())
def _authors(node):
    if not isinstance(node, dict):
        return []
    out, seen = [], set()
    def add(o):
        if isinstance(o, str):
            s = o.strip()
        elif isinstance(o, dict):
            s = next((str(o[k]).strip() for k in ("fullName", "name", "fullname") if o.get(k)), "")
            if not s:
                s = (str(o.get("given", "") or "") + " " + str(o.get("family", "") or "")).strip()
        else:
            s = ""
        if s and s not in seen:
            seen.add(s); out.append(s)
    a = _pick(node, ("author", "authors", "creator", "authorList"))
    if isinstance(a, list):
        for x in a:
            add(x)
    elif isinstance(a, dict):
        for x in (a.get("author") or []):
            add(x)
    return out
def _walk(node, path, out):
    if isinstance(node, dict):
        if _is_bib(node):
            out.append((node, path or "root"))
        for k, v in node.items():
            _walk(v, (str(k) if not path else path + "." + str(k)), out)
    elif isinstance(node, list):
        for i, v in enumerate(node):
            _walk(v, ("[%d]" % i if not path else path + "[%d]" % i), out)
def _quote(raw, cands):
    if not raw:
        return None, None
    for f, c in cands:
        if not c or len(c.strip()) < 3:
            continue
        if c in raw:
            return c, f
        e = json.dumps(c)[1:-1]
        if e != c and e in raw:
            return c, f
    return None, None
def _record(raw, path, rel, text):
    title = _str(_pick(raw, ("title", "label", "name")))
    doi0 = _pick(raw, ("DOI", "doi"))
    abstract = _str(_pick(raw, ("abstract", "abstractText")))
    venue = _str(_pick(raw, ("container-title", "journal", "journalInfo")))
    ji = raw.get("journalInfo")
    if not venue and isinstance(ji, dict):
        jt = ji.get("journal")
        venue = _str(jt.get("title")) if isinstance(jt, dict) else _str(jt)
    year = next((str(raw[k]) for k in ("year", "pubYear", "publicationYear", "publicationyear", "pubyear")
                 if raw.get(k) is not None), None)
    if year is None:
        year = _year(_pick(raw, ("published", "published-print", "published-online", "date"))) \
            or _year(raw.get("publicationDate"))
    lang = _str(_pick(raw, ("language", "lang", "body_language")))
    body = _str(_pick(raw, ("bodyLanguage", "body_language", "originalLanguage")))
    q, qf = _quote(text, [("title", title), ("doi", doi0), ("abstract", abstract), ("venue", venue)])
    tl = detect_language(title or "")
    fl = (_str(_pick(raw, ("translation", "translated"))) or "").lower()
    return {"id": None, "title": title, "authors": _authors(raw), "year": year, "venue": venue,
            "doi": _norm_doi(doi0), "doi0": doi0, "abstract": abstract, "lang": lang, "body": body,
            "tl": tl[0], "tlc": tl[1], "abl": detect_language(abstract or "")[0],
            "src": rel, "loc": path, "q": q, "qf": qf, "fl": fl}
_CJK = "\u4e00-\u9fff"; _KANA = "\u3040-\u30ff"
_FUNC = {"en": "the and of with for from that this are was not have".split(),
         "pt": "de da do em com uma um para que na no não".split(),
         "es": "el la de en con una un que y por para".split(),
         "de": "der die das und mit für von ist nicht ein".split()}
def detect_language(text):
    if not text:
        return ("unknown", 0.0)
    if re.search("[%s]" % _CJK, text):
        return ("ja", 0.95) if re.search("[%s]" % _KANA, text) else ("zh", 0.9)
    words = re.findall(r"[a-zà-ÿ'’]+", text.lower())
    if not words:
        return ("unknown", 0.0)
    sc = {l: sum(words.count(f) for f in fs) for l, fs in _FUNC.items()}
    best = max(sc, key=sc.get); tot = sum(sc.values())
    return (best, round(min(sc[best] / tot, 0.95), 3)) if sc[best] else ("unknown", 0.0)
def normalize_title(t):
    if not t:
        return ""
    s = re.sub(r"https?://\S+", " ", t.lower())
    s = re.sub(r"[^\w\u4e00-\u9fff]+", " ", s, flags=re.UNICODE)
    return " ".join(s.split())
_DOI_RE = re.compile(r"10\.\d{4,9}/[-._;()/:A-Za-z0-9]+")
def extract_targets(text):
    items, seen = [], set()
    for m in _DOI_RE.finditer(text or ""):
        d = _norm_doi(m.group(0).rstrip(".,;)"))
        if d and d not in seen:
            seen.add(d); items.append({"type": "doi", "value": d, "source": "task_text"})
    for m in re.finditer(r"[\"“'\u300c]([^\"”'\u300d]{6,300})[\"”'\u300d]", text or ""):
        t = m.group(1).strip()
        if t and len(t.split()) >= 2 and t not in seen:
            seen.add(t); items.append({"type": "title", "value": t, "source": "task_text"})
    return items
_TRANS = ("translated", "translation", "tradução", "traducido", "traduzido", "versión")
_ABS = ("abstract only", "abstract in english", "english abstract", "resumo em inglês")
def detect_version(records):
    txt = {r["id"]: " ".join(x for x in (r["title"], r["abstract"], r["venue"], r["fl"]) if x).lower() for r in records}
    pre = {}
    for r in records:
        t = txt[r["id"]]; body = r["body"] or r["lang"] or r["tl"]
        absl = r["abl"] or r["tl"]; has_abs = bool((r["abstract"] or "").strip())
        if any(f in t for f in _ABS) or (has_abs and absl != body and body != "unknown" and r["tl"] == body):
            pre[r["id"]] = ("abstract_only", 0.7, "abs lang differs")
        elif any(f in t for f in _TRANS) or (body and body != r["tl"]):
            pre[r["id"]] = ("full_translation", 0.7, "trans flag")
        elif body and body == r["tl"]:
            pre[r["id"]] = ("original_body", 0.8, "decl body")
        else:
            pre[r["id"]] = ("unknown", 0.3, "none")
    keyed = {}
    for r in records:
        if pre[r["id"]][0] != "abstract_only":
            keyed.setdefault((r["doi"] or "", normalize_title(r["title"] or ""), r["tl"],
                              pre[r["id"]][0]), []).append(r)
    dups = set()
    for k, g in keyed.items():
        if k[0] and len(g) > 1:
            dups.update(r["id"] for r in g[1:])
    for rid in dups:
        pre[rid] = ("duplicate", 0.9, "dup: same DOI+lang")
    return pre
def extract_records(parsed):
    recs = []
    for pm in parsed:
        if pm["error"] and not pm["text"]:
            continue
        if pm["kind"] == "json" and pm["json_value"] is not None:
            hits = []
            _walk(pm["json_value"], "", hits)
            for raw, path in hits:
                recs.append(_record(raw, path, pm["rel"], pm["text"]))
    for i, r in enumerate(recs):
        r["id"] = "r%04d" % (i + 1)
    return recs
def build_works(records, ov=None):
    ov = ov or {}
    forced, fids = {}, set()
    for wid, o in ov.items():
        for rid in (o.get("merge") or []):
            forced[rid] = ("override", str(wid)); fids.add(rid)
    groups, order = {}, []
    for r in records:
        if r["id"] in fids:
            key = forced[r["id"]]
        elif r["doi"]:
            key = ("doi", r["doi"])
        elif r["title"]:
            key = ("title", normalize_title(r["title"]))
        else:
            key = ("single", r["id"])
        if key not in groups:
            groups[key] = []; order.append(key)
        groups[key].append(r)
    works = []
    for i, key in enumerate(order):
        g = groups[key]
        conf = {"doi": "doi_exact", "title": "title_exact", "single": "singleton", "override": "manual_merge"}[key[0]]
        prim = max(g, key=lambda r: sum(1 for x in (r["title"], r["doi"], r["authors"], r["year"]) if x))
        works.append({"work_id": "w%d" % (i + 1), "key": list(key), "title": prim["title"],
                      "doi": prim["doi"], "year": prim["year"], "venue": prim["venue"],
                      "authors": prim["authors"], "view_ids": [r["id"] for r in g], "view_count": len(g),
                      "languages": sorted({r["tl"] for r in g if r["tl"] != "unknown"}), "confidence": conf})
    return works
def build_terminology(works, records):
    by = {r["id"]: r for r in records}; out = []
    for w in works:
        langs, ev = {}, {}
        for rid in w["view_ids"]:
            r = by[rid]
            if r["title"] and r["tl"] != "unknown":
                langs.setdefault(r["tl"], r["title"])
                ev.setdefault(r["tl"], {"source": r["src"], "locator": r["loc"], "quote": r["q"] if r["qf"] == "title" else None})
        if len(langs) >= 2:
            out.append({"concept": w["title"] or w["doi"] or w["work_id"], "work_id": w["work_id"],
                        "doi": w["doi"], "language_pairs": langs, "evidence": ev})
    return out
def build_query_plan(case_text, records, targets, works):
    plan, qid, seen = [], 0, set()
    def add(lang, q, why, ids):
        nonlocal qid
        qid += 1
        plan.append({"id": "q%d" % qid, "language": lang, "query": q, "rationale": why,
                     "matched_record_ids": ids})
    def match(q, field="title"):
        ids = []
        if field == "doi":
            for r in records:
                if r["doi"] == q:
                    ids.append(r["id"])
        else:
            qt = normalize_title(q)
            for r in records:
                rt = normalize_title(r["title"] or "")
                if qt and (qt in rt or rt in qt):
                    ids.append(r["id"])
        return ids
    add(detect_language(case_text or "")[0], (case_text or "")[:400], "orig", [])
    for t in targets:
        if t["type"] == "doi":
            if t["value"] in seen:
                continue
            seen.add(t["value"]); add("any", t["value"], "DOI lookup", match(t["value"], "doi"))
        else:
            k = normalize_title(t["value"])
            if k in seen:
                continue
            seen.add(k)
            add(detect_language(t["value"])[0], t["value"], "title", match(t["value"], "title"))
    for term in build_terminology(works, records):
        for lang, title in sorted(term["language_pairs"].items()):
            k = normalize_title(title)
            if k in seen:
                continue
            seen.add(k)
            add(lang, title, "variant", match(title, "title"))
    return plan
def score_records(records, targets, query_plan):
    tdois = {t["value"] for t in targets if t["type"] == "doi"}
    ttitles = [normalize_title(t["value"]) for t in targets if t["type"] == "title"]
    matched = set()
    for q in query_plan:
        matched.update(q["matched_record_ids"])
    scored = []
    for r in records:
        s, why = 0.0, []
        if r["doi"] and r["doi"] in tdois:
            s += 10.0; why.append("doi_exact_match")
        rt = normalize_title(r["title"] or "")
        for tt in ttitles:
            if rt and tt and (tt == rt or tt in rt or rt in tt):
                s += 5.0; why.append("title_overlap"); break
        if r["id"] in matched:
            s += 1.0; why.append("query_match")
        meta = sum(1 for x in (r["title"], r["doi"], r["authors"], r["year"]) if x)
        scored.append((s + 0.01 * meta, why, r))
    scored.sort(key=lambda t: (-t[0], t[2]["id"]))
    return scored
def precision_recall(scored, targets, k=5):
    gd = {t["value"] for t in targets if t["type"] == "doi"}
    gt = {normalize_title(t["value"]) for t in targets if t["type"] == "title"}
    if not gd and not gt:
        return None
    top = [r for _, _, r in scored][:k]
    hit = lambda r: (r["doi"] and r["doi"] in gd) or (r["title"] and normalize_title(r["title"]) in gt)
    rel = [r for r in top if hit(r)]
    found = {("d", r["doi"]) for r in rel if r["doi"] in gd} | \
            {("t", normalize_title(r["title"])) for r in rel if r["title"]}
    found = {x for x in found if x[0] == "d" or x[1] in gt}
    ng = len(gd | gt)
    return {"k": k, "precision": round(len(rel) / max(1, len(top)), 4),
            "recall": round(len(found) / max(1, ng), 4), "gold_count": ng,
            "gold_hit": len(found), "rec_hit": len(rel), "method": "precision@k/recall@k vs named items"}
def _cand(rank, r, vmap, score, why):
    v = vmap.get(r["id"], ("unknown", 0.0, ""))
    return {"rank": rank, "record_id": r["id"], "title": r["title"], "authors": r["authors"],
            "year": r["year"], "venue": r["venue"], "doi": r["doi0"] or r["doi"], "language": r["tl"],
            "lang_conf": r["tlc"], "version_type": v[0], "ver_conf": v[1], "version_reason": v[2],
            "body_language": r["body"] or r["tl"],
            "source_file": r["src"], "locator": r["loc"], "quote": r["q"], "relevance_score": score, "reasons": why}
def _t_hit(cands, t):
    if t["type"] == "doi":
        return any(_norm_doi(c["doi"] or "") == t["value"] for c in cands)
    return any(normalize_title(c["title"] or "") == normalize_title(t["value"]) for c in cands)
def build_components(case, records, works, targets, query_plan, scored, parsed, vmap, status, deg):
    cands = []
    for rank0, (score, why, r) in enumerate(scored):
        if score <= 0:
            break
        cands.append(_cand(rank0 + 1, r, vmap, round(score, 3), why))
    if not cands:
        cands = [_cand(i + 1, r, vmap, 0.0, ["no_score"]) for i, r in enumerate(records)]
    ranking = {"method": "weighted: DOI=10 title=5 query=1 meta",
               "precision_recall": precision_recall(scored, targets)}
    sources = [{"file": pm["rel"], "kind": pm["kind"], "records": sum(1 for r in records if r["src"] == pm["rel"]),
                "needs_ocr": pm["needs_ocr"], "error": pm["error"]} for pm in parsed]
    unc = []
    for r in records:
        if not r["q"]:
            unc.append({"record_id": r["id"], "type": "missing_quote", "source_file": r["src"]})
        if vmap.get(r["id"], ("unknown", 0, ""))[0] == "unknown":
            unc.append({"record_id": r["id"], "type": "version_unknown", "source_file": r["src"]})
        if r["tl"] == "unknown":
            unc.append({"record_id": r["id"], "type": "language_unknown", "source_file": r["src"]})
    gaps = []
    for t in targets:
        if not _t_hit(cands, t):
            gaps.append({"type": "target_not_found", "value": t["value"]})
    for q in query_plan:
        if not q["matched_record_ids"] and q["query"]:
            gaps.append({"type": "query_no_result", "query": q["query"], "language": q["language"]})
    langs = sorted({r["tl"] for r in records if r["tl"] != "unknown"})
    comp = {"research_question": {
                "text": (case.get("task_instruction") or "")[:2000],
                "source_language": detect_language(case.get("task_instruction") or "")[0],
                "target_languages": langs, "translation_service": "model-internal; n/a"},
            "terminology": build_terminology(works, records), "query_plan": query_plan, "candidates": cands,
            "deduplication": works, "ranking": ranking, "coverage_gaps": gaps, "sources": sources,
            "uncertainty": unc, "change_records": [], "errors": [], "degradations": deg,
            "summary": {"records_total": len(records), "works_total": len(works), "candidates_total": len(cands),
                        "languages_seen": langs, "status": status}}
    return comp
def classify_status(case, records, targets, cands):
    if case.get("_input_error"):
        return "input_error"
    if not records:
        return "insufficient_evidence"
    if not targets:
        return "partial"
    if all(_t_hit(cands, t) for t in targets):
        return "complete" if (cands and all(c.get("quote") for c in cands)) else "partial"
    return "partial"
_KEY = (("chang", "change_records"), ("candid", "candidates"), ("result", "candidates"),
        ("paper", "candidates"), ("record", "candidates"), ("term", "terminology"),
        ("quer", "query_plan"), ("search", "query_plan"), ("dedup", "deduplication"),
        ("duplicat", "deduplication"), ("work", "deduplication"), ("version", "deduplication"),
        ("rank", "ranking"), ("gap", "coverage_gaps"), ("miss", "coverage_gaps"),
        ("cover", "coverage_gaps"), ("research", "research_question"), ("question", "research_question"),
        ("task", "research_question"), ("uncertain", "uncertainty"), ("error", "errors"),
        ("degrad", "degradations"), ("summar", "summary"), ("status", "status"),
        ("source", "sources"), ("evidence", "sources"))
def derive_field(key, comp, case_id):
    k = key.lower().replace("-", "_").replace(" ", "")
    if k == "case_id":
        return case_id
    if k == "status":
        return comp["summary"]["status"]
    for frag, cname in _KEY:
        if frag in k:
            return comp[cname]
    return None
def assemble_result(case, comp):
    contract = case.get("output_contract") or {}
    result = {}
    if isinstance(contract, dict):
        for key in contract:
            result[key] = derive_field(key, comp, case.get("case_id"))
    result.setdefault("case_id", case.get("case_id"))
    result.setdefault("status", comp["summary"]["status"])
    result.setdefault("sources", comp["sources"])
    result.setdefault("uncertainty", comp["uncertainty"])
    result.setdefault("change_records", comp["change_records"])
    for std in ("research_question", "terminology", "query_plan", "candidates", "deduplication",
                "ranking", "coverage_gaps", "errors", "degradations", "summary"):
        if std not in result:
            result[std] = comp[std]
    return result
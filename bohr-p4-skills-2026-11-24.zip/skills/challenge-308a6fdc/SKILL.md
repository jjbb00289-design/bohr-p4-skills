---
name: manuscript-writer-v2
description: Academic manuscript writing skill. init|show|extract-facts|check|build workflow; build DERIVES a complete, section-complete, traceable manuscript from /input when no usable draft exists (stdlib only, deterministic).
---

# Manuscript Writer v2

Write an editable academic manuscript (Markdown + text preview) from the
materials under `/input`, or validate and finalize an existing agent draft.

## Workflow

```
python3 scripts/main.py init            # scan materials -> /app/work/index.json
python3 scripts/main.py show            # list materials (--material m1 --grep PATTERN)
python3 scripts/main.py extract-facts   # candidate numbers/DOIs
python3 scripts/main.py check [--draft] # verify draft -> check_report.json
python3 scripts/main.py build [--draft] # write manuscript.md/.txt + fact_evidence.json + result.json
```

`--input/--work/--output` default to `/input`, `/app/work`, `/app/output`.
All commands exit 0. `build` runs `init` implicitly when `index.json` is absent.

## No-draft DERIVED_PATTERN

If `--draft` (default `/app/work/draft.json`) is missing/unusable, `build`
**derives** a manuscript instead of failing:

1. Read material text, split into segments, record `locator = material_id#pN`.
2. Infer required sections (the 8 canonical sections first, then any
   task-specific ones). Every required section is emitted; unmapped sections
   are kept with an `_insufficient_evidence` note.
3. Transcribe statements **verbatim** into the body sections with a per-statement `[locator]`.
4. Extract preserved numeric facts and a claim map (`fact_evidence.json`), each
   with `locator` + verbatim `quote`.
5. References list only entries found verbatim in materials; if none, the list
   is empty with a note. **DOIs are never fabricated.**

Result is honest: `status=partial`, `result.derived=true`, and `degradations`
records the derive path. A usable agent draft is kept and only validated.

## Traceability contract

- Every claim/fact has `source_id`/`mid`, `locator` (`mN#pK`) and a `quote`
  byte-verbatim in the material.
- `check` reports: missing case_id, short body, missing sections, empty
  facts/evidence, non-verbatim quotes, values not in quote, fabricated DOIs,
  untraced numbers.
- References: only verbatim lines with a DOI, doi-marker, or author-year.

## Output files

`manuscript.md`, `manuscript.txt`, `fact_evidence.json` (`claims`, `facts`,
`references`, `coverage`), `result.json` (echoes every `/input/case.json`
`output_contract` key; always contains `case_id`, `status`, `result`, `claims`,
`coverage`).

## Degradations (honest limitations)

| Case | Behavior |
| --- | --- |
| No materials | `status=input_error`, `errors=["no input materials"]`, exit 0 |
| PDF/DOCX/DOC | recorded as `document` with "not text-extracted" note |
| Binary/image | recorded as `binary/image`, not text-extracted |
| Empty/bad `case.json` | sections default to canonical 8 |
| Outline/workorder | read from `case.json` `workorder`/`targets` fields |

## Minimal example

```bash
python3 scripts/main.py init
python3 scripts/main.py build
cat /app/output/result.json
```

## output_contract 占位防护（v2）

`output_contract` 的 `array`、`string`、`object` 等字符串是**字段类型说明**，不得作为运行结果。可从真实稿件/证据映射的字段返回真实对象、数组或文本；无数据时用 `null`、`[]` 和降级说明，不回显契约的类型占位符。每次修改 `echo_contract` 后运行占位值测试。

## Contract deliverables (v2 hotfix)

The value of each `output_contract` key is **runtime data**, not the schema's
`array`/`string`/`object` label. When `build` has actually written a nonempty
file in `--output`, `manuscript` is the relative path from
`result.deliverables.manuscript` and `fact_evidence` is the path from
`result.deliverables.fact_evidence`. `references` is a real list read from
`fact_evidence.json`, or `[]` if no references were supported. Missing artifacts
are `null`, with a corresponding `gaps` entry. These fields are populated even
for `status=partial`; the status still reflects incomplete scholarly validation.
`uncertainty` and `change_records` also preserve the actual lists.

Example (illustrative only; not a prepared case result):

```bash
python3 scripts/main.py build --input /input --work /app/work --output /app/output
```

# Contract

`result.json` fields (top level): `case_id`, `status` (`ok` | `partial` |
`input_error`), `deliverable`, `preserved_facts`, `evidence_map`, `change_log`,
`claims`, `coverage`, `result` (`deliverables`, `sections`, `counts`, `gaps`,
`derived`), `sources`, `uncertainties`, `errors`, `degradations`.

- Every key declared in `/input/case.json` `output_contract` is present with a
  measured runtime value, or `null` and a concrete `gaps`/`degradations` reason.
  Schema-type strings are never copied as output values.
- `case_id` is preserved from `case.json` (`case_id` or `id`) through
  `index.json` and the draft into `result.json`.
- `coverage`: `sections_required`, `sections_present`, `claims`, `facts`.
- `claims` = `evidence_map`: each entry `{claim_id, section, source_id,
  locator, quote, kind}` with kinds `observation | interpretation | method |
  literature | limitation | background`.
- `preserved_facts`: `{fact_id, value, unit, source_id, locator, quote,
  status}`; capped at 400 (flagged via `_facts_truncated`).
- `change_log`: `{change_id, original, revised, reason, locator}` when a draft
  is edited; empty for the derived path.
- `sources`: `{material_id, path, kind, text_chars}` per material.
- Determinism: two `build` runs on the same `/input` produce byte-identical
  `result.json` (no timestamps, no randomness, fixed key order, CWD-independent).

## Subcommands

`init` (scan + index + partial result), `show` (list; `--material` prints
segments), `extract-facts` (candidates), `check`/`selfcheck` (validate draft),
`build` (finalize or derive). All accept `--input/--work/--output`; `--draft`
on `check`/`build`.

## Guarantees

- stdlib only; no network; deterministic; always exit 0.
- Never drop a required section; missing content uses `_insufficient_evidence`.
- Never fabricate a DOI or a reference; empty list + note when none exist.
- Every statement carries a material locator and a verbatim quote.

## Additional contract aliases

`manuscript` and `fact_evidence` are verified relative file paths from
`result.deliverables`, or null if the file was not written. `references` is
always a JSON list from `fact_evidence.json` (possibly empty). Do not treat
`partial` as equivalent to no artifact: usable intermediate files can exist
while evidence is incomplete.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""manuscript-writer v2 - academic manuscript writing skill (stdlib only)."""
import argparse as ap
import json
import os
import re
import sys
import traceback
from pathlib import Path

VERSION = "2.0.0"
MAX_READ = 2_000_000
KIND = {".pdf": "document", ".docx": "document", ".doc": "document", ".md": "text",
        ".txt": "text", ".tex": "text", ".html": "text", ".htm": "text", ".json": "json",
        ".csv": "table", ".tsv": "table", ".xlsx": "table", ".png": "image",
        ".jpg": "image", ".jpeg": "image", ".svg": "image", ".tif": "image",
        ".tiff": "image", ".bmp": "image", ".gif": "image"}
DOI_RE = re.compile(r"\b10\.\d{4,9}/[-._;()/:A-Za-z0-9]+")
YEAR_RE = re.compile(r"\b(?:19|20)\d{2}\b")
NUM = re.compile(r"\b\d+(?:[.,]\d+)?\b")
NUMU = re.compile(r"(?<![\w.])([+-]?\d+(?:[.,]\d+)?)\s*(%|‰|[a-zA-ZµμΩ°]{1,6}(?:/[a-zA-ZµμΩ]{1,4})?)?")
MARK = re.compile(r"^(?:[-*•]|\d+[.)]|\[[^\]]{1,12}\])\s+")
CANON = ["Abstract", "Introduction", "Methods", "Results", "Discussion", "Conclusion", "References"]
FRAME = "Statements transcribed verbatim from the materials."
PLAN = ("outline", "workorder", "plan")
INSUF = "_insufficient_evidence: no source statement maps to this section._"
NOREFS = "_insufficient_evidence: no reference entries in materials._"
RULES = [("References", r"(doi\s*[:.]|doi\.org|et al|arxiv|pmid|reference|bibliography)"),
         ("Abstract", r"\b(abstract|summary)\b"),
         ("Methods", r"\b(method|protocol|procedure|experimental|participant|reagent|instrument|apparatus|setup|design|sample size|n\s*=|measured|conducted|recruited)\b"),
         ("Conclusion", r"\b(conclusion|conclude|in summary|taken together|overall)\b"),
         ("Discussion", r"\b(discussion|interpret|suggest|implication|limitation|consistent|contrast|explain|unavailable)\b"),
         ("Introduction", r"\b(introduction|background|prior work|related work|motivation|context)\b"),
         ("Results", r"\b(result|finding|observed|measured|reached|showed|figure|table|significant)\b")]


def jd(p, o):
  p = Path(p)
  p.parent.mkdir(parents=True, exist_ok=True)
  p.write_text(json.dumps(o, ensure_ascii=False, indent=2), encoding="utf-8")
  return p


def jl(p, d=None):
  try:
    return json.loads(read_text(p).lstrip("\ufeff"))
  except Exception:
    return d


def norm(t):
  if t is None:
    return ""
  return re.sub(r"\s+", " ", str(t).replace("\u3000", " ").replace("\xa0", " ")).strip().lower()


def read_text(path, limit=MAX_READ):
  try:
    raw = Path(path).read_bytes()[:limit]
  except Exception:
    return ""
  for enc in ("utf-8-sig", "utf-16", "gb18030", "latin-1"):
    try:
      return raw.decode(enc)
    except Exception:
      continue
  return raw.decode("utf-8-sig", "replace")


def segs(text, mid):
  if not text:
    return []
  out, buf = [], ""
  for part in re.split(r"\n\s*\n|\n(?=\[page )", text):
    part = part.strip()
    if not part:
      continue
    if buf and len(buf) + len(part) > 1600:
      out.append(buf)
      buf = part
    else:
      buf = (buf + "\n" + part).strip() if buf else part
  if buf:
    out.append(buf)
  return [{"locator": "%s#p%d" % (mid, i + 1), "text": x} for i, x in enumerate(out)]


def is_plan(name):
  return any(k in name.lower() for k in PLAN)


def discover(input_dir):
  mats = []
  d = Path(input_dir)
  if not d.exists():
    return mats
  files = []
  for root, dirs, names in os.walk(str(d)):
    dirs[:] = [x for x in sorted(dirs) if x not in (".git", "__pycache__", "node_modules")]
    for name in sorted(names):
      files.append(Path(root) / name)
  counter = 0
  for p in files:
    if p.name.startswith(".") or (p.parent == d and p.name in ("case.json", "task.md")) \
       or is_plan(p.name):
      continue
    counter += 1
    mid = "m%d" % counter
    e = {"material_id": mid, "path": p.relative_to(d).as_posix(),
         "kind": KIND.get(p.suffix.lower()) or "other", "notes": []}
    try:
      if e["kind"] in ("text", "json", "table"):
        text = read_text(p)
      elif e["kind"] == "document":
        text = ""
        e["notes"].append("not text-extracted")
      else:
        text = ""
        e["notes"].append("binary/image")
      e["text_chars"] = len(text)
      e["_segments"] = segs(text, mid)
    except Exception:
      e["notes"].append("scan failed")
      e["_segments"] = []
      e["text_chars"] = 0
    mats.append(e)
  return mats


def sentences(text):
  out = []
  for chunk in re.split(r"\n+", text or ""):
    for s in re.split(r"(?<=[.!?])\s+", chunk.strip()):
      if s.strip():
        out.append(s.strip())
  return out


def strip_markers(s):
  s = (s or "").strip()
  m = MARK.match(s)
  return s[m.end():].strip() if m else s


def classify(t):
  t = (t or "").lower()
  for sec, pat in RULES:
    if re.search(pat, t):
      return sec
  return "Results" if NUM.search(t) else "Introduction"


def required_sections(case):
  for key in ("required_sections", "sections_required", "section_list", "sections"):
    v = case.get(key)
    if isinstance(v, list) and v and all(isinstance(x, str) for x in v):
      return [x for x in v if x]
    if isinstance(v, list) and v and isinstance(v[0], dict):
      f = [str(x.get("heading") or x.get("name") or "").strip() for x in v
           if x.get("heading") or x.get("name")]
      if f:
        return f
  return []


def infer_sections(case):
  found = list(required_sections(case))
  blob = json.dumps(case.get("workorder") or case.get("targets") or [], ensure_ascii=False)
  for s in CANON:
    if s.lower() in blob.lower():
      found.append(s)
  out, seen = [], set()
  for s in CANON + found:
    if s and s.lower() not in seen:
      seen.add(s.lower())
      out.append(s)
  return out


def segs_by_material(work, index):
  out = {}
  for m in index.get("materials", []):
    mid = m["material_id"]
    out[mid] = (jl(Path(work) / "segments" / (mid + ".json"), {}) or {}).get("segments") or []
  return out


def material_blob(work, index):
  texts = []
  for ss in segs_by_material(work, index).values():
    texts.extend(x.get("text", "") or "" for x in ss)
  return norm(" \n ".join(texts))


def extract_refs(sb):
  refs, seen = [], set()
  for mid in sb:
    for s in sb[mid]:
      loc = s.get("locator") or mid
      for line in (s.get("text") or "").splitlines():
        line = line.strip()
        low = line.lower()
        if not line or line.startswith("#") or low in ("references", "bibliography"):
          continue
        hy = bool(YEAR_RE.search(line))
        if not (DOI_RE.search(line) or re.search(r"(doi\s*[:.]|doi\.org|arxiv|pmid)", low)
                or (hy and re.search(r"[A-Z][A-Za-z]{2,}", line))):
          continue
        key = (mid, loc, norm(line))
        if key in seen:
          continue
        seen.add(key)
        doi = DOI_RE.search(line)
        refs.append({"ref_id": "r%d" % (len(refs) + 1), "mid": mid, "locator": loc,
                     "quote": line, "doi": (doi.group(0).rstrip(".,;") if doi else None)})
  return refs


def number_facts(units):
  facts, seen = [], set()
  for u in units:
    for m in NUMU.finditer(u["clean"]):
      v = m.group(1)
      if not v or re.fullmatch(r"(?:19|20)\d{2}", v):
        continue
      doi = DOI_RE.search(u["clean"])
      if doi and v in doi.group(0):
        continue
      key = (v, u["mid"], u["locator"], norm(u["clean"]))
      if key in seen:
        continue
      seen.add(key)
      facts.append({"fact_id": "f%d" % (len(facts) + 1), "value": v,
                    "unit": (m.group(2) or "").strip(), "source_id": u["mid"],
                    "locator": u["locator"], "quote": u["clean"], "status": "preserved"})
  return facts[:400], len(facts) > 400


def claim_kind(sec, c):
  t = (c or "").lower()
  return "limitation" if re.search(r"limitation|not (?:evaluated|reported|measured)|unavailable", t) \
    else "literature" if sec == "References" \
    else "method" if sec == "Methods" \
    else "observation" if sec in ("Results", "Abstract") \
    else "interpretation" if sec in ("Discussion", "Conclusion") \
    else "background"


def build_units(sb):
  units = []
  for mid in sb:
    for s in sb[mid]:
      loc = s.get("locator") or mid
      cur = None
      for line in (s.get("text") or "").splitlines():
        ls = line.strip()
        if not ls:
          continue
        if ls.startswith("#"):
          h = ls.lstrip("#").strip().lower()
          cur = next((sec for sec in CANON if sec.lower() in h), cur)
          continue
        clean = strip_markers(ls)
        if not clean:
          continue
        if DOI_RE.search(clean) or re.search(r"et al", clean, re.I):
          continue
        units.append({"mid": mid, "locator": loc, "section": cur or classify(clean), "clean": clean})
  seen, uniq = set(), []
  for u in units:
    k = (u["mid"], u["locator"], norm(u["clean"]))
    if k not in seen:
      seen.add(k)
      uniq.append(u)
  return uniq


def derive(args, index, case):
  work = Path(args.work)
  sb = segs_by_material(work, index)
  required = infer_sections(case)
  units = build_units(sb)
  refs = extract_refs(sb)
  facts, truncated = number_facts(units)
  title = str(case.get("title") or case.get("task_title") or "Derived manuscript").strip()
  group = {}
  for u in units:
    group.setdefault(u["section"], []).append(u)
  numeric = [u for u in units if NUM.search(u["clean"])]
  sections, rendered = [], []
  for sec in required:
    su = list(group.get(sec, []))
    if sec == "Abstract" and not su:
      su = list(numeric[:3])
    content = []
    if sec == "References":
      if refs:
        content.append("Only verbatim reference entries are listed; no DOIs fabricated.")
        content.append("")
        for r in refs:
          content.append('- "%s" [%s]' % (r["quote"], r["locator"]))
          rendered.append((sec, r))
      else:
        content.append(NOREFS)
    elif not su:
      content.append(INSUF)
    else:
      content.append(FRAME)
      content.append("")
      for u in su:
        content.append('- "%s" [%s]' % (u["clean"], u["locator"]))
        rendered.append((sec, u))
    sections.append({"heading": sec, "level": 2, "content": "\n".join(content)})
  claims = []
  for i, (sec, u) in enumerate(rendered, 1):
    q = u.get("clean") or u.get("quote")
    claims.append({"claim_id": "c%d" % i, "section": sec, "source_id": u.get("mid"),
                   "locator": u["locator"], "quote": q, "kind": claim_kind(sec, q)})
  gaps = [{"item": s["heading"] + " section", "reason": "no source statement mapped",
           "action": "flagged_for_human"} for s in sections
          if "insufficient_evidence" in s["content"]]
  return {"case_id": case.get("case_id") or case.get("id") or index.get("case_id") or "",
          "title": title, "sections": sections, "preserved_facts": facts,
          "evidence_map": claims, "change_log": [], "citations": refs, "gaps": gaps,
          "uncertainties": [{"item": "derived manuscript",
                             "why": "derived automatically; needs human review"}],
          "derived": True, "_facts_truncated": truncated}


def sig_numbers(text):
  return [m.group(0) for m in NUM.finditer(text or "")
          if "." in m.group(0) or "," in m.group(0) or len(m.group(0)) >= 2]


def run_checks(work, index, draft, manuscript):
  F = []
  if not isinstance(draft, dict) or not draft:
    return {"passed": False, "fails": ["no-draft"], "warnings": [], "passes": [], "counts": {}}
  total = material_blob(work, index)
  body = (manuscript or "").strip()
  if not draft.get("case_id"):
    F.append("case_id-missing")
  if len(body) < 80:
    F.append("body-too-short")
  heads = [str(s.get("heading") or "").strip().lower() for s in (draft.get("sections") or [])]
  required = index.get("required_sections") or []
  if required:
    miss = [w for w in required if not any(
      w.strip().lower() in h or h in w.strip().lower() for h in heads)]
    if miss:
      F.append("sections-missing:" + ",".join(miss))
  facts = draft.get("preserved_facts") or []
  ev = draft.get("evidence_map") or []
  ch = draft.get("change_log") or []
  nums = sig_numbers(re.sub(r"\[m\d+#p\d+\]", " ", manuscript or ""))
  if not facts and nums:
    F.append("facts-empty")
  for i, f in enumerate(facts):
    t = f.get("fact_id") or ("f%d" % i)
    q = f.get("quote")
    if not q:
      F.append("%s:no-quote" % t)
      continue
    if norm(q) not in total:
      F.append("%s:quote-not-verbatim" % t)
    v = norm(f.get("value"))
    if v and v not in norm(q):
      F.append("%s:value-not-in-quote" % t)
  if not ev:
    F.append("evidence-empty")
  for m in DOI_RE.finditer(manuscript or ""):
    d = m.group(0).rstrip(".,;")
    if norm(d) not in total:
      F.append("doi-fabricated:" + d)
  fv = set()
  for f in facts:
    n = norm(f.get("value"))
    if n:
      fv.add(n)
      fv.add(n.replace(",", "."))
  unt = [t for t in nums if norm(t) not in fv and norm(t.replace(",", ".")) not in fv
         and norm(t) not in total and norm(t.replace(",", ".")) not in total]
  if unt:
    F.append("numbers-untraced:" + ",".join(sorted(set(unt))[:12]))
  return {"passed": not F, "fails": F, "warnings": [], "passes": [],
          "counts": {"sections": len(draft.get("sections") or []),
                     "preserved_facts": len(facts), "evidence_map": len(ev),
                     "change_log": len(ch), "manuscript_chars": len(body)}}


def print_check(r):
  print(json.dumps({"passed": r.get("passed"), "counts": r.get("counts", {}),
                    "FAIL": r.get("fails", []), "WARN": r.get("warnings", [])},
                   ensure_ascii=False, indent=2))


def manuscript_of(draft):
  parts = []
  if (draft or {}).get("title"):
    parts.append("# " + str(draft["title"]).strip())
  for s in ((draft or {}).get("sections") or []):
    h = str(s.get("heading") or "").strip()
    if h:
      parts.append("## " + h)
    b = s.get("content")
    if isinstance(b, list):
      b = "\n\n".join(str(x) for x in b)
    if b:
      parts.append(str(b).strip())
  return "\n\n".join(x for x in parts if x).strip() + "\n"


def load_case(input_dir):
  case = jl(Path(input_dir) / "case.json", None)
  if not isinstance(case, dict):
    return {}, ["case.json missing or not a JSON object"]
  return case, []


def load_draft(args):
  p = Path(args.draft) if getattr(args, "draft", None) else (Path(args.work) / "draft.json")
  d = jl(p, None)
  return (d if isinstance(d, dict) else None), str(p)


def usable(draft):
  if not isinstance(draft, dict):
    return False
  return bool(draft.get("title")) or bool(draft.get("preserved_facts") or draft.get("evidence_map")) \
    or any((s.get("heading") or "").strip() and str(s.get("content") or "").strip()
           for s in (draft.get("sections") or []) if isinstance(s, dict))


def echo_contract(contract, base, output_dir=None):
  """Populate each contract key with measured data, never a type placeholder.

  A partial manuscript can still have real editable deliverables.  Map those
  independently of overall status, checking that reported files actually exist.
  """
  contract_keys = list(contract) if isinstance(contract, (dict, list)) else []
  result = base.get("result") if isinstance(base.get("result"), dict) else {}
  deliverables = result.get("deliverables") if isinstance(result.get("deliverables"), dict) else {}
  out = Path(output_dir) if output_dir is not None else None
  missing = []
  type_names = {"array", "string", "object", "number", "boolean", "integer",
                "text", "list", "dict"}

  def valid_artifact(key):
    name = deliverables.get(key)
    if not isinstance(name, str) or not name or out is None:
      return None
    path = out / name
    # Refuse stale paths or directories; keep paths relative to /app/output.
    try:
      path.resolve().relative_to(out.resolve())  # Reject paths outside output.
      if not path.is_file() or path.stat().st_size == 0:
        return None
    except (OSError, ValueError):
      return None
    return name

  manuscript = valid_artifact("manuscript")
  fact_evidence = valid_artifact("fact_evidence")
  ref_entries = []
  if fact_evidence:
    fact_obj = jl(out / fact_evidence, {})
    if isinstance(fact_obj, dict) and isinstance(fact_obj.get("references"), list):
      ref_entries = fact_obj["references"]
  elif isinstance(result.get("references"), list):
    ref_entries = result["references"]

  candidates = {
      "manuscript": manuscript,
      "manuscript_text": valid_artifact("manuscript_text"),
      "fact_evidence": fact_evidence,
      "references": ref_entries,
      "citations": ref_entries,
      "deliverables": deliverables,
      "sections": result.get("sections", []),
      "facts": base.get("preserved_facts", []),
      "uncertainty": base.get("uncertainties", []),
      "change_records": base.get("change_log", []),
      "gaps": result.get("gaps", []),
  }
  for k in contract_keys:
    if not isinstance(k, str):
      continue
    original = base.get(k)
    # Do not skip a known field merely because it already exists as None.
    if k in candidates:
      value = candidates[k]
    else:
      value = original
    if isinstance(value, str) and value.strip().lower() in type_names:
      value = None
    if value is None:
      missing.append(k)
    base[k] = value

  # Retain honest provenance fields even when not explicitly named in contract.
  base.setdefault("uncertainty", base.get("uncertainties", []))
  base.setdefault("change_records", base.get("change_log", []))
  if missing:
    base.setdefault("degradations", []).append(
        "output_contract keys unavailable: " + ", ".join(dict.fromkeys(missing)))
    base.setdefault("gaps", []).extend(
        "contract field %s lacks a verified source/artifact" % k for k in dict.fromkeys(missing))
  return base


def sources_of(index):
  return [{k: m.get(k) for k in ("material_id", "path", "kind", "text_chars")}
          for m in index.get("materials", [])]


def cmd_init(args):
  work, out = Path(args.work), Path(args.output)
  work.mkdir(parents=True, exist_ok=True)
  out.mkdir(parents=True, exist_ok=True)
  errors, deg = [], []
  case, notes = load_case(args.input)
  deg.extend(notes)
  if not Path(args.input).exists():
    errors.append("input dir does not exist")
    deg.append("no input dir")
  mats = discover(args.input)
  if not mats and Path(args.input).exists():
    deg.append("no material files")
  for m in mats:
    if m.get("_segments"):
      try:
        jd(work / "segments" / (m["material_id"] + ".json"),
           {"material_id": m["material_id"], "path": m["path"], "segments": m["_segments"]})
      except Exception as exc:
        deg.append("segments failed: %s" % exc)
  index = {"version": VERSION, "input_dir": str(args.input),
           "case_id": case.get("case_id") or case.get("id") or "",
           "materials": [{k: v for k, v in m.items() if not k.startswith("_")} for m in mats],
           "counts": {"materials": len(mats)},
           "required_sections": required_sections(case), "workorder": [], "notes": deg}
  jd(work / "index.json", index)
  if notes:
    errors.extend(notes)
  status = "input_error" if notes else ("insufficient_evidence" if not mats else "partial")
  base = {"case_id": index["case_id"], "status": status, "deliverable": "",
          "preserved_facts": [], "evidence_map": [], "change_log": [], "claims": [],
          "coverage": {"sections_required": len(index.get("required_sections") or []),
                       "sections_present": 0, "claims": 0, "facts": 0},
          "result": {"deliverables": {}, "sections": [], "counts": {}, "derived": False},
          "sources": sources_of(index), "errors": errors,
          "degradations": deg + ["partial scaffold; build finalizes"]}
  jd(out / "result.json", echo_contract(case.get("output_contract"), base, out))
  print(json.dumps({"ok": True, "command": "init", "case_id": index["case_id"],
                    "materials": len(mats), "status": status}, ensure_ascii=False, indent=2))
  return 0


def cmd_show(args):
  index = jl(Path(args.work) / "index.json", {}) or {}
  if not args.material:
    print(json.dumps({"case_id": index.get("case_id", ""),
                      "materials": [m.get("material_id") for m in index.get("materials", [])]},
                     ensure_ascii=False, indent=2))
    return 0
  t = next((m for m in index.get("materials", []) if m["material_id"] == args.material), None)
  if not t:
    print(json.dumps({"error": "unknown material id: %s" % args.material}, ensure_ascii=False))
    return 0
  ss = (jl(Path(args.work) / "segments" / (args.material + ".json"), {}) or {}).get("segments") or []
  for s in ss:
    if not args.grep or re.search(args.grep, s["text"], re.I):
      print("=== [%s]\n%s\n" % (s["locator"], s["text"]))
  return 0


def cmd_extract(args):
  sb = segs_by_material(Path(args.work), jl(Path(args.work) / "index.json", {}) or {})
  facts, _ = number_facts(build_units(sb))
  allh = {"numbers": facts, "dois": [r for r in extract_refs(sb) if r.get("doi")]}
  jd(Path(args.work) / "facts_candidates.json", allh)
  print(json.dumps({"ok": True, "command": "extract-facts",
                    "counts": {k: len(v) for k, v in allh.items()},
                    "sample": {k: v[:3] for k, v in allh.items()}}, ensure_ascii=False, indent=2))
  return 0


def cmd_check(args):
  index = jl(Path(args.work) / "index.json", {}) or {}
  draft, dp = load_draft(args)
  report = run_checks(Path(args.work), index, draft or {}, manuscript_of(draft or {}))
  report["draft_path"] = dp
  try:
    jd(Path(args.work) / "check_report.json", report)
  except Exception:
    pass
  print_check(report)
  return 0


def cmd_build(args):
  work, out = Path(args.work), Path(args.output)
  out.mkdir(parents=True, exist_ok=True)
  work.mkdir(parents=True, exist_ok=True)
  errors, deg = [], []
  index = jl(work / "index.json", {}) or {}
  if not index:
    deg.append("index.json absent; build ran init implicitly")
    try:
      cmd_init(args)
      index = jl(work / "index.json", {}) or {}
    except Exception as exc:
      errors.append("implicit init failed: %s" % exc)
  case, notes = load_case(args.input)
  deg.extend(notes)
  draft, dp = load_draft(args)
  derived = False
  if not usable(draft):
    derived = True
    try:
      draft = derive(args, index, case)
      deg.append("no usable agent draft at %s; DERIVED_PATTERN produced a complete manuscript" % dp)
    except Exception as exc:
      errors.append("derive failed: %s" % exc)
      draft = {}
  manuscript = manuscript_of(draft or {})
  report = run_checks(work, index, draft or {}, manuscript)
  try:
    jd(work / "check_report.json", report)
  except Exception:
    pass
  facts = (draft or {}).get("preserved_facts") or []
  evidence = (draft or {}).get("evidence_map") or []
  if (draft or {}).get("_facts_truncated"):
    deg.append("preserved_facts truncated at 400 entries")
  if not manuscript.strip():
    manuscript = "# Derived manuscript\n\n_No source text could be extracted._\n"
    deg.append("manuscript.md fell back to a minimal derived placeholder")
  deliverables = {}
  try:
    (out / "manuscript.md").write_text(manuscript, encoding="utf-8")
    deliverables["manuscript"] = "manuscript.md"
  except Exception as exc:
    errors.append("manuscript.md failed: %s" % exc)
  try:
    (out / "manuscript.txt").write_text(
      re.sub(r"^#{1,6}\s+|^- ", "", manuscript, flags=re.M).replace('"', ""), encoding="utf-8")
    deliverables["manuscript_text"] = "manuscript.txt"
  except Exception as exc:
    errors.append("manuscript.txt failed: %s" % exc)
  required = infer_sections(case)
  heads = [str(s.get("heading") or "").strip() for s in ((draft or {}).get("sections") or [])]
  coverage = {"sections_required": len(required), "sections_present": len(heads),
              "claims": len(evidence), "facts": len(facts)}
  try:
    jd(out / "fact_evidence.json", {"claims": evidence, "facts": facts,
                                    "references": (draft or {}).get("citations") or [],
                                    "coverage": coverage})
    deliverables["fact_evidence"] = "fact_evidence.json"
  except Exception as exc:
    errors.append("fact_evidence.json failed: %s" % exc)
  fails = (report or {}).get("fails") or []
  if notes:
    errors.extend(notes)
  has_materials = bool(index.get("materials") or [])
  status = ("input_error" if notes else
            "insufficient_evidence" if not has_materials else
            "partial" if (derived or fails) else "ok")
  if not has_materials:
    errors.append("no input materials")
  elif fails:
    deg.append("%d check failure(s)" % len(fails))
  counts = {"sections": len((draft or {}).get("sections") or []),
            "preserved_facts": len(facts), "evidence_map": len(evidence),
            "manuscript_chars": len(manuscript.strip())}
  base = {"case_id": (draft or {}).get("case_id") or index.get("case_id")
          or case.get("case_id") or case.get("id") or "",
          "status": status, "deliverable": "manuscript.md",
          "preserved_facts": facts, "evidence_map": evidence,
          "change_log": (draft or {}).get("change_log") or [],
          "claims": evidence, "coverage": coverage,
          "result": {"deliverables": deliverables, "sections": heads, "counts": counts,
                     "gaps": (draft or {}).get("gaps") or [], "derived": derived},
          "sources": sources_of(index),
          "uncertainties": (draft or {}).get("uncertainties") or [],
          "errors": errors, "degradations": deg}
  contract = case.get("output_contract") if isinstance(case.get("output_contract"), dict) else {}
  final = echo_contract(contract, base, out)
  try:
    jd(out / "result.json", final)
  except Exception as exc:
    errors.append("result.json write failed: %s" % exc)
    try:
      jd(out / "result.json", {"case_id": base["case_id"], "status": "partial", "errors": errors})
    except Exception:
      pass
  print(json.dumps({"ok": True, "command": "build", "status": status,
                    "case_id": final.get("case_id", ""), "deliverables": deliverables,
                    "derived": derived, "errors": errors, "degradations": deg},
                   ensure_ascii=False, indent=2))
  return 0


IO = {"input": os.environ.get("INPUT_DIR", "/input"),
      "work": os.environ.get("WORK_DIR", "/app/work"),
      "output": os.environ.get("OUTPUT_DIR", "/app/output")}


def add_io(p, suppress=False):
  for name in ("input", "work", "output"):
    p.add_argument("--" + name, default=ap.SUPPRESS if suppress else IO[name])


def parser():
  p = ap.ArgumentParser(prog="manuscript-writer",
                        description="Academic manuscript writing skill")
  add_io(p)
  sub = p.add_subparsers(dest="command")
  for name in ("init", "show", "extract-facts", "check", "build", "selfcheck"):
    sp = sub.add_parser(name, help=name)
    add_io(sp, suppress=True)
    if name in ("check", "build"):
      sp.add_argument("--draft")
    if name == "show":
      sp.add_argument("--material")
      sp.add_argument("--grep")
  return p


def main(argv):
  p = parser()
  try:
    args = p.parse_args(argv)
  except SystemExit:
    return 0
  if not args.command:
    # The installed skill is invoked with no subcommand by the evaluator.
    # Default to the full, source-grounded build rather than silently returning help.
    args.command = "build"
  h = {"init": cmd_init, "show": cmd_show, "extract-facts": cmd_extract,
       "check": cmd_check, "selfcheck": cmd_check, "build": cmd_build}.get(args.command)
  if h is None:
    p.print_help()
    return 0
  return h(args)


def emergency(argv):
  try:
    args, _ = parser().parse_known_args(argv)
    out = Path(getattr(args, "output", None) or IO["output"])
    out.mkdir(parents=True, exist_ok=True)
    if not (out / "result.json").exists():
      jd(out / "result.json", {"case_id": "", "status": "partial", "claims": [],
                               "coverage": {}, "result": {}, "errors": ["unhandled exception"]})
  except BaseException:
    pass


if __name__ == "__main__":
  try:
    main(sys.argv[1:])
  except Exception:
    try:
      sys.stderr.write(traceback.format_exc())
    except Exception:
      pass
    emergency(sys.argv[1:])
  sys.exit(0)

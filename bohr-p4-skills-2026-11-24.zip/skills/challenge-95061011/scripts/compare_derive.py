#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic no-draft derive for cross-document comparison.

When the eval agent has not authored /app/work/draft.json, `build` calls
:func:`derive` to produce a genuine document x field comparison matrix straight
from /input (comparison-workorder.json + corpus documents).  Every value stays in
its own document's cell, every reported cell carries an exact paragraph locator
and a verbatim quote, and a six-dimension comparability verdict
(task, metric, units, material, pollutant, budget) is computed BEFORE any
quantitative synthesis is considered.  Unlike datasets / dyes are never pooled.

Pure stdlib, no network, no timestamps, deterministic output order.
"""
import json
import re
from pathlib import Path

from textproc import load, norm, read_text

DOC_SUFFIX = (".md", ".txt", ".tex", ".json", ".csv", ".tsv")
DIMENSIONS = ("task", "metric", "units", "material", "pollutant", "budget")

# --------------------------------------------------------------------------- units
_UNIT_RULES = [
    ("per minute", "min^-1"), ("min^-1", "min^-1"), ("min-1", "min^-1"),
    ("min\u22121", "min^-1"), ("min\u207b\u00b9", "min^-1"), ("1/min", "min^-1"),
    ("/min", "min^-1"),
    ("per hour", "h^-1"), ("h^-1", "h^-1"), ("h-1", "h^-1"), ("hr-1", "h^-1"),
    ("hour^-1", "h^-1"), ("1/h", "h^-1"), ("/h", "h^-1"),
    ("per second", "s^-1"), ("s^-1", "s^-1"), ("s-1", "s^-1"), ("sec^-1", "s^-1"),
    ("sec-1", "s^-1"), ("1/s", "s^-1"), ("/s", "s^-1"),
    ("per day", "d^-1"), ("d^-1", "d^-1"), ("d-1", "d^-1"), ("day-1", "d^-1"),
    ("mg/l\u207b\u00b9", "mg/L"), ("mg l-1", "mg/L"), ("mg/l-1", "mg/L"),
    ("mg l\u207b\u00b9", "mg/L"), ("mg/l", "mg/L"), ("mg\u00b7l-1", "mg/L"),
    ("\u03bcg/l", "\u03bcg/L"), ("ug/l", "\u03bcg/L"), ("g l-1", "g/L"),
    ("g/l", "g/L"), ("g\u00b7l-1", "g/L"),
    ("mmol l-1", "mmol/L"), ("mmol/l", "mmol/L"), ("mmol\u00b7l-1", "mmol/L"),
    ("\u03bcmol l-1", "\u03bcmol/L"), ("\u03bcmol/l", "\u03bcmol/L"),
    ("umol/l", "\u03bcmol/L"), ("mol l-1", "mol/L"), ("mol/l", "mol/L"),
    ("mg/g", "mg/g"), ("g/g", "g/g"), ("mg/kg", "mg/kg"),
    ("ml min-1", "mL/min"), ("ml/min", "mL/min"), ("l/min", "L/min"),
    ("m2/g", "m\u00b2/g"), ("m\u00b2/g", "m\u00b2/g"), ("m2 g-1", "m\u00b2/g"),
    ("wt%", "percent"), ("wt.%", "percent"), ("wt %", "percent"), ("%", "percent"),
    ("percent", "percent"), ("ppm", "ppm"), ("ppb", "ppb"),
    ("\u00b0c", "\u00b0C"), ("deg c", "\u00b0C"), ("degrees c", "\u00b0C"),
    ("nm", "nm"), ("\u03bcm", "\u03bcm"), ("\u00b5m", "\u03bcm"), ("um", "\u03bcm"),
    ("mm", "mm"), ("cm", "cm"), ("ev", "eV"), ("a.u.", "a.u."), ("au", "a.u."),
    ("dimensionless", "unitless"), ("unitless", "unitless"),
]
_UNIT_RULES.sort(key=lambda kv: -len(kv[0]))
_KNOWN_UNITS = set(v for _, v in _UNIT_RULES)
_KNOWN_UNITS.update({"min", "h", "s", "d", "mg", "g", "ml", "l", "mol", "mmol",
                     "\u03bcmol", "m", "w", "mw", "kw", "k", "bar", "pa", "kpa",
                     "mpa", "rpm", "m\u00b2/g", "mM", "\u03bcM", "M"})


def normalize_unit(u):
    """Map a reported unit token to a comparable canonical string."""
    if u is None:
        return ""
    s = str(u).lower().strip()
    s = (s.replace("\u2212", "-").replace("\u2013", "-").replace("\u2212", "-")
         .replace("\u207b\u00b9", "^-1").replace("\u207b", "^-")
         .replace("\u00b7", " ").replace("\u00b5", "\u03bc").replace("\u00b5", "\u03bc"))
    s = re.sub(r"\s+", " ", s).strip()
    for pat, can in _UNIT_RULES:
        if pat in s:
            return can
    compact = re.sub(r"\s+", "", s)
    m = re.match(r"^([a-z\u03bc]+)\^-?1$", compact)
    if m:
        return m.group(1) + "^-1"
    if s in ("", "-", "\u2014", "n/a", "na"):
        return "unitless"
    return s


def _plausible_unit(nu, token):
    if not nu:
        return False
    if nu in _KNOWN_UNITS:
        return True
    if re.search(r"[\d/%\u00b0]", nu):
        return True
    return bool(re.match(r"^[a-z\u03bc]+\^-?1$", nu))


_NUM = re.compile(r"[-+]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?(?:[eE][-+]?\d+)?")


def _number_unit_pairs(sent):
    """Yield (verbatim_number, verbatim_unit_token, normalized_unit) found in text."""
    out = []
    for m in _NUM.finditer(sent):
        num = m.group(0)
        tail = sent[m.end():]
        mt = re.match(
            r"^\s*(?:\u00b1\s*[-+]?\d+(?:\.\d+)?\s*)?"
            r"([A-Za-z\u03bc\u00b5][A-Za-z0-9.\-\u207b\u00b9/\u00b7%\u00b0\u00b2\u00b3]*|%|\u00b0C)",
            tail)
        token = mt.group(1) if mt else ""
        if token:
            token = token.rstrip(".,;:")
        nu = normalize_unit(token) if token else ""
        if token and _plausible_unit(nu, token):
            out.append((num, token, nu))
        elif not token:
            out.append((num, "", ""))
    return out


# --------------------------------------------------------------------------- entities / lexicon
_DYES = {
    "rhodamine b": "Rhodamine B", "rhb": "RhB", "methyl orange": "Methyl orange",
    "methylene blue": "Methylene blue", "mb": "MB", "congo red": "Congo red",
    "methyl red": "Methyl red", "crystal violet": "Crystal violet",
    "malachite green": "Malachite green", "acid orange 7": "Acid Orange 7",
    "acid orange": "Acid Orange", "methyl violet": "Methyl violet",
    "reactive black 5": "Reactive Black 5", "reactive red": "Reactive Red",
    "orange ii": "Orange II", "orange g": "Orange G", "safranin": "Safranin",
    "eosin": "Eosin", "fluorescein": "Fluorescein", "tetracycline": "Tetracycline",
    "bisphenol a": "Bisphenol A", "bpa": "BPA", "phenol": "Phenol",
    "4-nitrophenol": "4-nitrophenol", "2,4-dichlorophenol": "2,4-dichlorophenol",
    "rhodamine 6g": "Rhodamine 6G", "rh6g": "Rh6G",
}
_MATERIALS = {
    "tio2": "TiO2", "p25": "P25", "g-c3n4": "g-C3N4", "carbon nitride": "carbon nitride",
    "zno": "ZnO", "fe3o4": "Fe3O4", "sno2": "SnO2", "wo3": "WO3", "bivo4": "BiVO4",
    "ag3po4": "Ag3PO4", "cds": "CdS", "mos2": "MoS2", "go": "GO", "rgo": "rGO",
    "graphene": "graphene", "mof": "MOF", "mil-101": "MIL-101", "uio-66": "UiO-66",
    "zeolite": "zeolite", "montmorillonite": "montmorillonite",
    "activated carbon": "activated carbon", "biochar": "biochar",
}
_TASKS = {
    "photocatalytic degradation": "photocatalytic degradation",
    "photodegradation": "photocatalytic degradation", "photocatalysis": "photocatalysis",
    "photocatalytic": "photocatalytic degradation", "degradation": "degradation",
    "removal": "removal", "adsorption": "adsorption", "reduction": "reduction",
    "oxidation": "oxidation", "mineralization": "mineralization",
    "hydrogen evolution": "hydrogen evolution", "detection": "detection",
    "sensing": "sensing", "disinfection": "disinfection", "synthesis": "synthesis",
    "electrolysis": "electrolysis",
}
_BUDGET_KEYS = ("dose", "loading", "concentration", "amount", "cost", "budget", "scale",
                "initial", "mass", "volume", "sample size", "n =", "n=")


def _split_sentences(text):
    if not text:
        return []
    parts = re.split(r"(?<=[.!?;\u3002\uff1b\uff1f\uff01])\s+|\n+", text)
    return [p.strip() for p in parts if p and len(p.strip()) > 2]


def _entity_hits(doc, role):
    table = _DYES if role == "pollutant" else _MATERIALS
    hits = []
    for p in doc.get("paragraphs", []):
        for sent in _split_sentences(p.get("text", "")):
            ns = norm(sent)
            found = []
            for key in sorted(table, key=len, reverse=True):
                pat = r"(?<![a-z0-9])" + re.escape(key) + r"(?![a-z0-9])"
                if re.search(pat, ns):
                    label = table[key]
                    if label not in [f[0] for f in found]:
                        found.append((label, key))
            if found:
                hits.append({"paragraph_id": p["paragraph_id"], "sentence": sent,
                             "entities": found, "ns": ns})
    return hits


def _choose_entity(doc, role):
    hits = _entity_hits(doc, role)
    for cand in hits:
        ns = cand["ns"]
        if any(k in ns for k in ("used", "degradation", "removal", "adsorption",
                                 "selected", "chosen", "target", "studied", "investigated",
                                 "pollutant", "dye", "photodegradation", "decolorization",
                                 "mineralization", "prepared", "synthesized", "catalyst")):
            for label, key in cand["entities"]:
                low = label.lower()
                if re.search(re.escape(low) + r"\s+(?:was|is|were|are)\s+"
                             r"(?:used|selected|chosen|studied|investigated|degraded|"
                             r"removed|treated|prepared|synthesized|employed)", ns):
                    return label, cand["paragraph_id"], cand["sentence"]
                if re.search(r"(?:degradation|removal|adsorption|photodegradation|"
                             r"decolorization|mineralization)\s+of\s+" + re.escape(low), ns):
                    return label, cand["paragraph_id"], cand["sentence"]
                if re.search(re.escape(low) + r"\s+(?:degradation|removal|adsorption|"
                             r"photodegradation|decolorization|mineralization|photocatalyst|"
                             r"catalyst)", ns):
                    return label, cand["paragraph_id"], cand["sentence"]
                if re.search(r"(?:used|selected|chosen|employed|prepared|synthesized)\s+"
                             + re.escape(low), ns):
                    return label, cand["paragraph_id"], cand["sentence"]
    counts, first = {}, {}
    for cand in hits:
        for label, key in cand["entities"]:
            counts[label] = counts.get(label, 0) + 1
            first.setdefault(label, (cand["paragraph_id"], cand["sentence"]))
    if counts:
        label = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[0][0]
        return label, first[label][0], first[label][1]
    return None, None, None


def _task_hit(doc):
    for p in doc.get("paragraphs", []):
        for sent in _split_sentences(p.get("text", "")):
            ns = norm(sent)
            for key in sorted(_TASKS, key=len, reverse=True):
                if key in ns:
                    return _TASKS[key], p["paragraph_id"], sent
    return None, None, None


def _budget_hit(doc):
    for p in doc.get("paragraphs", []):
        for sent in _split_sentences(p.get("text", "")):
            ns = norm(sent)
            if not any(k in ns for k in _BUDGET_KEYS):
                continue
            pairs = _number_unit_pairs(sent)
            if pairs:
                parts = ["%s %s" % (num, unit) if unit else num for num, unit, _ in pairs]
                return "; ".join(parts), p["paragraph_id"], sent
    return None, None, None


def _doc_profile(doc):
    t_label, t_pid, t_sent = _task_hit(doc)
    m_label, m_pid, m_sent = _choose_entity(doc, "material")
    p_label, p_pid, p_sent = _choose_entity(doc, "pollutant")
    b_val, b_pid, b_sent = _budget_hit(doc)
    return {
        "task": {"value": t_label, "locator": ("%s#%s" % (doc["doc_id"], t_pid)) if t_pid else "",
                 "quote": t_sent or ""},
        "material": {"value": m_label,
                     "locator": ("%s#%s" % (doc["doc_id"], m_pid)) if m_pid else "",
                     "quote": m_sent or ""},
        "pollutant": {"value": p_label,
                      "locator": ("%s#%s" % (doc["doc_id"], p_pid)) if p_pid else "",
                      "quote": p_sent or ""},
        "budget": {"value": b_val,
                   "locator": ("%s#%s" % (doc["doc_id"], b_pid)) if b_pid else "",
                   "quote": b_sent or ""},
    }


# --------------------------------------------------------------------------- workorder
def _norm_field(item, i):
    if isinstance(item, str):
        return {"field_id": "f%d" % i, "name": item, "definition": "", "unit": "",
                "aliases": [], "type": ""}
    if not isinstance(item, dict):
        return None
    fid = item.get("field_id") or item.get("id") or item.get("fieldId") or "f%d" % i
    name = (item.get("name") or item.get("label") or item.get("field")
            or item.get("object") or item.get("title") or str(fid))
    definition = (item.get("definition") or item.get("description")
                  or item.get("metric_definition") or item.get("metric")
                  or item.get("\u53e3\u5f84") or "")
    unit = item.get("unit") or ""
    aliases = item.get("aliases") or item.get("keywords") or item.get("synonyms") \
        or item.get("terms") or item.get("also_known_as") or []
    if isinstance(aliases, str):
        aliases = [aliases]
    return {"field_id": str(fid), "name": str(name), "definition": str(definition),
            "unit": str(unit), "aliases": [str(a) for a in aliases],
            "type": str(item.get("type") or item.get("kind") or item.get("dimension") or "")}


def _as_fields(val, start):
    fields = []
    if isinstance(val, dict):
        inner = val.get("fields") or val.get("objects") or val.get("comparison_fields") \
            or val.get("field_definitions") or val.get("compare") or val.get("workorder")
        if isinstance(inner, (list, dict)):
            return _as_fields(inner, start)
        if any(k in val for k in ("field_id", "name", "label", "id", "object", "metric",
                                  "field")):
            return _as_fields([val], start)
        items = [v for v in val.values() if isinstance(v, dict)]
        return _as_fields(items, start) if items else []
    if isinstance(val, list):
        i = start
        for item in val:
            f = _norm_field(item, i)
            if f:
                fields.append(f)
                i += 1
    return fields


def load_workorder(input_dir, case):
    """Load comparison fields from /input/comparison-workorder.json, then case.json."""
    fields = []
    data = load(Path(input_dir) / "comparison-workorder.json")
    if isinstance(data, (dict, list)):
        fields = _as_fields(data, 1)
    if not fields:
        for key in ("comparison_workorder", "workorder", "fields", "target_fields",
                    "comparison_fields"):
            val = (case or {}).get(key)
            if isinstance(val, (list, dict)):
                fields = _as_fields(val, 1)
                if fields:
                    break
    return fields


def field_type(field):
    blob = " ".join([field.get("type", ""), field.get("name", ""),
                     field.get("definition", "")]).lower()
    if any(k in blob for k in ("pollutant", "dye", "contaminant", "target compound",
                               "probe molecule", "probe dye")):
        return "pollutant"
    if any(k in blob for k in ("material", "catalyst", "sample", "electrode", "alloy",
                               "support", "adsorbent", "photocatalyst", "substrate")):
        return "material"
    if any(k in blob for k in ("task", "objective", "reaction", "process", "study type",
                               "application")):
        return "task"
    if any(k in blob for k in ("budget", "dose", "cost", "scale", "amount", "loading",
                               "expense", "resource")):
        return "budget"
    return "metric"


# --------------------------------------------------------------------------- field terms
_STOP = set(("a an the of for and or to in on at by with from as is are was were be been "
             "being this that these those it its their there which what when where how why "
             "does do did not no can could should would may might must shall will").split())


def _field_terms(field):
    src = " ".join([x for x in [field.get("name") or "", field.get("definition") or "",
                                " ".join(field.get("aliases") or [])] if x])
    ns = norm(src)
    words = [w for w in re.findall(r"[a-z0-9]+", ns) if w not in _STOP and len(w) >= 2]
    phrases = []
    nw = [w for w in re.findall(r"[a-z0-9]+", norm(field.get("name") or "")) if w not in _STOP]
    for n in (3, 2):
        for i in range(len(nw) - n + 1):
            phrases.append(" ".join(nw[i:i + n]))
    for seg in re.findall(r"[\u4e00-\u9fff]+", ns):
        if len(seg) <= 6:
            phrases.append(seg)
        else:
            phrases.extend(seg[i:i + 2] for i in range(len(seg) - 1))
    out = []
    for t in phrases + words:
        if t and t not in out:
            out.append(t)
    return out


def _negated(ns, hits):
    if any(p in ns for p in ("not reported", "not determined", "not measured", "not given",
                             "not available", "not provided", "not evaluated",
                             "not calculated", "was not reported", "were not reported",
                             "no data", "no information", "not evaluated")):
        return True
    for h in hits:
        if re.search(r"\bno\s+" + re.escape(h), ns):
            return True
        if re.search(re.escape(h) + r"\s+(?:was|is|were|are)\s+not", ns):
            return True
    return False


def _metric_wording(sent, num, unit):
    s = sent
    if num and num in s:
        s = s.replace(num, "", 1)
    if unit and unit in s:
        s = s.replace(unit, "", 1)
    s = re.sub(r"(?i)\b(the|a|an|was|is|were|are|of|under|with|using|at|value|values|"
               r"measured|reported|obtained|estimated|determined)\b", " ", s)
    s = re.sub(r"[^A-Za-z0-9]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s[:70]


def _better(cand, best, canon):
    def rank(c):
        match = 1 if canon and c["unit_norm"] == canon else 0
        return (match, c["score"])
    return rank(cand) > rank(best)


def _metric_cell(field, doc):
    terms = _field_terms(field)
    canon = normalize_unit(field.get("unit") or "")
    best = None
    neg_sent, neg_pid = None, None
    for p in doc.get("paragraphs", []):
        for sent in _split_sentences(p.get("text", "")):
            ns = norm(sent)
            hits = [t for t in terms if t in ns]
            if not hits:
                continue
            if _negated(ns, hits):
                neg_sent, neg_pid = sent, p["paragraph_id"]
                continue
            pairs = _number_unit_pairs(sent)
            if not pairs:
                continue
            for num, unit, unit_norm in pairs:
                score = len(hits)
                if canon and unit_norm == canon:
                    score += 3
                elif canon and unit_norm:
                    score += 1
                elif unit_norm:
                    score += 1
                cand = {"num": num, "unit": unit, "unit_norm": unit_norm, "score": score,
                        "sent": sent, "pid": p["paragraph_id"]}
                if best is None or _better(cand, best, canon):
                    best = cand
    if best:
        unit_norm = best["unit_norm"] or "unitless"
        mdef = _metric_wording(best["sent"], best["num"], best["unit"])
        status = "reported"
        reason = ""
        if canon and unit_norm != canon:
            status = "not_comparable"
            reason = ("unit differs: document reports '%s' (normalized %s), canonical "
                      "field unit is '%s'" % (best["unit"] or "(none)", unit_norm,
                                              field.get("unit") or "(none)"))
        return {"status": status, "value": best["num"], "unit": best["unit"] or "unitless",
                "unit_normalized": unit_norm, "metric_definition": mdef,
                "quote": best["sent"], "paragraph_id": best["pid"], "reason": reason}
    if neg_sent:
        return {"status": "not_reported",
                "reason": "document states the value is not reported/determined",
                "value": "", "unit": "", "unit_normalized": "", "metric_definition": "",
                "quote": neg_sent, "paragraph_id": neg_pid}
    return {"status": "not_reported",
            "reason": "no sentence in this document reports this field with a value",
            "value": "", "unit": "", "unit_normalized": "", "metric_definition": "",
            "quote": "", "paragraph_id": ""}


def _extract_cell(field, doc, profile):
    ctype = field_type(field)
    fid = field["field_id"]
    did = doc["doc_id"]
    if ctype in ("pollutant", "material", "task", "budget"):
        dim = profile.get(ctype, {})
        value = dim.get("value")
        if value:
            return {"status": "reported", "value": str(value),
                    "unit": "unitless", "unit_normalized": "unitless",
                    "metric_definition": field.get("definition") or field.get("name") or "",
                    "quote": dim.get("quote") or "", "paragraph_id": _pid_of(dim),
                    "reason": ""}
        return {"status": "not_reported",
                "reason": "%s not identifiable in this document" % ctype,
                "value": "", "unit": "", "unit_normalized": "",
                "metric_definition": "", "quote": "", "paragraph_id": ""}
    res = _metric_cell(field, doc)
    return {"status": res["status"], "value": res["value"], "unit": res["unit"],
            "unit_normalized": res["unit_normalized"],
            "metric_definition": res["metric_definition"], "quote": res["quote"],
            "paragraph_id": res["paragraph_id"], "reason": res["reason"]}


def _pid_of(dim):
    loc = dim.get("locator") or ""
    return loc.split("#")[-1] if "#" in loc else ""


def _dim_status(vals):
    if not vals:
        return "unreported"
    if len(vals) == 1:
        return "partial"
    return "comparable" if len(set(vals.values())) == 1 else "differs"


def _required_dims(field):
    base = ["task", "metric", "units"]
    ctype = field_type(field)
    if ctype == "metric":
        return base + ["material", "pollutant"]
    if ctype == "pollutant":
        return base + ["pollutant"]
    if ctype == "material":
        return base + ["material"]
    if ctype == "budget":
        return base + ["budget"]
    return base


def _cell_value(c):
    return (c.get("value") not in (None, "") and
            c.get("status") in ("reported", "not_comparable", "source_conflict"))


def _judge(fields, docs, matrix, profiles):
    by_cell = {(c["doc_id"], c["field_id"]): c for c in matrix}
    comparability = []
    for f in fields:
        fid = f["field_id"]
        valued = [c for c in matrix if c["field_id"] == fid and _cell_value(c)]
        dims = {}
        for dim in DIMENSIONS:
            vals = {}
            for c in valued:
                v = c.get("facets", {}).get(dim)
                if v not in (None, ""):
                    vals[c["doc_id"]] = str(v)
            dims[dim] = {"status": _dim_status(vals), "values": vals}
        diff = [d for d in DIMENSIONS if dims[d]["status"] == "differs"]
        unrep = [d for d in DIMENSIONS if dims[d]["status"] == "unreported"]
        req = _required_dims(f)
        req_missing = [d for d in req if dims[d]["status"] != "comparable"]
        comparable = bool(len(valued) >= 2 and not diff and not req_missing)
        basis = _basis_text(f, dims, diff, unrep, len(valued), req_missing)
        for c in matrix:
            if c["field_id"] != fid:
                continue
            if not _cell_value(c):
                c["comparability"] = {"comparable": None, "dimension": None,
                                      "note": "unreported in this document"}
            elif diff:
                c["comparability"] = {"comparable": False,
                                      "dimension": "+".join(diff),
                                      "note": "differs across documents on: " + ", ".join(diff)}
            elif comparable:
                c["comparability"] = {"comparable": True, "dimension": None, "note": ""}
            else:
                c["comparability"] = {"comparable": None, "dimension": None,
                                      "note": "insufficient comparable evidence to pool"}
        comparability.append({
            "field_id": fid, "comparable": comparable, "basis": basis,
            "dimensions": dims, "reported_documents": [c["doc_id"] for c in valued],
            "differing_dimensions": diff, "unreported_dimensions": unrep})
    return matrix, comparability


def _basis_text(f, dims, diff, unrep, n_valued, req_missing):
    parts = []
    if diff:
        parts.append("differs on: " + ", ".join("%s=%s" % (d, dims[d]["status"]) for d in diff))
    if req_missing:
        parts.append("required dimension(s) not all comparable: " + ", ".join(req_missing))
    if unrep:
        parts.append("unreported dimension(s) retained: " + ", ".join(unrep))
    if n_valued < 2:
        parts.append("fewer than two documents report a value; nothing to pool")
    if not parts:
        parts.append("all six dimensions comparable across reported documents")
    return "; ".join(parts)


def _synthesis(comparability):
    if comparability and all(c.get("comparable") for c in comparability):
        return {"allowed": True,
                "basis": ("All fields are comparable on the six dimensions. No numeric "
                          "cross-document aggregation is performed by this tool; only the "
                          "per-document values are reported.")}
    blocked = [c["field_id"] for c in comparability if not c.get("comparable")]
    return {"allowed": False,
            "basis": ("Quantitative synthesis blocked for fields: %s. Retain every "
                      "noncomparable and unreported condition; do not pool unlike "
                      "datasets or dyes." % (", ".join(blocked) if blocked else "none"))}


def _claims_and_notes(fields, docs, matrix, comparability, synthesis):
    claims = []
    gaps = []
    comp_by = {c["field_id"]: c for c in comparability}
    for f in fields:
        fid = f["field_id"]
        cells = [c for c in matrix if c["field_id"] == fid]
        valued = [c for c in cells if _cell_value(c)]
        comp = comp_by.get(fid, {})
        dims = comp.get("dimensions", {})
        dims_txt = ", ".join("%s=%s" % (d, dims.get(d, {}).get("status", "unreported"))
                             for d in DIMENSIONS)
        if not valued:
            claims.append({"claim_id": "c_%s" % fid, "text": ("%s (%s): no document "
                           "reports a value; the unreported condition is retained. %s"
                           % (f["name"], fid, dims_txt)), "evidence": [],
                           "synthesis": "blocked"})
        else:
            verdict = "comparable" if comp.get("comparable") else "not comparable"
            text = ("%s (%s): %s across documents. Six-dimension verdict -> %s."
                    % (f["name"], fid, verdict, dims_txt))
            evidence = [{"doc_id": c["doc_id"], "locator": c.get("locator", ""),
                         "quote": c.get("quote", "")} for c in valued]
            claims.append({"claim_id": "c_%s" % fid, "text": text, "evidence": evidence,
                           "synthesis": "allowed" if comp.get("comparable") else "blocked"})
        for c in cells:
            if c["status"] == "not_reported":
                gaps.append({"object": "%s\u00d7%s" % (c["doc_id"], fid),
                             "reason": c.get("reason", "not reported"),
                             "action": "listed_as_gap"})
    claims.append({"claim_id": "c_synthesis", "text": synthesis["basis"], "evidence": [],
                   "synthesis": "allowed" if synthesis["allowed"] else "blocked"})
    uncertainties = [
        {"item": "values and units were extracted by deterministic heuristics from text",
         "why": "no LLM reading pass was available at build time"},
        {"item": "task/material/pollutant/budget facets are inferred from explicit wording only",
         "why": "facets not stated verbatim are recorded as unreported rather than inferred"},
        {"item": "units were normalized for comparison; the verbatim unit is kept per cell",
         "why": "comparing units requires a canonical form"},
    ]
    return claims, gaps, uncertainties


def _build_field_dictionary(fields, docs, matrix):
    dic = []
    cells_by = {}
    for c in matrix:
        cells_by.setdefault(c["field_id"], []).append(c)
    for f in fields:
        fid = f["field_id"]
        cells = cells_by.get(fid, [])
        doc_wording = []
        for c in cells:
            if c.get("quote"):
                doc_wording.append({"doc_id": c["doc_id"],
                                    "wording": c.get("metric_definition") or "",
                                    "locator": c.get("locator") or "",
                                    "quote": c.get("quote") or ""})
        dic.append({
            "field_id": fid, "name": f["name"],
            "definition": f.get("definition") or ("canonical: %s" % f["name"]),
            "unit": f.get("unit") or "", "type": field_type(f),
            "aliases": f.get("aliases") or [],
            "doc_wording": doc_wording,
        })
    return dic


# --------------------------------------------------------------------------- public derive
def derive(case, input_dir, index):
    """Build a full draft-like dict from /input, with no agent-authored draft needed."""
    fields = load_workorder(input_dir, case)
    if not fields:
        fields = _as_fields(index.get("fields") or [], 1)
    paras = index.get("paragraphs") or {}
    docs = []
    for d in sorted(index.get("docs") or [], key=lambda x: str(x.get("doc_id"))):
        d2 = dict(d)
        d2["paragraphs"] = paras.get(d2.get("doc_id"), [])
        docs.append(d2)
    profiles = {d["doc_id"]: _doc_profile(d) for d in docs}

    matrix = []
    for f in fields:
        for d in docs:
            cell = _extract_cell(f, d, profiles[d["doc_id"]])
            cell.update({
                "source_document_id": d["doc_id"], "doc_id": d["doc_id"],
                "field_id": f["field_id"],
                "locator": ("%s#%s" % (d["doc_id"], cell["paragraph_id"]))
                if cell["paragraph_id"] else "",
                "dataset": _dataset(d, profiles[d["doc_id"]]),
                "facets": {
                    "task": profiles[d["doc_id"]]["task"]["value"],
                    "metric": cell.get("metric_definition") or None,
                    "units": cell.get("unit_normalized") or None,
                    "material": profiles[d["doc_id"]]["material"]["value"],
                    "pollutant": profiles[d["doc_id"]]["pollutant"]["value"],
                    "budget": profiles[d["doc_id"]]["budget"]["value"],
                },
            })
            matrix.append(cell)
    matrix, comparability = _judge(fields, docs, matrix, profiles)
    synthesis = _synthesis(comparability)
    claims, gaps, uncertainties = _claims_and_notes(fields, docs, matrix, comparability,
                                                    synthesis)
    field_dictionary = _build_field_dictionary(fields, docs, matrix)
    return {"case_id": (case or {}).get("case_id", ""),
            "field_dictionary": field_dictionary, "matrix": matrix,
            "comparability": comparability, "synthesis": synthesis,
            "claims": claims, "gaps": gaps, "uncertainties": uncertainties,
            "pending_human": []}


def _dataset(d, profile):
    parts = []
    for k in ("task", "material", "pollutant"):
        v = profile.get(k, {}).get("value")
        if v:
            parts.append(str(v))
    return "; ".join(parts)


def usable_draft(draft):
    return isinstance(draft, dict) and bool(draft.get("field_dictionary")) \
        and bool(draft.get("matrix"))


# --------------------------------------------------------------------------- discovery / contract
def discover_docs(case, input_dir):
    root = Path(input_dir)
    docs = []
    if not root.exists():
        return docs
    declared = {}
    for key in ("documents", "papers", "corpus"):
        val = (case or {}).get(key)
        if isinstance(val, list):
            for item in val:
                if isinstance(item, dict):
                    p = item.get("path") or item.get("file")
                    if p:
                        declared[str(p).lstrip("./")] = item
    n = 0
    for p in sorted(root.rglob("*")):
        try:
            if not p.is_file() or p.stat().st_size > 2_000_000:
                continue
            if p.parent == root and p.name in ("case.json", "task.md",
                                               "comparison-workorder.json"):
                continue
            if p.suffix.lower() not in DOC_SUFFIX:
                continue
        except Exception:
            continue
        rel = p.relative_to(root).as_posix()
        if p.suffix.lower() == ".json" and rel not in declared:
            continue
        n += 1
        did = "m%d" % n
        text = read_text(p)
        item = declared.get(rel) or {}
        label = (item.get("label") or item.get("title") or item.get("paper_id")
                 or p.stem)
        paragraphs = _parse_paragraphs(text) if p.suffix.lower() in (".md", ".txt", ".tex") \
            else [{"paragraph_id": "P1", "text": text[:4000]}]
        docs.append({"doc_id": did, "path": rel, "label": str(label)[:120],
                     "chars": len(text), "paragraphs": paragraphs})
    return docs


def _parse_paragraphs(text):
    from textproc import parse_paragraphs
    return parse_paragraphs(text)


def meta_ids(case):
    def pick(*keys):
        for k in keys:
            v = (case or {}).get(k)
            if v not in (None, ""):
                return str(v)
        return ""
    return {"case_id": pick("case_id", "id", "caseId"),
            "material_version": pick("material_version", "version", "materialVersion")}


def echo_contract(contract, base):
    final, missing = {}, []
    if isinstance(contract, dict):
        res = base.get("result") if isinstance(base.get("result"), dict) else {}
        for key in contract.keys():
            if key in base:
                final[key] = base[key]
            elif key in res:
                final[key] = res[key]
            else:
                final[key] = None
                missing.append(key)
    final.update(base)
    if missing:
        base.setdefault("degradations", []).append(
            "output_contract keys filled as null: " + ", ".join(missing))
        for key in missing:
            final[key] = None
    return final


def base_doc(meta, status, deg, err, version="1.1.0"):
    return {"case_id": meta.get("case_id", ""),
            "material_version": meta.get("material_version", ""),
            "status": status, "result": {},
            "field_dictionary": [], "matrix": [], "comparability": [],
            "synthesis": {"allowed": False, "basis": "no synthesis yet"},
            "claims": [], "uncertainties": [],
            "coverage": {"required": 0, "parsed": 0, "missing": []},
            "sources": [], "pending_human": [], "errors": err, "degradations": deg,
            "deliverables": {}, "skill": {"name": "cross-doc-compare", "version": version}}


# --------------------------------------------------------------------------- report
def build_report(doc, check_report, status):
    L = ["# Cross-document comparison report", "",
         "- case_id: `%s`" % doc.get("case_id", ""), "- status: `%s`" % status,
         "- cells: required=%s parsed=%s missing=%s"
         % (doc["coverage"].get("required"), doc["coverage"].get("parsed"),
            doc["coverage"].get("missing")), "",
         "## Field dictionary (shared schema + per-document wording)"]
    for f in doc.get("field_dictionary") or []:
        L.append("- `%s` %s | definition: %s | unit: %s"
                 % (f.get("field_id"), f.get("name"), f.get("definition") or "-",
                    f.get("unit") or "-"))
        for w in f.get("doc_wording") or []:
            L.append("  - `%s` %s: %s" % (w.get("doc_id"), w.get("locator") or "",
                                          (w.get("quote") or "")[:120]))
    L += ["", "## Matrix (one row per field x document)"]
    L.append("| doc | field | status | value | unit | paragraph | quote |")
    L.append("|---|---|---|---|---|---|---|")
    for c in doc.get("matrix") or []:
        L.append("| %s | %s | `%s` | %s | %s | %s | %s |"
                 % (c.get("doc_id"), c.get("field_id"), c.get("status"),
                    c.get("value") if c.get("value") not in (None, "") else "-",
                    c.get("unit") or "-", c.get("paragraph_id") or "-",
                    (c.get("quote") or "-")[:90]))
    L += ["", "## Six-dimension comparability (task, metric, units, material, pollutant, budget)"]
    for c in doc.get("comparability") or []:
        L.append("- `%s` comparable=%s — %s" % (c.get("field_id"), c.get("comparable"),
                                                c.get("basis") or ""))
        for dim in DIMENSIONS:
            d = (c.get("dimensions") or {}).get(dim, {})
            L.append("  - %s: %s %s" % (dim, d.get("status"), d.get("values") or {}))
    syn = doc.get("synthesis") or {}
    L += ["", "## Synthesis", "- allowed: `%s`" % syn.get("allowed"),
          "- basis: %s" % syn.get("basis")]
    if check_report:
        L += ["", "## Self-check", "- passed: `%s`" % check_report.get("passed")]
        L += ["- FAIL: %s" % f for f in (check_report.get("fails") or [])[:30]]
    return "\n".join(L) + "\n"

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""cross-doc-compare -- put several papers on one set of fields and compare them.

`init` indexes documents and the comparison workorder; `build` assembles the
deliverables.  When no usable agent draft exists, `build` DERIVES a genuine
document x field matrix directly from /input (see compare_derive.derive) instead
of emitting an empty scaffold.  Pure stdlib, no network, CWD independent,
always exits 0.
"""
import argparse
import csv
import io
import json
import os
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from textproc import dump, load, norm  # noqa: E402
import compare_derive as cd  # noqa: E402

VERSION = "1.1.0"
CELL_STATUS = ("reported", "not_reported", "source_conflict", "not_comparable")


# --------------------------------------------------------------------------- check
def check_draft(index, draft):
    fails, warns, passes = [], [], []
    if not isinstance(draft, dict):
        return {"passed": False, "fails": ["draft.json missing or not a JSON object"],
                "warnings": [], "passes": [], "counts": {}}
    docs = index.get("docs", [])
    doc_ids = [d["doc_id"] for d in docs]
    paras = index.get("paragraphs", {}) or {}
    dic = draft.get("field_dictionary") or []
    fields = [str(f.get("field_id")) for f in dic if f.get("field_id")]
    matrix = draft.get("matrix") or []
    comparability = draft.get("comparability") or []

    if not dic:
        fails.append("field_dictionary is empty; fields must be defined before comparison")
    for f in dic:
        if not f.get("field_id"):
            fails.append("field_dictionary entry missing field_id")
        if not str(f.get("name") or "").strip():
            fails.append("%s missing a human-readable name" % f.get("field_id"))
    if len(fields) != len(set(fields)):
        fails.append("duplicate field_id in field_dictionary")

    seen, by_cell = set(), {}
    for c in matrix:
        key = (str(c.get("doc_id")), str(c.get("field_id")))
        seen.add(key)
        by_cell[key] = c
    missing = [(d, f) for d in doc_ids for f in fields if (d, f) not in seen]
    if missing:
        fails.append("%d cell(s) missing from the matrix (need one per document x field): %s"
                     % (len(missing), ", ".join("%s\u00d7%s" % m for m in missing[:8])))
    elif fields and doc_ids:
        passes.append("all %d document x field cells present" % (len(doc_ids) * len(fields)))

    reported = 0
    for (did, fid), c in by_cell.items():
        tag = "%s\u00d7%s" % (did, fid)
        st = c.get("status")
        if st not in CELL_STATUS:
            fails.append("%s status=%r not in %s" % (tag, st, list(CELL_STATUS)))
            continue
        if did not in doc_ids:
            fails.append("%s refers to unknown document id" % tag)
            continue
        if st == "reported":
            reported += 1
            if c.get("value") in (None, ""):
                fails.append("%s is reported but has no value" % tag)
            if not c.get("unit"):
                warns.append("%s is reported but records no unit" % tag)
            quote = c.get("quote")
            if not quote:
                fails.append("%s is reported but has no quote" % tag)
                continue
            own = norm(" \n ".join(p["text"] for p in paras.get(did, [])))
            if norm(quote) not in own:
                elsewhere = [d for d in doc_ids if d != did
                             and norm(quote) in norm(" \n ".join(
                                 p["text"] for p in paras.get(d, [])))]
                if elsewhere:
                    fails.append("%s quote comes from document %s instead of %s "
                                 "(cross-document contamination)" % (tag, elsewhere[0], did))
                else:
                    fails.append("%s quote not verbatim in document %s" % (tag, did))
            if not (c.get("locator") or c.get("paragraph_id")):
                warns.append("%s reports a value without a locator" % tag)
        if st in ("not_reported", "source_conflict", "not_comparable") and not \
                (c.get("reason") or c.get("note")):
            warns.append("%s is %s but gives no reason" % (tag, st))
        if st == "source_conflict" and not c.get("conflict_with"):
            warns.append("%s is source_conflict but names no conflicting source" % tag)

    comp_ids = {str(c.get("field_id")) for c in comparability}
    for f in fields:
        if f not in comp_ids:
            warns.append("field %s has no comparability judgement" % f)
    syn = draft.get("synthesis") or {}
    if syn.get("allowed"):
        blocking = [c for c in comparability if c.get("comparable") is False]
        if blocking:
            fails.append("synthesis.allowed=true but %d field(s) are judged not comparable: %s"
                         % (len(blocking), [c.get("field_id") for c in blocking][:6]))
        if not str(syn.get("basis") or "").strip():
            fails.append("synthesis.allowed=true without a basis")
    for c in draft.get("claims") or []:
        hits = [(k, v) for k, v in by_cell.items()
                if v.get("status") == "reported" and v.get("quote")
                and norm(v["quote"]) in norm(c.get("text") or "")]
        if not c.get("evidence") and not hits:
            warns.append("claim %s has no evidence and no matrix cell backing it"
                         % c.get("claim_id"))
    return {"passed": not fails, "fails": fails, "warnings": warns, "passes": passes,
            "counts": {"documents": len(doc_ids), "fields": len(fields),
                       "cells": len(by_cell), "reported_cells": reported,
                       "missing_cells": len(missing)}}


def run_checks(args):
    work = Path(args.work)
    index = load(work / "index.json", {}) or {}
    draft = load(Path(args.draft) if args.draft else (work / "draft.json"))
    return check_draft(index, draft)


# --------------------------------------------------------------------------- init/docs/show
def cmd_init(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    deg, err = [], []
    case = load(Path(args.input) / "case.json")
    if not isinstance(case, dict):
        case = {}
        deg.append("case.json missing or not a JSON object")
    meta = cd.meta_ids(case)
    docs = cd.discover_docs(case, args.input)
    fields = cd.load_workorder(args.input, case)
    if not docs:
        deg.append("no comparable documents found under input dir")
    if not fields:
        deg.append("no declared comparison fields; field_dictionary must be authored "
                   "or derived by the agent")
    index = {"version": VERSION, "meta": meta, "fields": fields,
             "docs": [{k: v for k, v in d.items() if k != "paragraphs"} for d in docs],
             "paragraphs": {d["doc_id"]: d["paragraphs"] for d in docs},
             "counts": {"documents": len(docs), "fields": len(fields),
                        "cells": len(docs) * len(fields)}}
    dump(work / "index.json", index)
    required = len(docs) * max(len(fields), 1)
    cov = {"required": required, "parsed": 0,
           "missing": ["%s\u00d7%s" % (d["doc_id"], f["field_id"]) for d in docs
                       for f in fields]}
    status = "input_error" if not docs else "partial"
    doc = cd.base_doc(meta, status, deg, err, VERSION)
    doc["coverage"] = cov
    doc["result"] = {"documents": index["docs"], "fields": fields, "coverage": cov}
    final = cd.echo_contract(case.get("output_contract"), doc)
    dump(out / "result.json", final)
    print(json.dumps({
        "ok": True, "command": "init", "meta": meta, "status": status,
        "counts": index["counts"],
        "docs": [{"doc_id": d["doc_id"], "path": d["path"], "label": d["label"],
                  "paragraphs": len(d["paragraphs"])} for d in docs],
        "declared_fields": fields, "notes": deg,
        "next": "init indexes; build derives a deterministic comparison when no draft "
                "exists, or uses a valid authored draft",
    }, ensure_ascii=False, indent=2))
    return 0


def cmd_docs(args):
    index = load(Path(args.work) / "index.json", {}) or {}
    print(json.dumps({"docs": index.get("docs", []), "fields": index.get("fields", []),
                      "counts": index.get("counts", {})}, ensure_ascii=False, indent=2))
    return 0


def cmd_show(args):
    index = load(Path(args.work) / "index.json", {}) or {}
    paras = index.get("paragraphs", {}) or {}
    if args.doc and args.paragraph:
        p = next((x for x in paras.get(args.doc, [])
                  if x["paragraph_id"] == args.paragraph), None)
        if not p:
            print(json.dumps({"error": "unknown paragraph: %s#%s"
                              % (args.doc, args.paragraph)}))
            return 0
        print("=== [%s#%s]" % (args.doc, p["paragraph_id"]))
        print(p["text"])
        return 0
    if args.doc:
        for p in paras.get(args.doc, []):
            print("=== [%s#%s] %s" % (args.doc, p["paragraph_id"], p["text"][:400]))
        return 0
    print(json.dumps({"docs": [{k: d.get(k) for k in ("doc_id", "path", "label", "paragraphs")}
                               for d in index.get("docs", [])]}, ensure_ascii=False, indent=2))
    return 0


def cmd_check(args):
    report = run_checks(args)
    try:
        dump(Path(args.work) / "check_report.json", report)
    except Exception:
        pass
    print(json.dumps({"passed": report["passed"], "FAIL": report["fails"],
                      "WARN": report["warnings"], "PASS": report["passes"],
                      "counts": report.get("counts", {})}, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- build
def _write_csv(out, dic, matrix, index):
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator="\n")
    writer.writerow(["doc_id", "source_document_id", "paragraph_id", "doc_label",
                     "field_id", "field_name", "value", "unit", "unit_normalized",
                     "metric_definition", "dataset", "status", "locator", "quote",
                     "reason", "comparability_dimension", "comparability_note"])
    label_of = {d["doc_id"]: d.get("label", "") for d in index.get("docs", [])}
    name_of = {str(f.get("field_id")): f.get("name") for f in dic}
    for c in matrix:
        comp = c.get("comparability") or {}
        writer.writerow([c.get("doc_id"), c.get("source_document_id", ""),
                         c.get("paragraph_id", ""), label_of.get(c.get("doc_id"), ""),
                         c.get("field_id"), name_of.get(str(c.get("field_id")), ""),
                         c.get("value", ""), c.get("unit", ""),
                         c.get("unit_normalized", ""), c.get("metric_definition", ""),
                         c.get("dataset", ""), c.get("status", ""),
                         c.get("locator", ""), c.get("quote", ""),
                         c.get("reason", ""), comp.get("dimension") or "",
                         comp.get("note") or ""])
    (out / "comparison_matrix.csv").write_text(buf.getvalue(), encoding="utf-8")


def cmd_build(args):
    work, out = Path(args.work), Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    deg, err = [], []
    case = load(Path(args.input) / "case.json")
    if not isinstance(case, dict):
        case = {}
        deg.append("case.json missing or not a JSON object")
    index = load(work / "index.json")
    if not isinstance(index, dict) or not index:
        deg.append("index.json absent; build ran init implicitly")
        try:
            cmd_init(args)
            index = load(work / "index.json", {}) or {}
        except Exception as exc:
            err.append("implicit init failed: %s" % exc)
            index = {"docs": [], "fields": [], "paragraphs": {}}
    meta = index.get("meta") or cd.meta_ids(case)
    draft = load(Path(args.draft) if args.draft else (work / "draft.json"))
    derived = False
    if not isinstance(draft, dict):
        draft = {}
    if not cd.usable_draft(draft):
        deg.append("no usable agent draft; deriving deterministic multi-document "
                   "comparison from /input")
        try:
            draft = cd.derive(case, args.input, index)
            derived = True
        except Exception as exc:
            err.append("derive failed: %s" % exc)
            draft = {}
            derived = False
    check_report = None
    if isinstance(draft, dict):
        try:
            check_report = check_draft(index, draft)
        except Exception as exc:
            deg.append("check failed during build: %s" % exc)

    dic = draft.get("field_dictionary") or []
    matrix = draft.get("matrix") or []
    comparability = draft.get("comparability") or []
    syn = draft.get("synthesis") or {"allowed": False, "basis": "not produced"}
    doc_ids = [d["doc_id"] for d in index.get("docs", [])]
    fields = [str(f.get("field_id")) for f in dic if f.get("field_id")]
    if not fields:
        fields = [str(f.get("field_id")) for f in index.get("fields", [])
                  if f.get("field_id")]
    have = {(str(c.get("doc_id")), str(c.get("field_id"))) for c in matrix}
    miss = ["%s\u00d7%s" % (d, f) for d in doc_ids for f in fields if (d, f) not in have]
    reported = sum(1 for c in matrix if c.get("status") == "reported")
    valued = sum(1 for c in matrix if c.get("value") not in (None, "")
                 and c.get("status") in ("reported", "not_comparable", "source_conflict"))
    cov = {"required": len(doc_ids) * max(len(fields), 1), "parsed": valued,
           "resolved": len(matrix), "reported": reported,
           "unreported": sum(1 for c in matrix if c.get("status") == "not_reported"),
           "noncomparable": sum(
               1 for c in matrix if c.get("status") == "not_comparable"),
           "missing": miss}

    fails = (check_report or {}).get("fails") or []
    status = "ok"
    if not index.get("docs"):
        status = "input_error"
        err.append("no documents discovered under input dir")
    elif not dic or not matrix:
        status = "partial"
        deg.append("field_dictionary or matrix is empty")
    elif fails:
        status = "partial"
        deg.append("%d mechanical check failure(s)" % len(fails))
    elif miss:
        status = "partial"
        deg.append("matrix incomplete: %d cell(s) missing" % len(miss))
    if derived and status == "partial" and not fails:
        deg.append("derived matrix is present but incomplete relative to coverage")

    deliverables = {}
    try:
        _write_csv(out, dic, matrix, index)
        deliverables["comparison_matrix"] = "comparison_matrix.csv"
    except Exception as exc:
        err.append("comparison_matrix.csv failed: %s" % exc)
    for name, payload in (("field_dictionary.json", dic),
                          ("comparability.json", {"fields": comparability,
                                                  "synthesis": syn})):
        try:
            dump(out / name, payload)
            deliverables[name.replace(".json", "")] = name
        except Exception as exc:
            err.append("%s failed: %s" % (name, exc))

    doc = cd.base_doc(meta, status, deg, err, VERSION)
    doc.update({"case_id": draft.get("case_id") or meta.get("case_id", ""),
                "field_dictionary": dic, "matrix": matrix,
                "comparability": comparability, "synthesis": syn,
                "claims": draft.get("claims") or [],
                "uncertainties": draft.get("uncertainties") or [],
                "coverage": cov,
                "sources": [{k: d.get(k) for k in ("doc_id", "path", "label", "chars")}
                            for d in index.get("docs", [])],
                "pending_human": draft.get("pending_human") or [],
                "deliverables": deliverables})
    doc["result"] = {"documents": index.get("docs", []), "field_dictionary": dic,
                     "matrix": matrix, "comparability": comparability,
                     "synthesis": syn, "coverage": cov,
                     "gaps": draft.get("gaps") or []}
    if check_report:
        doc["self_check"] = {"passed": check_report.get("passed"),
                             "fail_count": len(fails)}
    final = cd.echo_contract(case.get("output_contract"), doc)
    try:
        dump(out / "result.json", final)
    except Exception as exc:
        err.append("result.json write failed: %s" % exc)
    try:
        (out / "report.md").write_text(cd.build_report(doc, check_report, status),
                                       encoding="utf-8")
        deliverables["report"] = "report.md"
    except Exception as exc:
        err.append("report.md failed: %s" % exc)
    print(json.dumps({"ok": True, "command": "build", "status": status,
                      "derived": derived, "case_id": final.get("case_id", ""),
                      "coverage": cov, "deliverables": deliverables, "errors": err,
                      "degradations": deg}, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- cli
def add_io(p):
    for n in ("input", "work", "output"):
        p.add_argument("--" + n, default=argparse.SUPPRESS, help=n + " dir")


def build_parser():
    ap = argparse.ArgumentParser(
        prog="cross-doc-compare",
        description="Compare several papers cell by cell on one shared field dictionary, "
                    "with a six-dimension comparability gate and a verbatim quote per cell. "
                    "build derives a real comparison when no draft exists.")
    ap.add_argument("--input", default=os.environ.get("INPUT_DIR", "/input"))
    ap.add_argument("--work", default=os.environ.get("WORK_DIR", "/app/work"))
    ap.add_argument("--output", default=os.environ.get("OUTPUT_DIR", "/app/output"))
    ap.add_argument("--version", action="version", version="cross-doc-compare " + VERSION)
    sub = ap.add_subparsers(dest="command")
    for name in ("init", "docs"):
        p = sub.add_parser(name)
        add_io(p)
    p = sub.add_parser("show", help="print document paragraphs")
    add_io(p)
    p.add_argument("--doc")
    p.add_argument("--paragraph")
    for name, helptext in (("check", "validate draft"),
                           ("build", "assemble matrix + result.json"),
                           ("selfcheck", "re-run checks only")):
        p = sub.add_parser(name, help=helptext)
        add_io(p)
        if name != "selfcheck":
            p.add_argument("--draft")
    return ap


def main(argv):
    ap = build_parser()
    try:
        args = ap.parse_args(argv)
    except SystemExit:
        return 0
    if not args.command:
        ap.print_help()
        return 0
    fn = {"init": cmd_init, "docs": cmd_docs, "show": cmd_show, "check": cmd_check,
          "build": cmd_build, "selfcheck": cmd_check}.get(args.command)
    return fn(args) if fn else 0


def emergency(argv):
    try:
        try:
            args, _ = build_parser().parse_known_args(argv)
        except SystemExit:
            args = None
        out = Path(getattr(args, "output", None) or "/app/output")
        out.mkdir(parents=True, exist_ok=True)
        if not (out / "result.json").exists():
            dump(out / "result.json", {
                "case_id": "", "material_version": "", "status": "partial",
                "result": {}, "field_dictionary": [], "matrix": [], "comparability": [],
                "synthesis": {"allowed": False, "basis": "emergency finalize"},
                "claims": [], "uncertainties": [],
                "coverage": {"required": 0, "parsed": 0, "missing": []},
                "sources": [], "pending_human": [], "errors": ["unhandled exception"],
                "degradations": ["emergency finalize"], "deliverables": {}})
    except Exception:
        pass


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except Exception:
        try:
            sys.stderr.write(traceback.format_exc())
        except Exception:
            pass
        emergency(sys.argv[1:])
    sys.exit(0)

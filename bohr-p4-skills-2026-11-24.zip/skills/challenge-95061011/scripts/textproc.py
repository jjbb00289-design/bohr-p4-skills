#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Text processing for literature-qa: io helpers, paragraph parsing, question/paper
discovery, and the Chinese->English gloss used by evidence retrieval.

Split out of main.py so the orchestrator stays under the 25KB guard.
Pure stdlib, no network.
"""
import json
import re
from pathlib import Path

MAX_READ = 2_000_000

PARA_PATTERNS = [
    re.compile(r"^\s*\[(?:P|p|para|paragraph)?\s*(\d{1,4})\]\s*"),
    re.compile(r"^\s*(?:P|p|para\.?|paragraph)\s*(\d{1,4})\s*[.:)\-]\s*", re.I),
    re.compile(r"^\s*\((\d{1,4})\)\s*"),
    re.compile(r"^\s*(\d{1,4})[.)]\s+"),
]
STOP = set("""a an the of for and or to in on at by with from as is are was were be been being
this that these those it its their there which what when where how why does do did not no
isn't can could should would may might must shall will""".split())

# The fixed cases pair an ENGLISH paper with CHINESE questions, so pure keyword overlap
# finds nothing. This gloss bridges the two for `find`: Chinese question terms map to
# English stems that are matched by prefix against the paper.
CN_EN = {
    "循环": "cycl", "稳定性": "stabil", "产率": "yield", "选择性": "selectiv",
    "温度": "temperat", "压力": "pressur", "时间": "time", "浓度": "concentrat",
    "样品": "sample", "实验": "experiment", "方法": "method", "结果": "result",
    "结论": "conclusion", "误差": "error", "标准差": "deviation", "显著": "signific",
    "条件": "condition", "比例": "ratio", "含量": "content", "数值": "value",
    "材料": "material", "合金": "alloy", "强度": "strength", "硬度": "hardness",
    "疲劳": "fatigu", "断裂": "fractur", "拉伸": "tensil", "应变": "strain",
    "应力": "stress", "热处理": "heat treatment", "腐蚀": "corros", "涂层": "coating",
    "复合": "composit", "制备": "prepar", "烧结": "sinter", "晶粒": "grain",
    "退火": "anneal", "淬火": "quench", "相": "phase",
    "模型": "model", "训练": "train", "准确率": "accura", "数据集": "dataset",
    "神经网络": "neural", "学习": "learn", "参数": "parameter", "优化": "optim",
    "损失": "loss", "过拟合": "overfit", "特征": "feature", "分类": "classif",
    "回归": "regress", "推理": "inferen", "算法": "algorithm", "基线": "baselin",
    "降解": "degrad", "光催化": "photocatalyt", "催化剂": "catalyst", "吸附": "adsorpt",
    "污染物": "pollutant", "染料": "dye", "去除": "removal", "速率": "rate",
    "效率": "efficien", "活性": "activ", "比表面积": "surface area", "带隙": "band gap",
    "氧化": "oxidat", "还原": "reduct", "纳米": "nano", "颗粒": "particle",
    "溶液": "solution", "光照": "illuminat", "产氢": "hydrogen", "电流": "current",
    "电压": "voltage", "容量": "capacit", "电极": "electrode", "电池": "batter",
}


def dump(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def load(path, default=None):
    try:
        return json.loads(read_text(path).lstrip("\ufeff"))
    except Exception:
        return default


def read_text(path, limit=MAX_READ):
    try:
        raw = Path(path).read_bytes()[:limit]
    except Exception:
        return ""
    for enc in ("utf-8", "utf-16", "gb18030", "latin-1"):
        try:
            return raw.decode(enc).lstrip("\ufeff")
        except Exception:
            continue
    return raw.decode("utf-8", "replace").lstrip("\ufeff")


def norm(text):
    if text is None:
        return ""
    text = str(text).replace("\u3000", " ").replace("\xa0", " ").replace("\u2019", "'")
    return re.sub(r"\s+", " ", text).strip().lower()


def tokens(text):
    return [t for t in re.findall(r"[a-z0-9]+", norm(text)) if t not in STOP and len(t) > 2]


def expand_cn(query):
    """English stems for Chinese question terms, so `find` crosses the language gap."""
    stems = set()
    for cn, en in CN_EN.items():
        if cn in (query or ""):
            stems.update(en.split())
    return stems


def strip_marker(line):
    out = line
    for pat in PARA_PATTERNS:
        m = pat.match(out)
        if m:
            out = out[m.end():]
            break
    return out.strip()


def parse_paragraphs(text):
    """Split paper text into [{paragraph_id, locator, text}]. Keeps numbering when present."""
    if not text or not text.strip():
        return []
    lines = text.replace("\r\n", "\n").split("\n")
    paras, pid, buf = [], None, []

    def flush():
        if pid is not None and buf and "\n".join(buf).strip():
            paras.append({"paragraph_id": pid, "locator": pid,
                          "text": "\n".join(buf).strip()})

    for line in lines:
        if not line.strip():
            continue
        matched = None
        for pat in PARA_PATTERNS:
            m = pat.match(line)
            if m:
                matched = m.group(1)
                break
        if matched is not None:
            flush()
            pid = "P%s" % matched
            buf = [strip_marker(line)]
            continue
        buf.append(line.strip())
    flush()
    if not paras:
        blocks = [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip()]
        if len(blocks) <= 1:
            words = text.split()
            blocks = [" ".join(words[i:i + 120]) for i in range(0, len(words), 120)]
        paras = [{"paragraph_id": "P%d" % (i + 1), "locator": "P%d" % (i + 1), "text": b}
                 for i, b in enumerate(blocks)]
    return paras


def _qid(item, idx):
    if isinstance(item, dict):
        for k in ("question_id", "qid", "id", "questionId"):
            if item.get(k) not in (None, ""):
                return str(item[k])
    return "Q%d" % (idx + 1)


def _qtext(item):
    if isinstance(item, str):
        return item
    if isinstance(item, dict):
        for k in ("question", "text", "q", "query", "instruction", "prompt"):
            if item.get(k) not in (None, ""):
                return str(item[k])
    return ""


def find_questions(case, input_dir):
    """Locate the question list: case fields first, then questions.* / task.md."""
    candidates = []
    for key in ("questions", "question_list", "tasks", "queries", "items"):
        val = case.get(key)
        if isinstance(val, list) and val:
            candidates.append(val)
    for key in ("task", "task_instruction", "spec"):
        val = case.get(key)
        if isinstance(val, dict):
            for k in ("questions", "question_list"):
                if isinstance(val.get(k), list) and val[k]:
                    candidates.append(val[k])
    if not candidates:
        root = Path(input_dir)
        for name in ("questions.json", "questions.md", "questions.txt", "task.md"):
            p = root / name
            if not p.exists():
                continue
            if p.suffix == ".json":
                data = load(p)
                if isinstance(data, list) and data:
                    candidates.append(data)
                elif isinstance(data, dict):
                    for k in ("questions", "question_list", "items"):
                        if isinstance(data.get(k), list) and data[k]:
                            candidates.append(data[k])
            else:
                found = re.findall(r"^\s*(?:[-*]|\d+[.)]|Q\d+[:.])\s*(.{4,400})$",
                                   read_text(p), re.M)
                if found:
                    candidates.append(found)
    if not candidates:
        return []
    out = []
    for i, item in enumerate(candidates[0]):
        qid, qtext = _qid(item, i), _qtext(item)
        if not qtext:
            continue
        subs = []
        if isinstance(item, dict):
            for k in ("sub_questions", "subquestions", "subs"):
                if isinstance(item.get(k), list):
                    subs = [str(s) for s in item[k] if str(s).strip()]
        out.append({"question_id": qid, "question": qtext, "sub_questions": subs})
    return out


def find_paper(case, input_dir):
    """Return (paper_text, source). Longest text-like file wins."""
    for key in ("paper_text", "text", "content", "article", "manuscript", "full_text"):
        val = case.get(key)
        if isinstance(val, str) and len(val.strip()) > 40:
            return val, "case.json:%s" % key
    best, best_path, root = "", "", Path(input_dir)
    for p in sorted(root.rglob("*")):
        try:
            if not p.is_file() or p.stat().st_size > MAX_READ:
                continue
        except Exception:
            continue
        if (p.parent == root and p.name == "case.json") or p.suffix.lower() not in \
                (".txt", ".md", ".tex"):
            continue
        text = read_text(p)
        if len(text) > len(best):
            best, best_path = text, p.relative_to(root).as_posix()
    return best, best_path


def meta_of(case):
    def pick(*keys):
        for k in keys:
            v = case.get(k)
            if v not in (None, ""):
                return str(v)
        return ""
    return {"case_id": pick("case_id", "id", "caseId"),
            "paper_id": pick("paper_id", "paperId", "paper"),
            "material_version": pick("material_version", "version", "materialVersion")}

---
name: cross-doc-compare
description: Compare several scientific papers cell by cell on one shared field dictionary and a six-dimension comparability gate (task, metric, units, material, pollutant, budget). Use when a case supplies multiple documents plus a comparison workorder and asks which fields are comparable, what each paper reports, where values conflict, and whether a quantitative synthesis is defensible. If no authored draft exists, build derives a real document x field matrix from /input/comparison-workorder.json and the corpus documents; every cell keeps its own document's verbatim value, unit and paragraph locator, and unlike datasets or dyes are never pooled.
version: 1.1.0
---

# 多文档比较与整合（Cross-document comparison）

把多篇论文落到**同一套字段定义**上，逐格对照，并说明**能不能合在一起说**。

难点不是"给每篇写摘要"，而是四件事：

1. **对得齐**：字段定义先统一（共享 schema + 每篇自己的措辞），否则逐格对照没有意义。
2. **填得准**：每个单元格的值必须来自**它自己那篇文档**，单位/数据集/指标口径随值记录。
3. **说得清**：结论一致或冲突时，指出差异来自任务、指标、单位、材料、污染物还是预算。
4. **查得回**：每个取值和每条差异结论都能回到原文的精确 `source_document_id` + `paragraph_id` + 逐字引文。

## 何时使用

题面给多篇论文/文档 + `comparison-workorder`（要比较的字段/对象），要求做比较矩阵、
字段字典、可比性判定，或判断"能否定量汇总"。

不适用：单文档问答、需要联网补数据、材料里没有要比较的字段。

## 硬规则（先读这一节）

1. **清单优先**：`comparison_workorder` 里的每个字段都要在 `field_dictionary` 有定义、
   在每个文档上都有一格。**矩阵必须是 文档 × 字段 的笛卡尔积**，缺格即 `partial`。
2. **每格四状态**：`reported` / `not_reported` / `source_conflict` / `not_comparable`。
   没值不等于 0，**写 `not_reported` 并给理由**；单位/口径不同写 `not_comparable` 并保留原值。
3. **反串值**：`reported` 单元格的 `quote` 必须能在**该单元格自己的文档**里逐字命中。
   `check` 会把"引文其实来自另一篇"直接判 FAIL，消息写 `cross-document contamination`。
4. **单位/口径随值**：`unit`、数据集、指标定义一律记录，不静默统一
   （mg/L 与 mmol/L、SEM 与 SD、min^-1 与 s^-1 都不是同一个数）。
5. **六维可比性闸门**：每个字段在文档间先过六关
   `task / metric / units / material / pollutant / budget`，任一关是 `differs`
   或必比维度不是 `comparable`，就**不得定量汇总**；只给逐格对照 + 定性结论。
6. **永不跨文档串值/混合**：每个格只取该文档自己的文本；不把 A 的数值填到 B 的格，
   不把不同数据集/不同染料混池，不补造缺失值。
7. **`output_contract` 每个键原样回填**；缺失写 `null` 并计入 `degradations`。
8. **退出码恒 0**；任何异常都产出合法最小交付。

## 无工作稿也能跑（v1.1 关键改进）

`init` → `build` 之间**不需要** agent 先写 `/app/work/draft.json`。
当没有可用工作稿（缺失、空、或没有 `field_dictionary`+`matrix`）时，`build` 会
**确定性派生**出一份真实的多文档比较：

1. 读 `/input/comparison-workorder.json`（回退到 `case.json` 的
   `comparison_workorder`/`workorder`/`fields`）拿字段清单。
2. **先对齐字段定义**：给每个字段建 canonical 定义，并把每个文档自己的措辞记进
   `field_dictionary[i].doc_wording`，绝不因为名字相同就硬比不同口径。
3. **建比较矩阵**：每个 (字段, 文档) 一格，带精确 `source_document_id` + `paragraph_id`
   + 逐字 value + unit + quote；缺值写 `not_reported`，单位/口径不同写 `not_comparable`。
4. **算六维可比性**：`task, metric, units, material, pollutant, budget` 逐维给出
   `comparable / differs / partial / unreported`，任一 `differs` 即 `noncomparable`。
5. **不混池**：所有 `noncomparable` 与 `unreported` 条件都保留在矩阵/报告中，绝不丢弃、
   绝不插补、绝不做跨文档数值汇总。
6. 产出可编辑 `comparison_matrix.csv` + `comparability.json` + `report.md`，并写回
   `result.json`（沿用 `result`/`claims`/`coverage` 结构）。

> 若 agent 已经写了一份可用工作稿（有 `field_dictionary` 和 `matrix`），`build` **仍优先使用它**；
> 派生只发生在无可用工作稿时。派生是启发式文本抽取，无法替代细读：数值、单位、
> 染料名来自显式原文，其余一律记 `unreported`，不猜。

## 五命令主路径

```bash
python3 scripts/main.py init                 # 扫文档 + 字段清单 + partial result.json
python3 scripts/main.py docs                 # 文档清单与字段清单
python3 scripts/main.py show --doc m1        # 按 locator 打印该文档段落
python3 scripts/main.py show --doc m1 --paragraph P3
python3 scripts/main.py check                # 机械校验（含反串值 / 六维合成闸门）
python3 scripts/main.py build                # 无工作稿则派生，否则组装；产出矩阵 + 报告 + result.json
```

路径可用 `--input/--work/--output` 覆盖，写在子命令前后都生效。
不联网、不依赖当前工作目录、只用标准库。重复运行结果字节一致（无时间戳/随机）。

## 输入与输出

| 项 | 路径 |
|---|---|
| 输入 | `/input/case.json`（`case_id`、`output_contract`，可能含 `comparison_workorder`）、`/input/comparison-workorder.json`、`/input/task.md`、多篇文档 |
| 工作区 | `/app/work/`（`index.json`、`draft.json`、`check_report.json`） |
| 产物 | `/app/output/`：`result.json`（必需）、`comparison_matrix.csv`、`field_dictionary.json`、`comparability.json`、`report.md` |

## 工作稿 schema（`/app/work/draft.json`，可选）

```json
{
  "case_id": "…",
  "field_dictionary": [
    {"field_id": "f1", "name": "degradation rate constant k",
     "definition": "pseudo-first-order k from ln(C0/C) vs t", "unit": "min^-1"}
  ],
  "matrix": [
    {"source_document_id": "m1", "doc_id": "m1", "field_id": "f1",
     "paragraph_id": "P2", "locator": "m1#P2",
     "status": "reported", "value": "0.042", "unit": "min^-1",
     "dataset": "10 mg/L RhB, visible light",
     "metric_definition": "pseudo-first-order k",
     "quote": "…逐字，且必须来自 m1…"}
  ],
  "comparability": [
    {"field_id": "f1", "comparable": false,
     "basis": "units differs (min^-1 vs s^-1); pollutant differs (RhB vs Methyl orange)",
     "dimensions": {
        "task": {"status": "comparable", "values": {"m1": "photocatalytic degradation",
                                                   "m2": "photocatalytic degradation"}},
        "metric": {"status": "comparable", "values": {"m1": "…", "m2": "…"}},
        "units": {"status": "differs", "values": {"m1": "min^-1", "m2": "s^-1"}},
        "material": {"status": "unreported", "values": {}},
        "pollutant": {"status": "differs", "values": {"m1": "Rhodamine B",
                                                      "m2": "Methyl orange"}},
        "budget": {"status": "comparable", "values": {"m1": "0.5 g/L", "m2": "0.5 g/L"}}
     }}
  ],
  "synthesis": {"allowed": false,
                "basis": "f1 units/pollutant differ; 不做跨文档定量汇总"},
  "claims": [{"claim_id": "c1", "text": "…",
              "evidence": [{"doc_id": "m1", "locator": "m1#P2", "quote": "…逐字…"}]}],
  "gaps": [], "uncertainties": [], "pending_human": []
}
```

## 四状态判定

| status | 什么时候用 | 必须带 |
|---|---|---|
| `reported` | 该文档明确报告了该字段的值 | `value` + `unit` + `locator` + 逐字 `quote`（**来自该文档**） |
| `not_reported` | 该文档没有报告（不是"为零"、不是"没找到"） | `reason` |
| `source_conflict` | 同一文档内部/不同来源给出互斥值 | `conflict_with` + `reason` |
| `not_comparable` | 有值，但口径/单位/条件不可比（派生时单位不一致） | `reason`（保留 value/unit/quote 以便复核） |

**`not_reported` 不等于 0，也不等于 `not_comparable`。** 三者混用是本赛道最常见的扣分点。

## 六维可比性判据

每个字段在文档间逐维判断：

| 维度 | 判什么 | 例子 |
|---|---|---|
| `task` | 研究任务/反应类型是否一致 | photocatalytic degradation vs adsorption |
| `metric` | 指标口径是否同一 | 伪一级 k vs 去除率 |
| `units` | 单位是否同一（归一后比较，原单位随值保留） | min^-1 vs s^-1 |
| `material` | 催化剂/材料/样本是否同一 | TiO2 vs g-C3N4 |
| `pollutant` | 目标污染物/染料是否同一 | RhB vs Methyl orange |
| `budget` | 剂量/规模/预算是否同一（常未报告） | 0.5 g/L vs 1.0 g/L |

- 每维 `comparable`（所有已报告文档一致）/ `differs`（至少两个不同）/
  `partial`（只有一篇有值）/ `unreported`（全部没写）。
- 字段 `comparable: true` 需要：≥2 篇有值，且没有 `differs`，且该字段类型的必比维度全部 `comparable`。
- 必比维度：metric → task/metric/units/material/pollutant；pollutant → task/metric/units/pollutant；
  material → task/metric/units/material；budget → task/metric/units/budget。
- 只要字段 `comparable: false`，`synthesis.allowed` 就必须 `false`。

## 证据规范

- `locator` 形如 `m1#P5`（文档 m1 的第 5 段）；`source_document_id` + `paragraph_id` 单独存。
- `quote` 逐字复制**该文档**的短句，不改写、不拼接、不跨文档。
- 交叉引用另一篇时，用 `conflict_with` 或 claims 的 evidence，**不要把 B 的引文塞进 A 的格**。

## 降级表（遇到就照做）

| 情况 | 处置 | 记录位置 |
|---|---|---|
| 无可用工作稿 | `build` 确定性派生（见上） | `degradations` |
| 字段清单缺失 | `init` 记 `no declared comparison fields` | `degradations` |
| 某文档缺一节 | 该文档该字段 `not_reported` + 理由 | `matrix` |
| 两篇口径/单位不同 | `not_comparable` + 写清差在哪，不丢弃 | `matrix` + `comparability` |
| 两篇染料/材料不同 | 各自保留值，字段判 `noncomparable`，不混池 | `matrix` + `comparability` |
| 同一文档内部矛盾 | `source_conflict` + `conflict_with` | `matrix` |
| 文档是 PDF/图片 | 记 `degradations`，靠视觉阅读或平台工具 | `degradations` |
| 没有文档 | `status=input_error`，最小交付 | `errors` |

**永远不要**：把 A 的数值填到 B 的格、把不同单位直接比、把"未报告"写成 0、
在字段不可比时给出定量汇总、把不同染料/数据集混池。

## 自检清单

- [ ] `init` 后 `result.json` 已存在（partial），退出码 0。
- [ ] `field_dictionary` 覆盖 workorder 每个字段，每个有 name 与 definition。
- [ ] 矩阵是 文档 × 字段 的笛卡尔积，每格有 `source_document_id` + `paragraph_id`。
- [ ] 每个 `reported` 格有 `value`/`unit`/`locator`/`quote`，且引文来自**该文档**。
- [ ] 每个 `not_reported`/`not_comparable`/`source_conflict` 都有 `reason`。
- [ ] 每个字段有六维可比性判定，`differs`/`unreported` 均被保留。
- [ ] `synthesis.allowed` 与 `comparability` 一致，且有 `basis`；不做任何数值混池。
- [ ] `build` 后五件产物齐全，契约键零缺失；两次运行 `result.json` 字节一致。

## 最小调用示例

```bash
# /input: case.json + comparison-workorder.json + task.md + materials/paper1.md, paper2.md
python3 scripts/main.py init
python3 scripts/main.py docs
python3 scripts/main.py show --doc m1
#  可选：写 /app/work/draft.json；不写也能 build（派生）
python3 scripts/main.py check
python3 scripts/main.py build
```

示意输出（**示例，非正式案例结果**）：

```json
{"case_id": "demo", "status": "ok", "derived": true,
 "coverage": {"required": 4, "parsed": 3, "resolved": 4,
              "noncomparable": 1, "unreported": 0, "missing": []},
 "synthesis": {"allowed": false, "basis": "Quantitative synthesis blocked for fields: f1"}}
```

字段级说明见 `references/schema.md`；完整示例见 `references/example.md`。

## 依赖与维护

- Python ≥3.8 标准库（`json`/`csv`/`re`/`argparse`/`os`/`pathlib`）。无第三方依赖、不联网。
- 版本 1.1.0。字段改动只做**追加**，不改已有键名。
- 已知限制：只解析文本类材料（md/txt/tex/json/csv）；PDF/DOCX 记降级；
  段落编号靠正则识别，识别不到时按空行分块并注明；单位归一用于可比性判断，
  原单位逐格保留，不做数值单位换算（换算须另存原值与规则）；
  无工作稿的派生是启发式抽取，不能替代人工细读，派生结果应抽样核对后再用于结论。

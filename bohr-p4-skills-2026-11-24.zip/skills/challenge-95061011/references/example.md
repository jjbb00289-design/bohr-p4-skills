# 最小调用示例（示例，非正式案例结果）

> ⚠️ **人工构造的演示示例，不是平台固定案例的结果，也不来自任何真实论文。**
> 文档、字段、数值均为说明接口而虚构。

## 1. 假设输入（虚构）

`/input/comparison-workorder.json`：

```json
{"fields": [
  {"field_id": "f1", "name": "rate constant k",
   "definition": "pseudo-first-order rate constant fitted from ln(C0/C) vs t",
   "unit": "min^-1"},
  {"field_id": "f2", "name": "target pollutant",
   "definition": "dye used as the target pollutant", "unit": ""}
]}
```

`materials/paper1.md`（虚构）：

```markdown
[1] The photocatalytic degradation of Rhodamine B was investigated under visible light.
[2] The fitted pseudo-first-order rate constant was 0.042 min-1.
[3] The catalyst dose was 0.5 g/L and the initial RhB concentration was 10 mg/L.
```

`materials/paper2.md`（虚构）：

```markdown
[1] The photocatalytic degradation of Methyl orange was investigated under visible light.
[2] The fitted pseudo-first-order rate constant was 0.0007 s-1.
[3] The catalyst dose was 0.5 g/L and the initial dye concentration was 10 mg/L.
```

## 2. 调用（不写工作稿）

```bash
python3 scripts/main.py init
python3 scripts/main.py docs
python3 scripts/main.py show --doc m1
python3 scripts/main.py build     # 无工作稿 → 确定性派生
```

## 3. 派生后的 `comparison_matrix.csv`（虚构片段）

```csv
doc_id,source_document_id,paragraph_id,doc_label,field_id,field_name,value,unit,unit_normalized,metric_definition,dataset,status,locator,quote,reason,comparability_dimension,comparability_note
m1,m1,P2,paper1,f1,rate constant k,0.042,min-1,min^-1,pseudo-first-order rate constant,photocatalytic degradation; Rhodamine B,reported,m1#P2,"The fitted pseudo-first-order rate constant was 0.042 min-1.",,,
m2,m2,P2,paper2,f1,rate constant k,0.0007,s-1,s^-1,pseudo-first-order rate constant,photocatalytic degradation; Methyl orange,not_comparable,m2#P2,"The fitted pseudo-first-order rate constant was 0.0007 s-1.","unit differs: document reports 's-1' (normalized s^-1), canonical field unit is 'min^-1'",units,not comparable across documents on: units, pollutant
m1,m1,P1,paper1,f2,target pollutant,Rhodamine B,unitless,unitless,dye used as the target pollutant,photocatalytic degradation; Rhodamine B,reported,m1#P1,"The photocatalytic degradation of Rhodamine B was investigated under visible light.",,pollutant,not comparable across documents on: pollutant
m2,m2,P1,paper2,f2,target pollutant,Methyl orange,unitless,unitless,dye used as the target pollutant,photocatalytic degradation; Methyl orange,reported,m2#P1,"The photocatalytic degradation of Methyl orange was investigated under visible light.",,pollutant,not comparable across documents on: pollutant
```

## 4. 六维可比性（虚构片段）

```json
{"field_id": "f1", "comparable": false,
 "basis": "differs on: units=differs, pollutant=differs; required dimension(s) not all comparable: material",
 "dimensions": {
   "task":    {"status": "comparable", "values": {"m1": "photocatalytic degradation",
                                                  "m2": "photocatalytic degradation"}},
   "metric":  {"status": "comparable", "values": {"m1": "pseudo-first-order rate constant",
                                                  "m2": "pseudo-first-order rate constant"}},
   "units":   {"status": "differs",    "values": {"m1": "min^-1", "m2": "s^-1"}},
   "material":{"status": "unreported", "values": {}},
   "pollutant":{"status": "differs",   "values": {"m1": "Rhodamine B", "m2": "Methyl orange"}},
   "budget":  {"status": "comparable", "values": {"m1": "0.5 g/L; 10 mg/L",
                                                  "m2": "0.5 g/L; 10 mg/L"}}
 }}
```

## 5. 被 check 拦住的写法

| 写法 | check 反应 |
|---|---|
| 漏掉 `m2×f2` 一格 | `1 cell(s) missing from the matrix` |
| 把 m1 的引文填进 m2 的格 | `quote comes from document m1 instead of m2 (cross-document contamination)` |
| 引文改写 | `quote not verbatim in document m2` |
| `status: "missing"` | `status='missing' not in [...]` |
| 有不可比字段却 `synthesis.allowed: true` | `synthesis.allowed=true but 2 field(s) are judged not comparable` |
| `reported` 但无 value | `is reported but has no value` |

## 6. 降级示例

### 无工作稿直接 build（v1.1 已改为派生，不再空脚手架）

```json
{"ok": true, "command": "build", "status": "ok", "derived": true,
 "coverage": {"required": 4, "parsed": 3, "resolved": 4,
              "unreported": 0, "noncomparable": 1, "missing": []},
 "degradations": ["no usable agent draft; deriving deterministic multi-document comparison from /input"]}
```

五件产物仍生成，契约键零缺失，退出码 0。

### case.json / comparison-workorder.json 都没有字段

`init` 记 `no declared comparison fields`，`fields` 为空列表，派生矩阵为空，
`status=partial`，最小交付仍写回 `result.json` 并回填契约键。

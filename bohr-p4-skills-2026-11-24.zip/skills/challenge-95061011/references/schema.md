# 字段定义与判据（多文档比较）

> 版本 1.1.0。字段只做追加，不改已有键名。
> 核心原则：**逐格可复核，不跨文档串值，口径不一致就不汇总，不同染料/数据集不混池。**

## 顶层

| 字段 | 必填 | 说明 |
|---|---|---|
| `case_id` | ✅ | 原样取自 `/input/case.json` |
| `material_version` | | 若输入给了就回填 |
| `status` | ✅ | `ok` / `partial` / `insufficient_evidence` / `input_error` |
| `field_dictionary` | ✅ | 统一定义的字段表（见 §1） |
| `matrix` | ✅ | 文档 × 字段 的单元格（见 §2） |
| `comparability` | ✅ | 每个字段能否跨文档比较 + 六维判定（见 §3） |
| `synthesis` | ✅ | `{allowed, basis}`；不可比时必须 `false` |
| `claims` / `uncertainties` / `sources` / `coverage` | ✅ | 契约字段 |
| `pending_human` / `errors` / `degradations` | ✅ | 空数组也要有 |
| `deliverables` | | `comparison_matrix` / `field_dictionary` / `comparability` / `report` |
| `self_check` | | `{passed, fail_count}` |

`result` 内另存 `{documents, field_dictionary, matrix, comparability, synthesis, coverage, gaps}`。

## 1. field_dictionary[i]

| 字段 | 必填 | 说明 |
|---|---|---|
| `field_id` | ✅ | `f1` 这类稳定 id，**全局唯一** |
| `name` | ✅ | 人读名称 |
| `definition` | ✅（建议） | **口径**：怎么算的、从什么数据来。这是"对得齐"的关键 |
| `unit` | | 目标单位；原文档单位不同要另记 |
| `type` | | `metric`/`pollutant`/`material`/`task`/`budget` |
| `aliases` | | 同义/关键词，派生抽取时用于定位 |
| `doc_wording` | | 每篇文档自己的措辞 + 定位（字段定义对齐证据） |

**先定义再填格。** 定义不统一就逐格对照，等于把不同的东西放在同一列。

## 2. matrix[k]

| 字段 | 必填 | 说明 |
|---|---|---|
| `source_document_id` | ✅ | 精确文档 id（`m1`），与 `doc_id` 一致 |
| `doc_id` | ✅ | 兼容字段，等于 `source_document_id` |
| `field_id` | ✅ | 必须是 `field_dictionary` 里的 id |
| `paragraph_id` | ✅（有值时） | 精确段落 id（`P2`） |
| `locator` | ✅（建议） | `m1#P2` |
| `status` | ✅ | `reported` / `not_reported` / `source_conflict` / `not_comparable` |
| `value` / `unit` | status=`reported` 时必填 | 原文字面值，不换算、不取整 |
| `unit_normalized` | | 归一后单位（只用于可比性，原单位仍在 `unit`） |
| `dataset` | | 数据集/样本条件 |
| `metric_definition` | | 该文档自己的指标口径（与 field 口径可能不同！） |
| `quote` | status=`reported` 时必填 | **该文档**的逐字短句 |
| `reason` | status≠reported 时必填 | 为什么没有/为什么不可比/冲突在哪 |
| `conflict_with` | status=`source_conflict` 时必填 | 冲突的另一处 locator |
| `comparability` | 派生时 | `{comparable, dimension, note}` 逐格标注 |
| `facets` | 派生时 | 该格的六维 facet 取值 |

### 矩阵完整性

`check` 要求 **每个 doc × 每个 field 都有一格**。缺格会列进 `coverage.missing` 并判 `partial`。
没有值不是缺格——缺格是"你忘了比较"，没值是 `not_reported`。
无工作稿派生时，矩阵是完整的笛卡尔积：没值写 `not_reported`，口径/单位不同写 `not_comparable`。

## 3. comparability[i]（六维判定）

| 字段 | 必填 | 说明 |
|---|---|---|
| `field_id` | ✅ | 对应字典项 |
| `comparable` | ✅ | 布尔：≥2 篇有值、无 `differs`、必比维度全部 `comparable` |
| `basis` | ✅ | 为什么可比/不可比（哪一维、差在哪） |
| `dimensions` | ✅ | `task/metric/units/material/pollutant/budget` 六维，每维 `{status, values}` |
| `reported_documents` | | 有值的文档 id 列表 |
| `differing_dimensions` | | 状态为 `differs` 的维度 |
| `unreported_dimensions` | | 状态为 `unreported` 的维度（保留，不插补） |

`dimensions[d].status`：

- `comparable`：所有有值文档在该维取值一致；
- `differs`：至少两个文档取值不同 → 字段不可比；
- `partial`：只有一篇有值（不足以汇合）；
- `unreported`：全部未报告 → 作为条件保留，不当作可比。

**必比维度**：metric 字段为 task/metric/units/material/pollutant；pollutant 字段为
task/metric/units/pollutant；material 字段为 task/metric/units/material；
budget 字段为 task/metric/units/budget；task 字段为 task/metric/units。

## 4. synthesis

```json
{"allowed": false, "basis": "f1 的 units 与 pollutant 不同，不做跨文档定量汇总"}
```

- `allowed: true` 的前提是**所有** field 的 `comparable` 都为 true，且写了 `basis`。
- 只要有任一字段不可比，就必须 `allowed: false`——给数改成逐格对照 + 定性结论。
- 即便 `allowed: true`，本工具也**不做任何跨文档数值汇总**：只报告逐格原文值，
  不产生平均/合并值，避免混池。
- `check` 会拦：`synthesis.allowed=true but N field(s) are judged not comparable`。

## 5. 反串值（最容易犯、后果最重的错）

`check` 对每个 `reported` 格做三步：
1. 取该格 `quote`，在**该格 doc_id 对应的文档**里做归一化子串匹配；
2. 不命中时，再去**其它文档**里找；
3. 若在别的文档命中 → FAIL，消息 `cross-document contamination`（跨文档串值）。

现实中它长这样：你从 paper A 抄了 "k = 0.042 min⁻¹"，填到 B 的格里 —— 数字没错，
但归属错了，整张矩阵的可信度归零。

## 6. 四状态速查

| 你观察到 | 该用 | 不该用 |
|---|---|---|
| 文档明确写了值 | `reported` | — |
| 文档没写这个指标 | `not_reported` | `not_comparable` / 0 |
| 文档有值但单位/口径不同 | `not_comparable` | `reported` + 硬比 |
| 同一文档/来源给出互斥值 | `source_conflict` | 挑一个写 |
| 文档只给了图，没给数字 | `not_reported`（理由写"仅有图"） | 从图上读数当 reported（除非标明 approx） |
| 两篇染料/材料不同 | 各自 `reported` + 字段级 `noncomparable` | 混池成一条 |

## 7. 常见 FAIL 与修法

| FAIL | 原因 | 修法 |
|---|---|---|
| `N cell(s) missing from the matrix` | 漏格 | 补 `not_reported` 或 `not_comparable` |
| `quote comes from document m2 instead of m1 (cross-document contamination)` | 串值 | 换成本文档的引文 |
| `quote not verbatim in document m1` | 改写/拼接 | 逐字复制 |
| `status='...' not in [...]` | 用了 `present`/`missing`/`NA` | 四枚举 |
| `synthesis.allowed=true but N field(s) not comparable` | 硬汇总 | 改 `allowed:false` |
| `is reported but has no value` | 状态与内容不一致 | 补值或改状态 |
| `field_dictionary is empty` | 没定义直接填 | 先写字典 |

## 8. 无工作稿派生（deterministic derive）

`build` 发现没有可用工作稿时执行，流程固定：

1. 读 `/input/comparison-workorder.json` → 回退 `case.json` 的
   `comparison_workorder`/`workorder`/`fields`。
2. 每字段建 canonical 定义（name/definition/unit/type/aliases）。
3. 每文档逐段逐句定位：数值+单位、染料/材料实体、任务词、预算词。
   显式原文才有 `reported`；否定表述（"no rate constant was reported"）→ `not_reported`；
   有值但单位不同 → `not_comparable`。
4. 计算六维可比性；任何 `differs` → 字段 `noncomparable`，不混池。
5. 产出 `field_dictionary` / `matrix` / `comparability` / `synthesis` / `claims`。

派生是启发式，忠实于显式原文；未显式出现的 facet 一律 `unreported`，绝不猜测。
人工细读后可用工作稿覆盖派生结果。

---
name: academic-translation-bilingual
description: 学术翻译与双语写作。单命令 build 即从 /input 材料自动派生术语表、双语对齐、数字与引用清单，每条带 locator 与逐字 quote；可选的 agent draft 用于把术语锁定预览升级为人工级译文，缺失时交付物依然完整可追溯。
version: 7.0
---

# 学术翻译与双语写作（空 work 也能完整交付）

## 用途与适用

把给定科研材料（PDF / Markdown / TXT / DOCX / CSV / JSON 等）译成中文，并交付一套**可直接进入修改流程**的双语工作稿：

- 术语表：术语随材料自动抽取、锁死同一译法（术语稳）；
- 双语对齐：句段级原文↔译文对照，数字、单位、引用原样落地（数字实、对得齐）；
- 数字清单与引用清单：每条带 `locator` 与逐字 `quote`（引用保真、边界清）；
- 三态：空输入 / 坏 case.json / 材料缺失分别标注，不伪造数据。

适用语向：英文/中文材料互相翻译；无材料或无法解析时诚实降级，不输出空壳。

## 输入输出

| 项 | 位置 |
|---|---|
| 输入 | `/input/case.json`、`/input/task.md`，以及 `/input/` 下的材料文件 |
| 工作区 | `/app/work`（agent 可选写入 `work/draft.json`） |
| 输出 | `/app/output/`：`translation.md`、`deliverable.md`、`content_map.json`、`result.json`、`compliance_checks.json`、`self_check.json`、`run.log`、`edit_record.json` |

脚本通过 `--input` / `--work` / `--output` 或环境变量 `INPUT_DIR` / `WORK_DIR` / `OUTPUT_DIR` 定位目录，默认 `/input`、`/app/work`、`/app/output`；不依赖当前工作目录。

## 调用方式

```bash
python3 scripts/main.py init
python3 scripts/main.py show                # 打印带 locator 的材料片段，先读再译
python3 scripts/main.py show --material m1  # 只看某一个材料
python3 scripts/main.py build               # 单命令完成交付
```

### 主路径：单命令 `build`，空 work 自动派生

`build` 只依赖 `/input` 材料，**不需要 agent 先填任何 draft**。它会：

1. 解析材料 → 分页 → 句段切分（每段带 `m1#p3` / `paper.pdf#p2` 等 locator）；
2. 从材料自动派生术语表（术语锁定，术语表随材料变化）；
3. 生成句段级双语对齐；未收录词的句段标注为「术语锁定预览」，不删原文、不冒充终稿；
4. 抽取数字/单位/年份与作者—年份/编号/DOI 引用，逐条带 locator 与逐字 quote；
5. 写出 `translation.md`（主交付物，含 7 个章节）与全部核验资产。

### 可选升级：agent 写 `work/draft.json`

想让译文达到人工级，agent 读材料后写 `work/draft.json`（逐句翻译），引擎逐条核对 quote 后才采用；对不上的一条会被丢弃并回退到术语锁定预览，**不会**破坏交付。

```json
{
  "case_id": "<照抄 case.json 的 case_id>",
  "claims": [
    {
      "section": "Sentence alignment",
      "claim": "奖励建模从人类偏好数据中学习一个奖励模型。",
      "quote": "Reward modeling learns a reward model from human preference data.",
      "locator": "m1#p3"
    }
  ]
}
```

规则：`quote` 必须是材料里的连续原文片段（英文 12–22 词、中文 12–60 字），逐字、不拼接、不改写；`claim` 是中文译文，不得引入材料之外的数字、机构或结论；`locator` 用 `show` 打印的值。

## 三态与异常处理

| 状态 | 触发 | status | 产物 |
|---|---|---|---|
| 空 | 无 `case.json`、无材料 | `input_error` | 合法 `result.json` + `errors`/`gaps` |
| 坏 | `case.json` 不是合法 JSON | `input_error` | 同上 |
| 缺 | `case.json` 可读但材料缺失 | `partial` | `result.json` + `gaps` |

任何异常都被捕获，退出码恒为 0；`result.json` 始终包含 `case_id`、`status`、`result`、`claims`、`coverage` 及 output_contract 的全部键。

## 自检方法

运行后检查 `output/self_check.json` 与 `output/run.log`：

- `quotes_verbatim`：逐字 quote 命中率 ≥ 0.95；
- `no_placeholders`：无占位文本；
- `draft_verified`：draft 未被丢弃；
- 本地冒烟：`python tools/smoke_generic.py --pkg <pkg> --keys case_id,status,result,claims,coverage`。

每条术语/数字/引用/句段都可经 `content_map.json` 的 `locator` + `quote` 回溯到材料。

## 限制与边界

- 无模型调用时的「术语锁定预览」是确定性术语替换，**不是**人工级整句译文；人工/模型译文请走 `work/draft.json`。
- 不擅自换算万/亿与 million/billion；数字、单位、否定范围、模糊限制语保持原样。
- 材料无法解析（如扫描版 PDF 无文本层）时按「缺」处理并如实标注，不补造科学数据。
- 每文件 ≤500KB、UTF-8 文本；脚本只用 Python 标准库，不联网。

## 最小调用示例（示例，非正式案例结果）

```bash
python3 scripts/main.py build --input /input --work /app/work --output /app/output
# 输出 translation.md 含：运行状态 / 术语表 / 双语对齐 / 数字清单 / 引用清单 / 覆盖与三态 / 说明
```

示意片段（示例，非正式案例结果）：

| # | locator | source (verbatim) | 中文 |
|---|---|---|---|
| 1 | `m1#p3` | Reward modeling learns a reward model from human preference data. | 奖励建模 从 人类偏好 数据 学习 一个 奖励模型 。 |

> 上表仅为接口示意，真实结果以 `/input` 材料实际派生为准。

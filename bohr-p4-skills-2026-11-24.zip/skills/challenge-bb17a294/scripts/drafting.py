"""Translation deliverable engine: agent-draft upgrade + deterministic fallback.

The one-command `build` must never degrade to an empty shell.  This module owns
the *translation* mode and produces, from the material alone:

  * a glossary whose entries are derived from the material and locked to one
    Chinese rendering (term consistency),
  * a sentence-level bilingual alignment (source verbatim <-> rendering),
  * a number ledger and a citation ledger, every item carrying a locator plus a
    verbatim quote,
  * explicit empty / bad / missing states.

An agent-written `work/draft.json` is optional: where a draft sentence quote is
verified verbatim it replaces the deterministic gloss; otherwise the gloss stays.
"""
import json
import re
from pathlib import Path

from seg import claim_of


# ---------------------------------------------------------------------------
# Bilingual academic lexicon.  Longest phrases are matched first so multi-word
# terms win over their single-word components.  Translations deliberately avoid
# the placeholder words the engine rejects ("示例", "占位", "待补", ...).
# ---------------------------------------------------------------------------
_FALLBACK_LEXICON = {
    "reward model": "奖励模型",
    "language model": "语言模型",
    "reinforcement learning": "强化学习",
    "human feedback": "人类反馈",
    "preference": "偏好",
    "policy": "策略",
    "objective": "目标函数",
    "optimization": "优化",
    "dataset": "数据集",
    "benchmark": "基准",
    "accuracy": "准确率",
    "performance": "性能",
}


def _load_lexicon():
    try:
        return json.loads(
            (Path(__file__).resolve().parent.parent / "references" / "glossary.json")
            .read_text(encoding="utf-8-sig"))
    except Exception:
        return dict(_FALLBACK_LEXICON)


LEXICON = _load_lexicon()


def _squeeze(s):
    return re.sub(r"\s+", " ", str(s or "")).strip()


def _jload(path):
    try:
        raw = Path(path).read_bytes()
    except Exception:
        return None
    for enc in ("utf-8-sig", "utf-8", "gb18030", "latin-1"):
        try:
            return json.loads(raw.decode(enc))
        except Exception:
            continue
    return None


def verbatim_ok(quote, hay_nospace):
    words = [w for w in re.findall(r"[A-Za-z][A-Za-z0-9\-]{2,}", quote)]
    if words:
        return sum(1 for w in words if w.lower() in hay_nospace) / float(len(words)) >= 0.9
    core = re.sub(r"\s+", "", quote).lower()
    return len(core) >= 6 and core in hay_nospace


def show_materials(mats, which=None, limit=600):
    """Step 1 for the agent: print what the material actually contains."""
    if not mats:
        return "no readable material found under the input directory"
    out = []
    for m in mats:
        if which and which not in (m["id"], m["rel"]):
            continue
        out.append("%s  (%s, %d page(s), %d chars)" % (
            m["id"], m["rel"], len(m["pages"]), len(m["text"])))
        for i, page in enumerate(m["pages"]):
            body = _squeeze(page)
            if not body:
                continue
            loc = "%s#p%d" % (m["rel"], i + 1) if m["suffix"] == ".pdf" else \
                "%s#p%d" % (m["id"], i + 1)
            out.append("  [%s] %s" % (loc, body[:limit]))
    return "\n".join(out) if out else "material id %r not found" % which


def apply_draft(work, mats, profile, blocks, claims):
    """(blocks, claims, used, rejected, draft_pairs) after merging a draft.

    `draft_pairs` is a list of (locator, verbatim_source, rendering) taken from
    verified draft claims; translation mode uses it to replace the gloss.
    """
    draft = _jload(Path(work) / "draft.json")
    if not isinstance(draft, dict) or not isinstance(draft.get("claims"), list):
        return blocks, claims, 0, 0, []
    titles = [s.get("title", "") for s in (profile.get("sections") or [])]
    hay = re.sub(r"\s+", "", " ".join(m["text"] for m in mats)).lower()
    kept, rejected, pairs = [], 0, []
    for c in draft["claims"]:
        if not isinstance(c, dict):
            rejected += 1
            continue
        q = _squeeze(c.get("quote") or c.get("claim") or "")
        if not q or not verbatim_ok(q, hay):
            rejected += 1
            continue
        loc = _squeeze(c.get("locator") or "draft#c%d" % (len(kept) + 1))
        kept.append({"section": _squeeze(c.get("section") or "") or
                     (titles[0] if titles else "Section"),
                     "claim": _squeeze(c.get("claim") or q),
                     "quote": q,
                     "locator": loc,
                     "evidence": {"type": "draft", "id": loc}})
        pairs.append((loc, q, _squeeze(c.get("claim") or q)))
    if not kept:
        return blocks, claims, 0, rejected, []
    if not titles:
        titles = [b[0] for b in blocks] or ["Section"]
    k = int(profile.get("claims_per_section", 3))
    bucket = {str(t): [] for t in titles}
    for c in kept:
        key = str(c["section"])
        sec = key if key in bucket else str(titles[0])
        bucket[sec].append((c["locator"], c["claim"]))
    for name, picked in blocks:
        if str(name) not in bucket:
            bucket[str(name)] = []
            titles.append(name)
        for loc, s in picked:
            if len(bucket[str(name)]) < k:
                bucket[str(name)].append((loc, claim_of(s)))
    out_blocks = [(t, bucket[str(t)]) for t in titles]
    engine = [c for c in claims if c.get("evidence", {}).get("type") != "draft"]
    return out_blocks, kept + engine, len(kept), rejected, pairs


# ---------------------------------------------------------------------------
# Deterministic translation fallback
# ---------------------------------------------------------------------------

def _full_lexicon(profile):
    lex = dict(LEXICON)
    for src, dst in (profile.get("glossary") or {}).items():
        lex[src] = dst
    return lex


# Function words are used by gloss_sentence for a readable preview but are not
# content terms and must not clutter the derived glossary table.
FUNCTION_STOP = {
    "the", "a", "an", "of", "in", "on", "at", "for", "and", "or", "with",
    "without", "by", "from", "to", "this", "that", "these", "those", "we",
    "our", "their", "its", "is", "are", "was", "were", "be", "has", "have",
    "had", "can", "may", "using", "used", "use", "uses", "each", "all", "some",
    "any", "no", "not", "only", "also", "then", "than", "as", "when", "while",
    "because", "therefore", "however", "moreover", "thus", "such", "both",
    "between", "among", "into", "over", "after", "before", "during", "per",
    "via", "including", "e.g.", "i.e.", "versus", "vs.",
}


def gloss_sentence(s, lex):
    """Longest-first, case-insensitive phrase replacement; numbers and citations
    are not in the lexicon and therefore pass through verbatim."""
    out = s
    for src in sorted(lex, key=len, reverse=True):
        if not src:
            continue
        pat = re.compile(r"(?<![A-Za-z0-9])" + re.escape(src) + r"(?![A-Za-z0-9])",
                         re.I)
        out = pat.sub(lex[src], out)
    return re.sub(r"\s{2,}", " ", out).strip()


def _term_re(term):
    return re.compile(r"(?<![A-Za-z0-9])" + re.escape(term) + r"(?![A-Za-z0-9])", re.I)


def _term_present(term, text):
    return _term_re(term).search(text) is not None


def _find_unit(units, needle):
    pat = _term_re(needle)
    for loc, s in units:
        if pat.search(s):
            return loc, s
    return None, None


def extract_numbers(units):
    unit_suffix = (r"(?:nm|μm|µm|µM|uM|μM|mM|kg|mg|μg|ug|mL|L|ms|Hz|kHz|MHz|"
                   r"eV|keV|MeV|GeV|K|°C|km|cm|mm|bp|Da|kDa|mol|min|h|s|×|x)")
    num_re = re.compile(
        r"(?<!\w)(?:"
        r"(?:19|20)\d{2}"
        r"|p\s*[<>=≤≥]\s*0?\.\d+"
        r"|n\s*=\s*\d[\d,]*"
        r"|\d+(?:\.\d+)?\s*[eE][+-]?\d+"
        r"|\d[\d,]*(?:\.\d+)?\s*%"
        r"|\d[\d,]*(?:\.\d+)?\s*(?:" + unit_suffix + r")"
        r"|\d[\d,]*(?:\.\d+)?\s*[–-]\s*\d[\d,]*(?:\.\d+)?"
        r"|\d[\d,]*(?:\.\d+)?"
        r")(?!\w)")
    out, seen = [], set()
    for loc, s in units:
        for m in num_re.finditer(s):
            val = _squeeze(m.group(0))
            key = (val, loc)
            if key in seen:
                continue
            seen.add(key)
            out.append({"value": val, "locator": loc, "quote": s})
    return out


def extract_citations(units):
    patterns = [
        re.compile(r"\[\d+(?:[,\-–\s]*\d+)*\]"),
        re.compile(r"\((?:[A-Z][A-Za-z'&.\-]+,?\s+)+(?:19|20)\d{2}[a-z]?"
                   r"(?:\s*;\s*(?:[A-Z][A-Za-z'&.\-]+,?\s+)*(?:19|20)\d{2}[a-z]?)*\)"),
        re.compile(r"\b[A-Z][A-Za-z'\-]+(?:\s+et\s+al\.?)?,?\s*\((?:19|20)\d{2}[a-z]?\)"),
        re.compile(r"\b(?:doi|DOI)\s*:?\s*10\.\d{4,9}/[^\s,;)]+"),
        re.compile(r"\barXiv\s*:\s*\d{4}\.\d{4,5}(?:v\d+)?", re.I),
    ]
    out, seen = [], set()
    for loc, s in units:
        for pat in patterns:
            for m in pat.finditer(s):
                val = _squeeze(m.group(0))
                key = (val, loc)
                if key in seen:
                    continue
                seen.add(key)
                out.append({"value": val, "locator": loc, "quote": s})
    return out


def build_translation(profile, units, mats, case):
    """Derive glossary, numbers, citations and base bilingual pairs from units."""
    lex = _full_lexicon(profile)
    maxn = int(profile.get("max_sentences", 60))
    sel = units[:maxn] if len(units) > maxn else units

    # --- glossary derived from the material (term consistency)
    hay = " ".join(s for _, s in sel)
    rows, seen = [], set()
    for src in sorted(lex, key=len, reverse=True):
        sl = src.lower()
        if not src or sl in seen or sl in FUNCTION_STOP:
            continue
        if not _term_present(src, hay):
            continue
        loc, quote = _find_unit(sel, src)
        if loc is None:
            continue
        rows.append({"source": src, "target": lex[src], "locator": loc,
                     "quote": quote, "status": "locked"})
        seen.add(sl)

    numbers = extract_numbers(sel)
    citations = extract_citations(sel)

    pairs = []
    for loc, s in sel:
        pairs.append({"locator": loc, "source": s,
                      "zh": gloss_sentence(s, lex), "evidence": "gloss"})

    blocks = [("Sentence alignment", [(p["locator"], p["source"]) for p in pairs])]
    state = {"glossary": rows, "numbers": numbers, "citations": citations,
             "pairs": pairs, "lexicon": lex}
    return blocks, state


def merge_draft(state, draft_pairs):
    """Replace the gloss rendering with a verified agent translation, by source."""
    if not draft_pairs:
        return
    dmap = {}
    for _loc, quote, zh in draft_pairs:
        dmap[re.sub(r"\s+", "", quote).lower()] = zh
    for p in state["pairs"]:
        key = re.sub(r"\s+", "", p["source"]).lower()
        if key in dmap:
            p["zh"] = dmap[key]
            p["evidence"] = "draft"


def translation_claims(state):
    claims = []
    for p in state["pairs"]:
        claims.append({"section": "Sentence alignment", "claim": p["zh"],
                       "quote": p["source"], "locator": p["locator"],
                       "evidence": {"type": "alignment", "id": p["locator"]}})
    for r in state["glossary"]:
        claims.append({"section": "Glossary",
                       "claim": "%s → %s" % (r["source"], r["target"]),
                       "quote": r["quote"], "locator": r["locator"],
                       "evidence": {"type": "glossary", "id": r["locator"]}})
    for n in state["numbers"]:
        claims.append({"section": "Numbers", "claim": n["value"],
                       "quote": n["quote"], "locator": n["locator"],
                       "evidence": {"type": "number", "id": n["locator"]}})
    for c in state["citations"]:
        claims.append({"section": "Citations", "claim": c["value"],
                       "quote": c["quote"], "locator": c["locator"],
                       "evidence": {"type": "citation", "id": c["locator"]}})
    return claims


def _esc(s):
    return str(s or "").replace("|", "/").replace("\n", " ").replace("\r", " ")


def render_translation(profile, state, status, gaps, errors):
    """Render the full bilingual deliverable with provenance and three-state notes."""
    title = profile.get("title") or "学术文献翻译（双语对齐）"
    target = profile.get("target_language") or "中文"
    n_pairs = len(state["pairs"])
    n_gloss = len(state["glossary"])
    n_num = len(state["numbers"])
    n_cit = len(state["citations"])
    n_draft = sum(1 for p in state["pairs"] if p["evidence"] == "draft")

    L = ["# %s" % title, "",
         "## 运行状态 (Status)", "",
         "- status: `%s`" % status,
         "- 双语对齐句段: %d（其中 agent 译文 %d、术语锁定预览 %d）"
         % (n_pairs, n_draft, n_pairs - n_draft),
         "- 术语表: %d 条；数字清单: %d 条；引用清单: %d 条" % (n_gloss, n_num, n_cit),
         ""]
    if gaps:
        L += ["- 缺口 (gaps): %s" % "；".join(gaps), ""]
    if errors:
        L += ["- 错误 (errors): %s" % "；".join(errors), ""]

    L += ["## 术语表 (Glossary)", "",
          "同一术语在全文锁定同一译法；每条带 locator 与逐字引文。", "",
          "| # | 源术语 | 中文译法 | locator | 逐字引文 (verbatim) |", "|---|---|---|---|---|"]
    for i, r in enumerate(state["glossary"], 1):
        L.append("| %d | %s | %s | `%s` | %s |" % (
            i, _esc(r["source"]), _esc(r["target"]), _esc(r["locator"]),
            _esc(r["quote"])))
    if not state["glossary"]:
        L.append("| - | (no terms found in the material) | - | - | - |")
    L += [""]

    L += ["## 双语对齐 (Sentence alignment)", "",
          "逐句段对照：`source` 为逐字原文，`%s` 为目标语言渲染。数字、单位、引用保持原样。"
          % target, "",
          "| # | locator | source (verbatim) | %s |" % target,
          "|---|---|---|---|"]
    for i, p in enumerate(state["pairs"], 1):
        tag = "" if p["evidence"] == "draft" else "（术语锁定预览）"
        L.append("| %d | `%s` | %s | %s%s |" % (
            i, _esc(p["locator"]), _esc(p["source"]), _esc(p["zh"]),
            tag if p["evidence"] != "draft" else ""))
    if not state["pairs"]:
        L.append("| - | - | - | - |")
    L += [""]

    L += ["## 数字清单 (Numbers)", "",
          "数字、单位、量级、范围、年份原样落地，不四舍五入、不改口径。", "",
          "| # | 数字/单位 | locator | 逐字引文 (verbatim) |", "|---|---|---|---|"]
    for i, n in enumerate(state["numbers"], 1):
        L.append("| %d | %s | `%s` | %s |" % (
            i, _esc(n["value"]), _esc(n["locator"]), _esc(n["quote"])))
    if not state["numbers"]:
        L.append("| - | (no numbers detected) | - | - |")
    L += [""]

    L += ["## 引用清单 (Citations)", "",
          "作者—年份、编号引用、DOI/arXiv 保持原样，归属不被改写。", "",
          "| # | 引用 | locator | 逐字引文 (verbatim) |", "|---|---|---|---|"]
    for i, c in enumerate(state["citations"], 1):
        L.append("| %d | %s | `%s` | %s |" % (
            i, _esc(c["value"]), _esc(c["locator"]), _esc(c["quote"])))
    if not state["citations"]:
        L.append("| - | (no citations detected) | - | - |")
    L += [""]

    L += ["## 材料覆盖与三态 (Coverage & three states)", "",
          "- 空 (empty): 输入目录无 case.json、无材料 → `input_error`，记录 errors/gaps。",
          "- 坏 (bad): case.json 不是合法 JSON → `input_error`，记录 errors/gaps。",
          "- 缺 (missing): case.json 可读但材料缺失 → `partial`，记录 gaps。",
          "- 覆盖说明: 本交付物由 `/input` 材料自动派生；agent 可写 `work/draft.json` 提升译文，"
          "但缺失 draft 时交付物依然完整、可逐条追溯。", ""]

    L += ["## 说明 (Notes)", "",
          "- 术语锁定：每个术语只出现一种中文译法，术语表随材料自动派生。",
          "- 数字保真：数字与单位按原文保留，不做万/亿与 million/billion 的私自换算。",
          "- 引用保真：作者—年份与编号引用不增不删。",
          "- 语义边界：未收录词的句段标记为“术语锁定预览”，不冒充人工终稿，也不删原文。",
          "- 每条术语/数字/引用/句段均可通过 locator + 逐字 quote 回溯到材料。", ""]
    return "\n".join(L)


def emit_init(out, profile, case, case_id, mats, units, gaps, errors):
    """Save an honest partial result.json immediately (early-partial contract).

    `init` is the index step: it records what was found without pretending the
    translation is done, so a budget-limited run still leaves a legal result.
    """
    mode = profile.get("mode", "doc")
    status = "input_error" if (not isinstance(case, dict) or not mats) else "partial"
    if not isinstance(case, dict):
        state = "empty" if not mats else "bad"
    elif not mats:
        state = "missing"
    else:
        state = "indexed"
    base = {
        "case_id": case_id, "status": status, "state": state,
        "result": {"deliverable": "translation.md" if mode == "translation" else "deliverable.md",
                   "mode": mode, "path": "init", "sections": 0, "claims": 0,
                   "quote_hit_rate": 0.0},
        "claims": [],
        "coverage": {"materials": len(mats), "units": len(units), "claims": 0,
                     "sections": 0, "sections_with_evidence": 0,
                     "quote_hit_rate": 0.0,
                     "chars": sum(len(m["text"]) for m in mats)},
        "content_map": [],
        "gaps": list(gaps), "degradations": list(gaps), "errors": list(errors),
        "sources": [m["rel"] for m in mats],
    }
    contract = (case or {}).get("output_contract") if isinstance(case, dict) else None
    if isinstance(contract, dict):
        for k2, v2 in contract.items():
            base.setdefault(k2, v2)
    elif isinstance(contract, list):
        for k2 in contract:
            base.setdefault(k2, "" if k2 not in ("claims", "content_map") else [])
    for k2 in ("case_id", "status", "result", "claims", "coverage"):
        base.setdefault(k2, "" if k2 != "claims" else [])
    base["case_id"] = case_id
    out_dir = Path(out)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "result.json").write_text(
        json.dumps(base, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({"ok": True, "command": "init", "status": status,
                      "case_id": case_id, "mode": mode,
                      "materials": len(mats), "units": len(units)},
                     ensure_ascii=False, indent=2, sort_keys=True))
    return 0

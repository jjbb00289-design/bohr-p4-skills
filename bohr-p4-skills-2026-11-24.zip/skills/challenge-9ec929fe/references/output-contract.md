# 输出契约与证据规范

## result.json 结构
`main.py` 读取 `case.json`，将 `output_contract`（dict 的键或 list 的元素）逐一回填为 `result.json` 的顶层键，并附加 `case_id`、`status`、`summary`、`sources`、`uncertainty`、`change_records`、`errors`、`degradations`、`gaps`、`artifacts`。不改名、不漏键；无法产出的字段填 `null`（列表场景填 `[]`）并在 `gaps` 说明。

## 契约字段 → 计算结果的映射（按小写字段名关键字）
| 字段含 | 映射到 |
|-|-|
| clean / data | `{"file":"cleaned_data.csv","rows":N,"columns":[...]}` |
| dict / schema / 字段 / 字典 | `data_dictionary.json` 的 columns |
| group / class / compar / 分组 | `group_statistics.json` |
| corr / 相关 | `correlation_matrix.json` |
| desc / stat / summar / 统计 / 描述 | `descriptive_statistics.json` |
| plot / chart / fig / visual / image / 图 | `plots` 文件名数组 |
| quality / report / qc / 质量 / 报告 | `quality_report.json` |
| code / script / pipeline / log / rule / 清洗 | `pipeline.json` 的 cleaning 段 |
| model / predict / regress / classif / query / sql / 模型 | `model_report.json`（本版不产出模型，填 `null` + gap） |

## 证据规范（真实派生）
- 每个统计数字来自 `source_table`（材料文件名 + 表名）的对应列；`descriptive_statistics.json` 等结果文件与 `result.json` 内联值同源同值。
- `sources` 每条含 `source`（文件名）、`locator`（表/列/文件头）、`quote`（可命中原文：数据表为列名逐字串，材料文件为文件头 256 字节）。
- 清洗动作写入 `pipeline.json` 的 `issues`/`changes`/`rules`，与 `result.json.change_records` 一致。

## 统计口径（写入 quality_report.md 与 pipeline.json）
缺失值按列 listwise 删除（绝不当作 0）；异常值 Tukey IQR 1.5 倍 fences 仅标记；重复行默认报告并保留；标准差为样本（n-1）；分位数 inclusive；p 值用 t→z 变换 + 正态 CDF（df≥30 准确）。

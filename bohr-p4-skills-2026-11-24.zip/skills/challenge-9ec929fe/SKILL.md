---
name: scientific-data-analysis
description: >-
  Deterministic, verifiable scientific-data analysis pipeline. Loads tabular
  data (CSV/TSV/SQLite/JSON/XLSX), parses data dictionaries, cleans data in
  five categories (missing values, outliers, duplicates, format/unit/encoding,
  quality report), computes descriptive/group/correlation statistics, fits a
  baseline regression or classifier, and renders editable SVG plots. Emits
  result.json mirroring every output_contract field plus case_id, status,
  sources, uncertainty and change records. Pure Python standard library, no
  network, no CWD dependence.
version: 1.0.0
---

# 科研数据分析 Skill

## 用途
在给定科研数据上完成“清洗 → 统计 → 可视化 → 模型/查询 → 质量报告 → 可复核证据”的完整链路，产出可被他人复算的结果。重点防止“跑通了但算错了”的静默错误：缺失值绝不当作 0，重复记录先报告再决定，分组统计前先说明去重口径，t 检验前先报告前提条件，图表轴/单位/图例与原始列一致。

## 触发条件
- 输入包含 `case.json` 与科研数据材料（CSV/TSV/SQLite/JSON/XLSX/`.names` 数据字典）。
- 任务要求对数据做清洗、描述统计、分组比较、相关分析、回归或分类基线、可视化或数据库查询。
- 需要一份能被他人独立重跑、能逐项指回来源的结构化结果。

## 调用方式
运行时默认入口（单命令即完整流程，无工作稿也会从 `/input` 真实派生全部交付）：

```bash
python3 /skills/weekly-skill/scripts/main.py
```

子命令：
- `init`：在 `$WORK_DIR/worksheet.json` 生成工作稿模板（供 Agent 补充人工判读，可缺省）。
- `show`：打印当前 work/output 状态与 result.json 摘要。
- `check`：对照 `case.json` 的 `output_contract` 校验 `result.json` 是否缺键，恒退出码 0。
- `build`：等价于默认完整流程。

路径优先级：命令行 `--input/--work/--output` > 环境变量 `INPUT_DIR/WORK_DIR/OUTPUT_DIR` > 平台默认 `/input`、`/app/work`、`/app/output`。脚本不依赖 CWD（以 `Path(__file__).resolve().parent` 定位）。

## 输入
- `/input/case.json`：含 `case_id`、`task_instruction`、`output_contract`（可能还含 `task_id`/`id`）。
- `/input/task.md`：任务说明与字段约定。
- `/input/` 下数据材料：CSV/TSV、SQLite(`.db/.sqlite/.sqlite3`)、JSON、XLSX、`.names` 数据字典、Markdown 字典。
- `/app/work/worksheet.json`（可选，Agent 可写）：人工判读覆盖，见下 schema。

## 输出（写入 `/app/output`）
- `result.json`（必需）：回填 `output_contract` 的每个字段 + `case_id`；含 `status`、`sources`、`uncertainty`、`change_records`、`errors`、`degradations`、`gaps`、`artifacts`。
- `cleaned_data.csv`：清洗后数据；`data_dictionary.json`：字段解析结果；`descriptive_statistics.json`；`group_statistics.json`（有分类目标时）；`correlation_matrix.json`；`model_report.json`（有目标变量时）；`quality_report.md`；`pipeline.json`（规则/日志/变更记录）；`plots/*.svg`（可编辑矢量图，非截图）。

## 工作稿 schema（`/app/work/worksheet.json`，全部可省略）
```json
{
  "data_dictionary": [{"name":"sepal length","type":"numeric","unit":"cm","role":"feature","missing":["NA"]}],
  "target_column": "species",
  "categorical_columns": ["species"],
  "task_type": "classification|regression|summary",
  "drop_duplicates": false,
  "notes": "人工判读备注"
}
```
未提供时，脚本自动探测：从 SQLite schema、CSV 表头或 `.names` 字典推断字段名/类型/单位/角色；`task_type` 由目标列类型决定。

## 证据规范（真实派生红线）
- 每个统计数值、每个结论、每个图表、每个清理动作都能指回 `source` + `locator` + 逐字 `quote`。
- 数据型结论：`source`=材料文件名，`locator`=表/列/行号，`quote`=原文单元格或原文行（可在材料中命中）。
- 文档型结论：`quote` 必须逐字命中 PDF/文档原文；无法命中即不写该结论，写入 `gaps`。
- 禁止 placeholder / scaffold / 空契约键；无法产出的字段用 `null`/`[]` 并在 `gaps` 说明原因，不伪造。

## 降级表
| 情况 | status | result.json | 退出码 |
|---|---|---|---|
| 全部材料齐、流程跑通 | `complete` | 契约字段填实值 | 0 |
| 部分材料缺失/部分步骤失败 | `partial` | 已得字段填实值，缺字段 `null`，`gaps` 说明 | 0 |
| 材料不足以支撑任何结论 | `insufficient_evidence` | 契约字段 `null`，`gaps` 说明 | 0 |
| `case.json` 缺失/坏 JSON/空输入 | `input_error` | 契约字段 `null`，`errors` 说明 | 0 |
| 缺列/类型错/空表/坏 CSV/权限不足 | `partial` | 相关字段 `null`，`errors`+`gaps` 说明 | 0 |

所有异常被捕获写入 `errors`/`degradations`，先写 partial 再增量 finalize，退出码恒 0。

## 自检
- `result.json` 键含 `case_id` + 每个 `output_contract` 字段，无改名/漏键；缺值用 `null`/`[]`。
- 每个数字与 `descriptive_statistics.json` 等结果文件一致；统计口径（样本/总体、listwise 缺失删除、去重前后）在 `quality_report.md` 与 `pipeline.json` 中显式声明。
- 图表为可编辑 SVG；数值轴与单位来自数据字典。
- 两次全新输出目录重跑产物结构一致（无时间戳/随机性；固定种子 42）。

## 限制
- 纯标准库；不安装第三方包；不联网。PDF 文本抽取由调用方（Agent 的 PDF 工具）完成，脚本只处理表格/数据库/JSON/文本材料。
- t 检验/相关 p 值用 t→z 变换 + 正态 CDF 数值近似（df≥30 时准确），非正态样本仍报告 skewness/kurtosis 与样本量作为前提说明。
- 单位换算只在数据字典显式给出换算关系时执行，否则原样保留并标注单位。

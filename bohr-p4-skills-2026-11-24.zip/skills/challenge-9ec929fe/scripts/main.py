"""Entry point: deterministic scientific-data analysis skill. Always exit 0."""
import argparse
import csv
import json
import math
import os
import re
import statistics as st
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import analysis  # noqa: E402

DEFAULT_INPUT = "/input"
DEFAULT_WORK = "/app/work"
DEFAULT_OUTPUT = "/app/output"


def _svg(w, h, b):
    return '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" font-family="sans-serif">%s</svg>' % (w, h, b)


def _slug(x):
    return re.sub(r"[^A-Za-z0-9_]+", "_", x).strip("_")


def _wjson(out, name, obj):
    with open(os.path.join(out, name), "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, sort_keys=True)


def hist_svg(vals, name, unit):
    v = [x for x in vals if x is not None]
    if not v:
        return None
    nb = max(4, min(20, int(1 + 3.322 * math.log10(len(v)))))
    lo, hi = min(v), max(v)
    if hi == lo:
        hi = lo + 1
    bw = (hi - lo) / nb
    c = [0] * nb
    for x in v:
        c[min(nb - 1, int((x - lo) / bw))] += 1
    W, H, ml, mb = 520, 260, 56, 40
    b = []
    for i, cnt in enumerate(c):
        x = ml + i * (W - ml - 10) / nb
        bh = cnt / max(c) * (H - mb - 10)
        b.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="#4C78A8"/>'
                 % (x, H - mb - bh, (W - ml - 10) / nb - 1, bh))
    b.append('<text x="%d" y="%d" font-size="12" text-anchor="middle">%s%s</text>'
             % (W / 2, H - 4, name, (" (%s)" % unit) if unit else ""))
    return _svg(W, H, "".join(b))


def box_svg(series, name, unit):
    series = [(g, [x for x in vs if x is not None]) for g, vs in series if vs]
    if not series:
        return None
    allv = [x for _, vs in series for x in vs]
    lo, hi = min(allv), max(allv)
    if hi == lo:
        hi = lo + 1
    W, H, ml, mb = 520, 280, 56, 40
    n = len(series)
    b = []

    def ym(v):
        return H - mb - (v - lo) / (hi - lo) * (H - mb - 10)
    for k, (g, vs) in enumerate(series):
        s = sorted(vs)
        q = st.quantiles(s, n=4, method="inclusive") if len(s) >= 4 else [min(s), st.median(s), max(s)]
        x = ml + (k + 0.5) * (W - ml - 10) / n
        b.append('<rect x="%.1f" y="%.1f" width="30" height="%.1f" fill="none" stroke="#2c3e50"/>'
                 % (x - 15, ym(q[2]), ym(q[0]) - ym(q[2])))
        b.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#2c3e50" stroke-width="2"/>'
                 % (x - 15, ym(q[1]), x + 15, ym(q[1])))
        b.append('<text x="%.1f" y="%d" font-size="9" text-anchor="middle">%s</text>' % (x, H - mb + 12, g[:14]))
    b.append('<text x="%d" y="%d" font-size="12" text-anchor="middle">%s%s</text>'
             % (W / 2, H - 4, name, (" (%s)" % unit) if unit else ""))
    return _svg(W, H, "".join(b))


def render_qmd(q):
    L = ["# 数据质量报告", "", "来源：`%s`；行 %d；列 %d；重复行 %d；缺失合计 %d。" %
         (q["source"], q["n_rows"], q["n_columns"], q["duplicate_rows"], q["missing_total"]), ""]
    L.append("字段 | 类型 | 单位 | n | 缺失 | 唯一")
    L.append("---|---|---|---|---|---")
    for c in q["per_column"]:
        L.append("%s | %s | %s | %s | %s | %s" % (c["name"], c["type"], c.get("unit") or "-",
                 c.get("n"), c.get("missing"), c.get("unique")))
    L.append("")
    L.append("问题清单：" + ("; ".join("[%s] %s" % (it.get("category"), json.dumps(it, ensure_ascii=False))
                                     for it in q["issues"]) or "无"))
    L.append("口径：缺失按列 listwise 删除（不当作 0）；异常值 Tukey IQR 1.5 仅标记；重复默认保留；标准差为样本(n-1)。")
    return "\n".join(L) + "\n"


def write_artifacts(out, rep):
    if rep.get("status") in ("insufficient_evidence",):
        return
    os.makedirs(os.path.join(out, "plots"), exist_ok=True)
    _wjson(out, "data_dictionary.json", {"source": rep.get("source_table"), "columns": rep.get("dictionary", [])})
    _wjson(out, "descriptive_statistics.json", rep.get("descriptive") or {})
    _wjson(out, "correlation_matrix.json", rep.get("correlation") or {})
    if rep.get("groups"):
        _wjson(out, "group_statistics.json", rep["groups"])
    with open(os.path.join(out, "cleaned_data.csv"), "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f)
        wr.writerow([c["name"] for c in rep.get("dictionary", [])])
        for r in rep.get("cleaned_rows", []):
            wr.writerow(r)
    _wjson(out, "pipeline.json", {"source": rep.get("source_table"),
                                  "cleaning": rep.get("cleaning", {}), "n_rows": rep.get("n_rows"),
                                  "n_columns": rep.get("n_columns"),
                                  "detected_format": rep.get("detected_format", {})})
    plots = []
    for name, unit, vals in rep.get("hist_data", []):
        svg = hist_svg(vals, name, unit)
        if svg:
            fn = "plots/hist_%s.svg" % _slug(name)
            open(os.path.join(out, fn), "w", encoding="utf-8").write(svg)
            plots.append(fn)
    for feat, unit, series in rep.get("box_data", []):
        svg = box_svg(series, feat, unit)
        if svg:
            fn = "plots/box_%s.svg" % _slug(feat)
            open(os.path.join(out, fn), "w", encoding="utf-8").write(svg)
            plots.append(fn)
    _wjson(out, "quality_report.json", rep.get("quality") or {})
    if rep.get("quality"):
        open(os.path.join(out, "quality_report.md"), "w", encoding="utf-8").write(render_qmd(rep["quality"]))
    rep["plots"] = plots


def resolve_dirs(args):
    inp = args.input_dir or os.environ.get("INPUT_DIR") or DEFAULT_INPUT
    work = args.work_dir or os.environ.get("WORK_DIR") or DEFAULT_WORK
    out = args.output_dir or os.environ.get("OUTPUT_DIR") or DEFAULT_OUTPUT
    return inp, work, out


def read_case(inp):
    p = os.path.join(inp, "case.json")
    if not os.path.isfile(p):
        return None, "case.json missing in %s" % inp
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f), None
    except Exception as e:
        return None, "case.json unreadable: %s" % e


def extract_case_id(case):
    if not isinstance(case, dict):
        return None
    for k in ("case_id", "caseId", "id", "task_id", "taskId"):
        if k in case and case[k] not in (None, ""):
            return str(case[k])
    return None


def extract_contract(case):
    if not isinstance(case, dict):
        return []
    for k in ("output_contract", "outputContract", "output_schema", "result_contract", "contract"):
        if k not in case:
            continue
        v = case[k]
        if isinstance(v, dict):
            return list(v.keys())
        if isinstance(v, list):
            return [str(x) for x in v if isinstance(x, str)]
        if isinstance(v, str) and v.strip():
            return [v.strip()]
    return []


def fill_contract(field, report):
    k = field.lower()

    def has(*subs):
        return any(s in k for s in subs)

    if has("clean") or has("data"):
        if report.get("n_rows") is None:
            return None
        return {"file": "cleaned_data.csv", "rows": report.get("n_rows"),
                "columns": report.get("columns")}
    if has("dict") or has("schema") or has("字段") or has("字典"):
        return report.get("dictionary")
    if has("group") or has("class") or has("compar") or has("分组"):
        return report.get("groups")
    if has("corr") or has("相关"):
        return report.get("correlation")
    if has("desc") or has("stat") or has("summar") or has("统计") or has("描述"):
        return report.get("descriptive")
    if has("plot") or has("chart") or has("fig") or has("visual") or has("image") or has("图"):
        return report.get("plots")
    if has("quality") or has("report") or has("qc") or has("质量") or has("报告"):
        return report.get("quality")
    if has("code") or has("script") or has("pipeline") or has("log") or has("rule") or has("清洗"):
        return report.get("cleaning")
    if has("model") or has("predict") or has("regress") or has("classif") or \
       has("查询") or has("query") or has("sql") or has("模型"):
        return report.get("model")
    return None


def build_uncertainty(report):
    q = report.get("quality", {}) or {}
    return {
        "missing_values_total": q.get("missing_total", 0),
        "duplicate_rows": q.get("duplicate_rows", 0),
        "statistical_convention": "sample std (n-1); listwise deletion; never treat missing as 0",
        "test_assumptions": "Welch t-test (no equal-variance assumption); skewness/kurtosis reported per column",
        "p_value_approximation": "t->z transform + normal CDF (accurate for df>=30)",
        "random_seed": 42,
        "limitations": report.get("warnings", []),
    }


def build_artifacts(out):
    names = ["result.json", "cleaned_data.csv", "data_dictionary.json",
             "descriptive_statistics.json", "correlation_matrix.json",
             "pipeline.json", "quality_report.md", "quality_report.json"]
    names += ["group_statistics.json", "model_report.json"]
    found = [n for n in names if os.path.isfile(os.path.join(out, n))]
    pdir = os.path.join(out, "plots")
    if os.path.isdir(pdir):
        found += ["plots/" + n for n in sorted(os.listdir(pdir))]
    return found


def build_summary(report):
    if report.get("status") == "insufficient_evidence":
        return "Insufficient evidence: " + report.get("reason", "no loadable material")
    parts = ["source=%s" % report.get("source_table"),
             "rows=%s" % report.get("n_rows"),
             "columns=%s" % report.get("n_columns")]
    m = report.get("model")
    if m:
        parts.append("model=%s" % m.get("task"))
        if "r2_test" in m:
            parts.append("r2_test=%s" % m["r2_test"])
        if "accuracy_test" in m:
            parts.append("accuracy_test=%s" % m["accuracy_test"])
    return "; ".join(parts)


def assemble_result(case, report, status, errors, degradations, gaps):
    contract = extract_contract(case)
    result = {"case_id": extract_case_id(case)}
    for f in contract:
        result[f] = fill_contract(f, report)
    result["status"] = status
    result["summary"] = build_summary(report)
    result["sources"] = report.get("sources", [])
    result["uncertainty"] = build_uncertainty(report)
    result["change_records"] = report.get("cleaning", {}).get("changes", [])
    result["errors"] = errors
    result["degradations"] = degradations + [d for d in report.get("degradations", []) if d not in degradations]
    result["gaps"] = gaps
    result["artifacts"] = []
    return result


def write_result(out, result):
    os.makedirs(out, exist_ok=True)
    p = os.path.join(out, "result.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2, sort_keys=True)
    return p


def empty_report(errors):
    return {"status": "input_error", "n_rows": None, "n_columns": None,
            "columns": [], "dictionary": [], "descriptive": None, "correlation": None,
            "groups": None, "model": None, "quality": None, "cleaning": {},
            "plots": [], "sources": [], "degradations": [], "warnings": [],
            "errors": errors}


def run_full(inp, work, out):
    errors, degradations, gaps = [], [], []
    os.makedirs(work, exist_ok=True)
    os.makedirs(out, exist_ok=True)
    case, case_err = read_case(inp)
    if case_err:
        errors.append(case_err)
        rep = empty_report(errors)
        result = assemble_result(case or {}, rep, "input_error", errors, degradations, gaps)
        result["artifacts"] = build_artifacts(out)
        write_result(out, result)
        return result
    # partial result.json early (never 0-byte on later failure)
    rep0 = empty_report([])
    partial = assemble_result(case, rep0, "partial", [], [], ["in progress"])
    write_result(out, partial)
    try:
        rep = analysis.run(inp, work, out)
        write_artifacts(out, rep)
    except Exception as e:
        errors.append("pipeline failed: %s" % e)
        errors.append(traceback.format_exc())
        rep = empty_report(errors)
    if rep.get("status") == "insufficient_evidence":
        status = "insufficient_evidence"
        gaps.append(rep.get("reason", "no loadable material"))
    elif errors:
        status = "partial"
    elif rep.get("degradations"):
        status = "partial"
    else:
        status = "complete"
    result = assemble_result(case, rep, status, errors, degradations, gaps)
    result["artifacts"] = build_artifacts(out)
    write_result(out, result)
    return result


def cmd_init(work):
    os.makedirs(work, exist_ok=True)
    p = os.path.join(work, "worksheet.json")
    if not os.path.isfile(p):
        tmpl = {"data_dictionary": [], "target_column": None,
                "categorical_columns": [], "task_type": None,
                "drop_duplicates": False, "notes": ""}
        with open(p, "w", encoding="utf-8") as f:
            json.dump(tmpl, f, ensure_ascii=False, indent=2)
    print(p)


def cmd_show(inp, work, out):
    print("input=%s work=%s output=%s" % (inp, work, out))
    case, err = read_case(inp)
    print("case_id=%s contract=%s" % (extract_case_id(case or {}), extract_contract(case or {})))
    rp = os.path.join(out, "result.json")
    if os.path.isfile(rp):
        d = json.load(open(rp, encoding="utf-8"))
        print("result status=%s" % d.get("status"))
        for f in extract_contract(case or {}):
            print("  contract[%s]=%s" % (f, "null" if d.get(f) is None else "filled"))
    else:
        print("result: not found")


def cmd_check(inp, out):
    case, err = read_case(inp)
    rp = os.path.join(out, "result.json")
    if not os.path.isfile(rp):
        print("FAIL result.json missing")
        return 0
    d = json.load(open(rp, encoding="utf-8"))
    missing = []
    for f in extract_contract(case or {}):
        if f not in d:
            missing.append(f)
    if "case_id" not in d:
        missing.append("case_id")
    if "status" not in d:
        missing.append("status")
    if missing:
        print("MISSING_KEYS " + ",".join(missing))
    else:
        print("OK all contract keys present")
    return 0


def main():
    p = argparse.ArgumentParser(prog="scientific-data-analysis",
                                description="Deterministic scientific-data analysis skill.")
    p.add_argument("command", nargs="?", default="run",
                   choices=["run", "build", "init", "show", "check"])
    p.add_argument("--input", dest="input_dir")
    p.add_argument("--work", dest="work_dir")
    p.add_argument("--output", dest="output_dir")
    args = p.parse_args()
    inp, work, out = resolve_dirs(args)
    cmd = "run" if args.command == "build" else args.command
    try:
        if cmd == "init":
            cmd_init(work)
        elif cmd == "show":
            cmd_show(inp, work, out)
        elif cmd == "check":
            cmd_check(inp, out)
        else:
            run_full(inp, work, out)
    except SystemExit:
        raise
    except Exception as e:
        # last-resort: write an input_error result and never crash
        try:
            os.makedirs(out, exist_ok=True)
            with open(os.path.join(out, "result.json"), "w", encoding="utf-8") as f:
                json.dump({"case_id": None, "status": "input_error",
                           "errors": ["unhandled: %s" % e, traceback.format_exc()],
                           "sources": [], "uncertainty": {}, "change_records": [],
                           "degradations": [], "gaps": ["unhandled exception"]},
                          f, ensure_ascii=False, indent=2)
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())

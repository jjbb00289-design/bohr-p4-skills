import csv
import io
import json
import math
import os
import re
import sqlite3
import statistics as st

MISSING = {"", "?", "na", "n/a", "nan", "null", "none", "-", "n.a.", "n.d.", "nd",
           "missing", ".", "N/A", "NA", "NaN", "NULL"}


def _erf(x):
    s = 1.0 if x >= 0 else -1.0
    x = abs(x)
    t = 1.0 / (1.0 + 0.3275911 * x)
    y = 1.0 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t
                - 0.284496736) * t + 0.254829592) * t * math.exp(-x * x)
    return s * y


def tpv(t, df):
    # two-sided p via t->z transform + normal CDF (accurate for df>=30)
    if df <= 0:
        return float("nan")
    z = abs(t) * (1.0 - 1.0 / (4.0 * df)) / math.sqrt(1.0 + t * t / (2.0 * df))
    return 2.0 * (1.0 - 0.5 * (1.0 + _erf(z / math.sqrt(2.0))))


def _num(s):
    if s is None:
        return None
    if isinstance(s, (int, float)):
        return s
    t = str(s).strip()
    if t in MISSING:
        return None
    for f in (int, float):
        try:
            return f(t)
        except ValueError:
            pass
    try:
        return float(t.replace(",", ""))
    except ValueError:
        return None


def _mis(s):
    return s is None or (isinstance(s, str) and s.strip() in MISSING)


def _r(x, nd=6):
    if x is None:
        return None
    if isinstance(x, float):
        return None if math.isnan(x) or math.isinf(x) else round(x, nd)
    return x


def _mom(v):
    n = len(v)
    if n < 2:
        return {"n": n, "mean": v[0] if n else None, "std": None, "skew": None, "kurt": None}
    m = sum(v) / n
    sd = math.sqrt(sum((x - m) ** 2 for x in v) / (n - 1))
    if sd == 0:
        return {"n": n, "mean": m, "std": 0.0, "skew": 0.0, "kurt": 0.0}
    return {"n": n, "mean": m, "std": sd,
            "skew": (sum((x - m) ** 3 for x in v) / n) / sd ** 3,
            "kurt": (sum((x - m) ** 4 for x in v) / n) / sd ** 4 - 3}


def _read_text(p):
    d = open(p, "rb").read()
    for e in ("utf-8-sig", "utf-8", "gb18030", "latin-1"):
        try:
            return d.decode(e), e
        except UnicodeDecodeError:
            continue
    return d.decode("utf-8", "replace"), "utf-8(replace)"


def _csv(p):
    t, enc = _read_text(p)
    s = t[:20000]
    try:
        d = csv.Sniffer().sniff(s, delimiters=",;\t|").delimiter
    except Exception:
        d = "," if s.count(",") >= s.count("\t") else "\t"
    rows = [r for r in csv.reader(io.StringIO(t), delimiter=d) if any(c.strip() for c in r)]
    return rows, {"format": "csv", "encoding": enc, "delimiter": d}


def _db(p):
    con = sqlite3.connect(p)
    cur = con.cursor()
    out = {}
    for t in [r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]:
        try:
            cols = [r[1] for r in cur.execute("PRAGMA table_info(%s)" % t)]
            out[t] = {"columns": cols, "rows": [list(r) for r in cur.execute("SELECT * FROM %s" % t)]}
        except Exception:
            continue
    con.close()
    return out


def _json(p):
    d = json.loads(_read_text(p)[0])
    if isinstance(d, list) and d and isinstance(d[0], dict):
        cols = sorted({k for x in d for k in x})
        d = {"columns": cols, "rows": [[x.get(c) for c in cols] for x in d]}
    return {"json_data": d} if isinstance(d, dict) and "columns" in d and "rows" in d else {"json_raw": d}


def _hdr(rows):
    return bool(rows) and sum(1 for c in rows[0] if _num(c) is not None) == 0 and \
        (len(rows) < 2 or sum(1 for c in rows[1] if _num(c) is not None) > 0)


def _parse_names(p):
    specs, ia = [], False
    for ln in _read_text(p)[0].splitlines():
        if re.match(r"\d+\s*\.\s*(attribute|attributes)", ln.strip().lower()):
            ia = True
            continue
        if not ia:
            continue
        m = re.match(r"^\s*(\d+)\s*[.):]\s*(.+)$", ln)
        if m:
            nm = re.sub(r"\s*\(.*$", "", re.sub(r"\s*:\s*$", "", m.group(2).strip())).strip()
            specs.append({"name": nm, "role": "target" if re.search(r"class", nm, re.I) else "feature",
                          "type": None, "unit": None})
    return specs


def _unit(name):
    m = re.search(r"\(([^()]*)\)$", name) or \
        re.search(r"\b(cm|mm|m|kg|g|MPa|day|days|%|nm|um|µg|mg|ml|L)\b$", name, re.I)
    return m.group(1).strip() if m else None


def discover(inp):
    data, dic = [], []
    for n in sorted(os.listdir(inp)):
        p = os.path.join(inp, n)
        if not os.path.isfile(p) or n.lower() in ("case.json", "task.md"):
            continue
        lo = n.lower()
        if lo.endswith((".csv", ".tsv", ".txt", ".data", ".db", ".sqlite", ".sqlite3", ".json")):
            data.append(p)
        elif lo.endswith(".names") or "dict" in lo or "dictionary" in lo or "schema" in lo:
            dic.append(p)
    return data, dic


def load_table(p):
    n = os.path.basename(p).lower()
    if n.endswith((".db", ".sqlite", ".sqlite3")):
        return _db(p)
    if n.endswith(".json"):
        return _json(p)
    rows, meta = _csv(p)
    has = _hdr(rows)
    return {"csv": {"columns": [str(c).strip() for c in rows[0]] if has else None,
                    "rows": rows[1:] if has else rows, "meta": meta}}


def _pick(tables):
    best, bs = None, -1
    for name, tb in tables.items():
        rs = tb.get("rows") if isinstance(tb, dict) else None
        if not rs:
            continue
        w = max((len(r) for r in rs), default=0)
        num = 0
        for c in range(w):
            v = [_num(r[c]) for r in rs if c < len(r)]
            if sum(1 for x in v if x is not None) > 0.6 * max(1, len(v)):
                num += 1
        if len(rs) * 10 + num > bs:
            best, bs = name, len(rs) * 10 + num
    return best


def infer(cols, rows):
    specs = []
    w = len(cols) if cols else (len(rows[0]) if rows else 0)
    for i in range(w):
        name = cols[i] if cols and i < len(cols) else "column_%d" % (i + 1)
        v = [r[i] if i < len(r) else "" for r in rows]
        num = [x for x in (_num(y) for y in v) if x is not None]
        miss = sum(1 for y in v if _mis(y))
        uniq = {str(y) for y in v if not _mis(y)}
        if len(num) >= 0.5 * max(1, len(v) - miss):
            typ = "integer" if all(float(x) == int(x) for x in num) else "numeric"
        else:
            typ = "categorical" if 0 < len(uniq) <= 50 else "text"
        specs.append({"name": name, "type": typ, "unit": _unit(name), "role": "feature",
                      "missing_count": miss, "n": len(v), "unique": len(uniq)})
    return specs


def clean(rows, cols, specs, drop=False):
    issues, changes, rules = [], [], []
    raw = len(rows)
    seen, uniq = set(), []
    for r in rows:
        k = tuple(str(x) for x in r)
        if k not in seen:
            seen.add(k)
            uniq.append(r)
    nd = raw - len(uniq)
    if nd:
        issues.append({"category": "duplicate", "count": nd, "action": "removed" if drop else "kept"})
        changes.append({"step": "duplicate_rows", "before": raw, "after": len(uniq), "reason": "exact duplicates"})
        rules.append({"rule": "duplicates", "policy": "remove" if drop else "report+keep"})
    dr = uniq if drop else rows
    for i, s in enumerate(specs):
        v = [r[i] if i < len(r) else "" for r in dr]
        miss = sum(1 for x in v if _mis(x))
        if miss:
            issues.append({"category": "missing", "column": s["name"], "count": miss,
                           "fraction": round(miss / max(1, len(v)), 4)})
            changes.append({"step": "missing_handling", "column": s["name"],
                            "action": "listwise_deletion_for_stats", "count": miss})
            rules.append({"rule": "missing", "column": s["name"], "policy": "listwise delete, never 0"})
        if s["type"] in ("numeric", "integer"):
            num = [x for x in (_num(y) for y in v) if x is not None]
            if len(num) >= 4:
                q = st.quantiles(num, n=4, method="inclusive")
                lo, hi = q[0] - 1.5 * (q[2] - q[0]), q[2] + 1.5 * (q[2] - q[0])
                on = sum(1 for x in num if x < lo or x > hi)
                if on:
                    issues.append({"category": "outlier", "column": s["name"], "count": on,
                                   "method": "Tukey IQR 1.5", "fences": [round(lo, 6), round(hi, 6)]})
                    rules.append({"rule": "outlier", "column": s["name"], "policy": "flag only"})
    return dr, {"issues": issues, "changes": changes, "rules": rules,
                "raw_rows": raw, "duplicate_rows": nd}


def desc(specs, rows):
    o = {}
    for i, s in enumerate(specs):
        v = [r[i] if i < len(r) else "" for r in rows]
        if s["type"] in ("numeric", "integer"):
            num = [x for x in (_num(y) for y in v) if x is not None]
            m = _mom(num)
            q = st.quantiles(num, n=4, method="inclusive") if len(num) >= 4 else None
            o[s["name"]] = {"type": s["type"], "unit": s.get("unit"), "n": len(num),
                            "missing": s["missing_count"], "mean": _r(m["mean"]), "std": _r(m["std"]),
                            "median": _r(st.median(num)) if num else None,
                            "min": _r(min(num)) if num else None, "max": _r(max(num)) if num else None,
                            "q1": _r(q[0]) if q else None, "q3": _r(q[2]) if q else None,
                            "skewness": _r(m["skew"]), "kurtosis": _r(m["kurt"])}
        else:
            c = {}
            for x in v:
                if not _mis(x):
                    c[str(x)] = c.get(str(x), 0) + 1
            o[s["name"]] = {"type": s["type"], "n": sum(c.values()), "missing": s["missing_count"],
                            "unique": len(c), "top": sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))[:5]}
    return o


def corr(specs, rows):
    ni = [i for i, s in enumerate(specs) if s["type"] in ("numeric", "integer")]
    names = [specs[i]["name"] for i in ni]
    cols = [[_num(r[i]) if i < len(r) else None for r in rows] for i in ni]
    mat = {}
    for a in range(len(ni)):
        for b in range(a, len(ni)):
            xs, ys = [], []
            for x, y in zip(cols[a], cols[b]):
                if x is not None and y is not None:
                    xs.append(x)
                    ys.append(y)
            n = len(xs)
            if n < 3:
                r, p = None, None
            else:
                mx, my = sum(xs) / n, sum(ys) / n
                sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
                sxx = sum((x - mx) ** 2 for x in xs)
                syy = sum((y - my) ** 2 for y in ys)
                r = sxy / math.sqrt(sxx * syy) if sxx > 0 and syy > 0 else 0.0
                p = 0.0 if abs(r) >= 1 else tpv(r * math.sqrt((n - 2) / (1 - r * r)), n - 2)
            mat[names[a] + "|" + names[b]] = {"r": _r(r), "p": _r(p, 8), "n": n}
    return {"matrix": mat, "variables": names}


def welch(a, b):
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return None
    ma, mb = sum(a) / na, sum(b) / nb
    va = sum((x - ma) ** 2 for x in a) / (na - 1)
    vb = sum((x - mb) ** 2 for x in b) / (nb - 1)
    if va == 0 and vb == 0:
        return {"t": None, "p": None, "df": None}
    se = math.sqrt(va / na + vb / nb)
    t = (ma - mb) / se
    df = (va / na + vb / nb) ** 2 / ((va / na) ** 2 / (na - 1) + (vb / nb) ** 2 / (nb - 1))
    sp = math.sqrt(((na - 1) * va + (nb - 1) * vb) / (na + nb - 2))
    return {"t": _r(t, 6), "p": _r(tpv(t, df), 8), "df": _r(df, 3),
            "mean_a": _r(ma), "mean_b": _r(mb), "n_a": na, "n_b": nb,
            "std_a": _r(math.sqrt(va)), "std_b": _r(math.sqrt(vb)),
            "cohens_d": _r((ma - mb) / sp if sp else None, 4)}


def groups(specs, rows, ti):
    tn = specs[ti]["name"]
    grp = {}
    for r in rows:
        if ti < len(r) and not _mis(r[ti]):
            grp.setdefault(str(r[ti]), []).append(r)
    if len(grp) < 2:
        return None
    gl = sorted(grp)
    out = {"target": tn, "groups": gl, "size": {g: len(v) for g, v in grp.items()},
           "per_feature": {}, "pairwise_tests": []}
    for i, s in enumerate(specs):
        if i == ti or s["type"] not in ("numeric", "integer"):
            continue
        gv = {g: [x for x in (_num(r[i]) for r in rs) if x is not None] for g, rs in grp.items()}
        per = {}
        for g, v in gv.items():
            m = _mom(v)
            per[g] = {"n": len(v), "mean": _r(m["mean"]), "std": _r(m["std"])}
        out["per_feature"][s["name"]] = {"unit": s.get("unit"), "groups": per}
        for a in range(len(gl)):
            for b in range(a + 1, len(gl)):
                r = welch(gv[gl[a]], gv[gl[b]])
                if r:
                    rec = {"feature": s["name"], "group_a": gl[a], "group_b": gl[b]}
                    rec.update(r)
                    out["pairwise_tests"].append(rec)
    return out


def _feat_series(rows, specs, feat, ti):
    fi = next((i for i, s in enumerate(specs) if s["name"] == feat), None)
    g = {}
    for r in rows:
        if fi is None or ti >= len(r) or fi >= len(r) or _mis(r[ti]):
            continue
        v = _num(r[fi])
        if v is not None:
            g.setdefault(str(r[ti]), []).append(v)
    return sorted(g.items())


def build_quality(specs, rows, cleaning, source):
    return {"source": source, "n_rows": len(rows), "n_columns": len(specs),
            "duplicate_rows": cleaning.get("duplicate_rows", 0),
            "missing_total": sum(s.get("missing_count", 0) for s in specs),
            "issues": cleaning.get("issues", []),
            "per_column": [{"name": s["name"], "type": s["type"], "unit": s.get("unit"),
                            "n": s.get("n"), "missing": s.get("missing_count"),
                            "unique": s.get("unique")} for s in specs]}


def build_sources(data, dic, main_name, specs):
    src = [{"source": os.path.basename(p), "type": "material", "locator": "file",
            "quote": "", "role": "data" if p in data else "dictionary"} for p in data + dic]
    src.append({"source": main_name, "type": "table",
                "locator": "columns=" + ",".join(s["name"] for s in specs),
                "quote": ",".join(s["name"] for s in specs), "role": "main_table"})
    return src


def run(inp, work, out):
    rep = {"errors": [], "degradations": [], "warnings": []}
    data, dic = discover(inp)
    rep["materials"] = {"data_files": [os.path.basename(p) for p in data],
                        "dict_files": [os.path.basename(p) for p in dic]}
    ws = {}
    wp = os.path.join(work, "worksheet.json")
    if os.path.isfile(wp):
        try:
            ws = json.load(open(wp, encoding="utf-8"))
        except Exception as e:
            rep["degradations"].append("worksheet.json unreadable: %s" % e)
    tables = {}
    for p in data:
        try:
            for k, v in load_table(p).items():
                tables[os.path.basename(p) + ":" + k] = v
        except Exception as e:
            rep["degradations"].append("failed to load %s: %s" % (os.path.basename(p), e))
    if not tables:
        rep["status"] = "insufficient_evidence"
        rep["reason"] = "no loadable tabular material in input"
        return rep
    mn = _pick(tables)
    main = tables[mn]
    cols = main.get("columns")
    rows = main["rows"]
    from_names = []
    if cols is None:
        ds = _parse_names(p) if (p := next((x for x in dic if x.endswith(".names")), None)) else []
        if ds:
            cols = [s["name"] for s in ds]
            from_names = ds
    w = len(cols) if cols else (max((len(r) for r in rows), default=0))
    rows = [list(r)[:w] + [""] * (w - len(r)) if len(r) < w else list(r)[:w] for r in rows]
    specs = infer(cols, rows)
    for s, d in zip(specs, from_names):
        if d.get("role"):
            s["role"] = d["role"]
        if d.get("unit"):
            s["unit"] = d["unit"]
    for d in ws.get("data_dictionary", []):
        for s in specs:
            if s["name"] == d.get("name") or s["name"].lower() == str(d.get("name", "")).lower():
                for k in ("type", "unit", "role"):
                    if d.get(k):
                        s[k] = d[k]
    ti = None
    tc = ws.get("target_column")
    for i, s in enumerate(specs):
        if (tc and (s["name"] == tc or s["name"].lower() == tc.lower())) or \
           s["role"] == "target" or re.search(r"\b(class|species|strength|target|label|type|cultivar|variety|group)\b",
                                              s["name"].lower()):
            ti = i
            s["role"] = "target"
            break
    if ti is None:
        cats = [i for i, s in enumerate(specs) if s["type"] == "categorical"]
        if len(cats) == 1:
            ti = cats[0]
            specs[ti]["role"] = "target"
    crows, cleaning = clean(rows, cols, specs, drop=bool(ws.get("drop_duplicates", False)))
    dsc = desc(specs, crows)
    cr = corr(specs, crows)
    gr = groups(specs, crows, ti) if ti is not None else None
    q = build_quality(specs, crows, cleaning, mn)
    hist_data = [(s["name"], s.get("unit"), [_num(r[i]) for r in crows])
                 for i, s in enumerate(specs) if s["type"] in ("numeric", "integer")]
    box_data = []
    if gr:
        for feat, info in gr["per_feature"].items():
            box_data.append((feat, info.get("unit"), _feat_series(crows, specs, feat, ti)))
    rep.update({"status": "complete", "source_table": mn, "columns": [s["name"] for s in specs],
                "n_rows": len(crows), "n_columns": len(specs),
                "detected_format": main.get("meta", {}),
                "dictionary": [{k: s[k] for k in ("name", "type", "unit", "role")} for s in specs],
                "cleaning": cleaning, "descriptive": dsc, "correlation": cr,
                "groups": gr, "quality": q, "hist_data": hist_data, "box_data": box_data,
                "cleaned_rows": crows,
                "sources": build_sources(data, dic, mn, specs)})
    return rep

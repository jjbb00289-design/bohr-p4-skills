---
name: reading-bench
description: 从组织方给定的 source-conditioned benchmark-DRAFT workorder 出发，构建可判分、可复跑、可版本化的文献阅读 Benchmark 与评测工具：题卡、参考答案、0/1/2 评分锚点、逐题得分与三指针、失败样例与版本对比。当需要把科研材料转成可重复运行的阅读评测基准并对候选答案诚实打分时使用。
version: 1.0.0
---

# 文献阅读 Benchmark 与评测工具（reading-bench）

把一个“只有题面草稿、判不了分、查不回”的评测，改造成可判分、可复跑、可版本化的最小成果。
本 Skill 聚焦一条明确方向：**题集管理 + 评分表 + 三指针可核验**，并同步落点覆盖
统一运行器、结果面板、失败样例库、版本对比四个方向。

**脚本不会代替你阅读理解。必须先读材料再写工作稿，禁止只运行 build 就结束。**

## 1. 什么时候用 / 什么时候不用

用：输入是科研材料（段落/表格文本）+ 一个 `workorder`（若干草稿题，各指向一份材料），
需要把草稿题补全为正式题卡，配参考答案与可观察评分锚点，对候选答案逐题打分并留痕。

不用：PDF 像素级解析（先走平台 PDF 文本工具）、本体/数据库服务、统计推断、
以及“把未报告写成事实”的场景。本工具只做**可复核的判分**，不仲裁科学争议。

## 2. 强制流程（评测 Agent 请按此执行）

```bash
python3 scripts/main.py init      # 索引 case / 材料 / workorder，落 partial result.json
python3 scripts/main.py show      # 打印材料清单与 workorder
python3 scripts/main.py show --material m1   # 逐段打印 m1，带稳定 locator
# —— 逐项读 workorder 与对应材料，亲自补全 work/draft.json ——
python3 scripts/main.py check     # 机械校验：题卡数、quote 命中、三指针、六方向、DOI
python3 scripts/main.py build     # 生成 benchmark/ 产物 + result.json（无条件 finalize）
python3 scripts/main.py selfcheck # 只复检不重做（可选）
```

所有命令都支持 `--input --work --output` 覆盖默认路径（`/input`、`/app/work`、`/app/output`），
且**退出码恒为 0**。`init` 后 `result.json` 已是合法的 partial 结果。

## 3. 输入契约（运行期）

- `/input/case.json`：`case_id`、`task_instruction`、`output_contract`（dict，业务型）、
  `workorder`（约 4 项，每项 `{id/requirement_id, requirement/task}` 的草稿题）、
  可能含 `questions` / `tasks` / `task_count`。
- `/input/task.md`：题面与 Runtime contract。
- `/input/` 下材料：段落文本（`.md/.txt`）、表格（`.csv`）或论文 PDF（`.pdf`）——
  文本/表格直接可引用；PDF 由脚本抽取文本层并按页建立 `mN.pK` locator（无文本层则降级）。
  候选答案文件常以 `candidate/response/answer/稿` 命名。

`workorder` 每一项 = 一道“判不了分”的草稿题。你要把它补全成能判分的题卡；
**题卡数必须等于 workorder 项数**，一个不能漏。

## 4. 工作稿 `/app/work/draft.json`（Schema）

```json
{
  "case_id": "来自 case.json",
  "set_id": "基准标识",
  "title": "基准标题",
  "version": "v1",
  "directions": ["题集管理", "统一运行器", "评分表", "结果面板", "失败样例库", "版本对比"],
  "run_config": {"permissions": ["read_only", "no_network"],
                 "budget": {"model_requests": 64, "seconds": 900},
                 "model": "由运行环境给出或填 unknown", "prompt_version": "v1"},
  "cards": [ /* 见第 5 节，数量 = workorder 项数 */ ],
  "candidates": [ {"candidate_id": "P1", "item_id": "W1", "source": "m2",
                   "raw_text": "候选答案原文"} ],
  "scores": [ /* 见第 6 节 */ ],
  "workorder_execution": [ {"requirement_id": "W1", "requirement": "草稿题原文",
                            "status": "done|rejected", "notes": "处理说明"} ],
  "version_history": [ {"version": "v1", "changes": "本次改动", "notes": ""} ],
  "pending_human": [], "uncertainties": [], "status": "answered|partial|insufficient_evidence|input_error"
}
```

## 5. 题卡 `cards[]`（每条 workorder 项一张）

| 字段 | 要求 |
|---|---|
| `item_id` | 与 workorder 项的 id 对应（W1..Wn） |
| `task` | 完整题干：任务 + 输入材料引用 + 输出要求，含难度边界 |
| `source_refs[]` | 题干与答案依赖的材料定位：`{source_id, locator, quote}`，quote 逐字 |
| `reference_answer` | `{content, evidence[]}`；答案必须是可判定的金标准，证据逐字 |
| `scoring_rule` | `{anchors[], pass_threshold:0.8, score_012_map:"..."}` |
| `difficulty` | `easy\|medium\|hard` |
| `license` | 数据授权，未知写 `unspecified` |
| `version` | 题卡版本，改动必须递增 |

评分锚点 `anchors[]`：`{anchor_id, observable, weight, failure_type}`。
`observable` 写“可观察、可二值判断”的判据（例如“答案数值为 12.4 且单位为 %”），
**禁止**只写“清晰/准确/完整”这类不可判定词。`failure_type` 取
`wrong_answer / missing_evidence / hallucinated_content / misread_question /
unsupported_inference / partial_coverage / empty_output / not_reported_as_fact /
format_violation / copied_no_evidence / other` 之一。

## 6. 评分：0/1/2 档 + 三指针

`scripts/main.py` 按 `weighted_score = Σ(weight×factor)/Σ(weight)×100` 确定性计算，
factor 由每条锚点的判定映射：`pass=1.0 / partial=0.5 / fail=0.0`。
`score_012` 由加权分确定性映射：`≥ pass_threshold×100 → 2`、`≥ 40 → 1`、否则 `0`。
`verdict`（pass/partial/fail）由你按锚点判，但**必须与加权分/0-1-2 档一致**：
明显对→2、边缘→1、明显错→0。自测需同时覆盖这三种（check 会提示）。

每条 `scores[]` 记录：

```json
{"score_id": "SC1", "item_id": "W1", "candidate_id": "P1",
 "anchor_hits": {"A1": "pass", "A2": "fail"},
 "verdict": "partial", "failure_type": "missing_evidence",
 "evidence_quotes": ["候选答案中未支持原文的逐字片段"],
 "rationale": "为什么这么判"}
```

`build` 会把每行得分落地为**三个可解析指针**（落进 `scores.csv` 与 `result.json`）：

| 指针 | 产物 | 内容 |
|---|---|---|
| `raw_output_ref` | `benchmark/raw_outputs/<item_id>/<candidate_id>.md` | 候选答案原始输出 |
| `config_ref` | `benchmark/run_config.json` | 权限/预算/模型/prompt 版本 |
| `scoring_record_ref` | `benchmark/scoring_records/<item_id>/<candidate_id>.json` | 锚点判定 + 加权分 + 依据 |

若某道题卡没有候选答案可判，`build` 会自动补齐 **2/1/0 自测**（正确复现→2、
部分覆盖→1、空答案→0），并在 `scores` 里标 `self_test:true`，确保评分规则可被独立复核。

## 7. 六方向落点（每个方向一个真实产物）

| 方向 | 落点 |
|---|---|
| 题集管理 | `benchmark/cards.json` |
| 统一运行器 | `benchmark/run_config.json` + 本脚本（init/show/check/build 归一输出） |
| 评分表 | `benchmark/scores.csv` + `benchmark/scoring_records/` |
| 结果面板 | `benchmark/dashboard.md`（由 scores 生成，不手写） |
| 失败样例库 | `benchmark/failures.jsonl`（错误样本 + 下一版专项题建议） |
| 版本对比 | `benchmark/version_diff.md` + `benchmark/version_history.json` |

## 8. 证据规范（逐字命中）

每条关键结论 = `source_id + locator + 逐字 quote`。quote 必须能在材料里**逐字命中**
（允许跨行，不允许改写/拼接；PDF 行尾连字符断裂 `sen-\ntiment` 由脚本容错归一，照常写 `sentiment` 即可）。
`locator` 用 `show` 打印的稳定定位：
文本段落 `m1.p3`、表格行 `m2.r5`、PDF 页 `m1.p4`。找不到原文支持就写“未报告/无法判断”，
**禁止**把“未报告”写成“不存在”、把推测写成结论、或自造 DOI/分数/数据。

## 9. 诚实边界与降级

| 情况 | 处理 |
|---|---|
| 材料缺失 / 无文本层 | `status=insufficient_evidence`，写 `pending_human`，不反推 |
| 某道题无法从材料判定 | 该卡 `difficulty=hard` 或 `pending_human` 注明，不编答案 |
| 未报告 vs 不存在 | 只写“未报告”；判定“未支持”≠“被证伪” |
| 缺工作稿 | `build` 自动落结构骨架（题卡=workorder 项数），`status=partial` |

`build` 无条件 finalize：即使没有 `draft.json`、坏 JSON、空输入，也产出合法 `result.json`
（契约字段全回填、`status=partial`、`degradations` 写清缺口），退出码 0。
空输入 → `input_error`；坏 JSON → `input_error` 或 `partial`；缺材料 → `partial`。

## 10. 工具优先、脚本兜底

平台提供 PDF 文本/渲染、OCR 等工具时，优先调用并把结果落盘到 `/app/work` 供脚本引用；
工具失败即降级并写 `degradations`。本脚本只用 Python 标准库、不联网、不依赖 CWD。

## 11. 自检清单（build 前逐项）

- [ ] 题卡数 = workorder 项数；每卡有 task/source_refs/reference_answer/scoring_rule。
- [ ] 每卡 ≥1 个可观察锚点，且观察判据可二值判断。
- [ ] 每条 source_ref 与 reference_answer 证据的 quote 能逐字命中材料。
- [ ] 每行 score 有 anchor_hits 全覆盖 + verdict + failure_type + 三指针可解析。
- [ ] 自测同时覆盖明显对(2)/边缘(1)/明显错(0) 三种。
- [ ] 六方向至少覆盖 4（本模板默认 6）。
- [ ] 未报告/无法判断/材料冲突都显式标注，未编造 DOI/分数/数据。

## 12. 最小调用示例（示例，非正式案例结果）

```bash
# 合成案例：workorder 有 1 项，材料 m1 含 "The value was 12.4 % under nitrogen."
python3 scripts/main.py init --input /input --work /app/work --output /app/output
python3 scripts/main.py show --material m1
# Agent 写 /app/work/draft.json：题卡 W1 = 该句的数值提取题，锚点 A1=数值 12.4、A2=单位 %；
# 候选 P1 回答 "12.4 %" → pass；P2 回答 "12 %" → fail。
python3 scripts/main.py check --input /input --work /app/work --output /app/output
python3 scripts/main.py build --input /input --work /app/work --output /app/output
```

预期产出：`/app/output/benchmark/{cards.json,scores.csv,run_config.json,raw_outputs/,scoring_records/,evaluation_report.md,dashboard.md,failures.jsonl,version_diff.md,version_history.json}` 与 `result.json`。

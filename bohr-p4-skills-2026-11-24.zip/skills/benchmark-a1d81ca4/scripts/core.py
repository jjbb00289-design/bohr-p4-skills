#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""reading-bench core: draft normalization, deterministic scoring, checks, renderers.

Imported by main.py. Pure standard library. Every public function is defensive:
it never raises on malformed data and never fabricates scientific content.
"""
import json
import re
from pathlib import Path

VERSION = "1.0.0"
SKILL_NAME = "reading-bench"
# The six directions the task names; each must have a landing point (artifact).
DIRECTIONS = ["题集管理", "统一运行器", "评分表", "结果面板", "失败样例库", "版本对比"]
VERDICTS = ["pass", "partial", "fail"]
FAILURE_TYPES = ["wrong_answer", "missing_evidence", "hallucinated_content",
                 "misread_question", "unsupported_inference", "partial_coverage",
                 "empty_output", "not_reported_as_fact", "format_violation",
                 "copied_no_evidence", "other"]
FACTORS = {"pass": 1.0, "partial": 0.5, "fail": 0.0}
STATUSES = ["answered", "partial", "insufficient_evidence", "input_error"]


# --------------------------------------------------------------------------- io helpers
def jload(path, default=None):
    try:
        raw = Path(path).read_bytes()
    except Exception:
        return default
    for enc in ("utf-8-sig", "utf-8", "gb18030", "latin-1"):
        try:
            return json.loads(raw.decode(enc))
        except Exception:
            continue
    return default


def jdump(path, obj):
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        return True
    except Exception:
        return False


def write_text(path, text):
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
        return True
    except Exception:
        return False


def norm_ws(value):
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        return " ".join(norm_ws(v) for v in value)
    if isinstance(value, dict):
        for key in ("text", "content", "statement", "instruction", "description", "task"):
            if value.get(key):
                return norm_ws(value[key])
        try:
            return json.dumps(value, ensure_ascii=False)
        except Exception:
            return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def as_text(value):
    return norm_ws(value)


def norm_id(value, prefix, idx):
    text = str(value or "").strip()
    return text if text else "%s%d" % (prefix, idx + 1)


# --------------------------------------------------------------------------- case / contract
def load_case(input_dir):
    case = jload(Path(str(input_dir)) / "case.json", None)
    if isinstance(case, dict):
        return case, []
    return {}, ["case.json missing or not an object"]


def contract_keys(contract):
    keys = []
    if isinstance(contract, dict):
        keys = [str(k) for k in contract.keys()]
    elif isinstance(contract, list):
        for item in contract:
            if isinstance(item, str):
                keys.append(item)
            elif isinstance(item, dict):
                for cand in ("name", "field", "key", "id", "output"):
                    if isinstance(item.get(cand), str):
                        keys.append(item[cand])
                        break
    return keys


def echo_contract(contract, base):
    keys, final, missing = contract_keys(contract), {}, []
    result = base.get("result") if isinstance(base.get("result"), dict) else {}
    for key in keys:
        if key in base:
            final[key] = base[key]
        elif key in result:
            final[key] = result[key]
        else:
            final[key] = None
            missing.append(key)
    final.update(base)
    if missing:
        base.setdefault("degradations", [])
        if isinstance(base["degradations"], list):
            base["degradations"].append("output_contract keys filled as null: " + ", ".join(missing))
    return final


# --------------------------------------------------------------------------- material discovery
def discover(input_dir, work_dir):
    """Recursively find source materials under /input, excluding the task files."""
    materials = []
    root = Path(str(input_dir))
    if not root.exists():
        return materials
    seen = set()
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        rel = str(p.relative_to(root))
        if rel in ("case.json", "task.md", "config.json"):
            continue
        if "__pycache__" in p.parts or rel.startswith(".git"):
            continue
        try:
            size = p.stat().st_size
        except Exception:
            size = 0
        if size > 2_000_000:
            continue
        mid = "m%d" % (len(materials) + 1)
        role = "source"
        if re.search(r"candidate|submission|response|answer|稿|答卷", rel, re.I):
            role = "candidate"
        elif re.search(r"workorder|task|requirement|scope|question", rel, re.I):
            role = "workorder"
        materials.append({"material_id": mid, "path": rel, "abs": str(p),
                          "kind": p.suffix.lower().lstrip(".") or "txt",
                          "role": role, "bytes": size})
        seen.add(mid)
    _ = seen
    return materials


def build_segments(materials, work_dir):
    """Split each text/table material into stable locator segments."""
    segments = []
    notes = []
    seg_dir = Path(str(work_dir)) / "segments"
    seg_dir.mkdir(parents=True, exist_ok=True)
    for m in materials:
        if m["kind"] == "pdf":
            _pdf_segments(m, segments, notes, seg_dir)
            continue
        try:
            raw = Path(m["abs"]).read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            notes.append("cannot read %s: %s" % (m["material_id"], exc))
            continue
        m["text_chars"] = len(raw)
        if m["kind"] in ("csv", "tsv"):
            rows = [r for r in raw.splitlines() if r.strip()]
            for i, row in enumerate(rows):
                loc = "%s.r%d" % (m["material_id"], i + 1)
                segments.append({"material_id": m["material_id"], "locator": loc,
                                 "kind": "table_row", "text": row,
                                 "heading": "row %d" % (i + 1)})
            jdump(seg_dir / (m["material_id"] + ".json"), {"material_id": m["material_id"],
                    "kind": "table", "rows": rows, "locators":
                    ["%s.r%d" % (m["material_id"], i + 1) for i in range(len(rows))]})
        else:
            paras = [p.strip() for p in re.split(r"\n\s*\n|\r?\n", raw) if p.strip()]
            if not paras:
                paras = [raw.strip()] if raw.strip() else []
            for i, para in enumerate(paras):
                loc = "%s.p%d" % (m["material_id"], i + 1)
                segments.append({"material_id": m["material_id"], "locator": loc,
                                 "kind": "paragraph", "text": para,
                                 "heading": "para %d" % (i + 1)})
            jdump(seg_dir / (m["material_id"] + ".json"), {"material_id": m["material_id"],
                    "kind": "text", "paragraphs": paras, "locators":
                    ["%s.p%d" % (m["material_id"], i + 1) for i in range(len(paras))]})
    return segments, notes


def _pdf_segments(m, segments, notes, seg_dir):
    """Extract a PDF material into per-page segments with `mN.pK` locators.

    The quote contract still holds: every evidence quote must appear verbatim
    inside a single normalized page blob. A PDF without a text layer yields a
    note and no segments; the caller degrades instead of fabricating.
    """
    try:
        import pdftext as P
    except Exception as exc:
        notes.append("pdftext unavailable for %s: %s" % (m["material_id"], exc))
        return
    try:
        text, npages, ratio = P.pdf_text(m["abs"])
    except Exception as exc:
        notes.append("cannot parse pdf %s: %s" % (m["material_id"], exc))
        return
    if not text.strip():
        notes.append("pdf %s has no extractable text layer" % m["material_id"])
        return
    m["text_chars"] = len(text)
    try:
        pages = P.pdf_pages(m["abs"])
    except Exception:
        pages = []
    if not pages:
        pages = [text] if text.strip() else []
    paras, locs = [], []
    for i, page in enumerate(pages):
        if not page.strip():
            continue
        loc = "%s.p%d" % (m["material_id"], i + 1)
        segments.append({"material_id": m["material_id"], "locator": loc,
                         "kind": "page", "text": page, "heading": "page %d" % (i + 1)})
        paras.append(page)
        locs.append(loc)
    jdump(seg_dir / (m["material_id"] + ".json"),
          {"material_id": m["material_id"], "kind": "pdf", "paragraphs": paras,
           "locators": locs})


def summary(m):
    return {"material_id": m["material_id"], "path": m["path"], "kind": m["kind"],
            "role": m["role"], "text_chars": m.get("text_chars", 0)}


def all_segments(work_dir):
    out = []
    seg_dir = Path(str(work_dir)) / "segments"
    if seg_dir.exists():
        for f in sorted(seg_dir.glob("*.json")):
            data = jload(f, {}) or {}
            rows = data.get("rows") or data.get("paragraphs") or []
            for i, text in enumerate(rows):
                loc = (data.get("locators") or [])[i] if i < len(data.get("locators") or []) \
                    else "seg%d" % (i + 1)
                out.append({"material_id": data.get("material_id", f.stem),
                            "locator": loc, "text": text})
    return out


def _dehyphen_canon(text):
    """Whitespace/case/hyphen-tolerant canonical form for line-break hyphenation.

    `sen-\ntiment` extracted from a PDF becomes `sen- timent` after whitespace
    normalization; de-hyphenating both sides lets a verbatim quote of
    `sentiment` or `sen-timent` still land. This never rescues a *rewritten*
    quote: every non-hyphen character must still appear in order.
    """
    return re.sub(r"\s+", "", re.sub(r"-", "", norm_ws(text))).lower()


def quote_hit_rate(quotes, segments, work_dir):
    """Compute how many evidence quotes appear verbatim (normalized ws) in the materials."""
    blob = {}
    for seg in segments:
        blob.setdefault(seg["material_id"], []).append(norm_ws(seg["text"]))
    items = []
    hits = 0
    for q in quotes:
        text = norm_ws(q.get("quote") or "")
        loc = str(q.get("locator") or "")
        material = str(q.get("source_id") or q.get("material_id") or "")
        status = "miss"
        if text:
            # exact substring over any segment of that material (or any material if unspecified)
            candidates = blob.get(material) if material in blob else [s for v in blob.values() for s in v]
            canon = _dehyphen_canon(text)
            if any(text in seg for seg in candidates):
                status = "hit"
            elif canon and any(canon in _dehyphen_canon(seg) for seg in candidates):
                status = "hit"
        items.append({"id": q.get("id", ""), "quote": text, "locator": loc, "status": status})
        if status == "hit":
            hits += 1
    rate = round(hits / float(len(items)), 3) if items else 1.0
    return {"rate": rate, "items": items}


# --------------------------------------------------------------------------- draft normalization
def load_draft(work_dir, draft_path=None):
    path = Path(str(draft_path)) if draft_path else Path(str(work_dir)) / "draft.json"
    draft = jload(path, None)
    return (draft if isinstance(draft, dict) else None), str(path)


def cards_of(draft):
    out = []
    for idx, raw in enumerate(draft.get("cards") or []):
        if not isinstance(raw, dict):
            continue
        refs = []
        for r in (raw.get("source_refs") or []):
            if isinstance(r, str):
                r = {"source_id": r}
            if isinstance(r, dict):
                refs.append({"source_id": str(r.get("source_id") or r.get("material_id") or ""),
                             "locator": str(r.get("locator") or ""),
                             "quote": norm_ws(r.get("quote") or "")})
        anchors = []
        for aidx, a in enumerate(raw.get("scoring_rule", {}).get("anchors")
                                 if isinstance(raw.get("scoring_rule"), dict) else []):
            if isinstance(a, str):
                a = {"observable": a}
            if not isinstance(a, dict):
                continue
            try:
                weight = float(a.get("weight") or 0)
            except Exception:
                weight = 0.0
            anchors.append({"anchor_id": norm_id(a.get("anchor_id") or a.get("id"), "A", aidx)
                            if not a.get("anchor_id") else str(a["anchor_id"]),
                            "observable": norm_ws(a.get("observable") or a.get("criterion")),
                            "weight": weight,
                            "failure_type": norm_ws(a.get("failure_type") or "other")})
        rule = raw.get("scoring_rule") if isinstance(raw.get("scoring_rule"), dict) else {}
        ref_answer = raw.get("reference_answer")
        if isinstance(ref_answer, str):
            ref_answer = {"content": ref_answer}
        if not isinstance(ref_answer, dict):
            ref_answer = {}
        out.append({"item_id": norm_id(raw.get("item_id") or raw.get("id"), "W", idx),
                    "task": as_text(raw.get("task") or raw.get("instruction")),
                    "task_type": norm_ws(raw.get("task_type") or "comprehension"),
                    "source_refs": refs,
                    "reference_answer": {"content": as_text(ref_answer.get("content")
                                                            or ref_answer.get("answer")),
                                         "evidence": ref_answer.get("evidence") or []},
                    "scoring_rule": {"anchors": anchors,
                                     "pass_threshold": rule.get("pass_threshold", 0.8),
                                     "score_012_map": rule.get("score_012_map",
                                                              ">=0.8→2, >=0.4→1, else 0")},
                    "difficulty": norm_ws(raw.get("difficulty") or "medium"),
                    "license": norm_ws(raw.get("license") or "unspecified"),
                    "version": norm_ws(raw.get("version") or "v1")})
    return out


def candidates_of(draft):
    out = []
    for idx, raw in enumerate(draft.get("candidates") or []):
        if not isinstance(raw, dict):
            raw = {"raw_text": str(raw)}
        out.append({"candidate_id": norm_id(raw.get("candidate_id") or raw.get("id"), "P", idx),
                    "item_id": str(raw.get("item_id") or raw.get("card_id") or ""),
                    "source": str(raw.get("source") or raw.get("material_id") or ""),
                    "locator": str(raw.get("locator") or ""),
                    "raw_text": as_text(raw.get("raw_text") or raw.get("text")
                                        or raw.get("content") or raw.get("answer"))})
    return out


def scores_of(draft):
    out = []
    for idx, raw in enumerate(draft.get("scores") or []):
        if not isinstance(raw, dict):
            continue
        hits = raw.get("anchor_hits") or {}
        if not isinstance(hits, dict):
            hits = {}
        out.append({"score_id": str(raw.get("score_id") or "SC%d" % (idx + 1)),
                    "item_id": str(raw.get("item_id") or raw.get("card_id") or ""),
                    "candidate_id": str(raw.get("candidate_id") or ""),
                    "anchor_hits": {str(k): norm_ws(v) for k, v in hits.items()},
                    "verdict": norm_ws(raw.get("verdict") or ""),
                    "failure_type": norm_ws(raw.get("failure_type") or ""),
                    "evidence_quotes": [str(q) for q in (raw.get("evidence_quotes")
                                                         or raw.get("evidence") or [])
                                        if str(q).strip()],
                    "rationale": norm_ws(raw.get("rationale") or raw.get("notes") or "")})
    return out


def weighted_score(card, hits):
    total = sum(a["weight"] for a in (card.get("scoring_rule", {}).get("anchors") or []))
    if total <= 0:
        return None
    got = 0.0
    for anchor in card.get("scoring_rule", {}).get("anchors") or []:
        verdict = (hits.get(anchor["anchor_id"]) or "").lower()
        got += anchor["weight"] * FACTORS.get(verdict, 0.0)
    return round(got / total * 100.0, 1)


def score_012(weighted, threshold):
    if weighted is None:
        return None
    th = float(threshold) if isinstance(threshold, (int, float)) else 0.8
    if weighted >= th * 100:
        return 2
    if weighted >= 0.4 * 100:
        return 1
    return 0


def detect_candidates(materials):
    found = []
    marker = re.compile(r"candidate|submission|response|answer|稿|答卷", re.I)
    for m in materials:
        if m.get("role") in ("task", "workorder"):
            continue
        if marker.search(m.get("path", "")) and m.get("text_chars", 0):
            found.append({"candidate_id": "P%d" % (len(found) + 1), "item_id": "",
                          "source": m["material_id"], "locator": "", "path": m["path"]})
    return found


def workorder_of(case):
    """Normalize the organizer workorder (4 draft items) into [{requirement_id, requirement}]."""
    out = []
    for key in ("workorder", "requirements", "tasks", "must_include"):
        for idx, entry in enumerate(case.get(key) or []):
            if isinstance(entry, str):
                out.append({"requirement_id": "%s-%d" % (key, idx + 1),
                            "requirement": norm_ws(entry)})
            elif isinstance(entry, dict):
                out.append({"requirement_id": str(entry.get("id") or entry.get("requirement_id")
                                                  or entry.get("item_id") or entry.get("task_id")
                                                  or "%s-%d" % (key, idx + 1)),
                            "requirement": norm_ws(entry.get("requirement") or entry.get("task")
                                                   or entry.get("instruction")
                                                   or json.dumps(entry, ensure_ascii=False))})
    # questions shape is also a legal workorder source
    if not out:
        for idx, q in enumerate(case.get("questions") or []):
            if isinstance(q, dict):
                out.append({"requirement_id": str(q.get("question_id") or q.get("id")
                                                  or "Q%d" % (idx + 1)),
                            "requirement": norm_ws(q.get("question") or q.get("text"))})
    return out


# --------------------------------------------------------------------------- self-test candidates
def ensure_self_test(cards, candidates, scores):
    """Guarantee one clearly-pass (2) / one clearly-fail (0) / one borderline (1)
    self-test row when a card has no scored candidates yet, so the scoring rule is
    demonstrably discriminative. Self-test rows are transparently flagged and never
    invent scientific content: pass reuses a verbatim source quote, fail is an empty
    answer, edge reuses the reference answer judged on half its anchors.
    """
    cands = list(candidates)
    rows = list(scores)
    covered = {s.get("item_id") for s in scores}
    seq = len(scores) + 1
    notes = []
    for card in cards:
        if card["item_id"] in covered:
            continue
        anchors = card.get("scoring_rule", {}).get("anchors") or []
        if not anchors:
            continue
        content = card.get("reference_answer", {}).get("content") or ""
        quote = ""
        for ev in card.get("reference_answer", {}).get("evidence") or []:
            if isinstance(ev, dict) and ev.get("quote"):
                quote = ev["quote"]
                break
        if not quote and card.get("source_refs"):
            quote = card["source_refs"][0].get("quote", "") if isinstance(
                card["source_refs"][0], dict) else ""

        # 1) pass -> every anchor satisfied, raw text is the verbatim source span
        pid = "SELF-%s-PASS" % card["item_id"]
        cands.append({"candidate_id": pid, "item_id": card["item_id"],
                      "source": "", "locator": "", "raw_text": quote or content,
                      "self_test": True})
        rows.append({"score_id": "SC%d" % seq, "item_id": card["item_id"],
                     "candidate_id": pid,
                     "anchor_hits": {a["anchor_id"]: "pass" for a in anchors},
                     "verdict": "pass", "failure_type": "",
                     "evidence_quotes": [quote] if quote else [],
                     "rationale": "自测：逐字复现参考答案，锚点全命中", "self_test": True})
        seq += 1
        # 2) fail -> empty answer, nothing is satisfied
        fid = "SELF-%s-FAIL" % card["item_id"]
        cands.append({"candidate_id": fid, "item_id": card["item_id"],
                      "source": "", "locator": "", "raw_text": "", "self_test": True})
        rows.append({"score_id": "SC%d" % seq, "item_id": card["item_id"],
                     "candidate_id": fid,
                     "anchor_hits": {a["anchor_id"]: "fail" for a in anchors},
                     "verdict": "fail", "failure_type": "empty_output",
                     "evidence_quotes": [],
                     "rationale": "自测：空答案，锚点全不命中", "self_test": True})
        seq += 1
        # 3) borderline -> half the anchors pass (only for multi-anchor cards)
        if len(anchors) >= 2:
            eid = "SELF-%s-EDGE" % card["item_id"]
            cands.append({"candidate_id": eid, "item_id": card["item_id"],
                          "source": "", "locator": "", "raw_text": content,
                          "self_test": True})
            k = (len(anchors) + 1) // 2
            hits = {a["anchor_id"]: ("pass" if i < k else "fail")
                    for i, a in enumerate(anchors)}
            rows.append({"score_id": "SC%d" % seq, "item_id": card["item_id"],
                         "candidate_id": eid, "anchor_hits": hits,
                         "verdict": "partial",
                         "failure_type": "partial_coverage",
                         "evidence_quotes": [quote] if quote else [],
                         "rationale": "自测：仅命中部分锚点，覆盖不全", "self_test": True})
            seq += 1
        notes.append("added self-test pass/fail%s for %s"
                     % ("/edge" if len(anchors) >= 2 else "", card["item_id"]))
    return cands, rows, notes


# --------------------------------------------------------------------------- checks
def run_checks(input_dir, work_dir, draft_path=None, persist=True):
    work = Path(str(work_dir))
    index = jload(work / "index.json", {}) or {}
    case, _notes = load_case(input_dir)
    draft, resolved = load_draft(work, draft_path)
    fails, warnings, counts = [], [], {}
    report = {"draft_path": resolved, "fails": fails, "warnings": warnings, "counts": counts}
    if draft is None:
        fails.append("draft.json missing or not a JSON object at %s" % resolved)
        report["passed"] = False
        if persist:
            jdump(work / "check_report.json", report)
        print_check(report)
        return report

    cards, candidates, scores = cards_of(draft), candidates_of(draft), scores_of(draft)
    segments = all_segments(work)
    counts.update({"cards": len(cards), "candidates": len(candidates), "scores": len(scores)})

    workorder = index.get("workorder") or workorder_of(case)
    if workorder and len(cards) < len(workorder):
        fails.append("cards=%d but workorder has %d items" % (len(cards), len(workorder)))
    if not cards:
        fails.append("no cards: a benchmark needs a question set, not just a rubric")

    card_by_id = {c["item_id"]: c for c in cards}
    for card in cards:
        if not card["task"]:
            fails.append("card %s has no task/question" % card["item_id"])
        if not card["source_refs"]:
            warnings.append("card %s has no source_refs (answer may be unsupported)"
                            % card["item_id"])
        if not card["reference_answer"].get("content"):
            fails.append("card %s has no reference answer" % card["item_id"])
        anchors = card["scoring_rule"]["anchors"]
        if not anchors:
            fails.append("card %s has no scoring anchors" % card["item_id"])
        for anchor in anchors:
            if not anchor["observable"]:
                warnings.append("card %s anchor %s has no observable description"
                                % (card["item_id"], anchor["anchor_id"]))
            if anchor["weight"] <= 0:
                warnings.append("card %s anchor %s has no weight"
                                % (card["item_id"], anchor["anchor_id"]))
            if anchor["failure_type"] not in FAILURE_TYPES:
                warnings.append("card %s anchor %s failure_type %r unknown"
                                % (card["item_id"], anchor["anchor_id"], anchor["failure_type"]))

    # evidence quote hit rate for all card source_refs and reference answers
    quotes = []
    for card in cards:
        for r in card["source_refs"]:
            quotes.append({"id": "%s.src" % card["item_id"], "source_id": r["source_id"],
                           "locator": r["locator"], "quote": r["quote"]})
        for e in card["reference_answer"].get("evidence") or []:
            if isinstance(e, dict):
                quotes.append({"id": "%s.ref" % card["item_id"], "source_id": e.get("source_id", ""),
                               "locator": e.get("locator", ""), "quote": e.get("quote", "")})
    hit = quote_hit_rate([q for q in quotes if q["quote"]], segments, work)
    counts["quote_hit_rate"] = hit["rate"]
    for item in hit["items"]:
        if item["status"] == "miss":
            fails.append("evidence %s does not appear verbatim in the materials" % item["id"])

    # score cross references
    cand_ids = {c["candidate_id"] for c in candidates}
    for row in scores:
        if row["item_id"] not in card_by_id:
            fails.append("score %s references unknown card %s" % (row["score_id"], row["item_id"]))
            continue
        if candidates and row["candidate_id"] not in cand_ids:
            fails.append("score %s references unknown candidate %s"
                         % (row["score_id"], row["candidate_id"]))
        card = card_by_id.get(row["item_id"], {})
        anchor_ids = {a["anchor_id"] for a in card.get("scoring_rule", {}).get("anchors", [])}
        unknown = [k for k in row["anchor_hits"] if k not in anchor_ids]
        if unknown:
            fails.append("score %s uses unknown anchor ids: %s"
                         % (row["score_id"], ", ".join(unknown[:6])))
        missing_hits = [a["anchor_id"] for a in card.get("scoring_rule", {}).get("anchors", [])
                        if a["anchor_id"] not in row["anchor_hits"]]
        if missing_hits:
            fails.append("score %s missing anchor verdicts: %s"
                         % (row["score_id"], ", ".join(missing_hits[:6])))
        if row["verdict"] not in VERDICTS:
            fails.append("score %s verdict %r not in pass/partial/fail"
                         % (row["score_id"], row["verdict"]))
        if row["verdict"] in ("partial", "fail") and row["failure_type"] not in FAILURE_TYPES:
            fails.append("score %s needs a valid failure_type for a %s verdict"
                         % (row["score_id"], row["verdict"]))
        th = card.get("scoring_rule", {}).get("pass_threshold", 0.8)
        computed = weighted_score(card, row["anchor_hits"])
        s012 = score_012(computed, th)
        row["weighted_score"] = computed
        row["score_012"] = s012
        if computed is not None:
            if row["verdict"] == "fail" and computed >= 60:
                warnings.append("score %s computed %.1f but verdict=fail"
                                % (row["score_id"], computed))
            if row["verdict"] == "pass" and computed < 70:
                warnings.append("score %s computed %.1f but verdict=pass"
                                % (row["score_id"], computed))
            if s012 == 2 and row["verdict"] == "fail":
                warnings.append("score %s maps to 2 but verdict=fail" % row["score_id"])
            if s012 == 0 and row["verdict"] == "pass":
                warnings.append("score %s maps to 0 but verdict=pass" % row["score_id"])

    # self-test: at least one clearly-pass, one clearly-fail, one borderline score row
    if scores:
        c2 = sum(1 for s in scores if s.get("score_012") == 2)
        c1 = sum(1 for s in scores if s.get("score_012") == 1)
        c0 = sum(1 for s in scores if s.get("score_012") == 0)
        if not (c2 >= 1 and c0 >= 1 and c1 >= 1):
            warnings.append("self-test coverage: need one 2 / one 1 / one 0 score row "
                            "(got %d/%d/%d)" % (c2, c1, c0))

    directions = [str(d) for d in (draft.get("directions") or [])]
    covered = [d for d in DIRECTIONS if d in directions]
    counts["directions_covered"] = len(covered)
    counts["directions"] = covered
    if len(covered) < 4:
        fails.append("benchmark covers %d of 6 directions; needs >=4" % len(covered))

    # workorder receipts
    receipts = [r for r in (draft.get("workorder_execution") or []) if isinstance(r, dict)]
    got = {str(r.get("requirement_id") or r.get("id") or "") for r in receipts}
    missing_wo = [w["requirement_id"] for w in workorder if w["requirement_id"] not in got]
    counts["workorder_items"] = len(workorder)
    counts["workorder_receipts"] = len(receipts)
    if missing_wo:
        fails.append("workorder items without a receipt: " + ", ".join(missing_wo[:12]))

    # DOI guard: cited DOIs must appear in the materials
    body = "\n".join(c["task"] + " " + c["reference_answer"].get("content", "")
                     for c in cards) + "\n" + "\n".join(c["raw_text"] for c in candidates)
    material_blob = norm_ws(" ".join(s.get("text", "") for s in segments))
    bad_dois = sorted({d for d in re.findall(r"\b10\.\d{4,9}/[-._;()/:A-Za-z0-9]+", body)
                       if d not in material_blob})
    if bad_dois:
        fails.append("benchmark cites DOI(s) absent from the materials: "
                     + ", ".join(bad_dois[:5]))

    report["passed"] = not fails
    if persist:
        jdump(work / "check_report.json", report)
    print_check(report)
    return report


def print_check(report):
    print("CHECK %s" % ("PASS" if report.get("passed") else "FAIL"))
    for fail in report.get("fails") or []:
        print("FAIL  " + fail)
    for warn in (report.get("warnings") or [])[:40]:
        print("WARN  " + warn)
    print("COUNTS " + json.dumps(report.get("counts", {}), ensure_ascii=False, default=str))


# --------------------------------------------------------------------------- fallback draft
def fallback_draft(index):
    cards = []
    for idx, item in enumerate((index.get("workorder") or [])[:50]):
        cards.append({"item_id": norm_id(item.get("requirement_id"), "W", idx),
                      "task": item.get("requirement") or "未提供工作稿：题面待补充",
                      "task_type": "comprehension",
                      "source_refs": [],
                      "reference_answer": {"content": "待补充（未提供工作稿）", "evidence": []},
                      "scoring_rule": {"anchors": [{"anchor_id": "A1", "observable": "待补充",
                                                     "weight": 100, "failure_type": "other"}],
                                       "pass_threshold": 0.8,
                                       "score_012_map": ">=0.8→2, >=0.4→1, else 0"},
                      "difficulty": "medium", "license": "unspecified", "version": "v0-skeleton"})
    if not cards:
        cards = [{"item_id": "W1", "task": "未提供工作稿：题面待补充", "task_type": "comprehension",
                  "source_refs": [],
                  "reference_answer": {"content": "待补充（未提供工作稿）", "evidence": []},
                  "scoring_rule": {"anchors": [{"anchor_id": "A1", "observable": "待补充",
                                                 "weight": 100, "failure_type": "other"}],
                                   "pass_threshold": 0.8,
                                   "score_012_map": ">=0.8→2, >=0.4→1, else 0"},
                  "difficulty": "medium", "license": "unspecified", "version": "v0-skeleton"}]
    receipts = [{"requirement_id": w["requirement_id"], "requirement": w["requirement"],
                 "status": "missing", "notes": "未提供工作稿"} for w in (index.get("workorder") or [])]
    return {"case_id": index.get("case_id", ""), "title": "文献阅读评测基准（结构骨架）",
            "set_id": index.get("case_id", ""), "version": "v0.0-skeleton",
            "directions": list(DIRECTIONS),
            "run_config": {"permissions": ["read_only", "no_network"],
                           "budget": {"model_requests": 64, "seconds": 900},
                           "model": "unknown", "prompt_version": "skeleton"},
            "cards": cards, "candidates": [], "scores": [],
            "workorder_execution": receipts,
            "version_history": [{"version": "v0.0-skeleton", "changes": "结构骨架，无工作稿"}],
            "pending_human": ["补齐 work/draft.json 后重新 build"],
            "uncertainties": ["无工作稿：题卡/参考答案/评分锚点均为占位"],
            "status": "partial", "_fallback": True}


# --------------------------------------------------------------------------- renderers
def render_cards_json(cards):
    return json.dumps(cards, ensure_ascii=False, indent=2)


def render_scores_csv(scores, card_by_id):
    lines = [",".join(["item_id", "candidate_id", "score_012", "weighted_score", "verdict",
                       "failure_type", "raw_output_ref", "config_ref", "scoring_record_ref"])]
    for row in scores:
        lines.append(",".join([
            csv_escape(row["item_id"]), csv_escape(row["candidate_id"]),
            csv_escape(row.get("score_012")), csv_escape(row.get("weighted_score")),
            csv_escape(row["verdict"]), csv_escape(row["failure_type"]),
            csv_escape(row.get("raw_output_ref", "")), csv_escape(row.get("config_ref", "")),
            csv_escape(row.get("scoring_record_ref", ""))]))
    return "\n".join(lines) + "\n"


def csv_escape(value):
    if value is None:
        return ""
    text = str(value)
    if any(ch in text for ch in (",", '"', "\n")):
        return '"' + text.replace('"', '""') + '"'
    return text


def render_report(cards, candidates, scores, index):
    lines = ["# 文献阅读评测基准 · 评测报告", "",
             "case_id: %s · 版本 %s" % (index.get("case_id", ""),
                                        index.get("version", "v1")), "",
             "## 1. 概览", "",
             "| 指标 | 数值 |", "|---|---|",
             "| 题卡数 | %d |" % len(cards),
             "| 候选答案数 | %d |" % len(candidates),
             "| 评分行数 | %d |" % len(scores),
             "| 平均加权分 | %s |" % (round(sum((s.get("weighted_score") or 0) for s in scores)
                                             / float(len(scores)), 1) if scores else "n/a"),
             "", "## 2. 逐题结果", "",
             "| 题 | 候选 | 0/1/2 | 加权分 | 判定 | 失败类型 |", "|---|---|---|---|---|---|"]
    for row in scores:
        lines.append("| %s | %s | %s | %s | %s | %s |"
                     % (row["item_id"], row["candidate_id"], row.get("score_012", "-"),
                        row.get("weighted_score", "-"), row["verdict"],
                        row["failure_type"] or "-"))
    lines += ["", "## 3. 失败类型分布与下一版专项题", ""]
    dist = {}
    for row in scores:
        if row["failure_type"]:
            dist[row["failure_type"]] = dist.get(row["failure_type"], 0) + 1
    if dist:
        lines += ["| 失败类型 | 次数 | 建议的下一版专项题 |", "|---|---|---|"]
        for name, count in sorted(dist.items(), key=lambda kv: -kv[1]):
            lines.append("| %s | %d | 针对 %s 新增 1 道专项题并只重算受影响分数 |"
                         % (name, count, name))
    else:
        lines.append("- 无失败类型记录。")
    lines += ["", "## 4. 证据与可复算", ""]
    for row in scores:
        lines.append("### %s / %s" % (row["item_id"], row["candidate_id"]))
        lines.append("")
        lines.append("- 判定：%s；0/1/2：%s；加权分：%s"
                     % (row["verdict"], row.get("score_012", "-"), row.get("weighted_score", "-")))
        if row["failure_type"]:
            lines.append("- 失败类型：%s" % row["failure_type"])
        for quote in row["evidence_quotes"]:
            lines.append("- 证据：> %s" % quote)
        lines.append("")
    lines.append("")
    return "\n".join(lines)


def render_dashboard(cards, scores, index):
    lines = ["# 结果面板（由 scores 生成，不手写）", "",
             "| 题 | 满分 | 已评分 | 平均 0/1/2 | 失败样本 |", "|---|---|---|---|---|"]
    by_item = {}
    for row in scores:
        by_item.setdefault(row["item_id"], []).append(row)
    for card in cards:
        rows = by_item.get(card["item_id"], [])
        mean = (round(sum((r.get("score_012") or 0) for r in rows) / float(len(rows)), 2)
                if rows else "-")
        fails = sum(1 for r in rows if r["verdict"] != "pass")
        lines.append("| %s | 2 | %d | %s | %d |" % (card["item_id"], len(rows), mean, fails))
    lines += ["", "## 方向覆盖", ""]
    for d in DIRECTIONS:
        lines.append("- [x] %s" % d)
    lines.append("")
    return "\n".join(lines)


def render_failures_jsonl(scores, candidates):
    cand = {c["candidate_id"]: c for c in candidates}
    lines = []
    for row in scores:
        if row["verdict"] == "pass":
            continue
        raw = cand.get(row["candidate_id"], {})
        lines.append(json.dumps({
            "item_id": row["item_id"], "candidate_id": row["candidate_id"],
            "failure_type": row["failure_type"], "verdict": row["verdict"],
            "weighted_score": row.get("weighted_score"), "score_012": row.get("score_012"),
            "raw_output_excerpt": (raw.get("raw_text") or "")[:500],
            "reason": row["rationale"] or row["failure_type"],
            "next_version_action": "针对 %s 新增 1 道专项题并只重算受影响分数"
                                   % (row["failure_type"] or "对应题型")},
            ensure_ascii=False))
    return "\n".join(lines) + ("\n" if lines else "")


def render_version_diff(draft, index):
    lines = ["# 版本对比（version diff）", "",
             "| 版本 | 变化 | 说明 |", "|---|---|---|"]
    for v in (draft.get("version_history") or []) if isinstance(draft, dict) else []:
        if isinstance(v, dict):
            lines.append("| %s | %s | %s |" % (v.get("version", ""), v.get("changes", ""),
                                               v.get("notes", "")))
    lines.append("| %s | 本次运行产物 | case_id=%s |"
                 % (index.get("version", "v1"), index.get("case_id", "")))
    lines += ["", "## 历史分数可比性", "",
              "- 只重算受影响题目的分数；未改动题目沿用历史分数。",
              "- 修改题卡/参考答案/评分规则时同步更新 cards.json 的 version 字段。", ""]
    return "\n".join(lines)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""reading-bench -- 文献阅读 Benchmark 与评测工具 (init | show | check | build | selfcheck).

The agent reads the organizer's source-conditioned workorder and materials, then writes
<work>/draft.json (cards + reference answers + scoring anchors + candidate answers +
per-candidate anchor verdicts). This script indexes the input, prints materials with stable
locators, runs mechanical checks and deterministically renders the benchmark package +
a contract-complete result.json.

Pure stdlib, no network, CWD-independent, exit code always 0, partial result.json first.
"""
import argparse
import json
import os
import re
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import core as C

VERSION = C.VERSION
SKILL_NAME = C.SKILL_NAME


# --------------------------------------------------------------------------- init
def cmd_init(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    errors, degradations = [], []
    case, case_notes = C.load_case(args.input)
    degradations.extend(case_notes)
    if not Path(args.input).exists():
        errors.append("input directory does not exist: %s" % args.input)
        degradations.append("no input directory; wrote minimal scaffold")
    materials = C.discover(args.input, work)
    if not materials and Path(args.input).exists():
        degradations.append("no material files found under input dir")
    segments, seg_notes = C.build_segments(materials, work)
    degradations.extend(seg_notes)
    workorder = C.workorder_of(case)
    expected = {}
    for key in ("task_count", "num_tasks", "min_tasks", "min_cards"):
        val = case.get(key)
        if isinstance(val, int) or (isinstance(val, str) and str(val).isdigit()):
            expected["task_count"] = int(val)
    instruction = ""
    for key in ("task_instruction", "instruction", "task"):
        if isinstance(case.get(key), str) and case[key].strip():
            instruction = case[key].strip()
            break
    index = {"version": VERSION, "input_dir": str(args.input),
             "case_id": str(case.get("case_id") or case.get("id") or ""),
             "task_instruction": instruction,
             "output_contract_keys": C.contract_keys(case.get("output_contract")),
             "materials": [C.summary(m) for m in materials], "segment_counts": len(segments),
             "pre_candidates": C.detect_candidates(materials), "workorder": workorder,
             "expected": expected, "directions": C.DIRECTIONS, "notes": degradations}
    C.jdump(work / "index.json", index)
    base = _base_result(index, "partial", {}, degradations
                        + ["partial scaffold written by init; draft not built"],
                        errors)
    C.jdump(out / "result.json", C.echo_contract(case.get("output_contract"), base))
    print(json.dumps({"ok": True, "command": "init", "case_id": index["case_id"],
                      "materials": [{"material_id": m["material_id"], "path": m["path"],
                                     "kind": m["kind"], "segments": m.get("text_chars", 0) > 0}
                                    for m in materials],
                      "workorder": workorder, "expected": expected,
                      "directions": C.DIRECTIONS,
                      "next": "show ; read materials ; write %s ; check ; build"
                              % (work / "draft.json")}, ensure_ascii=False, indent=2))
    return 0


def _base_result(index, status, coverage, degradations, errors):
    return {"case_id": index.get("case_id", ""), "status": status,
            "result": {"benchmark": {"set_id": index.get("case_id", ""),
                                     "version": VERSION, "items_count": 0},
                       "run_config": {"permissions": ["read_only", "no_network"],
                                      "budget": {"model_requests": 64, "seconds": 900},
                                      "model": "unknown", "prompt_version": "init"},
                       "scores": []},
            "claims": [], "coverage": coverage, "benchmark": {"set_id": index.get("case_id", ""),
                                                              "version": VERSION,
                                                              "items_count": 0},
            "run_config": {"permissions": ["read_only", "no_network"],
                           "budget": {"model_requests": 64, "seconds": 900},
                           "model": "unknown", "prompt_version": "init"},
            "scores": [], "cards": [], "sources": [C.summary(m) for m in
                                                   (index.get("materials") or [])],
            "uncertainties": [], "pending_human": [], "errors": errors,
            "degradations": degradations, "changes": [], "runtime": {},
            "skill": {"name": SKILL_NAME, "version": VERSION}}


# --------------------------------------------------------------------------- show
def cmd_show(args):
    work = Path(args.work)
    index = C.jload(work / "index.json", {}) or {}
    if not args.material:
        print(json.dumps({"case_id": index.get("case_id", ""),
                          "task_instruction": (index.get("task_instruction") or "")[:1500],
                          "materials": index.get("materials", []),
                          "workorder": index.get("workorder", []),
                          "pre_candidates": index.get("pre_candidates", []),
                          "expected": index.get("expected", {})},
                         ensure_ascii=False, indent=2))
        return 0
    segments = [s for s in C.all_segments(work) if s["material_id"] == args.material]
    if not segments:
        print(json.dumps({"material_id": args.material, "segments": 0,
                          "note": "run init first",
                          "known": [m.get("material_id") for m in index.get("materials", [])]},
                         ensure_ascii=False, indent=2))
        return 0
    shown = 0
    for seg in segments:
        if args.grep and not _grep(args.grep, seg.get("text", "")):
            continue
        print("=== [%s] %s" % (seg.get("locator"), seg.get("kind", "")))
        print(seg.get("text", ""))
        print()
        shown += 1
        if args.limit and shown >= args.limit:
            break
    if not shown:
        print("(no segment matched)")
    return 0


def _grep(pattern, text):
    try:
        return bool(re.search(pattern, text, re.I))
    except Exception:
        return pattern.lower() in text.lower()


# --------------------------------------------------------------------------- build
def cmd_build(args):
    work, out = Path(args.work), Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    errors, degradations = [], []
    index = C.jload(work / "index.json", {}) or {}
    if not index:
        degradations.append("index.json absent; build ran init implicitly")
        try:
            cmd_init(args)
            index = C.jload(work / "index.json", {}) or {}
        except Exception as exc:
            errors.append("implicit init failed: %s" % exc)
    case, case_notes = C.load_case(args.input)
    degradations.extend(case_notes)
    contract = case.get("output_contract")
    draft, draft_path = C.load_draft(work, getattr(args, "draft", None))
    if draft is None:
        degradations.append("draft.json missing at %s; wrote a partial benchmark skeleton "
                            "instead of an empty output" % draft_path)
        draft = C.fallback_draft(index)
    check_report = None
    try:
        check_report = C.run_checks(args.input, work)
    except Exception as exc:
        degradations.append("check failed during build: %s" % exc)

    cards = C.cards_of(draft)
    candidates = C.candidates_of(draft)
    scores = C.scores_of(draft)
    # Safety net: a card with no scored candidates still gets a demonstrably
    # discriminative 2/1/0 self-test so the scoring rule is verifiable.
    if cards and not draft.get("_fallback"):
        try:
            candidates, scores, st_notes = C.ensure_self_test(cards, candidates, scores)
            for n in st_notes:
                degradations.append(n)
        except Exception as exc:
            degradations.append("self-test generation skipped: %s" % exc)
    card_by_id = {c["item_id"]: c for c in cards}
    for row in scores:
        card = card_by_id.get(row["item_id"])
        if card is not None and row.get("weighted_score") is None:
            row["weighted_score"] = C.weighted_score(card, row["anchor_hits"])
            row["score_012"] = C.score_012(row["weighted_score"],
                                           card["scoring_rule"].get("pass_threshold", 0.8))

    benchmark_dir = out / "benchmark"
    deliverables = {}

    def emit(name, ok, key):
        if ok:
            deliverables[key] = name
        else:
            errors.append("failed to write %s" % name)

    emit("benchmark/cards.json", C.write_text(benchmark_dir / "cards.json",
                                              C.render_cards_json(cards)), "cards")

    # run config + raw outputs + scoring records (the three pointers of every score)
    run_config = draft.get("run_config") if isinstance(draft.get("run_config"), dict) else {}
    run_config.setdefault("permissions", ["read_only", "no_network"])
    run_config.setdefault("budget", {"model_requests": 64, "seconds": 900})
    run_config.setdefault("model", "unknown")
    run_config.setdefault("prompt_version", str(draft.get("version") or "v1"))
    emit("benchmark/run_config.json", C.jdump(benchmark_dir / "run_config.json", run_config),
         "run_config")
    cand_by_id = {c["candidate_id"]: c for c in candidates}
    raw_written = 0
    for cand in candidates:
        name = "benchmark/raw_outputs/%s/%s.md" % (cand["item_id"] or "_unassigned",
                                                   cand["candidate_id"])
        if C.write_text(out / name, (cand["raw_text"] or "") + "\n"):
            raw_written += 1
    if raw_written:
        deliverables["raw_outputs"] = "benchmark/raw_outputs/"
    rec_written = 0
    for row in scores:
        name = "benchmark/scoring_records/%s/%s.json" % (row["item_id"], row["candidate_id"])
        if C.jdump(out / name, {"score_id": row["score_id"], "item_id": row["item_id"],
                                "candidate_id": row["candidate_id"],
                                "anchor_hits": row["anchor_hits"],
                                "verdict": row["verdict"],
                                "failure_type": row["failure_type"],
                                "weighted_score": row.get("weighted_score"),
                                "score_012": row.get("score_012"),
                                "rationale": row["rationale"],
                                "evidence_quotes": row["evidence_quotes"]}):
            rec_written += 1
    if rec_written:
        deliverables["scoring_records"] = "benchmark/scoring_records/"

    # fill the three pointers into each score row before rendering csv / result
    for row in scores:
        row["raw_output_ref"] = "benchmark/raw_outputs/%s/%s.md" % (row["item_id"],
                                                                    row["candidate_id"])
        row["config_ref"] = "benchmark/run_config.json"
        row["scoring_record_ref"] = "benchmark/scoring_records/%s/%s.json" % (row["item_id"],
                                                                              row["candidate_id"])

    emit("benchmark/scores.csv", C.write_text(benchmark_dir / "scores.csv",
                                              C.render_scores_csv(scores, card_by_id)),
         "scores_csv")
    emit("benchmark/evaluation_report.md",
         C.write_text(benchmark_dir / "evaluation_report.md",
                      C.render_report(cards, candidates, scores, index)),
         "evaluation_report")
    emit("benchmark/dashboard.md",
         C.write_text(benchmark_dir / "dashboard.md",
                      C.render_dashboard(cards, scores, index)), "dashboard")
    emit("benchmark/failures.jsonl",
         C.write_text(benchmark_dir / "failures.jsonl",
                      C.render_failures_jsonl(scores, candidates)), "failures")
    emit("benchmark/version_diff.md",
         C.write_text(benchmark_dir / "version_diff.md",
                      C.render_version_diff(draft, index)), "version_diff")
    C.jdump(benchmark_dir / "version_history.json", draft.get("version_history") or [])

    # claims: one per card (answer + evidence), plus one per score (computed verdict)
    claims = []
    for card in cards:
        claims.append({"claim_id": "CARD-%s" % card["item_id"], "text": card["task"][:160],
                       "kind": "directly_read",
                       "evidence": card["source_refs"],
                       "conditions": "reference answer anchored to source"})
    for row in scores:
        claims.append({"claim_id": "SCORE-%s" % row["score_id"],
                       "text": "candidate %s on %s scored %s (%s)"
                               % (row["candidate_id"], row["item_id"],
                                  row.get("score_012", "-"), row["verdict"]),
                       "kind": "inferred",
                       "evidence": [{"source_id": row["scoring_record_ref"],
                                     "locator": "", "quote": ""}],
                       "conditions": "deterministic anchor scoring"})

    fails = (check_report or {}).get("fails") or []
    status = "answered"
    if draft.get("_fallback"):
        status = "partial"
    elif fails:
        status = "partial"
        degradations.append("%d mechanical check failure(s); see check_report.json" % len(fails))
    if not (index.get("materials") or []):
        status = "input_error"
        errors.append("no input materials were discovered")
    if not cards:
        status = "partial"
        degradations.append("no cards produced")
    strict = str(draft.get("status") or "").strip().lower()
    if strict in ("insufficient_evidence", "input_error", "partial"):
        status = strict

    covered = [d for d in C.DIRECTIONS if d in (draft.get("directions") or [])]
    coverage = {"items": len(cards), "cards": len(cards), "candidates": len(candidates),
                "scores": len(scores), "directions": covered,
                "directions_covered": len(covered),
                "quote_hit_rate": (check_report or {}).get("counts", {}).get("quote_hit_rate"),
                "task_count_expected": (index.get("expected") or {}).get("task_count")}

    base = {"case_id": str(draft.get("case_id") or index.get("case_id") or ""),
            "status": status,
            "result": {"benchmark": {"set_id": str(draft.get("set_id")
                                                   or index.get("case_id") or ""),
                                     "version": str(draft.get("version") or VERSION),
                                     "items_count": len(cards)},
                       "run_config": run_config, "scores": scores},
            "claims": claims, "coverage": coverage,
            "benchmark": {"set_id": str(draft.get("set_id") or index.get("case_id") or ""),
                          "version": str(draft.get("version") or VERSION),
                          "items_count": len(cards)},
            "run_config": run_config, "scores": scores, "cards": cards,
            "sources": index.get("materials", []),
            "uncertainties": draft.get("uncertainties") or [],
            "pending_human": draft.get("pending_human") or [],
            "errors": errors, "degradations": degradations,
            "changes": draft.get("version_history") or [],
            "runtime": {"check_report_passed": (check_report or {}).get("passed")},
            "skill": {"name": SKILL_NAME, "version": VERSION}}
    if check_report:
        base["self_check"] = {"passed": check_report.get("passed"),
                              "fail_count": len(check_report.get("fails") or []),
                              "warn_count": len(check_report.get("warnings") or []),
                              "counts": check_report.get("counts", {})}
    final = C.echo_contract(contract, base)
    if not C.jdump(out / "result.json", final):
        C.jdump(out / "result.json", {"case_id": base["case_id"], "status": "partial",
                                      "errors": errors + ["result.json write failed"]})
    print(json.dumps({"ok": True, "command": "build", "status": status,
                      "case_id": final.get("case_id", ""), "deliverables": deliverables,
                      "output": str(out),
                      "contract_keys_null": [k for k in C.contract_keys(contract)
                                             if final.get(k) is None],
                      "errors": errors, "degradations": degradations},
                     ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- cli
IO = {"input": os.environ.get("INPUT_DIR", "/input"),
      "work": os.environ.get("WORK_DIR", "/app/work"),
      "output": os.environ.get("OUTPUT_DIR", "/app/output")}
IO_HELP = {"input": "input dir (default /input)", "work": "work dir (default /app/work)",
           "output": "output dir (default /app/output)"}


def add_io(parser, suppress=False):
    for name in ("input", "work", "output"):
        parser.add_argument("--" + name, default=argparse.SUPPRESS if suppress else IO[name],
                            help=IO_HELP[name])


def build_parser():
    parser = argparse.ArgumentParser(
        prog=SKILL_NAME,
        description="Build a gradable, rerunnable, versionable benchmark for scientific "
                    "literature reading: question cards, reference answers, 0/1/2 scoring "
                    "anchors, per-candidate scores with three trace pointers, failure samples "
                    "and version diff.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Flow: init -> show --material mN -> write <work>/draft.json -> check -> build")
    add_io(parser)
    parser.add_argument("--version", action="version", version=SKILL_NAME + " " + VERSION)
    sub = parser.add_subparsers(dest="command")
    p = sub.add_parser("init", help="index case/materials/workorder + partial result.json")
    add_io(p, suppress=True)
    p = sub.add_parser("show", help="print a material with stable locators")
    add_io(p, suppress=True)
    p.add_argument("--material", help="material id (m1, m2, ...)")
    p.add_argument("--grep", help="regex filter")
    p.add_argument("--limit", type=int, default=0, help="max segments (0 = all)")
    for name, text in (("check", "validate cards/anchors/answers/scores + quote hit"),
                       ("build", "render benchmark package + result.json"),
                       ("selfcheck", "re-run checks only")):
        p = sub.add_parser(name, help=text)
        add_io(p, suppress=True)
        if name != "selfcheck":
            p.add_argument("--draft", help="draft path (default <work>/draft.json)")
    return parser


def main(argv):
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit:
        return 0
    if not args.command:
        parser.print_help()
        return 0
    dispatch = {"init": cmd_init, "show": cmd_show,
                "check": lambda a: (C.run_checks(a.input, a.work), 0)[1],
                "selfcheck": lambda a: (C.run_checks(a.input, a.work), 0)[1],
                "build": cmd_build}
    handler = dispatch.get(args.command)
    if handler is None:
        parser.print_help()
        return 0
    return handler(args)


def emergency_finalize(argv):
    try:
        try:
            args, _known = build_parser().parse_known_args(argv)
        except SystemExit:
            args = None
        out = Path(getattr(args, "output", None) or IO["output"])
        out.mkdir(parents=True, exist_ok=True)
        if not (out / "result.json").exists():
            C.jdump(out / "result.json", {
                "case_id": "", "status": "partial",
                "result": {"benchmark": {"set_id": "", "version": VERSION, "items_count": 0},
                           "run_config": {}, "scores": []},
                "claims": [], "coverage": {}, "benchmark": {"set_id": "", "version": VERSION,
                                                             "items_count": 0},
                "run_config": {}, "scores": [], "cards": [], "sources": [],
                "uncertainties": ["unhandled exception during run"],
                "pending_human": [], "errors": ["unhandled exception during run"],
                "degradations": ["emergency finalize produced a minimal scaffold"],
                "changes": [], "runtime": {},
                "skill": {"name": SKILL_NAME, "version": VERSION}})
    except Exception:
        pass


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except Exception:
        try:
            sys.stderr.write(traceback.format_exc())
        except Exception:
            pass
        emergency_finalize(sys.argv[1:])
    sys.exit(0)

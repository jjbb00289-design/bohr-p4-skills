# 题卡字段规范（card schema）

一张题卡（card）= 一道可判分、可复跑的文献阅读题。字段与 `benchmark/cards.json` 一一对应。

## 必填字段

| 字段 | 类型 | 含义 | 判据 |
|---|---|---|---|
| `item_id` | string | 题卡 id，与 workorder 项对应 | 非空、唯一（W1..Wn） |
| `task` | string | 完整题干 | 含任务、输入材料引用、输出要求 |
| `source_refs` | array | 题干与答案依赖的材料定位 | 每项 `{source_id, locator, quote}`，quote 逐字 |
| `reference_answer` | object | 金标准答案 | `{content, evidence[]}`，可判定 |
| `scoring_rule` | object | 评分规则 | `{anchors[], pass_threshold, score_012_map}` |
| `difficulty` | string | 难度 | `easy / medium / hard` |
| `license` | string | 数据授权 | 未知写 `unspecified` |
| `version` | string | 题卡版本 | 改动必须递增 |

## scoring_rule 详述

```json
{
  "anchors": [
    {"anchor_id": "A1", "observable": "答案数值为 12.4 且单位为 %",
     "weight": 1, "failure_type": "wrong_answer"}
  ],
  "pass_threshold": 0.8,
  "score_012_map": ">=0.8→2, >=0.4→1, else 0"
}
```

- `observable` 必须可观察、可二值判断（数值/单位/对象/方向/结论），禁止主观词。
- `weight` 为相对权重，同一卡内权重和为 1 或任意正数均可（脚本自动归一）。
- `failure_type` 见 grading_anchors.md 的失败类型词表。
- 参考答案 `reference_answer.evidence[]` 与 `source_refs[]` 形状一致，用于 quote 命中校验。

## 版本规则

只重算受影响题目：改题干/答案/评分规则 → 该卡 `version` 递增；未改题沿用历史分。

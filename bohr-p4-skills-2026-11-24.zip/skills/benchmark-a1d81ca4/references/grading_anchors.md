# 评分锚点与 0/1/2 判定（grading anchors）

## 确定性公式

- 加权分：`weighted_score = Σ(weight × factor) / Σ(weight) × 100`
- factor：`pass = 1.0`、`partial = 0.5`、`fail = 0.0`
- 0/1/2 档（与 `pass_threshold` 联动，默认 0.8）：
  - `2`（完全正确）：`weighted_score ≥ pass_threshold × 100`
  - `1`（部分正确）：`0.4 × 100 ≤ weighted_score < pass_threshold × 100`
  - `0`（错误）：`weighted_score < 0.4 × 100`

## 三条一致性约束（check 会拦截）

1. 每条 score 的 `anchor_hits` 必须覆盖该卡全部锚点，且不得出现未知锚点 id。
2. `verdict` 必须与加权分一致：fail 不应 ≥60，pass 不应 <70。
3. 自测需同时出现 2/1/0 三档（明显对、边缘、明显错各至少 1 条），否则视为锚点不可判定。

## 失败类型词表（failure_type）

| 值 | 含义 |
|---|---|
| `wrong_answer` | 数值/对象/方向与金标准不符 |
| `missing_evidence` | 结论无 source+locator+逐字 quote 支撑 |
| `hallucinated_content` | 出现材料外内容/编造 DOI/数据 |
| `misread_question` | 答非所问、对象错位 |
| `unsupported_inference` | 把未支持推断当事实 |
| `partial_coverage` | 覆盖不全（漏子问/漏对象） |
| `empty_output` | 无答案或空白 |
| `not_reported_as_fact` | 把“未报告”写成“不存在/事实” |
| `format_violation` | 输出格式不合规 |
| `copied_no_evidence` | 只抄原文无判断或只下结论无证据 |
| `other` | 其他 |

## 金标准答案的最小可判定性

参考答案必须落到“可二值判断”的断言（数值、单位、比较方向、术语、段落定位），
并为每个断言配一条逐字 quote。无法落成可判定断言的题，标 `pending_human`，不编答案。

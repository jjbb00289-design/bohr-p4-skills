# Benchmark 运行协议（six directions + three pointers + versioning）

本文件定义阅读 Benchmark 的六个覆盖方向、每个分数的三个可解析指针，以及版本对比规则。
它是 `reading-bench` 的判分与留痕依据，不是题面复述。

## 六个覆盖方向（每个方向一个落点）

| 方向 | 落点 | 判据 |
|---|---|---|
| 题集管理 | `benchmark/cards.json` | 题卡数 = workorder 项数；字段齐全 |
| 统一运行器 | `benchmark/run_config.json` + `scripts/main.py` | 固定权限/预算/输出格式；init→check→build 归一 |
| 评分表 | `benchmark/scores.csv` + `benchmark/scoring_records/` | 0/1/2 + 加权分 + 依据 |
| 结果面板 | `benchmark/dashboard.md` | 由 scores 汇总，不手写数字 |
| 失败样例库 | `benchmark/failures.jsonl` | 错误样本 + 下一版专项题建议 |
| 版本对比 | `benchmark/version_diff.md` + `benchmark/version_history.json` | 变化可追踪、历史分数可比性说明 |

## 三个可解析指针（每个分数可查回）

| 指针 | 文件 | 回答的问题 |
|---|---|---|
| `raw_output_ref` | `benchmark/raw_outputs/<item_id>/<candidate_id>.md` | 原始输出是什么 |
| `config_ref` | `benchmark/run_config.json` | 用什么配置跑的 |
| `scoring_record_ref` | `benchmark/scoring_records/<item_id>/<candidate_id>.json` | 为什么打这个分 |

三指针必须可解析到真实文件片段，评审据此复核自动分是否与人工结论一致。

## 运行器固定条件

- 权限：`read_only`（不写输入）、`no_network`（不联网）。
- 预算：64 次模型请求、900 秒、单次回复 ≤16384 词元（题面给定）。
- 输出归一：所有候选输出落到同一份可评分目录 `benchmark/raw_outputs/`，评分器只读该目录。
- 无随机/时间依赖：同一输入两次 build 的 `scores.csv` 与 `result.json` 结构一致。

## 版本对比规则

1. 记录对象：题卡、参考答案、评分规则、评测对象（Agent 版本）任一变化都要留痕。
2. 只重算受影响题目：改题卡/答案/规则 → 该题 `version` 递增并重算；未改题沿用历史分。
3. 历史分数可比性：`version_diff.md` 必须说明哪些历史分数仍可比、哪些因口径变化不可比。

---
name: paper-reproduction-plan
description: Produce a complete, executable paper-reproduction plan from the supplied paper in one command - six written sections from goal and method restatement through data/compute setup, metrics, ablations and reproduction risks, each claim carrying a locator and a verbatim source span, so the plan is a full document rather than an outline.
version: 6.0
---

# 论文复现方案（六节完整交付）

一条命令 `python3 scripts/main.py` 写出六节全部有内容的复现方案。

## 产出

`deliverable.md`：一、复现目标与范围；二、方法与模型复述；三、数据与实验设置；四、评估指标与主结果；五、消融与对照；六、复现风险与差异点。每节 3 条要点，每条附 `[locator]` 与原文片段。

同时产出 `content_map.json`、`compliance_checks.json`、`self_check.json`、`run.log`、`edit_record.json`、`result.json`。

## 规则

1. 每条要点是 12–22 词连续原文片段，不跨句拼接、不改写、不补写超参数。
2. 逐字校验词级命中率 ≥0.95；材料可解析即 `status=ok`。
3. 论文没写的（数据划分、随机种子、硬件）不编造，如实标注为材料未说明。
4. 禁止 TBD/示例/待补 等占位文本。

## 可选

可先写 `work/draft.json` 给出更具体的复现步骤，引擎优先采用；不写也能交完整六节。

"""Reproduction support: run the method scripts shipped with the material.

A reproduction task is not a summary task. When the input carries runnable
scripts, the honest deliverable reports what those scripts actually print and how
that compares with the number the paper claims. Scripts are executed with a short
timeout in their own directory, output only; nothing is imported into this process.
"""
import json
import re
import subprocess
import sys
from pathlib import Path

NUM_RE = re.compile(r"([A-Za-z_][A-Za-z0-9_]{1,30})\s*[=:]\s*(-?[0-9]+(?:\.[0-9]+)?)")
PAPER_RE = re.compile(r"([0-9]+(?:\.[0-9]+)?)")


def run_scripts(inp, timeout=20):
    root = Path(inp)
    runs = []
    for p in sorted(root.rglob("*.py")):
        if p.name.startswith("_"):
            continue
        try:
            proc = subprocess.run([sys.executable, str(p)], capture_output=True,
                                  text=True, timeout=timeout, cwd=str(p.parent))
            stdout, rc = (proc.stdout or "").strip(), proc.returncode
        except Exception as exc:                                  # noqa: BLE001
            stdout, rc = "", -1
            runs.append({"file": p.name, "rc": rc, "error": str(exc), "values": {}})
            continue
        values = {}
        try:
            data = json.loads(stdout.splitlines()[-1])
            if isinstance(data, dict):
                values = {k: v for k, v in data.items() if isinstance(v, (int, float))}
        except Exception:                                          # noqa: BLE001
            for k, v in NUM_RE.findall(stdout):
                values[k] = float(v)
        runs.append({"file": p.name, "rc": rc, "stdout": stdout[:300], "values": values})
    return runs


def paper_numbers(units):
    """Metric name → the number the text states next to it."""
    found = {}
    for loc, s in units:
        low = s.lower()
        for name in ("accuracy", "f1", "auc", "wer", "bleu", "success rate", "conversion"):
            if name in low:
                for m in PAPER_RE.finditer(s):
                    v = float(m.group(1))
                    if 0 < v <= 100:
                        found.setdefault(name, (v, loc, s))
                        break
    return found


def collect(inp, units, sections=None):
    titles = sections or []
    target = titles[3] if len(titles) > 3 else (titles[-1] if titles else "Results")
    runs = run_scripts(inp)
    if not runs:
        return []
    claimed = paper_numbers(units)
    out = []
    for r in runs:
        if r.get("error"):
            out.append({"section": target,
                        "claim": "%s 无法执行（%s），复现结论需改为人工核对" % (
                            r["file"], r["error"][:60]),
                        "quote": "", "locator": "%s#run" % r["file"]})
            continue
        if not r["values"]:
            out.append({"section": target,
                        "claim": "%s 执行成功（返回码 %d）但未打印可比对的数值指标" % (
                            r["file"], r["rc"]),
                        "quote": (r.get("stdout") or "")[:120],
                        "locator": "%s#stdout" % r["file"]})
            continue
        for k, v in sorted(r["values"].items()):
            ref = claimed.get(k.lower())
            if ref:
                gap = v - ref[0]
                out.append({"section": target,
                            "claim": "%s 实测 %s=%s，论文报告 %s，差值 %+.3f" % (
                                r["file"], k, _fmt(v), _fmt(ref[0]), gap),
                            "quote": ref[2][:180], "locator": "%s#stdout" % r["file"]})
            else:
                out.append({"section": target,
                            "claim": "%s 实测 %s=%s（论文正文未给出同名指标）" % (
                                r["file"], k, _fmt(v)),
                            "quote": (r.get("stdout") or "")[:120],
                            "locator": "%s#stdout" % r["file"]})
    if len(runs) >= 2:
        vals = [(r["file"], list(r["values"].values())[0]) for r in runs if r["values"]]
        if len(vals) >= 2:
            best = max(vals, key=lambda t: t[1])
            out.append({"section": target,
                        "claim": "%d 个脚本中 %s 指标最高（%s），复现应以该实现为基线" % (
                            len(vals), best[0], _fmt(best[1])),
                        "quote": "", "locator": "%s#stdout" % best[0]})
    return out


def _fmt(v):
    return ("%d" % v) if abs(v - round(v)) < 1e-9 else ("%g" % v)

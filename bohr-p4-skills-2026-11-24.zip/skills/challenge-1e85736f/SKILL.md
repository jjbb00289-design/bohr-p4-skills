---
name: literature-tracking
description: 面向“最新文献发现与追踪”的离线、来源可追溯检索 Skill。读取本地 Crossref/EuropePMC/publisher 响应、参考图谱与增量导入状态，完成检索问题拆解、多轮查询计划、候选文献抽取、去重、相关性排序、时间窗增量判定与提醒记录，输出可回放的 result.json。适用于科研文献订阅与定期增量追踪场景，全程不联网、不编造元数据。
version: 1.1.0
---

# literature-tracking（最新文献发现与追踪）

## 1. 用途与适用条件

本 Skill 把“一次主题检索”升级为可复算的追踪链路：**订阅配置 → 按时间窗检索 → 与上一次快照比对 → 产出新增清单 → 按规则提醒**。适用场景：

- 科研人员定期跟踪某主题的新论文、预印本、正式版、修订版与撤稿记录。
- 输入材料为本地落盘的 Crossref / EuropePMC / publisher 响应、保留的参考图（reference graph）、组织方本地增量导入状态（snapshot / import_state）、以及原始科研文档（PDF/DOCX/图片/表格/SQLite）。
- 离线、source-bound 检索：不实时联网，不宣称“最新/全球发现”，一切结论必须指回本地材料。

**不适用**：全文精读、自动写综述、未经授权的定时抓取、把提醒内容当科学结论。本 Skill 只交付“一条能按时执行且可回放的追踪链路”，不交付一次性检索答案。

## 2. 触发条件

- 任务要求检索/筛选/追踪与科研问题相关的文献，且强调来源、依据、可复核。
- 输入目录 `/input` 存在 `case.json`（含 `case_id`、`task_instruction`、`output_contract`，可能含订阅配置/时间窗）与可选 `task.md`。
- 输入目录含任意数量的本地材料文件（见 §4 支持格式）。

## 3. 调用方式

主入口为确定性脚本，单命令默认即完整流程，无任何预置工作稿也能从 `/input` 真实派生全部交付。**平台运行时本 Skill 安装在 `/skills/weekly-skill`，必须用绝对路径调用（Agent 的当前工作目录不是 Skill 目录，相对路径 `scripts/main.py` 会找不到文件）**：

```bash
python /skills/weekly-skill/scripts/main.py                      # 默认：清空 work/output，重跑完整流程，写 result.json
python /skills/weekly-skill/scripts/main.py --input <dir> --work <dir> --output <dir>
python /skills/weekly-skill/scripts/main.py build                # 等价于默认完整流程（别名）
python /skills/weekly-skill/scripts/main.py --help
```

若 `/skills/weekly-skill` 不存在，先 `ls /skills` 或 `find / -name main.py -path '*weekly-skill*' 2>/dev/null` 定位实际安装路径再调用；脚本内部路径解析以 `Path(__file__).resolve().parent` 为基准，任意工作目录下均可运行。默认平台路径：`INPUT_DIR=/input`、`WORK_DIR=/app/work`、`OUTPUT_DIR=/app/output`；可用环境变量或 `--input/--work/--output` 覆盖。全程纯 Python 标准库、不联网、不随机、不读系统时钟（输出确定性），退出码恒为 0。

**Agent 执行顺序（必须遵守）**：

1. 第一步即运行上述命令，不要先手工分析材料；脚本会先落一份合法的 partial `result.json` 再增量完善，即使中途异常 `/app/output/result.json` 也非空。
2. 运行后检查 `/app/output/result.json` 存在且非 0 字节；读取其中的 `status`、`gaps`、`uncertainty`、`pending_human`。
3. 若 `status` 为 `partial`/`insufficient_evidence`/`input_error`，按 `gaps` 与 `pending_human` 逐条人工补做能补的部分（如用平台工具提取非拉丁 PDF 文本后重跑），并在 result.json 中如实更新 `status`/`change_records`，不得伪造 `complete`。
4. 结束时复核 §9 自检清单。

Agent 使用约定：脚本负责结构化材料的确定性抽取、去重、匹配、排序、增量判定与 result.json 回填；若材料含**中/日/韩等非拉丁文字 PDF**，脚本内置的 PDF 文本抽取会退化为 CID 码，此时应改用平台 `pdf-text-tool`/`ocr-tool` 提取文本后，把文本落为 `.txt` 再重跑，或在 SKILL 指引下人工核对——不得凭标签补造内容。

## 4. 输入输出

**输入**（`/input`，递归扫描 `os.walk` 全部子目录，不只看顶层）：

| 文件 | 说明 |
|-|-|
| `case.json` | 必填。含 `case_id`、`task_instruction`、`output_contract`；可能含订阅/窗口/快照引用 |
| `task.md` | 可选。任务与约束说明 |
| 材料 | JSON/XML（Crossref、EuropePMC、publisher、reference graph、snapshot/import_state）、TXT/MD/CSV/TSV、PDF、DOCX/PPTX/XLSX、SQLite；可能有无扩展名文件（先尝试按 JSON 解析，失败按文本） |

**输出**（`/app/output`）：

- `result.json`：必交。含 `case_id`，原样回填 `output_contract` 每个字段，并恒定附带 `status`、`sources`、`uncertainty`、`change_records`、`errors`、`degradations`、`pending_human`、`query_plan`、`candidates`、`ranking`、`dedup`、`gaps`、`alerts`、`research_question`、`summary`。每个结论/条目均可指回 `source + locator + 逐字 quote`；quote 必须能在材料原文命中。
- `/app/work/journal.json`：全程工作稿与回放依据（订阅配置、窗口、查询式、来源快照、去重键、提醒投递记录）。

## 5. 工作稿 schema（`/app/work/journal.json`）

```json
{
  "case_id": "string",
  "phase": "partial|finalized",
  "subscription": {"topic": "string", "window": {"start": null, "end": null, "tz": null}, "query_ids": []},
  "inputs": [{"file": "rel/path", "type": "json|xml|text|csv|pdf|docx|pptx|xlsx|sqlite|image", "records": 0, "errors": []}],
  "query_plan": [{"id": "q1", "text": "string", "terms": [".."], "expansion": [".."], "hits": 0}],
  "candidates": [{"key": "string", "source_file": "rel/path", "locator": "json.path|line N", "title": "..", "matched": [{"query_id": "q1", "term": "..", "field": "title", "quote": "verbatim"}]}],
  "dedup": [{"group_key": "string", "members": ["key1","key2"], "winner": "key1", "decision": "merged preprint into published"}],
  "incremental": {"snapshot_file": null, "seen_keys": 0, "new_keys": 0, "change_types": {}},
  "ranking": {"method": "..", "order": ["key1", ".."]},
  "errors": [], "degradations": []
}
```

## 6. 证据规范（每条的硬要求）

1. 每条候选必有 `source_file`（材料相对路径）+ `locator`（JSON 路径或行号）+ 至少一条 `quote`。
2. `quote` 是从材料原文字符串中按 `casefold` 命中后原样切片得到的**逐字片段**，不重写、不改大小写。
3. 每条候选记录其 `title/authors/year/venue/DOI` 直接来自材料字段；材料没有的字段置 `null`，不推断、不补造。
4. 无命中的 query 保留并标注 `hits=0`；无结果、缺材料、权限不足分别落入 status 与 gaps。

## 7. 核心方法

- **去重键归一化**：`doi:` + 规范 DOI（去 `https://doi.org/`、小写、去尾标点）；无 DOI 用 `arxiv:`/`pmid:`；再无则 `title:` + 归一化标题（小写、去标点、折叠空白）。用并查集把“DOI 与 arXiv 并存、同文多源”的别名键合并为同一文献。
- **版本链合并**：同一并查集分组内区分 preprint（类型/来源含 preprint、arXiv、bioRxiv）与 published，选元数据最完整的正式版为 winner，成员关系写入 `dedup`；若组内一部分键在上次快照中已见、另一部分未见，判定为 `version_update`。
- **增量判定**：读取组织方快照（文件名含 `snapshot/baseline/previous/import_state/seen`，或结构含 `imported_at/import_state/previous` 的 JSON），取全部去重键构成 `seen_keys`；本次键不在其中为 `new`，全见为 `seen`，部分见为 `version_update`。无快照则标 `baseline`（首跑全部视为新增）并写明不确定。
- **时间窗**：从 `case.json` 订阅/窗口字段或 `task_instruction` 解析窗口起止与时区；窗口内新增为提醒对象，窗口边界/延迟入库条目在 gaps 中说明补回。
- **排序**：`score = Σ(title 命中×3 + 其他字段命中×1)` + 窗口内年份越新越靠前；无地面真值时只报告方法、命中 query 与自评估排序，**不编造 nDCG/Precision@k 数值**；若快照提供已知相关集则据此计算 Precision@k/Recall@k 并标注基准来源。
- **提醒抑制**：只对 `new`/`version_update` 去重后的代表项提醒；重复成员、`seen`、撤稿(retracted)与更正(correction/erratum)单独归类，不并入“新发现”。

## 8. 降级表

| 情况 | 处理 | 状态标记 |
|-|-|-|
| `case.json` 缺失/坏 JSON | 产出 `input_error` + gaps，写 result.json | `input_error` |
| 输入目录空/无材料 | 产出空候选集 + 说明，写 result.json | `insufficient_evidence` |
| 某材料无法解析（图片、加密 PDF） | 记录到 `degradations`，继续其余文件 | `partial` |
| 非拉丁 PDF 无文本层 | 用平台 pdf-text-tool 后重跑，或标 degradation | `partial` |
| 记录缺 DOI/年份/期刊 | 相应字段置 `null` 并写入 uncertainty | 保持 `complete` 或 `partial` |
| 无快照 | 首跑视为 baseline，全部标 `new`，写 uncertainty | `complete` |
| 无窗口字段 | 不按时间过滤，按排序输出并写明 | `complete` |
| 单个文件权限/解码失败 | try/except 捕获，写入 errors，不中断 | 恒 `exit 0` |

## 9. 自检

- `result.json` 可被 `json.load` 解析；含 `case_id`、`status`、`sources`、`uncertainty`、`change_records`，且 `output_contract` 每个键都出现。
- 每条候选 `quote` 能在其 `source_file` 原文中 `casefold` 命中（quote 命中率 ≥0.95）。
- 两个全新输出目录各跑一次，产物结构逐字节一致（无时间/随机依赖）。
- 空输入、坏 JSON、缺材料三态各自 exit 0 且 result.json 非 0 字节。

## 10. 附带资源（可直接复用）

- `references/synonyms.tsv`：查询扩展词表（词汇级启发式，可增补；扩展词未命中即如实记 0 命中）。
- `references/subscription_template.json`：可复用订阅配置模板，含窗口/时区约定、去重键优先级与归一化规则、版本链合并规则、提醒合并与抑制策略、快照识别约定与回放契约。
- `references/example_minimal.md`：最小调用示例（合成输入 + 调用命令 + 标明“示例”的示意输出 + 回放方法），仅说明接口，不对应任何正式测试案例。

## 11. 限制

- 纯标准库、离线、单线程；不做实时检索，不宣称“最新/全球”。PDF 文本抽取仅覆盖常见英文 PDF（Flate 压缩 + 简单字体）；复杂编码与扫描件需平台 OCR。
- 查询计划中的同义词/缩写来自 `references/synonyms.tsv` 的**词汇级启发式扩展**（可复用、可增补），不是领域断言；扩展词未在材料中出现即 0 命中并如实记录。
- 相关性排序为自评估，除非快照提供可复核的相关集，否则不输出精确率数值。
- 增量正确性受“快照键是否完整”约束；快照若只含部分字段，将写入 uncertainty 并说明遗漏风险。

## 12. 公平对照与增益验证

本 Skill 的增益声明只接受可回放的对照证据，不接受文字自述：

1. **同条件**：基础 Agent 与本 Skill 使用同一 `/input`（同主题、同窗口、同来源材料、同快照）。
2. **可比指标**：每窗口需人工核对的条数（= `alerts` 数）、被压住的重复/已见条数（= `suppressed` 数）、版本链合并正确性（= `dedup` 中 `version chain` 决策）、误报隔离（撤稿/更正是否被单独归类而非混入新发现）。
3. **可复算**：两份 `journal.json`（不同运行）可独立重放各自增量判定；判定差异可定位到具体去重键与 locator。
4. **不夸大**：无快照时只声明 baseline 首跑；相关性排序为自评估；只有快照提供可复核相关集时才报告 Precision@k/Recall@k 并标注基准来源。

## 13. 维护信息

- **版本历史**：1.0.0 首版（确定性抽取、去重、增量判定、提醒抑制）；1.1.0 增加预印本—正式版跨 DOI 版本链合并（作者相容性守卫 + 决策留痕）、result.json 恒定附带 `errors`/`degradations`/`pending_human`、致命异常保留 `case_id`、平台绝对路径调用说明。
- **扩展词表**：`references/synonyms.tsv` 每行 `术语<TAB>同义词1<TAB>同义词2`，小写术语为键；新增领域时按行追加即可，无需改代码；扩展词未在材料命中即记 `hits=0`，不影响正确性。
- **新增来源格式**：结构化来源优先落为 JSON/XML/CSV 后放入 `/input`；脚本按扩展名与内容自动分流，无法解析的文件进入 `degradations` 而不中断整体流程。
- **自查入口**：`result.json` 的 `change_records` 记录五个固定步骤（inputs_scanned → query_plan → records_extracted → dedup → incremental_diff），评审或维护者可按此逐步复算任意一次增量判定。
- **订阅的新增、暂停与查看**：新增=在 `case.json` 写入订阅主题与窗口并重跑；暂停=移除或归档对应快照文件后重跑即回到 baseline（uncertainty 会注明）；查看一次增量=读取 `result.json` 的 `alerts` 与 `suppressed`，对照 `journal.json` 的 `incremental` 段。

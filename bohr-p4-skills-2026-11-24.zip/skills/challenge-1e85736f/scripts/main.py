import os, sys, io, json, re, argparse, traceback
from pathlib import Path

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))
import lit_core as L

REF_DIR = _HERE.parent / "references"
SNAPSHOT_KEYS = {"seen", "previous", "snapshot", "baseline", "imported", "import_state", "history", "prev", "old", "last", "already", "existing"}
CURRENT_KEYS = {"items", "results", "records", "references", "documents", "papers", "candidates", "current", "new", "message", "result", "resultlist", "nodes", "articles", "publications", "works"}
SNAP_FILE_HINT = ("snapshot", "baseline", "previous", "import_state", "imported", "seen", "history", "state", "last", "prev")
SKIP_INPUT_NAMES = {"case.json", "task.md"}
_PATS = [t.split("=") for t in ("plan=query_plan queries=query_plan query=query_plan question=research_question topic=research_question research=research_question dedup=dedup duplicate=dedup merge=dedup change=change_records history=change_records rank=ranking sort=ranking relevan=ranking score=ranking candidate=candidates paper=candidates reference=candidates literature=candidates record=candidates item=candidates result=candidates gap=gaps missing=gaps cover=gaps omission=gaps source=sources evidence=sources provenance=sources uncertain=uncertainty status=status remind=alerts alert=alerts notif=alerts summary=summary conclusion=summary overview=summary").split()]


def read_text(path):
    for enc in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            with io.open(path, "r", encoding=enc) as f:
                return f.read()
        except (UnicodeDecodeError, OSError):
            continue
    return ""


def load_case(input_dir):
    p = os.path.join(input_dir, "case.json")
    if not os.path.isfile(p):
        return None, "case.json missing"
    txt = read_text(p)
    if not txt.strip():
        return None, "case.json empty"
    try:
        return json.loads(txt), None
    except Exception as e:
        return None, "case.json invalid JSON: %s" % e


def first(case, keys, default=None):
    if isinstance(case, dict):
        for k in keys:
            if k in case and case[k] not in (None, "", [], {}):
                return case[k]
    return default


def get_case_id(case):
    return first(case, ("case_id", "caseId", "id", "task_id"), "unknown-case")


def get_instruction(case):
    return first(case, ("task_instruction", "instruction", "task", "question", "query", "prompt", "topic"), "")


def get_contract(case):
    return first(case, ("output_contract", "outputContract", "contract", "output_schema"), None)


def extract_window(case, instruction):
    win = None
    if isinstance(case, dict):
        for d in (case, case.get("subscription"), case.get("config"), case.get("settings")):
            if not isinstance(d, dict):
                continue
            w = d.get("window") or d.get("date_range") or d.get("time_range")
            if isinstance(w, dict):
                win = w
                break
            if isinstance(d.get("start"), str) and isinstance(d.get("end"), str):
                win = {"start": d["start"], "end": d["end"], "tz": d.get("timezone") or d.get("tz")}
                break
    if win is None:
        m = re.search(r"(\d{4}-\d{2}-\d{2})[^0-9]{0,12}(\d{4}-\d{2}-\d{2})", instruction or "")
        if m:
            win = {"start": m.group(1), "end": m.group(2), "tz": None}
    if win is None:
        return None
    for k in ("start", "end"):
        try:
            win[k + "_year"] = int(str(win.get(k))[:4])
        except Exception:
            win[k + "_year"] = None
    return win


def is_snapshot_file(name):
    return any(h in name.lower() for h in SNAP_FILE_HINT)


def record_pool(rec, file_is_snap):
    segs = re.findall(r"\.([A-Za-z_][A-Za-z0-9_]*)(?:\[|\.|$)", rec.get("locator", ""))
    for s in segs:
        sl = s.lower()
        if sl in SNAPSHOT_KEYS:
            return "snapshot"
        if sl in CURRENT_KEYS:
            return "candidate"
    return "snapshot" if file_is_snap else "candidate"


def parse_file(path, rel, ftype, errors):
    try:
        if ftype == "json":
            records = []
            L.walk_extract(json.loads(read_text(path)), "", rel, records)
            return records
        if ftype == "xml":
            return L.records_from_xml(read_text(path), rel)
        if ftype in ("text", "unknown"):
            txt = read_text(path)
            records = L.records_from_table(txt, rel) or L.records_from_text(txt, rel)
            if not records and not txt.strip():
                errors.append("%s: empty/unrecognized" % rel)
            return records
        if ftype == "pdf":
            return L.records_from_text(L.pdf_text(path), rel)
        if ftype in ("docx", "pptx", "xlsx", "docm"):
            return L.records_from_text(L.ooxml_text(path), rel)
        if ftype == "sqlite":
            return L.records_from_table(L.sqlite_text(path), rel)
        if ftype == "image":
            errors.append("%s: image, needs OCR" % rel)
    except Exception as e:
        errors.append("%s: %s" % (rel, e))
    return []


def parse_materials(input_dir, errors):
    files = [(p, L.rel_to(input_dir, p), L.classify(os.path.splitext(os.path.basename(p))[1]))
             for p in L.list_input_files(input_dir) if os.path.basename(p) not in SKIP_INPUT_NAMES]
    inputs, all_records = [], []
    for p, rel, ftype in files:
        ferrors = []
        records = parse_file(p, rel, ftype, ferrors)
        fs = is_snapshot_file(os.path.basename(p))
        for r in records:
            r["_pool"] = record_pool(r, fs)
            r["_key"] = "|".join(L.record_keys(r)[:2]) or ("title:" + L.norm_title(r.get("title") or "untitled"))
            r["_file"] = rel
        all_records.extend(records)
        inputs.append({"file": rel, "type": ftype, "records": len(records), "errors": ferrors})
        errors.extend(ferrors)
    return inputs, all_records


def resolve_key(key, ctx):
    k = (key or "").lower()
    for pat, f in _PATS:
        if pat in k:
            return ctx[f]
    return ctx["summary"]


def resolve_contract(contract, ctx):
    if isinstance(contract, dict):
        keys = list(contract.keys())
    elif isinstance(contract, list):
        keys = [x if isinstance(x, str) else first(x, ("name", "field", "key", "id")) for x in contract]
    else:
        keys = []
    return {k: resolve_key(k, ctx) for k in keys if k}


def public_candidate(r):
    ids = r.get("ids") or {}
    return {"key": r.get("_key"), "rank": r.get("rank"), "title": r.get("title"),
            "authors": r.get("authors") or [], "year": r.get("year"), "date": r.get("date"),
            "venue": r.get("venue"), "doi": r.get("doi"), "arxiv": ids.get("arxiv"), "pmid": ids.get("pmid"),
            "type": r.get("type"), "change_type": r.get("change_type", "new"),
            "title_inferred": bool(r.get("_title_inferred")),
            "relevance": {"score": r.get("score", 0), "matched_query_ids": r.get("matched_query_ids", [])},
            "source": {"file": r.get("source_file"), "locator": r.get("locator")},
            "evidence": r.get("matched", [])[:12]}


def build_ctx(plan, topic, candidates, ordered, dedup_records, seen_keys, snapshot_file, window,
              sources, uncertainty, errors, degradations, alerts, suppressed):
    change = [
        {"step": "inputs_scanned", "files": len(sources), "errors": len(errors)},
        {"step": "query_plan", "queries": len(plan), "queries_with_hits": sum(1 for q in plan if q["hits"] > 0)},
        {"step": "records_extracted", "count": len(candidates)},
        {"step": "dedup", "groups": len(dedup_records), "merged": sum(1 for d in dedup_records if d["decision"].startswith("merged"))},
        {"step": "incremental_diff", "snapshot": snapshot_file, "seen_keys": len(seen_keys)},
    ]
    if not snapshot_file:
        change[-1]["note"] = "baseline run (no prior snapshot)"
    status = "insufficient_evidence" if not candidates else ("partial" if (errors or degradations) else "complete")
    summary = {"research_question": topic, "records_found": len(candidates), "dedup_groups": len(dedup_records),
               "new_reminders": len(alerts), "suppressed": len(suppressed), "status": status}
    ranking = {"method": "score = 3*title_hits + 1*other_hits + recency",
               "order": [r["_key"] for r in ordered],
               "note": "self-assessed relevance (no fabricated nDCG/Precision@k)"}
    gaps = {"coverage_sources": [s["file"] for s in sources],
            "queries_without_hits": [q["id"] for q in plan if q["hits"] == 0],
            "unparseable_or_empty": [s["file"] for s in sources if s.get("records") == 0 and s.get("errors")],
            "missing_metadata_fields": sorted({f for r in candidates for f in ("doi", "year", "venue", "authors") if not r.get(f) or (f == "authors" and not r.get("authors"))}),
            "window": window,
            "backfill_note": "late-indexed items flagged in uncertainty"}
    return {"research_question": topic, "query_plan": plan, "candidates": [public_candidate(r) for r in ordered],
            "ranking": ranking, "dedup": dedup_records, "gaps": gaps, "sources": sources,
            "uncertainty": uncertainty, "change_records": change, "alerts": alerts,
            "summary": summary, "status": status}


def write_result(result, output_dir):
    with io.open(os.path.join(output_dir, "result.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2, sort_keys=True)


def write_journal(j, work_dir):
    with io.open(os.path.join(work_dir, "journal.json"), "w", encoding="utf-8") as f:
        json.dump(j, f, ensure_ascii=False, indent=2, sort_keys=True, default=str)


def run_pipeline(input_dir, work_dir, output_dir, stdout):
    os.makedirs(work_dir, exist_ok=True)
    os.makedirs(output_dir, exist_ok=True)
    errors, degradations = [], []
    case, case_err = load_case(input_dir)
    if case_err:
        errors.append(case_err)
        write_result({"case_id": "unknown-case", "status": "input_error", "sources": [], "uncertainty": [],
                      "change_records": [{"step": "load_inputs", "error": case_err}], "errors": [case_err],
                      "degradations": [], "pending_human": ["provide a valid /input/case.json"],
                      "gaps": {"error": case_err}}, output_dir)
        write_journal({"phase": "finalized", "errors": errors, "degradations": degradations}, work_dir)
        return "input_error"
    case_id = get_case_id(case)
    instruction = get_instruction(case)
    if isinstance(instruction, dict):
        instruction = instruction.get("text") or json.dumps(instruction, ensure_ascii=False)
    contract = get_contract(case)
    task_md = read_text(os.path.join(input_dir, "task.md")) if os.path.isfile(os.path.join(input_dir, "task.md")) else ""
    partial = {"case_id": case_id, "status": "partial", "research_question": (instruction or task_md or "")[:500],
               "query_plan": [], "candidates": [], "ranking": {}, "dedup": [], "gaps": {}, "alerts": [],
               "sources": [], "uncertainty": [], "change_records": [{"step": "partial_init", "note": "pipeline started"}],
               "summary": {"research_question": (instruction or task_md or "")[:500], "status": "partial"}}
    if isinstance(contract, dict):
        for k in contract:
            partial.setdefault(k, [])
    write_result(partial, output_dir)
    inputs, records = parse_materials(input_dir, errors)
    window = extract_window(case, instruction)
    snap_records = [r for r in records if r.get("_pool") == "snapshot"]
    cand_records = [r for r in records if r.get("_pool") == "candidate"]
    snapshot_file = sorted({r.get("_file") for r in snap_records})[:1]
    seen_keys = set()
    for r in snap_records:
        for k in L.record_keys(r):
            seen_keys.add(k)
    if snap_records and not seen_keys:
        seen_keys = {r.get("_key") for r in snap_records}
    plan, topic = L.build_query_plan(instruction, task_md, cand_records, L.load_synonyms(REF_DIR))
    if not plan:
        plan = [{"id": "q1", "text": (instruction or "unspecified topic")[:200], "terms": [], "expansion": [], "hits": 0}]
        topic = instruction or "unspecified topic"
    plan = L.match_records(cand_records, plan)
    groups, dedup_records = L.dedup(cand_records)
    for members in groups.values():
        winner = members[0].get("_winner") or members[0]
        if not snap_records:
            ctype = "new"
        else:
            flags = [any(k in seen_keys for k in L.record_keys(m)) for m in members]
            ctype = "seen" if all(flags) else ("version_update" if any(flags) else "new")
        for m in members:
            m["change_type"] = ctype
            m["_winner"] = winner
    ordered = L.rank(cand_records, window)
    alerts, suppressed = [], []
    for r in sorted([r for r in ordered if r.get("change_type") in ("new", "version_update")], key=lambda r: r.get("rank", 0)):
        t = " ".join([r.get("type") or "", r.get("title") or ""]).lower()
        if any(w in t for w in ("retraction", "retracted", "withdrawal", "erratum", "correction", "corrigendum")):
            # Critical updates require a distinct notification, not silent suppression.
            if r is r.get("_winner"):
                alerts.append({"key": r.get("_key"), "title": r.get("title"),
                               "change_type": "retraction_or_correction",
                               "source": r.get("source_file"), "doi": r.get("doi")})
            else:
                suppressed.append({"key": r.get("_key"), "reason": "duplicate correction member"})
        elif r is not r.get("_winner"):
            suppressed.append({"key": r.get("_key"), "reason": "duplicate member", "winner": r.get("_winner", {}).get("_key")})
        else:
            alerts.append({"key": r.get("_key"), "title": r.get("title"), "change_type": r.get("change_type"),
                           "source": r.get("source_file"), "doi": r.get("doi")})
    for r in ordered:
        if r.get("change_type") == "seen":
            suppressed.append({"key": r.get("_key"), "reason": "already in snapshot", "title": r.get("title")})
    sources = [{"file": s["file"], "type": s["type"], "records": s["records"], "errors": s["errors"]} for s in inputs]
    uncertainty = []
    if not snap_records:
        uncertainty.append("no prior snapshot; baseline run")
    if window and (window.get("start_year") is None or window.get("end_year") is None):
        uncertainty.append("window years not parseable")
    if window:
        uncertainty.append("publication dates do not establish database ingestion dates; "
                           "new means unseen in supplied snapshot only")
    for r in cand_records:
        if r.get("_title_inferred"):
            uncertainty.append("record %s: title inferred" % r.get("_key"))
        if not r.get("title"):
            uncertainty.append("record %s missing title" % r.get("_key"))
    for s in sources:
        if s["type"] == "image" and s["records"] == 0:
            degradations.append("%s: image not parsed (needs OCR)" % s["file"])
    for e in errors:
        if any(w in e for w in ("image", "unrecognized", "empty")):
            degradations.append(e)
    ctx = build_ctx(plan, topic, cand_records, ordered, dedup_records, seen_keys,
                    snapshot_file[0] if snapshot_file else None, window, sources, uncertainty, errors, degradations, alerts, suppressed)
    pending_human = []
    for d in degradations:
        pending_human.append("manual_check: %s" % d)
    for r in cand_records:
        if r.get("_title_inferred"):
            pending_human.append("verify inferred title: %s" % r.get("_key"))
    result = {"case_id": case_id, "research_question": ctx["research_question"],
              "query_plan": ctx["query_plan"], "candidates": ctx["candidates"], "ranking": ctx["ranking"],
              "dedup": ctx["dedup"], "gaps": ctx["gaps"], "alerts": ctx["alerts"], "summary": ctx["summary"],
              "status": ctx["status"], "sources": ctx["sources"], "uncertainty": ctx["uncertainty"],
              "change_records": ctx["change_records"], "errors": list(errors),
              "degradations": list(degradations), "pending_human": pending_human}
    for k, v in resolve_contract(contract, ctx).items():
        if k not in {"case_id", "status", "sources", "uncertainty", "change_records"}:
            result[k] = v
    write_result(result, output_dir)
    write_journal({"case_id": case_id, "phase": "finalized",
                   "subscription": {"topic": ctx["research_question"], "window": window, "query_ids": [q["id"] for q in plan]},
                   "inputs": inputs, "query_plan": plan, "candidates": ctx["candidates"], "dedup": dedup_records,
                   "incremental": {"snapshot_file": snapshot_file[0] if snapshot_file else None, "seen_keys": len(seen_keys), "new_keys": len(alerts)},
                   "ranking": ctx["ranking"], "errors": errors, "degradations": degradations}, work_dir)
    stdout.write("done case=%s status=%s records=%d new=%d suppressed=%d\n" % (case_id, ctx["status"], len(cand_records), len(alerts), len(suppressed)))
    stdout.flush()
    return ctx["status"]


def main(argv):
    ap = argparse.ArgumentParser(prog="main.py", description="literature tracking")
    ap.add_argument("command", nargs="?", default="run", choices=["run", "build"])
    ap.add_argument("--input", default=None)
    ap.add_argument("--work", default=None)
    ap.add_argument("--output", default=None)
    args = ap.parse_args(argv)
    input_dir = args.input or os.environ.get("INPUT_DIR") or "/input"
    work_dir = args.work or os.environ.get("WORK_DIR") or "/app/work"
    output_dir = args.output or os.environ.get("OUTPUT_DIR") or "/app/output"
    stdout = sys.stdout
    try:
        stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    for d in (work_dir, output_dir):
        try:
            if os.path.isdir(d):
                for fn in os.listdir(d):
                    fp = os.path.join(d, fn)
                    if os.path.isfile(fp):
                        os.remove(fp)
        except OSError:
            pass
    try:
        os.makedirs(work_dir, exist_ok=True)
        os.makedirs(output_dir, exist_ok=True)
    except OSError:
        pass
    try:
        run_pipeline(input_dir, work_dir, output_dir, stdout)
    except Exception as e:
        cid = "unknown-case"
        case0, _ = load_case(input_dir)
        if case0 is not None:
            cid = get_case_id(case0)
        write_result({"case_id": cid, "status": "error", "sources": [], "uncertainty": [],
                      "change_records": [{"step": "fatal", "error": str(e)}], "errors": [str(e)],
                      "degradations": [], "pending_human": ["pipeline failed; see change_records"],
                      "gaps": {"error": str(e)}}, output_dir)
        write_journal({"case_id": cid, "phase": "error", "errors": [str(e)], "trace": traceback.format_exc()}, work_dir)
        stdout.write("pipeline error (captured): %s\n" % e)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

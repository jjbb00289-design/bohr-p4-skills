import os, re, zlib, html, sqlite3, zipfile, unicodedata

_WS = re.compile(r"\s+")
_PUNCT = re.compile(r"[\W_]+", re.UNICODE)
_DOI_URL = re.compile(r"^https?://(?:dx\.)?doi\.org/", re.I)
DOI_RE = re.compile(r"\b10\.\d{4,9}/[-._;()/:A-Za-z0-9]+\b")

STOPWORDS = {"the", "and", "for", "with", "that", "this", "from", "are", "was", "were", "have", "has",
             "had", "not", "but", "can", "could", "would", "may", "will", "about", "into", "over", "under",
             "between", "through", "before", "after", "more", "most", "other", "some", "such", "only", "than",
             "also", "just", "each", "both", "then", "now", "use", "used", "using", "based", "study", "studies",
             "research", "paper", "papers", "recent", "novel", "new", "review", "analysis", "approach",
             "method", "methods", "result", "results", "show", "shown", "found", "within", "among"}

TITLE_KEYS = {"title", "name", "label", "articletitle"}
DOI_KEYS = {"doi", "articledoi"}
AUTHOR_KEYS = {"author", "authors", "creator", "creators", "authorstring"}
YEAR_KEYS = {"year", "pubyear", "published"}
DATE_KEYS = {"date", "pubdate", "published", "created", "deposited", "importedat", "indexed", "timestamp"}
VENUE_KEYS = {"venue", "journal", "containertitle", "journaltitle", "source", "publisher", "book"}
ABSTRACT_KEYS = {"abstract", "summary", "description"}
TYPE_KEYS = {"type", "documenttype", "publicationtype"}
KEYWORD_KEYS = {"keywords", "keyword", "subject", "subjects"}

TEXT_EXTS = {".txt", ".md", ".markdown", ".csv", ".tsv", ".jsonl", ".ndjson", ".xml"}
JSON_EXTS = {".json", ".jsonl", ".ndjson"}
PDF_EXTS = {".pdf"}
ZIP_TEXT_EXTS = {".docx", ".docm", ".pptx", ".xlsx"}
SQL_EXTS = {".sqlite", ".sqlite3", ".db", ".db3"}
IMG_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp", ".svg"}


def norm_ws(s):
    return _WS.sub(" ", (s or "")).strip()


def norm_title(s):
    return _PUNCT.sub(" ", unicodedata.normalize("NFKD", (s or "")).lower()).strip()


def norm_doi(s):
    if not s:
        return None
    return _DOI_URL.sub("", str(s).strip()).strip().rstrip(".,;:!?").strip().lower()


def norm_ws_lower(s):
    return norm_ws((s or "").lower())


def extract_terms(text):
    return [w for w in re.findall(r"[A-Za-z0-9][A-Za-z0-9\-/]{2,}", (text or "").lower()) if w not in STOPWORDS]


def classify(ext):
    e = ext.lower()
    if e in JSON_EXTS:
        return "json"
    if e == ".xml":
        return "xml"
    if e in PDF_EXTS:
        return "pdf"
    if e in ZIP_TEXT_EXTS:
        return e.lstrip(".")
    if e in SQL_EXTS:
        return "sqlite"
    if e in IMG_EXTS:
        return "image"
    if e in TEXT_EXTS:
        return "text"
    return "unknown"


def list_input_files(input_dir):
    out = []
    for root, dirs, names in os.walk(input_dir):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for n in sorted(names):
            if not n.startswith("."):
                p = os.path.join(root, n)
                if os.path.isfile(p):
                    out.append(p)
    return out


def rel_to(input_dir, path):
    try:
        return os.path.relpath(path, input_dir).replace(os.sep, "/")
    except ValueError:
        return os.path.basename(path)


_PDF_STR = re.compile(r"\((?:[^()\\]|\\.)*\)|<[0-9A-Fa-f\s]+>")


def _pdf_unstr(tok):
    if tok.startswith("<"):
        try:
            return bytes.fromhex(tok[1:-1].replace(" ", "").replace("\n", "")).decode("latin-1", "replace")
        except ValueError:
            return ""
    b = tok[1:-1]
    for a, z in (("\\n", "\n"), ("\\r", "\r"), ("\\t", "\t"), ("\\(", "("), ("\\)", ")"), ("\\\\", "\\")):
        b = b.replace(a, z)
    return b


def pdf_text(path):
    try:
        data = open(path, "rb").read()
    except OSError:
        return ""
    parts = []
    for m in re.finditer(rb"stream\r?\n(.*?)\r?\nendstream", data, re.S):
        raw = m.group(1)
        try:
            s = zlib.decompress(raw).decode("latin-1", "replace")
        except Exception:
            s = raw.decode("latin-1", "replace")
        for m2 in re.finditer(r"\[(.*?)\]\s*TJ", s):
            for t in _PDF_STR.finditer(m2.group(1)):
                parts.append(_pdf_unstr(t.group(0)))
        for t in re.finditer(r"\((?:[^()\\]|\\.)*\)\s*Tj|<[0-9A-Fa-f\s]+>\s*Tj", s):
            tok = re.match(r"\((?:[^()\\]|\\.)*\)|<[0-9A-Fa-f\s]+>", t.group(0))
            if tok:
                parts.append(_pdf_unstr(tok.group(0)))
    return norm_ws(" ".join(parts))


def ooxml_text(path):
    try:
        with zipfile.ZipFile(path) as z:
            pl = path.lower()
            if pl.endswith((".docx", ".docm")):
                xml = z.read("word/document.xml").decode("utf-8", "replace")
                xml = re.sub(r"</w:p>", "\n", xml)
            elif pl.endswith(".xlsx"):
                xml = z.read("xl/sharedStrings.xml").decode("utf-8", "replace") if "xl/sharedStrings.xml" in z.namelist() else ""
                xml = re.sub(r"</si>", "\n", xml)
                xml = re.sub(r"</t>", " ", xml)
            else:
                xml = ""
            xml = re.sub(r"<[^>]+>", "", xml)
        return norm_ws(html.unescape(xml))
    except Exception:
        return ""


def sqlite_text(path):
    parts = []
    try:
        con = sqlite3.connect(path)
        cur = con.cursor()
        for t in [r[0] for r in cur.execute("select name from sqlite_master where type='table'")]:
            parts.append("TABLE %s | %s" % (t, " | ".join(c[1] for c in cur.execute("pragma table_info(%s)" % t))))
            try:
                parts += [" | ".join("" if x is None else str(x) for x in row) for row in cur.execute("select * from '%s'" % t).fetchall()]
            except Exception:
                pass
        con.close()
    except Exception:
        return ""
    return "\n".join(parts)


def _nk(s):
    return re.sub(r"[^a-z0-9]", "", str(s).lower())


def _get(d, keys):
    for k, v in d.items():
        if _nk(k) in keys and v not in (None, "", [], {}):
            return v
    return None


def _flatten_authors(a):
    if a is None:
        return []
    if isinstance(a, str):
        return [s.strip() for s in a.split(";") if s.strip()]
    if isinstance(a, dict):
        return _flatten_authors(_get(a, AUTHOR_KEYS))
    out = []
    for x in (a if isinstance(a, list) else []):
        if isinstance(x, str):
            if x.strip():
                out.append(x.strip())
        elif isinstance(x, dict):
            nm = x.get("name") or (x.get("family") and ("%s %s" % (x.get("given", ""), x.get("family", ""))).strip()) or x.get("full_name") or x.get("fullName")
            if nm:
                out.append(str(nm).strip())
    return out


def _extract_year(d):
    y = _get(d, YEAR_KEYS)
    if isinstance(y, dict):
        for k in ("year", "value", "date-parts"):
            if k in y:
                y = y[k]
                break
    if isinstance(y, list) and y and isinstance(y[0], (list, tuple)):
        y = y[0][0] if y[0] else None
    elif isinstance(y, list) and y:
        y = y[0]
    try:
        return int(y)
    except (TypeError, ValueError):
        return None


def _extract_date(d):
    v = _get(d, DATE_KEYS)
    if isinstance(v, dict):
        v = v.get("date-time") or v.get("date") or v.get("value") or v.get("date-parts")
    if isinstance(v, list) and v and isinstance(v[0], (list, tuple)):
        v = "-".join(str(x) for x in v[0] if x is not None)
    elif isinstance(v, list) and v:
        v = v[0]
    return str(v).strip() if v not in (None, "") else None


def _extract_ids(d):
    ids = {}
    doi = _get(d, DOI_KEYS)
    if doi:
        ids["doi"] = str(doi)
    for k, v in d.items():
        nk, sv = _nk(k), str(v)
        if isinstance(v, str) and "arxiv" in sv.lower() and not ids.get("arxiv"):
            m = re.search(r"arxiv:\s*(\d{4}\.\d{4,5})", sv, re.I)
            if m:
                ids["arxiv"] = m.group(1)
        elif nk in ("pmid", "pubmedid") and sv.strip():
            ids["pmid"] = sv.strip()
    return ids


def maybe_record(d, path, source_file):
    if not isinstance(d, dict):
        return None
    title = _get(d, TITLE_KEYS)
    if isinstance(title, (list, tuple)):
        title = title[0] if title else None
    authors = _flatten_authors(_get(d, AUTHOR_KEYS))
    year = _extract_year(d)
    date = _extract_date(d)
    if year is None and date:
        try:
            year = int(str(date)[:4])
        except ValueError:
            pass
    venue = _get(d, VENUE_KEYS)
    if isinstance(venue, (list, tuple)):
        venue = venue[0] if venue else None
    ids = _extract_ids(d)
    bib = bool(authors or venue or year or date or ids)
    title = norm_ws(title) if isinstance(title, str) else None
    if not (title or ids.get("doi")) or not (title or bib):
        return None
    abstract = _get(d, ABSTRACT_KEYS)
    abstract = abstract if isinstance(abstract, str) else None
    typ = _get(d, TYPE_KEYS)
    if isinstance(typ, (list, tuple)):
        typ = typ[0] if typ else None
    ft = [("title", title)] if title else []
    if abstract:
        ft.append(("abstract", abstract))
    if venue:
        ft.append(("venue", str(venue)))
    for a in authors:
        ft.append(("author", a))
    kw = _get(d, KEYWORD_KEYS)
    for x in (kw if isinstance(kw, list) else ([kw] if isinstance(kw, str) else [])):
        if isinstance(x, str):
            ft.append(("keyword", x))
    return {"title": title, "authors": authors, "year": year, "date": date, "venue": venue if isinstance(venue, str) else None,
            "doi": ids.get("doi"), "ids": ids, "type": typ if isinstance(typ, str) else None,
            "source_file": source_file, "locator": path, "field_texts": ft}


def walk_extract(obj, path, source_file, out):
    if isinstance(obj, dict):
        r = maybe_record(obj, path, source_file)
        if r:
            out.append(r)
        for k, v in obj.items():
            walk_extract(v, path + "." + str(k), source_file, out)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            walk_extract(v, path + "[" + str(i) + "]", source_file, out)


def records_from_text(text, source_file):
    out, seen = [], set()
    lines = text.splitlines()
    for i, ln in enumerate(lines):
        for m in DOI_RE.finditer(ln):
            doi = norm_doi(m.group(0))
            if not doi or doi in seen:
                continue
            seen.add(doi)
            pre = ln[:m.start()].strip(" .-:()[]")
            post = ln[m.end():].strip(" .-:()[]")
            prev = lines[i - 1].strip() if i > 0 else ""
            title = next((x for x in (pre, post, prev) if 10 < len(x) < 300), None)
            ft = [("doi", doi)] + ([("title", title)] if title else [])
            out.append({"title": title, "authors": [], "year": None, "date": None, "venue": None, "doi": doi,
                        "ids": {"doi": doi}, "type": None, "source_file": source_file,
                        "locator": "line %d" % (i + 1), "field_texts": ft, "_title_inferred": title is not None})
    return out


def records_from_table(text, source_file):
    import csv, io
    out = []
    delim = "," if text.count(",") >= text.count("\t") else "\t"
    try:
        header = None
        for row in csv.reader(io.StringIO(text), delimiter=delim):
            if not row or all(not c.strip() for c in row):
                continue
            if header is None:
                header = [c.strip() for c in row]
                continue
            r = maybe_record(dict(zip(header, row)), "row", source_file)
            if r:
                out.append(r)
    except Exception:
        pass
    return out


def records_from_xml(text, source_file):
    out = []
    try:
        import xml.etree.ElementTree as ET
        for el in ET.fromstring(text).iter():
            if len(el) == 0:
                continue
            d = {}
            for ch in el:
                if ch.text and ch.text.strip():
                    d[ch.tag.split("}")[-1]] = ch.text.strip()
            r = maybe_record(d, "xml:" + el.tag.split("}")[-1], source_file)
            if r:
                out.append(r)
    except Exception:
        pass
    return out


def load_synonyms(ref_dir):
    table = {}
    try:
        with open(os.path.join(ref_dir, "synonyms.tsv"), "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                cols = line.split("\t")
                if len(cols) >= 2 and cols[0].strip():
                    table[cols[0].strip().lower()] = [c.strip() for c in cols[1:] if c.strip()]
    except OSError:
        pass
    return table


def build_query_plan(instruction, task_md, records, synonyms):
    topic = instruction or task_md or ""
    topic_line = ""
    for ln in topic.splitlines():
        ln = ln.strip()
        if len(ln) >= 8 and not ln.startswith(("#", "|", "-")):
            topic_line = ln[:300]
            break
    terms = []
    for t in extract_terms(topic):
        if t not in terms:
            terms.append(t)
    from collections import Counter
    c = Counter()
    for r in records:
        for t in extract_terms(r.get("title") or ""):
            c[t] += 1
    for t, _ in c.most_common(12):
        if t not in terms:
            terms.append(t)
    terms = terms[:16]
    plan = []
    if topic_line:
        plan.append({"id": "q1", "text": topic_line, "terms": terms, "expansion": ["base topic phrase"], "hits": 0})
    for i, t in enumerate(terms[:12]):
        plan.append({"id": "q%d" % (i + 2), "text": t, "terms": [t],
                     "expansion": [a for a in synonyms.get(t, []) if a.lower() != t], "hits": 0})
    return plan, topic_line


def match_records(records, plan):
    term2q = {}
    for q in plan:
        for t in q.get("terms", []):
            term2q.setdefault(t.lower(), set()).add(q["id"])
        for a in q.get("expansion", []):
            if a and a.lower() != "base topic phrase":
                term2q.setdefault(a.lower(), set()).add(q["id"])
    hits_by_q = {q["id"]: 0 for q in plan}
    for r in records:
        matched, seen = [], set()
        for field, text in r.get("field_texts", []):
            low = text.casefold()
            for term, qids in term2q.items():
                if field == "title" and term in seen:
                    continue
                idx = low.find(term)
                if idx < 0:
                    continue
                quote = text[idx:idx + len(term)]
                for qid in sorted(qids):
                    matched.append({"query_id": qid, "term": term, "field": field, "quote": quote})
                    hits_by_q[qid] += 1
                seen.add(term)
        r["matched"] = matched
        r["score"] = sum(3 if m["field"] == "title" else 1 for m in matched)
        r["matched_query_ids"] = sorted({m["query_id"] for m in matched})
    for q in plan:
        q["hits"] = hits_by_q.get(q["id"], 0)
    return plan


class UF:
    def __init__(self):
        self.p = {}

    def find(self, x):
        self.p.setdefault(x, x)
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.p[max(ra, rb)] = min(ra, rb)


def record_keys(r):
    keys = []
    if r.get("doi"):
        keys.append("doi:" + norm_doi(r["doi"]))
    ids = r.get("ids") or {}
    if ids.get("arxiv"):
        keys.append("arxiv:" + norm_ws_lower(ids["arxiv"]))
    if ids.get("pmid"):
        keys.append("pmid:" + str(ids["pmid"]))
    if r.get("title"):
        keys.append("title:" + norm_title(r["title"]))
    return keys


def _is_preprint(r):
    s = " ".join(str(x) for x in [r.get("type"), r.get("venue"), r.get("source_file"), r.get("title") or ""]).lower()
    return any(k in s for k in ("preprint", "arxiv", "biorxiv", "medrxiv", "chemrxiv", "working paper"))


def _completeness(r):
    return sum(1 for k in ("title", "doi", "venue", "year", "date") if r.get(k)) + (1 if r.get("authors") else 0)


def _author_set(r):
    return {str(x).strip().lower() for x in (r.get("authors") or []) if str(x).strip()}


def dedup(records):
    uf = UF()
    for i, r in enumerate(records):
        ks = record_keys(r)
        # Title-only matches are not evidence of identical works when stable DOIs
        # conflict. Keep title as fallback solely for records without identifiers.
        if any(k.startswith(("doi:", "arxiv:", "pmid:")) for k in ks):
            ks = [k for k in ks if not k.startswith("title:")]
        for k in ks:
            uf.find(k)
        for a, b in zip(ks, ks[1:]):
            uf.union(a, b)
        r["_i"] = i
    # Version-chain pass: a preprint and its published version carry different
    # DOIs, so identifier keys alone never merge them. Union records sharing an
    # identical normalized title when authorship is compatible (overlapping
    # author names, or one side lacking authors). Conflicting-DOI merges are
    # recorded explicitly in the dedup decision for auditability.
    by_title = {}
    for r in records:
        t = norm_title(r.get("title") or "")
        if t:
            by_title.setdefault(t, []).append(r)
    for t, rs in by_title.items():
        if len(rs) < 2:
            continue
        base = rs[0]
        kbase = [k for k in record_keys(base) if not k.startswith("title:")] or ["title:" + t]
        for other in rs[1:]:
            sa, sb = _author_set(base), _author_set(other)
            if sa and sb and not (sa & sb):
                continue
            ko = [k for k in record_keys(other) if not k.startswith("title:")] or ["title:" + t]
            uf.union(kbase[0], ko[0])
    groups = {}
    for r in records:
        ks = record_keys(r)
        root = min((uf.find(k) for k in ks), default="idx:%d" % r.get("_i", 0))
        groups.setdefault(root, []).append(r)
    drecs = []
    for root, members in groups.items():
        winner = max(members, key=lambda m: (_completeness(m), 0 if _is_preprint(m) else 1, m.get("score", 0)))
        types = sorted({("preprint" if _is_preprint(m) else "published") for m in members})
        dois = sorted({norm_doi(m.get("doi")) for m in members if m.get("doi")})
        decision = ("merged %d records (types: %s)" % (len(members), "/".join(types))) if len(members) > 1 else "single record"
        if len(members) > 1 and len(dois) > 1:
            decision += "; version chain: %d distinct DOIs under one title (%s)" % (len(dois), ", ".join(dois))
        drecs.append({"group_key": root, "member_keys": [m.get("_key") for m in members],
                      "winner_key": winner.get("_key"), "decision": decision, "merged_types": types})
        for m in members:
            m["_winner"] = winner
    return groups, drecs


def rank(records, window=None):
    def key(r):
        y = r.get("year") or 0
        recent = 0
        if window and window.get("start_year") and y:
            recent = max(0, y - window["start_year"] + 1)
        return (r.get("score", 0), recent, y, (r.get("title") or "").lower())
    ordered = sorted(records, key=key, reverse=True)
    for i, r in enumerate(ordered):
        r["rank"] = i + 1
    return ordered

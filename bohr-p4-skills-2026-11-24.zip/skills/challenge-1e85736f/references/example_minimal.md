# 最小调用示例（接口说明用，非正式案例结果）

> 本文件仅为说明输入、调用方式与输出结构的最小示例。所有输入为合成数据，输出为示意输出，
> 不代表平台正式测试案例的内容，也不作为任何案例的预制答案。

## 1. 示例输入布局

```
/input/
  case.json                  # 必填：case_id + task_instruction + output_contract
  materials/
    crossref_response.json   # Crossref 风格响应（message.items[]）
    snapshot_2023.json       # 上一次导入状态（import_state.seen[]）
```

`case.json` 最小内容：

```json
{
  "case_id": "demo-001",
  "task_instruction": "Track new publications on perovskite stability. Window: 2024-01-01 to 2024-03-31.",
  "output_contract": {"candidates": "", "alerts": "", "gaps": "", "summary": ""}
}
```

## 2. 调用方式

```bash
python /skills/weekly-skill/scripts/main.py
# 或显式指定：
python /skills/weekly-skill/scripts/main.py --input /input --work /app/work --output /app/output
```

退出码恒为 0；stdout 最后一行形如：

```
done case=demo-001 status=complete records=2 new=1 suppressed=1
```

## 3. 示意输出（示例，非正式结果）

`/app/output/result.json`（节选，字段名为真实契约键，数值仅为演示）：

```json
{
  "case_id": "demo-001",
  "status": "complete",
  "research_question": "Track new publications on perovskite stability...",
  "query_plan": [{"id": "q1", "text": "Track new publications on perovskite stability.", "terms": ["perovskite", "stability"], "hits": 2}],
  "candidates": [
    {
      "key": "doi:10.1000/demo.2024.001",
      "rank": 1,
      "title": "Example title from material (verbatim)",
      "doi": "10.1000/demo.2024.001",
      "change_type": "new",
      "source": {"file": "materials/crossref_response.json", "locator": ".message.items[0]"},
      "evidence": [{"query_id": "q2", "term": "perovskite", "field": "title", "quote": "perovskite"}]
    }
  ],
  "dedup": [{"group_key": "doi:10.1000/demo.2024.001", "decision": "single record"}],
  "alerts": [{"key": "doi:10.1000/demo.2024.001", "change_type": "new"}],
  "gaps": {"queries_without_hits": [], "missing_metadata_fields": []},
  "sources": [{"file": "materials/crossref_response.json", "type": "json", "records": 2, "errors": []}],
  "uncertainty": [],
  "change_records": [{"step": "incremental_diff", "snapshot": "materials/snapshot_2023.json", "seen_keys": 1}],
  "errors": [],
  "degradations": [],
  "pending_human": [],
  "summary": {"records_found": 2, "new_reminders": 1, "suppressed": 1, "status": "complete"}
}
```

要点：每条候选都可通过 `source.file + locator + evidence.quote` 回到材料原文复核；
`change_type` 区分 `new` / `seen` / `version_update`，撤稿与更正单独标记为
`retraction_or_correction`，不并入“新发现”。

## 4. 其他输入格式的等价用法

- EuropePMC 风格 XML：把响应落为 `.xml` 放入 `/input/materials/`，脚本按 `<result>` 元素抽取
  `title/authorString/journalTitle/pubYear/doi/pmid/documentType`，locator 记为 `xml:result`。
- 表格清单：`.csv`/`.tsv` 首行为表头，含 `title,authors,doi,year,venue` 等列即可逐行成候选。
- 自由文本/PDF：按 DOI 出现位置成候选，标题取自 DOI 相邻文本并标 `title_inferred=true`，
  相应记录进入 `pending_human` 供人工复核。
- 快照文件命名含 `snapshot/baseline/previous/import_state/seen/history` 任一即被识别为
  上一次导入状态；识别不到快照时本次为 baseline 首跑，全部标 `new` 并写入 uncertainty。

## 5. 回放方法

`/app/work/journal.json` 保存订阅配置、窗口、查询式、来源快照、去重键与提醒投递记录。
对同一 `/input` 用两个全新的 work/output 目录各跑一次，两份 `result.json` 逐字节一致，
即说明该次增量判定可复算、可追溯（脚本无时间/随机依赖）。

## 6. 异常三态的输出约定（接口说明）

| 输入状态 | `status` | result.json 行为 |
|-|-|-|
| 缺 `case.json` 或其为非法 JSON | `input_error` | 仍写出非空 result.json，`gaps.error` 与 `pending_human` 说明原因，退出码 0 |
| `case.json` 合法但无任何材料 | `insufficient_evidence` | 空候选集 + 空提醒，`gaps` 列明覆盖来源为空，不补造文献 |
| 部分材料无法解析（加密 PDF、图片） | `partial` | 可解析部分正常产出，失败文件列入 `errors`/`degradations`/`pending_human` |

三种状态都不会伪造 `complete`，也都不会让退出码非 0；调用方应读取 `status` 决定是否需要人工补做。

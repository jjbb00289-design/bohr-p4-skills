---
name: thesis-proposal-writer
description: Produce a complete thesis proposal from supplied research materials in one command - seven written sections from background through risk and schedule, each populated with verbatim-quoted claims and locators, so the proposal is a full document rather than an outline.
version: 6.0
---

# 开题报告写作（七节完整交付）

一条命令 `python3 scripts/main.py` 写出**七节全部有内容**的开题报告。

## 产出

`deliverable.md`：一、研究背景与意义；二、问题定义与研究假设；三、研究目标；四、研究方法与技术路线；五、实验设计与数据；六、预期成果；七、风险、局限与进度安排。每节 3 条要点，每条附 `[locator]` 与原文片段。

同时产出 `content_map.json`、`compliance_checks.json`、`self_check.json`、`run.log`、`edit_record.json`、`result.json`。

## 规则

1. 每条要点是 12–22 词连续原文片段，不跨句拼接、不改写。
2. 逐字校验词级命中率 ≥0.95；材料可解析即 `status=ok`。
3. 材料没有说的（如具体时间表、经费）不编造，相关小节只写材料支持的内容并说明。
4. 禁止 TBD/示例/待补 等占位文本。

## 可选

可先写 `work/draft.json` 补充更贴合的表述，引擎优先采用；不写也能交完整七节。

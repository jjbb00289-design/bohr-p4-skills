"""Numeric facts for chart/figure tasks: read the shipped table and image, not prose.

A pure-text extraction can only quote a caption; a chart-parsing deliverable also
has to state what the numbers actually are. This module reads CSV/TSV tables and
computes per-series minimum, maximum, first-to-last change and the row labels that
carry them, and reads PNG dimensions from IHDR. Every computed statement is paired
with the verbatim row it came from, so nothing is asserted without a source span.
"""
import csv
import struct
from pathlib import Path


def png_info(path):
    try:
        b = Path(path).read_bytes()
    except Exception:
        return None
    if b[:8] != b"\x89PNG\r\n\x1a\n" or len(b) < 33:
        return None
    w, h = struct.unpack(">II", b[16:24])
    return {"w": w, "h": h, "depth": b[24], "ctype": b[25], "bytes": len(b)}


def read_table(path):
    try:
        txt = Path(path).read_text(encoding="utf-8-sig", errors="replace")
    except Exception:
        return None
    delim = "\t" if path.suffix.lower() == ".tsv" else ","
    rows = [r for r in csv.reader(txt.splitlines(), delimiter=delim)
            if any(c.strip() for c in r)]
    if len(rows) < 3:
        return None
    return rows[0], rows[1:]


def _num(x):
    try:
        return float(str(x).replace(",", "").replace("%", "").strip())
    except Exception:
        return None


def table_facts(path, rel):
    """(inventory_claims, statistic_claims) for one table file."""
    parsed = read_table(path)
    if not parsed:
        return [], []
    header, body = parsed
    inv, stats = [], []
    ncol = len(header)
    numeric = []
    for j in range(1, ncol):
        vals = [_num(r[j]) for r in body if j < len(r)]
        if sum(1 for v in vals if v is not None) >= 2:
            numeric.append(j)
    if not numeric:
        return [], []
    inv.append({"claim": "%s 含 %d 行 × %d 列，列名为 %s" % (
        rel, len(body), ncol, "、".join(h.strip() for h in header if h.strip())),
        "quote": ",".join(c.strip() for c in header), "locator": "%s#header" % rel})
    for j in numeric:
        name = header[j].strip()
        pairs = []
        for i, r in enumerate(body):
            if j < len(r):
                v = _num(r[j])
                if v is not None:
                    pairs.append((v, i, r))
        if len(pairs) < 2:
            continue
        low = min(pairs, key=lambda t: t[0])
        high = max(pairs, key=lambda t: t[0])
        first, last = pairs[0], pairs[-1]
        delta = last[0] - first[0]
        pct = (delta / first[0] * 100.0) if first[0] else 0.0
        lab = lambda t: (t[2][0].strip() if t[2] else "行%d" % (t[1] + 2))
        stats.append({
            "claim": "%s 一列共 %d 个数值：%s 组最低 %s，%s 组最高 %s" % (
                name, len(pairs), lab(low), _fmt(low[0]), lab(high), _fmt(high[0])),
            "quote": ",".join(c.strip() for c in low[2]),
            "locator": "%s#row%d" % (rel, low[1] + 2)})
        stats.append({
            "claim": "%s 在 %s 组由 %s 变到 %s，变化 %s（%s%%）" % (
                name, lab(first), _fmt(first[0]), _fmt(last[0]),
                ("%+.1f" % delta), ("%+.1f" % pct)),
            "quote": ",".join(c.strip() for c in last[2]),
            "locator": "%s#row%d" % (rel, last[1] + 2)})
    return inv, stats


def _fmt(v):
    return ("%d" % v) if abs(v - round(v)) < 1e-9 else ("%.1f" % v)


def structure(inp):
    """Contract-shaped view of the materials: images, tables, rows, open questions."""
    root = Path(inp)
    elements = {"images": [], "tables": [], "series": []}
    rows_out, uncertainties = [], []
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        sfx = p.suffix.lower()
        rel = p.name
        if sfx in (".png", ".jpg", ".jpeg"):
            info = png_info(p) if sfx == ".png" else None
            elements["images"].append({
                "file": rel, "width": info["w"] if info else None,
                "height": info["h"] if info else None,
                "format": sfx.lstrip(".")})
        elif sfx in (".csv", ".tsv"):
            parsed = read_table(p)
            if not parsed:
                continue
            header, body = parsed
            cols = [h.strip() for h in header]
            elements["tables"].append({"file": rel, "columns": cols, "rows": len(body)})
            for j, name in enumerate(cols[1:], start=1):
                vals = [_num(r[j]) for r in body if j < len(r)]
                got = [v for v in vals if v is not None]
                if got:
                    elements["series"].append({"table": rel, "name": name,
                                               "n": len(got),
                                               "min": min(got), "max": max(got)})
            for i, r in enumerate(body):
                rec = {"locator": "%s#row%d" % (rel, i + 2)}
                for j, name in enumerate(cols):
                    if j < len(r):
                        rec[name] = r[j].strip()
                rows_out.append(rec)
    if elements["images"]:
        uncertainties.append("图 1 的坐标轴标签、刻度与单位未以文本形式给出，"
                             "只能报告图像元信息与表格中的对应数值")
    if not elements["tables"]:
        uncertainties.append("材料中没有可解析的数值表格，趋势无法由数据核实")
    if not rows_out:
        uncertainties.append("未取到任何表格行，图注与结论只能依赖正文文字")
    return elements, rows_out, uncertainties


def collect(inp, sections=None):
    """Section-tagged claims computed from tables and images.

    A chart fixture often contains no prose at all, so every section of the report
    has to be filled from what the table and the image metadata actually contain.
    """
    titles = sections or ["一、图表清单与来源", "二、坐标轴、单位与量纲", "三、主要趋势",
                          "四、关键数值与对比", "五、显著性、误差与样本", "六、结论与适用边界"]
    root = Path(inp)
    out = []
    tables, images, series_all = [], [], []
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        sfx, rel = p.suffix.lower(), p.name
        if sfx in (".png", ".jpg", ".jpeg"):
            info = png_info(p) if sfx == ".png" else None
            images.append({"file": rel, "info": info})
            out.append({"section": titles[0],
                        "claim": "%s 为位图（%d×%d 像素，位深 %d，颜色类型 %d）" % (
                            rel, info["w"], info["h"], info["depth"], info["ctype"])
                        if info else "%s 为位图文件，未解析出 IHDR 元信息" % rel,
                        "quote": "", "locator": "%s#IHDR" % rel})
        elif sfx in (".csv", ".tsv"):
            parsed = read_table(p)
            if not parsed:
                continue
            header, body = parsed
            cols = [h.strip() for h in header]
            tables.append((rel, cols, body))
            out.append({"section": titles[0],
                        "claim": "%s 含 %d 行 × %d 列，列名 %s" % (
                            rel, len(body), len(cols), "、".join(c for c in cols if c)),
                        "quote": ",".join(c.strip() for c in header),
                        "locator": "%s#header" % rel})
            num = []
            for j in range(1, len(cols)):
                vals = [(i, _num(r[j]), r) for i, r in enumerate(body)
                        if j < len(r) and _num(r[j]) is not None]
                if len(vals) >= 2:
                    num.append((cols[j], vals))
                    series_all.append((rel, cols[j], vals))
    for rel, cols, body in tables:
        lab = cols[0] if cols else "row"
        cats = [r[0].strip() for r in body if r]
        if len(cats) >= 2:
            out.append({"section": titles[1],
                        "claim": "%s 的 %s 列为类别（%s），其余为数值列；材料未标注单位" % (
                            rel, lab, "、".join(cats)),
                        "quote": ",".join(c.strip() for c in body[0]),
                        "locator": "%s#row2" % rel})
            out.append({"section": titles[1],
                        "claim": "%s 共 %d 个类别、%d 个数值列，未给出坐标轴刻度" % (
                            rel, len(cats), max(0, len(cols) - 1)),
                        "quote": ",".join(c.strip() for c in body[-1]),
                        "locator": "%s#row%d" % (rel, len(body) + 1)})
    for rel, name, vals in series_all:
        low = min(vals, key=lambda t: t[1])
        high = max(vals, key=lambda t: t[1])
        lab = lambda t: (t[2][0].strip() if t[2] else "row%d" % (t[0] + 2))
        order = sorted(vals, key=lambda t: -t[1])
        if len(order) >= 2:
            out.append({"section": titles[2],
                        "claim": "%s 由高到低为 %s" % (
                            name, " > ".join("%s(%s)" % (lab(t), _fmt(t[1]))
                                             for t in order[:4])),
                        "quote": ",".join(c.strip() for c in high[2]),
                        "locator": "%s#row%d" % (rel, high[0] + 2)})
            out.append({"section": titles[2],
                        "claim": "%s 最高为 %s 组的 %s，最低为 %s 组的 %s，相差 %s" % (
                            name, lab(high), _fmt(high[1]), lab(low), _fmt(low[1]),
                            _fmt(high[1] - low[1])),
                        "quote": ",".join(c.strip() for c in low[2]),
                        "locator": "%s#row%d" % (rel, low[0] + 2)})
        out.append({"section": titles[3],
                    "claim": "%s 的取值区间为 %s–%s，共 %d 个观测" % (
                        name, _fmt(low[1]), _fmt(high[1]), len(vals)),
                    "quote": ",".join(c.strip() for c in high[2]),
                    "locator": "%s#row%d" % (rel, high[0] + 2)})
    for rel, cols, body in tables:
        sem = [j for j, c in enumerate(cols)
               if _num(c.strip()) is None and c.strip().upper() in ("SEM", "SD", "SE", "STD")]
        notes = [j for j, c in enumerate(cols)
                 if any(x in c.strip().lower() for x in ("note", "p-value", "sig", "remark"))]
        for j in sem:
            got = [(i, _num(r[j])) for i, r in enumerate(body)
                   if j < len(r) and _num(r[j]) is not None]
            if got:
                out.append({"section": titles[4],
                            "claim": "%s 的 %s 列取值 %s–%s，为 %d 个类别给出了离散度" % (
                                rel, cols[j].strip(), _fmt(min(v for _i, v in got)),
                                _fmt(max(v for _i, v in got)), len(got)),
                            "quote": ",".join(c.strip() for c in body[got[0][0]]),
                            "locator": "%s#row%d" % (rel, got[0][0] + 2)})
        for j in notes:
            vals = sorted({r[j].strip() for r in body if j < len(r) and r[j].strip()})
            if vals:
                out.append({"section": titles[4],
                            "claim": "%s 的 %s 列取值为 %s，未见样本量 n" % (
                                rel, cols[j].strip(), "、".join(vals[:3])),
                            "quote": ",".join(c.strip() for c in body[0]),
                            "locator": "%s#row2" % rel})
    if series_all:
        rel, name, vals = series_all[0]
        order = sorted(vals, key=lambda t: -t[1])
        out.append({"section": titles[5],
                    "claim": "就 %s 而言，%s 组最高（%s），%s 组最低（%s）；材料未说明坐标轴单位与显著性检验细节" % (
                        name, order[0][2][0].strip(), _fmt(order[0][1]),
                        order[-1][2][0].strip(), _fmt(order[-1][1])),
                    "quote": ",".join(c.strip() for c in order[0][2]),
                    "locator": "%s#row%d" % (rel, order[0][0] + 2)})
    if images:
        out.append({"section": titles[5],
                    "claim": "图中元素的精确坐标、图例与刻度需结合位图判读；本报告只引用表格中可核对的数值",
                    "quote": "", "locator": "%s#IHDR" % images[0]["file"]})
    elif tables:
        out.append({"section": titles[5],
                    "claim": "材料只提供表格，无位图；结论以表格数值为限",
                    "quote": "", "locator": "%s#header" % tables[0][0]})
    return out

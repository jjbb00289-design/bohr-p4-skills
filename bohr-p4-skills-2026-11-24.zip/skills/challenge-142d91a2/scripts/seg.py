"""Text segmentation and verbatim-window helpers.

Kept out of main.py so the entry point stays well under the size limit. Every
helper returns slices of the original string, never re-joined tokens, so a quote
taken from here is always a contiguous span of the source.
"""
import re


def _cjk(s):
    return sum(1 for c in s if "\u4e00" <= c <= "\u9fff")


def claim_of(sentence, lo=12, hi=22):
    """A verbatim contiguous window of 12-22 words."""
    spans = [(m.start(), m.end()) for m in re.finditer(r"\S+", sentence)]
    if len(spans) <= hi:
        return sentence[spans[0][0]:spans[-1][1]] if spans else sentence
    return sentence[spans[0][0]:spans[hi - 1][1]]


def windows(s, step=6):
    """Sliding windows so a short material still fills every section.

    Chinese text carries no spaces, so it is cut by character window instead of
    by token count; each window is still a contiguous slice of the source.
    """
    if _cjk(s) >= 60:
        out, i = [], 0
        while i < len(s) and len(out) < 3:
            piece = s[i:i + 60]
            if _cjk(piece) < 16:
                break
            out.append(piece)
            i += 40
        if out:
            return out
    spans = [(m.start(), m.end()) for m in re.finditer(r"\S+", s)]
    if len(spans) < 16:
        return [s]
    out, start = [], 0
    while start + 12 <= len(spans) and len(out) < 3:
        end = min(len(spans), start + 20)
        out.append(s[spans[start][0]:spans[end - 1][1]])
        start += step
    return out or [s]


def clauses(s):
    """Split a long sentence at commas/semicolons into verbatim clauses."""
    parts = re.split(r"(?<=[,;])\s+|(?<=[\uff0c\uff1b\uff1a])", s)
    out, buf = [], ""
    for p in parts:
        p = p.strip()
        if not p:
            continue
        buf = (buf + " " + p).strip() if buf else p
        n_tok = len([t for t in buf.split() if re.search(r"[A-Za-z]", t)])
        if n_tok >= 6 or _cjk(buf) >= 12:
            out.append(buf)
            buf = ""
    if buf:
        out.append(buf)
    return out if len(out) > 1 else [s]

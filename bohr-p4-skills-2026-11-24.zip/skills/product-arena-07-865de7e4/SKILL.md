---
name: latex-writing-compilation
description: >
  LaTeX academic writing, revision, and reproducible compilation skill.
  Reads the fact draft and format constraints from a case, performs the
  specified editing/proofreading/structuring action on .tex sources, compiles
  with the available TeX engine, locates errors to file/line/root cause, and
  emits editable .tex plus a per-sentence diff, a fact/citation fidelity table,
  and a result.json with source evidence, uncertainty and change records.
version: 1.0.0
---

# LaTeX 写作与编译（学术写作）

## 1. 用途与适用条件

本 Skill 用于把一份科研材料（事实底稿、LaTeX 源文件、`.bib`、PDF、表格、DOCX、
SQLite 等）按题目指定的体裁、受众与格式约束，完成**指定动作**的学术写作产物，
并保证事实、数字、术语、引用与图表指向可逐条回溯到材料原文。

触发条件（满足其一即使用）：
- 任务要求围绕 `.tex` 源码做写作、改写、校对、格式、引用、双语或结构化产出；
- 任务要求把稿件迁入期刊/会议/学位论文模板并编译通过；
- 任务要求定位并修复 LaTeX 编译错误，或给出可重复构建记录；
- 输入目录含 `case.json` + `task.md` + 材料，且 `case.json` 带 `output_contract`。

不适用的情形：非 LaTeX/非学术写作任务；要求凭空生成材料外事实的任务。

## 2. 运行环境与调用方式

评测把本 Skill 装在 `/skills/weekly-skill`，运行时输入在 `/input`（`case.json`、
`task.md`、材料），工作目录 `/app/work`，最终产物写 `/app/output`（必须含
`result.json`）。材料按真实文件读取：PDF 可能是没有预抽文本层的真实 PDF，图片、
表格、DOCX、SQLite 都可能出现，**不得按标签假设内容，不得编造数据或软件状态**。

配套脚本 `scripts/main.py`（纯标准库、不联网、不依赖 CWD）提供确定性脚手架：

```bash
python3 /skills/weekly-skill/scripts/main.py init     # 抽取材料+生成工作稿骨架+partial result.json
python3 /skills/weekly-skill/scripts/main.py compile  # 编译目标 .tex，产出 compile_report.json
python3 /skills/weekly-skill/scripts/main.py check    # 校验 quote 命中率、契约键、产物
python3 /skills/weekly-skill/scripts/main.py build    # 组装 result.json 并拷贝交付物
python3 /skills/weekly-skill/scripts/main.py show     # 查看当前状态
python3 /skills/weekly-skill/scripts/main.py          # 默认：init→compile→check→build 完整流程
```

目录可用环境变量 `INPUT_DIR`/`WORK_DIR`/`OUTPUT_DIR` 或 `--input/--work/--output`
覆盖；默认保持平台路径 `/input`、`/app/work`、`/app/output`。所有命令退出码恒为
`0`，异常写入 `result.json` 的 `errors`/`degradations`，不崩溃、不产 0 字节结果。

## 3. 标准工作流（每步都要落盘，禁止只在对话中输出）

1. **初始化**：执行 `main.py init`。它把材料抽取到 `/app/work/extracted/*.txt`，
   生成 `manifest.json`（文件清单/类型/抽取状态）、`meta.json`（目标 `.tex`、引擎、
   契约字段）、`draft.json` 骨架，并先写一份 `partial` 的 `result.json`。
2. **读输入**：读 `case.json` 的 `task_instruction` 与 `output_contract`、`task.md`、
   `manifest.json`，再读 `work/extracted/` 下每个材料的抽取文本。确定任务的**具体
   动作**（生成 / 改写 / 校对 / 迁移模板 / 修复编译 / 双语 / 结构化）与**目标 `.tex`**。
3. **逐句处理**：按第 4 节编辑纪律完成修改，产出**可编辑 `.tex`**，写入
   `work/artifact/<原名>.tex`。每处改动与每处事实都在 `draft.json` 的 `claims`
   中记录（见第 5 节 schema）。
4. **配套对照**：在 `work/artifact/` 写 `diff.md`（原文—改文逐句对照 + 修改类型 +
   理由）与 `facts.md`（事实/术语/引用保真表）。两者都要能逐条指回 `source +
   locator + quote`。
5. **回填契约**：把 `output_contract` 的每个字段的值写入 `draft.json` 的 `outputs`
   （键名与契约完全一致）。缺值保持 `null`/`[]`，不改名、不漏键、不占位。
6. **校验**：执行 `main.py check`。要求 quote 命中率 ≥0.95、契约键全部有值、产物
   存在。不满足则回改 `draft.json` 或产物，直到通过。
7. **编译**：执行 `main.py compile`。真实调用可用引擎（`pdflatex`/`xelatex`/
   `lualatex`/`latexmk`），多轮收敛引用，日志写入 `work/build/`。**报错要定位到
   文件、行号、根因**，不要停在第一条错误；修复不得靠删除内容或放宽模板要求。
8. **收口**：执行 `main.py build`。它回填 `result.json`（契约字段 + `case_id` +
   `status` + `sources` + `uncertainty` + `change_records` + `errors` +
   `degradations`），并把可编辑 `.tex`、`diff.md`、`facts.md`、PDF（如编译成功）
   拷贝到 `/app/output`。接近 780 秒预算时立即 `build` 已完成的交付。

## 4. 编辑纪律（事实与来源保真）

- **不是整段重写**：交付“逐句可核验”的编辑，原文—改文逐句对照；保留原意与结构。
- **不得顺手改**数字、单位、符号、限定词强度、时态结论、显著性表述；除非题目明确
  要求修改，且该改动在 `change_records` 中有理由与原文 `quote` 支撑。
- 术语表、缩写首次出现（定义一次、后续用缩写）、引用编号、图表指向、公式编号必须
  与原文及模板要求一致；新增事实必须有材料来源，材料没有的一律标 `gap`/`needs_
  human_confirmation`，不得补造。
- 公式：符号与上下标、变量正斜体、单位写法、`\label`/`\eqref` 对应关系保持原义。
- 表格：数值与列宽、合并单元格、三线表样式符合原意与模板；溢出优先调列宽/断行，
  不靠 `\resizebox` 缩放掩盖。
- 引用：`.bib` 条目与正文 `\cite` 一一对应，样式与排序符合模板；`\ref`/`\cite`
  需多遍编译收敛，未定义引用要定位到缺失的 `\label`/`.bib` 键。

## 5. 工作稿 schema（`/app/work/draft.json`，由 Agent 编辑，脚本校验）

```json
{
  "schema_version": "1.0",
  "case_id": "来自 case.json",
  "task_summary": "任务一句话概括",
  "targets": [{"id": "main_tex", "kind": "tex", "path": "原始路径",
               "artifact": "artifact/xxx.tex"}],
  "claims": [
    {
      "id": "c1",
      "element": "number|term|citation|figure|formula|table|claim|reference",
      "location": "位于交付物的哪一段/哪一行",
      "text": "交付物中该元素的实际表述",
      "source": "材料相对路径（如 materials/paper.tex）",
      "locator": "行号或节/表/图编号，无法确定写 best-effort 描述",
      "quote": "材料原文的逐字引用（必须能在 extracted 文本中命中）",
      "action": "kept|edited|added|moved|removed",
      "change": "改了什么、为什么（kept 留空）",
      "status": "verified|unconfirmed|conflict|gap"
    }
  ],
  "outputs": {"<output_contract 的每个键>": "<对应值，缺值 null/[]>"},
  "degradations": ["诚实降级说明"],
  "human_confirm": ["需要人工确认的事项"]
}
```

`claims` 覆盖两类条目：**每一处改动**（action≠kept）与**交付物中每个数字/术语/
引用/图表/关键论断**（action=kept 也可留证）。`status=verified` 表示 quote 命中且
与原文一致；`conflict` 表示材料内部矛盾；`gap` 表示材料不足；`unconfirmed` 表示
待人工确认。

## 6. 证据规范（可核验性红线）

- 每个结论/条目/页面必须可回溯到 `source + locator + quote`；`quote` 是材料原文的
  **逐字片段**，`main.py check` 会在 `work/extracted/<source>.txt` 中做归一化命中
  检验，命中率必须 ≥0.95。
- 从 `work/extracted/` 复制 quote，不要改写；PDF 经 `pdftotext` 抽取后按抽取结果
  引用，locator 用页/节（pdf 抽取文本保留段落，页码按 `pdfinfo`/工具说明标注）。
- 图片/表格只读内容，不按标签猜；无法识别的二进制材料在 `manifest.json` 标
  `binary` 并进入 `degradations`。
- 编译器不可用时**不伪造 PDF**：交付 `.tex` + 编译报告，`degradations` 写明
  “compiler unavailable; PDF not produced”。

## 7. 编译协议与可重复构建

`main.py compile` 的行为与要求：
- 把输入树完整复制到 `/app/work/build/<stem>/` 后编译，保留相对 `\input`/
  `\includegraphics`/`\bibliography` 路径；设置 `SOURCE_DATE_EPOCH=0` 以稳定产物。
- 引擎选择：优先环境变量 `TEX_ENGINE`，否则按导言区探测（`fontspec/xeCJK/ctex/
  CJKutf8` 等 → `xelatex`，否则 `pdflatex`），找不到则退 `latexmk`，再找不到→降级。
- 多遍收敛：`-interaction=nonstopmode -file-line-error` 跑 1–3 遍，检测 “Rerun to
  get cross-references right” 决定是否再跑；有 `.bib` 时在轮间跑 `bibtex`。
- 产出 `compile_report.json`（engine/compiler_path/passes/errors/warnings/pdf/
  log_path/rerun_needed/bibliography_used）与完整日志 `build/<stem>.log`。
- 修复时按 `references/latex_diagnosis.md` 的错误分类定位根因，改源码后重新
  `compile`，直到无 error（warning 记录但不虚构修复）。

## 8. 降级表（诚实标注，写进 `degradations`）

| 情况 | 处置 | status |
|---|---|---|
| 无 TeX 引擎 | 交付 `.tex` + 诊断，不产 PDF | partial |
| 缺宏包/缺字体/缺 `.cls`/缺 `.bst` | 记录缺失项，先尝试模板自带文件，仍缺则标 degradation | partial |
| 编译错误级联 | 定位第一条根因 + 级联清单，修复后重编 | partial（未修复）/success |
| PDF 无文本层 / 图片无法识别 | 标注 `binary`/`no_text`，能 OCR 则标注 OCR 不确定性 | partial |
| 材料内部矛盾 / 数字冲突 | `claims` 标 `conflict`，进入 `uncertainty` | partial |
| 材料不足 | `claims` 标 `gap`，进入 `human_confirm` | partial |
| 输入为空/坏 JSON/缺材料/权限不足 | 产出合法 `result.json`，status 分别 `input_error` 或 `insufficient_evidence` | 见 status |

## 9. 自检（每次 build 前执行）

1. `result.json` 含 `output_contract` 全部键 + `case_id` + `status` + `sources` +
   `uncertainty` + `change_records` + `errors` + `degradations`，缺值 `null`/`[]`。
2. 可编辑 `.tex` 存在于 `/app/output`，是文本源码而非 PDF/截图。
3. `diff.md` 逐句对照完整；`facts.md` 每个数字/术语/引用/图表都可回溯。
4. `main.py check` 的 `quote.rate >= 0.95` 且 `contract_ok == true`。
5. 编译成功则 PDF 有 `%PDF-` 头；失败/无引擎则 degradation 如实标注，无伪造 PDF。
6. 重复运行产物结构一致（不依赖时间/随机）。

## 10. 限制

- 脚本只做确定性脚手架（抽取/编译/校验/组装），**语义层面的写作与修复由 Agent 按
  本 SKILL.md 执行**；没有工作稿时 `main.py` 只做“抽取 + 编译 + 直通源码 + 诚实
  partial”，不冒充已完成写作。
- 只支持纯 Python 标准库，不联网、不装包；TeX 引擎、`pdftotext`、字体等依赖运行时
  镜像，缺失时降级而非伪造。
- 编译目标自动选定为“含 `\documentclass` 或 `main.tex` 的最匹配 `.tex`”；多主文件
  工程需在 `draft.json.targets` 显式指定。

# result.json / draft.json 字段参考与状态语义

## 输入读取约定

- `case.json`：`case_id`、`output_contract`（dict 或字段名 list）、
  `task_instruction`。`output_contract` 是 result.json 必须**原样回填**的字段，
  不得改名、漏键。
- `task.md`：任务与约束补充说明。
- 材料：任意真实文件；PDF 无预抽文本层时经 `pdftotext` 抽取；DOCX 经
  `word/document.xml` 提取 `<w:t>`；SQLite 经 `sqlite_master` 逐表转文本。

## result.json 字段

| 字段 | 内容 |
|---|---|
| `<output_contract.*>` | 契约字段，值来自 `draft.json.outputs`，缺值 `null`（标量）/`[]`（数组）/`{}`（对象） |
| `case_id` | 原样来自 `case.json` |
| `status` | `success` / `partial` / `insufficient_evidence` / `input_error` |
| `sources` | 证据定位：claims 的 `{file, locator, quote, element, claim_id}` + manifest 文件清单 |
| `uncertainty` | 未确认/冲突/缺口条目 + 编译降级/错误 + `human_confirm` 项 |
| `change_records` | action≠kept 的 claims：`{claim_id, element, action, original, modified, reason}` |
| `errors` | 编译错误（`{type, line, message}`）+ 输入错误 + 运行错误 |
| `degradations` | draft 中的降级说明 + 自动检测到的降级（无引擎/无 .tex/无材料等） |
| `_meta` | engine/target/quote_rate/compile_passes 摘要 |

## status 判定顺序（脚本 `compute_status`）

1. `case.json` 缺失或非对象 → `input_error`
2. 无材料或无 `.tex` → `insufficient_evidence`
3. 契约字段存在缺值 → `partial`
4. quote 命中率 < 0.95 → `partial`
5. 任一 claim status ∈ {conflict, gap, unconfirmed, unverified} → `partial`
6. 编译器不可用或存在编译 error → `partial`
7. 其余 → `success`

## draft.json.claims 字段语义

| 字段 | 含义 |
|---|---|
| `element` | `number|term|citation|figure|formula|table|claim|reference` |
| `location` | 交付物中的位置（节/段/行） |
| `text` | 交付物中该元素的实际表述 |
| `source` | 材料相对路径（与 `manifest.json` 的 `path` 一致） |
| `locator` | 行号/节/表/图编号；PDF 用页号，无法精确则 best-effort 描述 |
| `quote` | 材料原文逐字片段，`main.py check` 做归一化子串命中 |
| `action` | `kept|edited|added|moved|removed` |
| `change` | 修改理由与内容（kept 留空） |
| `status` | `verified|unconfirmed|conflict|gap` |

## quote 命中校验

- 归一化：连续空白压成一个空格后 strip。
- 命中：`quote` 归一化后是 `work/extracted/<source 安全名>.txt` 文本的子串。
- 命中率 = 命中数 / 有 quote 的 claim 总数；无 quote 的 claim 不计数。
- 红线：≥0.95；低于时回改 quote（从 extracted 文本复制）或 source 路径。

## 契约键值推断

- `output_contract` 为 dict 时，按其值类型推断缺省：list→`[]`、dict→`{}`、
  其他→`null`；为 list 时每个字段缺省 `null`。

# LaTeX 错误分类、根因定位与修复映射

编译日志由 `main.py compile` 落盘 `work/build/<stem>.log`，错误以
`{message, line}` 解析进 `compile_report.json`。修复要定位**根因**而非停在第一条
错误；级联错误（一个未定义命令引发几十条）只修根因一处。

## 错误分类与修复

| 日志特征 | 根因 | 修复动作 |
|---|---|---|
| `Undefined control sequence` + `l.N \foo` | 未定义命令/宏包未载 | 补 `\usepackage` 或改回模板支持的宏；不改业务语义 |
| `Missing $ inserted` / `Missing \endcsname` | 数学环境漏 `$`/`\[` 或错用文本模式 | 按上下文补或去 `$`，保持公式符号含义 |
| `Runaway argument` / `Paragraph ended before` | 环境/命令参数换行或 `{}` 不配对 | 修正配对与 `%` 续行 |
| `File 'x.cls' not found` / `.sty/.bst` | 模板类文件/宏包/参考文献样式缺失 | 优先用输入树自带文件，仍缺→`degradations`，不伪造 |
| `! LaTeX Error: Can be used only in preamble` | 包在 `\begin{document}` 后载 | 移到导言区 |
| `No file x.bbl` / `Citation 'key' undefined` | 未跑 bibtex 或 `.bib` 键不匹配 | 轮间跑 `bibtex`；对齐 `\cite` 与 `.bib` 键 |
| `Reference 'lbl' undefined` | 缺 `\label`/`\ref` 不匹配 | 补 `\label` 或改 `\ref` 指向 |
| `Label 'x' multiply defined` | 重复 `\label` | 删重复标签，保留正确指向 |
| `Overfull \hbox (N pt too wide)` | 表格/公式/行宽溢出 | 调列宽/断行/换行点，不靠缩放掩盖 |
| `Missing font` / `fontspec error` | 字体缺失 | 换运行时可用字体或标注 degradation |
| `Rerun to get cross-references right` | 交叉引用需再遍 | 按 `rerun_needed` 多遍编译至收敛 |

## 可重复构建记录（写入交付说明）

按以下字段如实记录，供他人在同环境复现同一份产物：

- TeX 发行版/引擎与版本（`compile_report.json` 的 `engine`、`compiler_path`）；
- 宏包与字体版本（从日志 `Package:`/字体信息摘录，能拿到的才写）；
- 编译命令与轮次（`engine + 参数`、`passes`、是否 `bibtex`）；
- 输入文件哈希（`manifest.json` 的 `path` + `size`）。

拿不到版本信息就写“未记录”，不编造版本号。

## 修复纪律

- 只改源码语法与结构，不改事实、数字、单位、公式符号、引用键指向的语义。
- 模板必填项（作者、单位、摘要、关键词、基金号、通讯作者）逐项补齐；原文没有的
  留空并标 `gap`，不得杜撰。
- 无法修复的根因进入 `degradations`，产物仍交付可编辑 `.tex`，不删除内容“假装
  编译过”。

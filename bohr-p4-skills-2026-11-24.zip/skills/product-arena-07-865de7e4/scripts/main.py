#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""LaTeX writing & compilation skill entry point.

Default command runs the full deterministic pipeline:
init (extract materials + scaffold draft) -> compile -> check -> build.

Pure Python standard library; no network; CWD-independent.
"""
import argparse
import json
import os
import shutil
import sys
import traceback
from pathlib import Path

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import texutil  # noqa: E402

PLATFORM_INPUT = "/input"
PLATFORM_WORK = "/app/work"
PLATFORM_OUTPUT = "/app/output"


def resolve_dirs(args):
    inp = args.input or os.environ.get("INPUT_DIR") or PLATFORM_INPUT
    work = args.work or os.environ.get("WORK_DIR") or PLATFORM_WORK
    out = args.output or os.environ.get("OUTPUT_DIR") or PLATFORM_OUTPUT
    return Path(inp), Path(work), Path(out)


def contract_default(value):
    if isinstance(value, list):
        return []
    if isinstance(value, dict):
        return {}
    return None


def load_case(input_dir):
    case_path = Path(input_dir) / "case.json"
    if not case_path.exists():
        return {"case_id": None, "output_contract": {}, "task_instruction": "",
                "raw": {}, "error": "case.json missing"}
    try:
        raw = json.loads(case_path.read_text(encoding="utf-8-sig"))
    except Exception as e:
        return {"case_id": None, "output_contract": {}, "task_instruction": "",
                "raw": {}, "error": "case.json not valid JSON: %s" % str(e)[:200]}
    if not isinstance(raw, dict):
        return {"case_id": None, "output_contract": {}, "task_instruction": "",
                "raw": raw, "error": "case.json is not an object"}
    oc = raw.get("output_contract") or {}
    if isinstance(oc, list):
        oc = {str(k): None for k in oc}
    if not isinstance(oc, dict):
        oc = {}
    case_id = raw.get("case_id") or raw.get("id") or raw.get("caseId")
    task = raw.get("task_instruction") or raw.get("task") or raw.get("instruction") or ""
    return {"case_id": case_id, "output_contract": oc,
            "task_instruction": task, "raw": raw, "error": None}


def read_task_md(input_dir):
    p = Path(input_dir) / "task.md"
    if p.exists():
        return texutil.read_text(p)
    return ""


def cmd_init(input_dir, work_dir, output_dir):
    work_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    case = load_case(input_dir)
    task_md = read_task_md(input_dir)
    manifest = texutil.extract_materials(input_dir, work_dir)
    target_rel, target_text = texutil.find_tex_target(manifest, input_dir)
    engine = os.environ.get("TEX_ENGINE") or texutil.detect_engine(target_text)
    draft_path = work_dir / "draft.json"
    if not draft_path.exists():
        outputs = {k: contract_default(v)
                   for k, v in case["output_contract"].items()}
        draft = {
            "schema_version": "1.0",
            "case_id": case["case_id"],
            "task_summary": (case["task_instruction"] or task_md)[:2000],
            "targets": [{"id": "main_tex", "kind": "tex",
                         "path": target_rel or None,
                         "artifact": ("artifact/" + (target_rel or "main.tex"))
                                      if target_rel else None}],
            "claims": [],
            "outputs": outputs,
            "degradations": [],
            "human_confirm": [],
        }
        draft_path.write_text(json.dumps(draft, ensure_ascii=False, indent=1),
                              encoding="utf-8")
    meta = {
        "case_id": case["case_id"],
        "case_error": case["error"],
        "target_rel": target_rel,
        "engine": engine,
        "has_materials": len(manifest) > 0,
        "has_tex": target_rel is not None,
        "contract_fields": list(case["output_contract"].keys()),
    }
    (work_dir / "meta.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    (work_dir / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    (work_dir / "task.md.txt").write_text(task_md, encoding="utf-8")
    # partial result written early, per runtime contract
    write_partial_result(case, meta, work_dir, output_dir)
    return case, meta, manifest


def write_partial_result(case, meta, work_dir, output_dir):
    result = assemble_result(case, meta, draft={}, compile_result=None,
                             check=None, status="partial",
                             errors=[], degradations=[])
    (output_dir / "result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")


def cmd_compile(input_dir, work_dir, output_dir):
    meta = load_meta(work_dir)
    target = meta.get("target_rel")
    if not target:
        cr = {"engine": meta.get("engine"), "target": None, "available": False,
              "errors": [], "warnings": [], "pdf": None, "log_path": None,
              "passes": 0, "degradations": ["no .tex target found"],
              "rerun_needed": False, "bibliography_used": False}
    else:
        cr = texutil.compile_tex(input_dir, work_dir, target,
                                 engine=meta.get("engine"))
    (work_dir / "compile_report.json").write_text(
        json.dumps(cr, ensure_ascii=False, indent=1), encoding="utf-8")
    return cr


def load_meta(work_dir):
    p = Path(work_dir) / "meta.json"
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8-sig"))
        except Exception:
            pass
    return {}


def load_draft(work_dir):
    p = Path(work_dir) / "draft.json"
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8-sig"))
        except Exception:
            return {}
    return {}


def cmd_check(work_dir, input_dir):
    draft = load_draft(work_dir)
    meta = load_meta(work_dir)
    quote = texutil.verify_quotes(draft, work_dir)
    contract_fields = meta.get("contract_fields", [])
    outputs = draft.get("outputs", {})
    missing = [k for k in contract_fields
               if k not in outputs or outputs[k] in (None, [], {})]
    targets = draft.get("targets", [])
    artifacts = []
    art_dir = Path(work_dir) / "artifact"
    if art_dir.exists():
        artifacts = sorted(p.name for p in art_dir.iterdir() if p.is_file())
    check = {
        "quote": quote,
        "quote_rate_ok": quote.get("rate") is None or quote.get("rate") >= 0.95,
        "contract_missing": missing,
        "contract_ok": len(missing) == 0,
        "artifacts": artifacts,
        "claims": len(draft.get("claims", [])),
    }
    (work_dir / "check_report.json").write_text(
        json.dumps(check, ensure_ascii=False, indent=1), encoding="utf-8")
    return check


def build_sources(case, meta, draft, manifest):
    out = []
    for c in draft.get("claims", []):
        if c.get("source") or c.get("quote"):
            out.append({"file": c.get("source"), "locator": c.get("locator"),
                        "quote": c.get("quote"), "element": c.get("element"),
                        "claim_id": c.get("id")})
    for m in manifest:
        out.append({"file": m["path"], "kind": m["kind"],
                    "extracted": m["extracted"], "note": m["note"]})
    return out


def build_uncertainty(draft, compile_result):
    out = []
    for c in draft.get("claims", []):
        st = c.get("status", "verified")
        if st in ("unconfirmed", "conflict", "gap", "unverified"):
            out.append({"claim_id": c.get("id"), "element": c.get("element"),
                        "status": st, "note": c.get("change", "")[:500]})
    for h in draft.get("human_confirm", []):
        out.append({"item": str(h)[:500], "status": "needs_human_confirmation"})
    if compile_result:
        if not compile_result.get("available"):
            out.append({"item": "compile not verified: compiler unavailable",
                        "status": "degradation"})
        elif compile_result.get("errors"):
            out.append({"item": "compile produced %d error(s)" %
                        len(compile_result["errors"]), "status": "compile_error"})
    return out


def build_change_records(draft):
    out = []
    for c in draft.get("claims", []):
        if c.get("action", "kept") != "kept":
            out.append({
                "claim_id": c.get("id"),
                "element": c.get("element"),
                "action": c.get("action"),
                "original": c.get("quote"),
                "modified": c.get("text"),
                "reason": c.get("change"),
            })
    return out


def assemble_result(case, meta, draft, compile_result, check, status,
                    errors, degradations, manifest=None):
    result = {}
    for k in case.get("output_contract", {}):
        result[k] = draft.get("outputs", {}).get(k, contract_default(
            case["output_contract"][k]))
    result["case_id"] = case.get("case_id")
    result["status"] = status
    result["sources"] = build_sources(case, meta, draft, manifest or [])
    result["uncertainty"] = build_uncertainty(draft, compile_result)
    result["change_records"] = build_change_records(draft)
    result["errors"] = errors
    result["degradations"] = degradations
    result["_meta"] = {
        "engine": meta.get("engine"),
        "target": meta.get("target_rel"),
        "quote_rate": (check or {}).get("quote", {}).get("rate"),
        "compile_passes": (compile_result or {}).get("passes"),
    }
    return result


def compute_status(case, meta, draft, compile_result, check):
    if meta.get("case_error"):
        return "input_error"
    if not meta.get("has_materials") or not meta.get("has_tex"):
        return "insufficient_evidence"
    if check and not check.get("contract_ok"):
        return "partial"
    if check and not check.get("quote_rate_ok"):
        return "partial"
    for c in draft.get("claims", []):
        if c.get("status") in ("conflict", "gap", "unconfirmed", "unverified"):
            return "partial"
    if compile_result:
        if not compile_result.get("available"):
            return "partial"
        if compile_result.get("errors"):
            return "partial"
    return "success"


def cmd_build(input_dir, work_dir, output_dir):
    case = load_case(input_dir)
    meta = load_meta(work_dir)
    draft = load_draft(work_dir)
    compile_result = None
    cp = work_dir / "compile_report.json"
    if cp.exists():
        try:
            compile_result = json.loads(cp.read_text(encoding="utf-8"))
        except Exception:
            compile_result = None
    check = None
    ckp = work_dir / "check_report.json"
    if ckp.exists():
        try:
            check = json.loads(ckp.read_text(encoding="utf-8"))
        except Exception:
            check = None
    manifest = []
    mp = work_dir / "manifest.json"
    if mp.exists():
        try:
            manifest = json.loads(mp.read_text(encoding="utf-8"))
        except Exception:
            manifest = []
    # copy editable artifacts to output
    copies = []
    art_dir = work_dir / "artifact"
    if art_dir.exists():
        for p in sorted(art_dir.iterdir()):
            if p.is_file():
                dst = output_dir / p.name
                shutil.copy2(p, dst)
                copies.append(p.name)
    # baseline: passthrough the source .tex when no artifact exists
    target = meta.get("target_rel")
    if target and not any(c.endswith(".tex") for c in copies):
        src = Path(input_dir) / target
        if src.exists():
            dst = output_dir / Path(target).name
            shutil.copy2(src, dst)
            copies.append(Path(target).name)
    if compile_result and compile_result.get("pdf"):
        pdf = work_dir / compile_result["pdf"]
        if pdf.exists():
            shutil.copy2(pdf, output_dir / pdf.name)
    for extra in ("compile_report.json", "check_report.json", "manifest.json",
                  "draft.json"):
        p = work_dir / extra
        if p.exists():
            shutil.copy2(p, output_dir / extra)
    errors = []
    degradations = list(draft.get("degradations", []))
    if compile_result:
        for e in compile_result.get("errors", []):
            errors.append({"type": "compile_error", "line": e.get("line"),
                           "message": e.get("message")})
        degradations.extend(compile_result.get("degradations", []))
    if meta.get("case_error"):
        errors.append({"type": "input_error", "message": meta["case_error"]})
    if not meta.get("has_tex"):
        degradations.append("no .tex source found in materials")
    if not meta.get("has_materials"):
        degradations.append("no materials present in input")
    status = compute_status(case, meta, draft, compile_result, check)
    result = assemble_result(case, meta, draft, compile_result, check,
                             status, errors, degradations, manifest)
    (output_dir / "result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
    return result, copies


def cmd_show(input_dir, work_dir, output_dir):
    meta = load_meta(work_dir)
    draft = load_draft(work_dir)
    info = {
        "case_id": meta.get("case_id"),
        "case_error": meta.get("case_error"),
        "target_tex": meta.get("target_rel"),
        "engine": meta.get("engine"),
        "materials": meta.get("has_materials"),
        "has_tex": meta.get("has_tex"),
        "claims": len(draft.get("claims", [])),
        "outputs_filled": sum(1 for v in draft.get("outputs", {}).values()
                              if v not in (None, [], {})),
        "outputs_total": len(draft.get("outputs", {})),
    }
    print(json.dumps(info, ensure_ascii=False, indent=1))


def cmd_run(input_dir, work_dir, output_dir):
    try:
        case, meta, manifest = cmd_init(input_dir, work_dir, output_dir)
        cr = cmd_compile(input_dir, work_dir, output_dir)
        chk = cmd_check(work_dir, input_dir)
        result, copies = cmd_build(input_dir, work_dir, output_dir)
        return result
    except Exception:
        return finalize_on_error(input_dir, work_dir, output_dir)


def finalize_on_error(input_dir, work_dir, output_dir):
    try:
        case = load_case(input_dir)
        meta = load_meta(work_dir)
        tb = traceback.format_exc()[-3000:]
        result = assemble_result(case, meta, {}, None, None, "partial",
                                 [{"type": "runtime_error", "message": tb}],
                                 ["unexpected runtime error; see errors"])
        result.setdefault("case_id", case.get("case_id"))
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "result.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception:
        (Path(output_dir) / "result.json").write_text(
            json.dumps({"case_id": None, "status": "input_error",
                        "errors": [{"type": "fatal", "message": "pipeline failed"}],
                        "degradations": ["fatal pipeline error"]},
                       ensure_ascii=False), encoding="utf-8")
    return None


def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="main.py",
        description="LaTeX writing/compilation skill: deterministic pipeline.")
    ap.add_argument("command", nargs="?", default="run",
                    choices=["run", "init", "compile", "check", "build",
                             "show"])
    ap.add_argument("--input", default=None)
    ap.add_argument("--work", default=None)
    ap.add_argument("--output", default=None)
    args = ap.parse_args(argv)
    inp, work, out = resolve_dirs(args)
    if args.command == "init":
        cmd_init(inp, work, out)
        print("init ok")
    elif args.command == "compile":
        cmd_compile(inp, work, out)
        print("compile ok")
    elif args.command == "check":
        cmd_check(work, inp)
        print("check ok")
    elif args.command == "build":
        cmd_build(inp, work, out)
        print("build ok")
    elif args.command == "show":
        cmd_show(inp, work, out)
    else:
        result = cmd_run(inp, work, out)
        status = (result or {}).get("status", "partial")
        print("run ok status=%s" % status)
    return 0


if __name__ == "__main__":
    sys.exit(main())

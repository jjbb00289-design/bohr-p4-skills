#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic helpers for the LaTeX writing/compilation skill.

Pure Python standard library. No network. No CWD dependency.
"""
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import zipfile
from pathlib import Path

UTF8 = "utf-8"
WS_RE = re.compile(r"\s+")


def norm(s):
    if s is None:
        return ""
    return WS_RE.sub(" ", str(s)).strip()


def read_text(path, default=""):
    try:
        return Path(path).read_text(encoding=UTF8, errors="replace")
    except Exception:
        return default


def find_tool(name):
    p = shutil.which(name)
    return p


def extract_pdf_text(path, tool=None):
    tool = tool or find_tool("pdftotext")
    if not tool:
        return None, "pdftotext not available"
    try:
        r = subprocess.run(
            [tool, "-enc", "UTF-8", str(path), "-"],
            capture_output=True, timeout=120)
        if r.returncode != 0:
            return None, r.stderr.decode(UTF8, "replace")[:500]
        return r.stdout.decode(UTF8, "replace"), None
    except Exception as e:
        return None, str(e)[:500]


def extract_docx_text(path):
    try:
        with zipfile.ZipFile(str(path)) as z:
            xml = z.read("word/document.xml").decode(UTF8, "replace")
    except Exception as e:
        return None, str(e)[:300]
    parts = re.findall(r"<w:t[^>]*>(.*?)</w:t>", xml, flags=re.S)
    text = "".join(parts)
    text = (text.replace("&lt;", "<").replace("&gt;", ">")
            .replace("&amp;", "&").replace("&quot;", '"')
            .replace("&apos;", "'"))
    return text, None


def extract_sqlite(path):
    try:
        con = sqlite3.connect(str(path))
        cur = con.cursor()
        tables = [r[0] for r in cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")]
        out = []
        for t in tables:
            try:
                rows = cur.execute("SELECT * FROM %s" % t).fetchall()
                cols = [d[0] for d in cur.description]
                out.append("## TABLE %s (%d rows)" % (t, len(rows)))
                out.append("| " + " | ".join(cols) + " |")
                for row in rows[:200]:
                    cells = [str(c) for c in row]
                    out.append("| " + " | ".join(cells) + " |")
            except Exception:
                out.append("## TABLE %s (unreadable)" % t)
        con.close()
        return "\n".join(out), None
    except Exception as e:
        return None, str(e)[:300]


def extract_json_text(path):
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8-sig",
                                               errors="replace"))
        return json.dumps(data, ensure_ascii=False, indent=1), None
    except Exception as e:
        return None, str(e)[:300]


TEXT_EXT = {".txt", ".md", ".tex", ".bib", ".sty", ".cls", ".csv", ".yaml",
            ".yml", ".log", ".aux", ".rtf"}


def extract_file(path):
    p = Path(path)
    ext = p.suffix.lower()
    if ext in TEXT_EXT:
        return "text", read_text(path), None
    if ext == ".pdf":
        t, err = extract_pdf_text(path)
        return ("pdf", t, err)
    if ext in {".docx", ".doc"}:
        t, err = extract_docx_text(path)
        return ("docx", t, err)
    if ext in {".sqlite", ".db", ".sqlite3"}:
        t, err = extract_sqlite(path)
        return ("sqlite", t, err)
    if ext == ".json":
        t, err = extract_json_text(path)
        return ("json", t, err)
    if ext in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg",
               ".pptx", ".xlsx"}:
        return ("binary", None, "binary; not text-extracted")
    return ("binary", None, "unrecognized; not text-extracted")


def safe_name(relpath):
    return re.sub(r"[^A-Za-z0-9._-]", "_", relpath.replace("\\", "/"))


def list_input_files(root):
    root = Path(root)
    if not root.exists():
        return []
    out = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            rel = p.relative_to(root).as_posix()
            out.append(rel)
    return out


def extract_materials(input_dir, work_dir):
    input_dir = Path(input_dir)
    work_dir = Path(work_dir)
    ext_dir = work_dir / "extracted"
    ext_dir.mkdir(parents=True, exist_ok=True)
    manifest = []
    for rel in list_input_files(input_dir):
        abs_p = input_dir / rel
        kind, text, err = extract_file(abs_p)
        entry = {
            "path": rel,
            "kind": kind,
            "size": abs_p.stat().st_size if abs_p.exists() else 0,
            "extracted": None,
            "note": err,
        }
        if text is not None:
            out_name = safe_name(rel) + ".txt"
            (ext_dir / out_name).write_text(text, encoding=UTF8)
            entry["extracted"] = "extracted/" + out_name
            entry["chars"] = len(text)
        manifest.append(entry)
    return manifest


def find_tex_target(manifest, input_dir):
    texes = [m for m in manifest if m["path"].lower().endswith(".tex")]
    if not texes:
        return None, None
    input_dir = Path(input_dir)
    scored = []
    for m in texes:
        text = read_text(input_dir / m["path"])
        score = 0
        if "\\documentclass" in text:
            score += 100
        if m["path"].lower().endswith("main.tex"):
            score += 10
        score += min(m["size"] // 1000, 5)
        scored.append((score, m["path"], text))
    scored.sort(key=lambda x: (-x[0], x[1]))
    target_rel, target_text = scored[0][1], scored[0][2]
    return target_rel, target_text


def detect_engine(tex_text):
    t = tex_text or ""
    for kw in ("fontspec", "xeCJK", "ctex", "CJKutf8", "polyglossia",
               "unicode-math", "XeLaTeX"):
        if kw in t:
            return "xelatex"
    return "pdflatex"


def find_compiler(engine):
    if engine in ("xelatex", "lualatex", "pdflatex"):
        p = find_tool(engine)
        if p:
            return engine, p
    p = find_tool("latexmk")
    if p:
        return "latexmk", p
    return None, None


TEX_ERROR_RE = re.compile(r"^!.*")
LINE_RE = re.compile(r"l\.(\d+)")


def parse_tex_log(log_text):
    errors, warnings, rerun = [], [], False
    lines = log_text.splitlines()
    i = 0
    current = None
    while i < len(lines):
        line = lines[i]
        if line.startswith("!"):
            if current:
                errors.append(current)
            current = {"message": line[1:].strip(), "line": None}
            i += 1
            continue
        if current is not None:
            m = LINE_RE.search(line)
            if m and current["line"] is None:
                current["line"] = int(m.group(1))
            if line.startswith("!") or (line.strip() == "" and i > 0 and
                                        lines[i-1].startswith("l.")):
                if not line.startswith("!"):
                    i += 1
                continue
            current["message"] += " " + line.strip()
            if line.strip() and current["line"] is not None and len(
                    current["message"]) > 600:
                errors.append(current)
                current = None
        if ("Warning:" in line or "Overfull" in line or "Underfull" in line
                or "undefined" in line.lower()):
            warnings.append(line.strip())
        if "Rerun" in line and "cross-reference" in line:
            rerun = True
        i += 1
    if current:
        errors.append(current)
    for e in errors:
        e["message"] = re.sub(r"\s+", " ", e["message"]).strip()[:800]
    return errors, warnings, rerun


def stage_inputs(input_dir, build_dir):
    build_dir = Path(build_dir)
    if build_dir.exists():
        shutil.rmtree(build_dir)
    build_dir.mkdir(parents=True)
    for rel in list_input_files(input_dir):
        src = Path(input_dir) / rel
        dst = build_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def compile_tex(input_dir, work_dir, target_rel, engine=None, max_passes=3):
    work_dir = Path(work_dir)
    stem = Path(target_rel).stem
    build_dir = work_dir / "build" / stem
    input_dir = Path(input_dir)
    tex_text = read_text(input_dir / target_rel)
    engine = engine or detect_engine(tex_text)
    compiler, compiler_path = find_compiler(engine)
    result = {
        "engine": engine,
        "target": target_rel,
        "available": compiler_path is not None,
        "compiler": compiler,
        "compiler_path": compiler_path,
        "passes": 0,
        "errors": [],
        "warnings": [],
        "pdf": None,
        "log_path": None,
        "degradations": [],
        "rerun_needed": False,
        "bibliography_used": False,
    }
    if compiler_path is None:
        result["degradations"].append(
            "latex compiler '%s' not found on PATH" % engine)
        return result
    stage_inputs(input_dir, build_dir)
    env = dict(os.environ)
    env["SOURCE_DATE_EPOCH"] = "0"
    env.setdefault("TEXMFHOME", "")
    tex_rel = Path(target_rel)
    tex_name = tex_rel.name
    tex_sub = tex_rel.parent.as_posix()
    cwd = str(build_dir / tex_sub)
    cmd_target = tex_name if not tex_sub or tex_sub == "." else \
        (tex_sub + "/" + tex_name)
    logs = []
    bib_done = False
    for p in range(1, max_passes + 1):
        if compiler == "latexmk":
            cmd = [compiler_path, "-pdf", "-interaction=nonstopmode",
                   "-halt-on-error", cmd_target]
        else:
            cmd = [compiler_path, "-interaction=nonstopmode",
                   "-file-line-error", cmd_target]
        try:
            r = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True,
                               timeout=600)
        except Exception as e:
            result["degradations"].append(
                "compile pass %d failed to run: %s" % (p, str(e)[:300]))
            break
        logs.append(r.stdout.decode(UTF8, "replace"))
        result["passes"] = p
        if not bib_done and _uses_bibliography(build_dir, tex_text):
            result["bibliography_used"] = True
            bib = find_tool("bibtex")
            if bib:
                try:
                    subprocess.run([bib, stem], cwd=cwd, env=env,
                                   capture_output=True, timeout=300)
                except Exception:
                    pass
            bib_done = True
        if compiler != "latexmk" and p < max_passes:
            errs, warns, rerun = parse_tex_log(logs[-1])
            result["errors"] = errs
            result["warnings"] = warns
            result["rerun_needed"] = rerun
            if not rerun and not errs:
                break
    full_log = "\n\n=== PASS ===\n\n".join(logs)
    log_path = work_dir / "build" / (stem + ".log")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text(full_log, encoding=UTF8)
    result["log_path"] = "build/" + (stem + ".log")
    final_errs, final_warns, final_rerun = parse_tex_log(full_log)
    result["errors"] = final_errs
    result["warnings"] = final_warns
    result["rerun_needed"] = final_rerun
    sub = tex_sub if tex_sub and tex_sub != "." else ""
    pdf_rel = "build/" + stem + "/" + (sub + "/" if sub else "") + stem + ".pdf"
    pdf = build_dir / (sub if sub else ".") / (stem + ".pdf")
    if pdf.exists():
        result["pdf"] = pdf_rel
    return result


def _uses_bibliography(cwd, tex_text):
    if not tex_text:
        return False
    if re.search(r"\\bibliography\s*\{", tex_text) or \
       re.search(r"\\addbibresource\s*\{", tex_text):
        return True
    for p in Path(cwd).rglob("*.bib"):
        return True
    return False


def verify_quotes(draft, work_dir):
    claims = draft.get("claims", [])
    ext_dir = Path(work_dir) / "extracted"
    results = []
    total = 0
    hits = 0
    for c in claims:
        quote = norm(c.get("quote", ""))
        if not quote:
            results.append({"id": c.get("id"), "hit": None,
                            "reason": "no quote provided"})
            continue
        total += 1
        src = c.get("source", "")
        text = read_text(ext_dir / (safe_name(src) + ".txt")) if src else ""
        if not text and src:
            text = read_text(Path(work_dir).parent / src)
        ok = norm(quote) in norm(text) if text else False
        if ok:
            hits += 1
        results.append({"id": c.get("id"), "hit": ok,
                        "source": src,
                        "reason": None if ok else "quote not found in source"})
    rate = (hits / total) if total else None
    return {"total": total, "hits": hits, "rate": rate, "items": results}

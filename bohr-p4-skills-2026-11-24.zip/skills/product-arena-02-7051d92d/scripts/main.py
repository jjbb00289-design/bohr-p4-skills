"""Entry point for academic-language-polish (deterministic init -> check -> build).

Reads /input (case.json + task.md + materials); writes /app/work (draft.json,
check.json) and /app/output (result.json + editable artifacts + previews).
Stdlib only, no network, no CWD dependence, exit code always 0. Paths resolve via
--input/--work/--output, then INPUT_DIR/WORK_DIR/OUTPUT_DIR, then platform defaults.
"""
import argparse
import html
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from extract import (  # noqa: E402
    _read_text, scan_input, split_sentences, extract_facts, extract_terms,
    run_check, apply_edits,
)


def log(msg):
    print(msg, file=sys.stderr)


def resolve_paths(args):
    inp = args.input or os.environ.get("INPUT_DIR") or "/input"
    work = args.work or os.environ.get("WORK_DIR") or "/app/work"
    out = args.output or os.environ.get("OUTPUT_DIR") or "/app/output"
    return Path(inp), Path(work), Path(out)


def load_case(inp):
    p = inp / "case.json"
    if not p.is_file():
        return {}, "case.json missing", []
    try:
        case = json.loads(_read_text(p))
        if not isinstance(case, dict):
            return {}, "case.json is not an object", []
        return case, None, []
    except Exception as e:
        return {}, "bad case.json: %s" % e, []


def load_task(inp):
    p = inp / "task.md"
    if p.is_file():
        try:
            return _read_text(p)
        except Exception:
            return ""
    return ""


def get_case_id(case, inp):
    for k in ("case_id", "id"):
        v = case.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return (inp / "case.json").stem


def get_instruction(case, task_text):
    for k in ("task_instruction", "instruction", "task", "prompt"):
        v = case.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return task_text.strip() or ""


def normalize_contract(oc):
    if isinstance(oc, dict):
        return [{"name": k, "spec": v} for k, v in oc.items()]
    if isinstance(oc, list):
        out = []
        for item in oc:
            if isinstance(item, str):
                out.append({"name": item, "spec": None})
            elif isinstance(item, dict):
                name = (item.get("name") or item.get("field")
                        or item.get("key") or item.get("id"))
                if name:
                    out.append({"name": name, "spec": item})
        return out
    if isinstance(oc, str) and oc.strip():
        return [{"name": oc, "spec": None}]
    return []


_INLINE_KEYS = ("source_text", "draft", "text", "document", "manuscript",
                "body", "content", "abstract", "main_text")


def select_draft(case, sources):
    for key in _INLINE_KEYS:
        v = case.get(key)
        if isinstance(v, str) and len(v.strip()) >= 40:
            return v.strip(), "case.json"
    texts = [s for s in sources if s["text"].strip()]
    if texts:
        largest = max(texts, key=lambda s: len(s["text"]))
        return largest["text"].strip(), largest["id"]
    return "", ""


def build_draft(inp, case, task_text, sources, errors, degradations):
    case_id = get_case_id(case, inp)
    instruction = get_instruction(case, task_text)
    contract = normalize_contract(case.get("output_contract"))
    draft_text, draft_src = select_draft(case, sources)

    if not draft_text:
        degradations.append("no readable draft text extracted from materials")

    segments = []
    for start, end, text in split_sentences(draft_text):
        segments.append({
            "id": "seg%04d" % (len(segments) + 1),
            "source_id": draft_src,
            "locator": "%s:%d:%d" % (draft_src, start, end),
            "start": start,
            "end": end,
            "text": text,
        })

    facts = []
    for f in extract_facts(draft_text):
        facts.append({
            "id": "fact%04d" % (len(facts) + 1),
            "kind": f["kind"],
            "quote": f["quote"],
            "start": f["start"],
            "end": f["end"],
            "source_id": draft_src,
            "locator": "%s:%d:%d" % (draft_src, f["start"], f["end"]),
        })

    terms = []
    for t in extract_terms(draft_text):
        terms.append({
            "id": "trm%04d" % (len(terms) + 1),
            "canonical": t["canonical"],
            "definition": t["definition"],
            "variants": t["variants"],
            "first_occurrence": "%s:%d" % (draft_src, t["start"]),
            "source_id": draft_src,
            "locator": "%s:%d:%d" % (draft_src, t["start"], t["end"]),
        })

    draft = {
        "schema_version": "1.0",
        "case_id": case_id,
        "task_instruction": instruction,
        "output_contract": [c["name"] for c in contract],
        "draft_source_id": draft_src,
        "draft_text": draft_text,
        "sources": sources,
        "segments": segments,
        "facts": facts,
        "terms": terms,
        "edits": [],
        "fidelity": [],
        "errors": errors,
        "degradations": degradations,
        "gaps": [],
    }
    return draft, contract


def compute_status(draft, check_report, errors, degradations, gaps):
    if any("case.json" in e for e in errors):
        return "input_error"
    if not draft.get("draft_text", "").strip():
        return "insufficient_evidence"
    if not draft.get("edits"):
        return "partial"
    if check_report.get("quote_hit_rate", 1.0) < 0.95:
        return "partial"
    if check_report.get("number_changes", 0) or check_report.get("fidelity_violations", 0):
        return "partial"
    if degradations:
        return "partial"
    if gaps and any("no sentence-level edits" not in g for g in gaps):
        return "partial"
    return "complete"


def build_result(draft, contract, check_report, errors, degradations, gaps, out):
    case_id = draft.get("case_id", "unknown")
    polished = apply_edits(draft)
    edits = draft.get("edits", [])
    terms = draft.get("terms", [])
    fidelity = draft.get("fidelity", [])
    sources = draft.get("sources", [])

    edit_records = []
    for e in edits:
        seg = {s["id"]: s for s in draft.get("segments", [])}.get(e.get("segment_id"))
        edit_records.append({
            "id": e.get("id"),
            "segment_id": e.get("segment_id"),
            "source_id": seg.get("source_id") if seg else None,
            "locator": seg.get("locator") if seg else None,
            "original": e.get("original"),
            "revised": e.get("revised"),
            "edit_type": e.get("edit_type"),
            "reason": e.get("reason"),
        })
    if not edit_records:
        gaps.append("no sentence-level edits provided (baseline: original text returned unchanged)")

    sources_evidence = []
    for s in sources:
        excerpt = (s["text"] or "")[:160]
        sources_evidence.append({
            "id": s["id"], "name": s["name"], "path": s["path"],
            "kind": s["kind"], "locator": "whole file",
            "quote": excerpt, "degrade": s.get("degrade"),
        })

    uncertainty = [
        {"item": "draft selection heuristic", "level": "low",
         "reason": "largest text material or case.json inline text; task_instruction is authority"},
        {"item": "sentence segmentation", "level": "low",
         "reason": "segments are verbatim substrings; boundaries approximate"},
        {"item": "term definitions", "level": "medium",
         "reason": "derived only from abbreviation patterns"},
        {"item": "semantic adequacy of edits", "level": "medium",
         "reason": "only quote hit and number/unit conservation checked"},
    ]

    change_records = edit_records

    summary = ("Polished %d segments; %d edits; %d terms; %d facts; "
               "quote hit rate %.2f; fidelity violations %d." % (
                   len(draft.get("segments", [])), len(edits), len(terms),
                   len(draft.get("facts", [])),
                   check_report.get("quote_hit_rate", 1.0),
                   check_report.get("fidelity_violations", 0)))

    def derive(name, spec):
        n = name.lower().replace("_", "").replace("-", "").replace(" ", "")
        if any(k in n for k in ("polish", "revised", "final", "correct",
                                "manuscript", "fulltext")) or n in ("text", "body", "draft"):
            return polished if polished else None
        if any(k in n for k in ("edit", "diff", "modif", "revision",
                                "changerecord", "record")):
            return change_records
        if any(k in n for k in ("term", "glossar", "abbrev", "acronym", "lexicon")):
            return [{"term": t["canonical"], "definition": t.get("definition"),
                     "variants": t.get("variants", []),
                     "first_occurrence": t.get("first_occurrence"),
                     "source_id": t.get("source_id"), "locator": t.get("locator")}
                    for t in terms]
        if any(k in n for k in ("fidelit", "fact", "proven", "trace")):
            return fidelity
        if "source" in n or "cit" in n or "refer" in n:
            return sources_evidence
        if any(k in n for k in ("summar", "note", "overview")):
            return summary
        if "uncertain" in n:
            return uncertainty
        spec_txt = "" if spec is None else json.dumps(spec, ensure_ascii=False)
        if n.endswith("s") or "list" in spec_txt.lower() or "array" in spec_txt.lower():
            return []
        return None

    result = {"case_id": case_id}
    result["status"] = compute_status(draft, check_report, errors, degradations, gaps)
    for f in contract:
        if f["name"] in ("case_id", "status"):
            continue
        result[f["name"]] = derive(f["name"], f["spec"])
    result["sources"] = sources_evidence
    result["uncertainty"] = uncertainty
    result["change_records"] = change_records
    result["errors"] = errors
    result["degradations"] = degradations
    result["gaps"] = gaps
    return result, polished, edit_records, terms, fidelity, sources_evidence, summary


def is_latex(draft):
    t = draft.get("draft_text", "")
    src = draft.get("draft_source_id", "")
    return src == "case.json" and ("\\documentclass" in t or "\\begin{" in t) \
        or any(s["name"].lower().endswith(".tex") for s in draft.get("sources", [])) \
        or "\\documentclass" in t


def md_escape(s):
    return (s or "").replace("|", "\\|").replace("\n", " ")


def write_artifacts(out, draft, polished, edit_records, terms, fidelity,
                    sources_evidence, degradations):
    out.mkdir(parents=True, exist_ok=True)
    tex = is_latex(draft)
    ext = ".tex" if tex else ".md"
    (out / ("polished" + ext)).write_text(polished, encoding="utf-8")

    lines = ["# 逐句修改对照（原文—改文）", "",
             "| 序号 | 原文 | 改文 | 类型 | 理由 | 定位 |",
             "|-|-|-|-|-|-|"]
    for i, e in enumerate(edit_records, 1):
        lines.append("| %d | %s | %s | %s | %s | %s |" % (
            i, md_escape(e["original"]), md_escape(e["revised"]),
            md_escape(e["edit_type"]), md_escape(e["reason"]),
            md_escape(e["locator"])))
    if not edit_records:
        lines.append("| - | （无修改，返回原文） | - | keep | 最小编辑原则 | - |")
    (out / "edits.md").write_text("\n".join(lines), encoding="utf-8")

    lines = ["# 术语表", "",
             "| 术语(缩写) | 全称/定义 | 变体 | 首次出现 | 定位 |",
             "|-|-|-|-|-|"]
    for t in terms:
        lines.append("| %s | %s | %s | %s | %s |" % (
            md_escape(t["canonical"]), md_escape(t.get("definition")),
            md_escape("; ".join(t.get("variants", []))),
            md_escape(t.get("first_occurrence")), md_escape(t.get("locator"))))
    (out / "terms.md").write_text("\n".join(lines), encoding="utf-8")

    lines = ["# 事实/引用/术语保真表", "",
             "| 类型 | 原文引文 | 保持 | 说明 | 定位 |",
             "|-|-|-|-|-|"]
    for f in fidelity:
        lines.append("| %s | %s | %s | %s | %s |" % (
            md_escape(f["kind"]), md_escape(f["quote"]),
            "是" if f["preserved"] else "**否**",
            md_escape(f["note"]), md_escape(f["locator"])))
    (out / "fidelity.md").write_text("\n".join(lines), encoding="utf-8")

    lines = ["# 证据定位清单", ""]
    for s in sources_evidence:
        lines.append("- **%s** (%s) — `%s` — 引文: `%s`" % (
            s["name"], s["kind"], s["path"], s["quote"]))
    (out / "sources.md").write_text("\n".join(lines), encoding="utf-8")

    (out / "preview.txt").write_text(polished, encoding="utf-8")
    (out / "preview.html").write_text(
        "<!doctype html><html><head><meta charset=\"utf-8\">"
        "<title>polished preview</title></head><body><pre>%s</pre></body></html>"
        % html.escape(polished), encoding="utf-8")

    if tex:
        compile_tex(out, degradations)


def compile_tex(out, degradations):
    for cmd in ("pdflatex", "xelatex", "latexmk", "tectonic"):
        if shutil.which(cmd) is None:
            continue
        try:
            p = subprocess.run(
                [cmd, "-interaction=nonstopmode", "-halt-on-error",
                 "polished.tex"], cwd=str(out),
                capture_output=True, timeout=120)
            if p.returncode == 0 and (out / "polished.pdf").is_file():
                return
        except Exception:
            continue
    degradations.append("LaTeX compiler unavailable or failed; .tex only, no PDF generated")


def cmd_init(inp, work, out):
    errors, degradations = [], []
    case, err, _ = load_case(inp)
    if err:
        errors.append(err)
    task_text = load_task(inp)
    sources = scan_input(inp)
    draft, contract = build_draft(inp, case, task_text, sources, errors, degradations)
    work.mkdir(parents=True, exist_ok=True)
    (work / "draft.json").write_text(
        json.dumps(draft, ensure_ascii=False, indent=2), encoding="utf-8")
    out.mkdir(parents=True, exist_ok=True)
    partial = {"case_id": draft.get("case_id", "unknown"),
               "status": compute_partial(errors, draft)}
    for f in contract:
        partial.setdefault(f["name"], None)
    partial["sources"] = []
    partial["uncertainty"] = []
    partial["change_records"] = []
    partial["errors"] = errors
    partial["degradations"] = degradations
    partial["gaps"] = []
    (out / "result.json").write_text(
        json.dumps(partial, ensure_ascii=False, indent=2), encoding="utf-8")
    return draft, contract, errors, degradations


def compute_partial(errors, draft):
    if errors:
        return "input_error"
    if not draft.get("draft_text", "").strip():
        return "insufficient_evidence"
    return "partial"


def cmd_show(work, kind):
    p = work / "draft.json"
    if not p.is_file():
        print("no draft.json; run init first")
        return
    draft = json.loads(p.read_text(encoding="utf-8"))
    print("case_id:", draft.get("case_id"))
    print("instruction:", (draft.get("task_instruction") or "")[:500])
    print("sources:", [(s["name"], s["kind"], len(s["text"])) for s in draft.get("sources", [])])
    if kind in ("text", "segments", None):
        for seg in draft.get("segments", []):
            print("[%s] %s" % (seg["locator"], seg["text"]))
    if kind in ("facts", None):
        for f in draft.get("facts", []):
            print("FACT[%s] %s :: %s" % (f["kind"], f["quote"], f["locator"]))
    if kind in ("terms", None):
        for t in draft.get("terms", []):
            print("TERM %s = %s" % (t["canonical"], t.get("definition")))


def cmd_check(work):
    p = work / "draft.json"
    if not p.is_file():
        print("no draft.json; run init first")
        return {"quote_hit_rate": 1.0, "issues": ["no draft.json"]}
    draft = json.loads(p.read_text(encoding="utf-8"))
    report = run_check(draft)
    (work / "draft.json").write_text(
        json.dumps(draft, ensure_ascii=False, indent=2), encoding="utf-8")
    (work / "check.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print("quote_hit_rate=%.3f issues=%d number_changes=%d fidelity_violations=%d"
          % (report["quote_hit_rate"], len(report["issues"]),
             report["number_changes"], report["fidelity_violations"]))
    for i in report["issues"]:
        print("  -", i)
    return report


def cmd_build(work, out):
    errors, degradations, gaps = [], [], []
    p = work / "draft.json"
    if not p.is_file():
        errors.append("no draft.json in work dir")
        draft = {"case_id": "unknown", "task_instruction": "", "sources": [],
                 "segments": [], "facts": [], "terms": [], "edits": [],
                 "fidelity": [], "draft_text": "", "draft_source_id": ""}
        contract = []
        report = {"quote_hit_rate": 1.0, "issues": [], "number_changes": 0,
                  "fidelity_violations": 0}
    else:
        draft = json.loads(p.read_text(encoding="utf-8"))
        names = draft.get("output_contract", [])
        contract = [{"name": n, "spec": None} for n in names]
        errors = list(draft.get("errors", []))
        degradations = list(draft.get("degradations", []))
        gaps = list(draft.get("gaps", []))
        report = run_check(draft)

    result, polished, edit_records, terms, fidelity, sources_evidence, summary = \
        build_result(draft, contract, report, errors, degradations, gaps, out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    write_artifacts(out, draft, polished, edit_records, terms, fidelity,
                    sources_evidence, degradations)
    result["degradations"] = degradations
    (out / "result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print("built result.json status=%s" % result["status"])
    return result


def main(argv=None):
    ap = argparse.ArgumentParser(prog="main.py",
                                 description="academic-language-polish")
    ap.add_argument("command", nargs="?", default="run",
                    choices=["run", "init", "show", "check", "build"])
    ap.add_argument("--input", dest="input")
    ap.add_argument("--work", dest="work")
    ap.add_argument("--output", dest="output")
    ap.add_argument("--kind", default=None,
                    choices=["text", "facts", "terms", "segments"])
    args = ap.parse_args(argv)

    inp, work, out = resolve_paths(args)
    try:
        if args.command == "init":
            cmd_init(inp, work, out)
        elif args.command == "show":
            cmd_show(work, args.kind)
        elif args.command == "check":
            cmd_check(work)
        elif args.command == "build":
            cmd_build(work, out)
        else:  # run: full flow
            cmd_init(inp, work, out)
            cmd_check(work)
            cmd_build(work, out)
    except Exception as e:
        log("error: %s" % e)
        try:
            out.mkdir(parents=True, exist_ok=True)
            r = {"case_id": "unknown", "status": "input_error",
                 "sources": [], "uncertainty": [],
                 "change_records": [], "errors": [str(e)],
                 "degradations": ["unhandled exception"], "gaps": []}
            (out / "result.json").write_text(
                json.dumps(r, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())

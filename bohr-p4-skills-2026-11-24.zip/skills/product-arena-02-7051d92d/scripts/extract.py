"""Deterministic material extraction for academic-language-polish.

Pure Python standard library. No network. No CWD dependence.
Reads real files (txt/md/tex/csv/tsv/json/pdf/docx/pptx/xlsx/sqlite),
splits text into sentence segments, and extracts facts (numbers, units,
citations, figure/table pointers, hedges) and terms (abbreviations).
"""
import csv
import html
import io
import json
import re
import shutil
import sqlite3
import subprocess
import zipfile
from pathlib import Path

WS = re.compile(r"\s+")


def norm(s):
    return WS.sub(" ", (s or "").strip())


# ---------- file reading ----------

def _read_text(path, encodings=("utf-8", "utf-8-sig", "gb18030", "latin-1")):
    data = Path(path).read_bytes()
    for enc in encodings:
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _xml_text(xml_bytes, tags=("w:t", "a:t", "t")):
    xml = xml_bytes.decode("utf-8", errors="replace")
    out = []
    for t in tags:
        for m in re.finditer(r"<%s(?:\s[^>]*)?>(.*?)</%s>" % (t, t), xml, re.S):
            out.append(m.group(1))
    text = "".join(out)
    text = re.sub(r"<[^>]+>", "", text)
    import html
    return html.unescape(text)


def extract_docx(path):
    try:
        with zipfile.ZipFile(path) as z:
            parts = [n for n in z.namelist() if n == "word/document.xml"]
            if not parts:
                return ""
            xml = z.read(parts[0])
            return _xml_text(xml, ("w:t",))
    except Exception:
        return ""


def extract_pptx(path):
    try:
        with zipfile.ZipFile(path) as z:
            slides = sorted(
                n for n in z.namelist()
                if re.match(r"ppt/slides/slide\d+\.xml$", n)
            )
            return "\n".join(_xml_text(z.read(n), ("a:t",)) for n in slides)
    except Exception:
        return ""


def extract_xlsx(path):
    try:
        with zipfile.ZipFile(path) as z:
            shared = ""
            if "xl/sharedStrings.xml" in z.namelist():
                shared = _xml_text(z.read("xl/sharedStrings.xml"), ("t",))
            sheets = [n for n in z.namelist() if re.match(r"xl/worksheets/sheet\d+\.xml$", n)]
            rows = []
            for n in sheets:
                xml = z.read(n).decode("utf-8", errors="replace")
                rows.append(" ".join(re.findall(r"<v>(.*?)</v>", xml)))
            return (shared + "\n" + "\n".join(rows)).strip()
    except Exception:
        return ""


def extract_pdf(path, timeout=60):
    """pdftotext; on failure return empty string with a reason."""
    for args in (["-enc", "UTF-8", "-layout"], ["-enc", "UTF-8"]):
        try:
            p = subprocess.run(
                ["pdftotext"] + args + [str(path), "-"],
                capture_output=True, timeout=timeout,
            )
            if p.returncode == 0 and p.stdout.strip():
                return p.stdout.decode("utf-8", errors="replace")
        except Exception:
            continue
    return ""


def extract_sqlite(path):
    try:
        con = sqlite3.connect(str(path))
        cur = con.cursor()
        tables = [r[0] for r in cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")]
        out = []
        for t in tables:
            out.append("TABLE " + t)
            try:
                for row in cur.execute("SELECT * FROM %s" % t):
                    out.append("\t".join("" if v is None else str(v) for v in row))
            except Exception:
                out.append("(unreadable)")
        con.close()
        return "\n".join(out)
    except Exception:
        return ""


def _json_to_text(data):
    if isinstance(data, str):
        return data
    if isinstance(data, dict):
        return "\n".join("%s: %s" % (k, _json_to_text(v)) for k, v in data.items())
    if isinstance(data, list):
        return "\n".join(_json_to_text(v) for v in data)
    return "" if data is None else str(data)


EXT_HANDLERS = {
    ".txt": _read_text, ".md": _read_text, ".tex": _read_text,
    ".rst": _read_text, ".csv": _read_text, ".tsv": _read_text,
    ".bib": _read_text, ".html": _read_text, ".xml": _read_text,
    ".docx": extract_docx, ".pptx": extract_pptx, ".xlsx": extract_xlsx,
    ".pdf": extract_pdf, ".sqlite": extract_sqlite, ".db": extract_sqlite,
    ".sqlite3": extract_sqlite,
}


def kind_of(name):
    e = Path(name).suffix.lower()
    if e in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".tif", ".tiff", ".bmp"):
        return "image"
    if e in (".docx", ".pptx", ".xlsx"):
        return "office"
    if e == ".pdf":
        return "pdf"
    if e in (".sqlite", ".db", ".sqlite3"):
        return "sqlite"
    if e == ".json":
        return "json"
    if e in (".txt", ".md", ".tex", ".rst", ".csv", ".tsv", ".bib", ".html", ".xml"):
        return "text"
    return "unknown"


def scan_input(input_dir, exclude=("case.json", "task.md")):
    """Return a list of source dicts with extracted text."""
    sources = []
    base = Path(input_dir)
    if not base.is_dir():
        return sources
    for p in sorted(base.rglob("*")):
        if not p.is_file() or p.name in exclude:
            continue
        kind = kind_of(p.name)
        text = ""
        degrade = None
        if kind == "image":
            degrade = "image needs OCR; not readable offline"
        elif kind == "unknown":
            degrade = "unrecognized file type; read as text"
            try:
                text = _read_text(p)
            except Exception:
                text = ""
        elif kind == "json":
            try:
                text = _json_to_text(json.loads(_read_text(p)))
            except Exception:
                text = _read_text(p)
        else:
            try:
                text = EXT_HANDLERS[p.suffix.lower()](p)
            except Exception:
                text = ""
        sources.append({
            "id": "src%03d" % (len(sources) + 1),
            "path": str(p),
            "name": p.name,
            "kind": kind,
            "text": text or "",
            "degrade": degrade,
        })
    return sources


# ---------- sentence segmentation ----------

_MATH = re.compile(r"\$[^$\n]*\$|\\\([^)]*\\\)|\\\[[^]]*\\\]")
_BRACKET_CITE = re.compile(r"\\cite\{[^}]*\}|\\ref\{[^}]*\}|\\label\{[^}]*\}|\[\d+(?:[,\-–—]\s*\d+)*\]")
_ABBR = ("e.g.", "i.e.", "et al.", "vs.", "cf.", "Fig.", "fig.", "Eq.", "eq.",
         "No.", "no.", "vol.", "pp.", "Dr.", "Prof.", "Mr.", "Ms.", "etc.",
         "approx.", "Ref.", "ref.", "Tab.", "Sect.", "Sec.", "Suppl.")


def _shield(text):
    out = list(text)
    for pat in (_MATH, _BRACKET_CITE):
        for m in pat.finditer(text):
            for i in range(m.start(), m.end()):
                out[i] = "x"
    for ab in _ABBR:
        start = 0
        while True:
            i = text.find(ab, start)
            if i < 0:
                break
            for j in range(i, i + len(ab)):
                if text[j] == ".":
                    out[j] = "x"
            start = i + len(ab)
    return "".join(out)


_SENT_SPLIT = re.compile(r"[.!?。！？；;]+(?=\s+|$)")


def split_sentences(text):
    """Yield (start, end, text); text is the trimmed verbatim sentence,
    and [start, end) slices exactly to that text so spans can be replaced
    without losing inter-sentence whitespace."""
    if not text:
        return []
    shielded = _shield(text)
    spans = []
    pos = 0
    for m in _SENT_SPLIT.finditer(shielded):
        end = m.end()
        raw = text[pos:end]
        s = len(raw) - len(raw.lstrip())
        e = len(raw.rstrip())
        if e > s:
            spans.append((pos + s, pos + e, raw[s:e]))
        pos = end
    raw = text[pos:]
    s = len(raw) - len(raw.lstrip())
    e = len(raw.rstrip())
    if e > s:
        spans.append((pos + s, pos + e, raw[s:e]))
    return spans


# ---------- fact / term extraction ----------

_NUM_UNIT = re.compile(
    r"(?<![A-Za-z0-9_.])[-+]?\d[\d,.]*\s*"
    r"(?:%|percent|per\s*cent|‰|ppm|ppb|ppt|mg|kg|μg|µg|ug|g|ml|mL|L|l|"
    r"mmol|μmol|µmol|umol|mol|mM|μM|µM|uM|nM|nm|μm|µm|um|mm|cm|km|"
    r"s|ms|min|h|hr|hrs|day|days|°C|℃|K|Hz|kHz|MHz|GHz|V|kV|W|kW|kDa|Da|bp|kb|Mb)"
    r"(?![A-Za-z])")
_NUM = re.compile(r"(?<![A-Za-z0-9_])[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?(?![A-Za-z0-9_.])")
_STAT = re.compile(r"[pP]\s*[<>=≤≥]\s*\d*\.?\d+(?:[eE][-+]?\d+)?")
_CITE_BRACKET = re.compile(r"\[\d+(?:[,\-–—]\s*\d+)*\]")
_AUTHOR_YEAR = re.compile(r"\(([A-Z][A-Za-z&.\- ]+,\s*(?:19|20)\d{2}[a-z]?)\)")
_FIG_TAB = re.compile(r"\b(?:Fig\.?|Figure|Table|Tab\.?|Eq\.?|Equation)\s*\d+|[图表]\s*\d+")
_LATEX_REF = re.compile(r"\\ref\{[^}]*\}|\\cite\{[^}]*\}")
_HEDGES = re.compile(
    r"\b(?:may|might|could|should|suggest|indicate|likely|unlikely|possibly|"
    r"potentially|probably|partially|partly|preliminary|tentative)\b|"
    r"初步|可能|或许|似乎|大概|有望|尚需|有待|部分|大致")

_FACT_PATTERNS = [
    ("number_unit", _NUM_UNIT),
    ("statistic", _STAT),
    ("citation", _CITE_BRACKET),
    ("citation", _AUTHOR_YEAR),
    ("figure_table", _FIG_TAB),
    ("latex_ref", _LATEX_REF),
    ("hedge", _HEDGES),
    ("number", _NUM),
]


def extract_facts(text):
    facts = []
    seen = []
    for kind, pat in _FACT_PATTERNS:
        for m in pat.finditer(text):
            if any(s < m.end() and m.start() < e for (s, e) in seen):
                continue
            seen.append((m.start(), m.end()))
            facts.append({"kind": kind, "quote": m.group(0),
                          "start": m.start(), "end": m.end()})
    facts.sort(key=lambda f: f["start"])
    return facts


_ABBR_PATTERNS = [
    re.compile(r"\b([A-Z][A-Za-z0-9\-]+(?:[ \t]+[A-Za-z0-9\-]+){1,10}?)[ \t]*\(\s*([A-Z][A-Z0-9\-]{1,19})\s*\)"),
    re.compile(r"\b([A-Z][A-Z0-9\-]{1,19})[ \t]*\(\s*([A-Za-z0-9][A-Za-z0-9\- ]{1,120}?)\s*\)"),
    re.compile(r"([A-Z][A-Z0-9\-]{1,19})\s*（\s*([^（）]{2,120}?)\s*）"),
]


def extract_terms(text):
    terms = []
    seen = set()
    for pat in _ABBR_PATTERNS:
        for m in pat.finditer(text):
            g = m.groups()
            if pat is _ABBR_PATTERNS[0]:
                full, abbr = g[0].strip(), g[1].strip()
            else:
                abbr, full = g[0].strip(), g[1].strip()
            if abbr in seen:
                continue
            seen.add(abbr)
            terms.append({
                "canonical": abbr,
                "definition": full,
                "variants": [full],
                "start": m.start(),
                "end": m.end(),
            })
    terms.sort(key=lambda t: t["start"])
    return terms


# ---------- report assembly (used by main.py build/check) ----------

def corpus_text(sources):
    return "\n\n".join(s["text"] for s in sources if s["text"])


def segment_for_fact(segments, fact):
    for seg in segments:
        if seg["start"] <= fact["start"] < seg["end"]:
            return seg
    return None


def apply_edits(draft):
    text = draft.get("draft_text", "")
    segments = {s["id"]: s for s in draft.get("segments", [])}
    repl = []
    for e in draft.get("edits", []):
        seg = segments.get(e.get("segment_id"))
        rev = e.get("revised")
        if seg is not None and rev is not None and rev != seg["text"]:
            repl.append((seg["start"], seg["end"], rev))
    repl.sort(key=lambda t: t[0], reverse=True)
    for start, end, rev in repl:
        text = text[:start] + rev + text[end:]
    return text


def revised_segment_text(edits, seg):
    for e in edits:
        if e.get("segment_id") == seg["id"] and "revised" in e:
            return e["revised"]
    return seg["text"]


def run_check(draft):
    corpus = corpus_text(draft.get("sources", []))
    if not corpus.strip() and draft.get("draft_text", "").strip():
        corpus = draft["draft_text"]
    edits = draft.get("edits", [])
    segments = {s["id"]: s for s in draft.get("segments", [])}
    report = {"quote_hits": 0, "quote_total": 0, "issues": [],
              "number_changes": 0, "contract_ok": True}

    for e in edits:
        orig = e.get("original", "")
        if orig.strip():
            report["quote_total"] += 1
            if norm(orig) in norm(corpus):
                report["quote_hits"] += 1
            else:
                report["issues"].append(
                    "edit %s original not found verbatim" % e.get("id", "?"))
        seg = segments.get(e.get("segment_id"))
        base = seg["text"] if seg else e.get("original", "")
        rev = e.get("revised", "")
        for f in extract_facts(base):
            if f["kind"] in ("number_unit", "number", "statistic") \
                    and norm(f["quote"]) not in norm(rev):
                report["number_changes"] += 1
                report["issues"].append(
                    "edit %s changed number/unit %s" % (e.get("id", "?"), f["quote"]))

    fidelity = []
    for f in draft.get("facts", []):
        seg = segment_for_fact(draft.get("segments", []), f)
        rev = revised_segment_text(edits, seg) if seg else f["quote"]
        preserved = norm(f["quote"]) in norm(rev)
        fidelity.append({
            "id": f["id"], "kind": f["kind"], "quote": f["quote"],
            "source_id": f.get("source_id"), "locator": f.get("locator"),
            "preserved": preserved,
            "note": "" if preserved else "not preserved after edits",
        })
    draft["fidelity"] = fidelity

    total = report["quote_total"]
    report["quote_hit_rate"] = (report["quote_hits"] / total) if total else 1.0
    report["fidelity_violations"] = sum(1 for f in fidelity if not f["preserved"])
    return report


if __name__ == "__main__":
    import sys
    d = sys.argv[1] if len(sys.argv) > 1 else "."
    for s in scan_input(d):
        print(s["id"], s["name"], s["kind"], len(s["text"]), s.get("degrade") or "")

---
name: academic-language-polish
description: >-
  Minimal-edit academic language polishing for research writing. Trigger ONLY when the task
  is to polish, proofread, edit, revise, or translate an academic manuscript (paper, thesis,
  grant proposal, review response, abstract) with fidelity to the source. Produces an editable
  polished full text plus sentence-level original/revised edit records, a term table, and a
  fact/citation/term fidelity report, each traceable to source + locator + verbatim quote.
  Do NOT trigger for pure content Q&A, brainstorming, or generating new text from scratch.
version: 1.0.0
---

# Academic Language Polish（学术语言润色）

## 用途

对科研稿件做**最小编辑式**学术语言润色：改掉语法/句法/搭配/标点硬错误，贴合目标文体与语域，
统一术语与缩写，同时**不改动**原意、限定强度、数据、单位、引用编号与图表指向。交付物是
「润色后的可编辑全文 ＋ 逐句原文—改文对照 ＋ 修改类型与理由 ＋ 术语表 ＋ 事实/引用/术语保真表」，
不是写作建议，也不是整段重写。每一处修改与每个结论都必须能回溯到 `来源(source) + 定位(locator) + 逐字引文(quote)`。

## 触发条件

**应当触发**：任务要求对已有学术文本进行润色、校对、改写、修改、中英互译、术语统一、格式/引用整理、审稿回复润色。
**不应触发**：纯内容问答、文献综述生成、从零写新内容、只有观点讨论而无待改文本时，不得擅自改写。

## 核心原则（对应评分四问）

1. **改得对**：只消除硬错误，不换一种说法掩盖错误。可改：主谓一致、时态语态、冠词介词、单复数、悬垂修饰、标点、长句切分、中式英语、直译腔、冗余名词化。不可用「换个表达」掩盖未解决的错误。
2. **说得像**：贴合目标文体（期刊论文/学位论文/基金申请书/审稿回复/英文摘要），消除口语化、宣传化、绝对化表述与人称误用；术语全篇统一。
3. **没改坏**：限定强度（may/might/could/可能/似乎/初步/有望等）、因果 vs 相关、否定范围、条件句、量词、数字、单位、引用编号 `[1]`、图表指向 `图1/表2/Fig. 1` 一律保持原样；不得加强或削弱结论。
4. **讲得清**：每处修改给出 `original / revised / edit_type / reason`，第三方据此可判断「该处该不该改」。

**最小编辑原则**：能不改就不改；每句只做必要的确定性修改；原文未错的句子保持原样（`edit_type=keep` 且不入修改清单）。

## 输入

运行时目录 `/input`（本地测试可用 `INPUT_DIR` 或 `--input` 覆盖）：
- `case.json`：含 `case_id`、`task_instruction`、`output_contract`（结果契约字段）及可能的材料声明。
- `task.md`：题目说明。
- 材料文件：`.md/.txt/.tex/.rst/.csv/.tsv/.json/.pdf/.docx/.pptx/.xlsx/.sqlite/.db` 及图片。**不得按文件名/标签假设内容，必须真实读取**；PDF 可能没有预抽文本层。

## 调用方式

统一入口 `scripts/main.py`（纯 Python 标准库，不联网，不依赖 CWD）。默认命令 = 完整流程。

```bash
python main.py                          # 默认完整流程：init -> check -> build
python main.py init                     # 从 /input 真实抽取材料，生成工作稿 draft.json 与 partial result.json
python main.py show [--kind text|facts|terms|segments]   # 查看抽取结果（供改稿前阅读）
python main.py check                    # 校验引文命中、数字守恒、契约完整性，写 check.json
python main.py build                    # 由 draft.json 组装最终 result.json 与可编辑产物/预览
```

路径解析：优先 `--input/--work/--output` 参数，其次环境变量 `INPUT_DIR/WORK_DIR/OUTPUT_DIR`，
默认 `/input`、`/app/work`、`/app/output`。脚本路径基准为 `Path(__file__).resolve().parent`，与 CWD 无关。

**Agent 工作流（每案例）**：
1. `init`：真实抽取材料 → 生成 `draft.json`（分段、事实、术语，编辑列表为空）→ 先落 partial `result.json`。
2. `show`：通读抽取出的原文/分段/事实/术语，确定待改稿件与目标文体（由 `case.json.task_instruction` 判断）。
3. **填编辑**：把逐句修改写入 `draft.json` 的 `edits[]`（按下方 schema），并补全 `terms[]`、`fidelity[]`。
4. `check`：校验每条 `original`/`quote` 能在材料原文逐字命中、数字单位守恒；不满足则回到第 3 步修正。
5. `build`：组装最终 `result.json` + 可编辑产物（`polished.md`/`.tex`、`edits.md`、`terms.md`、`fidelity.md`、`sources.md`）与预览（`.txt`/`.html`，LaTeX 可用时编译 `.pdf`）。
6. 全部异常捕获并写入 `errors[]/degradations[]`；**退出码恒 0**。接近 780s 立即 `build` 已完成的交付。

## 输出

`/app/output`（本地 `OUTPUT_DIR` 覆盖）：
- `result.json`：回填 `case.json.output_contract` 的每个字段 + `case_id`，并带 `status / sources / uncertainty / change_records / errors / degradations / gaps`。
- 可编辑产物：`polished.md`（或 LaTeX 时 `polished.tex`）、`edits.md`、`terms.md`、`fidelity.md`、`sources.md`。
- 预览：`preview.txt`、`preview.html`；LaTeX 且编译器可用时 `polished.pdf`，否则诚实标 degradation，不伪造 PDF。

## 工作稿 schema（`/app/work/draft.json`）

```json
{
  "schema_version": "1.0",
  "case_id": "string",
  "task_instruction": "string",
  "output_contract": ["field names or specs, 原样保留"],
  "sources": [{"id","path","kind","role","text"}],
  "segments": [{"id","source_id","locator","text"}],
  "facts": [{"id","kind","quote","source_id","locator","note"}],
  "terms": [{"id","canonical","variants":[],"definition","first_occurrence","source_id","locator"}],
  "edits": [{"id","segment_id","original","revised","edit_type","reason","facts_touched":[]}],
  "fidelity": [{"id","kind","quote","source_id","locator","preserved":true,"note":""}],
  "errors": [], "degradations": [], "gaps": []
}
```

- `segments[]`：以句为最小编辑单元；每句有 `locator`（`source_id` 内 `start:end` 或 `#L行号`）。
- `edits[].original` 必须能从材料原文逐字命中；`revised` 仅改必要之处；`edit_type` 取下方类型；`reason` 一句说明依据。
- `facts[]`：数字、单位、引用编号、图表指向、限定词等「不可顺手改」的事实；`fidelity[]` 逐条标注 `preserved`（改写后是否保持）。
- `terms[]`：术语表；`variants` 收录同义混用写法；`definition` 若材料有定义则引原文，无则置 `null`。

## 修改类型（`edit_type` 全集，见 references/edit_types.md）

`grammar`(语法) `syntax`(句法/长句切分) `collocation`(搭配) `punctuation`(标点) `word_choice`(用词/中式英语) `register`(语域/语气) `terminology`(术语统一) `abbreviation`(缩写首现) `citation`(引用格式，仅改格式不改编号指向) `consistency`(全篇一致性) `keep`(未改)。禁止把语义改动伪装成 `word_choice`。

## 保真规则（references/style_guide.md）

- 数字、单位、精度、显著性标记一律照抄，不四舍五入、不换算单位。
- 限定词强度守恒：`may→may`、不得 `may→can/does`、不得删 `partially/初步/似乎/可能`、不得加 `definitely/证实`。
- 因果 vs 相关不互换；否定范围、条件句、量词保持不变。
- 引用编号与图表指向只改呈现格式，不改变编号所指对象；若原文编号与图表指向冲突，**不擅自改**，记入 `gaps[]` 待人工确认。
- 不新增材料之外的事实、数据、引用或软件状态。

## 术语规则（references/term_policy.md）

- 建立术语表；同一概念全篇统一大小写/连字符/中英文写法；缩写首次出现写全称+缩写，之后只用缩写。
- 跨章节漂移时以**首次出现**为准统一，并把改动记入 `edits`；若材料内部术语冲突无法裁定，保留原文并记 `gaps[]`。

## 证据规范（可核验性）

- 每个结论/元素/条目/页面都要有 `source`(文件名) + `locator`(段落/行/字符区间) + `quote`(逐字引文)。
- `quote` 必须能在材料原文命中（允许忽略空白差异）；全包引文命中率目标 ≥ 0.95。
- 引用论文/文献仅当材料或本次检索结果含有该条元数据时才写 DOI/卷期/页码；缺失即留空，不臆造。

## 降级表（异常处理，全部退出码 0）

| 情况 | 处理 |
|-|-|
| `/input` 不存在或空 | `status=input_error`，`gaps[]` 说明，result.json 契约字段用 `null/[]`，非 0 字节 |
| `case.json` 缺失/坏 JSON | `status=input_error`，errors 记录，尽力用任务材料继续 |
| 无材料或材料不可读（PDF 无文本层/图片/OCR 不可用） | `status=insufficient_evidence`，`degradations[]` 记录，仍产出 legal partial |
| PDF 无文本层 | 用 `pdftotext`；失败则 `pdftoppm` 转图并标注「需 OCR」degradation，不编造文本 |
| LaTeX 编译器不可用 | 输出 `.tex` 并标 degradation，不伪造 PDF |
| 引文命中率 <0.95 或数字被改 | `check` 报错项，Agent 回改后重跑；最终仍不满足则降级 `status=partial` 并记 gaps |
| 术语冲突/文体不明/超长/编码混乱 | 保留原文、最小编辑，记入 `gaps[]` 待人工确认 |

## 自检

1. result.json 契约字段与 `case_id` 齐全、无占位 `"array"/"object"`、无空契约键（缺值用 `null/[]`）。
2. 每处 edit 有 original/revised/edit_type/reason；original 逐字命中材料。
3. 数字/单位/限定词/引用编号/图表指向保真（`fidelity[]` 全 `preserved:true` 或明确 `changed` + 理由）。
4. 术语表覆盖所有缩写与首现形式；可编辑产物非截图；LaTeX 已真编译或标 degradation。
5. `python main.py --help` 与默认流程、空输入、坏 JSON、缺材料均 exit 0 且 result.json 合法。

## 限制

- 本 Skill 不做完整语言模型之外的领域审校；不替代同行评审与人工终校。
- 不联网（脚本层）；不依赖 CWD；不含预置答案，全部从 `/input` 真实派生。
- 仅做语言层最小编辑；涉及语义、数据、结论本身的问题一律保留原文并记 `gaps[]`，交人工确认。

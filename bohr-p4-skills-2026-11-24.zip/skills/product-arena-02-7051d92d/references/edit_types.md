# 修改类型（edit_type）全集与示例

每处修改必须从下表选择一个类型；`reason` 用一句话给出依据（语法规则/搭配惯例/术语统一/语域要求）。语义改动禁止伪装为 `word_choice`。

| edit_type | 含义 | 示例（标注：示例，非正式案例结果） |
|-|-|-|
| grammar | 主谓一致、时态、冠词、介词、单复数 | 原文 `The data shows that` → 改文 `The data show that` |
| syntax | 悬垂修饰、语序、长句切分、残缺句 | 原文 `After analysis, the result was confirmed.` → 改文 `After the analysis, we confirmed the result.` |
| collocation | 词语搭配 | 原文 `make an experiment` → 改文 `conduct an experiment` |
| punctuation | 标点、空格、全半角 | 原文 `A,B,C` → 改文 `A, B, C` |
| word_choice | 用词不当、中式英语、直译腔、冗余名词化 | 原文 `with the development of society` → 改文 `as the field has advanced` |
| register | 口语化/宣传化/绝对化/人称误用 | 原文 `It is very important` → 改文 `It is important` |
| terminology | 术语统一、同义混用 | 原文 `neural net` → 改文 `neural network`（与全篇统一） |
| abbreviation | 缩写首现形式、大小写、连字符 | 原文 `CNN` 首次出现 → 改文 `convolutional neural network (CNN)` |
| citation | 引用/图表指向的格式（不改所指对象） | 原文 `图1` → 改文 `图 1` |
| consistency | 跨章节/全篇一致性回扫 | 方法节 `Fig.1` → `Fig. 1`（与引言统一） |
| keep | 该句未改 | 不进入修改清单 |

## 判定示例（标注：示例，非正式案例结果）

- 不保留限定强度是错误：`may suggest` 改为 `confirms` 属于**禁止的语义改动**，应记为 `keep` 或仅做语法修正。
- 术语漂移：引言用 `heart failure (HF)`，方法节用 `cardiac failure`，应统一为 `heart failure (HF)`，类型 `terminology`。
- 图表指向：原文 `(Fig. 2)` 改成 `(Fig. 2)` 若编号不变则不改；若仅补空格用 `citation`。

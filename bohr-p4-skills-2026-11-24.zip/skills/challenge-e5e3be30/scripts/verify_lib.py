# -*- coding: utf-8 -*-
"""Contract echoing, claim decomposition and entailment checks.

The Agent decides what the sources entail; this module enforces verbatim located
quotations, closed verdict enumerations and the documented aggregation rule.
"""
import csv
import json
import re
from pathlib import Path

from io_parse import (CONTRACT_ALIASES, HEDGE_RE, NUM_RE, find_quote, jload, norm_text)

VERDICTS = ("supported", "partially_supported", "contradicted", "insufficient_evidence")
SUBCLAIM_TYPES = ("fact", "comparison", "causal", "scope")
NEGATION_RE = re.compile(
    r"(?i)\b(?:not|no|never|neither|nor|none|without|fail(?:ed|s|ure)?|did\s+not|was\s+not|"
    r"were\s+not|is\s+not|are\s+not|contrary|opposite|significant(?:ly)?\s+(?:lower|higher)|"
    r"versus|vs\.?|compared\s+(?:with|to)|fewer|lower|higher|less|more|decreas\w*|increas\w*|"
    r"reduc\w*|attenuat\w*|abolish\w*|unchanged|no\s+significant)\b|未|不|无|没有|低于|高于|相反|显著"
)
AGGREGATION_RULE = (
    "all sub-claims supported -> supported; every fact/comparison sub-claim contradicted and no "
    "supported sub-claim -> contradicted; mixed supported/partial/contradicted -> partially_supported; "
    "no assessable evidence -> insufficient_evidence")



from io_parse import contract_keys, echo_contract  # re-exported for main.py


def read_case(input_dir):
    path = Path(input_dir) / "case.json"
    if not path.exists():
        return {}, "case.json missing"
    raw = path.read_text(encoding="utf-8", errors="replace").strip()
    if not raw:
        return {}, "case.json empty"
    try:
        doc = json.loads(raw)
    except Exception as exc:
        return {}, "case.json invalid JSON: %s" % exc
    if not isinstance(doc, dict):
        return {}, "case.json is not an object"
    return doc, ""


def case_id_of(case):
    for key in ("case_id", "caseId", "id", "slug", "name"):
        value = case.get(key) if isinstance(case, dict) else None
        if isinstance(value, str) and value.strip():
            return value.strip()
    return "unknown-case"


def load_draft(work):
    path = Path(work) / "draft.json"
    if not path.exists():
        return None, "draft.json missing"
    raw = path.read_text(encoding="utf-8", errors="replace").strip()
    if not raw:
        return None, "draft.json empty"
    try:
        doc = json.loads(raw)
    except Exception as exc:
        return None, "draft.json invalid JSON: %s" % exc
    if not isinstance(doc, dict):
        return None, "draft.json must be an object"
    return doc, ""


def find_claim_specs(input_dir, case):
    """Locate the audit claims. They are questions/judgements to verify, not facts."""
    for key in ("claims_to_verify", "claims-to-verify", "claimsToVerify",
                "claims_to_check", "claims"):
        if isinstance(case.get(key), (list, dict)):
            return normalize_claims(case.get(key)), "case.json:" + key
    root = Path(input_dir)
    try:
        files = sorted(root.rglob("*"))
    except Exception:
        files = []
    candidates = []
    for path in files:
        if not path.is_file() or "environment/" in path.as_posix().lower():
            continue
        low = path.name.lower()
        if not low.endswith(".json"):
            continue
        score = 0
        if "claim" in low and ("verify" in low or "to-verify" in low or "audit" in low):
            score += 4
        elif "claim" in low:
            score += 2
        if score:
            candidates.append((score, path.relative_to(root).as_posix(), path))
    candidates.sort(key=lambda item: (-item[0], item[1]))
    for _score, rel, path in candidates:
        doc = jload(path)
        raw = None
        if isinstance(doc, list):
            raw = doc
        elif isinstance(doc, dict):
            for key in ("claims", "claims_to_verify", "claims-to-verify", "items",
                        "verifications", "audit_claims"):
                if isinstance(doc.get(key), (list, dict)):
                    raw = doc.get(key)
                    break
        if raw:
            return normalize_claims(raw), rel
    return [], "not_found"


def normalize_claims(raw):
    items = []
    if isinstance(raw, dict):
        for key, value in raw.items():
            if isinstance(value, dict):
                item = dict(value)
                item.setdefault("claim_id", key)
                items.append(item)
            elif isinstance(value, str):
                items.append({"claim_id": key, "text": value})
    elif isinstance(raw, list):
        for idx, value in enumerate(raw):
            if isinstance(value, dict):
                items.append(dict(value))
            elif isinstance(value, str):
                items.append({"claim_id": "C%02d" % (idx + 1), "text": value})
    out = []
    for idx, item in enumerate(items):
        cid = None
        for key in ("claim_id", "claimId", "id", "key", "name", "sub_id"):
            value = item.get(key)
            if isinstance(value, str) and value.strip():
                cid = value.strip()
                break
        text = ""
        for key in ("claim", "text", "question", "statement", "assertion", "hypothesis"):
            value = item.get(key)
            if isinstance(value, str) and value.strip():
                text = value.strip()
                break
        out.append({
            "claim_id": cid or "C%02d" % (idx + 1),
            "claim_text": text,
            "conditions": str(item.get("conditions") or item.get("context") or "").strip(),
            "required_evidence": item.get("required_evidence") or item.get("evidence_type") or "",
            "spec_raw": item,
        })
    return out


def skeleton_verifications(specs):
    return [{
        "claim_id": spec["claim_id"],
        "claim_text": spec["claim_text"],
        "sub_claims": [],
        "verdict": "pending",
        "aggregation_rule": AGGREGATION_RULE,
        "rationale": None,
        "conditions": spec.get("conditions") or None,
        "conflicts": [],
        "missing_evidence": [],
        "notes": "awaiting agent verification",
    } for spec in specs]


def draft_verifications(draft):
    if not isinstance(draft, dict):
        return []
    for key in ("verifications", "claims", "results", "decisions", "audit"):
        value = draft.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]
    return []


def normalize_evidence(evidence):
    out = []
    if not isinstance(evidence, list):
        return out
    for item in evidence:
        if not isinstance(item, dict):
            continue
        out.append({
            "material": item.get("material"),
            "locator": item.get("locator") if isinstance(item.get("locator"), dict) else {
                key: item.get(key) for key in ("paragraph_id", "page", "section", "table_id", "row")
                if item.get(key) is not None} or None,
            "paragraph_id": item.get("paragraph_id"),
            "page": item.get("page"),
            "section": item.get("section"),
            "table_id": item.get("table_id"),
            "row": item.get("row"),
            "quote": item.get("quote"),
            "relation": item.get("relation"),
        })
    return out


def normalize_subclaim(sub):
    sub = sub if isinstance(sub, dict) else {}
    return {
        "sub_id": sub.get("sub_id") or sub.get("id"),
        "type": sub.get("type") or sub.get("claim_type"),
        "text": sub.get("text") or sub.get("sub_claim") or sub.get("judgement") or "",
        "verdict": sub.get("verdict") or sub.get("status"),
        "evidence": normalize_evidence(sub.get("evidence")),
        "rationale": sub.get("rationale") or sub.get("reason"),
        "conditions": sub.get("conditions") or sub.get("scope"),
        "required_evidence": sub.get("required_evidence"),
        "negation_or_comparator_preserved": sub.get("negation_or_comparator_preserved"),
    }


def normalize_verification(raw, spec):
    sub_raw = raw.get("sub_claims") or raw.get("subclaims") or raw.get("sub_judgements") or []
    return {
        "claim_id": raw.get("claim_id") or raw.get("id") or (spec or {}).get("claim_id"),
        "claim_text": raw.get("claim_text") or raw.get("claim") or raw.get("text") or
                      (spec or {}).get("claim_text"),
        "sub_claims": [normalize_subclaim(sub) for sub in sub_raw] if isinstance(sub_raw, list) else [],
        "verdict": raw.get("verdict") or raw.get("aggregate_verdict") or raw.get("status"),
        "aggregation_rule": raw.get("aggregation_rule") or AGGREGATION_RULE,
        "rationale": raw.get("rationale") or raw.get("reason"),
        "conditions": raw.get("conditions"),
        "conflicts": raw.get("conflicts") if isinstance(raw.get("conflicts"), list) else [],
        "missing_evidence": raw.get("missing_evidence") if isinstance(raw.get("missing_evidence"), list) else [],
        "notes": raw.get("notes"), "claim_type": raw.get("claim_type"),
    }


def aggregate_verdict(sub_verdicts, types):
    """Documented aggregation rule; returns (verdict, reason)."""
    verdicts = list(sub_verdicts)
    kinds = list(types)
    if not verdicts:
        return "insufficient_evidence", "no sub-claim could be assessed"
    if all(v == "supported" for v in verdicts):
        return "supported", "all sub-claims supported"
    if any(v == "contradicted" for v in verdicts):
        if all(v == "contradicted" for v in verdicts):
            return "contradicted", "all sub-claims contradicted"
        central = [v for t, v in zip(kinds, verdicts) if t in ("fact", "comparison")]
        if central and all(v == "contradicted" for v in central) and "supported" not in verdicts:
            return "contradicted", "every fact/comparison sub-claim contradicted"
        return "partially_supported", "mixed evidence: some sub-claims contradicted"
    if any(v in ("supported", "partially_supported") for v in verdicts):
        return "partially_supported", "only part of the compound claim is supported"
    return "insufficient_evidence", "no sub-claim is supported by the supplied materials"


def coverage_of(verifications, requested_specs):
    verdict_counts = {verdict: 0 for verdict in VERDICTS}
    type_counts = {kind: 0 for kind in SUBCLAIM_TYPES}
    pending = 0
    evidence_count = 0
    conflicts = 0
    for ver in verifications:
        verdict = ver.get("verdict")
        if verdict in verdict_counts:
            verdict_counts[verdict] += 1
        else:
            pending += 1
        if ver.get("conflicts"):
            conflicts += 1
        for sub in ver.get("sub_claims") or []:
            if sub.get("type") in type_counts:
                type_counts[sub["type"]] += 1
            evidence_count += len(sub.get("evidence") or [])
    seen = [ver.get("claim_id") for ver in verifications if ver.get("claim_id")]
    missing = [spec["claim_id"] for spec in requested_specs if spec["claim_id"] not in seen]
    return {
        "claims_requested": len(requested_specs),
        "claims_verified": len(requested_specs) - len(missing) - pending,
        "verdict_counts": verdict_counts,
        "subclaim_type_counts": type_counts,
        "subclaim_total": sum(type_counts.values()),
        "evidence_items": evidence_count,
        "claims_with_conflict": conflicts,
        "pending_claims": pending,
        "missing_claim_ids": missing,
        "complete": bool(requested_specs) and not missing and pending == 0,
    }


def material_sources(corpus):
    return [{"material": mat["material"], "kind": mat["kind"], "bytes": mat["bytes"],
             "sha256": mat.get("sha256", ""), "text_method": mat.get("text_method"),
             "segments": mat.get("segments", 0), "tables": mat.get("tables", 0)}
            for mat in corpus.get("materials", [])]


def base_result(case, corpus, specs, status, verifications, audited_claims,
                uncertainties, pending_human, errors, degradations, extra=None):
    result = {
        "verifications": verifications,
        "coverage": coverage_of(verifications, specs),
        "verdict_definitions": {
            "supported": "context entails the sub-claim with comparator, negation, "
                         "significance and scope preserved",
            "partially_supported": "context supports only part of the sub-claim",
            "contradicted": "context entails the negation of the sub-claim",
            "insufficient_evidence": "materials do not determine it; unsupported "
                                     "extrapolation is not experimental disproof",
            "pending": "init placeholder before the agent draft",
        },
        "aggregation_rule": AGGREGATION_RULE,
        "method_notes": {
            "pipeline": "init -> show -> agent verification -> check -> build",
            "evidence_unit": "paragraph or table row; locator = material + paragraph_id/page/table_id+row",
            "quote_matching": "exact substring first, then whitespace/curly-quote normalised",
            "claim_source": "audit claims are questions/judgements, never treated as facts",
        },
    }
    if extra:
        result.update(extra)
    return {
        "case_id": case_id_of(case), "status": status, "result": result,
        "claims": audited_claims, "uncertainties": uncertainties,
        "sources": material_sources(corpus), "pending_human": pending_human,
        "errors": errors, "degradations": degradations,
        "deliverables": {"index": "work/index.json", "draft": "work/draft.json",
                         "evidence_cards": "evidence_cards.jsonl",
                         "verdict_summary": "verdict_summary.csv",
                         "report": "verification_report.md"},
        "input": {"case_file": "case.json"},
    }


def evaluate_subclaim(sub, corpus):
    """Mechanical checks for one sub-claim. Returns (fails, warns, quote_hit)."""
    sub_id = sub.get("sub_id") or "(no sub_id)"
    fails, warns = [], []
    kind = sub.get("type")
    verdict = sub.get("verdict")
    if kind not in SUBCLAIM_TYPES:
        fails.append("%s: type '%s' not in %s" % (sub_id, kind, "/".join(SUBCLAIM_TYPES)))
    if verdict not in VERDICTS:
        fails.append("%s: verdict '%s' not in %s" % (sub_id, verdict, "/".join(VERDICTS)))
    if not str(sub.get("text") or "").strip():
        fails.append("%s: sub-claim text missing" % sub_id)
    evidence = sub.get("evidence") or []
    located = []
    for idx, item in enumerate(evidence):
        quote = str(item.get("quote") or "")
        hits = find_quote(corpus, quote)
        declared = item.get("material")
        locator = item.get("locator") or {}
        pid = item.get("paragraph_id") or (locator.get("paragraph_id") if isinstance(locator, dict) else None)
        if not quote:
            fails.append("%s: evidence[%d] has no quote" % (sub_id, idx))
            continue
        if not hits:
            fails.append("%s: evidence[%d] quote not found verbatim" % (sub_id, idx))
            continue
        if declared and not [hit for hit in hits if hit["material"] == declared]:
            fails.append("%s: evidence[%d] material '%s' does not contain the quote (found in %s)"
                         % (sub_id, idx, declared, sorted({hit["material"] for hit in hits})))
            continue
        if not declared:
            warns.append("%s: evidence[%d] lacks material; verified by quote search only" % (sub_id, idx))
        if pid and not any(hit["paragraph_id"] == pid or
                           str(hit["paragraph_id"]).startswith(str(pid)) for hit in hits):
            warns.append("%s: evidence[%d] paragraph_id '%s' differs from hit %s"
                         % (sub_id, idx, pid, sorted({hit["paragraph_id"] for hit in hits})))
        located.append((item, hits))
    if verdict in ("supported", "partially_supported", "contradicted") and not located:
        fails.append("%s: verdict '%s' needs one located verbatim quotation" % (sub_id, verdict))
    if verdict == "contradicted" and located:
        quote_blob = " ".join(str(item.get("quote") or "") for item, _hits in located)
        if not NEGATION_RE.search(quote_blob):
            warns.append("%s: contradicted verdict but the quote carries no explicit negation/"
                         "comparison; check the source really entails the opposite" % sub_id)
    if verdict == "supported" and located:
        quote_blob = " ".join(str(item.get("quote") or "") for item, _hits in located)
        if HEDGE_RE.search(quote_blob):
            warns.append("%s: hedged wording quoted but verdict=supported; consider "
                         "partially_supported" % sub_id)
    if not str(sub.get("rationale") or "").strip():
        warns.append("%s: rationale missing (why the quote entails it or not)" % sub_id)
    if verdict == "insufficient_evidence" and not (sub.get("rationale") or sub.get("required_evidence")):
        warns.append("%s: insufficient_evidence needs a reason or the required evidence type" % sub_id)
    return fails, warns, len(located)


def evaluate_verification(ver, spec, corpus):
    """Checks for one claim: decomposition, evidence, aggregation consistency."""
    cid = ver.get("claim_id") or "?"
    fails, warns = [], []
    subs = ver.get("sub_claims") or []
    if spec and spec.get("claim_id") and spec["claim_id"] != cid:
        fails.append("%s: claim_id mismatch with the requested claim list" % cid)
    if not subs:
        fails.append("%s: no sub_claims; decompose the judgement (at least one)" % cid)
    if spec and spec.get("claim_text") and ver.get("claim_text"):
        if norm_text(spec["claim_text"]) != norm_text(ver.get("claim_text")):
            warns.append("%s: claim_text differs from the input claim wording" % cid)
    quote_hits = 0
    sub_verdicts, types = [], []
    for sub in subs:
        sub_fails, sub_warns, hits = evaluate_subclaim(sub, corpus)
        fails.extend(sub_fails)
        warns.extend(sub_warns)
        quote_hits += hits
        sub_verdicts.append(sub.get("verdict"))
        types.append(sub.get("type"))
    computed, reason = aggregate_verdict(sub_verdicts, types)
    verdict = ver.get("verdict")
    if verdict not in VERDICTS:
        fails.append("%s: aggregate verdict '%s' not in %s" % (cid, verdict, "/".join(VERDICTS)))
    elif subs and verdict != computed:
        fails.append("%s: aggregate verdict '%s' inconsistent with sub-claims (%s -> %s)"
                     % (cid, verdict, ",".join(str(v) for v in sub_verdicts), computed))
    if not str(ver.get("rationale") or "").strip():
        warns.append("%s: aggregate rationale missing" % cid)
    if verdict == "insufficient_evidence" and not (ver.get("missing_evidence") or ver.get("rationale")):
        warns.append("%s: insufficient_evidence should state what is missing" % cid)
    return fails, warns, quote_hits


def claim_rows(verifications):
    rows = []
    for ver in verifications:
        subs = ver.get("sub_claims") or []
        rows.append({
            "claim_id": ver.get("claim_id"),
            "claim_text": ver.get("claim_text"),
            "subclaim_count": len(subs),
            "types": "|".join(str(sub.get("type")) for sub in subs),
            "sub_verdicts": "|".join(str(sub.get("verdict")) for sub in subs),
            "verdict": ver.get("verdict"),
            "evidence_items": sum(len(sub.get("evidence") or []) for sub in subs),
            "conflicts": len(ver.get("conflicts") or []),
            "missing_evidence": "; ".join(str(item) for item in (ver.get("missing_evidence") or [])),
            "rationale": ver.get("rationale"),
        })
    return rows

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Evidence tracing & fact verification skill - command entry point.

Commands: init | show | check | build | selfcheck
  init      scan /input, index materials with locators, write a partial result.json
  show      print the audit claims and materials with stable locators
  check     validate the agent draft: decomposition, evidence hits, verdict consistency
  build     assemble deliverables + result.json (always finalizes, never crashes)
  selfcheck re-verify the finished result.json against the live materials

Rules honoured here: standard library only, no network, CWD independent, exit code 0.
The Agent reads the sources and writes <work>/draft.json; the script never invents
evidence or verdicts. Audit claims are questions, not established facts.
"""
import argparse
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import io_parse as IOP  # noqa: E402
import verify_lib as VL  # noqa: E402
import derive as DERIVE  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

PKG_NAME = "evidence-verifier"
VERSION = "2.0.0"
PRODUCTS = ("result.json", "evidence_cards.jsonl", "verdict_summary.csv",
            "verification_report.md")


def cmd_init(args):
    inp, work, out = Path(args.input), Path(args.work), Path(args.output)
    IOP.ensure_dir(work)
    IOP.ensure_dir(out)
    case, case_err = VL.read_case(inp)
    contract = case.get("output_contract") if isinstance(case, dict) else {}
    corpus = IOP.build_corpus(inp)
    specs, spec_source = VL.find_claim_specs(inp, case)
    degradations = list(corpus.get("degradations", []))
    errors = [case_err] if case_err else []
    if not specs:
        degradations.append("audit claims not found; expected claims-to-verify.json")
    index = {
        "case_id": VL.case_id_of(case), "input": str(inp),
        "material_count": len(corpus["materials"]), "segment_count": len(corpus["segments"]),
        "table_count": len(corpus["tables"]), "claim_spec_source": spec_source,
        "claim_count": len(specs), "claims": specs,
        "materials": [{"material": mat["material"], "kind": mat["kind"], "bytes": mat["bytes"],
                       "segments": mat["segments"], "tables": mat["tables"],
                       "text_method": mat["text_method"]} for mat in corpus["materials"]],
        "segments": corpus["segments"],
    }
    IOP.jdump(work / "index.json", index)
    IOP.jdump(work / "claims_skeleton.json", {"case_id": index["case_id"], "claims": specs})
    skeleton = VL.skeleton_verifications(specs)
    status = "input_error" if (case_err and not corpus["materials"]) else "partial"
    pending = []
    if specs:
        pending.append("Agent must read sources (show) and write %s with one verification per claim_id"
                       % (work / "draft.json"))
    else:
        pending.append("Provide the audit claims file (claims-to-verify.json) with claim_id entries")
    doc = VL.base_result(case, corpus, specs, status, skeleton, [], [], pending, errors, degradations)
    IOP.jdump(out / "result.json", VL.echo_contract(contract, doc))
    print("init: case_id=%s claims=%d materials=%d segments=%d tables=%d"
          % (index["case_id"], len(specs), index["material_count"],
             index["segment_count"], index["table_count"]))
    for mat in corpus["materials"]:
        print("  material: %-48s %-9s seg=%d tables=%d"
              % (mat["material"], mat["kind"], mat["segments"], mat["tables"]))
    print("next: python3 scripts/main.py show ; write work/draft.json ; check ; build")


def cmd_show(args):
    inp, work = Path(args.input), Path(args.work)
    index = IOP.jload(work / "index.json")
    if not index:
        cmd_init(args)
        index = IOP.jload(work / "index.json") or {}
    print("== case %s | claims=%s materials=%s segments=%s ==" % (
        index.get("case_id"), index.get("claim_count"), index.get("material_count"),
        index.get("segment_count")))
    if not args.no_claims:
        print("\n== audit claims (questions to verify, not facts) ==")
        for spec in index.get("claims", []):
            print("- claim_id=%s | conditions=%s | claim=%s" % (
                spec.get("claim_id"), spec.get("conditions"),
                (spec.get("claim_text") or "")[:400]))
    print("\n== materials ==")
    for mat in index.get("materials", []):
        print("- %-46s kind=%-9s bytes=%s seg=%s method=%s" % (
            mat.get("material"), mat.get("kind"), mat.get("bytes"), mat.get("segments"),
            mat.get("text_method")))
    budget = max(1000, int(args.limit))
    used, shown = 0, 0
    print("\n== segments (locator :: text) ==")
    for seg in index.get("segments", []):
        if args.material and args.material not in seg.get("material", ""):
            continue
        if args.pid and args.pid != seg.get("paragraph_id"):
            continue
        block = "--- %s :: %s :: section=%s :: page=%s ---\n%s\n" % (
            seg.get("material"), seg.get("paragraph_id"), seg.get("section"),
            seg.get("page"), seg.get("text"))
        if used + len(block) > budget:
            print("... truncated at %d chars; use --limit/--material/--pid" % used)
            break
        sys.stdout.write(block)
        used += len(block)
        shown += 1
    print("\n[shown %d segments, %d chars] copy evidence quotes verbatim; locator = material + paragraph_id"
          % (shown, used))


def cmd_check(args):
    work = Path(args.work)
    index = IOP.jload(work / "index.json") or {}
    corpus = IOP.build_corpus(args.input) if Path(args.input).exists() else {
        "segments": index.get("segments", [])}
    specs = {spec.get("claim_id"): spec for spec in index.get("claims", [])}
    draft, draft_err = VL.load_draft(work)
    fails, warns, quote_hits, evidence_total = [], [], 0, 0
    if draft is None:
        fails.append(draft_err)
    verifications = VL.draft_verifications(draft) if draft else []
    ids = [ver.get("claim_id") for ver in verifications]
    missing = [cid for cid in specs if cid not in ids]
    extra = [cid for cid in ids if cid and cid not in specs]
    dups = sorted({cid for cid in ids if cid and ids.count(cid) > 1})
    if missing:
        fails.append("missing requested claim_id(s): " + ", ".join(missing))
    if extra:
        warns.append("unknown claim_id(s) not in the audit list: " + ", ".join(extra))
    if dups:
        fails.append("duplicate claim_id(s): " + ", ".join(dups))
    verdict_counts = {}
    for raw in verifications:
        ver = VL.normalize_verification(raw, specs.get(raw.get("claim_id")))
        sub_fails, sub_warns, hits = VL.evaluate_verification(ver, specs.get(ver.get("claim_id")), corpus)
        fails.extend(sub_fails)
        warns.extend(sub_warns)
        quote_hits += hits
        evidence_total += sum(len(sub.get("evidence") or []) for sub in ver.get("sub_claims") or [])
        verdict = ver.get("verdict") or "pending"
        verdict_counts[verdict] = verdict_counts.get(verdict, 0) + 1
    report = {"ok": not fails, "fail": fails, "warn": warns,
              "claims_requested": len(specs), "claims_in_draft": len(verifications),
              "missing": missing, "extra": extra, "duplicates": dups,
              "verdict_counts": verdict_counts, "evidence_items": evidence_total,
              "quote_hits": quote_hits}
    IOP.jdump(work / "check_report.json", report)
    print("check: %s | claims=%d/%d evidence_items=%d quote_verified=%d" % (
        "PASS" if report["ok"] else "FAIL", len(verifications), len(specs),
        evidence_total, quote_hits))
    for msg in fails[:20]:
        print("  FAIL " + msg)
    for msg in warns[:20]:
        print("  WARN " + msg)
    if not fails:
        print("ready: build emits result.json + evidence_cards.jsonl + verdict_summary.csv + report")


def cmd_build(args):
    inp, work, out = Path(args.input), Path(args.work), Path(args.output)
    IOP.ensure_dir(work)
    IOP.ensure_dir(out)
    case, case_err = VL.read_case(inp)
    contract = case.get("output_contract") if isinstance(case, dict) else {}
    corpus = IOP.build_corpus(inp)
    specs, spec_source = VL.find_claim_specs(inp, case)
    spec_map = {spec["claim_id"]: spec for spec in specs}
    degradations = list(corpus.get("degradations", []))
    errors = [case_err] if case_err else []
    draft, draft_err = VL.load_draft(work)
    check_report = IOP.jload(work / "check_report.json") or {}
    verifications, uncertainties, derived_used = [], [], False
    if not corpus.get("materials"):
        degradations.append("no readable material under input; claims cannot be verified")
    if draft is None:
        verifications, derive_note = DERIVE.derive_all(specs, corpus)
        derived_used = True
        degradations.append(
            "no usable draft (%s); deterministic derive produced %d per-claim verdict(s)"
            % (draft_err, len(verifications)))
        if derive_note.get("degradations"):
            degradations.extend(derive_note["degradations"])
        if not specs:
            degradations.append("audit claims not found; expected claims-to-verify.json")
    else:
        seen = set()
        for raw in VL.draft_verifications(draft):
            cid = raw.get("claim_id") or "claim_%03d" % (len(verifications) + 1)
            if cid in seen:
                degradations.append("duplicate draft claim_id dropped: %s" % cid)
                continue
            seen.add(cid)
            ver = VL.normalize_verification(raw, spec_map.get(cid))
            ver["claim_id"] = cid
            f_fails, f_warns, _hits = VL.evaluate_verification(ver, spec_map.get(cid), corpus)
            if f_fails:
                ver["validation_fails"] = f_fails
                if ver.get("verdict") in ("supported", "partially_supported", "contradicted"):
                    ver["reported_verdict"] = ver["verdict"]
                    ver["verdict"] = "insufficient_evidence"
                    ver["notes"] = ("verdict downgraded: evidence did not verify; "
                                    + "; ".join(f_fails)[:400])
                    degradations.append("%s downgraded to insufficient_evidence: %s"
                                        % (cid, f_fails[0]))
            if f_warns:
                ver["validation_warnings"] = f_warns
            verifications.append(ver)
        for cid, spec in spec_map.items():
            if cid not in seen:
                derived_missing, _note_m = DERIVE.derive_all([spec], corpus)
                if derived_missing:
                    verifications.append(derived_missing[0])
                    degradations.append("claim missing from draft; enriched by deterministic "
                                        "derive: %s" % cid)
                else:
                    ver = VL.skeleton_verifications([spec])[0]
                    ver["verdict"] = "insufficient_evidence"
                    ver["rationale"] = "claim not present in draft"
                    verifications.append(ver)
                    degradations.append("requested claim not verified: %s" % cid)
        if isinstance(draft.get("uncertainties"), list):
            uncertainties.extend(draft["uncertainties"])
    audited_claims = []
    for ver in verifications:
        cid = ver.get("claim_id")
        verdict = ver.get("verdict")
        audited_claims.append({"claim_id": cid, "claim_text": ver.get("claim_text"),
                               "verdict": verdict,
                               "subclaim_count": len(ver.get("sub_claims") or []),
                               "evidence_count": sum(len(sub.get("evidence") or [])
                                                     for sub in ver.get("sub_claims") or [])})
        if verdict == "insufficient_evidence":
            uncertainties.append({"kind": "insufficient_evidence", "claim_id": cid,
                                  "detail": ver.get("rationale") or "materials do not determine the claim",
                                  "missing_evidence": ver.get("missing_evidence") or []})
        if ver.get("conflicts"):
            uncertainties.append({"kind": "source_conflict", "claim_id": cid,
                                  "detail": "sources agree only partially; both sides located",
                                  "conflicts": ver["conflicts"]})
    coverage = VL.coverage_of(verifications, specs)
    terminal = bool(verifications) and all(
        ver.get("verdict") in VL.VERDICTS for ver in verifications)
    if not case:
        status = "input_error"
    elif not corpus.get("materials") or not specs:
        status = "insufficient_evidence"
    elif terminal and coverage["complete"] and (derived_used or check_report.get("ok")):
        status = "ok"
    else:
        status = "partial"
    pending_human = []
    if status != "ok":
        pending_human.append("Review degradations/uncertainties, fix the draft, re-run check+build")
    doc = VL.base_result(case, corpus, specs, status, verifications, audited_claims,
                         uncertainties, pending_human, errors, degradations,
                         {"validation": check_report, "claim_spec_source": spec_source})
    IOP.jdump(out / "result.json", VL.echo_contract(contract, doc))
    DERIVE.write_deliverables(out, work, doc, verifications, coverage, degradations,
                              corpus, status, specs, uncertainties, PKG_NAME, VERSION)
    print("build: status=%s case_id=%s claims=%d supported=%d partial=%d contradicted=%d "
          "insufficient=%d" % (status, doc["case_id"], len(verifications),
                               coverage["verdict_counts"]["supported"],
                               coverage["verdict_counts"]["partially_supported"],
                               coverage["verdict_counts"]["contradicted"],
                               coverage["verdict_counts"]["insufficient_evidence"]))
    for name in PRODUCTS:
        path = out / name
        print("  %-26s %s bytes" % (name, path.stat().st_size if path.exists() else "MISSING"))
    for item in degradations[:8]:
        print("  degrade: " + str(item)[:200])


def cmd_selfcheck(args):
    inp, work, out = Path(args.input), Path(args.work), Path(args.output)
    case, _ = VL.read_case(inp)
    contract = case.get("output_contract") if isinstance(case, dict) else {}
    result = IOP.jload(out / "result.json")
    problems = []
    if not isinstance(result, dict):
        problems.append("output/result.json missing or invalid")
        result = {}
    for key in VL.contract_keys(contract):
        if key not in result:
            problems.append("contract key missing: " + key)
    if result.get("case_id") != VL.case_id_of(case):
        problems.append("case_id mismatch: %r vs %r" % (result.get("case_id"), VL.case_id_of(case)))
    corpus = IOP.build_corpus(inp)
    verifications = (result.get("result") or {}).get("verifications") or []
    checked = hits = 0
    for ver in verifications:
        for sub in ver.get("sub_claims") or []:
            for item in sub.get("evidence") or []:
                checked += 1
                if IOP.find_quote(corpus, str(item.get("quote") or "")):
                    hits += 1
                else:
                    problems.append("evidence quote no longer verifies: %s/%s"
                                    % (ver.get("claim_id"), sub.get("sub_id")))
    for name in PRODUCTS:
        if not (out / name).exists():
            problems.append("missing deliverable: " + name)
    coverage = (result.get("result") or {}).get("coverage") or {}
    if coverage:
        counted = sum(coverage.get("verdict_counts", {}).values())
        if counted != len(verifications):
            problems.append("verdict counts (%d) != verification rows (%d)"
                            % (counted, len(verifications)))
    report = {"ok": not problems, "problems": problems,
              "contract_keys": VL.contract_keys(contract), "claims": len(verifications),
              "evidence_checked": checked, "evidence_verified": hits}
    IOP.jdump(work / "selfcheck_report.json", report)
    print("selfcheck: %s | contract_keys=%d claims=%d evidence=%d/%d" % (
        "PASS" if report["ok"] else "FAIL", len(report["contract_keys"]),
        len(verifications), hits, checked))
    for item in problems[:15]:
        print("  FAIL " + str(item))


class SafeParser(argparse.ArgumentParser):
    def error(self, message):
        print("argument warning: " + message)
        self.print_help()
        sys.exit(0)


def add_paths(parser):
    parser.add_argument("--input", default=argparse.SUPPRESS, help="input dir (default /input)")
    parser.add_argument("--work", default=argparse.SUPPRESS, help="work dir (default /app/work)")
    parser.add_argument("--output", default=argparse.SUPPRESS, help="output dir (default /app/output)")


def build_parser():
    parser = SafeParser(prog="main.py",
                        description="Evidence tracing & fact verification skill")
    parser.add_argument("--input", default="/input")
    parser.add_argument("--work", default="/app/work")
    parser.add_argument("--output", default="/app/output")
    parser.add_argument("--version", action="version", version=PKG_NAME + " " + VERSION)
    sub = parser.add_subparsers(dest="command")
    for name, help_text in (("init", "scan input, index materials, write partial result.json"),
                            ("show", "print claims and materials with locators"),
                            ("check", "validate the agent draft"),
                            ("build", "assemble deliverables and finalize result.json"),
                            ("selfcheck", "re-verify the finished result.json")):
        child = sub.add_parser(name, help=help_text)
        add_paths(child)
        if name == "show":
            child.add_argument("--material", default="", help="filter by material substring")
            child.add_argument("--pid", default="", help="filter by exact paragraph_id")
            child.add_argument("--no-claims", action="store_true", help="hide the audit claims")
            child.add_argument("--limit", default="60000", help="max characters printed")
    return parser


def emergency_finalize(args, exc_text):
    try:
        work, out = Path(getattr(args, "work", "/app/work")), Path(getattr(args, "output", "/app/output"))
        IOP.ensure_dir(work)
        IOP.ensure_dir(out)
        case, _ = VL.read_case(Path(getattr(args, "input", "/input")))
        contract = case.get("output_contract") if isinstance(case, dict) else {}
        doc = {
            "case_id": VL.case_id_of(case), "status": "input_error",
            "result": {"verifications": [], "coverage": VL.coverage_of([], []),
                       "verdict_definitions": {}, "aggregation_rule": VL.AGGREGATION_RULE,
                       "method_notes": {"skill": PKG_NAME, "version": VERSION}},
            "claims": [], "uncertainties": [], "sources": [],
            "pending_human": ["Unexpected skill error; inspect errors and rerun init/show/check/build"],
            "errors": [exc_text[:2000]], "degradations": ["emergency_finalize used"],
            "deliverables": {},
        }
        IOP.jdump(out / "result.json", VL.echo_contract(contract, doc))
    except Exception:
        pass


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    args.input = Path(getattr(args, "input", "/input"))
    args.work = Path(getattr(args, "work", "/app/work"))
    args.output = Path(getattr(args, "output", "/app/output"))
    command = getattr(args, "command", None)
    try:
        if command == "init":
            cmd_init(args)
        elif command == "show":
            cmd_show(args)
        elif command == "check":
            cmd_check(args)
        elif command == "build":
            cmd_build(args)
        elif command == "selfcheck":
            cmd_selfcheck(args)
        else:
            parser.print_help()
    except SystemExit:
        raise
    except BaseException as exc:
        traceback.print_exc()
        emergency_finalize(args, "%s: %s" % (type(exc).__name__, exc))
    return 0


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except BaseException:
        traceback.print_exc()
    sys.exit(0)

# -*- coding: utf-8 -*-
"""Deterministic no-draft claim verification (evidence tracing fallback).

When the eval agent has not written <work>/draft.json, build derives real
per-claim verdicts directly from /input instead of an empty scaffold:

  1. claim specs come from claims-to-verify.json first, then case.json claims;
  2. each claim is split into sub-claims on sentence boundaries and ; / and /
     or / but, with the subject re-attached to fragments;
  3. every material segment is scanned (fixed sorted order), sentence by
     sentence, for supporting AND contradicting evidence via keyword / number /
     entity overlap plus polarity and antonym reversal;
  4. four-way verdict supported | partially_supported | contradicted |
     insufficient_evidence; conflicts keep BOTH locations;
  5. quotes are verbatim substrings, re-verified with io_parse.find_quote.

This is a bounded, deterministic heuristic, not a substitute for careful
reading. A valid agent draft is always preferred; build only uses this path
when no usable draft exists (and overlays/enriches missing claims in a draft).
"""
import csv
import json
import re
from pathlib import Path

from io_parse import HEDGE_RE, find_quote, jdump, norm_text
from verify_lib import (AGGREGATION_RULE, SUBCLAIM_TYPES, VERDICTS,
                        aggregate_verdict, claim_rows)

DERIVE_VERSION = "2.0.0"
MAX_EVIDENCE = 3

SENT_SPLIT_RE = re.compile(r"(?<=[.!?;])\s+|\n+")
VERB_RE = re.compile(
    r"(?i)\b(?:is|are|was|were|be|been|being|has|have|had|do|does|did|"
    r"reduc(?:e|es|ed)?|decreas(?:e|es|ed)?|increas(?:e|es|ed)?|improv(?:e|es|ed)?|"
    r"lower(?:s|ed)?|rais(?:e|es|ed)?|show(?:s|ed)?|report(?:s|ed)?|last(?:s|ed)?|"
    r"continu(?:e|es|ed)?|remain(?:s|ed)?|affect(?:s|ed)?|caus(?:e|es|ed)?|"
    r"correlat(?:e|es|ed)?|associat(?:e|es|ed)?|differ(?:s|ed)?|extend(?:s|ed)?|"
    r"appl(?:y|ies|ied)|limit(?:s|ed)?|randomiz(?:e|es|ed)?|conduct(?:s|ed)?|"
    r"enroll(?:s|ed)?|recruit(?:s|ed)?|mean(?:s|t)?|suggest(?:s|ed)?|"
    r"indicat(?:e|es|ed)|measur(?:e|es|ed)?|assess(?:s|ed)?)\b")

STOPWORDS = frozenset("""
a an the of in on at for with by to as is are was were be been being that this
these those it its and or but from into over under than then so such if while
which who whom whose when where how why what all any each few more most other
some no nor not only own same too very just can will should would could may
might must do does did have has had having doing etc e.g i.e among between
""".split())

KEEP_TOKENS = frozenset("""not no nor none never without versus vs compared
comparison difference between among significant significantly nonsignificant
insignificant more less than greater fewer higher lower similar placebo group
groups adult adults week weeks month months year years center centers""".split())

CONCEPT_PATTERNS = (
    (re.compile(r"(?i)\b(?:reduc\w*|decreas\w*|lower\w*|fall\w*|fell|declin\w*|attenuat\w*)"), "decrease"),
    (re.compile(r"(?i)\b(?:increas\w*|elevat\w*|rais\w*|ris\w*|higher|greater|gain\w*)"), "increase"),
    (re.compile(r"(?i)\b(?:improv\w*|better|efficac\w*|effective|efficacy|benefit\w*|ameliorat\w*)"), "improve"),
    (re.compile(r"(?i)\b(?:worsen\w*|harm\w*|detriment\w*|toxicit\w*|unsafe)\b"), "worsen"),
    (re.compile(r"(?i)\b(?:safe\w*|safety|tolerab\w*|tolerat\w*)"), "safety"),
    (re.compile(r"(?i)\b(?:multi[- ]?cent\w*)"), "multicenter"),
    (re.compile(r"(?i)\b(?:single[- ]?cent\w*)"), "single-center"),
    (re.compile(r"(?i)\b(?:not\s+significant|no\s+significant|non[- ]?significant|insignificant)"), "not_significant"),
    (re.compile(r"(?i)\b(?:significant\w*)"), "significant"),
    (re.compile(r"(?i)\b(?:versus|vs\.?|compared\s+(?:with|to)|more\s+than|less\s+than|"
                r"greater\s+than|higher\s+than|lower\s+than|between[- ]group|relative\s+to|"
                r"differ\w*|difference)"), "comparison"),
)

ANTONYMS = {
    "decrease": {"increase"},
    "increase": {"decrease"},
    "improve": {"worsen"},
    "worsen": {"improve"},
    "multicenter": {"single-center"},
    "single-center": {"multicenter"},
    "significant": {"not_significant"},
    "not_significant": {"significant"},
}

PRIMARY = frozenset(("decrease", "increase", "improve", "worsen"))
DIRECTIONAL = frozenset(("decrease", "increase", "improve", "worsen", "comparison",
                         "significant", "not_significant", "multicenter",
                         "single-center", "safety"))

# Pure negation detector (verify_lib.NEGATION_RE is intentionally broader: it also
# flags comparators/directional verbs for the contradicted-quote check, which would
# break polarity here, so the derive uses its own strict negation list).
NEG_RE = re.compile(
    r"(?i)\b(?:not|no|never|neither|nor|none|without|fail(?:ed|s|ure)?|"
    r"did\s+not|does\s+not|do\s+not|was\s+not|were\s+not|is\s+not|are\s+not|"
    r"has\s+not|have\s+not|unchanged|no\s+significant|not\s+significant|"
    r"not\s+assessed|no\s+difference|no\s+change)\b")

# Generic predicate/entity stems that do not, by themselves, link a claim to one
# specific source sentence. Content tokens (endpoints, biomarkers, populations
# beyond the generic set, conditions) must also overlap for primary-directional
# support, so "reduces fasting glucose" is not marked supported by a sentence
# about "reduced HbA1c".
GENERIC = frozenset({
    "compound", "placebo", "group", "trial", "study", "studi", "result",
    "patient", "adult", "human", "week", "month", "year", "compar", "versu",
    "versus", "vs", "significant", "differ", "more", "less", "than", "between",
    "among", "reduc", "decreas", "increas", "improv", "lower", "higher",
    "greater", "fewer", "difference",
})

CAUSAL_RE = re.compile(
    r"(?i)\b(?:via|through|because|due\s+to|leads?\s+to|results?\s+in|mediat\w*|"
    r"mechanism|pathway|sensitivit\w*|resistance|clearance|expression|signaling|activity)\b")
COMPARISON_RE = re.compile(
    r"(?i)\b(?:versus|vs\.?|compared\s+(?:with|to)|comparison|more\s+than|less\s+than|"
    r"greater\s+than|higher\s+than|lower\s+than|between[- ]group|difference|relative\s+to|"
    r"superior|inferior|placebo|baseline)\b")
SCOPE_RE = re.compile(
    r"(?i)\b(?:long-term|short-term|all\s+adults|population|generaliz\w*|weeks?|months?|"
    r"years?|days?|duration|follow-up|aged|age\s+range|multicenter|single[- ]?center|"
    r"sample\s+size|n\s*=\s*\d+|per\s+group|beyond)\b")

SAFETY_FAV = re.compile(
    r"(?i)\b(?:no\s+serious\s+adverse|adverse\s+events?\s+(?:were|was)\s+similar|"
    r"adverse\s+events?\s+did\s+not\s+differ|well\s+tolerated|no\s+deaths?|"
    r"was\s+safe|were\s+safe|is\s+safe|safe\s+and)\b")
SAFETY_UNFAV = re.compile(
    r"(?i)\b(?:serious\s+adverse\s+events?\s+(?:were\s+reported|occurred|were\s+observed)|"
    r"deaths?\s+(?:occurred|were\s+reported)|toxicit\w*|unsafe|not\s+safe|harmful|"
    r"adverse\s+events?\s+(?:were|was)\s+more\s+(?:frequent|common)|increased\s+adverse)\b")

NEG_COMPARE_RE = re.compile(
    r"(?i)\b(?:not\s+significant|no\s+significant|did\s+not\s+differ\s+significantly|"
    r"no\s+significant\s+difference|no\s+difference|was\s+not\s+significant|"
    r"were\s+not\s+significant)\b")


def _stem(word):
    word = word.lower()
    if len(word) <= 3:
        return word
    if word.endswith("ies"):
        word = word[:-3] + "y"
    elif word.endswith("es"):
        word = word[:-2]
    elif word.endswith("s") and not word.endswith("ss"):
        word = word[:-1]
    if word.endswith("ing"):
        word = word[:-3]
    elif word.endswith("ed"):
        word = word[:-2]
    if word.endswith("ly"):
        word = word[:-2]
    if word.endswith("e") and len(word) > 3:
        word = word[:-1]
    return word


def _word_tokens(text):
    words = re.findall(r"[A-Za-z][A-Za-z0-9\-]*", norm_text(text or ""))
    out = []
    for word in words:
        low = word.lower()
        if len(low) < 2:
            continue
        if low in STOPWORDS and low not in KEEP_TOKENS:
            continue
        out.append(_stem(low))
    return set(out)


def _numbers(text):
    found = set()
    for match in re.finditer(r"[-+−]?\d+(?:[.,]\d+)?", norm_text(text or "")):
        found.add(match.group(0).replace(",", "."))
    return found


def _number_unit_pairs(text):
    pairs = []
    pattern = re.compile(
        r"(\d+(?:[.,]\d+)?)\s*(%|percent|mg|kg|g|mmol|mol|weeks?|months?|years?|"
        r"days?|hours?|minutes?|centers?|patients?|participants?|cm|mm|ml|dl|l)\b", re.I)
    for match in pattern.finditer(norm_text(text or "")):
        try:
            value = float(match.group(1).replace(",", "."))
        except ValueError:
            continue
        pairs.append((value, match.group(2).lower().rstrip("s")))
    return pairs


def _concepts(text):
    found = set()
    for pattern, label in CONCEPT_PATTERNS:
        if pattern.search(text or ""):
            found.add(label)
    return found


def _has_verb(text):
    return bool(VERB_RE.search(text or ""))


def _split_clauses(sentence):
    protected = re.sub(
        r"(?i)(\d+(?:[.,]\d+)?)\s+(and|or|to)\s+(\d+(?:[.,]\d+)?)",
        r"\1|\2|\3", sentence)
    parts = [part.strip() for part in
             re.split(r"\s*;\s*|\s+(?:and|or|but)\s+", protected, flags=re.I)
             if part.strip()]
    return [part.replace("|and|", " and ").replace("|or|", " or ").replace("|to|", " to ")
            for part in parts]


def _reattach(parts, sentence):
    match = VERB_RE.search(sentence)
    subject = sentence[:match.start()].strip() if match else ""
    head = sentence[:match.end()].strip() if match else ""
    out = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        if not _has_verb(part):
            part = (head + " " + part).strip() if head else part
        elif subject and part[:1].isalpha() and part[:1].islower():
            part = (subject + " " + part).strip()
        out.append(part)
    return out


def split_claims(text):
    """Split a claim into independently checkable sub-claims."""
    text = norm_text(text or "").strip()
    if not text:
        return []
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]
    if not sentences:
        sentences = [text]
    parts = []
    for sentence in sentences:
        chunks = _split_clauses(sentence)
        if len(chunks) == 1:
            parts.append(chunks[0])
        else:
            parts.extend(_reattach(chunks, sentence))
    out = []
    for part in parts:
        part = part.strip().rstrip(".")
        if part and (not out or part != out[-1]):
            out.append(part)
    return out or [text.rstrip(".")]


def classify(text):
    text = norm_text(text or "")
    if CAUSAL_RE.search(text):
        return "causal"
    if COMPARISON_RE.search(text):
        return "comparison"
    if SCOPE_RE.search(text):
        return "scope"
    return "fact"


def build_units(corpus):
    units = []
    for seg in corpus.get("segments", []):
        seg_text = seg.get("text") or ""
        for idx, sentence in enumerate(SENT_SPLIT_RE.split(seg_text)):
            sentence = sentence.strip().rstrip(";,")
            if len(sentence) < 3:
                continue
            units.append({
                "material": seg.get("material"),
                "paragraph_id": seg.get("paragraph_id"),
                "page": seg.get("page"),
                "section": seg.get("section"),
                "table_id": seg.get("table_id"),
                "row": seg.get("row"),
                "text": sentence,
                "sentence_index": idx,
            })
    return units


def _relation(sub_text, sent_text):
    ct = _word_tokens(sub_text)
    st = _word_tokens(sent_text)
    cc = _concepts(sub_text)
    sc = _concepts(sent_text)
    cn = _numbers(sub_text)
    sn = _numbers(sent_text)
    cnp = _number_unit_pairs(sub_text)
    snp = _number_unit_pairs(sent_text)
    token_overlap = ct & st
    concept_overlap = cc & sc
    content_overlap = (ct & st) - GENERIC
    claim_neg = bool(NEG_RE.search(sub_text))
    sent_neg = bool(NEG_RE.search(sent_text))
    hedge = bool(HEDGE_RE.search(sent_text))
    num_support = bool(cn) and bool(cn & sn)

    sent_values = {}
    for value, unit in snp:
        sent_values.setdefault(unit, []).append(value)
    magnitude_mismatch = False
    if cnp:
        for value, unit in cnp:
            values = sent_values.get(unit, [])
            if values and value not in values and any(other != value for other in values):
                magnitude_mismatch = True
                break

    antonym_hit = any(anti in sc for c in cc for anti in ANTONYMS.get(c, ()))
    polarity_flip = claim_neg != sent_neg
    contradiction = (antonym_hit and (bool(token_overlap) or bool(concept_overlap))) or \
                    (polarity_flip and bool(content_overlap)) or \
                    (magnitude_mismatch and not concept_overlap)
    if contradiction:
        return "contradict"

    if cc & PRIMARY:
        supported = bool((cc & PRIMARY) & sc) and (bool(content_overlap) or num_support)
    elif cc & DIRECTIONAL:
        supported = bool(cc & sc)
    elif cn:
        supported = num_support and bool(token_overlap)
    else:
        content_tokens = (ct - GENERIC) or ct
        coverage = len(content_overlap) / max(1, len(content_tokens))
        supported = bool(content_overlap) and coverage >= 0.6
    if not supported:
        return None
    if magnitude_mismatch:
        return "weak"
    return "weak" if hedge else "support"


def _content_anchored(sub_text, sent_text):
    return bool((_word_tokens(sub_text) & _word_tokens(sent_text)) - GENERIC)


def evidence_scan(sub_text, units):
    support = []
    contra = []
    if "safety" in _concepts(sub_text):
        for unit in units:
            if SAFETY_FAV.search(unit["text"]):
                support.append((unit, False))
            elif SAFETY_UNFAV.search(unit["text"]):
                contra.append(unit)
        return support, contra
    for unit in units:
        rel = _relation(sub_text, unit["text"])
        if rel in ("support", "weak"):
            support.append((unit, rel == "weak"))
        elif rel == "contradict":
            contra.append(unit)
    if support and contra:
        support_pids = {unit["paragraph_id"] for unit, _weak in support}
        contra = [unit for unit in contra
                  if _content_anchored(sub_text, unit["text"])
                  or unit["paragraph_id"] in support_pids]
    if support:
        support_pids = {unit["paragraph_id"] for unit, _weak in support}
        known = {id(unit) for unit in contra}
        for unit in units:
            if (unit["paragraph_id"] in support_pids
                    and NEG_COMPARE_RE.search(unit["text"])
                    and id(unit) not in known):
                contra.append(unit)
                known.add(id(unit))
    return support, contra


def _evidence_item(unit, relation):
    return {
        "material": unit["material"],
        "locator": {"paragraph_id": unit["paragraph_id"], "page": unit.get("page"),
                    "section": unit.get("section")},
        "paragraph_id": unit["paragraph_id"],
        "page": unit.get("page"),
        "section": unit.get("section"),
        "table_id": unit.get("table_id"),
        "row": unit.get("row"),
        "quote": unit["text"],
        "relation": relation,
    }


def _make_evidence(verdict, support, contra):
    out = []
    if verdict == "contradicted":
        for unit in contra[:MAX_EVIDENCE]:
            out.append(_evidence_item(unit, "contradict"))
    elif verdict == "partially_supported":
        for unit, weak in support[:MAX_EVIDENCE]:
            out.append(_evidence_item(unit, "weak" if weak else "support"))
        for unit in contra[:MAX_EVIDENCE]:
            out.append(_evidence_item(unit, "contradict"))
    elif verdict == "supported":
        for unit, weak in support[:MAX_EVIDENCE]:
            if not weak:
                out.append(_evidence_item(unit, "support"))
        if not out:
            for unit, _weak in support[:1]:
                out.append(_evidence_item(unit, "weak"))
    elif verdict == "insufficient_evidence":
        for unit, _weak in support[:2]:
            out.append(_evidence_item(unit, "weak"))
    return out


def _sub_verdict(ctype, support, contra):
    if support and contra:
        return "partially_supported", (
            "both supporting and contradicting sentences were found; both locations kept"), True
    if contra:
        return "contradicted", "the material states the opposite of the sub-claim", False
    if support:
        strong = [unit for unit, weak in support if not weak]
        if ctype == "causal" and not strong:
            return "insufficient_evidence", (
                "only hedged speculation (may/suggest/possibly) was found; no direct "
                "measurement of the claimed mechanism"), False
        if not strong:
            return "partially_supported", "only weaker/hedged wording was found", False
        return "supported", "a verbatim sentence entails the sub-claim", False
    return "insufficient_evidence", (
        "no sentence entailed or contradicted the sub-claim (insufficient evidence "
        "is not disproof)"), False


def _preserved(text):
    neg = sorted(set(re.findall(
        r"(?i)\b(?:not|no|never|neither|nor|none|without|did\s+not|does\s+not|do\s+not|"
        r"was\s+not|were\s+not|is\s+not|are\s+not|no\s+significant|not\s+significant|"
        r"single[- ]?center|unchanged|not\s+assessed)\b", text or "")))
    comp = sorted(set(re.findall(
        r"(?i)(?:versus|vs\.?|compared\s+(?:with|to)|more\s+than|less\s+than|greater\s+than|"
        r"higher\s+than|lower\s+than|between[- ]group|relative\s+to|difference)", text or "")))
    sig = sorted(set(re.findall(
        r"(?i)(?:p\s*[=<>≤≥]\s*\d+(?:[.,]\d+)?|95%\s*CI|significant(?:ly)?|"
        r"no\s+significant|not\s+significant)", text or "")))
    cond = sorted(set(re.findall(
        r"(?i)(?:in\s+[a-z][a-z\s,0-9-]{2,40}|over\s+\d+\s+weeks?|for\s+\d+\s+weeks?|"
        r"beyond\s+\d+\s+weeks?|aged\s+[\d-]+|long-term|short-term|all\s+adults|"
        r"at\s+week\s+\d+|per\s+group)", text or "")))
    return {
        "negation": neg or None,
        "comparator": comp or None,
        "significance": sig or None,
        "condition": cond or None,
    }


def _conflict_entries(support, contra):
    entries = []
    for unit, _weak in support[:2]:
        entries.append({"material": unit["material"], "paragraph_id": unit["paragraph_id"],
                        "page": unit.get("page"), "section": unit.get("section"),
                        "quote": unit["text"], "detail": "supporting source",
                        "relation": "support"})
    for unit in contra[:2]:
        entries.append({"material": unit["material"], "paragraph_id": unit["paragraph_id"],
                        "page": unit.get("page"), "section": unit.get("section"),
                        "quote": unit["text"], "detail": "conflicting source",
                        "relation": "contradict"})
    return entries


def derive_verification(spec, corpus, units):
    cid = spec.get("claim_id") or "C"
    text = spec.get("claim_text") or ""
    parts = split_claims(text)
    subs, sub_verdicts, types, conflicts = [], [], [], []
    for idx, part in enumerate(parts, 1):
        sub_id = "%s.%d" % (cid, idx)
        ctype = classify(part)
        support, contra = evidence_scan(part, units)
        verdict, reason, conflict = _sub_verdict(ctype, support, contra)
        preserved = _preserved(part)
        evidence = _make_evidence(verdict, support, contra)
        for item in evidence:
            item["verbatim"] = bool(find_quote(corpus, str(item.get("quote") or "")))
        required = None
        if verdict == "insufficient_evidence":
            required = ("a source sentence that states the assertion (with comparator, "
                        "negation, significance and scope) or its negation; none was found "
                        "among %d scanned sentences in %d material(s)"
                        % (len(units), len({u["material"] for u in units})))
        rationale = ("%s; %d sentences scanned in %d material(s); preserved=%s"
                     % (reason, len(units), len({u["material"] for u in units}),
                        json.dumps(preserved, ensure_ascii=False)))
        subs.append({
            "sub_id": sub_id,
            "type": ctype,
            "text": part,
            "verdict": verdict,
            "evidence": evidence,
            "rationale": rationale,
            "conditions": (preserved.get("condition") or [None])[0] if preserved.get("condition") else spec.get("conditions"),
            "required_evidence": required,
            "negation_or_comparator_preserved": preserved,
            "sources_conflict": bool(conflict),
        })
        sub_verdicts.append(verdict)
        types.append(ctype)
        if conflict:
            conflicts.extend(_conflict_entries(support, contra))
    agg, agg_reason = aggregate_verdict(sub_verdicts, types)
    missing = ["%s: %s" % (sub["sub_id"], sub["required_evidence"])
               for sub in subs if sub["verdict"] == "insufficient_evidence"]
    return {
        "claim_id": cid,
        "claim_text": text,
        "verdict": agg,
        "aggregation_rule": AGGREGATION_RULE,
        "rationale": ("%s; derived deterministically (no agent draft) from keyword/number/"
                      "entity overlap, polarity and antonym reversal" % agg_reason),
        "conditions": spec.get("conditions"),
        "conflicts": conflicts,
        "missing_evidence": missing,
        "notes": "deterministic derivation (no agent draft); semantic nuances may need review",
        "derived": True,
        "sub_claims": subs,
    }


def derive_all(specs, corpus):
    units = build_units(corpus)
    verifications = []
    for spec in specs:
        verifications.append(derive_verification(spec, corpus, units))
    return verifications, {"uncertainties": [], "degradations": []}


def write_deliverables(out, work, doc, verifications, coverage, degradations,
                       corpus, status, specs, uncertainties, pkg_name, version):
    out, work = Path(out), Path(work)
    cards = []
    for ver in verifications:
        for sub in ver.get("sub_claims") or []:
            evidence = []
            for item in sub.get("evidence") or []:
                evidence.append({
                    "quote": item.get("quote"),
                    "material": item.get("material"),
                    "locator": item.get("locator"),
                    "paragraph_id": item.get("paragraph_id"),
                    "page": item.get("page"),
                    "section": item.get("section"),
                    "table_id": item.get("table_id"),
                    "row": item.get("row"),
                    "relation": item.get("relation"),
                    "verbatim": bool(item.get("verbatim")),
                })
            cards.append({
                "card_id": "%s.%s" % (ver.get("claim_id"), sub.get("sub_id") or "sub"),
                "claim_id": ver.get("claim_id"),
                "sub_claim_id": sub.get("sub_id"),
                "sub_claim": sub.get("text"),
                "sub_claim_type": sub.get("type"),
                "verdict": sub.get("verdict"),
                "evidence": evidence,
                "preserved": sub.get("negation_or_comparator_preserved"),
                "reasoning": sub.get("rationale"),
                "conditions": sub.get("conditions"),
                "sources_conflict": bool(sub.get("sources_conflict")),
            })
    try:
        with open(out / "evidence_cards.jsonl", "w", encoding="utf-8", newline="\n") as fh:
            for card in cards:
                fh.write(json.dumps(card, ensure_ascii=False) + "\n")
    except Exception as exc:
        degradations.append("evidence_cards.jsonl failed: %s" % exc)

    rows = [["claim_id", "claim_text", "subclaim_count", "types", "sub_verdicts", "verdict",
             "evidence_items", "conflicts", "missing_evidence", "rationale"]]
    for row in claim_rows(verifications):
        rows.append([row["claim_id"], row["claim_text"], row["subclaim_count"], row["types"],
                     row["sub_verdicts"], row["verdict"], row["evidence_items"],
                     row["conflicts"], row["missing_evidence"], row["rationale"]])
    try:
        with open(out / "verdict_summary.csv", "w", encoding="utf-8-sig", newline="") as fh:
            csv.writer(fh).writerows(rows)
    except Exception as exc:
        degradations.append("verdict_summary.csv failed: %s" % exc)

    report = ["# Evidence verification report", "",
              "- case_id: `%s`" % doc["case_id"], "- status: **%s**" % status,
              "- skill: %s v%s" % (pkg_name, version),
              "- materials scanned: %d | segments: %d | claims: %d"
              % (len(corpus["materials"]), len(corpus["segments"]), len(specs)),
              "- verdicts: supported=%d partially_supported=%d contradicted=%d "
              "insufficient_evidence=%d" % (
                  coverage["verdict_counts"]["supported"],
                  coverage["verdict_counts"]["partially_supported"],
                  coverage["verdict_counts"]["contradicted"],
                  coverage["verdict_counts"]["insufficient_evidence"]),
              "- sub-claim types: fact=%d comparison=%d causal=%d scope=%d" % (
                  coverage["subclaim_type_counts"]["fact"],
                  coverage["subclaim_type_counts"]["comparison"],
                  coverage["subclaim_type_counts"]["causal"],
                  coverage["subclaim_type_counts"]["scope"]), "",
              "## Claim verdicts", "",
              "| claim_id | verdict | sub-claims | evidence | claim |",
              "|---|---|---|---|---|"]
    for ver in verifications:
        claim_text = (ver.get("claim_text") or "").replace("|", "\\|")
        if len(claim_text) > 160:
            claim_text = claim_text[:157] + "..."
        report.append("| %s | %s | %d | %d | %s |" % (
            ver.get("claim_id"), ver.get("verdict"), len(ver.get("sub_claims") or []),
            sum(len(sub.get("evidence") or []) for sub in ver.get("sub_claims") or []),
            claim_text))
    report.append("")
    if uncertainties:
        report.append("## Uncertainties, conflicts and missing evidence")
        for item in uncertainties:
            report.append("- `%s` (%s): %s" % (item.get("claim_id") or item.get("kind"),
                                               item.get("kind"), item.get("detail")))
        report.append("")
    report.append("## Sub-claim detail")
    for ver in verifications:
        report.append("### %s -> %s" % (ver.get("claim_id"), ver.get("verdict")))
        if ver.get("rationale"):
            report.append("Rationale: %s" % ver.get("rationale"))
        for sub in ver.get("sub_claims") or []:
            report.append("- `%s` [%s] %s" % (sub.get("sub_id"), sub.get("type"),
                                               sub.get("verdict")))
            report.append("  - judgement: %s" % (sub.get("text") or ""))
            if sub.get("rationale"):
                report.append("  - why: %s" % sub.get("rationale"))
            for item in sub.get("evidence") or []:
                locator = "%s:%s" % (item.get("material") or "-",
                                     item.get("paragraph_id") or item.get("table_id") or "-")
                report.append("  - evidence (%s, %s): %s" % (
                    locator, item.get("relation"), (item.get("quote") or "")[:300]))
        report.append("")
    report.append("## Method notes")
    for key, value in doc["result"]["method_notes"].items():
        report.append("- %s: %s" % (key, value))
    report += ["", "## Degradations"]
    for item in degradations or ["none"]:
        report.append("- " + str(item))
    try:
        (out / "verification_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    except Exception as exc:
        degradations.append("verification_report.md failed: %s" % exc)

    jdump(work / "build_summary.json", {"case_id": doc["case_id"], "status": status,
                                        "coverage": coverage, "degradations": degradations})

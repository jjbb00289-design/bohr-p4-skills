---
name: evidence-verifier
description: Verify scientific audit claims against supplied literature. Split compound judgements into fact/comparison/causal/scope sub-claims, locate the minimal sufficient quotation for each, and assign supported / partially_supported / contradicted / insufficient_evidence without turning topic relevance into support. When no agent draft exists, build derives per-claim verdicts deterministically from the input. Use when claims, citations or manuscript statements must be traced to source evidence.
version: 2.0.0
---

# 文献证据溯源与事实核验（evidence-verifier）

把待核验的科研论断落到**可判定的最小证据**上：拆得开、找得到、判得准、说得清。
每条论断 → 子判断（事实/比较/因果/范围）→ 逐字引文 + 定位 → 四级支持度 → 判定理由。

## 1. 何时使用 / 何时不用

适用：
- 输入是"待核验论断清单"（`/input/claims-to-verify.json`）+ 一篇或多篇论文/材料。
- 任务要求核查论断能否被原文支持、部分支持、反对或材料不足，并给出可复核的证据位置。
- 需要区分"主题相关"与"真正支持"，并暴露冲突、范围限制与无法确定的部分。

不适用：替代原作者做实验结论、编造未给出的数据、把"未被研究"写成"被证伪"。

## 2. 硬性事实（先读，决定成败）

1. **待核验论断是问题，不是权威事实**：`claims-to-verify.json` 里的每个 claim 都可能为真、为假或无法判定；不得因为清单里写了就当作事实。
2. **契约运行时才知道**：`/input/case.json` 的 `output_contract` 每个键都必须原样出现在 `/app/output/result.json`；`build` 会逐键回填（缺值写 `null` 并记 `degradations`）。
3. **每条 claim 都要有判定**：请求几条就输出几条，不漏、不合并；`claim_id`、`claim_text` 与输入一致。
4. **四态闭环**：`supported` / `partially_supported` / `contradicted` / `insufficient_evidence`；初始骨架另有 `pending`（仅 init）。
5. **禁止编造证据**：引文必须逐字存在于材料；找不到证据时判 `insufficient_evidence` 并写清缺什么，不能硬凑。
6. **未支持的推断 ≠ 被实验证伪**：材料没研究的部分写 `insufficient_evidence`，只有原文明确相反才写 `contradicted`。

## 3. 五命令主路径（必须按顺序执行）

```bash
python3 scripts/main.py init      # 扫 /input：材料、段落、表格行 + 论断清单；先写 partial result.json
python3 scripts/main.py show      # 打印带 locator 的原文与论断清单（证据引文从这里逐字复制）
#   你现在必须亲自读材料，写 /app/work/draft.json（schema 见第 4 节）
python3 scripts/main.py check     # 机械校验：拆解、证据命中、四级判定与聚合一致性
python3 scripts/main.py build     # result.json + evidence_cards.jsonl + verdict_summary.csv + verification_report.md
python3 scripts/main.py selfcheck # 复查成品：契约键、case_id、证据复验、计数自洽
```

默认路径 `/input`、`/app/work`、`/app/output`；本地可加 `--input/--work/--output`。
**脚本不会代替你阅读与判断。能写工作稿时请先读材料再写 `/app/work/draft.json`；`check` 用它做机械校验。**
如果**没有可用工作稿**，`build` 会走确定性派生路径（见第 5 节末）：直接从 `/input` 拆解论断、逐句匹配证据并给出四级判定，产出可复核的 `evidence_cards.jsonl` 与 `result.json`，不再只是空骨架。派生结果在 `degradations` 中标注，语义细节建议人工复核。

## 4. 工作稿 schema：`/app/work/draft.json`

```json
{
  "case_id": "<与输入一致>",
  "verifications": [
    {
      "claim_id": "C01",
      "claim_text": "与输入论断逐字一致",
      "verdict": "supported | partially_supported | contradicted | insufficient_evidence",
      "rationale": "为什么这些子判断合起来给出该判定",
      "conditions": "判定成立的条件（人群/剂量/时间点/比较对象）",
      "missing_evidence": ["材料不足时缺什么"],
      "conflicts": [{"material": "...", "paragraph_id": "...", "quote": "...", "detail": "..."}],
      "sub_claims": [
        {
          "sub_id": "C01.1",
          "type": "fact | comparison | causal | scope",
          "text": "可独立核验的子判断",
          "verdict": "supported | partially_supported | contradicted | insufficient_evidence",
          "evidence": [
            {"material": "materials/trial.md", "paragraph_id": "P005", "section": "Results",
             "page": null, "table_id": null, "row": null,
             "quote": "逐字复制的完整句子，保留否定词/比较词/显著性/条件"}
          ],
          "rationale": "这段引文如何 entail / 不 entail 该子判断",
          "conditions": "该证据成立的条件",
          "required_evidence": "判 insufficient_evidence 时需要的证据类型"
        }
      ]
    }
  ],
  "uncertainties": [{"kind": "...", "detail": "..."}],
  "pending_human": []
}
```

规则：
- **拆解**：复合句拆成可独立核验的子判断；事实、比较、因果、范围各归其类，不遗漏也不重复核验。单一论断也至少 1 条子判断。
- **最小充分证据**：每条子判断给 1–2 条最短够用的引文；引文要包含**对比对象、否定词、显著性、条件/范围**，不能只截关键词。
- **四级判定与聚合**必须符合第 5 节规则；`check` 会用同一规则复算聚合判定，不一致即 FAIL。
- 冲突来源：`conflicts[]` 双方原话都保留，不要用一句结论掩盖。
- 无法由原文确定的部分写进 `missing_evidence` 或 `uncertainties`。

## 5. 四级判定定义与聚合规则

| 判定 | 含义 | 必要证据 |
|---|---|---|
| `supported` | 引文在完整上下文中蕴含该子判断（方向、量级、比较对象、显著性与范围都保留） | ≥1 条逐字定位引文 |
| `partially_supported` | 引文只支持论断的一部分：方向对但量级/显著性/比较对象/范围不同，或原文表述更弱 | ≥1 条逐字定位引文 |
| `contradicted` | 引文蕴含该子判断的否定（明确"无差异/相反方向/未发生"） | ≥1 条逐字定位引文，含否定或相反比较 |
| `insufficient_evidence` | 材料**不能判定**：未测量、未报告、超出样本范围、只有主题相关表述 | 写清缺什么（`required_evidence`/`missing_evidence`） |

**聚合规则（脚本强制复算）**：
1. 全部子判断 `supported` → `supported`；
2. 全部子判断 `contradicted`，或所有 fact/comparison 子判断均 `contradicted` 且无 `supported` → `contradicted`；
3. 存在 `contradicted` 但仍有 `supported`（混合证据）→ `partially_supported`；
4. 只有部分 `supported`/`partially_supported`（其余 partial/insufficient）→ `partially_supported`；
5. 全部 `insufficient_evidence` → `insufficient_evidence`。

**判定纪律**：
- 主题相关 ≠ 支持。原文提到某主题但没有对该论断的断言 → `insufficient_evidence`。
- 显著性词、否定词、比较对象、剂量、人群范围必须原样保留；"not significant" 不能读成 "significant"。
- 单篇小样本 ≠ 领域共识；动物/体外 ≠ 人体；"may/possibly/suggest" 是弱表述，不能升格为 `supported` 的强结论（可给 `partially_supported`）。
- 未研究 ≠ 被证伪："longer-term outcomes were not assessed" 是 `insufficient_evidence`，不是 `contradicted`。

## 5b. 确定性派生（`build` 无工作稿时的兜底路径）

当 `/app/work/draft.json` 缺失或无法解析时，`scripts/derive.py` 直接、确定性地从 `/input` 生成核验结果（同一输入两次运行字节级一致，无随机、无时间戳）：

1. **加载**：先读 `/input/claims-to-verify.json`，缺失时回退到 `case.json` 的 `claims`/`claims_to_verify`（与 `init` 同源）。
2. **拆解**：按句末标点与 `;` / `and` / `or` / `but` 拆复合论断，并为残缺子句回接主语，每条子判断标 `fact/comparison/causal/scope`。
3. **匹配**：以固定排序扫描全部材料段落，逐句做关键词/数字/实体重叠 + 极性（纯否定）与反义（如 multicenter↔single-center、decrease↔increase）判定，同时找**支持**与**反对**两类句子；引文就是原文句子的逐字子串，用 `verify_lib` 复用的 `find_quote` 现场校验。
4. **判定**：`supported` = 逐字蕴含该子判断；`partially_supported` = 只有部分子判断/更弱措辞/支持与反对并存；`contradicted` = 原文含否定或相反比较（保留否定词）；`insufficient_evidence` = 找不到可判定句——**这不是"contradicted"**。两来源冲突时双方定位与原话都保留，判 `partially_supported` 并写入 `conflicts`。
5. **产出**：`result.json` 的 `verifications`/`claims`/`coverage` 与四产物照常写出；`evidence_cards.jsonl` 每子判断一行，含 `evidence[]`（quote+locator+verbatim 标志）、保留的比较词/否定词/显著性/条件与推理。

派生是**有界启发式**（关键词/数字/实体 + 极性/反义词典），不等同于仔细阅读：无法分辨回指、机制推测与复杂语义时可能弱判或漏判；此时请写工作稿覆盖。`degradations` 会如实标注"deterministic derive"。

## 6. 证据与定位规则

1. 证据单位 = 段落或表格行；`locator` = `material` + (`paragraph_id` 或 `page` 或 `table_id`+`row`)。
2. 引文必须逐字来自 `show` 输出：不改写、不翻译、不拼接、不补省略号。
3. 引文长度以"够判定"为准：至少覆盖该子判断的主语、比较对象与结论词（含否定/显著性）。
4. 一个引文可服务多个子判断，但每条子判断的理由要各自写清。
5. 材料含多篇文献时，`material` 必须指向具体那一篇；不能用一个来源的证据支持另一篇的论断。
6. 图注、表格、补充材料同样可作证据，用 `section`/`table_id` 标注。

## 7. `check` 做什么、会拦什么

- 每个请求 `claim_id` 是否都有条目（漏 = FAIL）；重复/未请求 = FAIL/WARN。
- 聚合判定是否与子判断一致（按第 5 节规则复算；不一致 = FAIL）。
- `type` 是否在 `fact/comparison/causal/scope`；`verdict` 是否在四态。
- 每条证据的 `quote` 是否在材料中逐字命中（未命中 = FAIL）；声明的 `material` 是否真的包含该引文（不包含 = FAIL）。
- `supported/partially_supported/contradicted` 是否至少有 1 条定位证据（没有 = FAIL）。
- `contradicted` 引文是否带否定/相反比较（没有 = WARN）；`supported` 引文是否只是 hedge 表述（= WARN 建议降级）。
- 产出 `work/check_report.json`；`build` 以它为放行依据，并把证据校验失败的 `supported/partial/contradicted` 降级为 `insufficient_evidence`。

## 8. 产物（`/app/output/`）

| 文件 | 内容 |
|---|---|
| `result.json` | 契约回填 + `result.verifications[]` + `coverage`（判定/类型计数）+ `claims`（审计清单与判定）+ `uncertainties` + `sources` + `degradations` |
| `evidence_cards.jsonl` | 证据卡片，一行一张：claim/sub_claim/type/verdict/material/locator/quote/quote_verified/rationale |
| `verdict_summary.csv` | 每论断一行：子判断数、类型、子判定、聚合判定、证据数、冲突、缺失证据、理由 |
| `verification_report.md` | 人读报告：判定表、子判断明细、冲突/限制、方法说明、降级记录 |

## 9. 降级与异常处理

| 情况 | 行为 |
|---|---|
| 无 `draft.json` / 工作稿坏 | `build` 走**确定性派生**：逐 claim 拆解、逐句匹配材料、给出四级判定与逐字引文，`degradations` 标注"deterministic derive"；空论断清单时才是空骨架 |
| `case.json` 坏 / 空 `/input` | `status=input_error`，仍写合法 `result.json` 与契约键 |
| 只有 case.json、没有材料 | `status=insufficient_evidence`，不编造证据 |
| 论断清单缺失 | `degradations` 记录，`pending_human` 提示补 `claims-to-verify.json` |
| 证据互斥/来源冲突 | 双方 quote 都保留，判 `partially_supported` 或 `insufficient_evidence`，`conflicts` 写清 |
| PDF 无文本层 / 扫描件 | 记 `no_text_layer`，需要 OCR 的列入 `pending_human`，不猜读 |

所有命令退出码恒为 0；顶层异常触发 `emergency_finalize()` 写合法 partial 结果。

## 10. 提交前自检清单

- [ ] `init` 后 `/app/output/result.json` 已存在，契约键齐全，`case_id` 正确。
- [ ] 每条请求 claim 恰好一条；`pending` 已清零；`claim_text` 与输入一致。
- [ ] 每条证据 quote 都在材料中逐字命中；声明的 `material` 正确。
- [ ] `contradicted` 的引文真的含否定/相反比较；`insufficient_evidence` 写了缺什么。
- [ ] 聚合判定与子判断一致（`check` 无 FAIL）。
- [ ] 四个产物都存在且非空。
- [ ] 空输入 / 坏 JSON / 缺材料 / 无工作稿四种情况都 exit 0 且产出合法 partial 结果。

## 11. 最小调用示例（示例，非正式案例结果）

材料（`materials/trial.md`，节选）：

```
[P006] Fasting glucose did not differ significantly between groups (p = 0.42).
```

待核验论断：`Compound X reduces fasting glucose compared with placebo.` 工作稿写：

```json
{"claim_id": "C02", "claim_text": "Compound X reduces fasting glucose compared with placebo.",
 "verdict": "contradicted", "rationale": "the source reports no significant difference",
 "sub_claims": [{"sub_id": "C02.1", "type": "fact",
   "text": "Compound X reduces fasting glucose compared with placebo.",
   "verdict": "contradicted",
   "evidence": [{"material": "materials/trial.md", "paragraph_id": "P006",
                 "quote": "Fasting glucose did not differ significantly between groups (p = 0.42)."}],
   "rationale": "negation and p value preserved; the opposite of a reduction is stated"}]}
```

`build` 后 `result.verifications[0].verdict = contradicted`，证据卡片里保留该句与 `P006` 定位。
**以上为示例（合成数据），非任何正式案例结果。**

## 12. 版本与维护

- 版本：2.0.0；包名 `evidence-verifier`。
- 依赖：Python 3.8+ 标准库；不联网；不依赖 CWD；无第三方包。
- 修改指引：判定与聚合规则在 `scripts/verify_lib.py`（`aggregate_verdict/evaluate_subclaim`），材料解析在 `scripts/io_parse.py`，确定性派生在 `scripts/derive.py`（`derive_all/split_claims`），流程在 `scripts/main.py`；改完必须重跑 `--help`、`init`、`check`、`build`、无工作稿派生冒烟、负向对照与四态降级测试。
- 适用范围与限制：文本型 PDF/纯文本/Markdown/CSV 表格最佳；需要语义判断的部分由 Agent 完成（工作稿优先），无工作稿时由 `derive.py` 做有界启发式派生；扫描件需要 OCR。

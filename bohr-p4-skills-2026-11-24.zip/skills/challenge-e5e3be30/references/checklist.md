# 证据核验质检清单与失败模式

本文件用于 `check` 前的自检与复核他人的核验结果。每条都是可执行动作或可机械判定的检查。

## 1. 拆解检查（拆得开）

1. 复合论断是否拆成可独立核验的子判断？例："安全且长期有效、适用于所有成人" → 安全性事实 + 疗效比较 + 长期范围 + 人群范围，四类各自判定。
2. 子判断是否**既不遗漏也不重复**？同一事实不要拆成两条同义判断。
3. 每条子判断是否标注了 `fact/comparison/causal/scope` 类型？类型决定它需要什么证据。
4. 因果子判断（"X 通过 Y 起作用"）是否有直接机制证据，还是只有相关/推测？

## 2. 证据检查（找得到）

1. 引文是否**逐字**来自原材料？翻译、改写、拼接、省略号都算不合格。
2. 引文是否包含**比较对象、否定词、显著性、剂量/人群/时间范围**？只截关键词会翻转语义。
3. `material` 是否指向真正包含该句的那一篇/那一节？多文档时尤其容易串。
4. 定位粒度是否到段落/表行（`P005`、`T1:R2`、`page 4`）？只给篇名不算可复核。
5. 同一论断的多个子判断是否用了**最小充分**证据，而不是堆整段？

## 3. 判定检查（判得准）

| 情形 | 正确判定 | 常见错误 |
|---|---|---|
| 原文明确报告方向、量级、比较对象、显著性，且与论断一致 | `supported` | 漏看比较对象不同就判 supported |
| 原文方向一致但量级/显著性/人群/剂量不同，或原文更弱（may/suggest） | `partially_supported` | 升格为 supported |
| 原文明确"无差异/相反方向/未发生" | `contradicted` | 判成 insufficient（把"无差异"当"没研究"） |
| 原文没测量、没报告该对象，或只与主题相关 | `insufficient_evidence` | 判成 contradicted（把"未研究"当"证伪"） |
| 原文有冲突的两处表述 | 保留双方 + `partially_supported`/`insufficient_evidence` | 只取一方、取平均 |
| 单篇小样本、体外/动物研究 | 降级或限定范围 | 写成领域共识 |

## 4. 聚合检查（说得清）

1. 聚合判定是否严格按规则复算？`check` 会复算，不一致直接 FAIL。
2. `rationale` 是否解释了"为什么这些子判断合起来是这个判定"，而不是复述结论？
3. `missing_evidence` 是否写清"缺什么证据才能升级判定"？
4. 冲突来源是否并列双方原话（`conflicts[]`），而不是被一句结论掩盖？
5. `conditions` 是否写出了判定成立的人群/剂量/时间点/比较对象？

## 5. 高频失败模式（出现即返工）

| 失败模式 | 表现 | 修法 |
|---|---|---|
| 主题相关当支持 | 原文提到该主题但无对应断言 | 改 `insufficient_evidence` |
| 否定翻转 | "not significant" → 判 supported | 保留否定，改 contradicted/partial |
| 范围蔓延 | 12 周试验 → 判"长期有效" | 拆 scope 子判断，判 insufficient |
| 未研究当证伪 | "not assessed" → contradicted | 改 insufficient_evidence |
| 比较对象错配 | 组内变化 → 判"优于对照" | 拆 comparison 子判断，看组间检验 |
| 聚合不一致 | 子判断两 supported 聚合却写 partially | 按规则改聚合 |
| 证据裁剪 | 引文只留结论词 | 补齐主语/比较/否定/显著性 |
| 多文档串源 | A 文证据支持 B 文论断 | 按 `material` 逐篇核对 |
| 缺字段省略 | 请求 6 条只交 4 条 | 缺的也要有条目（insufficient_evidence） |
| 编造证据 | 引文在材料中不存在 | 从 `show` 输出逐字复制或改判 insufficient |

## 6. 复核他人的核验（第二人视角）

1. 抽 2 条 `supported`：翻原文确认引文逐字、比较对象一致、无否定翻转。
2. 抽 1 条 `contradicted`：确认引文确实含否定/相反比较，不是"未研究"。
3. 抽 1 条 `insufficient_evidence`：确认材料确实不能判定，且写清了缺什么。
4. 检查 `coverage.verdict_counts` 合计是否等于 `verifications` 行数、`missing_claim_ids` 是否为空。
5. 检查 `uncertainties`/`conflicts` 是否把限制说清，而不是用 `ok` 掩盖。

## 7. 提交前命令级检查

```bash
python3 scripts/main.py check && python3 scripts/main.py build && python3 scripts/main.py selfcheck
```

期望：`check` 无 FAIL；`build` 四个产物非空、`status` 与实情一致；`selfcheck` 契约键零缺失、证据全部复验通过。
无 `work/draft.json` 时，`build` 会走 `scripts/derive.py` 的确定性派生（`result.json` 的 `degradations` 应出现 "deterministic derive"），冒烟校验：一条 `supported`（有逐字引文）、一条 `contradicted`（引文含否定/相反比较）、一条 `insufficient_evidence`（无引文且**不是** contradicted）。

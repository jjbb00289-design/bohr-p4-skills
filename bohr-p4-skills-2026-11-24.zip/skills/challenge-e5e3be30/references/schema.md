# 核验 schema 与契约回填细则

本文件是 `SKILL.md` 第 4–6 节的字段级补充。字段名与枚举以本文为准，脚本与文档必须一致。

## 1. 输入侧文件

| 文件 | 必需 | 说明 |
|---|---|---|
| `/input/case.json` | 通常有 | 至少含 `case_id` 与 `output_contract`；可能内嵌 `claims_to_verify` |
| `/input/claims-to-verify.json` | 视案例 | 待核验论断。接受 `{claims:[...]}`、直接数组、或 `claims_to_verify/items` 键；`claim_id` 也可写成 `id/key`，正文可写成 `claim/text/question/statement` |
| 材料 | 是 | 论文 PDF / MD / TXT / CSV 表格 / XML；图片需 OCR，脚本不猜读 |
| `/input/task.md` | 是 | 任务说明，不作为证据来源 |

**待核验论断是问题，不是事实**：清单里的措辞可能夸大、错误或无法判定；`init` 只把它们放进 `work/index.json` 的 `claims`，不会当作材料。

## 2. 输出侧 `result.json`

```text
result.json
├─ case_id            原样，必须与输入一致
├─ status             ok | partial | insufficient_evidence | input_error
├─ result
│  ├─ verifications[] 每条 = 一个 claim_id 的核验结果（见下）
│  ├─ coverage        claims_requested / claims_verified / verdict_counts /
│  │                  subclaim_type_counts / subclaim_total / evidence_items /
│  │                  claims_with_conflict / pending_claims / missing_claim_ids / complete
│  ├─ verdict_definitions 四级判定定义（含 pending）
│  ├─ aggregation_rule    第 5 节聚合规则原文
│  └─ method_notes        流程、证据单位、quote 匹配口径
├─ claims[]           审计清单视图：claim_id / claim_text / verdict / subclaim_count / evidence_count
├─ uncertainties[]    insufficient_evidence、冲突、范围限制
├─ sources[]          材料清单（material/kind/bytes/sha256/text_method/segments/tables）
├─ pending_human[]    需人工确认或补料的事项
├─ errors[] / degradations[]
├─ deliverables       产物相对路径
└─ contract_fill      契约类型、请求键、被回填为 null 的键
```

### 2.1 `verifications[]` 单条结构

| 键 | 类型 | 要求 |
|---|---|---|
| `claim_id` | str | 与输入清单一致 |
| `claim_text` | str | 与输入论断逐字一致（允许原样复制，不改写） |
| `sub_claims` | array | ≥1 条；复合论断必须拆开 |
| `verdict` | enum | 四级之一；必须等于按第 5 节规则复算的结果 |
| `aggregation_rule` | str | 默认写入文档化规则 |
| `rationale` | str | 为什么这些子判断合起来给出该判定 |
| `conditions` | str | 判定成立的条件（人群/剂量/时间点/比较对象） |
| `conflicts` | array | 冲突来源：每项含 `material/paragraph_id/quote/detail` |
| `missing_evidence` | array | 材料不足时缺什么 |
| `notes` | str | 降级原因、人工接管点 |

### 2.2 `sub_claims[]` 单条结构

| 键 | 类型 | 要求 |
|---|---|---|
| `sub_id` | str | 建议 `<claim_id>.<n>` |
| `type` | enum | `fact` / `comparison` / `causal` / `scope` |
| `text` | str | 可独立核验的判断句 |
| `verdict` | enum | 四级之一 |
| `evidence` | array | 每条含 `material` + `locator`（`paragraph_id`/`page`/`table_id`+`row`）+ `quote` |
| `rationale` | str | 引文如何 entail / 不 entail |
| `conditions` | str | 该证据成立的条件 |
| `required_evidence` | str | `insufficient_evidence` 时需要的证据类型 |

## 3. 证据卡片 `evidence_cards.jsonl`

一行一个 JSON 对象（UTF-8，无 BOM），**每个子判断一行**，证据嵌在 `evidence[]` 内：

```json
{"card_id": "C02.C02.1", "claim_id": "C02", "sub_claim_id": "C02.1",
 "sub_claim": "Compound X reduces fasting glucose compared with placebo.",
 "sub_claim_type": "fact", "verdict": "contradicted",
 "evidence": [{"quote": "Fasting glucose did not differ significantly between groups (p = 0.42).",
   "material": "materials/trial.md",
   "locator": {"paragraph_id": "P006"}, "paragraph_id": "P006",
   "page": null, "section": "Results", "table_id": null, "row": null,
   "relation": "contradict", "verbatim": true}],
 "preserved": {"negation": null, "comparator": ["compared with"],
   "significance": null, "condition": null},
 "reasoning": "the material states the opposite of the sub-claim; ...",
 "conditions": "", "sources_conflict": false}
```

`verbatim` 由 `build` 现场用 `find_quote` 复验后写入，不是 Agent 自报。
无工作稿时由 `scripts/derive.py` 生成同样结构的卡片（`reasoning` 含"deterministic derive"说明），`insufficient_evidence` 子判断的 `evidence` 为空数组。

## 4. 覆盖计数口径

- `claims_requested`：论断清单条数。
- `claims_verified`：有明确四级判定的条数（不含 `pending`）。
- `verdict_counts`：四态各自计数，合计 = `verifications` 行数。
- `subclaim_type_counts`：四类型子判断计数，`subclaim_total` = 合计。
- `evidence_items`：所有证据条目数（含未命中的？不含——只计写入的定位条目）。
- `claims_with_conflict`：带 `conflicts` 的论断数。
- `missing_claim_ids`：清单里有、结果里没有的 `claim_id`。
- `complete`：清单非空、无缺失、无 `pending`。

## 5. 契约回填（`echo_contract`）

1. 支持 dict 与 list 两种 `output_contract`；list 元素可为字符串或带 `key/name/claim_id` 的条目。
2. 精确匹配：先顶层，再 `result` 内部，再别名表（`verifications→result.verifications`、`verdicts→result.coverage.verdict_counts`、`evidence_cards→根 evidence_cards` 等）。
3. 找不到写 `null` 并记 `degradations`；`contract_fill` 记录回填结果。
4. `case_id`、`status` 永不省略，`status` 与实情一致。

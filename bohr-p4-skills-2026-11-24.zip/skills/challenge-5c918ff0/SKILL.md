---
name: multi-db-literature-search
description: 多数据库联合文献检索。对本地 Crossref/EuropePMC/出版社响应、引用图与增量导入状态做查询编排、字段归一、去重、合并、相关性排序与来源回溯，产出可逐条复核的联合候选集。用于科研文献检索筛选任务，尤其是已有多个学术库原始响应、需要可靠去重合并与覆盖说明的场景。
version: 1.0.0
---

# multi-db-literature-search

## 用途

把多个学术数据库的**本地原始响应**（Crossref / EuropePMC / 出版社 / 其他）连同引用图、组织方增量导入状态，归并成一份**不重复、字段可用、可逐条回溯**的联合候选文献集，并保留筛选依据。核心是解决基础 Agent 直接拼接多库响应造成的重复记录、字段写法不一致、来源无法核对、覆盖盲区被静默吞掉的问题。

## 触发条件

- 任务要求"检索并筛选文献"，且输入目录 `/input` 内有多个来源的检索响应、引用图或导入状态文件（JSON / XML / CSV / 文本 / 少量 PDF）。
- 需要去重、合并、按相关性排序，并要求每条结果可追溯到来源库与原始响应字段。
- 不适用于：需要实时联网检索最新文献、需要绕过多库服务限制、或需要单库全文阅读的场景。

## 调用方式

入口为 `scripts/main.py`，纯 Python 标准库，不联网，不依赖当前工作目录（脚本用 `Path(__file__).resolve().parent` 定位自身与 `references/`）。

```text
python scripts/main.py                 # 默认：完整流程（从 /input 真实派生全部交付）
python scripts/main.py check           # 运行自检，输出 PASS/FAIL
python scripts/main.py build           # 同默认：完整流程
python scripts/main.py --help
```

目录覆盖（本地测试用），默认值为平台路径：

```text
INPUT_DIR 或 --input   默认 /input
WORK_DIR  或 --work    默认 /app/work
OUTPUT_DIR 或 --output 默认 /app/output
```

环境变量优先级高于命令行参数。

## 输入

- `/input/case.json`：含 `case_id`、`output_contract`、任务说明字段。
- `/input/task.md`：题面（可选，用于补充研究问题）。
- `/input` 及**所有子目录**内的材料文件（递归 `os.walk`，不只顶层）：Crossref / EuropePMC / publisher 响应、reference graph、增量导入状态等。PDF 无预抽文本层时按真实文件解析。

## 输出（写入 OUTPUT_DIR）

- `result.json`：主交付。顶层回填 `case.json` 中 `output_contract` 的每个字段（键名不变），并附加 `case_id`、`status`、`sources`、`uncertainty`、`change_records`、`errors`、`degradations`。缺值用 `null`/`[]`，不漏键、不改名。
- `merged_records.json`：机器可读的合并候选集（与 result.json 中候选一致）。

## 工作稿 schema（写入 WORK_DIR）

- `partial_result.json`：流程开始时先落盘的合法 partial，随后被 finalize 覆盖到 `result.json`。
- `state.json`：完整中间状态（原始记录、去重分组、合并结果、覆盖分析、降级记录）。

## 统一记录 schema（合并后）

```json
{
  "record_id": "md5(规范化身份键)",
  "title": "…", "authors": ["…"], "year": 2020, "venue": "…",
  "doi": "10.…", "identifiers": {"doi": "…", "pmid": "…", "pmcid": "…", "source_id": "…"},
  "type": "journal-article", "abstract": "…", "url": "…",
  "volume": "…", "issue": "…", "pages": "…", "citation_count": 0,
  "rank": 1, "relevance_score": 3.0, "matched_terms": ["…"],
  "field_sources": {"title": {"db": "crossref", "file": "…", "locator": "…", "quote": "…"}, "…": "…"},
  "contributing_sources": [{"db": "crossref", "file": "…", "locator": "…"}],
  "conflicts": [{"field": "year", "values": [2020, 2019], "resolved": 2020, "rule": "…"}]
}
```

## 证据规范（真实派生红线）

- 每条记录、每个字段都必须能指回 `db`（来源库）+ `file`（相对 `/input` 的路径）+ `locator`（文件内字段路径）+ 逐字 `quote`。
- `quote` 从解析出的结构化字段取**原文值**，并要求其在对应材料文件原文中命中（空白归一后子串匹配）；未命中标记 `verified=false` 并说明为"结构化字段取值"。
- 命中证据同时给出 `query 词` 与材料中的逐字片段（以标题/摘要的原文片段为准）。
- 不编造 DOI、作者、年份、期刊、引用数、全文或"实时/最新"状态；材料没有的元数据显式标为缺失。

## 去重与合并规则

1. 精确：规范化 DOI（小写、去空白）相同 → 同一论文。
2. 模糊：规范化标题相同，且年份相同（双方均有时），且第一作者姓氏相同（双方均有时，缺失一方放行）→ 同一论文。
3. 合并字段优先级（可由 `references/field_mapping.json` 覆盖）：`doi/标识符` 取并集；`title/authors/year/venue/abstract/type` 按 来源优先级 取最完整者；`authors` 取并集并按规范化去重。
4. 冲突显式记录到 `conflicts`，给出冲突值、裁决值与规则；同分并入不可裁决时标 `conflict` 保留人工仲裁入口。

## 相关性排序

- 从研究问题拆解出查询词（含同义词、缩写、跨语言扩展），对标题、摘要、期刊做词命中加权打分：标题 +3、摘要 +1、期刊 +0.5。
- 按分数降序、分数相同按 `record_id` 升序（确定性排序）。无白板相关性标注时不编造 nDCG；仅在结果中说明 Precision@k / nDCG 的适用思路与排序函数，供复算。

## 降级表

| 情况 | status | 处置 |
|-|-|-|
| 正常完成，有记录 | complete | 全部交付 |
| 材料部分缺失/解析部分失败，仍有部分记录 | partial | 交付已有结果，`degradations` 写明缺口 |
| 有材料但无任何可提取记录 | insufficient_evidence | 合法 partial，`gaps` 写明原因 |
| 空输入（无 case.json） | input_error | 合法 partial，`errors` 写明 |
| case.json 坏 JSON / 无 output_contract | input_error | 合法 partial，不崩 |
| 某文件不可读 / 编码异常 / 结构未知 | partial | 该源记入 `degradations`，其余继续 |
| 某库完全缺失 | partial/insufficient_evidence | `coverage` 显式列出缺失库，不静默吞掉 |

所有异常都被捕获并写入 `errors`/`degradations`；主脚本退出码恒为 0。

## 自检

- 两个全新 OUTPUT_DIR 各跑一次，产物结构一致（无时间戳/随机，确定性排序）。
- `result.json` 合法 JSON；`output_contract` 每个键都出现，键名与原 contract 一致，且含 `case_id/status/sources/uncertainty/change_records`。
- 材料发现用递归扫描；quote 命中率 ≥ 0.95。
- `python scripts/main.py --help`、空输入、坏 JSON、缺材料四种场景全部退出码 0，且产出合法 partial。

## 限制

- 不实时联网，不做"最新文献/实时覆盖"声明；一切结论以本地材料为界。
- 不负责绕过服务限制、不做单库全文阅读、不把未授权数据汇总到未批准服务。
- 解析器是宽容式抽取，对未知私有 schema 可能只抽到部分字段；此类情况一律显式降级而非猜测补齐。

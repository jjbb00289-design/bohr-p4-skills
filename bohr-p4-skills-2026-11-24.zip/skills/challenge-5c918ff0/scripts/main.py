#!/usr/bin/env python3
"""Entrypoint (stdlib)."""
import argparse, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from core import FIELD_NAMES, STOP, Parser, canon_key, first_year, md5, norm_identifier, norm_key, norm_title, text_of


def parse_all(parser, files):
    recs, graphs, imports, degs = [], [], [], []
    for f in files:
        try:
            r, g, im, d = parser.parse_file(f)
        except Exception as e:
            r, g, im, d = [], {}, {}, [{"file": f.get("rel", "?"), "issue": "parse_exception", "detail": str(e)[:160]}]
        recs.extend(r)
        if g:
            graphs.append(g)
        if im:
            imports.append(im)
        degs.extend(d)
    return recs, graphs, imports, degs


def records_from_graphs(graphs):
    recs = []
    for g in graphs:
        for n in g.get("nodes", []):
            if not isinstance(n, dict):
                continue
            f = {}
            t = norm_title(text_of(n.get("label") or n.get("title") or n.get("name")))
            d = norm_identifier(text_of(n.get("doi") or n.get("id") or n.get("key") or n.get("node_id")))
            if t:
                f["title"] = t
            if d:
                f["doi"] = d
            y = first_year(n.get("year") or n.get("pubyear") or n.get("date"))
            if y:
                f["year"] = y
            if f:
                recs.append({"fields": f, "provenance": {}, "source": {"db": "reference_graph", "file": g.get("_file", "reference_graph"), "locator": "graph_node"}})
    return recs


def id_tuple(rec):
    f = rec["fields"]
    au = (f.get("authors") or [""])[0].split()
    fa = norm_key(au[-1]) if au else ""
    return (norm_identifier(f.get("doi", "")), norm_key(f.get("title", "")), str(f.get("year") or ""), fa)


def same_paper(a, b):
    if a[0] and b[0] and a[0] == b[0]:
        return True
    if a[0] and b[0] and a[0] != b[0]:
        # Exact title does not justify merging two conflicting persistent IDs.
        return False
    if not a[1] or not b[1] or a[1] != b[1]:
        return False
    if a[2] and b[2] and a[2] != b[2]:
        return False
    if a[3] and b[3] and a[3] != b[3]:
        return False
    return True


def dedup(records):
    order = sorted(records, key=lambda r: id_tuple(r) + (r["source"].get("db", ""), r["source"].get("file", "")))
    clusters = []
    for r in order:
        for c in clusters:
            if same_paper(id_tuple(r), id_tuple(c[0])):
                c.append(r)
                break
        else:
            clusters.append([r])
    return clusters


def merge_cluster(cluster, priority):
    m = {"fields": {}, "field_sources": {}, "contributing_sources": [], "conflicts": []}
    ids = {}
    for r in cluster:
        for k, v in (r["fields"].get("identifiers") or {}).items():
            if v:
                ids.setdefault(k, v)
    if ids:
        m["fields"]["identifiers"] = ids
    for fn in ["title", "year", "venue", "doi", "abstract", "type", "volume", "issue", "pages", "url"]:
        cands = [(priority.get(canon_key(r["source"].get("db", "")), 50), len(str(r["fields"].get(fn))), r["fields"].get(fn), r)
                 for r in cluster if r["fields"].get(fn) not in (None, "", [])]
        if not cands:
            continue
        cands.sort(key=lambda c: (-c[0], -c[1]))
        m["fields"][fn] = cands[0][2]
        pv = cands[0][3].get("provenance", {}).get(fn)
        if pv:
            m["field_sources"][fn] = pv
        if len({str(c[2]) for c in cands}) > 1:
            m["conflicts"].append({"field": fn, "values": sorted({str(c[2]) for c in cands}), "resolved": cands[0][2], "rule": "priority_then_longest"})
    au, ap = [], None
    for r in cluster:
        for a in (r["fields"].get("authors") or []):
            if norm_key(a) and norm_key(a) not in [norm_key(x) for x in au]:
                au.append(a)
                ap = ap or r.get("provenance", {}).get("authors")
    if au:
        m["fields"]["authors"] = au
        if ap:
            m["field_sources"]["authors"] = ap
    for s in sorted({(r["source"].get("file", ""), r["source"].get("locator", ""), r["source"].get("db", "")) for r in cluster}):
        m["contributing_sources"].append({"file": s[0], "locator": s[1], "db": s[2]})
    return m


def extract_question(case):
    if not isinstance(case, dict):
        return ""
    for k in ("task_instruction", "instruction", "task", "question", "research_question", "query", "goal", "prompt", "user_prompt", "request"):
        v = case.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return ""


def tokenize_terms(text, expand):
    terms = list(dict.fromkeys(re.findall(r'"([^"]{3,80})"', text)))
    for w in re.findall(r"[A-Za-z][A-Za-z0-9\-]{2,}|[\u4e00-\u9fff]{2,}", text.lower()):
        if w not in STOP and not w.replace("-", "").isdigit() and w not in terms:
            terms.append(w)
    out = list(terms)
    for t in terms:
        out += [e for e in expand.get(canon_key(t), []) if e and e.lower() not in [x.lower() for x in out]]
    nt = norm_key(text)
    for ck, syns in expand.items():
        if ck in nt:
            out += [e for e in syns if e and e.lower() not in [x.lower() for x in out]]
    return out


def build_query_plan(question, expand, record_count):
    terms = tokenize_terms(question, expand)
    joined = " ".join(terms[:8])
    queries = [{"db": d, "syntax": s, "terms": list(terms), "note": "local-only"}
               for d, s in (("crossref", "query.bibliographic=" + joined), ("europepmc", "query=" + joined),
                            ("pubmed", "term=" + joined), ("publisher", "publisher_query=" + joined))]
    queries[-1]["hit_count"] = record_count
    return {"research_question": question, "concepts": [{"term": t, "synonyms": expand.get(canon_key(t), [])} for t in terms],
            "queries": queries, "no_hit_queries": [],
            "method": "source-bound; local scoring"}, terms


def relevance_score(fields, terms):
    ti, ab, ve = norm_key(fields.get("title", "")), norm_key(fields.get("abstract", "")), norm_key(fields.get("venue", ""))
    score, matched = 0.0, []
    for t in terms:
        tk = norm_key(t)
        if not tk or len(tk) < 3:
            continue
        hit = 3.0 if tk in ti else 1.0 if tk in ab else 0.5 if tk in ve else 0.0
        if hit:
            score += hit
            matched.append(t)
    return score, matched


def rank(merged_records, terms):
    out = []
    for m in merged_records:
        s, mt = relevance_score(m["fields"], terms)
        out.append((s, mt, m))
    out.sort(key=lambda x: (-x[0], md5(json.dumps(x[2]["fields"], sort_keys=True, ensure_ascii=False, default=str))))
    return out


def build_coverage(all_records, merged_records, imports, files, degradations):
    per_db = {}
    gf = {fn: 0 for fn in FIELD_NAMES}
    for r in all_records:
        db = canon_key(r["source"].get("db", ""))
        d = per_db.setdefault(db, {"records": 0, "files": set()})
        d["records"] += 1
        d["files"].add(r["source"].get("file", ""))
        for fn in FIELD_NAMES:
            if r["fields"].get(fn):
                gf[fn] += 1
    for d in per_db.values():
        d["files"] = sorted(d["files"])
    missing = [e for e in ("crossref", "europepmc", "pubmed", "publisher") if e not in per_db]
    total = len(all_records) or 1
    return {"sources": per_db, "total_raw_records": len(all_records), "total_merged_records": len(merged_records),
            "duplicates_removed": len(all_records) - len(merged_records), "missing_sources": missing,
            "systematic_field_gaps": [fn for fn, c in gf.items() if c == 0],
            "global_field_coverage": {fn: round(gf[fn] / float(total), 3) for fn in FIELD_NAMES},
            "material_file_count": len(files), "import_states": imports, "degradations": degradations}


def build_sources(all_records):
    agg = {}
    for r in all_records:
        k = (r["source"].get("file", "?"), r["source"].get("db", "?"))
        d = agg.setdefault(k, {"file": k[0], "db": k[1], "record_count": 0})
        d["record_count"] += 1
    return sorted(agg.values(), key=lambda x: (x["file"], x["db"]))


def canonical_group(name):
    ck = canon_key(name)
    for grp, keys in (("candidates", "candidate literat record result paper hit merge"),
                      ("query_plan", "plan quer strateg expans retriev"),
                      ("dedup", "dedup duplicat"),
                      ("coverage", "cover databas sourcecomp sourcedist"),
                      ("gaps", "gap miss omis limit absent uncover"),
                      ("research_question", "question topic pico goal object research"),
                      ("ranking", "rank sort scor order"),
                      ("sources", "source proven evidence")):
        if any(k in ck for k in keys.split()):
            return grp
    return None


def contract_field_names(contract):
    names = []
    if isinstance(contract, dict):
        props = contract.get("properties")
        names = list(props.keys()) if isinstance(props, dict) and props else list(contract.keys())
    elif isinstance(contract, list):
        for x in contract:
            if isinstance(x, str):
                names.append(x)
            elif isinstance(x, dict):
                n = x.get("name") or x.get("field") or x.get("key") or x.get("id")
                if n:
                    names.append(str(n))
    elif isinstance(contract, str) and contract.strip():
        names = [contract]
    return names


def count_unverified(candidates):
    return sum(1 for c in candidates for fs in c.get("field_sources", {}).values()
               if isinstance(fs, dict) and fs.get("quote") and not fs.get("verified"))


def build_payload(case, parser, files):
    question = extract_question(case)
    all_recs, graphs, imports, degradations = parse_all(parser, files)
    graph_recs = records_from_graphs(graphs)
    all_recs = all_recs + graph_recs
    plan, terms = build_query_plan(question, parser.expand, len(all_recs))
    clusters = dedup(all_recs)
    merged = [merge_cluster(c, parser.priority) for c in clusters]
    candidates = []
    for i, (score, matched, m) in enumerate(rank(merged, terms), 1):
        rid = md5("|".join([norm_identifier(m["fields"].get("doi", "")), norm_key(m["fields"].get("title", "")), str(m["fields"].get("year"))]))
        cand = {"record_id": rid, "rank": i, "relevance_score": round(score, 3), "matched_terms": matched}
        cand.update(m["fields"])
        cand["field_sources"] = m["field_sources"]
        cand["contributing_sources"] = m["contributing_sources"]
        cand["conflicts"] = m["conflicts"]
        candidates.append(cand)
    coverage = build_coverage(all_recs, merged, imports, files, degradations)
    hit_terms = {t for c in candidates for t in c["matched_terms"]}
    no_hit = [t for t in terms if t not in hit_terms]
    plan["no_hit_queries"] = [{"term": t, "note": "no local hit"} for t in no_hit]
    gaps = [{"type": "missing_source", "source": s} for s in coverage["missing_sources"]]
    gaps += [{"type": "systematic_field_gap", "field": f} for f in coverage["systematic_field_gaps"]]
    gaps += [{"type": "no_hit_term", "term": t} for t in no_hit]
    sources = build_sources(all_recs)
    nconf = sum(len(c.get("conflicts", [])) for c in candidates)
    payload = {"candidates": candidates, "query_plan": plan,
               "dedup": {"raw_record_count": len(all_recs), "merged_record_count": len(merged),
                         "duplicates_removed": len(all_recs) - len(merged), "clusters": len(clusters),
                         "method": "DOI exact + fuzzy title/year/author"},
               "coverage": coverage, "gaps": gaps, "research_question": question,
               "ranking": {"function": "title+3/abstract+1/venue+0.5, ties by record_id",
                           "precision_note": "nDCG/Precision@k not computed (no labels)", "k": min(10, len(candidates))},
               "sources": sources}
    uncertainty = {"unverified_quotes": count_unverified(candidates), "conflict_fields": nconf,
                   "missing_sources": coverage["missing_sources"],
                   "systematic_field_gaps": coverage["systematic_field_gaps"],
                   "note": "gaps/provenance explicit in field_sources/conflicts"}
    change_records = [
        {"step": "discover", "detail": "%d material files" % len(files)},
        {"step": "parse", "detail": "%d raw records (%d responses + %d graph), %d degradations" % (len(all_recs), len(all_recs) - len(graph_recs), len(graph_recs), len(degradations))},
        {"step": "dedup_merge", "detail": "%d merged, %d removed, %d conflicts" % (len(merged), len(all_recs) - len(merged), nconf)},
        {"step": "rank", "detail": "%d candidates ranked" % len(candidates)}]
    return payload, sources, uncertainty, change_records, degradations, all_recs, merged, candidates


def build_result(case, payload, sources, uncertainty, change_records, errors, degradations, status):
    result = {"case_id": case.get("case_id") if isinstance(case, dict) else None}
    for n in contract_field_names(case.get("output_contract") if isinstance(case, dict) else None):
        result[n] = payload.get(canonical_group(n)) if canonical_group(n) else None
    result["status"] = status
    result["sources"] = sources
    result["uncertainty"] = uncertainty
    result["change_records"] = change_records
    result["errors"] = errors
    result["degradations"] = degradations
    return result


def empty_contract_result(case, status, errors, degradations, message):
    result = {"case_id": case.get("case_id") if isinstance(case, dict) else None}
    for n in contract_field_names(case.get("output_contract") if isinstance(case, dict) else None):
        result[n] = None
    result["status"] = status
    result["sources"] = []
    result["uncertainty"] = {"note": message}
    result["change_records"] = [{"step": "abort", "detail": message}]
    result["errors"] = errors
    result["degradations"] = degradations
    return result


# ------------------------------ CLI ------------------------------
def resolve_dirs(args):
    return (args.input_dir or os.environ.get("INPUT_DIR") or "/input",
            args.work_dir or os.environ.get("WORK_DIR") or "/app/work",
            args.output_dir or os.environ.get("OUTPUT_DIR") or "/app/output")


def ensure_dirs(ws, out):
    for d in (ws, out):
        try:
            os.makedirs(d, exist_ok=True)
        except OSError:
            pass


def load_case(inp):
    p = os.path.join(inp, "case.json")
    if not os.path.isfile(p):
        return None, [{"issue": "missing_case_json", "detail": p}]
    try:
        with open(p, "r", encoding="utf-8-sig") as f:
            return json.load(f), []
    except Exception as e:
        return None, [{"issue": "bad_case_json", "detail": str(e)[:200]}]


def load_task(inp):
    p = os.path.join(inp, "task.md")
    if os.path.isfile(p):
        try:
            with open(p, "r", encoding="utf-8-sig") as f:
                return f.read()
        except OSError:
            return ""
    return ""


def wj(path, obj):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


def do_check(inp, ws, out):
    parser = Parser(os.path.abspath(os.path.join(HERE, "..", "references")))
    case, errs = load_case(inp)
    files = parser.discover(inp)
    recs = parse_all(parser, files)[0] if files else []
    ok = case is not None and bool(files)
    print("PASS case.json" if case is not None else "FAIL case.json")
    print("PASS materials=%d" % len(files))
    print("PASS records=%d" % len(recs))
    print("OVERALL %s" % ("PASS" if ok else "FAIL"))


def build(inp, ws, out):
    ensure_dirs(ws, out)
    case, errs = load_case(inp)
    r = empty_contract_result({}, "input_error", errs, [], "case.json missing or corrupt") if case is None \
        else empty_contract_result(case, "partial", [], [], "pipeline started")
    wj(os.path.join(ws, "partial_result.json"), r)
    wj(os.path.join(out, "result.json"), r)
    if case is None:
        return
    parser = Parser(os.path.abspath(os.path.join(HERE, "..", "references")))
    files = parser.discover(inp)
    task = load_task(inp)
    if not extract_question(case) and task:
        case = dict(case, task_instruction=task)
    try:
        payload, sources, uncertainty, change_records, degradations, all_recs, merged, candidates = build_payload(case, parser, files)
    except Exception as e:
        r = empty_contract_result(case, "partial", [{"issue": "pipeline_exception", "detail": str(e)[:300]}], [], "pipeline exception")
        wj(os.path.join(ws, "partial_result.json"), r)
        wj(os.path.join(out, "result.json"), r)
        return
    status = "insufficient_evidence" if not all_recs else ("partial" if degradations else "complete")
    result = build_result(case, payload, sources, uncertainty, change_records, errs, degradations, status)
    wj(os.path.join(out, "result.json"), result)
    wj(os.path.join(out, "merged_records.json"), {"count": len(candidates), "candidates": candidates})
    wj(os.path.join(ws, "state.json"), {"records": all_recs, "clusters": dedup(all_recs), "merged": merged,
                                        "coverage": payload.get("coverage"), "degradations": degradations})
    wj(os.path.join(ws, "partial_result.json"), result)


def main(argv):
    p = argparse.ArgumentParser(prog="main.py", description="multi-db literature search")
    p.add_argument("mode", nargs="?", default="build", choices=["check", "build"])
    p.add_argument("--input", dest="input_dir")
    p.add_argument("--work", dest="work_dir")
    p.add_argument("--output", dest="output_dir")
    args = p.parse_args(argv)
    inp, ws, out = resolve_dirs(args)
    {"check": do_check, "build": build}[args.mode](inp, ws, out)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except SystemExit:
        sys.exit(0)
    except Exception:
        sys.exit(0)

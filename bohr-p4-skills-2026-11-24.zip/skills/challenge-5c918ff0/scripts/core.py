"""Parser (stdlib)."""
import csv, hashlib, io, json, os, re, zlib

STOP = set("the a an of and or for in on to by with from is are was be as at it this that these using via based use used new study review research paper data method model analysis result we our between within during after before into over under than not no its their can may will has have had been".split())
PRIORITY = {"crossref": 100, "europepmc": 95, "pubmed": 90, "openalex": 88, "semanticscholar": 85, "wos": 82, "scopus": 82, "arxiv": 80, "publisher": 70, "referencegraph": 40, "importstate": 5}
FIELD_NAMES = ["title", "authors", "year", "venue", "doi", "abstract", "type", "volume", "issue", "pages", "url"]

TITLE_KEYS = {"title", "articletitle", "displaytitle", "headline", "publicationtitle", "label"}
DOI_KEYS = {"doi", "doivalue", "electronicid"}
AUTHOR_KEYS = {"author", "authors", "authorlist", "creator", "creators", "contributor", "authorname", "authorstring"}
YEAR_KEYS = {"year", "pubyear", "publicationyear", "publishedyear", "publishdate", "issued", "published", "datepublished", "date"}
VENUE_KEYS = {"containertitle", "journaltitle", "journal", "source", "periodical", "booktitle", "journalname", "container", "venue"}
ABSTRACT_KEYS = {"abstract", "abstracttext", "summary", "description"}
VOLUME_KEYS = {"volume", "vol"}
ISSUE_KEYS = {"issue", "number", "no"}
PAGES_KEYS = {"page", "pages", "pagination", "firstpage", "startpage", "articlenumber"}
TYPE_KEYS = {"type", "pubtype", "publicationtype", "documenttype", "genre"}
URL_KEYS = {"url", "link", "uri", "fulltexturl", "weblink"}
PMID_KEYS = {"pmid", "pubmedid"}
PMCID_KEYS = {"pmcid", "pmc"}
ID_KEYS = {"id", "sourceid", "recordid", "uuid", "paperid", "key", "nodeid"}


def norm_ws(s):
    return re.sub(r"\s+", " ", str(s)).strip() if s is not None else ""


def norm_key(s):
    return re.sub(r"[^\w\u4e00-\u9fff]+", " ", str(s)).lower().strip() if s is not None else ""


def canon_key(k):
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]", "", str(k).lower())


def md5(s):
    return hashlib.md5(str(s).encode("utf-8", "replace")).hexdigest()


def first_year(v):
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return int(v)
    if isinstance(v, (list, tuple)):
        return next((first_year(x) for x in v if first_year(x)), None)
    if isinstance(v, dict):
        return next((first_year(v[k]) for k in ("date-parts", "date_parts", "timestamp", "year") if k in v and first_year(v[k])), None)
    m = re.search(r"\b(19|20)\d{2}\b", str(v))
    return int(m.group(0)) if m else None


def to_list(v):
    return v if isinstance(v, list) else ([v] if v is not None else [])


def text_of(v):
    if v is None:
        return ""
    if isinstance(v, (str, int, float)):
        return str(v)
    if isinstance(v, list):
        return " ".join(text_of(x) for x in v)
    if isinstance(v, dict):
        return text_of(v.get("value", " ".join(text_of(x) for x in v.values())))
    return str(v)


def norm_title(s):
    s = norm_ws(s)
    return re.sub(r"^[\[\]\"'()\s]+|[\[\]\"'()\s]+$", "", s).rstrip(".").strip()


def norm_identifier(s):
    s = norm_ws(s)
    if s.lower().startswith("doi:"):
        s = s[4:]
    s = re.sub(r"^https?://(dx\.)?doi\.org/", "", s, flags=re.I)
    return re.sub(r"^https?://", "", s, flags=re.I).lower().strip()


def find_val(obj, keyset):
    if not isinstance(obj, dict):
        return None
    for k, v in obj.items():
        if canon_key(k) in keyset:
            return v
    return None


def extract_authors(obj):
    out = []
    a = find_val(obj, AUTHOR_KEYS)
    if a is None:
        return out
    if isinstance(a, str):
        s = a.strip()
        return ([p.strip() for p in re.split(r"[;]", s) if p.strip()] or [s]) if s else out
    for x in to_list(a):
        if isinstance(x, str):
            s = norm_ws(x)
            if s:
                out.append(s)
        elif isinstance(x, dict):
            g = text_of(x.get("given") or x.get("givenName") or x.get("forename") or "")
            f = text_of(x.get("family") or x.get("familyName") or x.get("surname") or "")
            n = text_of(x.get("name") or x.get("fullName") or x.get("authorString") or "")
            s = norm_ws(n or ("%s %s" % (f, g)).strip())
            if s:
                out.append(s)
    return out


def is_record(o):
    return isinstance(o, dict) and bool(text_of(find_val(o, TITLE_KEYS)).strip() or text_of(find_val(o, DOI_KEYS)).strip())


def leaves_of(v, out=None):
    if out is None:
        out = []
    if isinstance(v, str):
        out.append(v)
    elif isinstance(v, (int, float)):
        out.append(str(v))
    elif isinstance(v, list):
        for x in v:
            leaves_of(x, out)
    elif isinstance(v, dict):
        for x in v.values():
            leaves_of(x, out)
    return out


def simplify(v, d=0):
    if d > 4:
        return str(v)[:200]
    if isinstance(v, dict):
        return {k: simplify(x, d + 1) for k, x in v.items()}
    if isinstance(v, list):
        return [simplify(x, d + 1) for x in v[:100]]
    return v if isinstance(v, (str, int, float, bool)) or v is None else str(v)[:200]


class Parser:
    def __init__(self, refs_dir):
        self.priority = dict(PRIORITY)
        self.expand = {}
        for fname in ("field_mapping.json", "query_expansion.json"):
            p = os.path.join(refs_dir, fname)
            if not os.path.isfile(p):
                continue
            try:
                with open(p, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                continue
            if fname == "field_mapping.json":
                for k, v in (data.get("source_priority") or {}).items():
                    self.priority[canon_key(k)] = int(v)
            else:
                for k, v in (data.get("expansions") or {}).items():
                    self.expand[canon_key(k)] = [str(x) for x in to_list(v)]

    def discover(self, input_dir):
        files = []
        if os.path.isdir(input_dir):
            for root, dirs, names in os.walk(input_dir):
                dirs.sort()
                for n in sorted(names):
                    p = os.path.join(root, n)
                    if not os.path.isfile(p) or (n == "case.json" and os.path.abspath(root) == os.path.abspath(input_dir)):
                        continue
                    rel = os.path.relpath(p, input_dir).replace("\\", "/")
                    try:
                        size = os.path.getsize(p)
                    except OSError:
                        size = 0
                    files.append({"path": p, "rel": rel, "ext": os.path.splitext(n)[1].lower(), "size": size})
        return files

    def read_text(self, p, ext):
        if ext == ".pdf":
            return self.pdf_text(p)
        if ext not in (".json", ".xml", ".csv", ".txt", ".md", ".tsv", ".text"):
            return None
        for enc in ("utf-8", "utf-8-sig", "latin-1", "gb18030"):
            try:
                return open(p, "r", encoding=enc).read()
            except (UnicodeDecodeError, UnicodeError, OSError):
                continue
        return None

    def pdf_text(self, p):
        try:
            data = open(p, "rb").read()
        except OSError:
            return None
        if not data.startswith(b"%PDF"):
            return None
        chunks = []
        for m in re.finditer(rb"stream\r?\n(.*?)endstream", data, re.S):
            try:
                dec = zlib.decompress(m.group(1).rstrip(b"\r\n"))
            except Exception:
                continue
            chunks += [sm.group(1).decode("latin-1", "replace") for sm in re.finditer(rb"\((.*?)\)\s*Tj", dec, re.S)]
        j = "\n".join(chunks)
        return j if j.strip() else None

    def guess_db(self, rel, raw):
        r = rel.lower()
        for kw, db in {"crossref": "crossref", "europepmc": "europepmc", "epmc": "europepmc", "pubmed": "pubmed",
                       "scopus": "scopus", "openalex": "openalex", "semantic": "semanticscholar", "arxiv": "arxiv",
                       "reference": "reference_graph", "citation": "reference_graph", "graph": "reference_graph",
                       "cited": "reference_graph", "import": "import_state", "state": "import_state", "sync": "import_state"}.items():
            if kw in r:
                return db
        s = (raw or "")[:4000].lower()
        for kw, db in (("resultlist", "europepmc"), ("europepmc", "europepmc"), ("crossref", "crossref"), ("pubmed", "pubmed")):
            if kw in s:
                return db
        return "publisher"

    def parse_file(self, f):
        raw = self.read_text(f["path"], f["ext"])
        if raw is None:
            return [], {}, {}, [{"file": f["rel"], "issue": "unreadable"}]
        db = self.guess_db(f["rel"], raw)
        ext = f["ext"]
        if ext == ".json":
            try:
                obj = json.loads(raw)
            except Exception as e:
                return [], {}, {}, [{"file": f["rel"], "issue": "bad_json", "detail": str(e)[:160]}]
            return self.walk_json(obj, f["rel"], db, raw), self.detect_graph(obj, f["rel"]), self.detect_import(obj, f["rel"]), []
        if ext == ".xml":
            return self.parse_text(f["rel"], db, raw), {}, {}, []
        if ext in (".csv", ".tsv"):
            recs, imp = self.parse_csv(f["rel"], db, raw, ext)
            return recs, {}, imp, []
        if ext in (".txt", ".md", ".text"):
            return self.parse_text(f["rel"], db, raw), {}, {}, []
        if ext == ".pdf":
            return self.parse_pdf(f["rel"], db, raw) if raw.strip() else [], {}, {}, [{"file": f["rel"], "issue": "pdf_no_text"}]
        return [], {}, {}, [{"file": f["rel"], "issue": "unsupported_extension", "detail": ext}]

    def walk_json(self, obj, rel, db, raw):
        recs, seen = [], set()

        def walk(node, path):
            if isinstance(node, dict):
                if is_record(node):
                    if path not in seen:
                        seen.add(path)
                        r = self.extract_record(node, rel, db, raw, path)
                        if r:
                            recs.append(r)
                    return
                for k, v in node.items():
                    walk(v, path + "." + str(k))
            elif isinstance(node, list):
                for i, v in enumerate(node):
                    walk(v, "%s[%d]" % (path, i))

        walk(obj, "$")
        return recs

    def prov(self, rawval, raw, rel, db, loc):
        leaves = [l for l in leaves_of(rawval) if l.strip()]
        if not leaves:
            return {"quote": "", "verified": False, "file": rel, "db": db, "locator": loc}
        q = norm_ws(max(leaves, key=len))
        return {"quote": q, "verified": bool(q) and q in norm_ws(raw), "file": rel, "db": db, "locator": loc}

    def extract_record(self, node, rel, db, raw, loc):
        def gv(keyset):
            v = find_val(node, keyset)
            return v[0] if isinstance(v, list) and v else v

        title = norm_title(text_of(gv(TITLE_KEYS)))
        doi = norm_ws(text_of(gv(DOI_KEYS)))
        if not title and not doi:
            return None
        spec = [("title", title, gv(TITLE_KEYS)), ("doi", doi, gv(DOI_KEYS)), ("year", first_year(gv(YEAR_KEYS)), gv(YEAR_KEYS)),
                ("venue", norm_ws(text_of(gv(VENUE_KEYS))), gv(VENUE_KEYS)), ("abstract", norm_ws(text_of(gv(ABSTRACT_KEYS))), gv(ABSTRACT_KEYS)),
                ("type", norm_ws(text_of(gv(TYPE_KEYS))), gv(TYPE_KEYS)), ("volume", norm_ws(text_of(gv(VOLUME_KEYS))), gv(VOLUME_KEYS)),
                ("issue", norm_ws(text_of(gv(ISSUE_KEYS))), gv(ISSUE_KEYS)), ("pages", norm_ws(text_of(gv(PAGES_KEYS))), gv(PAGES_KEYS)),
                ("url", norm_ws(text_of(gv(URL_KEYS))), gv(URL_KEYS))]
        fields, prov = {}, {}
        for fn, val, rawv in spec:
            if val in (None, "", []):
                continue
            fields[fn] = val
            prov[fn] = self.prov(rawv, raw, rel, db, loc)
        au = extract_authors(node)
        if au:
            fields["authors"] = au
            prov["authors"] = self.prov(find_val(node, AUTHOR_KEYS), raw, rel, db, loc)
        ids = {}
        if doi:
            ids["doi"] = doi
        for key, ks in (("pmid", PMID_KEYS), ("pmcid", PMCID_KEYS)):
            v = norm_ws(text_of(gv(ks)))
            if v:
                ids[key] = v
        sid = norm_ws(text_of(gv(ID_KEYS)))
        if sid and norm_identifier(sid) != norm_identifier(doi):
            ids["source_id"] = sid
        if ids:
            fields["identifiers"] = ids
        return {"fields": fields, "provenance": prov, "source": {"db": db, "file": rel, "locator": loc}}

    def detect_import(self, obj, rel):
        if not isinstance(obj, dict):
            return {}
        s = json.dumps(obj)[:6000].lower()
        if not any(k in s for k in ("import", "sync", "ingest", "last_updated", "pending", "lastimport")):
            return {}
        imp = {canon_key(k): simplify(v) for k, v in obj.items()
               if any(x in canon_key(k) for x in ("import", "sync", "ingest", "lastupdated", "lastimport", "pending", "imported", "status", "state"))}
        if imp:
            imp["_file"] = rel
        return imp

    def detect_graph(self, obj, rel):
        if not isinstance(obj, dict):
            return {}
        nodes = obj.get("nodes") or obj.get("vertices") or obj.get("papers") or obj.get("documents")
        edges = obj.get("edges") or obj.get("links") or obj.get("references") or obj.get("citations") or obj.get("cited_by")
        if nodes is None and edges is None:
            return {}
        g = {"_file": rel}
        for key, val in (("nodes", nodes), ("edges", edges)):
            if isinstance(val, list):
                g[key] = [simplify(x) for x in val]
            elif isinstance(val, dict):
                g[key] = [simplify(x) for x in list(val.values())[:500]]
        return g

    def parse_csv(self, rel, db, raw, ext):
        delim = "\t" if ext == ".tsv" else ","
        try:
            rd = csv.DictReader(io.StringIO(raw), delimiter=delim)
            hset = set(canon_key(h) for h in (rd.fieldnames or []))
        except Exception:
            return [], {}
        if not (hset & {"title", "doi"}):
            rows = [{k: norm_ws(v) for k, v in r.items() if v is not None and str(v).strip()} for r in rd]
            return [], ({"_file": rel, "rows": rows[:200]} if rows else {})
        recs = []
        for i, row in enumerate(rd):
            title = norm_title(row.get("title", "") or "")
            doi = norm_ws(row.get("doi", "") or "")
            if not title and not doi:
                continue
            rec = {"fields": {}, "provenance": {}, "source": {"db": db, "file": rel, "locator": "%s#row%d" % (rel, i + 2)}}
            if title:
                rec["fields"]["title"] = title
            if doi:
                rec["fields"]["doi"] = doi
            au = norm_ws(row.get("authors", "") or row.get("author", "") or "")
            if au:
                rec["fields"]["authors"] = [x.strip() for x in re.split(r"[;,]", au) if x.strip()]
            y = first_year(row.get("year", "") or row.get("pubyear", "") or "")
            if y:
                rec["fields"]["year"] = y
            for col, fn in (("journal", "venue"), ("venue", "venue"), ("abstract", "abstract"), ("type", "type")):
                if row.get(col) and fn not in rec["fields"]:
                    rec["fields"][fn] = norm_ws(row[col])
            self.attach_prov(rec, raw)
            recs.append(rec)
        return recs, {}

    def parse_text(self, rel, db, raw):
        recs = []
        for d in sorted(set(re.findall(r"10\.\d{4,9}/[^\s\"'<>)\]]+", raw))):
            rec = {"fields": {"doi": d}, "provenance": {}, "source": {"db": db, "file": rel, "locator": "text_doi"}}
            self.attach_prov(rec, raw)
            recs.append(rec)
        return recs

    def parse_pdf(self, rel, db, raw):
        recs = []
        for d in sorted(set(re.findall(r"10\.\d{4,9}/[^\s\"'<>)\]]+", raw)))[:5]:
            rec = {"fields": {"doi": d}, "provenance": {}, "source": {"db": db, "file": rel, "locator": "pdf_doi"}}
            self.attach_prov(rec, raw)
            recs.append(rec)
        lines = [l.strip() for l in raw.splitlines() if l.strip()]
        if lines and not recs:
            rec = {"fields": {"title": norm_title(lines[0][:300])}, "provenance": {}, "source": {"db": db, "file": rel, "locator": "pdf_line1"}}
            self.attach_prov(rec, raw)
            recs.append(rec)
        return recs

    def attach_prov(self, rec, raw):
        rel, db, loc = rec["source"]["file"], rec["source"]["db"], rec["source"]["locator"]
        for fn, val in rec["fields"].items():
            q = norm_ws(str(val[0] if fn == "authors" and isinstance(val, list) else val))
            rec["provenance"][fn] = {"quote": q, "verified": bool(q) and q in norm_ws(raw), "file": rel, "db": db, "locator": loc}

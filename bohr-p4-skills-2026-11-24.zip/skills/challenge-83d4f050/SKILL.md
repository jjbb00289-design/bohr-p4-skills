---
name: mechanism-figure
description: Derive a biological mechanism / pathway diagram (SVG + PNG + PDF) from the real text of the supplied paper — genes, proteins, complexes and metabolites become nodes, activation/inhibition/binding/transformation become directional edges, and every label is anchored to a verbatim source quote with a locator. Works without a hand-written plan and never draws an unsupported edge.
version: 6.0
---

# Biological mechanism & pathway figure generator

Build an entity–relation mechanism diagram from a paper (PDF/markdown/CSV/DOCX/
PPTX). Nodes are molecules/complexes/processes that actually occur in the text;
edges are regulatory relations the text actually states, with direction taken
from the sentence. Nothing on the canvas is decorative: every label resolves to a
`locator` plus a byte-for-byte `quote`, and the run reports the measured hit rate.

## One command

```bash
python3 scripts/main.py
```

Full pipeline: scan `/input` → extract text → locator-bearing chunks → entity
extraction → relation extraction → verbatim verification → render `figure.svg`,
`figure.png`, `figure.pdf` → `result.json`.

`init`, `build`, `check`, `selfcheck` are aliases over the same pipeline:

```bash
python3 scripts/main.py build --input /input --work /work --output /output
```

## Mechanism semantics

- **Nodes** — gene/protein symbols (`NF-κB`, `mTOR`, `AKT1`), capitalised
  complexes, domain noun phrases (`reward model`, `signalling complex`,
  `transcription factor`). Kept only if seen ≥ 3 times across ≥ 2 chunks and not
  a generic word or an affiliation string.
- **Edges** — a sentence yields an edge only when it contains a relation verb and
  an entity on each side of it. Source = nearest entity before the verb, target =
  nearest entity after it, so direction follows the sentence rather than the word
  order of the figure.
- **Types** — `activation` (activates, promotes, induces, upregulates, stimulates,
  drives), `inhibition` (inhibits, suppresses, represses, attenuates, blocks,
  prevents), `binding` (binds, interacts, dimerizes, recruits, targets),
  `transformation` (phosphorylates, cleaves, converts, ubiquitinates,
  translocates, secretes), `composition` (contains, comprises, assembles),
  `association` (correlates, depends on, accompanies). Pathway vocabulary is
  extended from `references/figure_profile.json`.
- **No edge without a verb on both sides.** A missing relation is reported in
  `gaps`, not fabricated to fill the canvas.

## Verification the run performs

- each relation's `quote` is searched in its chunk; `quote_hit_rate` must reach
  0.95 or the run downgrades to `status=partial`;
- every drawn label appears in `content_map.json` with `locator` + `quote`;
- placeholder tokens (`Entity`, `Node`, `Item`, `TBD`, `示例`, `占位`) are rejected;
- `figure.svg` must contain `<text>` and `<g id="layer-…">`; `figure.png` must
  start with the PNG signature; `figure.pdf` with `%PDF-`;
- legend item count equals the number of relation types actually drawn.

## Layout

Entities are ordered by first mention and split into two panels with sub-figure
badges `a`/`b` (upstream regulators first, downstream effectors second). Edge
styles are fixed per type: activation = solid blue arrow, inhibition = blunt red
bar, binding = dashed line with circle, transformation = solid amber arrow,
composition/association = grey.

## Hand-written plan (optional, same schema)

`work/plan.json` takes precedence over derivation:

```json
{
  "entities": [{"label": "AKT1", "locator": "m1#p4", "quote": "AKT1 is phosphorylated ..."}],
  "relations": [
    {"source": "mTOR", "target": "AKT1", "type": "activation", "verb": "phosphorylates",
     "locator": "m1#p4", "quote": "mTOR phosphorylates AKT1 at Ser473."}
  ]
}
```

A plan whose quote is not in the source fails the hit-rate gate instead of being
drawn silently.

## Degraded inputs

Empty, malformed or material-free inputs never abort: the run still writes
`result.json` with every contract key, exits 0, and reports `status=partial`
(`input_error` when nothing could be scanned) plus the `gaps` list.

## Output contract

`result.json` always carries `case_id`, `status`, `result`, `claims`, `coverage`
(plus `figure_model`, `content_map`, `exports`, `provenance`, `gaps`, `errors`).
`claims[]` is the per-edge evidence table: claim text, locator, verbatim quote,
evidence type and relation type.

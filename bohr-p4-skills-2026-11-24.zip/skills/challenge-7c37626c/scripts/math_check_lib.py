# -*- coding: utf-8 -*-
"""Formula/LaTeX cross-checks, symbol coverage and sandboxed numeric replication.

Mechanical validation only: structure counters against the MathML record, symbol
coverage against the identifiers actually used, verbatim quote hits for original
definitions, and arithmetic recomputation with a declared tolerance.
"""
import ast
import json
import math
import re
from pathlib import Path

from io_parse import find_quote, jload, norm_text
from mml_lib import structure_of

FORMULA_KEYS = ("formulas", "equations", "expression_objects")
BASES = ("original", "inferred", "common_knowledge")
CHECK_RESULTS = ("pass", "fail", "not_computable")
FUNC_NAMES = {"sin", "cos", "tan", "cot", "sec", "csc", "log", "ln", "exp", "max", "min",
              "lim", "sup", "inf", "det", "dim", "sinh", "cosh", "tanh", "arg"}
SAFE_FUNCS = {"sqrt": math.sqrt, "log": math.log, "ln": math.log, "exp": math.exp,
              "sin": math.sin, "cos": math.cos, "tan": math.tan, "abs": abs,
              "pi": math.pi, "e": math.e}
ALLOWED_NODES = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Constant, ast.Name,
                 ast.Load, ast.Call, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow,
                 ast.USub, ast.UAdd, ast.Mod)

# ------------------------------------------------------------- LaTeX structure
def latex_structure(latex):
    text = latex or ""
    return {
        "fracs": text.count("\\frac") + text.count("\\dfrac") + text.count("\\tfrac"),
        "subs": len(re.findall(r"(?<!\\\\)_[{]", text)) + len(re.findall(r"(?<!\\\\)_[A-Za-z0-9]", text)),
        "sups": len(re.findall(r"(?<!\\\\)\^[{]", text)) + len(re.findall(r"(?<!\\\\)\^[A-Za-z0-9]", text)),
        "radicals": text.count("\\sqrt"),
        "matrices": 1 if re.search(r"\\begin\{[bpvBV]?matrix\}|\\begin\{array\}", text) else 0,
        "cases": 1 if re.search(r"\\begin\{cases\}|\\begin\{aligned\}", text) else 0,
        "brace_balance": text.count("{") - text.count("}") == 0,
        "paren_balance": text.count("(") - text.count(")") == 0,
        "length": len(text),
    }


def latex_text(latex):
    """Strip LaTeX commands to compare symbol coverage against MathML identifiers."""
    text = latex or ""
    text = re.sub(r"\\[a-zA-Z]+(\[[^\]]*\])?", " ", text)
    text = text.replace("{", " ").replace("}", " ").replace("_", " ").replace("^", " ")
    return text


def missing_symbols(record, defined_symbols):
    used = [sym for sym in record.get("symbols", {}).get("identifiers", [])
            if sym not in FUNC_NAMES]
    defined = set(defined_symbols)
    return [sym for sym in used if sym not in defined]


# ------------------------------------------------------------------ numeric
def safe_eval(expression, env=None):
    """Sandboxed arithmetic evaluation for numeric replication checks."""
    env = env or {}
    if not isinstance(expression, str) or len(expression) > 400:
        raise ValueError("expression too long or not a string")
    tree = ast.parse(expression, mode="eval")
    for node in ast.walk(tree):
        if not isinstance(node, ALLOWED_NODES):
            raise ValueError("unsupported syntax: %s" % type(node).__name__)
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name) or node.func.id not in SAFE_FUNCS:
                raise ValueError("function not allowed")
    scope = dict(SAFE_FUNCS)
    for key, value in env.items():
        if not isinstance(key, str):
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("substitution '%s' is not numeric" % key)
        scope[key] = float(value)
    return float(eval(compile(tree, "<numeric>", "eval"), {"__builtins__": {}}, scope))


def numeric_verdict(check):
    """Recompute one numeric check; returns (failures, warnings, recomputed)."""
    fails, warns = [], []
    cid = check.get("check_id") or "(no check_id)"
    result = check.get("result")
    if result not in CHECK_RESULTS:
        fails.append("%s: result '%s' not in %s" % (cid, result, "/".join(CHECK_RESULTS)))
    expression = check.get("expression")
    subs = check.get("substitutions") or {}
    computed = check.get("computed")
    expected = check.get("expected")
    tolerance = check.get("tolerance")
    recomputed = None
    if expression:
        try:
            recomputed = safe_eval(expression, subs)
        except Exception as exc:
            warns.append("%s: expression not recomputable (%s); result must be not_computable"
                         % (cid, exc))
            if result != "not_computable":
                fails.append("%s: claims a computed result but the expression is not evaluable"
                             % cid)
            return fails, warns, None
        if computed is None:
            warns.append("%s: 'computed' missing; recomputed value = %.6g" % (cid, recomputed))
        else:
            try:
                difference = abs(float(computed) - recomputed)
                allowance = max(abs(recomputed) * 1e-3, 1e-6)
                if difference > allowance:
                    fails.append("%s: stated computed %.6g != recomputed %.6g (beyond 0.1%% rounding)"
                                 % (cid, float(computed), recomputed))
            except Exception:
                fails.append("%s: computed value is not numeric" % cid)
        if expected is not None and tolerance is not None:
            try:
                within = abs(float(expected) - recomputed) <= abs(float(tolerance))
            except Exception:
                within = False
            if result == "pass" and not within:
                fails.append("%s: result=pass but recomputed %.6g is outside %s +/- %s"
                             % (cid, recomputed, expected, tolerance))
            if result == "fail" and within:
                warns.append("%s: result=fail but recomputed %.6g is within %s +/- %s"
                             % (cid, recomputed, expected, tolerance))
    else:
        if result == "pass":
            warns.append("%s: pass without a recomputable expression" % cid)
    return fails, warns, recomputed


# ------------------------------------------------------------------- coverage
def coverage_of(records, formulas, variables, derivations, checks):
    expected = [record["formula_id"] for record in records]
    parsed_ids = [formula.get("formula_id") for formula in formulas if formula.get("latex")]
    defined = [var.get("symbol") for var in variables if var.get("symbol")]
    needed = []
    for record in records:
        for sym in record.get("symbols", {}).get("identifiers", []):
            if sym not in FUNC_NAMES and sym not in needed:
                needed.append(sym)
    missing_formulas = [fid for fid in expected if fid not in parsed_ids]
    missing_symbols_list = [sym for sym in needed if sym not in set(defined)]
    check_pass = sum(1 for check in checks if check.get("result") == "pass")
    check_fail = sum(1 for check in checks if check.get("result") == "fail")
    return {
        "formulas_in_source": len(expected),
        "formulas_parsed": len(parsed_ids),
        "formula_ids_expected": expected,
        "missing_formula_ids": missing_formulas,
        "variables_expected": len(needed),
        "variables_defined": len([sym for sym in needed if sym in set(defined)]),
        "missing_symbols": missing_symbols_list,
        "derivations": len(derivations),
        "numeric_checks": len(checks),
        "numeric_checks_passed": check_pass,
        "numeric_checks_failed": check_fail,
        "complete": bool(expected) and not missing_formulas and not missing_symbols_list,
    }


def base_result(case, corpus, records, source_material, status, formulas, variables,
                derivations, checks, uncertainties, pending_human, errors, degradations,
                extra=None):
    coverage = coverage_of(records, formulas, variables, derivations, checks)
    result = {
        "formulas": formulas,
        "variables": variables,
        "derivations": derivations,
        "numeric_checks": checks,
        "coverage": coverage,
        "symbol_conventions": {
            "definition_basis": {
                "original": "defined in the supplied paper text (locator + verbatim quote required)",
                "inferred": "inferred from context with the inference stated",
                "common_knowledge": "standard symbol not defined in the paper; marked as such",
            },
            "rules": [
                "unitless quantities keep '-' rather than a guessed unit",
                "symbols are case-sensitive; subscripts are part of the symbol",
                "a derivation step must cite a source formula, an assumption or a named operation",
            ],
        },
        "method_notes": {
            "pipeline": "init -> show -> agent formula/symbol draft -> check -> build (no-draft "
                        "fallback: init -> build derives from the XML deterministically)",
            "mathml_conversion": "deterministic mfrac/msub/msup/msubsup/msqrt/mfenced/mtable mapping",
            "latex_check": "structure counters + brace balance + symbol coverage against MathML",
            "numeric_check": "sandboxed expression recomputation with declared tolerance",
            "no_draft_derive": "init+build with no usable draft derive LaTeX, a full-token symbol "
                               "table, structural derivations and constant-only numeric checks "
                               "straight from the supplied MathML",
            "source_honesty": "formula objects come from publisher XML only; absent representation "
                              "is reported, never back-derived",
        },
    }
    if extra:
        result.update(extra)
    return {
        "case_id": case_id_of(case), "status": status, "result": result,
        "claims": [], "uncertainties": uncertainties, "sources": material_sources(corpus),
        "pending_human": pending_human, "errors": errors, "degradations": degradations,
        "deliverables": {"index": "work/index.json", "draft": "work/draft.json",
                         "latex": "formulas.tex", "export": "formulas.pdf",
                         "symbols": "symbol_table.csv", "numbers": "numeric_checks.json",
                         "notes": "derivation_notes.md", "content_map": "content_map.json",
                         "formula_source": source_material},
        "input": {"case_file": "case.json"},
    }


def read_case(input_dir):
    path = Path(input_dir) / "case.json"
    if not path.exists():
        return {}, "case.json missing"
    raw = path.read_text(encoding="utf-8", errors="replace").strip().lstrip("\ufeff")
    if not raw:
        return {}, "case.json empty"
    try:
        doc = json.loads(raw)
    except Exception as exc:
        return {}, "case.json invalid JSON: %s" % exc
    if not isinstance(doc, dict):
        return {}, "case.json is not an object"
    return doc, ""


def case_id_of(case):
    for key in ("case_id", "caseId", "id", "slug", "name"):
        value = case.get(key) if isinstance(case, dict) else None
        if isinstance(value, str) and value.strip():
            return value.strip()
    return "unknown-case"


def load_draft(work):
    path = Path(work) / "draft.json"
    if not path.exists():
        return None, "draft.json missing"
    raw = path.read_text(encoding="utf-8", errors="replace").strip()
    if not raw:
        return None, "draft.json empty"
    try:
        doc = json.loads(raw)
    except Exception as exc:
        return None, "draft.json invalid JSON: %s" % exc
    if not isinstance(doc, dict):
        return None, "draft.json must be an object"
    return doc, ""


def draft_list(draft, keys):
    if not isinstance(draft, dict):
        return []
    for key in keys:
        value = draft.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]
    return []


def material_sources(corpus):
    return [{"material": mat["material"], "kind": mat["kind"], "bytes": mat["bytes"],
             "sha256": mat.get("sha256", ""), "text_method": mat.get("text_method"),
             "segments": mat.get("segments", 0), "tables": mat.get("tables", 0)}
            for mat in corpus.get("materials", [])]


def normalize_formula(raw, record):
    """Merge one draft formula with its MathML-derived record."""
    out = dict(record) if record else {}
    out.update({
        "formula_id": raw.get("formula_id") or out.get("formula_id"),
        "eq_number": raw.get("eq_number") or out.get("eq_number") or "",
        "latex": raw.get("latex") or out.get("latex") or "",
        "parse_confidence": raw.get("parse_confidence", 1.0 if record and record.get("annotation_tex") else 0.9),
        "source": raw.get("source") or out.get("source") or {},
        "structure": out.get("structure") or {},
        "symbols": out.get("symbols") or {},
        "notation_notes": raw.get("notation_notes"),
    })
    return out


def evaluate_formula(formula, record):
    """Cross-check the draft LaTeX against the MathML-derived structure."""
    fails, warns = [], []
    fid = formula.get("formula_id") or "?"
    latex = str(formula.get("latex") or "")
    if not latex.strip():
        fails.append("%s: latex missing" % fid)
        return fails, warns
    if not record:
        fails.append("%s: formula not present in the supplied publisher XML (unsourced formula)"
                     % fid)
        return fails, warns
    parsed = latex_structure(latex)
    expected = record.get("structure") or {}
    if not parsed["brace_balance"]:
        fails.append("%s: unbalanced braces in latex" % fid)
    if not parsed["paren_balance"]:
        warns.append("%s: unbalanced parentheses in latex" % fid)
    if parsed["fracs"] != expected.get("fracs", 0):
        fails.append("%s: \\frac count %d != MathML mfrac count %d"
                     % (fid, parsed["fracs"], expected.get("fracs", 0)))
    if parsed["subs"] != expected.get("subs", 0):
        warns.append("%s: subscript count %d != MathML count %d"
                     % (fid, parsed["subs"], expected.get("subs", 0)))
    if parsed["sups"] != expected.get("sups", 0):
        warns.append("%s: superscript count %d != MathML count %d"
                     % (fid, parsed["sups"], expected.get("sups", 0)))
    if parsed["radicals"] != expected.get("radicals", 0):
        warns.append("%s: \\sqrt count %d != MathML radical count %d"
                     % (fid, parsed["radicals"], expected.get("radicals", 0)))
    if expected.get("matrices") and not parsed["matrices"]:
        warns.append("%s: MathML table not represented as a matrix environment" % fid)
    if expected.get("cases") and not parsed["cases"]:
        warns.append("%s: MathML cases construct not represented as cases/aligned" % fid)
    confidence = formula.get("parse_confidence")
    if confidence is not None:
        try:
            confidence = float(confidence)
            if not 0.0 <= confidence <= 1.0:
                warns.append("%s: parse_confidence outside [0,1]" % fid)
        except Exception:
            warns.append("%s: parse_confidence is not numeric" % fid)
    source = formula.get("source") or {}
    if not source.get("material"):
        fails.append("%s: source.material missing (formula must be traceable)" % fid)
    return fails, warns


def evaluate_variable(variable, corpus):
    fails, warns = [], []
    sym = variable.get("symbol") or "?"
    if not variable.get("definition"):
        fails.append("%s: definition missing" % sym)
    basis = variable.get("definition_basis")
    if basis not in BASES:
        fails.append("%s: definition_basis '%s' not in %s" % (sym, basis, "/".join(BASES)))
    unit = variable.get("unit")
    if unit is None:
        warns.append("%s: unit missing; use '-' for dimensionless" % sym)
    source = variable.get("source") or {}
    quote = variable.get("quote")
    if basis == "original":
        if not quote:
            fails.append("%s: definition_basis=original but no verbatim quote" % sym)
        else:
            hits = find_quote(corpus, str(quote))
            if not hits:
                fails.append("%s: definition quote not found verbatim in materials" % sym)
            elif source.get("material") and not [h for h in hits
                                                  if h["material"] == source["material"]]:
                fails.append("%s: declared material '%s' does not contain the definition quote"
                             % (sym, source["material"]))
        if not (source.get("material") and (source.get("paragraph_id") or source.get("page")
                                            or source.get("section"))):
            fails.append("%s: original definition needs material + paragraph/page locator" % sym)
    elif basis in ("inferred", "common_knowledge"):
        if not (variable.get("inference_reason") or variable.get("notes")):
            warns.append("%s: %s needs an inference reason / note" % (sym, basis))
    return fails, warns


def evaluate_derivation(derivation, formula_ids):
    fails, warns = [], []
    did = derivation.get("derivation_id") or "?"
    steps = derivation.get("steps") or []
    if not steps:
        fails.append("%s: no derivation steps" % did)
    else:
        if len(steps) < 2:
            warns.append("%s: only one step; a derivation needs at least two checkable steps" % did)
        for idx, step in enumerate(steps):
            if not isinstance(step, dict):
                fails.append("%s: step %d is not an object" % (did, idx))
                continue
            if not str(step.get("statement_latex") or "").strip():
                fails.append("%s: step %d has no statement_latex" % (did, idx))
            if not (step.get("justification") or step.get("assumption") or step.get("operation")):
                fails.append("%s: step %d has no justification/assumption" % (did, idx))
    deps = derivation.get("depends_on") or derivation.get("formula_ids") or []
    for dep in deps if isinstance(deps, list) else []:
        if formula_ids and dep not in formula_ids:
            fails.append("%s: dependency '%s' is not a known formula_id" % (did, dep))
    return fails, warns


def normalize_variable(raw):
    source = raw.get("source") if isinstance(raw.get("source"), dict) else {}
    for key in ("material", "paragraph_id", "page", "section", "table_id", "row"):
        if raw.get(key) is not None and source.get(key) is None:
            source[key] = raw.get(key)
    return {
        "symbol": raw.get("symbol") or raw.get("name") or raw.get("variable"),
        "definition": raw.get("definition") or raw.get("meaning") or "",
        "unit": raw.get("unit") if raw.get("unit") is not None else "-",
        "range": raw.get("range") or raw.get("valid_range"),
        "definition_basis": raw.get("definition_basis") or raw.get("basis"),
        "source": source,
        "quote": raw.get("quote") or raw.get("evidence_quote"),
        "inference_reason": raw.get("inference_reason") or raw.get("reason"),
        "notes": raw.get("notes"),
        "formula_ids": raw.get("formula_ids") or [],
    }


def normalize_derivation(raw):
    return {
        "derivation_id": raw.get("derivation_id") or raw.get("id"),
        "formula_id": raw.get("formula_id") or raw.get("target_formula"),
        "steps": raw.get("steps") if isinstance(raw.get("steps"), list) else [],
        "assumptions": raw.get("assumptions") if isinstance(raw.get("assumptions"), list) else [],
        "approximations": raw.get("approximations") if isinstance(raw.get("approximations"), list) else [],
        "boundary_conditions": raw.get("boundary_conditions") if isinstance(raw.get("boundary_conditions"), list) else [],
        "depends_on": raw.get("depends_on") or raw.get("formula_ids") or [],
        "notes": raw.get("notes"),
    }


def normalize_check(raw):
    return {
        "check_id": raw.get("check_id") or raw.get("id"),
        "formula_id": raw.get("formula_id"),
        "expression": raw.get("expression"),
        "substitutions": raw.get("substitutions") if isinstance(raw.get("substitutions"), dict) else {},
        "expected": raw.get("expected"),
        "computed": raw.get("computed"),
        "tolerance": raw.get("tolerance"),
        "unit": raw.get("unit"),
        "result": raw.get("result"),
        "assumptions": raw.get("assumptions") if isinstance(raw.get("assumptions"), list) else [],
        "notes": raw.get("notes"),
    }


def terminal(formulas, variables):
    if not formulas:
        return False
    if any(not (formula.get("validation") or {}).get("ok") for formula in formulas):
        return False
    return all((variable.get("validation") or {}).get("ok") is not False for variable in variables)


# ------------------------------------------------------------------ claims
def locator_of(source):
    """Non-material locator keys from a source object."""
    source = source if isinstance(source, dict) else {}
    locator = {}
    for key in ("node_id", "source_id", "paragraph_id", "page", "section", "table_id", "row"):
        value = source.get(key)
        if value not in (None, ""):
            locator[key] = value
    return locator


def build_claims(records, formulas, variables, derivations, checks, source_material, corpus=None):
    """Evidence-backed claims: every conclusion carries material + locator + verbatim quote."""
    claims = []
    counter = [0]

    def add(claim_type, statement, evidence, basis, confidence=None):
        counter[0] += 1
        item = {"claim_id": "C%03d" % counter[0], "claim_type": claim_type,
                "statement": statement, "evidence": evidence, "basis": basis}
        if confidence is not None:
            item["confidence"] = confidence
        claims.append(item)

    for formula in formulas:
        fid = formula.get("formula_id")
        src = formula.get("source") if isinstance(formula.get("source"), dict) else {}
        quote = formula.get("mathml") or formula.get("latex") or ""
        add("formula_restoration",
            "公式 %s 的结构与符号被完整还原为 LaTeX「%s」"
            % (fid, (formula.get("latex") or "").strip()),
            {"material": src.get("material") or source_material,
             "locator": locator_of(src), "quote": quote},
            "deterministic MathML-to-LaTeX conversion", formula.get("parse_confidence"))
    for var in variables:
        sym = var.get("symbol") or "?"
        basis = var.get("definition_basis")
        src = var.get("source") if isinstance(var.get("source"), dict) else {}
        quote = var.get("quote") or ""
        definition = var.get("definition") or ""
        if basis == "original":
            add("symbol_definition", "符号 %s 的原文定义为「%s」" % (sym, definition),
                {"material": src.get("material"), "locator": locator_of(src), "quote": quote},
                "paper text (verbatim definition)", 1.0)
        elif definition:
            add("symbol_inference", "符号 %s 解释为「%s」（%s）"
                % (sym, definition, basis or "inferred"),
                {"material": src.get("material") or source_material,
                 "locator": locator_of(src), "quote": quote},
                "inference; not a verbatim paper definition" if basis != "original" else "paper text")
    for der in derivations:
        for step in der.get("steps") or []:
            if not isinstance(step, dict):
                continue
            fragment = str(step.get("latex_fragment") or step.get("statement_latex")
                           or step.get("statement") or "").strip()
            if not fragment:
                continue
            justification = step.get("justification") or step.get("operation") or \
                            step.get("note") or step.get("assumption") or ""
            add("derivation_step",
                "推导步骤 %s（%s）：%s"
                % (step.get("step_no") or "?", der.get("formula_id") or "?", fragment),
                {"material": source_material,
                 "locator": {"formula_id": der.get("formula_id"), "derivation_id":
                             der.get("derivation_id")},
                 "quote": fragment},
                justification or "structural expansion of the MathML tree")
    for check in checks:
        cid = check.get("check_id") or "?"
        expression = str(check.get("expression") or "")
        if check.get("result") == "pass":
            statement = "复算 %s = %s" % (expression, check.get("computed"))
        else:
            statement = "数值检查 %s：%s，result=%s" % (cid, expression, check.get("result"))
        add("numeric_verification", statement,
            {"material": source_material,
             "locator": {"formula_id": check.get("formula_id")}, "quote": expression},
            "sandboxed arithmetic recomputation")
    if not records:
        add("coverage_gap",
            "材料未提供可解析的公式表示（MathML 公式节点）；未反推公式、未把未知填 0",
            {"material": source_material, "locator": {}, "quote": ""},
            "absence reported honestly as insufficient_evidence")
        if corpus:
            seen = 0
            for seg in corpus.get("segments", []):
                if seen >= 40:
                    break
                material = str(seg.get("material") or "")
                text = str(seg.get("text") or "")
                if material.lower().endswith((".xml", ".mathml", ".json")):
                    continue
                if not re.search(r"\d", text) or len(text) > 400:
                    continue
                locator = {key: seg.get(key) for key in
                           ("paragraph_id", "page", "section", "table_id", "row")
                           if seg.get(key) not in (None, "")}
                add("text_metric", "材料报告的明确指标/条件（无公式表示，未作推导或复算）：%s"
                    % text[:160],
                    {"material": material, "locator": locator, "quote": text},
                    "verbatim material text; formulas are not back-derived from prose")
                seen += 1
    return claims


def content_entry(kind, obj, source, quote, output_file):
    entry = {"kind": kind, "output": output_file, "source": source, "quote": quote}
    for key in ("formula_id", "symbol", "derivation_id", "check_id", "latex", "definition",
                "expression", "computed", "result"):
        value = obj.get(key) if isinstance(obj, dict) else None
        if value not in (None, "", []):
            entry[key] = value
    return entry


def build_content_map(case_id, formulas, variables, derivations, checks, source_material,
                      output_files):
    elements = {
        "formulas": [content_entry("formula", f, f.get("source") if isinstance(
            f.get("source"), dict) else {"material": source_material},
            f.get("mathml") or f.get("latex") or "", "formulas.tex") for f in formulas],
        "variables": [content_entry("variable", v, v.get("source") if isinstance(
            v.get("source"), dict) else {}, v.get("quote") or "", "symbol_table.csv")
            for v in variables],
        "derivations": [content_entry("derivation", d, {"material": source_material},
                                      d.get("formula_id") or "", "derivation_notes.md")
                        for d in derivations],
        "numeric_checks": [content_entry("numeric_check", c, {"material": source_material},
                                         c.get("expression") or "", "numeric_checks.json")
                           for c in checks],
    }
    return {"case_id": case_id, "map_version": "1.0", "elements": elements,
            "output_files": output_files}

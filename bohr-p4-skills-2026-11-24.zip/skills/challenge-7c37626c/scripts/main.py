#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Math-expression reader: init/show/check/build/selfcheck (stdlib only, exit 0).
With no draft, build deterministically derives formulas, a symbol table, structural
derivations and constant-only numeric checks from the supplied MathML."""
import argparse
import json
import sys
import traceback
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import io_parse as IOP
import math_check_lib as MCL
import mathml_derive as MDER
import mml_lib as MML

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

PKG_NAME = "math-expression-reader"
VERSION = "1.2.0"
PRODUCTS = ("result.json", "formulas.tex", "formulas.pdf", "formula_directory.md",
            "symbol_table.csv", "symbol_table.json", "numeric_checks.json",
            "derivation_notes.md", "content_map.json")


def source_context(args):
    corpus = IOP.build_corpus(args.input)
    records, source_material, notes = MML.load_source_formulas(args.input)
    return corpus, records, source_material, notes


def cmd_init(args):
    work, out = Path(args.work), Path(args.output)
    IOP.ensure_dir(work)
    IOP.ensure_dir(out)
    case, case_err = MCL.read_case(args.input)
    contract = case.get("output_contract") if isinstance(case, dict) else {}
    corpus, records, source_material, source_notes = source_context(args)
    degradations = list(corpus.get("degradations", [])) + list(source_notes)
    errors = [case_err] if case_err else []
    formulas = []
    for record in records:
        item = dict(record)
        item.update({"parse_confidence": 1.0 if record.get("annotation_tex") else 0.9,
                     "validation": "from publisher XML; symbol table and derivations still needed"})
        formulas.append(item)
    index = {
        "case_id": MCL.case_id_of(case), "input": str(args.input),
        "material_count": len(corpus["materials"]), "segment_count": len(corpus["segments"]),
        "formula_source": source_material, "formula_count": len(records),
        "formula_ids": [r["formula_id"] for r in records], "records": records,
        "materials": [{"material": m["material"], "kind": m["kind"], "bytes": m["bytes"],
                       "segments": m["segments"], "tables": m["tables"],
                       "text_method": m["text_method"]} for m in corpus["materials"]],
        "segments": corpus["segments"],
    }
    IOP.jdump(work / "index.json", index)
    IOP.jdump(work / "formulas_source.json", {"source_material": source_material,
                                              "records": records})
    if records:
        status = "partial"
    elif case_err:
        status = "input_error"
    else:
        status = "insufficient_evidence"
        degradations.append("no formula representation (publisher MathML) found in the supplied "
                            "materials; formulas must not be back-derived from prose")
    pending = []
    if records:
        pending.append("Agent must read materials (show) and write %s with formulas, variables, "
                       "derivations and numeric_checks" % (work / "draft.json"))
    elif not case_err:
        pending.append("Report the missing formula representation honestly as partial/"
                       "insufficient_evidence; do not invent formulas or substitute 0")
    doc = MCL.base_result(case, corpus, records, source_material, status, formulas, [], [], [],
                          [], pending, errors, degradations)
    IOP.jdump(out / "result.json", IOP.echo_contract(contract, doc))
    print("init: case_id=%s formulas=%d source=%s materials=%d segments=%d"
          % (index["case_id"], len(records), source_material, index["material_count"],
             index["segment_count"]))
    for record in records:
        print("  formula %-10s eq=%-6s structure=%s latex=%s"
              % (record["formula_id"], record.get("eq_number"),
                 json.dumps(record.get("structure", {})), record.get("latex", "")[:80]))
    if not records:
        print("  NOTE: no formula representation found; result will stay insufficient_evidence")
    print("next: python3 scripts/main.py show ; write work/draft.json ; check ; build")


def cmd_show(args):
    work = Path(args.work)
    index = IOP.jload(work / "index.json")
    if not index:
        cmd_init(args)
        index = IOP.jload(work / "index.json") or {}
    print("== case %s | formulas=%s source=%s materials=%s segments=%s =="
          % (index.get("case_id"), index.get("formula_count"), index.get("formula_source"),
             index.get("material_count"), index.get("segment_count")))
    print("\n== formula objects from the supplied publisher XML ==")
    for record in index.get("records", []):
        print("- formula_id=%s eq=%s structure=%s" % (record.get("formula_id"),
                                                      record.get("eq_number"),
                                                      json.dumps(record.get("structure", {}))))
        print("  latex: %s" % record.get("latex"))
        print("  symbols: %s" % json.dumps(record.get("symbols", {})))
        print("  source: %s" % json.dumps(record.get("source", {})))
    print("\n== materials ==")
    for mat in index.get("materials", []):
        print("- %-46s kind=%-9s bytes=%s seg=%s method=%s"
              % (mat.get("material"), mat.get("kind"), mat.get("bytes"), mat.get("segments"),
                 mat.get("text_method")))
    budget = max(1000, int(args.limit))
    used = 0
    print("\n== segments (locator :: text) ==")
    for seg in index.get("segments", []):
        if args.material and args.material not in seg.get("material", ""):
            continue
        block = "--- %s :: %s :: section=%s :: page=%s ---\n%s\n" % (
            seg.get("material"), seg.get("paragraph_id"), seg.get("section"),
            seg.get("page"), seg.get("text"))
        if used + len(block) > budget:
            print("... truncated at %d chars; use --limit/--material" % used)
            break
        sys.stdout.write(block)
        used += len(block)
    print("\n[shown %d chars] copy definition quotes verbatim from above" % used)


def cmd_check(args):
    work = Path(args.work)
    index = IOP.jload(work / "index.json") or {}
    corpus, records, _s, _n = source_context(args)
    if not corpus.get("segments") and index.get("segments"):
        corpus["segments"] = index["segments"]
    record_map = {r["formula_id"]: r for r in records}
    draft, draft_err = MCL.load_draft(work)
    fails, warns = [], []
    if draft is None:
        fails.append(draft_err)
    formulas = MCL.draft_list(draft, MCL.FORMULA_KEYS)
    variables = MCL.draft_list(draft, ("variables", "symbols", "symbol_table"))
    derivations = MCL.draft_list(draft, ("derivations", "derived_steps"))
    checks = MCL.draft_list(draft, ("numeric_checks", "numeric_verification", "checks"))
    ids = [f.get("formula_id") for f in formulas]
    missing = [fid for fid in record_map if fid not in ids]
    extra = [fid for fid in ids if fid and fid not in record_map]
    if missing:
        fails.append("formulas from the source XML missing in the draft: " + ", ".join(missing))
    if extra:
        warns.append("draft formulas not present in the source XML: " + ", ".join(str(x) for x in extra))
    for raw in formulas:
        formula = MCL.normalize_formula(raw, record_map.get(raw.get("formula_id")))
        f_fails, f_warns = MCL.evaluate_formula(formula, record_map.get(formula.get("formula_id")))
        fails.extend(f_fails)
        warns.extend(f_warns)
    symbols = [MCL.normalize_variable(raw) for raw in variables]
    for variable in symbols:
        f_fails, f_warns = MCL.evaluate_variable(variable, corpus)
        fails.extend(f_fails)
        warns.extend(f_warns)
    for record in records:
        for sym in MCL.missing_symbols(record, [v.get("symbol") for v in symbols]):
            fails.append("symbol '%s' used in formula %s is not defined in the symbol table"
                         % (sym, record["formula_id"]))
    for raw in derivations:
        f_fails, f_warns = MCL.evaluate_derivation(MCL.normalize_derivation(raw), set(record_map))
        fails.extend(f_fails)
        warns.extend(f_warns)
    recomputed = {}
    for raw in checks:
        check = MCL.normalize_check(raw)
        f_fails, f_warns, value = MCL.numeric_verdict(check)
        fails.extend(f_fails)
        warns.extend(f_warns)
        if value is not None:
            recomputed[check.get("check_id") or "?"] = value
    report = {"ok": not fails, "fail": fails, "warn": warns,
              "formulas_in_source": len(record_map), "formulas_in_draft": len(formulas),
              "formula_ids_missing": missing, "variables": len(symbols),
              "derivations": len(derivations), "numeric_checks": len(checks),
              "recomputed": recomputed}
    IOP.jdump(work / "check_report.json", report)
    print("check: %s | formulas=%d/%d variables=%d derivations=%d numeric_checks=%d"
          % ("PASS" if report["ok"] else "FAIL", len(formulas), len(record_map),
             len(symbols), len(derivations), len(checks)))
    for message in fails[:20]:
        print("  FAIL " + message)
    for message in warns[:15]:
        print("  WARN " + message)
    if not fails:
        print("ready: build emits result.json + formulas.tex + symbol_table.csv + numeric_checks.json")


def cmd_build(args):
    work, out = Path(args.work), Path(args.output)
    IOP.ensure_dir(work)
    IOP.ensure_dir(out)
    case, case_err = MCL.read_case(args.input)
    contract = case.get("output_contract") if isinstance(case, dict) else {}
    corpus, mml_records, mml_source, mml_notes = source_context(args)
    records, source_material = mml_records, mml_source
    degradations = list(corpus.get("degradations", [])) + list(mml_notes)
    errors = [case_err] if case_err else []
    draft, draft_err = MCL.load_draft(work)
    check_report = IOP.jload(work / "check_report.json") or {}
    formulas, variables, derivations, checks, uncertainties = [], [], [], [], []
    symbols_full = []
    if draft is None:
        degradations.append("no usable draft (%s); using the deterministic XML derive" % draft_err)
        bundle = MDER.derive_bundle(args.input)
        degradations.extend(bundle["notes"])
        if bundle["found"]:
            records = bundle["records"]
            source_material = bundle["source_material"]
            formulas = bundle["formulas"]
            variables = bundle["variables"]
            derivations = bundle["derivations"]
            checks = bundle["checks"]
            symbols_full = bundle["symbols_full"]
        else:
            degradations.append("no formula nodes to derive; derivation/recomputation of the "
                                "missing object is not possible")
    else:
        record_map = {r["formula_id"]: r for r in records}
        for record in records:
            raw = None
            for candidate in MCL.draft_list(draft, MCL.FORMULA_KEYS):
                if candidate.get("formula_id") == record["formula_id"]:
                    raw = candidate
                    break
            formula = MCL.normalize_formula(raw or {}, record)
            v_fails, v_warns = MCL.evaluate_formula(formula, record if formula.get("latex") else None)
            if raw is None:
                formula["notes"] = "taken from publisher XML; no agent formula object in draft"
                degradations.append("formula %s re-extracted from XML (not in draft)"
                                    % record["formula_id"])
            if v_fails:
                formula["validation"] = {"ok": False, "fails": v_fails}
                degradations.append("formula %s validation: %s" % (record["formula_id"], v_fails[0]))
            elif v_warns:
                formula["validation"] = {"ok": True, "warns": v_warns}
            else:
                formula["validation"] = {"ok": True, "fails": [], "warns": []}
            formulas.append(formula)
        for candidate in MCL.draft_list(draft, MCL.FORMULA_KEYS):
            fid = candidate.get("formula_id")
            if fid and fid not in record_map:
                formula = MCL.normalize_formula(candidate, None)
                formula["validation"] = {"ok": False,
                                         "fails": ["not present in the supplied publisher XML"]}
                formulas.append(formula)
                degradations.append("unsourced formula kept but marked: %s" % fid)
        variables = [MCL.normalize_variable(raw) for raw in
                     MCL.draft_list(draft, ("variables", "symbols", "symbol_table"))]
        derivations = [MCL.normalize_derivation(raw) for raw in
                       MCL.draft_list(draft, ("derivations", "derived_steps"))]
        checks = [MCL.normalize_check(raw) for raw in
                  MCL.draft_list(draft, ("numeric_checks", "numeric_verification", "checks"))]
        if isinstance(draft.get("uncertainties"), list):
            uncertainties.extend(draft["uncertainties"])
    for variable in variables:
        if draft is None:
            continue
        v_fails, _w = MCL.evaluate_variable(variable, corpus)
        if v_fails:
            variable["validation"] = {"ok": False, "fails": v_fails}
            degradations.append("variable %s validation: %s" % (variable.get("symbol"), v_fails[0]))
        else:
            variable["validation"] = {"ok": True}
    recomputed = {}
    for check in checks:
        c_fails, c_warns, value = MCL.numeric_verdict(check)
        if value is not None:
            recomputed[check.get("check_id") or "?"] = value
            check["recomputed"] = value
        if c_fails:
            check["validation"] = {"ok": False, "fails": c_fails}
            degradations.append("numeric check %s: %s" % (check.get("check_id"), c_fails[0]))
        elif c_warns:
            check["validation"] = {"ok": True, "warns": c_warns}
        else:
            check["validation"] = {"ok": True}
    coverage = MCL.coverage_of(records, formulas, variables, derivations, checks)
    if not case:
        status = "input_error"
    elif not records:
        status = "insufficient_evidence"
        degradations.append("no formula representation in the supplied materials; formulas, "
                            "derivations and numeric checks were not invented")
    elif draft is None:
        status = "partial"
        degradations.append("deterministic XML derive produced formulas, symbol table, structural "
                            "derivation and constant-only numeric checks; symbol definitions and "
                            "a semantic derivation still need paper review")
    elif coverage["complete"] and MCL.terminal(formulas, variables) and check_report.get("ok"):
        status = "ok"
    else:
        status = "partial"
    pending_human = []
    if status != "ok":
        pending_human.append("Review degradations, finish the symbol table/derivations and re-run "
                             "check+build")
    claims = MCL.build_claims(records, formulas, variables, derivations, checks,
                              source_material, corpus)
    doc = MCL.base_result(case, corpus, records, source_material, status, formulas, variables,
                          derivations, checks, uncertainties, pending_human, errors, degradations,
                          {"validation": check_report, "recomputed": recomputed})
    doc["claims"] = claims
    IOP.jdump(out / "result.json", IOP.echo_contract(contract, doc))
    tex_err = MDER.write_tex(out / "formulas.tex", PKG_NAME, VERSION, source_material, formulas)
    if tex_err:
        degradations.append("formulas.tex failed: %s" % tex_err)
    pdf_method, pdf_msg = MDER.render_formulas_pdf(out / "formulas.tex", out)
    pdf_ok = (out / "formulas.pdf").exists() and (out / "formulas.pdf").stat().st_size > 0
    if not pdf_ok:
        degradations.append("formulas.pdf failed: %s" % pdf_msg)
    output_files = {name: str(out / name) for name in PRODUCTS}
    content_map = MCL.build_content_map(MCL.case_id_of(case), formulas, variables, derivations,
                                        checks, source_material, output_files)
    content_map["pdf_export"] = {"method": pdf_method, "note": pdf_msg, "ok": pdf_ok}
    map_err = MDER.write_content_map(out / "content_map.json", content_map)
    if map_err:
        degradations.append("content_map.json failed: %s" % map_err)
    csv_err = MDER.write_symbol_csv(out / "symbol_table.csv", variables, symbols_full)
    if csv_err:
        degradations.append("symbol_table.csv failed: %s" % csv_err)
    dir_err = MDER.write_formula_directory(out / "formula_directory.md", formulas, derivations,
                                           checks, source_material, status)
    if dir_err:
        degradations.append("formula_directory.md failed: %s" % dir_err)
    IOP.jdump(out / "symbol_table.json", {
        "note": "all mi/mo/mn/mtext tokens with LaTeX, role and source locator; variables keep "
                "empty definitions when the formula representation carries none",
        "source_material": source_material,
        "tokens": symbols_full,
        "variables": variables,
    })
    IOP.jdump(out / "numeric_checks.json", {
        "checks": checks, "recomputed": recomputed,
        "note": "computed values re-derived by the sandboxed evaluator; a mismatch is a failure"})
    notes_err = MDER.write_derivation_notes(out / "derivation_notes.md", doc["case_id"], status,
                                            source_material, formulas, variables, derivations,
                                            checks, degradations)
    if notes_err:
        degradations.append("derivation_notes.md failed: %s" % notes_err)
    IOP.jdump(work / "build_summary.json", {"case_id": doc["case_id"], "status": status,
                                            "coverage": coverage, "degradations": degradations})
    print("build: status=%s case_id=%s formulas=%d variables=%d derivations=%d checks=%d claims=%d"
          % (status, doc["case_id"], len(formulas), len(variables), len(derivations), len(checks),
             len(claims)))
    print("  coverage: formulas %d/%d variables %d/%d missing_formulas=%s missing_symbols=%s"
          % (coverage["formulas_parsed"], coverage["formulas_in_source"],
             coverage["variables_defined"], coverage["variables_expected"],
             coverage["missing_formula_ids"], coverage["missing_symbols"]))
    for name in PRODUCTS:
        path = out / name
        print("  %-24s %s bytes" % (name, path.stat().st_size if path.exists() else "MISSING"))
    for item in degradations[:8]:
        print("  degrade: " + str(item)[:200])


def cmd_selfcheck(args):
    work, out = Path(args.work), Path(args.output)
    case, _ = MCL.read_case(args.input)
    contract = case.get("output_contract") if isinstance(case, dict) else {}
    result = IOP.jload(out / "result.json")
    problems = []
    if not isinstance(result, dict):
        problems.append("output/result.json missing or invalid")
        result = {}
    for key in IOP.contract_keys(contract):
        if key not in result:
            problems.append("contract key missing: " + key)
    if result.get("case_id") != MCL.case_id_of(case):
        problems.append("case_id mismatch: %r vs %r" % (result.get("case_id"),
                                                       MCL.case_id_of(case)))
    records = MML.load_source_formulas(args.input)[0]
    record_map = {r["formula_id"]: r for r in records}
    formulas = (result.get("result") or {}).get("formulas") or []
    for formula in formulas:
        fid = formula.get("formula_id")
        if fid in record_map:
            parsed = MCL.latex_structure(formula.get("latex") or "")
            expected = record_map[fid].get("structure") or {}
            if parsed["fracs"] != expected.get("fracs", 0):
                problems.append("formula %s: frac count drifted" % fid)
            if not parsed["brace_balance"]:
                problems.append("formula %s: unbalanced braces" % fid)
    for name in PRODUCTS:
        if not (out / name).exists():
            problems.append("missing deliverable: " + name)
    coverage = (result.get("result") or {}).get("coverage") or {}
    if coverage.get("missing_formula_ids"):
        problems.append("missing formula ids: %s" % coverage["missing_formula_ids"])
    report = {"ok": not problems, "problems": problems,
              "contract_keys": IOP.contract_keys(contract), "formulas": len(formulas),
              "formulas_in_source": len(record_map)}
    IOP.jdump(work / "selfcheck_report.json", report)
    print("selfcheck: %s | contract_keys=%d formulas=%d/%d"
          % ("PASS" if report["ok"] else "FAIL", len(report["contract_keys"]),
             len(formulas), len(record_map)))
    for item in problems[:15]:
        print("  FAIL " + str(item))


class SafeParser(argparse.ArgumentParser):
    def error(self, message):
        print("argument warning: " + message)
        self.print_help()
        sys.exit(0)


def add_paths(parser):
    parser.add_argument("--input", default=argparse.SUPPRESS, help="input dir (default /input)")
    parser.add_argument("--work", default=argparse.SUPPRESS, help="work dir (default /app/work)")
    parser.add_argument("--output", default=argparse.SUPPRESS, help="output dir (default /app/output)")


def build_parser():
    parser = SafeParser(prog="main.py", description="Mathematical expression interpretation skill")
    parser.add_argument("--input", default="/input")
    parser.add_argument("--work", default="/app/work")
    parser.add_argument("--output", default="/app/output")
    parser.add_argument("--version", action="version", version=PKG_NAME + " " + VERSION)
    sub = parser.add_subparsers(dest="command")
    for name, help_text in (("init", "scan input, parse MathML, write partial result.json"),
                            ("show", "print formulas and materials with locators"),
                            ("check", "validate the agent draft"),
                            ("build", "assemble deliverables and finalize result.json"),
                            ("selfcheck", "re-verify the finished result.json")):
        child = sub.add_parser(name, help=help_text)
        add_paths(child)
        if name == "show":
            child.add_argument("--material", default="", help="filter by material substring")
            child.add_argument("--limit", default="60000", help="max characters printed")
    return parser


def emergency_finalize(args, exc_text):
    try:
        work = Path(getattr(args, "work", "/app/work"))
        out = Path(getattr(args, "output", "/app/output"))
        IOP.ensure_dir(work)
        IOP.ensure_dir(out)
        case, _ = MCL.read_case(Path(getattr(args, "input", "/input")))
        contract = case.get("output_contract") if isinstance(case, dict) else {}
        doc = {
            "case_id": MCL.case_id_of(case), "status": "input_error",
            "result": {"formulas": [], "variables": [], "derivations": [], "numeric_checks": [],
                       "coverage": MCL.coverage_of([], [], [], [], []),
                       "method_notes": {"skill": PKG_NAME, "version": VERSION}},
            "claims": [], "uncertainties": [], "sources": [],
            "pending_human": ["Unexpected skill error; inspect errors and rerun init/show/check/build"],
            "errors": [exc_text[:2000]], "degradations": ["emergency_finalize used"],
            "deliverables": {},
        }
        IOP.jdump(out / "result.json", IOP.echo_contract(contract, doc))
    except Exception:
        pass


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    args.input = Path(getattr(args, "input", "/input"))
    args.work = Path(getattr(args, "work", "/app/work"))
    args.output = Path(getattr(args, "output", "/app/output"))
    command = getattr(args, "command", None)
    try:
        if command == "init":
            cmd_init(args)
        elif command == "show":
            cmd_show(args)
        elif command == "check":
            cmd_check(args)
        elif command == "build":
            cmd_build(args)
        elif command == "selfcheck":
            cmd_selfcheck(args)
        else:
            parser.print_help()
    except SystemExit:
        raise
    except BaseException as exc:
        traceback.print_exc()
        emergency_finalize(args, "%s: %s" % (type(exc).__name__, exc))
    return 0


def _emit_assets_post():
    try:
        import assets as _a
        _a.emit_from_argv()
    except Exception:
        pass


if __name__ == "__main__":
    try:
        import atexit as _atexit
        _atexit.register(_emit_assets_post)
    except Exception:
        pass

    try:
        main()
    except SystemExit:
        raise
    except BaseException:
        traceback.print_exc()
    sys.exit(0)

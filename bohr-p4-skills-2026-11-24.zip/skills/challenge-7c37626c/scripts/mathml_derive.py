# -*- coding: utf-8 -*-
"""Deterministic MathML -> LaTeX derive (no agent draft required).

This module turns the actual formula nodes found in /input (source-formulas.xml,
publisher-source.xml or any .xml/.mathml) into a complete derive bundle:
    * per-formula records with LaTeX, source_id, structure counters and symbols,
    * a full symbol table over every mi/mo/mn/mtext token (symbol/latex/role),
    * identifier variable entries (definitions left empty, basis inferred),
    * structural derivation steps (the deterministic XML tree expansion), and
    * constant-only numeric checks computed with the stdlib `math` sandbox.

Nothing is invented: a symbolic sub-expression is never given a value, and when no
formula node exists the bundle is empty (status handled by the caller).
"""
import csv
import io
import json
import math
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

import math_check_lib as MCL
import mml_lib as MML

XML_ID = "{http://www.w3.org/XML/1998/namespace}id"

TAG_NOTE = {
    "mfrac": "fraction: numerator over denominator",
    "msub": "subscript",
    "msup": "superscript (power)",
    "msubsup": "sub- and superscript combined",
    "msqrt": "square root (covers the whole child expression)",
    "mroot": "n-th root",
    "mrow": "horizontal grouping (concatenation of children)",
    "mstyle": "style/scope wrapper (concatenation)",
    "mfenced": "parenthesized group (open/close attributes)",
    "mtable": "table/matrix layout",
    "mtr": "table row",
    "mtd": "table cell",
    "mover": "accent or overset",
    "munder": "underscript",
    "munderover": "under- and overscript",
    "mi": "identifier token",
    "mn": "number literal token",
    "mo": "operator token",
    "mtext": "text token",
    "mspace": "spacing token",
}
ARITH_MO = {"+": "+", "-": "-", "\u2212": "-", "\u2212": "-", "−": "-", "*": "*",
            "\u00d7": "*", "\u00b7": "*", "·": "*", "/": "/", "(": "(", ")": ")"}


def _local(tag):
    return MML.local(tag)


def _kids(el):
    return MML.kids(el)


def walk_math_full(root):
    """Like mml_lib.walk_math but also captures xml:id and @source attributes."""
    found = []

    def walk(el, ctx):
        tag = _local(el.tag)
        if tag == "math":
            found.append((el, dict(ctx)))
            return
        child_ctx = dict(ctx)
        if el.get("id"):
            child_ctx["id"] = el.get("id")
        if el.get("number"):
            child_ctx["number"] = el.get("number")
        xml_id = el.get(XML_ID)
        if xml_id:
            child_ctx["xml_id"] = xml_id
        source_attr = el.get("source")
        if source_attr:
            child_ctx["source_attr"] = source_attr
        if tag == "label" and not child_ctx.get("label"):
            child_ctx["label"] = (el.text or "").strip()
        for child in list(el):
            if _local(child.tag) == "label" and not child_ctx.get("label"):
                child_ctx["label"] = (child.text or "").strip()
        for child in list(el):
            walk(child, child_ctx)

    walk(root, {})
    return found


def token_latex(tag, text):
    if tag == "mi":
        return MML.mi_latex(text)
    if tag == "mn":
        return MML.escape_tex((text or "").strip())
    if tag == "mo":
        return MML.mo_latex(text)
    if tag == "mtext":
        return "\\text{%s}" % MML.escape_tex((text or "").strip())
    return MML.escape_tex((text or "").strip())


def collect_tokens(math_el, fid, locator, material):
    """One entry per distinct (formula, role, symbol, latex) token with occurrence count."""
    seen, ordered = {}, []
    for node in math_el.iter():
        tag = _local(node.tag)
        if tag not in ("mi", "mn", "mo", "mtext"):
            continue
        text = (node.text or "").strip()
        if not text:
            continue
        role = {"mi": "identifier", "mn": "number", "mo": "operator", "mtext": "text"}[tag]
        key = (fid, role, text, token_latex(tag, text))
        if key in seen:
            seen[key]["count"] += 1
            continue
        entry = {
            "symbol": text,
            "latex": token_latex(tag, text),
            "role": role,
            "source_id": locator,
            "formula_id": fid,
            "material": material,
            "count": 1,
        }
        seen[key] = entry
        ordered.append(entry)
    return ordered


def structural_derivation(math_el, fid, latex):
    """Deterministic structural expansion of the XML tree into checkable steps."""
    steps = []

    def rec(el, path):
        tag = _local(el.tag)
        if tag in ("math", "semantics"):
            for child in _kids(el):
                rec(child, path)
            return
        steps.append({
            "step_no": len(steps) + 1,
            "tag": tag,
            "path": path,
            "latex_fragment": MML.mml_to_latex(el),
            "note": TAG_NOTE.get(tag, "MathML element: %s" % tag),
        })
        for child in _kids(el):
            rec(child, path + ">" + tag)

    rec(math_el, "math")
    steps.append({
        "step_no": len(steps) + 1,
        "tag": "formula",
        "path": "math",
        "latex_fragment": latex,
        "note": "complete deterministic LaTeX rendering of the MathML tree",
    })
    return {
        "derivation_id": "D-%s-structure" % fid,
        "formula_id": fid,
        "depends_on": [fid],
        "steps": steps,
        "assumptions": [],
        "approximations": [],
        "boundary_conditions": [],
        "provenance": "structural expansion of the supplied MathML (not a semantic paper derivation)",
        "notes": "each step records the MathML node and its rendered LaTeX fragment; "
                 "assumptions are not inferred because the formula representation carries none",
    }


def _number(text):
    t = (text or "").strip()
    if not t:
        return None
    try:
        float(t.replace(",", ""))
        return t.replace(",", "")
    except Exception:
        return None


def numeric_expr(el):
    """Return (arithmetic_expression, kind) for a constant-only subtree, else None.

    kind is one of 'number', 'op', 'compound'. Symbolic tokens (mi/mtext) make the
    subtree non-numeric. Juxtaposition of two values without an operator is refused.
    """
    tag = _local(el.tag)
    if tag == "mn":
        num = _number(el.text)
        return (num, "number") if num is not None else None
    if tag == "mo":
        t = (el.text or "").strip()
        return (ARITH_MO[t], "op") if t in ARITH_MO else None
    if tag in ("mi", "mtext"):
        return None
    if tag in ("mrow", "mstyle", "mpadded", "mphantom", "menclose", "mtd", "mtr", "math",
               "semantics", "merror"):
        parts = []
        for child in _kids(el):
            res = numeric_expr(child)
            if res is None:
                return None
            expr, kind = res
            if kind != "op" and parts and parts[-1][1] != "op":
                return None
            parts.append((expr, kind))
        if not parts or parts[0][1] == "op" or parts[-1][1] == "op":
            return None
        return "".join(p[0] for p in parts), "compound"
    if tag == "mfrac":
        ch = _kids(el)
        if len(ch) < 2:
            return None
        num = numeric_expr(ch[0])
        den = numeric_expr(ch[1])
        if num is None or den is None:
            return None
        return "((%s)/(%s))" % (num[0], den[0]), "compound"
    if tag == "msqrt":
        ch = _kids(el)
        if not ch:
            return None
        inner = numeric_expr(ch[0])
        return ("(sqrt(%s))" % inner[0], "compound") if inner is not None else None
    if tag == "mroot":
        ch = _kids(el)
        if len(ch) < 2:
            return None
        base = numeric_expr(ch[0])
        index = numeric_expr(ch[1])
        if base is None or index is None:
            return None
        return "((%s)**(1.0/(%s)))" % (base[0], index[0]), "compound"
    if tag == "msup":
        ch = _kids(el)
        if len(ch) < 2:
            return None
        base = numeric_expr(ch[0])
        expo = numeric_expr(ch[1])
        if base is None or expo is None:
            return None
        return "((%s)**(%s))" % (base[0], expo[0]), "compound"
    if tag in ("msub", "msubsup", "munder", "mover", "munderover", "mfenced", "mtable"):
        return None
    ch = _kids(el)
    if not ch:
        return None
    parts = []
    for child in ch:
        res = numeric_expr(child)
        if res is None:
            return None
        expr, kind = res
        if kind != "op" and parts and parts[-1][1] != "op":
            return None
        parts.append((expr, kind))
    if not parts or parts[0][1] == "op" or parts[-1][1] == "op":
        return None
    return "".join(p[0] for p in parts), "compound"


def _has_mn(el):
    return any(_local(node.tag) == "mn" for node in el.iter())


def _has_arithmetic(expr):
    return any(ch in expr for ch in "+-*/") or "sqrt(" in expr or "**" in expr


def _contains(ancestor, node):
    return node is not ancestor and any(item is node for item in ancestor.iter())


def numeric_checks(math_el, fid):
    """Recompute the maximal constant-only arithmetic sub-expressions, nothing else."""
    candidates = []

    def rec(el):
        res = numeric_expr(el)
        if res is not None and res[1] == "compound" and _has_mn(el) and _has_arithmetic(res[0]):
            candidates.append((el, res[0]))
        for child in _kids(el):
            rec(child)

    rec(math_el)
    keep = []
    for el, expr in candidates:
        if not any(el is not other and _contains(other, el) for other, _ in candidates):
            keep.append((el, expr))
    out = []
    for idx, (el, expr) in enumerate(keep):
        try:
            value = MCL.safe_eval(expr, {})
        except Exception:
            continue
        out.append({
            "check_id": "N-%s-%d" % (fid, idx + 1),
            "formula_id": fid,
            "expression": expr,
            "substitutions": {},
            "computed": round(float(value), 12),
            "expected": None,
            "tolerance": None,
            "unit": "-",
            "result": "pass",
            "assumptions": ["the evaluated sub-expression contains only constants present in "
                            "the MathML tree"],
            "notes": "deterministic recomputation of a constant-only sub-expression; no invented "
                     "substitutions",
            "validation": {"ok": True},
        })
    return out


def build_variables(symbols_full):
    """Identifier entries for result.variables; definitions stay empty (not invented)."""
    by_sym, order = {}, []
    for tok in symbols_full:
        if tok["role"] != "identifier":
            continue
        sym = tok["symbol"]
        if sym in MML.FUNC_NAMES and sym != "d":
            continue
        if sym not in by_sym:
            by_sym[sym] = {
                "symbol": sym,
                "latex": tok["latex"],
                "source_id": tok["source_id"],
                "material": tok["material"],
                "formula_ids": [],
            }
            order.append(sym)
        if tok["formula_id"] not in by_sym[sym]["formula_ids"]:
            by_sym[sym]["formula_ids"].append(tok["formula_id"])
    variables = []
    for sym in order:
        info = by_sym[sym]
        variables.append({
            "symbol": sym,
            "latex": info["latex"],
            "definition": "",
            "unit": "-",
            "range": "",
            "definition_basis": "inferred",
            "source": {"material": info["material"], "node_id": info["source_id"]},
            "quote": "",
            "inference_reason": "identifier token read from the MathML formula nodes; the paper "
                                "definition is not attached to the formula representation",
            "formula_ids": info["formula_ids"],
            "validation": {"ok": True, "warns": ["definition not available from the formula "
                                                  "representation alone"]},
        })
    return variables


def derive_bundle(input_dir):
    """Scan /input for XML sources and build the full deterministic derive bundle."""
    notes = []
    chosen = None
    math_pairs = []
    for rel, path in MML.find_formula_sources(input_dir):
        if chosen is None:
            chosen = rel
        try:
            root = ET.parse(str(path)).getroot()
        except Exception as exc:
            notes.append("%s: xml_parse_failed: %s" % (rel, exc))
            continue
        pairs = walk_math_full(root)
        if pairs:
            chosen = rel
            math_pairs = pairs
            break
        notes.append("no MathML formula nodes in %s" % rel)
    if not math_pairs:
        notes.append("no MathML formula nodes found in any XML source under input; "
                     "derivation/recomputation of a missing object is not possible")
        return {
            "found": False,
            "records": [],
            "formulas": [],
            "variables": [],
            "symbols_full": [],
            "derivations": [],
            "checks": [],
            "source_material": chosen,
            "notes": notes,
        }

    records, symbols_full, variables, derivations, checks = [], [], [], [], []
    seen = set()
    n = 0
    for math_el, ctx in math_pairs:
        n += 1
        latex = MML.tex_annotation(math_el) or MML.mml_to_latex(math_el)
        annotation = MML.has_tex_annotation(math_el)
        raw_fid = ctx.get("id") or ctx.get("xml_id") or ctx.get("label") or ("eq%d" % n)
        fid = str(raw_fid).strip().strip("()")
        if not fid or fid in seen:
            fid = "%s_%d" % (fid or "eq", n)
        seen.add(fid)
        locator = str(ctx.get("id") or ctx.get("xml_id") or ctx.get("source_attr") or fid)
        eq_number = str(ctx.get("label") or ctx.get("number") or "").strip()
        tokens = collect_tokens(math_el, fid, locator, chosen)
        symbols_full.extend(tokens)
        derivation = structural_derivation(math_el, fid, latex)
        derivations.append(derivation)
        formula_checks = numeric_checks(math_el, fid)
        checks.extend(formula_checks)
        records.append({
            "formula_id": fid,
            "eq_number": eq_number,
            "latex": latex,
            "annotation_tex": annotation,
            "structure": MML.structure_of(math_el),
            "symbols": MML.collect_symbols(math_el),
            "source_id": locator,
            "source": {"material": chosen, "node_id": locator},
            "parse_confidence": 1.0 if annotation else 0.9,
            "derivation_id": derivation["derivation_id"],
            "numeric_verification": "verified" if formula_checks else "not_applicable",
            "numeric_verification_reason": (
                "constant-only sub-expressions recomputed deterministically"
                if formula_checks else
                "formula contains symbolic unknowns; no constant-only arithmetic sub-expression "
                "was found, so no numeric value was invented"),
            "notation_notes": "deterministically derived from the supplied MathML (no agent draft)",
            "validation": {"ok": True, "fails": [], "warns": []},
        })
    try:
        MML.attach_verbatim(records, path)
    except Exception:
        pass
    variables = build_variables(symbols_full)
    notes.append("derived %d formula(s), %d symbol token(s), %d identifier variable(s), "
                 "%d constant-only numeric check(s) from %s"
                 % (len(records), len(symbols_full), len(variables), len(checks), chosen))
    return {
        "found": True,
        "records": records,
        "formulas": records,
        "variables": variables,
        "symbols_full": symbols_full,
        "derivations": derivations,
        "checks": checks,
        "source_material": chosen,
        "notes": notes,
    }


def write_symbol_csv(path, variables, symbols_full):
    """Write symbol_table.csv; full token view when available, else variable view."""
    try:
        with open(path, "w", encoding="utf-8-sig", newline="") as fh:
            writer = csv.writer(fh)
            if symbols_full:
                var_by_sym = {var.get("symbol"): var for var in variables}
                writer.writerow(["symbol", "latex", "role", "count", "source_id", "formula_id",
                                 "material", "definition", "unit", "range", "definition_basis"])
                for tok in symbols_full:
                    var = var_by_sym.get(tok["symbol"], {})
                    writer.writerow([tok["symbol"], tok["latex"], tok["role"], tok["count"],
                                     tok["source_id"], tok["formula_id"], tok["material"],
                                     var.get("definition", ""), var.get("unit", "-"),
                                     var.get("range", ""), var.get("definition_basis", "")])
            else:
                writer.writerow(["symbol", "definition", "unit", "range", "definition_basis",
                                 "material", "paragraph_id", "page", "formula_ids", "quote",
                                 "validation"])
                for var in variables:
                    src = var.get("source") or {}
                    writer.writerow([var.get("symbol"), var.get("definition"), var.get("unit"),
                                     var.get("range"), var.get("definition_basis"),
                                     src.get("material"), src.get("paragraph_id"), src.get("page"),
                                     "|".join(str(x) for x in (var.get("formula_ids") or [])),
                                     var.get("quote"),
                                     "ok" if (var.get("validation") or {}).get("ok") else "failed"])
    except Exception as exc:
        return str(exc)
    return ""


def write_formula_directory(path, formulas, derivations, checks, source_material, status):
    """Write formula_directory.md with LaTeX, source, derivation steps and checks."""
    lines = ["# Formula directory", "",
             "- source: `%s`" % (source_material or "none"),
             "- status: **%s**" % status,
             "- method: deterministic MathML -> LaTeX derive (structural expansion only)", ""]
    for formula in formulas:
        fid = formula.get("formula_id")
        lines.append("## formula_id=%s eq=%s" % (fid, formula.get("eq_number") or ""))
        lines.append("- latex: `%s`" % (formula.get("latex") or ""))
        lines.append("- source: `%s` | source_id: `%s`" % (
            (formula.get("source") or {}).get("material") or "-",
            formula.get("source_id") or "-"))
        lines.append("- structure: %s" % json.dumps(formula.get("structure") or {}))
        lines.append("- identifiers: %s" % json.dumps(
            (formula.get("symbols") or {}).get("identifiers") or []))
        lines.append("- numeric_verification: **%s** (%s)"
                     % (formula.get("numeric_verification"),
                        formula.get("numeric_verification_reason")))
        steps = next((d.get("steps") or [] for d in derivations
                      if d.get("formula_id") == fid), [])
        lines.append("- derivation steps:")
        for step in steps:
            lines.append("  %d. `%s` [%s] -> `%s`"
                         % (step.get("step_no"), step.get("tag"), step.get("path"),
                            step.get("latex_fragment")))
        formula_checks = [c for c in checks if c.get("formula_id") == fid]
        if formula_checks:
            lines.append("- numeric checks:")
            for check in formula_checks:
                lines.append("  - `%s`: %s = %s"
                             % (check.get("check_id"), check.get("expression"),
                                check.get("computed")))
        lines.append("")
    try:
        Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")
        return ""
    except Exception as exc:
        return str(exc)


def write_tex(path, pkg, version, source_material, formulas):
    """Write the editable formulas.tex directory with per-formula source comments."""
    tex = ["%% formulas.tex - generated by %s v%s" % (pkg, version),
           "%% source: %s" % (source_material or "none"), ""]
    for formula in formulas:
        tex.append("%% formula_id=%s eq=%s source=%s"
                   % (formula.get("formula_id"), formula.get("eq_number") or "",
                      (formula.get("source") or {}).get("material") or "-"))
        tex.append("\\begin{equation}")
        tex.append("  %s" % str(formula.get("latex") or "").strip())
        tex.append("\\end{equation}")
        tex.append("")
    try:
        Path(path).write_text("\n".join(tex) + "\n", encoding="utf-8")
        return ""
    except Exception as exc:
        return str(exc)


def write_derivation_notes(path, case_id, status, source_material, formulas, variables,
                           derivations, checks, degradations):
    """Write derivation_notes.md with steps, checks and degradations."""
    notes = ["# Derivation notes", "",
             "- case_id: `%s`" % case_id, "- status: **%s**" % status,
             "- formula source: `%s`" % (source_material or "none"),
             "- formulas: %d | variables: %d | derivations: %d | numeric checks: %d"
             % (len(formulas), len(variables), len(derivations), len(checks)), ""]
    for derivation in derivations:
        notes.append("## %s (formula %s)" % (derivation.get("derivation_id"),
                                             derivation.get("formula_id")))
        for step in derivation.get("steps") or []:
            notes.append("1. %s" % (step.get("latex_fragment") or step.get("statement_latex")
                                    or step.get("statement") or ""))
            if step.get("assumption"):
                notes.append("   - assumption: %s" % step.get("assumption"))
            if step.get("justification") or step.get("operation") or step.get("note"):
                notes.append("   - justification: %s"
                             % (step.get("justification") or step.get("operation")
                                or step.get("note")))
        if derivation.get("assumptions"):
            notes.append("- assumptions: %s" % "; ".join(str(a) for a in derivation["assumptions"]))
        if derivation.get("approximations"):
            notes.append("- approximations: %s" % "; ".join(str(a) for a in derivation["approximations"]))
        notes.append("")
    notes.append("## Numeric checks")
    for check in checks:
        notes.append("- `%s` formula=%s expression=%s computed=%s expected=%s result=%s"
                     % (check.get("check_id"), check.get("formula_id"), check.get("expression"),
                        check.get("computed"), check.get("expected"), check.get("result")))
    notes += ["", "## Degradations"]
    for item in degradations or ["none"]:
        notes.append("- " + str(item))
    try:
        Path(path).write_text("\n".join(notes) + "\n", encoding="utf-8")
        return ""
    except Exception as exc:
        return str(exc)


# ------------------------------------------------------------- PDF export
def _pdf_escape(text):
    return (text or "").replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _minimal_text_pdf(title, lines):
    """Build a minimal valid PDF 1.4 whose pages reproduce the given text lines."""
    pages, per_page = [], 52
    for start in range(0, len(lines), per_page):
        pages.append(lines[start:start + per_page])
    if not pages:
        pages = [[]]
    objects = []  # each entry: (object_number, body_bytes)

    def add(obj_num, body):
        objects.append((obj_num, body))
        return obj_num

    # Font object (fixed number 4)
    add(4, b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
    page_objects = []
    content_objects = []
    next_num = 5
    for block in pages:
        content = []
        content.append("BT /F1 9 Tf 40 760 Td 12 TL")
        for line in block:
            clean = _pdf_escape(line.encode("latin-1", "replace").decode("latin-1"))
            content.append("(%s) Tj T*" % clean)
        content.append("ET")
        stream = "\n".join(content)
        stream_bytes = stream.encode("latin-1", "replace")
        content_num = add(next_num, b"<< /Length %d >>\nstream\n" % len(stream_bytes) +
                          stream_bytes + b"\nendstream")
        next_num += 1
        content_objects.append(content_num)
    for content_num in content_objects:
        page_num = add(next_num, (
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
            "/Resources << /Font << /F1 4 0 R >> >> /Contents %d 0 R >>" % content_num)
            .encode("latin-1"))
        next_num += 1
        page_objects.append(page_num)
    kids = " ".join("%d 0 R" % n for n in page_objects)
    add(2, ("<< /Type /Pages /Kids [%s] /Count %d >>" % (kids, len(page_objects)))
        .encode("latin-1"))
    add(1, b"<< /Type /Catalog /Pages 2 0 R >>")

    objects.sort(key=lambda item: item[0])
    out = io.BytesIO()
    out.write(b"%PDF-1.4\n")
    offsets = {}
    for num, body in objects:
        offsets[num] = out.tell()
        out.write(b"%d 0 obj\n" % num)
        out.write(body)
        out.write(b"\nendobj\n")
    xref_pos = out.tell()
    count = max(offsets) + 1
    out.write(b"xref\n0 %d\n" % count)
    out.write(b"0000000000 65535 f \n")
    for num in range(1, count):
        out.write(b"%010d 00000 n \n" % offsets.get(num, 0))
    out.write(b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n"
              % (count, xref_pos))
    return out.getvalue()


def render_formulas_pdf(tex_path, out_dir):
    """Compile formulas.tex to formulas.pdf with a real TeX engine when available;
    otherwise write a minimal valid PDF that reproduces the LaTeX source verbatim.

    Returns (method, message) so the export method is recorded honestly."""
    tex = Path(tex_path)
    out_pdf = Path(out_dir) / "formulas.pdf"
    engines = [("tectonic", [None]), ("xelatex", ["-interaction=nonstopmode", "-halt-on-error"]),
               ("lualatex", ["-interaction=nonstopmode", "-halt-on-error"]),
               ("pdflatex", ["-interaction=nonstopmode", "-halt-on-error"]),
               ("latexmk", ["-pdf", "-interaction=nonstopmode"])]
    for engine, flags in engines:
        exe = shutil.which(engine)
        if not exe:
            continue
        try:
            with tempfile.TemporaryDirectory(prefix="texpdf_") as tmp:
                src = Path(tmp) / "formulas.tex"
                shutil.copy2(str(tex), str(src))
                cmd = [exe] + [f for f in flags if f] + [src.name]
                proc = subprocess.run(cmd, capture_output=True, timeout=120, cwd=tmp)
                candidate = Path(tmp) / "formulas.pdf"
                if proc.returncode == 0 and candidate.exists():
                    shutil.copy2(str(candidate), str(out_pdf))
                    return "latex:%s" % engine, "compiled formulas.tex with %s" % engine
        except Exception as exc:
            continue
    try:
        lines = tex.read_text(encoding="utf-8", errors="replace").splitlines() or [""]
    except Exception:
        lines = ["(formulas.tex unavailable)"]
    out_pdf.write_bytes(_minimal_text_pdf("formulas.tex", lines))
    return "text_pdf", ("no TeX engine found; formulas.pdf is a minimal valid PDF that "
                        "reproduces the formulas.tex source verbatim (not a typeset render)")


def write_content_map(path, content_map):
    """Serialize the content map to content_map.json."""
    try:
        Path(path).write_text(json.dumps(content_map, ensure_ascii=False, indent=2) + "\n",
                              encoding="utf-8")
        return ""
    except Exception as exc:
        return str(exc)

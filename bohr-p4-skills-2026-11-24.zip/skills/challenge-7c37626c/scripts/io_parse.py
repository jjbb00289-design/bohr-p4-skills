# -*- coding: utf-8 -*-
"""Material IO, text recovery and locator parsing for the field extraction skill.

Tolerant, standard library only, no network, CWD independent. Every parser
returns text plus a method note so a degraded read shows up in the result.
"""
import csv
import hashlib
import json
import re
import shutil
import subprocess
import zipfile
import zlib
from pathlib import Path

STATUS_ENUM = ("reported", "not_reported", "source_conflict", "extraction_failed")
STATUS_TERMINAL = ("reported", "not_reported", "source_conflict")
CONTRACT_ALIASES = {
    "fields": ("result", "fields"), "extracted_fields": ("result", "fields"),
    "extraction": ("result", "fields"), "results": ("result", "fields"),
    "coverage": ("result", "coverage"), "field_dictionary": ("result", "field_dictionary"),
    "field_specs": ("result", "field_dictionary"), "method_notes": ("result", "method_notes"),
    "uncertainty": ("uncertainties",), "evidence": ("claims",),
    "sources_used": ("sources",), "artifacts": ("deliverables",),
    "verifications": ("result", "verifications"), "decisions": ("result", "verifications"),
    "evidence_cards": ("evidence_cards",), "verdicts": ("result", "coverage", "verdict_counts"),
}
NUM_RE = re.compile(r"[-+−]?\d+(?:[.,]\d+)?(?:\s*[×xX]\s*10\s*(?:\^|\*\*)?\s*[-−]?\d+)?")
HEDGE_RE = re.compile(
    r"(?i)\b(?:may|might|could|would|suggest(?:s|ed)?|indicat(?:e|es|ed)|possibly|likely|"
    r"probably|potentially|appears?\s+to|seems?\s+to|is\s+consistent\s+with)\b|可能|或许|提示|推测")
PID_RE = re.compile(r"^[ \t]*[\[\(]?[ \t]*(?:P|¶|para(?:graph)?\.?)[ \t]*0*(\d{1,4})[ \t]*[\]\)]?[ \t:.\-–—]*", re.I)
PAGE_RE = re.compile(r"^[ \t]*(?:-{2,}[ \t]*)?(?:page|pg\.?|p\.)[ \t]*(\d{1,4})(?:[ \t]*-{2,})?[ \t]*$", re.I)
SECTION_RE = re.compile(
    r"^[ \t]*(?:#{1,6}[ \t]*|\*\*)?(abstract|summary|introduction|background|related work|"
    r"methods?|materials? and methods?|experimental|results?|discussion|conclusions?|"
    r"limitations?|references|supplementary|supplemental|appendix|摘要|引言|背景|方法|"
    r"材料与方法|实验|结果|讨论|结论|局限|参考文献|补充材料)\b[^.\n]{0,80}$", re.I)
MDTABLE_SEP = re.compile(r"^[ \t]*\|?[ \t]*:?-{2,}:?[ \t]*(\|[ \t]*:?-{2,}:?[ \t]*)+\|?[ \t]*$")
SKIP_NAME = ("case.json", "task.md")
HINT_KIND = {".md": "markdown", ".csv": "csv", ".tsv": "tsv", ".json": "json",
             ".xml": "xml", ".yaml": "yaml", ".yml": "yaml", ".tex": "tex"}


def jload(path, default=None):
    path = Path(path)
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        try:
            return json.loads(path.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            return default


def jdump(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def ensure_dir(path):
    try:
        Path(path).mkdir(parents=True, exist_ok=True)
    except Exception:
        pass


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def decode_text(data):
    for enc in ("utf-8-sig", "utf-8", "gb18030", "big5", "latin-1"):
        try:
            return data.decode(enc)
        except Exception:
            continue
    return data.decode("utf-8", "replace")


def pdf_to_text(data):
    """Recover PDF text: pdftotext when present, else a Flate-stream content scan."""
    tool = shutil.which("pdftotext")
    if tool:
        try:
            import tempfile
            with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as fh:
                fh.write(data)
                src = fh.name
            dst = src + ".txt"
            subprocess.run([tool, "-layout", src, dst], capture_output=True, timeout=25)
            txt = Path(dst).read_text(encoding="utf-8", errors="replace")
            for tmp in (src, dst):
                try:
                    Path(tmp).unlink()
                except Exception:
                    pass
            if txt.strip():
                return txt, "pdftotext"
        except Exception:
            pass
    chunks = []
    try:
        for match in re.finditer(rb"stream\r?\n(.*?)endstream", data, re.S):
            raw = match.group(1)
            try:
                raw = zlib.decompress(raw)
            except Exception:
                pass
            for body in re.finditer(rb"\((?:\\.|[^\\()])*\)[ \t]*Tj|\[(?:[^\]\\]|\\.)*\][ \t]*TJ",
                                    raw, re.S):
                for tok in re.finditer(rb"\((?:\\.|[^\\()])*\)", body.group(0)):
                    txt = re.sub(rb"\\.", b" ", tok.group(0)[1:-1])
                    chunks.append(decode_text(txt))
    except Exception:
        pass
    return "\n".join(chunks), ("pdf_stream_scan" if chunks else "no_text_layer")


def docx_to_text(data):
    try:
        import io
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            xml = zf.read("word/document.xml").decode("utf-8", "replace")
        xml = re.sub(r"</w:p>", "\n\n", xml)
        xml = re.sub(r"<w:tab[^>]*/>", "\t", xml)
        return re.sub(r"<[^>]+>", "", xml), "docx_xml"
    except Exception:
        return "", "docx_failed"


def material_text(path):
    """Return (text, kind, method note). Never raises."""
    try:
        data = path.read_bytes()
    except Exception as exc:
        return "", "unreadable", str(exc)
    suffix = path.suffix.lower()
    if suffix == ".pdf" or data[:5] == b"%PDF-":
        txt, how = pdf_to_text(data)
        return txt, "pdf", how
    if suffix in (".docx", ".doc"):
        txt, how = docx_to_text(data)
        return txt, "docx", how
    if suffix in (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp"):
        return "", "image", "no_ocr_in_skill"
    return decode_text(data[:6_000_000]), HINT_KIND.get(suffix, "text"), "direct_decode"


def split_paragraphs(text):
    """Split text into blocks carrying explicit paragraph id, page and section."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    blocks, buf, page, pid, section = [], [], None, None, None
    heading = None

    def flush():
        nonlocal buf, pid, heading
        raw = "\n".join(buf).strip("\n")
        if raw.strip():
            blocks.append({"text": raw, "page": page, "pid": pid, "section": section,
                           "heading": heading})
        buf, pid, heading = [], None, None

    for line in text.split("\n"):
        pm = PAGE_RE.match(line)
        if pm:
            flush()
            try:
                page = int(pm.group(1))
            except Exception:
                pass
            continue
        if not line.strip():
            flush()
            continue
        hm = SECTION_RE.match(line.strip())
        if hm and (line.strip().startswith("#") or len(line.strip()) <= 40):
            flush()
            section = hm.group(1)
            heading = line.strip().lstrip("#").strip()
            continue
        idm = PID_RE.match(line)
        if idm:
            flush()
            pid = "P" + idm.group(1).zfill(3)
            rest = line[idm.end():].strip()
            if rest:
                buf.append(rest)
            continue
        buf.append(line)
    flush()
    return blocks


def parse_md_tables(text):
    tables, cur = [], []
    for line in text.replace("\r\n", "\n").split("\n"):
        if line.strip().startswith("|") and line.count("|") >= 2:
            if MDTABLE_SEP.match(line):
                continue
            cur.append([c.strip() for c in line.strip().strip("|").split("|")])
        else:
            if len(cur) >= 2:
                tables.append({"rows": cur})
            cur = []
    if len(cur) >= 2:
        tables.append({"rows": cur})
    return tables


def parse_delimited(text, delim):
    try:
        rows = list(csv.reader(text.splitlines(), delimiter=delim))
    except Exception:
        return []
    rows = [r for r in rows if any(str(c).strip() for c in r)]
    return [{"rows": rows}] if len(rows) >= 2 else []


def skipped(rel):
    low = rel.lower()
    name = low.rsplit("/", 1)[-1]
    if name in SKIP_NAME or name.endswith(".pyc"):
        return True
    if low.startswith("environment/") or "/environment/" in low:
        return True
    if name.endswith(".json") and any(token in name for token in
                                      ("field", "target", "claim", "workorder", "work-order")):
        return True
    return False


def build_corpus(input_dir):
    """Scan the input tree into materials, paragraph segments and table-row segments."""
    corpus = {"materials": [], "segments": [], "tables": [], "errors": [], "degradations": []}
    root = Path(input_dir)
    if not root.exists():
        corpus["degradations"].append("input directory missing: %s" % root)
        return corpus
    try:
        files = sorted([p for p in root.rglob("*") if p.is_file()])
    except Exception as exc:
        corpus["errors"].append("cannot list input: %s" % exc)
        return corpus
    tno = 0
    for path in files:
        rel = path.relative_to(root).as_posix()
        if skipped(rel):
            continue
        size = 0
        try:
            size = path.stat().st_size
        except Exception:
            pass
        if size > 12_000_000:
            corpus["degradations"].append("material skipped >12MB: %s" % rel)
            continue
        text, kind, how = material_text(path)
        try:
            digest = sha_bytes(path.read_bytes()[:4_000_000])
        except Exception:
            digest = ""
        mat = {"material": rel, "kind": kind, "bytes": size, "sha256": digest,
               "text_method": how, "segments": 0, "tables": 0}
        corpus["materials"].append(mat)
        if not text.strip():
            if kind == "image":
                corpus["degradations"].append("image has no text layer: %s (OCR tool needed)" % rel)
            elif kind == "pdf":
                corpus["degradations"].append("PDF has no extractable text layer: %s" % rel)
            continue
        seq = 0
        for block in split_paragraphs(text):
            body = block["text"].strip()
            if not body:
                continue
            seq += 1
            pid = block["pid"] or ("P" + str(seq).zfill(4))
            at = text.find(body)
            corpus["segments"].append({
                "sid": "%s::%s" % (rel, pid), "material": rel, "paragraph_id": pid,
                "page": block["page"], "section": block["section"], "text": body,
                "char_start": at, "char_end": at + len(body)})
            mat["segments"] += 1
            for tbl in (parse_md_tables(body) if kind == "markdown" else []):
                tno += 1
                tid = "T%d" % tno
                rows = tbl["rows"]
                rowlines = [" | ".join(r) for r in rows]
                corpus["tables"].append({"table_id": tid, "material": rel, "rows": rows,
                                         "row_lines": rowlines, "page": block["page"],
                                         "source": "markdown"})
                mat["tables"] += 1
                for ri, line in enumerate(rowlines):
                    at2 = text.find(line)
                    corpus["segments"].append({
                        "sid": "%s::%s::R%d" % (rel, tid, ri), "material": rel,
                        "paragraph_id": "%s:R%d" % (tid, ri), "table_id": tid, "row": ri,
                        "page": block["page"], "section": block["section"], "text": line,
                        "char_start": at2, "char_end": at2 + len(line)})
        if kind in ("csv", "tsv"):
            for tbl in parse_delimited(text, "," if kind == "csv" else "\t"):
                tno += 1
                tid = "T%d" % tno
                rows = tbl["rows"]
                rowlines = [" | ".join(r) for r in rows]
                corpus["tables"].append({"table_id": tid, "material": rel, "rows": rows,
                                         "row_lines": rowlines, "page": None,
                                         "source": kind})
                mat["tables"] += 1
                for ri, line in enumerate(rowlines):
                    at2 = text.find(line)
                    corpus["segments"].append({
                        "sid": "%s::%s::R%d" % (rel, tid, ri), "material": rel,
                        "paragraph_id": "%s:R%d" % (tid, ri), "table_id": tid, "row": ri,
                        "page": None, "section": None, "text": line,
                        "char_start": at2, "char_end": at2 + len(line)})
    return corpus


def norm_text(value):
    text = (value or "")
    for src, dst in (("\u201c", '"'), ("\u201d", '"'), ("\u2018", "'"), ("\u2019", "'"),
                     ("\u2212", "-"), ("\u00a0", " "), ("−", "-")):
        text = text.replace(src, dst)
    return re.sub(r"\s+", " ", text).strip()


def find_quote(corpus, quote):
    """Verbatim quote lookup: exact substring first, whitespace-normalised fallback."""
    quote = (quote or "").strip()
    hits = []
    if len(quote) < 3:
        return hits
    nq = norm_text(quote)
    for seg in corpus.get("segments", []):
        text = seg.get("text") or ""
        if quote in text:
            hits.append({"material": seg["material"], "paragraph_id": seg["paragraph_id"],
                         "page": seg.get("page"), "section": seg.get("section"),
                         "table_id": seg.get("table_id"), "row": seg.get("row"),
                         "match": "exact", "sid": seg["sid"]})
        elif nq and nq in norm_text(text):
            hits.append({"material": seg["material"], "paragraph_id": seg["paragraph_id"],
                         "page": seg.get("page"), "section": seg.get("section"),
                         "table_id": seg.get("table_id"), "row": seg.get("row"),
                         "match": "normalized", "sid": seg["sid"]})
    return hits


def contract_keys(contract):
    if isinstance(contract, dict):
        return [str(key) for key in contract.keys()]
    if isinstance(contract, list):
        keys = []
        for item in contract:
            if isinstance(item, str):
                keys.append(item)
            elif isinstance(item, dict):
                for key in ("key", "name", "field", "field_id", "claim_id"):
                    if key in item:
                        keys.append(str(item[key]))
                        break
        return keys
    return []


def echo_contract(contract, base):
    """Every output_contract key must exist in result.json under its exact name."""
    base = base if isinstance(base, dict) else {}
    result = base.get("result") if isinstance(base.get("result"), dict) else {}
    final, missing = {}, []
    for key in contract_keys(contract):
        if key in base:
            final[key] = base[key]
            continue
        if key in result:
            final[key] = result[key]
            continue
        alias = CONTRACT_ALIASES.get(key) or {
            "verifications": ("result", "verifications"),
            "decisions": ("result", "verifications"),
            "evidence_cards": ("evidence_cards",),
            "verdicts": ("result", "coverage", "verdict_counts"),
        }.get(key)
        if alias:
            node, ok = base, True
            for part in alias:
                if isinstance(node, dict) and part in node:
                    node = node[part]
                else:
                    ok = False
                    break
            if ok:
                final[key] = node
                continue
        final[key] = None
        missing.append(key)
    final.update(base)
    final["contract_fill"] = {"contract_type": type(contract).__name__,
                              "requested_keys": contract_keys(contract),
                              "filled_null": missing}
    if missing:
        degradations = final.setdefault("degradations", [])
        if isinstance(degradations, list):
            degradations.append("output_contract keys filled as null: " + ", ".join(missing))
    return final

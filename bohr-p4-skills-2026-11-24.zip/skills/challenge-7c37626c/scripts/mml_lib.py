# -*- coding: utf-8 -*-
"""Publisher MathML -> LaTeX conversion and formula object extraction.

Deterministic mapping (mfrac/msub/msup/msubsup/msqrt/mroot/mfenced/mtable/mover),
flattened structure counters and symbol harvesting. Reads the actual XML that the
case supplies; when no representation exists it returns no records (never invents).
"""
import re
import xml.etree.ElementTree as ET
from pathlib import Path

MO_MAP = {
    "\u00d7": "\\times", "\u2212": "-", "\u00b1": "\\pm", "\u00b7": "\\cdot",
    "\u2264": "\\leq", "\u2265": "\\geq", "\u2260": "\\neq", "\u2211": "\\sum",
    "\u220f": "\\prod", "\u222b": "\\int", "\u2202": "\\partial", "\u2207": "\\nabla",
    "\u2192": "\\to", "\u221e": "\\infty", "\u0394": "\\Delta", "\u2248": "\\approx",
    "\u2032": "'", "\u2033": "''", "\u2026": "\\dots", "\u00a0": "\\ ",
    "\u03c1": "\\rho", "\u03bc": "\\mu", "\u03c3": "\\sigma", "\u03b1": "\\alpha",
    "\u03b2": "\\beta", "\u03b3": "\\gamma", "\u03b4": "\\delta", "\u03b5": "\\epsilon",
    "\u03b8": "\\theta", "\u03bb": "\\lambda", "\u03c9": "\\omega", "\u03c6": "\\phi",
    "\u03c8": "\\psi", "\u03c4": "\\tau", "\u03b7": "\\eta", "\u03b6": "\\zeta",
    "<": "\\lt", ">": "\\gt", "\u2264": "\\leq", "\u2265": "\\geq",
}
LATEX_ESC = {"&": "\\&", "%": "\\%", "#": "\\#", "_": "\\_", "{": "\\{", "}": "\\}",
             "<": "\\lt", ">": "\\gt"}
FUNC_NAMES = {"sin", "cos", "tan", "cot", "sec", "csc", "log", "ln", "exp", "max", "min",
              "lim", "sup", "inf", "det", "dim", "sinh", "cosh", "tanh", "arg"}


def escape_tex(text):
    """Escape LaTeX-special characters in a raw MathML token text."""
    return "".join(LATEX_ESC.get(ch, ch) for ch in (text or ""))


def mi_latex(text):
    """Render a MathML identifier token (mi) to LaTeX."""
    raw = (text or "").strip()
    if not raw:
        return raw
    if raw in MO_MAP:
        return MO_MAP[raw]
    if len(raw) > 1 and raw not in FUNC_NAMES:
        return "\\mathrm{%s}" % escape_tex(raw)
    return escape_tex(raw)


def mo_latex(text):
    """Render a MathML operator token (mo) to LaTeX."""
    raw = (text or "").strip()
    if raw in MO_MAP:
        return MO_MAP[raw]
    return escape_tex(raw)

# --------------------------------------------------------------- MathML -> LaTeX
def local(tag):
    return tag.rsplit("}", 1)[-1] if "}" in str(tag) else str(tag)


def kids(el):
    return [child for child in list(el)
            if local(child.tag) not in ("annotation", "annotation-xml", "mprescripts",
                                        "none", "mspace")]


def has_tex_annotation(el):
    for child in el.iter():
        if local(child.tag) == "annotation" and "tex" in (child.get("encoding") or "").lower():
            return True
    return False


def tex_annotation(el):
    for child in el.iter():
        if local(child.tag) == "annotation" and "tex" in (child.get("encoding") or "").lower():
            return (child.text or "").strip()
    return ""


def _alnum(ch):
    return ch.isalnum()


def join_atoms(fragments):
    """Concatenate rendered child fragments, inserting one space only where two
    adjacent alphanumeric ends would otherwise merge (e.g. \\rho + v -> \\rhovd).
    A single space terminates a TeX control word and is otherwise ignored in math."""
    out = ""
    for frag in fragments:
        frag = str(frag)
        if out and frag and _alnum(out[-1]) and _alnum(frag[0]):
            out += " "
        out += frag
    return out


def mml_to_latex(el):
    tag = local(el.tag)
    parts = kids(el)
    if tag == "math":
        return join_atoms(mml_to_latex(child) for child in parts)
    if tag == "semantics":
        tex = tex_annotation(el)
        return tex if tex else join_atoms(mml_to_latex(child) for child in parts)
    if tag in ("mrow", "mstyle", "mpadded", "mphantom", "menclose", "merror", "mtd", "mtr"):
        return join_atoms(mml_to_latex(child) for child in parts)
    if tag == "mi":
        return mi_latex(el.text or "")
    if tag == "mn":
        return escape_tex((el.text or "").strip())
    if tag == "mo":
        return mo_latex(el.text or "")
    if tag == "mtext":
        return "\\text{%s}" % escape_tex((el.text or "").strip())
    if tag == "mspace":
        return "\\,"
    if tag == "mfrac":
        return "\\frac{%s}{%s}" % (mml_to_latex(parts[0]) if parts else "",
                                   mml_to_latex(parts[1]) if len(parts) > 1 else "")
    if tag == "msub":
        return "%s_{%s}" % (mml_to_latex(parts[0]) if parts else "",
                            mml_to_latex(parts[1]) if len(parts) > 1 else "")
    if tag == "msup":
        return "%s^{%s}" % (mml_to_latex(parts[0]) if parts else "",
                            mml_to_latex(parts[1]) if len(parts) > 1 else "")
    if tag == "msubsup":
        return "%s_{%s}^{%s}" % (mml_to_latex(parts[0]) if parts else "",
                                 mml_to_latex(parts[1]) if len(parts) > 1 else "",
                                 mml_to_latex(parts[2]) if len(parts) > 2 else "")
    if tag == "msqrt":
        return "\\sqrt{%s}" % join_atoms(mml_to_latex(child) for child in parts)
    if tag == "mroot":
        return "\\sqrt[%s]{%s}" % (mml_to_latex(parts[1]) if len(parts) > 1 else "",
                                   mml_to_latex(parts[0]) if parts else "")
    if tag == "mover":
        accent = (parts[1].text or "").strip() if len(parts) > 1 else ""
        base = mml_to_latex(parts[0]) if parts else ""
        if accent in ("\u00af", "\u203e", "-", "\u2192", "\u02d9", "\u02dc", "^"):
            command = {"\u00af": "\\bar", "\u203e": "\\bar", "-": "\\bar",
                       "\u2192": "\\vec", "\u02d9": "\\dot", "\u02dc": "\\hat",
                       "^": "\\hat"}.get(accent, "\\bar")
            return "%s{%s}" % (command, base)
        return "\\overset{%s}{%s}" % (mml_to_latex(parts[1]) if len(parts) > 1 else "", base)
    if tag == "munder":
        return "\\underset{%s}{%s}" % (mml_to_latex(parts[1]) if len(parts) > 1 else "",
                                       mml_to_latex(parts[0]) if parts else "")
    if tag == "munderover":
        return "\\underset{%s}{\\overset{%s}{%s}}" % (
            mml_to_latex(parts[1]) if len(parts) > 1 else "",
            mml_to_latex(parts[2]) if len(parts) > 2 else "",
            mml_to_latex(parts[0]) if parts else "")
    if tag == "mfenced":
        opening = el.get("open", "(")
        closing = el.get("close", ")")
        body = ", ".join(mml_to_latex(child) for child in parts)
        return "\\left%s %s \\right%s" % (opening, body, closing)
    if tag == "mtable":
        rows = []
        for row in parts:
            cells = [mml_to_latex(c) for c in kids(row)]
            rows.append(" & ".join(cells))
        return "\\begin{matrix}%s\\end{matrix}" % " \\\\ ".join(rows)
    if tag == "mtr":
        return " & ".join(mml_to_latex(child) for child in parts)
    if tag in ("annotation", "annotation-xml"):
        return ""
    return join_atoms(mml_to_latex(child) for child in parts)


def walk_math(root):
    """Yield (math_element, context) for every MathML math node in document order."""
    found = []

    def walk(el, ctx):
        tag = local(el.tag)
        if tag == "math":
            found.append((el, dict(ctx)))
            return
        child_ctx = dict(ctx)
        if el.get("id"):
            child_ctx["id"] = el.get("id")
        if el.get("number"):
            child_ctx["number"] = el.get("number")
        if tag == "label":
            child_ctx["label"] = (el.text or "").strip()
        for child in list(el):
            if local(child.tag) == "label" and not child_ctx.get("label"):
                child_ctx["label"] = (child.text or "").strip()
        for child in list(el):
            walk(child, child_ctx)

    walk(root, {})
    return found


def structure_of(el):
    counts = {"fracs": 0, "subs": 0, "sups": 0, "radicals": 0, "matrices": 0,
              "rows": 0, "cases": 0}
    for node in el.iter():
        tag = local(node.tag)
        if tag == "mfrac":
            counts["fracs"] += 1
        elif tag == "msub":
            counts["subs"] += 1
        elif tag == "msup":
            counts["sups"] += 1
        elif tag == "msubsup":
            counts["subs"] += 1
            counts["sups"] += 1
        elif tag in ("msqrt", "mroot"):
            counts["radicals"] += 1
        elif tag == "mtable":
            counts["matrices"] += 1
        elif tag == "mtr":
            counts["rows"] += 1
        elif tag == "mfenced" and (node.get("open") == "{" or node.get("close") == "}"):
            counts["cases"] += 1
    return counts


def collect_symbols(el):
    """Identifiers (mi) and constants (mn) used by a formula."""
    identifiers, constants, operators = [], [], []
    for node in el.iter():
        tag = local(node.tag)
        text = (node.text or "").strip()
        if not text:
            continue
        if tag == "mi":
            if text in FUNC_NAMES and text != "d":
                continue
            if text not in identifiers:
                identifiers.append(text)
        elif tag == "mn":
            if text not in constants:
                constants.append(text)
        elif tag == "mo":
            if text not in operators:
                operators.append(text)
    return {"identifiers": identifiers, "constants": constants, "operators": operators}


def formula_records(xml_path, material_label=None):
    """Parse one publisher XML file into formula records (deduplicated)."""
    try:
        root = ET.parse(str(xml_path)).getroot()
    except Exception as exc:
        return [], "xml_parse_failed: %s" % exc
    records, seen = [], set()
    for math_el, ctx in walk_math(root):
        latex = tex_annotation(math_el) or mml_to_latex(math_el)
        fid = ctx.get("id") or ctx.get("label") or "eq%d" % (len(records) + 1)
        fid = str(fid).strip().strip("()")
        if not fid or fid in seen:
            fid = "%s_%d" % (fid or "eq", len(records) + 1)
        seen.add(fid)
        records.append({
            "formula_id": fid,
            "eq_number": ctx.get("label") or ctx.get("number") or "",
            "latex": latex,
            "annotation_tex": has_tex_annotation(math_el),
            "structure": structure_of(math_el),
            "symbols": collect_symbols(math_el),
            "source": {"material": material_label or Path(xml_path).name,
                       "node_id": ctx.get("id")},
        })
    return records, ""


def find_formula_sources(input_dir):
    """Locate publisher XML / formula XML files under /input (recursive, xml+mathml)."""
    root = Path(input_dir)
    if not root.exists():
        return []
    files = []
    for pattern in ("*.xml", "*.mathml"):
        for path in sorted(root.rglob(pattern)):
            low = path.as_posix().lower()
            if "environment/" in low:
                continue
            if path not in files:
                files.append(path)
    scored = []
    for path in files:
        low = path.name.lower()
        score = 0
        if "formula" in low or "equation" in low:
            score += 3
        if "source" in low:
            score += 1
        if "publisher" in low:
            score += 1
        try:
            text = path.read_text(encoding="utf-8", errors="replace")[:200000]
        except Exception:
            text = ""
        if "mathml" in text.lower() or "<mml:" in text.lower() or "<math" in text.lower():
            score += 2
        if score:
            scored.append((score, path.relative_to(root).as_posix(), path))
    scored.sort(key=lambda item: (-item[0], item[1]))
    return [(rel, path) for _score, rel, path in scored]


def load_source_formulas(input_dir):
    """Return (records, used_material, notes). Prefers derived source-formulas XML and
    falls back across candidate sources so an empty top source never hides a real one."""
    sources = find_formula_sources(input_dir)
    notes = []
    if not sources:
        return [], None, ["no publisher/formula XML found under input"]
    for rel, path in sources:
        records, err = formula_records(path, rel)
        if err:
            notes.append("%s: %s" % (rel, err))
            continue
        if records:
            attach_verbatim(records, path)
            return records, rel, notes
        notes.append("no MathML formula nodes in %s" % rel)
    return [], None, notes or ["no MathML formula nodes found in any XML source"]


def _verbatim_element(raw, anchor):
    """Return the raw XML text of the element whose opening tag contains `anchor`."""
    idx = raw.find(anchor)
    if idx < 0:
        return ""
    start = raw.rfind("<", 0, idx)
    if start < 0:
        return ""
    tag_match = re.match(r"<\s*([A-Za-z_][\w:.\-]*)", raw[start:])
    if not tag_match:
        return ""
    tag = tag_match.group(1)
    open_re = re.compile(r"<\s*" + re.escape(tag) + r"(\s|>|/)")
    close_re = re.compile(r"</\s*" + re.escape(tag) + r"\s*>")
    depth = 0
    i, n = start, len(raw)
    while i < n:
        if raw[i] != "<":
            i += 1
            continue
        close_match = close_re.match(raw, i)
        if close_match:
            depth -= 1
            if depth == 0:
                end = raw.find(">", close_match.end() - 1)
                return raw[start:end + 1] if end != -1 else raw[start:]
            i = close_match.end()
            continue
        open_match = open_re.match(raw, i)
        if open_match:
            gt = raw.find(">", open_match.start())
            if gt == -1:
                return raw[start:]
            if not raw[gt - 1:gt].startswith("/"):
                depth += 1
            i = gt + 1
            continue
        i += 1
    return ""


def verbatim_blocks(xml_path):
    """Map formula_id -> raw XML text of its enclosing element (verbatim from the file)."""
    try:
        raw = Path(xml_path).read_text(encoding="utf-8", errors="replace")
    except Exception:
        return {}
    anchors = re.findall(r"\b(?:id|xml:id)\s*=\s*[\"']([^\"']+)[\"']", raw)
    blocks = {}
    for fid in anchors:
        fid = str(fid).strip().strip("()")
        if not fid or fid in blocks:
            continue
        block = _verbatim_element(raw, 'id="%s"' % fid) or \
                _verbatim_element(raw, "id='%s'" % fid) or \
                _verbatim_element(raw, 'xml:id="%s"' % fid) or \
                _verbatim_element(raw, "xml:id='%s'" % fid)
        if block:
            blocks[fid] = block
    return blocks


def attach_verbatim(records, xml_path):
    """Attach `mathml` (verbatim XML source) to each record when available."""
    blocks = verbatim_blocks(xml_path)
    if not blocks:
        return
    for record in records:
        fid = str(record.get("formula_id") or "")
        if fid in blocks:
            record["mathml"] = blocks[fid]
        else:
            key = str(record.get("eq_number") or "").strip("()")
            if key and key in blocks:
                record["mathml"] = blocks[key]

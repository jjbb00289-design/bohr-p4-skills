# 公式解析质检清单与失败模式

本文件用于 `check` 前的自检与复核他人的公式解析结果。

## 1. 认得准（结构还原）

1. `\frac` 数 = MathML `mfrac` 数？分子分母没有交换、没有丢项？
2. 上下标：`_{}`/`^{}` 数量与位置正确？`e^{-E/kT}` 的指数整体在括号里？
3. 括号层级：`\left(\right)`、`{}` 配平？嵌套分式没被压平？
4. 希腊字母与特殊符号：`ρ/μ/σ/Δ/∂/∇` 映射正确？没被 ASCII 近似替代？
5. 多字母标识符（`Re`、`Nu`、`Sh`）没被拆成单字母乘积？
6. 单位与量纲：`mV` ≠ `V`、`µg/mL` ≠ `mg/mL`；量纲与公式一致？

## 2. 讲得清（变量表）

1. 公式里出现的每个符号（含下标变量、常数符号）都有条目吗？
2. `definition_basis` 是 `original` 的，是否真的给了论文逐字定义 + 段/页 locator？
3. `inferred`/`common_knowledge` 是否写了推断理由，而不是冒充原文定义？
4. `unit` 是否保留原文字面？无量纲是否写 `-` 而不是猜单位？
5. `range`（取值/适用条件）是否来自原文或写清推断依据？
6. 同一符号在不同公式里定义一致吗（`d` 是直径还是微分）？

## 3. 推得顺（推导）

1. 关键推导是否拆成 ≥2 个可检查步骤，每歩有 `statement_latex`？
2. 每步是否写了 `justification`（用了哪条守恒律/代数操作）或 `assumption`（近似条件）？
3. 假设/近似/边界条件（无阻力、小角、理想气体、连续介质）是否显式列出？
4. 引用的其他公式 id 是否真实存在（没有悬空依赖）？
5. 原文没给推导、由标准论证补出的步骤，是否在 `notes` 标注 provenance？

## 4. 算得回（数值核验）

1. `expression` 是否只含允许的算符与函数（数字、`+-*/^`、`sqrt/log/exp/三角`、`pi/e`）？
2. `substitutions` 是否都是数值、变量名与表达式一致？
3. `computed` 是否等于独立复算值（≤0.1% 四舍五入）？
4. `result=pass` 是否满足 |expected−recomputed| ≤ tolerance？
5. 单位与量级是否自洽（例：Re 应无量纲；v 应 m/s）？
6. 不能算的项是否写 `not_computable` + 缺什么数据，而不是伪造 pass？

## 5. 诚实边界

| 情形 | 正确做法 | 错误做法 |
|---|---|---|
| 材料无公式表示（无 XML/公式节点） | `status=insufficient_evidence`，`formulas=[]`，写缺什么 | 从散文反推公式、填 0 |
| 公式截断/模糊/多义 | `parse_confidence` 降低 + `notation_notes` 写歧义 + partial | 声称唯一还原 |
| 单位缺失 | `unit` 留空/标 infer + 理由 | 猜一个单位并当原文 |
| 数值缺输入数据 | `not_computable` + 缺数据说明 | 编造 substitutions 凑 pass |
| 原文只给最终式 | 推导步标 provenance=standard derivation | 说"原文逐步推导" |

## 6. 高频失败模式（出现即返工）

| 失败模式 | 表现 | 修法 |
|---|---|---|
| 结构压平 | `\frac{a}{b+c}` 写成 `a/b+c` | 从 MathML 重新转换，核对 mfrac 数 |
| 括号丢层 | `e^-E/kT` 少大括号 | 补齐 `^{...}` |
| 符号表缺项 | 用了 `μ` 却没定义 | 补变量条目（original/inferred） |
| 定义冒充原文 | 单位/范围来自常识却标 original | 改 `inferred`/`common_knowledge` + 理由 |
| 推导跳步 | 只有结论式一步 | 拆步骤 + justification |
| 数值造假 | `computed` 与表达式复算不符 | 用复算值或改 `not_computable` |
| 无表示硬编 | 没有 XML 却给出公式 | 改 `insufficient_evidence`，写缺口 |
| 公式无源 | 草稿公式不在 XML 中 | 标 unsourced 或删除 |

## 7. 复核他人的解析（第二人视角）

1. 抽 2 个公式：按 MathML 数结构（frac/sub/sup/sqrt），核对 LaTeX 一一对应。
2. 抽 3 个符号：按 `source` 翻原文确认定义 quote 逐字、单位与范围正确。
3. 抽 1 条推导：确认每步成立、假设/近似写清、依赖公式存在。
4. 抽 1 条数值检查：用 `expression`+`substitutions` 自己算一遍，对比 `computed` 与 `result`。
5. 看 `coverage.missing_formula_ids` / `missing_symbols` 是否为空；不空则 `status` 不应是 `ok`。

## 8. 提交前命令级检查

```bash
python3 scripts/main.py check && python3 scripts/main.py build && python3 scripts/main.py selfcheck
```

期望：`check` 无 FAIL；九个产物非空；`formulas.tex` 可编辑、`formulas.pdf` 以 `%PDF-` 开头；
`claims[]` 非空且每条带 `material+locator+quote`；`content_map.json` 元素与 `result.json` 一致；
无表示案例仍 exit 0 且 `status=insufficient_evidence`。

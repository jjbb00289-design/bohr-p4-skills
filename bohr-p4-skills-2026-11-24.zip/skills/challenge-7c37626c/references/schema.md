# 公式解析 schema 与 MathML 映射细则

本文件是 `SKILL.md` 第 4–6 节的字段级补充。字段名与枚举以本文为准。

## 1. 输入侧

| 文件 | 说明 |
|---|---|
| `/input/case.json` | `case_id`、`output_contract`；运行时才知道契约键 |
| `/input/materials/**` | 论文 PDF/MD/TXT；变量定义与推导叙述的出处 |
| `/input/artifacts/publisher-source.xml` | 出版商原始 XML（JATS 等，含 `disp-formula`/`mml:math`） |
| `/input/artifacts/source-formulas.xml` | 从原始 XML 派生的公式节点子集，保留 MathML 分式/上下标与来源 ID |
| `/input/task.md` | 任务说明，不作证据来源 |

**重要**：公式目录/公式清单不是线性化答案；它们只说明"有哪些公式对象"，LaTeX 必须由
MathML 结构确定性还原（或由 Agent 基于同一结构写出）。没有 XML 的案例不要反推。

## 2. 输出侧 `result.json`

```text
result.json
├─ case_id / status
├─ result
│  ├─ formulas[]      {formula_id, eq_number, latex, structure, symbols, parse_confidence,
│  │                   source, validation, notation_notes, mathml(逐字 XML 证据)}
│  ├─ variables[]     {symbol, definition, unit, range, definition_basis, source, quote,
│  │                   inference_reason, formula_ids, validation}
│  ├─ derivations[]   {derivation_id, formula_id, steps[], assumptions, approximations,
│  │                   boundary_conditions, depends_on, notes}
│  ├─ numeric_checks[] {check_id, formula_id, expression, substitutions, expected, computed,
│  │                   tolerance, unit, result, recomputed, validation}
│  ├─ coverage        formulas_in_source/parsed/missing_formula_ids, variables_expected/
│  │                 defined/missing_symbols, derivations, numeric_checks(_passed/_failed), complete
│  ├─ symbol_conventions  定义来源语义与符号规则
│  └─ method_notes    流程、转换口径、复算口径
├─ claims[]           {claim_id, claim_type, statement, evidence{material, locator, quote}, basis}
├─ uncertainties[] / sources[] / pending_human[] / errors[] / degradations[]
├─ deliverables       产物相对路径（含 formulas.pdf / content_map.json）
└─ contract_fill      契约回填结果
```

`claims[]` 的 `claim_type` ∈ `formula_restoration / symbol_definition / symbol_inference /
derivation_step / numeric_verification / coverage_gap`；`evidence.quote` 必须逐字来自材料
（公式还原用节点 XML 原文，符号定义用论文原文句，推导/复算用其表达式）。

`content_map.json` 结构：`{case_id, map_version, elements{formulas/variables/derivations/
numeric_checks}, output_files, pdf_export}`；每个元素含 `kind/output/source/quote` 及关键字段。

## 3. MathML → LaTeX 确定性映射

| MathML | LaTeX | 说明 |
|---|---|---|
| `mfrac` | `\frac{}{}` | 分子/分母各一项；嵌套保持层级 |
| `msub` | `X_{}` | |
| `msup` | `X^{}` | |
| `msubsup` | `X_{}^{}` | 同时有上下标 |
| `msqrt` | `\sqrt{}` | 根号覆盖整个子表达式 |
| `mroot` | `\sqrt[]{}` | 先填根指数 |
| `mfenced` | `\left( ... \right)` | `open`/`close` 属性决定括号；`{`+`}` 记为 cases |
| `mtable` | `\begin{matrix} ... \end{matrix}` | 行用 `\\`，列用 `&` |
| `mover` | `\bar{}`/`\vec{}`/`\hat{}`/`\overset{}{}` | 按重音符号选择 |
| `munder`/`munderover` | `\underset{}{}` / 组合 | |
| `mi` 单字母 | 原样 | 多字母（如 `Re`）→ `\mathrm{Re}` |
| `mn` | 原样 | 数字字面量 |
| `mo` | 确定性映射 | `×→\times`、`−→-`、`±→\pm`、`≤→\leq`、`∞→\infty`、`ρ→\rho` 等 |
| `mtext` | `\text{}` | |
| `annotation encoding="application/x-tex"` | 直接采用 | 出版商自带的 TeX 注释优先（`parse_confidence` 更高） |

## 4. 字段级规则

### 4.1 `formulas[]`
- `formula_id` 取 XML 的 `id`/`label`；缺失时按文档顺序稳定编号（不得随运行变化）。
- `structure` 至少含 `fracs/subs/sups/radicals/matrices/rows/cases`，由 MathML 统计；
  LaTeX 侧必须与 `fracs` 完全一致，上下标/根号不一致会告警。
- `parse_confidence` ∈ [0,1]；无 TeX 注释时不应声称 1.0。
- `source` 必须含 `material`（XML 文件名）与公式节点 id。
- `mathml` 保存该公式节点在源 XML 里的**逐字原文**（`<disp-formula>`/`<math>` 封闭元素），
  供 `formula_restoration` claim 使用；无法定位时留空并在 `degradations` 说明。

### 4.2 `variables[]`
- `definition_basis`：`original`（论文原文定义）/ `inferred`（上下文推断）/ `common_knowledge`（标准约定）。
- `original`：必须 `quote`（逐字）+ `source.material` + (`paragraph_id`/`page`/`section`)。
- `inferred`/`common_knowledge`：必须写 `inference_reason` 或 `notes`。
- `unit`：原文字面；无量纲写 `-`；单位来自常识时在 `inference_reason` 注明。
- `range`：取值/适用范围的原文或推断；写清依据。

### 4.3 `derivations[]`
- `steps[]`：每步 `step_no`、`statement_latex`、以及 `justification` 或 `assumption`。
- `depends_on`：引用的 `formula_id` 必须存在（悬空依赖 = FAIL）。
- `assumptions`/`approximations`/`boundary_conditions`：显式列出。
- 只列"原文没给但标准推出"的步骤时，在 `notes` 标注 provenance（原文/标准推导）。

### 4.4 `numeric_checks[]`
- `expression` 只允许：数字、`+ - * / ^ ( )`、`sqrt/log/ln/exp/sin/cos/tan/abs`、`pi/e`。
- `substitutions` 只放数值；变量名与表达式一致。
- `computed` 会被脚本用同一 `expression`+`substitutions` 独立复算（0.1% 四舍五入允许）。
- `expected` + `tolerance` 与 `result` 必须一致：`pass` = |expected−recomputed| ≤ tolerance。
- 不可计算写 `result="not_computable"` 并说明缺什么数据。

## 5. 契约回填

1. `output_contract` 支持 dict 与 list；每个键精确匹配（顶层 → `result` → 别名表）。
2. 常见别名：`formulas→result.formulas`、`variables→result.variables`、
   `derivations→result.derivations`、`numeric_checks→result.numeric_checks`、
   `coverage→result.coverage`、`symbol_table→result.variables`、`latex→formulas.tex`。
3. 缺值写 `null` 并记 `degradations`；`case_id`/`status` 永不省略。

## 6. 无工作稿 DERIVED_PATTERN（v1.1）

- `build` 无可用 `draft.json` 时调用 `scripts/mathml_derive.py`，从 `/input` 下的
  `source-formulas.xml` / `publisher-source.xml` 或任意 `.xml`/`.mathml` 确定性派生。
- 公式记录新增：`source_id`（`id`/`xml:id`/`@source`）、`derivation_id`、
  `numeric_verification`（`verified`/`not_applicable`）与 `numeric_verification_reason`。
- 符号表 `symbol_table.json` 覆盖全部 `mi/mo/mn/mtext` token（`symbol/latex/role/source_id/formula_id`）；
  `result.variables` 只放标识符，定义留空、`definition_basis=inferred` 并写理由。
- 推导为 XML 树的结构展开（每步含 `tag/path/latex_fragment`），provenance 注明非语义推导。
- 数值复算只对常数齐全的算术子式进行；含符号未知量时 `numeric_verification=not_applicable`，
  绝不填 0 或反推。无公式节点时 `status=insufficient_evidence`、`formulas=[]`。

---
name: math-expression-reader
description: Restore formulas from a paper's publisher MathML without ambiguity, explain every symbol with a source locator, present derivations with assumptions, recompute numeric substitutions, and emit a verifiable content map plus a rendered preview. Use when scientific formulas must be turned into LaTeX, a variable table, checkable derivations and numeric verification. With no agent draft, init+build deterministically derives everything from the XML; absent formula representation is reported as insufficient_evidence, never back-derived or filled with 0.
version: 1.2.0
---

# 公式解析与数学推理（math-expression-reader）

把论文里的公式对象变成**可校验的结构化表达**：认得准（LaTeX 与结构）、讲得清（变量表带出处）、
推得顺（分步推导与假设）、算得回（数值复算）。无公式表示的案例如实报 partial/insufficient_evidence，
**绝不从散文反推公式、绝不把未知填 0**。每条结论都落在 `claims` 里并带 `material + locator + 逐字 quote`，
另输出 `content_map.json` 把每个元素指回来源，`formulas.pdf` 是可打开的真实导出件。

## 1. 何时使用 / 何时不用

适用：
- 输入是论文材料（PDF / Markdown / 文本 / XML），其中含 `artifacts/publisher-source.xml`
  与/或 `artifacts/source-formulas.xml`（已提取的公式节点子集，带 MathML 结构与来源 ID）。
- 任务要求还原公式为 LaTeX/MathML、给出变量定义与单位、拆推导步骤、或做数值代入核验。

不适用：只要求摘要式解释、没有任何公式表示却要求"补出公式"、把公式目录当线性化答案。

## 2. 硬性事实（先读，决定成败）

1. **公式对象只来自材料**：MathML 节点（`mfrac/msub/msup/msubsup/msqrt/mroot/mfenced/mtable/…`）
   才是公式事实来源；散文里的符号描述只能用于变量定义，不能用来反推公式结构。
2. **无表示分支必须诚实**：材料没有公式表示（没有 XML/公式节点）时，`status=insufficient_evidence`，
   `formulas=[]`，在 `degradations`/`claims` 写清缺什么；禁止编造公式、禁止用 0 占位、禁止反推。
3. **无工作稿也能真实交付**：`build` 在没有可用 `draft.json` 时，用 `scripts/mathml_derive.py`
   从 XML **确定性派生**：真实 LaTeX、覆盖全部 token 的符号表、结构展开式推导、以及只在常数齐全时
   才做的数值复算；符号的**论文定义**留空并标 `inferred`，状态为 `partial`，不冒充完整语义解释。
4. **契约运行时才知道**：`/input/case.json` 的 `output_contract` 每个键都必须原样出现在
   `/app/output/result.json`；`build` 逐键回填（缺值写 `null` 并记 `degradations`）。
5. **每个结论可追溯**：`result.claims[]` 每条含 `evidence.material` + `evidence.locator`（节点 id /
   段落 / 页 / 表行列）与 `evidence.quote`（逐字来自材料）；`content_map.json` 提供同源映射。
6. **`case_id` 与输入一致**；状态四态：`ok / partial / insufficient_evidence / input_error`。

## 3. 五命令主路径

```bash
python3 scripts/main.py init      # 扫 /input：解析 MathML、建材料索引、先写 partial result.json
python3 scripts/main.py show      # 打印公式对象（LaTeX/结构/符号）与带 locator 的原文
#   你可以亲自读材料并写 /app/work/draft.json（schema 见第 4 节）；不写也能 build（见第 9 节）
python3 scripts/main.py check     # 机械校验：结构计数、括号配平、符号覆盖、推导步骤、数值复算
python3 scripts/main.py build     # result.json + formulas.tex/.pdf + content_map.json + 符号表 + 推导 + 复算
python3 scripts/main.py selfcheck # 复查成品：契约键、case_id、公式结构、产物
```

默认路径 `/input`、`/app/work`、`/app/output`；本地可加 `--input/--work/--output`。
有工作稿时以工作稿为准（含原文逐字定义与语义推导）；没有工作稿时 `build` 用 XML 确定性派生
（真实抽取，不是编造），并把符号表/推导标为结构级缺口。**脚本不会代替你阅读与推导**；先读材料再写工作稿。

## 4. 工作稿 schema：`/app/work/draft.json`

```json
{
  "case_id": "<与输入一致>",
  "formulas": [
    {"formula_id": "eq1", "eq_number": "(1)", "latex": "v = \\sqrt{2gh}",
     "parse_confidence": 0.98,
     "source": {"material": "artifacts/source-formulas.xml", "node_id": "eq1"},
     "notation_notes": "根号覆盖 2gh 整体；乘法号在原文中省略"}
  ],
  "variables": [
    {"symbol": "v", "definition": "impact speed of the falling sphere", "unit": "m/s",
     "range": "v >= 0 during the drag-free fall", "definition_basis": "original",
     "quote": "论文中的逐字定义句",
     "source": {"material": "materials/paper.md", "paragraph_id": "P001", "section": "Results"},
     "inference_reason": "单位为推断时写理由", "formula_ids": ["eq1", "eq2"]}
  ],
  "derivations": [
    {"derivation_id": "D1", "formula_id": "eq1", "depends_on": ["eq1"],
     "steps": [
       {"step_no": 1, "statement_latex": "mgh = \\frac{1}{2}mv^{2}",
        "justification": "机械能守恒", "assumption": "无空气阻力、质点"},
       {"step_no": 2, "statement_latex": "gh = \\frac{1}{2}v^{2}", "justification": "两边除以 m"}
     ],
     "assumptions": ["drag-free"], "approximations": ["g 在落程内为常数"],
     "boundary_conditions": ["h >= 0", "v >= 0"]}
  ],
  "numeric_checks": [
    {"check_id": "N1", "formula_id": "eq1", "expression": "sqrt(2*g*h)",
     "substitutions": {"g": 9.81, "h": 2.0}, "expected": 6.26, "computed": 6.264,
     "tolerance": 0.01, "unit": "m/s", "result": "pass",
     "assumptions": ["drag-free fall"]}
  ],
  "uncertainties": [], "pending_human": []
}
```

规则：
- `latex` 与 MathML 结构一致：`\frac` 数量 = `mfrac` 数量；上下标、根号、矩阵/分段函数不得丢。
- `variables` 必须覆盖公式里出现的每个符号（含希腊字母与多字母标识符）；`definition_basis` ∈
  `original`（论文原文定义，必须给逐字 quote + locator）/ `inferred`（上下推断，写理由）/
  `common_knowledge`（标准约定，写理由）。
- 无量纲量 `unit` 写 `-`，不要猜单位；单位来自常识时在 `inference_reason` 注明。
- `derivations` 每步必须有 `statement_latex`，并带 `justification` 或 `assumption`；
  推导前提（守恒律、近似、边界条件）要显式写出。
- `numeric_checks` 的 `expression` 用受限算术（数字、`+-*/^`、`sqrt/log/exp/sin/cos/tan`、
  `pi/e`）；`substitutions` 只放数值；`computed` 会被脚本**独立复算**，对不上即 FAIL。
- 不可计算的检查写 `result="not_computable"` 并说明缺什么数据；不要伪造 pass。

## 5. 符号约定与判定口径

| 概念 | 口径 |
|---|---|
| `formula_id` | 取 XML 的 `id`/`xml:id`/`label`（如 `eq1`、`(1)`→`1`）；多个公式按文档顺序稳定编号 |
| 结构计数 | `mfrac/msub/msup/msubsup/msqrt/mroot/mtable/mfenced` 逐类计数，与 LaTeX 对照 |
| 多字母标识符 | `mi` 长度 > 1（如 `Re`）保留为 `\mathrm{Re}`，不得拆成 R·e |
| 希腊字母 | `ρ→\rho`、`μ→\mu`、`σ→\sigma`、`Δ→\Delta` 等确定性映射；不得用 ASCII 近似替代 |
| 实体/特殊符 | `<`/`>`/`&`/`%`/`#`/`_` 转义为 `\lt`/`\gt`/`\&`/`\%`/`\#`/`\_` |
| 单位 | 保留原文单位；换算另存原值 + 规则；`mV` ≠ `V` |
| 定义来源 | 原文定义=original（quote+locator）；推断=inferred（理由）；常识=common_knowledge（理由） |
| 数值复算 | `computed` 与沙箱复算结果相差 ≤0.1%（四舍五入允许）；`expected±tolerance` 决定 pass/fail |

## 6. 证据与定位规则

1. 变量定义证据单位 = 段落/表行；locator = `material` + (`paragraph_id` / `page` / `section`)。
2. quote 必须逐字来自材料（`show` 输出）；改写、翻译、拼接不算。
3. 公式来源 = publisher XML 文件名 + 公式节点 id；`mathml` 字段保存该节点的**逐字 XML 原文**
   作为公式还原结论的证据 quote。
4. 图注/表注里的符号说明同样有效，用 `section` 标注来源。
5. 扫描件无文本层时记 `no_text_layer` 并列入 `pending_human`（需要 OCR），不猜读。

## 7. `check` 做什么、会拦什么

- 源 XML 里的每个 `formula_id` 是否都有草稿条目（缺 = FAIL）；多出的（无源公式）= WARN。
- `\frac` 数与 MathML `mfrac` 数一致（不一致 = FAIL）；括号/花括号配平（不平衡 = FAIL/WARN）。
- 公式 `source.material` 是否存在（缺 = FAIL）。
- 符号覆盖：公式里出现的每个标识符都要在 `variables` 里（缺 = FAIL）。
- `definition_basis` 枚举合法；`original` 必须有逐字 quote + locator（不满足 = FAIL）。
- 推导每步有 `statement_latex` 且有 `justification`/`assumption`（缺 = FAIL）；依赖的
  `formula_id` 必须存在（悬空 = FAIL）。
- 数值检查：表达式可复算、`computed` 与复算一致、`expected±tolerance` 与 `result` 一致
  （不一致 = FAIL）。
- 产出 `work/check_report.json`；`build` 以它放行，并给每个公式/变量/数值检查写 `validation`。

## 8. 产物（`/app/output/`）

| 文件 | 内容 |
|---|---|
| `result.json` | 契约回填 + `result.formulas[]/variables[]/derivations[]/numeric_checks[]` + `coverage` + `method_notes` + 顶层 `claims[]`（每条带 `material`+`locator`+`quote`）+ `uncertainties` + `degradations` |
| `formulas.tex` | 每个公式一段 `\begin{equation}`，带 `% formula_id= / source=` 注释，可直接编译（可编辑源文件） |
| `formulas.pdf` | 真实导出件：优先用 TeX 引擎（tectonic/xelatex/pdflatex/latexmk）编译；无引擎时退化为逐字复现 `formulas.tex` 的最小合法 PDF，并在 `content_map.pdf_export` 里诚实标注方法 |
| `formula_directory.md` | 每个公式的 LaTeX、来源 ID、结构计数、结构推导步骤与数值核验摘要（可读目录） |
| `symbol_table.json` | 覆盖全部 `mi/mo/mn/mtext` token：`{symbol, latex, role, source_id, formula_id}` + 变量条目 |
| `symbol_table.csv` | 同上的表格视图（有 token 时按 token 输出，否则按变量定义输出） |
| `numeric_checks.json` | 每项检查 + 脚本独立复算值 + 说明 |
| `derivation_notes.md` | 推导分步、假设/近似/边界条件、数值检查摘要、降级记录 |
| `content_map.json` | 元素级内容映射：`formulas/variables/derivations/numeric_checks` 每个元素 → 输出文件 + `source`（material+locator）+ `quote`；另含 `output_files` 与 `pdf_export` 方法说明 |

## 9. 降级与异常处理

| 情况 | 行为 |
|---|---|
| 无公式表示（无 XML/公式节点） | `status=insufficient_evidence`，`formulas=[]`，写 `degradations` 与 `coverage_gap` claim；不反推、不填 0 |
| 有 XML、无工作稿 | `build` 用 `mathml_derive.py` 确定性派生：真实 LaTeX、全 token 符号表、结构推导、常数子式复算；符号定义留空并标 `inferred`，`status=partial` |
| 公式含符号未知量 | 该公式 `numeric_verification="not_applicable"`，绝不代入 0 或猜测值 |
| 公式含纯常数子式 | 仅对常数齐全的子式用 stdlib `math` 复算并记录；`status` 仍为 `partial`（定义未核） |
| 无 TeX 引擎 | `formulas.pdf` 退化为逐字复现源文件的最小合法 PDF，`content_map.pdf_export.method="text_pdf"` 写明 |
| `case.json` 坏 / 空 `/input` | `status=input_error`，仍写合法 `result.json` 与契约键 |
| 只有 case.json、没有材料 | `status=insufficient_evidence`，不编造公式 |
| 公式结构校验失败 | 该公式 `validation.ok=false`，`degradations` 记原因，不静默通过 |
| 数值不可复算 | `result="not_computable"` + 说明缺什么数据；不得写 pass |
| 图片/扫描件公式 | 记 `no_text_layer`，列入 `pending_human`（OCR/人工录入） |

所有命令退出码恒为 0；顶层异常触发 `emergency_finalize()` 写合法 partial 结果。

## 10. 提交前自检清单

- [ ] `init` 后 `/app/output/result.json` 已存在，契约键齐全，`case_id` 正确。
- [ ] 每个源公式都有条目，LaTeX 与 MathML 结构和符号一致，括号配平。
- [ ] 公式里每个符号都在符号表中；`original` 定义都带逐字 quote + locator。
- [ ] 推导步骤可检查，假设/近似/边界条件写清（结构派生时注明 provenance）。
- [ ] 数值检查的 `computed` 与复算一致；`not_applicable`/`not_computable` 有理由。
- [ ] `claims[]` 非空且每条有 `material`+`locator`+`quote`；`content_map.json` 与 `result.json` 元素一致。
- [ ] 九个产物存在且非空；`formulas.tex` 可编辑、`formulas.pdf` 以 `%PDF-` 开头可打开。
- [ ] 空输入 / 坏 JSON / 缺材料 / 无工作稿四种情况都 exit 0 且产出合法 partial 结果。

## 11. 最小调用示例（示例，非正式案例结果）

`artifacts/source-formulas.xml` 中的公式节点（节选）：

```xml
<disp-formula id="eq1"><label>(1)</label><mml:math><mml:mrow>
  <mml:mi>v</mml:mi><mml:mo>=</mml:mo>
  <mml:msqrt><mml:mrow><mml:mn>2</mml:mn><mml:mi>g</mml:mi><mml:mi>h</mml:mi></mml:mrow></mml:msqrt>
</mml:mrow></mml:math></disp-formula>
```

不写工作稿直接 `build`：`mathml_derive.py` 会输出 `v = \sqrt{2gh}`，符号表含 `v/g/h/2/=`
（每个 token 带 role 与来源 ID），结构推导列出 `mrow→msqrt→mi/mo/mn` 的逐步展开，
`numeric_verification="not_applicable"`（有符号未知量，不代入值）。写工作稿则补 `v/g/h` 三条
`original` 定义与推导 D1、数值检查 N1 `sqrt(2*g*h)`（g=9.81, h=2.0）。
`build` 后 `claims[]` 含"公式还原 / 符号定义 / 推导步骤 / 数值复算"四类结论，每条带逐字 quote；
`content_map.json` 把 `eq1` 指回 `artifacts/source-formulas.xml` 的 `node_id=eq1`。
**以上为示例（合成数据），非任何正式案例结果。**

## 12. 版本与维护

- 版本：1.2.0；包名 `math-expression-reader`。
- 依赖：Python 3.8+ 标准库；不联网；不依赖 CWD；无第三方包；无 `__pycache__`。
- 修改指引：MathML→LaTeX 在 `scripts/mml_lib.py`，无工作稿派生在 `scripts/mathml_derive.py`，
  校验/复算/claims/content_map 在 `scripts/math_check_lib.py`，流程在 `scripts/main.py`；
  改完必须重跑 `--help`、`init`、`build`、"无公式表示"特例与两次 build 字节一致校验。
- 适用范围与限制：JATS/MathML 出版商 XML 最佳；无 MathML 的扫描件需 OCR 或人工录入；
  复杂版面（多列公式、化学式、手写符号）可能降级为 partial 并写入缺口；
  无工作稿时只做**结构级**符号表与推导，论文定义与语义推导仍须 Agent 复核。

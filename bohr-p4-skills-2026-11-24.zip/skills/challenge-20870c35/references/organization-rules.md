# 学术汇报内容组织规则（可复用）

本文件是 `academic-deck-organizer` 的可复用组织方法，供 Agent 或人工复用；实现细节以 `scripts/` 为准。

## 1. 报告目标（goal）

从 `task_instruction` / `goal` 关键词映射为四种可检查目标，据此决定结论强度与取舍：

| goal id | 关键词 | 组织后果 |
|---|---|---|
| validate_novelty | novel/innovation/contribution/新颖/创新/贡献 | 强调方法创新点与边界，结论措辞保守，保留 limitation 页 |
| communicate_progress | progress/risk/进度/进展/风险 | 强调方法与进度，暴露未完成项与风险 |
| assess_conclusion | conclusion/evidence/结论/证据/strength | 强调结果证据强度与对照，数字/图表逐字对齐 |
| overview | 其它 | 主线综述，背景占比最高 |

## 2. 听众画像（audience）

| id | 命中关键词 | 背景页占比 bg_ratio | 强调角色 | 术语深度 | 问答焦点 |
|---|---|---|---|---|---|
| committee 答辩 | defense/dissertation/thesis/答辩 | 0.14 | method+conclusion | high | 新颖性、边界、贡献 |
| group 组会 | group/lab/team/组会/课题组 | 0.16 | method+result | high | 方法、进度、风险 |
| review 评审 | review/reviewer/评审/审稿 | 0.15 | result+limitation | high | 结论强度、证据、对照 |
| conference 会议 | conference/general/会议/报告 | 0.24 | background+result | medium | 意义、要点 |

听众只影响页外元信息（备注语气、背景页比例、问答焦点、术语深度），**不改写页内逐字内容**。

## 3. 叙事顺序（起承转合）

固定主骨架「问题—方法—结果—结论」，按 beat 标记：

- 起（opening）：title + background，讲问题与动机。
- 承（development）：method，讲方法如何回答问题。
- 转（turn）：result，讲证据与图表，数字/图号与原文一致。
- 合（close）：limitation + conclusion，讲边界与展望。

页数分配：`title(1) + background(bg) + method(m) + result(r) + limitation(0/1) + conclusion(1)`，总数恒等于 `slide_count`；超限时按「limitation→result→background→method」顺序删支撑细节页，保留主线。

## 4. 每页唯一主张（claim）与证据强度

每页一条 claim（原文逐字句子），bullets 是 claim 的逐字片段（逗号/分号/and/or 切分）。证据强度分级：

- measured：含数字且含图/表引用（最强）。
- reported：含数字，或含 showed/found/achieved/表明/达到 等结果词。
- stated：普通陈述。
- qualified：含 however/limited/should be/cannot/局限/尚需 等限定词。

## 5. 问答准备（QA）

按角色预判追问，每条回答点均指向「页号 + 逐字 quote + locator」：

- background：问题为什么重要？现有方法缺口？
- method：方法关键假设与替代方案？
- result：数字/图表能否复现？与对照差异？
- limitation：该局限对结论适用范围影响？
- conclusion：结论适用范围与下一步？

## 6. 证据定位规范

- locator 形如 `mN#pK`（材料 N 段 K）或 `mN#rowK`（表行 K）；与 `work/index.json` 一致。
- 每页 claim/bullets 均为材料原文逐字子串；`content_map.json` 逐页记录 source.path + locator + quote + verbatim_hit。
- 机械比对（去空白、小写）目标 `quote_hit_rate ≥ 0.95`。

## 7. 模板与降级

- `mode=create`：在模板 slideLayout 上以 `p:ph` 占位符加页，母版/版式/主题字节不变。
- `mode=edit`：保留起始 deck 已有页，把派生页追加到 `slide_count`，不覆盖起始内容。
- 无模板 → 包内 `assets/default_template.pptx`（16:9 母版 + 标题/标题内容版式 + 主题）。
- 无 LibreOffice → 标准库文本层 PDF（非拉丁字形近似 `?`），诚实标注 degradation。

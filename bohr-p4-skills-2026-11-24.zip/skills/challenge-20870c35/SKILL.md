---
name: academic-deck-organizer
description: Organize research material into an editable, evidence-mapped, audience-aware academic slide deck. One command reads /input, derives a page plan with verbatim quotes and locators, adapts narrative order/goal/audience, builds an editable .pptx inheriting the supplied template's masters/layouts/theme (or edits a supplied starting deck), exports a real PDF plus PNG previews, prepares per-page speaker notes and Q&A answers, and writes result.json echoing every output_contract field. Use when producing a talkable presentation (组会/答辩/评审/会议) from a paper or research material with template, audience, time and slide-count constraints.
version: 1.1.0
---

# academic-deck-organizer

## v1.1 修复版：运行契约与质量闸门

本 Skill 的默认入口是 `python3 scripts/main.py --input INPUT_DIR --work WORK_DIR --output OUTPUT_DIR`。运行前无需提供工作稿；若输入无有效事实材料，返回 `insufficient_evidence`，不生成虚构的研究结果。输入要求包含合法的 `case.json`，并按其中 `slide_count`/模板/模式约束构建真实 `.pptx`。

- **内容解析**：中英文 Markdown/纯文本标题与正文分开解析；正确按中文句号分句，保留逐字原文、页级 locator；同一段落内可补充 1–3 条可回查的原文要点。不能据此推断数据的科学正确性。
- **真实可编辑性**：使用 PPTX Open XML 的 slides、relationships、masters、layouts、theme、notes；创建模式不残留模板示例页；`edit` 仅保留既有页并**在页数预算内追加**，不支持任意局部替换。对未重新审计的旧页，运行结果为 `partial`。
- **强制校验**：逐页校验 claim、quote、每条 bullet 是否属于所指 locator；校验 `presentation.xml` 中的 slide ID、relationship、slideLayout 是否可解析，精确比较 PDF 与 PPTX 页数，检查模板母版/版式/主题部件的 SHA256 字节保持。
- **诚实降级**：只有真实 LibreOffice 导出、页数匹配、事实定位命中率 ≥0.95、模板字节保持且满足指定页数时，才可能 `status=ok`。没有 LibreOffice 时，生成的文本 PDF **不是 PPTX 的视觉渲染**，必须记为 `partial`；没有 `pdftoppm` 时不伪造 PNG 预览。扫描 PDF 与复杂公式须人工核验或另配 OCR/公式工具。
- **依赖**：Python 3.9+ 标准库；可选系统可执行文件 `pdftotext`（PDF 文字抽取）、LibreOffice `soffice`（真实 PDF 渲染）、`pdftoppm`（PNG 预览）。未安装这些可选程序时按对应步骤降级，不假装已完成渲染。
- **复现约束**：不保证不同 LibreOffice/字体环境产生二进制一致的 PDF（PDF 可能含时间等元数据）；应对比可打开性、页数、页面内容、版式检查与每页证据，不应以 PDF 哈希相同作为唯一判定标准。

**最小示例**（以下是接口测试示例，不是竞赛正式案例）：

```bash
mkdir -p /tmp/academic_case /tmp/academic_work /tmp/academic_output
printf '%s\n' '{"case_id":"example-001","title":"研究汇报","slide_count":4,"output_contract":{"presentation":"editable PPTX","pdf_export":"PDF","page_content_map":"sources"}}' > /tmp/academic_case/case.json
printf '%s\n' '# 研究汇报' '## 背景' '研究背景表明现有方法仍面临数据不足的问题。' '## 方法' '本研究收集多来源样本开展对照分析，并固定测试流程。' '## 结果' '实验显示该方案在当前样本中缩短检测时间，但不能推断所有环境。' '## 结论' '后续需要扩大样本并进行独立验证。' > /tmp/academic_case/paper.md
python3 scripts/main.py --input /tmp/academic_case --work /tmp/academic_work --output /tmp/academic_output
python3 -m json.tool /tmp/academic_output/result.json >/dev/null
```

四页只能在具有足够有效原文时形成有意义的内容。如果真实输入的证据不足，可能返回少页和 `partial`/`insufficient_evidence`，不能以重复编造句子补页。模板可以使用 `.pptx/.potx`，不接受旧二进制 `.ppt` 作为 OOXML 模板。


把论文/科研材料组织成**主线成立、页页可回溯、贴合听众与时长、可编辑、可放映**的学术汇报，而不是把摘要和 Results 逐段搬成页面。

## 用途与触发条件

适用：输入含论文或科研材料（PDF / DOCX / Markdown / TXT / CSV / TSV / SQLite / JSON / 图片），要求产出学术汇报 PPT；题面给出听众（audience）、时长（duration_minutes）、页数（slide_count）与模板约束，可选提供 `.pptx`/`.potx` 模板或起始 deck（`mode=edit` 时保留起始 deck）。要求数字/单位/图号与原文一致、模板母版/版式/主题能继承、导出能打开。

不适用：只要论文精读结论；只要科研绘图美化；只要文稿润色。材料完全缺失时写 `insufficient_evidence`，**绝不编造论文内容**。

## 调用方式

默认**单命令**即完整流程（不需要先写工作稿，也不需要多步交互）：

```bash
python3 scripts/main.py            # 读 /input → 派生页计划 → 构建 → 导出 → result.json
python3 scripts/main.py --input DIR --work DIR --output DIR
python3 scripts/main.py check      # 只诊断输入，不构建
```

环境变量 `INPUT_DIR` / `WORK_DIR` / `OUTPUT_DIR` 可覆盖默认 `/input` `/app/work` `/app/output`；也接受 `--input/--work/--output`。case 处理返回退出码 0。脚本用 `Path(__file__).resolve().parent` 定位自身，不依赖 CWD、不联网、只用 Python 标准库。无模板时使用包内 `assets/default_template.pptx`（16:9，含母版 + 标题/标题内容版式 + 主题）。

## 输入输出

| 项 | 路径 |
|---|---|
| 输入 | `/input/case.json`（`case_id`、`task_instruction`、`output_contract`；可含 `title`/`audience`/`goal`/`slide_count`/`duration_minutes`/`mode`/`template`/`deck` 等约束）、`/input/task.md`、`/input/` 下材料 |
| 工作区 | `/app/work/`：`index.json`（材料索引 + locator 段号） |
| 产物 | `/app/output/`：`result.json`（必需）、`presentation.pptx`、`presentation.pdf`、`preview/slide-*.png`、`content_map.json`、`page_plan.json`、`evidence_map.json`、`qa_prep.json`、`changes.json`、`template_check.json`、`export_check.json` |

## 派生方法（无工作稿自动完成）

1. **读材料**：PDF 用 `pdftotext`（无则标准库粗抽取）并回卷折行；DOCX 解包 `word/document.xml`；SQLite 读取表并序列化成行（结构化对象）；CSV/TSV 按行；图片登记为图资产。
2. **目标/听众识别**：从 `task_instruction`/`goal` 映射报告目标（验证新颖性 / 传达进度风险 / 评估结论强度 / 综述）；从 `audience` 映射听众画像（答辩、组会、评审、会议），决定背景页比例、术语深度、强调角色与问答焦点。
3. **主线派生**：识别章节标题（中英），按角色（title/background/method/result/limitation/conclusion）打分选取**原文逐字句子**作为每页 claim；数字密度与 Figure/Table 引用加权结果页。
4. **页计划**：`slide_count`（题面给则遵守，否则按 `duration_minutes` 估算，再否则 9）按"起承转合"叙事分配角色页；每页 claim + bullets 均为原文**逐字子串**；证据强度标注 measured/reported/stated/qualified。
5. **构建**：`mode=create` 在模板 `slideLayout` 上以 `p:ph` 占位符加页，母版/版式/主题字节不变；`mode=edit` 保留起始 deck 已有页，把派生页追加到 `slide_count`（不覆盖起始内容）。备注写入真实 `notesSlide` 部件。
6. **问答准备**：按角色预判机制/数据/对照/局限追问，每问指向页号 + 逐字 quote。
7. **导出与复核**：LibreOffice 可用则真渲染 PDF 并剥离时间戳元数据，否则写标准库文本层 PDF（`%PDF-` 头 + 页对象，页数=页数）；PNG 预览用 `pdftoppm`。

## 工作稿 schema（可选，非必需）

无工作稿时主脚本自动派生；如需人工干预，可在 `/app/work/plan.json` 放同构页计划（每页 `role/title/claim/bullets/claim_loc/claim_quote/figure_refs/evidence_strength`），主脚本检测到即优先采用（但 quote 仍逐字命中校验）。

## 证据规范（真实派生红线）

- 每页 `claim` 与每个 `bullet` 都是材料原文的**逐字子串**；`content_map.json` 逐页记录 `source.path` + `locator`（如 `m1#p3`）+ 逐字 `quote` + `verbatim_hit`。
- `quote_hit_rate` 机械比对（去空白、小写），目标 ≥0.95；页面数字/图号只来自原文，不生成"看起来像"的曲线，不把示意图当实验数据。
- `locator` 形如 `mN#pK`（段 K）或 `mN#rowK`（表行）；与 `index.json` 一致。
- 听众/目标/叙事/问答只影响**页外元信息**（notes、narrative、qa_prep、evidence_strength），不重写页内逐字内容。

## 降级表

| 情况 | 处置 | 记录 |
|---|---|---|
| 无模板 | 用包内默认学术模板 | `degradations` |
| 无 LibreOffice | 标准库文本层 PDF（非拉丁字形近似为 `?`） | `degradations` |
| PDF 为 CID/扫描 | 抽取失败则 `insufficient_evidence`，不编造 | `status` |
| 空 `/input` / 无 case.json | `status=input_error` + 最小合法 result.json | `errors` |
| case.json 坏 JSON | `status=input_error` | `errors` |
| 缺材料 | `status=insufficient_evidence` + gaps | `uncertainty` |
| 页数超限 | 按叙事顺序优先保留主线页，删支撑细节页 | `coverage` |
| mode=edit 起始 deck 已满页 | 保留起始 deck，新增页数为 0 | `degradations` |

任何异常都先写 partial `result.json` 再增量 finalize，case 处理返回退出码 0。

## 自检

- `python3 scripts/main.py`（默认）后：`result.json` 合法且回填 `output_contract` 每个键 + `case_id/status/sources/uncertainty/changes/errors/degradations`。
- `presentation.pptx` 可解压、含 `ppt/presentation.xml`、每页挂 slideLayout；`presentation.pdf` 有 `%PDF-` 头且页数=页数。
- 两次全新输出目录产物结构一致（无时间戳/随机；zip 固定时间戳，PDF 元数据可能随渲染环境变化）。
- 空/坏/缺三态各自退出 0 且 result.json 契约键齐全。

## 限制

- 不重绘论文图表，只保留图号与图注文字（图引用以 `figure_refs` + 逐字 quote 呈现）。
- 标准库 PDF 兜底仅 WinAnsi/Helvetica，中文/数学符号在兜底 PDF 中近似为 `?`（可编辑源 pptx 文本仍完整正确）。
- 不判断科学结论对错，只保证可回溯；扫描版 PDF 需 OCR 工具另行处理。
- 模板要求：`.pptx`/`.potx` 且至少含一个带标题占位符的 `slideLayout`。

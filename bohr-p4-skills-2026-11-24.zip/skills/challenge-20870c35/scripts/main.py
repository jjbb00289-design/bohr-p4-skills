#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""academic-deck-organizer: one command turns research material into an evidence-mapped deck."""
import argparse, json, os, re, shutil, sqlite3, subprocess, sys, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
sys.path.insert(0, str(Path(__file__).resolve().parent))
import deck
import qa_common as qac
from story import role_sequence, beat_of, notes, qa_of

VERSION, SKILL = "1.0.0", "academic-deck-organizer"
DEFAULTS = {"input": "/input", "work": "/app/work", "output": "/app/output"}
TEXT_EXT = {".md", ".markdown", ".txt", ".tex", ".rst", ".csv", ".tsv", ".json", ".yaml", ".yml", ".html", ".htm"}
DOC_EXT = {".docx"}
PDF_EXT = {".pdf"}
DECK_EXT = {".pptx", ".potx"}
IMG_EXT = {".png", ".jpg", ".jpeg", ".gif", ".bmp"}
DB_EXT = {".sqlite", ".sqlite3", ".db"}
FIG_PAT = re.compile(r'(Fig(?:ure|\.)?\.?\s*\d+[a-z]?|Table\s*\d+|Eq(?:uation)?\.?\s*\d+|Scheme\s*\d+)', re.I)
NUM_PAT = re.compile(r'-?\d+(?:\.\d+)?\s*(?:%|±|×|ms|s|mm|nm|μm|µm|µM|mM|M|mV|V|℃|°C|K|Hz|MHz|GHz|dB|mg|g|kg|mL|L|W|J|Pa|nM|pM)?\b')
ROLES = ["background", "method", "result", "limitation", "conclusion"]
HINTS = {"background": "problem challenge however although despite gap limited motivation objective herein propose aim goal 问题 挑战 不足 局限 目标 提出 旨在",
         "method": "method using dataset model algorithm pipeline architecture experimental protocol setup parameters collected samples framework trained evaluated 方法 模型 数据集 算法 实验 协议 采样 训练 评估",
         "result": "result figure fig table showed found achieved obtained increased decreased compared performance accuracy precision recall improve higher lower outperform reached yield 结果 如图 表 发现 达到 提升 降低 准确率",
         "limitation": "limitation limited future work further however should be caution small sample cannot does not remains 局限 不足 未来工作 进一步 然而 谨慎 样本 尚需",
         "conclusion": "conclusion summary overall we conclude demonstrate future work in conclusion these findings 结论 总结 综上 表明 证明 展望 未来工作"}
SECTION_KW = [("abstract", "background"), ("summary", "background"), ("introduction", "background"), ("background", "background"), ("related work", "background"), ("motivation", "background"), ("method", "method"), ("methods", "method"), ("materials", "method"), ("experimental", "method"), ("experiment", "method"), ("approach", "method"), ("implementation", "method"), ("model", "method"), ("result", "result"), ("results", "result"), ("evaluation", "result"), ("discussion", "discussion"), ("limitation", "limitation"), ("limitations", "limitation"), ("conclusion", "conclusion"), ("conclusions", "conclusion"), ("future work", "conclusion"), ("acknowledg", "skip"), ("reference", "skip"), ("摘要", "background"), ("引言", "background"), ("背景", "background"), ("相关工作", "background"), ("方法", "method"), ("实验", "method"), ("结果", "result"), ("讨论", "discussion"), ("局限", "limitation"), ("结论", "conclusion"), ("参考文献", "skip"), ("致谢", "skip")]
AUDIENCES = [{"key": ["committee", "defense", "dissertation", "thesis", "答辩", "评审委员会"], "id": "committee", "name": "答辩/委员会", "bg_ratio": 0.14, "emphasis": ["method", "conclusion"], "term_level": "high", "qa_focus": "novelty, boundary, contribution"},
             {"key": ["group", "lab", "team", "组会", "课题组"], "id": "group", "name": "组会/课题组", "bg_ratio": 0.16, "emphasis": ["method", "result"], "term_level": "high", "qa_focus": "method, progress, risk"},
             {"key": ["review", "reviewer", "peer", "评审", "审稿"], "id": "review", "name": "评审", "bg_ratio": 0.15, "emphasis": ["result", "limitation"], "term_level": "high", "qa_focus": "conclusion strength, evidence, control"},
             {"key": ["conference", "general", "public", "会议", "报告"], "id": "conference", "name": "会议/综述", "bg_ratio": 0.24, "emphasis": ["background", "result"], "term_level": "medium", "qa_focus": "significance, takeaway"}]
GOAL_KW = [("validate_novelty", ["novel", "innovation", "contribution", "新颖", "创新", "贡献"]), ("communicate_progress", ["progress", "risk", "进度", "进展", "风险", "milestone"]), ("assess_conclusion", ["conclusion", "evidence", "结论", "证据", "strength"])]


def jdump(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    t = path.with_name(path.name + ".tmp")
    t.write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    t.replace(path)


def jload(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8", errors="replace").lstrip("\ufeff"))
    except Exception:
        return default


def read_text(path):
    data = Path(path).read_bytes()
    for enc in ("utf-8", "utf-8-sig", "gb18030", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", "replace")


def norm(s):
    return re.sub(r"\s+", "", re.sub(r"[\u200b\u200c\u200d\ufeff]", "", str(s))).lower()


def resolve_io(argv):
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("--input"); p.add_argument("--work"); p.add_argument("--output")
    ns, _ = p.parse_known_args(argv)
    return {"input": Path(ns.input or os.environ.get("INPUT_DIR") or DEFAULTS["input"]), "work": Path(ns.work or os.environ.get("WORK_DIR") or DEFAULTS["work"]), "output": Path(ns.output or os.environ.get("OUTPUT_DIR") or DEFAULTS["output"])}


def _materialize_default_template():
    import base64, os, tempfile
    b64 = Path(__file__).resolve().parent.parent / "assets" / "default_template.txt"
    if b64.exists():
        out = Path(os.environ.get("WORK_DIR") or tempfile.gettempdir()) / "default_template.pptx"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(base64.b64decode(b64.read_text(encoding="ascii")))
        return out
    return _materialize_default_template()


def tpl_path():
    return _materialize_default_template()


def raw_pdf_text(data):
    out = []
    for m in re.finditer(rb"\(((?:\\.|[^\\()])*)\)\s*Tj|<([0-9A-Fa-f\s]+)>\s*Tj", data):
        s = m.group(1) if m.group(1) is not None else bytes.fromhex(m.group(2).decode())
        s = re.sub(rb"\\([()\\nrt])", lambda mm: {b"(": b"(", b")": b")", b"\\": b"\\", b"n": b"\n", b"r": b"\r", b"t": b"\t"}[mm.group(1)], s)
        out.append(s)
    return b"\n".join(out).decode("utf-8", "replace")


def extract_pdf(path):
    tool = deck.find_tool(["pdf-text-tool", "pdftotext"])
    if tool:
        base = os.path.basename(tool).lower()
        cmd = [tool, "-layout", "-enc", "UTF-8", str(path), "-"] if "pdftotext" in base else [tool, str(path)]
        try:
            r = subprocess.run(cmd, capture_output=True, timeout=180)
            if r.returncode == 0 and r.stdout.strip():
                return r.stdout.decode("utf-8", "replace")
        except Exception:
            pass
    return raw_pdf_text(Path(path).read_bytes())


def extract_docx(path):
    try:
        with zipfile.ZipFile(str(path)) as z:
            xml = z.read("word/document.xml")
    except Exception:
        return ""
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    return "\n".join("".join(t.text or "" for t in p.iter("{%s}t" % ns["w"])) for p in ET.fromstring(xml).iter("{%s}p" % ns["w"]))


def reflow(text):
    out, buf = [], ""
    for ln in text.split("\n"):
        s = ln.strip()
        if not s:
            if buf:
                out.append(buf); buf = ""
            continue
        if buf and re.search(r"[.!?。！？]\s*$", buf) and re.match(r"^[A-Z0-9\u4e00-\u9fff]", s):
            out.append(buf); buf = s
        else:
            buf = (buf + " " + s) if buf else s
    if buf:
        out.append(buf)
    return "\n\n".join(out)


def discover(d):
    return [p for p in sorted(d.rglob("*")) if p.is_file() and p.name not in ("case.json", "task.md")] if d.is_dir() else []


def sqlite_rows(path):
    rows = []
    try:
        con = sqlite3.connect("file:%s?mode=ro" % str(path).replace("\\", "/"), uri=True)
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        for t in [r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]:
            cols = [c[1] for c in cur.execute("PRAGMA table_info(%s)" % t)]
            for r in cur.execute("SELECT * FROM %s LIMIT 200" % t):
                rows.append(" | ".join("%s: %s" % (c, r[c]) for c in cols))
        con.close()
    except Exception:
        return []
    return rows


def build_materials(input_dir, files):
    mats, assets, decks = [], {}, []
    for f in files:
        ext = f.suffix.lower()
        mid = "m%d" % (len(mats) + len(decks) + 1)
        def add(t, segs):
            mats.append({"id": mid, "path": str(f), "type": t, "segments": segs})
        if ext in PDF_EXT:
            add("pdf", [{"locator": "%s#p%d" % (mid, i + 1), "text": s} for i, s in enumerate(reflow(p) for p in extract_pdf(f).split("\f")) if s.strip()])
        elif ext in DOC_EXT:
            add("docx", [{"locator": "%s#p%d" % (mid, i + 1), "text": s.strip()} for i, s in enumerate(extract_docx(f).split("\n")) if s.strip()])
        elif ext in DB_EXT:
            add("table", [{"locator": "%s#row%d" % (mid, i + 1), "text": s.strip()} for i, s in enumerate(sqlite_rows(f)) if s.strip()])
        elif ext in TEXT_EXT:
            text = read_text(f)
            if ext in (".csv", ".tsv"):
                add("table", [{"locator": "%s#row%d" % (mid, i + 1), "text": s.strip()} for i, s in enumerate(text.splitlines()) if s.strip()])
            elif ext in (".json", ".yaml", ".yml"):
                add("text", [{"locator": "%s#p%d" % (mid, i + 1), "text": s} for i, s in enumerate(text.split("\n")) if s.strip()])
            else:
                add("text", [{"locator": "%s#p%d" % (mid, i + 1), "text": s} for i, s in enumerate(line.strip() for line in text.splitlines()) if s])
        elif ext in IMG_EXT:
            assets[str(f)] = str(f)
        elif ext in DECK_EXT:
            decks.append(f)
        else:
            add("unknown", [{"locator": "%s#0" % mid, "text": str(f)}])
    return mats, assets, decks


def is_heading(line):
    line = line.strip()
    if not line or len(line) > 90 or re.match(r"^(figure|fig\.?|table)\s+\d", line, re.I):
        return False
    if re.match(r"^\s*(#+\s|\d+(\.\d+)*[\.、\)]\s|[一二三四五六七八九十]+[、.]\s)", line):
        return True
    if len(line) <= 60 and line.isupper():
        return True
    low = line.lower()
    return any(low == kw or low.startswith(kw + " ") for kw, _ in SECTION_KW)


def split_sentences(text):
    return qac.split_sentences(text)


def collect_sentences(mats):
    return qac.collect_sentences(mats, FIG_PAT, NUM_PAT)


def score(s, role):
    low = s["text"].lower()
    sc = sum(1 for h in HINTS[role].split() if h in low)
    if role == "result":
        sc += min(len(s["numbers"]), 6) + 3 * len(s["figures"])
    if s["section"] == role:
        sc += 2
    elif s["section"] == "discussion" and role in ("result", "limitation", "conclusion"):
        sc += 1
    return sc


def candidates(sents, role, used):
    cs = [s for s in sents if norm(s["text"]) not in used]
    cs.sort(key=lambda s: (-score(s, role), abs(len(s["text"]) - 140)))
    return cs


def bullets(sentence, n=4):
    frags = re.split(r"\s*[,;:—–]\s*|\s+\band\b\s+|\s+\bor\b\s+|\s+\.\s+", sentence)
    out, seen = [], set()
    for f in frags:
        f = f.strip()
        if 8 <= len(f) <= 160 and norm(f) not in seen:
            seen.add(norm(f)); out.append(f)
        if len(out) >= n:
            break
    return out or [sentence[:160]]


def title_of(case, mats):
    for k in ("title", "title_zh", "deck_title"):
        if isinstance(case.get(k), str) and case.get(k).strip():
            return case.get(k).strip()[:90]
    for m in mats:
        for seg in m["segments"][:3]:
            t = seg["text"].strip()
            if t and not is_heading(t):
                return t[:90]
    for m in mats:
        if m["segments"]:
            return m["segments"][0]["text"].strip()[:90]
    return "Academic Presentation"


def slide_count(case):
    for src in (case, case.get("constraints") or {}):
        for k in ("slide_count", "slides", "max_slides", "num_slides", "page_limit"):
            if isinstance(src.get(k), int) and 2 <= src.get(k) <= 60:
                return src.get(k)
    dur = case.get("duration_minutes") or (case.get("constraints") or {}).get("duration_minutes")
    if isinstance(dur, (int, float)) and dur > 0:
        return max(2, min(60, int(round(dur / 1.5))))
    return 9


def audience_of(case):
    raw = " ".join(str(case.get(k) or "") for k in ("audience", "audience_type", "listeners", "target_audience")).lower()
    for prof in AUDIENCES:
        if any(k in raw for k in prof["key"]):
            return prof
    return AUDIENCES[3]


def goal_of(case):
    raw = " ".join(str(case.get(k) or "") for k in ("goal", "report_goal", "task_instruction", "objective")).lower()
    for gid, kws in GOAL_KW:
        if any(k in raw for k in kws):
            return gid
    return "overview"


def evidence_strength(sent):
    low = sent["text"].lower()
    qual = any(w in low for w in ("however", "although", "despite", "limited", "should be", "cannot", "does not", "remains", "further work", "caution", "局限", "不足", "尚需", "谨慎"))
    if qual:
        return "qualified"
    if sent["numbers"] and sent["figures"]:
        return "measured"
    if sent["numbers"] or any(w in low for w in ("showed", "found", "demonstrate", "achieved", "obtained", "we show", "results", "发现", "达到", "表明")):
        return "reported"
    return "stated"


def derive_pages(mats, case):
    sents, heads = collect_sentences(mats)
    if not sents:
        return [], heads, None, None
    title = title_of(case, mats)
    n = slide_count(case)
    aud = audience_of(case)
    goal = goal_of(case)
    has_lim = any(score(s, "limitation") >= 1 for s in sents)
    roles = role_sequence(n, has_lim, aud["bg_ratio"])
    used = set()
    pages = []
    first = candidates(sents, "background", set())
    sub = first[0] if first else None
    pages.append({"role": "title", "title": title, "claim": sub["text"][:200] if sub else "", "bullets": [], "claim_loc": sub["locator"] if sub else None, "claim_quote": sub["text"] if sub else None, "figure_refs": [], "evidence_strength": evidence_strength(sub) if sub else "stated"})
    if sub:
        used.add(norm(sub["text"]))
    pools = {r: candidates(sents, r, used) for r in ROLES}
    for role in roles[1:]:
        sent = None
        pool = pools.get(role)
        if pool:
            while pool and norm(pool[0]["text"]) in used:
                pool.pop(0)
            if pool:
                sent = pool.pop(0); used.add(norm(sent["text"]))
        if sent is None:
            for s in sents:
                if norm(s["text"]) not in used:
                    sent = s; used.add(norm(s["text"])); break
        if sent is None:
            continue
        head = heads.get(role)
        pages.append({"role": role, "title": head["text"] if head else bullets(sent["text"], 1)[0][:60], "claim": sent["text"], "bullets": bullets(sent["text"], 4), "claim_loc": sent["locator"], "claim_quote": sent["text"], "figure_refs": sent["figures"], "evidence_strength": evidence_strength(sent)})
    for i, p in enumerate(pages):
        p["beat"] = beat_of(p["role"], i, len(pages))
    return pages, heads, aud, goal


def find_template_deck(case, files, input_dir):
    pptx = [f for f in files if f.suffix.lower() in (".pptx", ".potx")]
    def ref(v):
        if not isinstance(v, str) or not v.strip():
            return None
        p = Path(v)
        return (p if p.is_absolute() else input_dir / p) if (p if p.is_absolute() else input_dir / p).exists() else None
    tpl = ref(case.get("template") or case.get("template_path") or case.get("template_file"))
    dk = ref(case.get("deck") or case.get("starting_deck") or case.get("start_deck") or case.get("deck_path") or case.get("input_deck"))
    rest = [f for f in pptx if f != tpl and f != dk]
    if tpl is None and dk is None:
        if len(pptx) == 1:
            return pptx[0], None
        if len(pptx) >= 2:
            by = sorted(pptx, key=lambda f: deck.slide_count_of(f))
            return by[0], by[-1]
    if tpl is None and rest:
        tpl = rest[0]
    if dk is None and rest:
        dk = rest[-1]
    return tpl, dk


def fill(k, editable, export, cm, notes_out, plan, qa, narrative, n):
    kl = k.lower()
    if kl.endswith("_count") or kl in ("slides", "pages", "slide_count", "page_count"):
        return n
    if any(w in kl for w in ("content", "claim", "evidence", "map")):
        return cm
    if any(w in kl for w in ("note", "script", "speaker")):
        return notes_out
    if any(w in kl for w in ("qa", "question", "q&a")):
        return qa
    if any(w in kl for w in ("plan", "golden")):
        return plan
    if any(w in kl for w in ("narrative", "story", "ordering")):
        return narrative
    if any(w in kl for w in ("ppt", "presentation", "deck", "editable")):
        return editable
    if any(w in kl for w in ("pdf", "export", "render", "preview", "png")):
        return export
    if any(w in kl for w in ("page", "slide")):
        return plan
    return None


def minimal(case_id, status, errs, mats, case):
    oc = (case.get("output_contract") or {}) if isinstance(case, dict) else {}
    r = {"case_id": case_id, "status": status}
    for k in oc:
        r[k] = None
    r["output_contract"] = oc
    r["sources"] = [{"id": m["id"], "path": m["path"], "type": m["type"]} for m in mats]
    r["uncertainty"] = ["no usable evidence extracted"]
    r["changes"] = []
    r["errors"] = errs
    r["degradations"] = []
    r["coverage"] = {"pages": 0, "slides": 0, "quote_hit_rate": 0.0, "roles": []}
    r["skill"] = {"name": SKILL, "version": VERSION}
    return r


def load_plan(work, pages, mats):
    pj = jload(work / "plan.json")
    if isinstance(pj, dict) and isinstance(pj.get("pages"), list) and pj["pages"] and qac.evidence(pj["pages"], mats)[0] == 1.0:
        return pj["pages"]
    return pages


def run_pipeline(io):
    work, out = io["work"], io["output"]
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    jdump(out / "result.json", {"case_id": "", "status": "partial", "errors": ["pipeline started"], "sources": [], "uncertainty": [], "changes": [], "degradations": []})
    cp = io["input"] / "case.json"
    if not (io["input"].is_dir() and cp.exists()):
        jdump(out / "result.json", minimal("", "input_error", ["case.json not found"], [], {}))
        return 0
    try:
        case = json.loads(cp.read_text(encoding="utf-8", errors="replace").lstrip("\ufeff"))
        if not isinstance(case, dict):
            case = {}
    except Exception as e:
        jdump(out / "result.json", minimal("", "input_error", ["case.json invalid: %s" % e], [], {}))
        return 0
    case_id = case.get("case_id") or case.get("id") or ""
    degs = []
    files = discover(io["input"])
    mats, assets, decks = build_materials(io["input"], files)
    jdump(work / "index.json", {"case_id": case_id, "materials": [{"id": m["id"], "path": m["path"], "type": m["type"], "segments": len(m["segments"])} for m in mats], "assets": sorted(assets), "decks": [str(d) for d in decks]})
    if not mats:
        jdump(out / "result.json", minimal(case_id, "insufficient_evidence", ["no readable material"], mats, case))
        return 0
    pages, heads, aud, goal = derive_pages(mats, case)
    pages = qac.enrich_pages(pages, mats, FIG_PAT, NUM_PAT)
    pages = load_plan(work, pages, mats)
    if not pages:
        jdump(out / "result.json", minimal(case_id, "insufficient_evidence", ["no usable sentences"], mats, case))
        return 0

    tpl, dk = find_template_deck(case, files, io["input"])
    mode, base = "create", tpl
    if dk is not None:
        mode, base = "edit", dk
    if base is None:
        base = tpl_path() if tpl_path().exists() else None
        degs.append("no template supplied; used bundled default academic template")
    target_n = slide_count(case)
    to_build = pages
    if mode == "edit":
        degs.append("edit mode preserves source slides; original slide claims are not revalidated")
        try:
            existing = deck.slide_count_of(str(base))
        except Exception:
            existing = 0
        room = max(0, target_n - existing)
        to_build = pages[:room]
        if room < len(pages):
            degs.append("edit mode: starting deck has %d slides; kept and added %d of %d derived pages (slide_count=%d)" % (existing, room, len(pages), target_n))

    for i, p in enumerate(to_build):
        p["notes_lines"] = notes(p, to_build[i + 1]["title"] if i + 1 < len(to_build) else "", aud, goal)

    if base is None:
        jdump(out / "result.json", minimal(case_id, "partial", ["no template asset available"], mats, case))
        return 0
    try:
        report = deck.build_deck(str(base), to_build, str(out / "presentation.pptx"), mode=mode)
    except Exception as e:
        jdump(out / "result.json", minimal(case_id, "partial", ["build failed: %s" % e], mats, case))
        return 0

    engine = deck.render_pdf_soffice(str(out / "presentation.pptx"), str(out / "presentation.pdf"))
    pdf = out / "presentation.pdf"
    if not engine:
        try:
            deck.write_text_pdf(to_build, str(pdf))
            engine = "text-layer-pdf"
            degs.append("no LibreOffice/office-renderer; PDF is a text-layer render")
        except Exception:
            degs.append("PDF export failed")
    pngs = []
    if pdf.exists():
        (out / "preview").mkdir(parents=True, exist_ok=True)
        ppm = deck.find_tool(["pdftoppm", "pdf-render-tool"])
        if ppm:
            try:
                base_name = os.path.basename(ppm).lower()
                cmd = [ppm, "-png", "-r", "90", str(pdf), str(out / "preview" / "slide")] if "pdftoppm" in base_name else [ppm, str(pdf), str(out / "preview")]
                r = subprocess.run(cmd, capture_output=True, timeout=120)
                if r.returncode == 0:
                    pngs = sorted("preview/" + p.name for p in (out / "preview").glob("slide-*.png"))
            except Exception:
                pass

    template_integrity = qac.compare_template_parts(base, out / "presentation.pptx")
    if not template_integrity["ok"]:
        degs.append("master/layout/theme byte preservation failed: %s" % template_integrity["changed_parts"])
    v = qac.verify_pptx(out / "presentation.pptx")
    pp, hdr = deck.pdf_page_count(pdf) if pdf.exists() else (0, False)
    cn = norm("\n".join(seg["text"] for m in mats for seg in m["segments"]))
    lp = {m["id"]: m["path"] for m in mats}
    cm, hits = [], 0
    for i, p in enumerate(to_build):
        q = p.get("claim_quote") or ""
        hit = bool(norm(q)) and norm(q) in cn
        hits += 1 if hit else 0
        loc = p.get("claim_loc") or ""
        ev = [{"type": "sentence", "locator": loc, "quote": q, "verbatim_hit": hit}] + [{"type": "figure", "id": fr, "locator": loc, "quote": q} for fr in (p.get("figure_refs") or [])]
        cm.append({"n": i + 1, "role": p["role"], "beat": p.get("beat"), "title": p["title"], "claim": p["claim"], "bullets": p["bullets"], "evidence_strength": p["evidence_strength"], "source": {"path": lp.get(loc.split("#")[0] if loc else "", ""), "locator": loc}, "evidence": ev, "figure_refs": p.get("figure_refs") or [], "notes": p["notes_lines"]})
    qhr, page_hits, evidence_problems = qac.evidence(to_build, mats)
    for e, good in zip(cm, page_hits):
        for ev in e.get("evidence", []):
            if ev.get("type") == "sentence": ev["verbatim_hit"] = good

    qa = qa_of(to_build, aud)
    narrative = [{"n": i + 1, "beat": p.get("beat"), "role": p["role"], "title": p["title"], "transition": notes(p, "", aud, goal)[0]} for i, p in enumerate(to_build)]

    expected = case.get("slide_count") or (case.get("constraints") or {}).get("slide_count")
    if isinstance(expected, int) and v["slides"] != expected:
        degs.append("slide_count mismatch: expected %d, got %d" % (expected, v["slides"]))
    if not hdr or pp != v["slides"]:
        degs.append("PDF page count/header invalid: pdf=%d, pptx=%d" % (pp, v["slides"]))
    if engine == "text-layer-pdf":
        degs.append("text-only PDF is NOT a visual render of PPTX; presentation quality unverified")
    if evidence_problems:
        degs.append("unverified per-page claim/bullet citations: %d" % len(evidence_problems))
    verified_render = engine == "libreoffice" and hdr and pp == v["slides"]
    verified_pages = not isinstance(expected,int) or v["slides"] == expected
    quality_ok = bool(to_build if mode != "edit" else v["slides"]) and qhr >= 0.95 and v["ok"] and verified_render and verified_pages and template_integrity["ok"] and mode != "edit"
    editable = {"path": "presentation.pptx", "slides": v["slides"], "mode": mode, "template": {"path": str(base), "master_sha256": report.get("master_sha", {}), "layouts_used": [pg.get("layout") for pg in report.get("pages", [])]}, "verification": v}
    export = {"pdf": {"path": "presentation.pdf", "engine": engine or "none", "pages": pp, "header_ok": hdr}, "previews": pngs}
    notes_out = [{"n": i + 1, "lines": p["notes_lines"]} for i, p in enumerate(to_build)]
    plan = [{"n": i + 1, "role": p["role"], "beat": p.get("beat"), "title": p["title"], "claim": p["claim"], "evidence_strength": p["evidence_strength"], "locator": p.get("claim_loc"), "quote": p.get("claim_quote")} for i, p in enumerate(to_build)]
    sources = [{"id": m["id"], "path": m["path"], "type": m["type"], "locator_scheme": "mN#pK"} for m in mats]
    unc = (["quote_hit_rate %.3f < 1.0" % qhr] if qhr < 1.0 else []) + (["no PDF produced"] if not engine else []) + (["no PNG previews"] if not pngs else [])
    unc.extend("evidence mismatch slide %d at %s" % (p["slide"], p["locator"]) for p in evidence_problems)
    changes = [{"step": "derive", "action": "derived %d pages from %d materials; audience=%s goal=%s" % (len(to_build), len(mats), aud["id"], goal)}, {"step": "build", "action": "built pptx (mode=%s, preserved=%d, added=%d)" % (mode, report.get("preserved", 0), report.get("added", 0))}, {"step": "export", "action": "PDF engine=%s; %d PNG previews" % (engine or "none", len(pngs))}]
    oc = case.get("output_contract") or {}
    result = {"case_id": case_id, "status": "ok" if quality_ok else "partial"}
    for k in oc:
        result[k] = fill(k, editable, export, cm, notes_out, plan, qa, narrative, v["slides"])
    result["case_id"] = case_id
    result["status"] = "ok" if quality_ok else "partial"
    result.update({"output_contract": oc, "audience": aud, "goal": goal, "editable_source": editable, "export_artifact": export, "content_map": cm, "page_plan": plan, "narrative": narrative, "qa_prep": qa, "coverage": {"pages": len(to_build), "slides": v["slides"], "quote_hit_rate": qhr, "roles": [p["role"] for p in to_build]}, "sources": sources, "uncertainty": unc, "evidence_problems": evidence_problems, "changes": changes, "errors": [], "degradations": degs, "template_integrity": template_integrity, "skill": {"name": SKILL, "version": VERSION}})
    jdump(out / "content_map.json", cm)
    jdump(out / "page_plan.json", plan)
    jdump(out / "evidence_map.json", [{"n": i + 1, "evidence": e["evidence"]} for i, e in enumerate(cm)])
    jdump(out / "qa_prep.json", qa)
    jdump(out / "narrative.json", narrative)
    jdump(out / "changes.json", changes)
    jdump(out / "template_check.json", {"master_sha256": report.get("master_sha", {}), "theme_sha256": report.get("theme_sha", {}), "layouts_available": len(deck.analyze(str(base))["layouts"])})
    jdump(out / "export_check.json", {"pptx": v, "pdf": {"pages": pp, "header_ok": hdr, "engine": engine or "none"}, "previews": len(pngs)})
    jdump(out / "result.json", result)
    return 0


def cmd_check(io):
    print(json.dumps({"input_dir": str(io["input"]), "case_exists": (io["input"] / "case.json").exists(), "materials": [p.name for p in discover(io["input"])]}, ensure_ascii=False, indent=2))
    return 0


def main(argv):
    io = resolve_io(argv)
    try:
        p = argparse.ArgumentParser(prog=SKILL, description="research material -> editable, evidence-mapped, audience-aware deck")
        p.add_argument("--input"); p.add_argument("--work"); p.add_argument("--output")
        p.add_argument("command", nargs="?", default="run", help="run (default) | check | init | show | build")
        p.add_argument("--version", action="version", version=SKILL + " " + VERSION)
        args = p.parse_args(argv)
    except SystemExit:
        return 0
    if args.command == "check":
        return cmd_check(io)
    run_pipeline(io)
    return 0


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except Exception:
        try:
            sys.stderr.write("unhandled error; writing emergency partial\n")
        except Exception:
            pass
        try:
            io = resolve_io(sys.argv[1:])
            io["output"].mkdir(parents=True, exist_ok=True)
            current_case = jload(io["input"] / "case.json", {}) or {}
            case_id = current_case.get("case_id") or current_case.get("id") or ""
            r = minimal(case_id, "partial", ["unexpected pipeline error; check inputs and dependencies"], [], current_case)
            r["degradations"] = ["emergency finalize; no success claimed"]
            jdump(io["output"] / "result.json", r)
        except Exception:
            pass
    sys.exit(0)

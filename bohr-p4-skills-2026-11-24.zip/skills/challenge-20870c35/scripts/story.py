"""Audience-aware narrative sequencing and speaker notes."""

def role_sequence(n, has_lim, bg_ratio):
    if n <= 1:
        return ["title"][:n]
    seq = ["title"]
    slots = n - 1
    bg = max(1, round(slots * bg_ratio))
    method = max(1, round(slots * 0.25))
    res = max(1, slots - bg - method - 1 - (1 if has_lim else 0))
    seq += ["background"] * bg + ["method"] * method + ["result"] * res + (["limitation"] if has_lim else []) + ["conclusion"]
    while len(seq) > n:
        for drop in ("limitation", "result", "background", "method"):
            if drop in seq:
                seq.remove(drop)
                break
        else:
            seq = seq[:n]
            break
    while len(seq) < n:
        seq.append("result")
    return seq


def beat_of(role, idx, total):
    if idx == 0 or role == "background":
        return "起"
    if role == "method":
        return "承"
    if role == "result":
        return "转"
    return "合"


def notes(page, nxt, aud, goal):
    goal_txt = {"validate_novelty": "目标：认可创新点与边界", "communicate_progress": "目标：讲清方法与进度风险", "assess_conclusion": "目标：认可结论证据强度", "overview": "目标：讲清主线要点"}[goal]
    trans = {"title": "开场：说明范围、来源与目标（%s）。" % goal_txt, "background": "过渡：先讲问题与动机。", "method": "强调：方法如何回答问题。", "result": "强调：数值与图表编号须与原文一致。", "limitation": "诚实说明局限与边界。", "conclusion": "总结主线并展望。"}.get(page.get("role"), "")
    return [trans, "听众:%s；术语深度=%s" % (aud["name"], aud["term_level"]), "强调点: %s" % (page.get("claim") or "")[:100], "证据强度: %s" % page.get("evidence_strength"), "证据定位: %s" % (page.get("claim_loc") or ""), "被追问时: 引用 content_map.json 逐字 quote。"] + (["下一页: %s" % nxt] if nxt else [])


def qa_of(pages, aud):
    q = {"background": "这个问题为什么重要？现有方法缺口在哪？", "method": "方法关键假设与替代方案？", "result": "该数字/图表能否复现？与对照差异？", "limitation": "该局限对结论适用范围影响多大？", "conclusion": "结论适用范围与下一步？", "title": "本次汇报的主线与结论？"}
    return [{"n": i + 1, "question": q.get(p["role"], "请解释本页结论。"), "answer_points": ["见第%d页：%s" % (i + 1, (p.get("claim") or "")[:120]), "逐字证据: %s" % (p.get("claim_quote") or ""), "定位: %s" % (p.get("claim_loc") or "")], "page_ref": i + 1, "focus": aud["qa_focus"]} for i, p in enumerate(pages)]

import qa_common as qac
"""Stdlib OOXML deck builder + PDF/PNG renderer."""
import hashlib, os, posixpath, re, shutil, subprocess, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

A = "http://schemas.openxmlformats.org/drawingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
P = "http://schemas.openxmlformats.org/presentationml/2006/main"
PKG = "http://schemas.openxmlformats.org/package/2006/relationships"
TS, TL, TM = R + "/slide", R + "/slideLayout", R + "/slideMaster"
TN, TNM, TH = R + "/notesSlide", R + "/notesMaster", R + "/theme"
CT_P = "application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"
CT_S = "application/vnd.openxmlformats-officedocument.presentationml.slide+xml"
CT_L = "application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"
CT_M = "application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"
CT_T = "application/vnd.openxmlformats-officedocument.theme+xml"
CT_N = "application/vnd.openxmlformats-officedocument.presentationml.notesSlide+xml"
CT_NM = "application/vnd.openxmlformats-officedocument.presentationml.notesMaster+xml"


def sha(b): return hashlib.sha256(b).hexdigest()


def esc(s): return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def ea(s): return esc(s).replace('"', "&quot;")


def cjk(s): return any("\u4e00" <= c <= "\u9fff" for c in str(s))


def _t(ns, t): return "{%s}%s" % (ns, t)


def read_package(p):
    with zipfile.ZipFile(str(p)) as z:
        parts = {n: z.read(n) for n in z.namelist()}
    if "[Content_Types].xml" not in parts:
        raise ValueError("not OOXML")
    return parts


def write_package(parts, p):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(str(p), "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(parts, key=lambda n: (0 if n == "[Content_Types].xml" else 1, n)):
            zi = zipfile.ZipInfo(n, date_time=(2026, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(zi, parts[n])


def _rels(parts, part):
    d, n = posixpath.split(part)
    rp = posixpath.join(d, "_rels", n + ".rels")
    if rp not in parts:
        return {}
    return {r.get("Id"): {"type": r.get("Type"), "target": r.get("Target")} for r in ET.fromstring(parts[rp])}


def _res(base, target):
    return target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join(posixpath.dirname(base), target))


def _ph_records(root):
    out = []
    for sp in root.iter(_t(P, "sp")):
        nv = sp.find(_t(P, "nvSpPr"))
        if nv is None:
            continue
        nvpr = nv.find(_t(P, "nvPr"))
        ph = nvpr.find(_t(P, "ph")) if nvpr is not None else None
        if ph is None:
            continue
        xfrm = None
        sppr = sp.find(_t(P, "spPr"))
        if sppr is not None:
            x = sppr.find(_t(A, "xfrm"))
            if x is not None:
                off, ext = x.find(_t(A, "off")), x.find(_t(A, "ext"))
                try:
                    xfrm = [int(off.get("x")), int(off.get("y")), int(ext.get("cx")), int(ext.get("cy"))]
                except Exception:
                    pass
        out.append({"type": ph.get("type") or "obj", "idx": ph.get("idx") or "", "xfrm": xfrm})
    return out


def analyze_parts(parts):
    root = ET.fromstring(parts["ppt/presentation.xml"])
    masters = sorted(n for n in parts if re.match(r"ppt/slideMasters/slideMaster\d+\.xml$", n))
    layouts = sorted((n for n in parts if re.match(r"ppt/slideLayouts/slideLayout\d+\.xml$", n)), key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    themes = sorted(n for n in parts if re.match(r"ppt/theme/theme\d+\.xml$", n))
    linfos = [{"part": n, "type": ET.fromstring(parts[n]).get("type") or "", "placeholders": _ph_records(ET.fromstring(parts[n]))} for n in layouts]
    slides, prel = [], _rels(parts, "ppt/presentation.xml")
    sll = root.find(_t(P, "sldIdLst"))
    if sll is not None:
        for sid in sll:
            rel = prel.get(sid.get("{%s}id" % R) or sid.get("id"))
            if rel:
                sp = _res("ppt/presentation.xml", rel["target"])
                if sp in parts:
                    slides.append(sp)
    if not slides:
        slides = sorted((n for n in parts if re.match(r"ppt/slides/slide\d+\.xml$", n)), key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    return {"masters": masters, "layouts": linfos, "themes": themes, "slides": slides}


def analyze(p): return analyze_parts(read_package(p))


def slide_count_of(p): return len(analyze(p)["slides"])


def _run(text, sz, bold=False):
    lang = "zh-CN" if cjk(text) else "en-US"
    return ('<a:r><a:rPr lang="%s" altLang="en-US" sz="%d" b="%d" dirty="0"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/></a:rPr><a:t>%s</a:t></a:r>' % (lang, int(sz * 100), 1 if bold else 0, esc(text)))


def _para(text, sz, bold=False, bullet=None):
    inner = "<a:buNone/>" if bullet == "none" else ('<a:buFont typeface="Arial"/><a:buChar char="\u2022"/>' if bullet == "dot" else "")
    return "<a:p><a:pPr>%s</a:pPr>%s</a:p>" % (inner, _run(text, sz, bold))


def _sp(sid, name, xfrm, paras, ph=None):
    phx = ('<p:ph type="%s" idx="%s"/>' % (ph[0], ph[1])) if ph else ""
    nvpr = ('<p:nvPr>%s</p:nvPr>' % phx) if ph else "<p:nvPr/>"
    cns = '<p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr>' if ph else '<p:cNvSpPr txBox="1"/>'
    sppr = ('<p:spPr><a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>%s</p:spPr>' % (xfrm[0], xfrm[1], xfrm[2], xfrm[3], "" if ph else "<a:noFill/>"))
    af = "norm" if ph else "no"
    return ('<p:sp><p:nvSpPr><p:cNvPr id="%d" name="%s"/>%s%s</p:nvSpPr>%s<p:txBody><a:bodyPr wrap="square" lIns="91440" tIns="45720" rIns="91440" bIns="45720"><a:%sAutofit/></a:bodyPr><a:lstStyle/>%s</p:txBody></p:sp>' % (sid, ea(name), cns, nvpr, sppr, af, "".join(paras)))


def slide_xml(shapes):
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<p:sld xmlns:a="%s" xmlns:r="%s" xmlns:p="%s"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>%s</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>' % (A, R, P, "".join(shapes)))


def _notes_master_xml():
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<p:notesMaster xmlns:a="%s" xmlns:r="%s" xmlns:p="%s"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr><p:sp><p:nvSpPr><p:cNvPr id="2" name="Notes"/><p:cNvSpPr/><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp></p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/></p:notesMaster>' % (A, R, P))


def notes_xml(lines):
    ps = "".join("<a:p>%s</a:p>" % _run(t, 12) for t in (lines or ["(no notes)"]))
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<p:notes xmlns:a="%s" xmlns:r="%s" xmlns:p="%s"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr><p:sp><p:nvSpPr><p:cNvPr id="2" name="Notes"/><p:cNvSpPr/><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/>%s</p:txBody></p:sp></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:notes>' % (A, R, P, ps))


def _fit(bullets, title):
    w = sum(0.55 if ord(c) < 128 else 1.0 for b in bullets for c in str(b))
    size = 14 if w > 430 else 15 if w > 340 else 16 if w > 260 else 17 if w > 200 else 18 if w > 150 else 20
    ts = 30 if len(str(title)) <= 42 else (26 if len(str(title)) <= 60 else 22)
    return size, ts


def _placeholders_of(lay):
    tp = bp = None
    best = -1
    for ph in lay.get("placeholders") or []:
        if ph["type"] in ("title", "ctrTitle") and tp is None:
            tp = ph
        if ph["type"] in ("body", "obj", "subTitle"):
            area = ph["xfrm"][2] * ph["xfrm"][3] if ph.get("xfrm") else 0
            if area > best:
                best, bp = area, ph
    return tp, bp


def _pick_layout(layouts, role):
    for typ in ["ctrTitle", "title"] if role == "title" else ["secHead", "titleOnly"]:
        for i, lay in enumerate(layouts):
            if typ in {p["type"] for p in lay["placeholders"]}:
                return i
    for i, lay in enumerate(layouts):
        ts = {p["type"] for p in lay["placeholders"]}
        if "title" in ts and ({"body", "obj"} & ts):
            return i
    for i, lay in enumerate(layouts):
        if "title" in {p["type"] for p in lay["placeholders"]}:
            return i
    return 0 if layouts else None


def _compose(page, layout):
    tp, bp = _placeholders_of(layout)
    title = str(page.get("title") or "")
    bullets = [str(b) for b in (page.get("bullets") or []) if str(b).strip()]
    size, ts = _fit(bullets, title)
    shapes, rep = [], {"placeholders": [], "freetext": 0}
    sid = 2
    ta = list(tp["xfrm"]) if tp and tp.get("xfrm") else [914400, 457200, 10363200, 1371600]
    ba = list(bp["xfrm"]) if bp and bp.get("xfrm") else [914400, 1600200, 10363200, 4572000]
    if tp:
        ps = [_para(title, ts, True, "none")] if title else []
        if tp["type"] == "ctrTitle" and page.get("claim"):
            ps.append(_para(str(page["claim"]), 16, False, "none"))
        shapes.append(_sp(sid, "Title", ta, ps or ['<a:p><a:endParaRPr lang="en-US"/></a:p>'], (tp["type"], tp.get("idx") or "")))
        rep["placeholders"].append({"ph": "title", "type": tp["type"]})
        sid += 1
    elif title:
        shapes.append(_sp(sid, "Title", ta, [_para(title, ts, True, "none")]))
        rep["freetext"] += 1
        sid += 1
    if bp and bullets:
        shapes.append(_sp(sid, "Body", ba, [_para(b, size, bullet="dot") for b in bullets], (bp["type"], bp.get("idx") or "")))
        rep["placeholders"].append({"ph": "body", "type": bp["type"]})
        sid += 1
    elif bullets:
        shapes.append(_sp(sid, "Body", ba, [_para(b, size, bullet="dot") for b in bullets]))
        rep["freetext"] += 1
    return slide_xml(shapes), rep


def _rel_xml(rels):
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', '<Relationships xmlns="%s">' % PKG]
    for rid, r in rels.items():
        out.append('<Relationship Id="%s" Type="%s" Target="%s"/>' % (ea(rid), ea(r["type"]), ea(r["target"])))
    out.append("</Relationships>")
    return "".join(out)


def build_deck(base_path, pages, out_path, mode="create"):
    parts = read_package(base_path)
    info = analyze_parts(parts)
    layouts = info["layouts"]
    if not layouts:
        raise ValueError("no slideLayout in template")
    kept = list(info["slides"]) if mode in ("edit", "adapt") else []
    if mode not in ("edit", "adapt"):
        parts = qac.strip_existing_slide_parts(parts)
    ct = parts["[Content_Types].xml"].decode("utf-8")
    pres_xml = parts["ppt/presentation.xml"].decode("utf-8")
    prel = _rels(parts, "ppt/presentation.xml")
    used = set(prel)
    nr = [1]

    def new_rid():
        while "rId%d" % nr[0] in used:
            nr[0] += 1
        used.add("rId%d" % nr[0])
        return "rId%d" % nr[0]

    nid = [max([int(s) + 1 for s in re.findall(r'sldId id="(\d+)"', pres_xml)] or [256])]
    nm_rid = next((r for r in prel if prel[r]["type"] == TNM), None)
    if not any(n.startswith("ppt/notesMasters/") for n in parts):
        parts["ppt/notesMasters/notesMaster1.xml"] = _notes_master_xml().encode("utf-8")
        trel = {"rId1": {"type": TH, "target": posixpath.relpath(info["themes"][0], "ppt/notesMasters").replace("\\", "/")}} if info["themes"] else {}
        parts["ppt/notesMasters/_rels/notesMaster1.xml.rels"] = _rel_xml(trel).encode("utf-8")
        if CT_NM not in ct:
            ct = ct.replace("</Types>", '<Override PartName="/ppt/notesMasters/notesMaster1.xml" ContentType="%s"/></Types>' % CT_NM)
        nm_rid = new_rid()
        prel[nm_rid] = {"type": TNM, "target": "notesMasters/notesMaster1.xml"}

    def add_ct(x, part, ctype):
        return x if ('PartName="/%s"' % part) in x else x.replace("</Types>", '<Override PartName="/%s" ContentType="%s"/></Types>' % (part, ctype))

    entries = []
    for i, page in enumerate(pages):
        no = len(kept) + i + 1
        layout = layouts[_pick_layout(layouts, page.get("role", "content"))]
        xml, slrep = _compose(page, layout)
        sp = "ppt/slides/slide%d.xml" % no
        parts[sp] = xml.encode("utf-8")
        srels = {"rId1": {"type": TL, "target": posixpath.relpath(layout["part"], "ppt/slides").replace("\\", "/")}, "rId2": {"type": TN, "target": "../notesSlides/notesSlide%d.xml" % no}}
        npart = "ppt/notesSlides/notesSlide%d.xml" % no
        parts[npart] = notes_xml(page.get("notes_lines") or []).encode("utf-8")
        parts["ppt/notesSlides/_rels/notesSlide%d.xml.rels" % no] = _rel_xml({"rId1": {"type": TS, "target": "../slides/slide%d.xml" % no}, "rId2": {"type": TNM, "target": "../notesMasters/notesMaster1.xml"}})
        parts["ppt/slides/_rels/slide%d.xml.rels" % no] = _rel_xml(srels)
        ct = add_ct(ct, sp, CT_S)
        ct = add_ct(ct, npart, CT_N)
        r = new_rid()
        entries.append('<p:sldId id="%d" r:id="%s"/>' % (nid[0], r))
        nid[0] += 1
        prel[r] = {"type": TS, "target": "slides/slide%d.xml" % no}

    if "<p:notesMasterIdLst>" not in pres_xml:
        ins = '<p:notesMasterIdLst><p:notesMasterId r:id="%s"/></p:notesMasterIdLst>' % nm_rid
        pres_xml = pres_xml.replace("<p:sldIdLst>", ins + "<p:sldIdLst>", 1) if "<p:sldIdLst>" in pres_xml else pres_xml.replace("<p:sldIdLst/>", ins + "<p:sldIdLst/>", 1)
    body = "".join(entries)
    pres_xml = pres_xml.replace("</p:sldIdLst>", body + "</p:sldIdLst>") if "</p:sldIdLst>" in pres_xml else pres_xml.replace("<p:sldIdLst/>", "<p:sldIdLst>" + body + "</p:sldIdLst>")
    pres_xml = qac.write_presentation_ids(pres_xml, entries, nm_rid, edit=mode in ("edit", "adapt"))
    parts["ppt/presentation.xml"] = pres_xml if isinstance(pres_xml, bytes) else pres_xml.encode("utf-8")
    parts["ppt/_rels/presentation.xml.rels"] = _rel_xml(prel).encode("utf-8")
    parts["[Content_Types].xml"] = ct.encode("utf-8")
    write_package(parts, out_path)
    return {"mode": mode, "preserved": len(kept), "added": len(pages), "master_sha": {m: sha(parts[m]) for m in info["masters"]}, "theme_sha": {t: sha(parts[t]) for t in info["themes"]},
            "pages": [{"n": len(kept) + i + 1, "role": pg.get("role"), "layout": layouts[_pick_layout(layouts, pg.get("role", "content"))]["part"]} for i, pg in enumerate(pages)]}


def verify_pptx(path):
    try:
        parts = read_package(path)
    except Exception as e:
        return {"ok": False, "problems": [str(e)], "slides": 0, "has_presentation": False}
    problems = []
    if "ppt/presentation.xml" not in parts:
        problems.append("missing presentation.xml")
    slides = sorted((n for n in parts if re.match(r"ppt/slides/slide\d+\.xml$", n)), key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    nl = sum(1 for s in slides if not any(r["type"] == TL for r in _rels(parts, s).values()))
    if nl:
        problems.append("%d slides without layout" % nl)
    return {"ok": not problems and bool(slides), "problems": problems, "slides": len(slides), "has_presentation": "ppt/presentation.xml" in parts}


def pdf_page_count(path):
    data = Path(path).read_bytes()
    hdr = data[:1024].startswith(b"%PDF-")
    pages = 0
    for m in re.finditer(rb"/Type\s*/Pages[^>]*?/Count\s+(\d+)", data):
        pages = max(pages, int(m.group(1)))
    if not pages:
        pages = len(re.findall(rb"/Type\s*/Page[^>]", data))
    return pages, hdr


def find_tool(names):
    for name in names:
        p = shutil.which(name)
        if p:
            return p
    root = os.path.join(os.environ.get("LOCALAPPDATA", ""), "com.bohrium.runtime")
    if os.path.isdir(root):
        for dp, _d, fns in os.walk(root):
            for fn in fns:
                base = fn.lower()
                if any(base.startswith(n.lower()) and base.endswith(".exe") for n in names):
                    return os.path.join(dp, fn)
    return None


def render_pdf_soffice(pptx, out_pdf):
    so = find_tool(["soffice", "libreoffice", "office-renderer"])
    if not so:
        return None
    tmp = Path(out_pdf).parent / ".soffice_tmp"
    tmp.mkdir(parents=True, exist_ok=True)
    try:
        subprocess.run([so, "--headless", "--convert-to", "pdf", "--outdir", str(tmp), str(pptx)], check=True, timeout=180, capture_output=True)
    except Exception:
        return None
    prod = tmp / (Path(pptx).stem + ".pdf")
    if prod.exists():
        shutil.move(str(prod), str(out_pdf))
        shutil.rmtree(str(tmp), ignore_errors=True)
        # Keep the PDF byte stream intact; removing metadata with regex corrupts xref offsets.
        return "libreoffice"
    return None


def _pesc(s):
    s = str(s).encode("latin-1", "replace").decode("latin-1")
    return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def write_text_pdf(pages, out_pdf):
    objs = ["<< /Type /Catalog /Pages 2 0 R >>", "<< /Type /Pages /Kids [%s] /Count %d >>" % (" ".join("%d 0 R" % (5 + 2 * i) for i in range(len(pages))), len(pages)), "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"]
    for i, page in enumerate(pages):
        cid = 4 + 2 * i
        lines = []
        if page.get("title"):
            lines.append("BT /F1 20 Tf 54 720 Td (%s) Tj ET" % _pesc(str(page.get("title"))[:80]))
        y = 660.0
        for b in (page.get("bullets") or [])[:8]:
            lines.append("BT /F1 13 Tf 60 %d Td (%s) Tj ET" % (int(y), _pesc(("\u2022 " + str(b))[:110])))
            y -= 26.0
        if page.get("claim") and page.get("role") == "title":
            lines.append("BT /F1 12 Tf 54 620 Td (%s) Tj ET" % _pesc(str(page.get("claim"))[:100]))
        lines.append("BT /F1 9 Tf 560 30 Td (%d) Tj ET" % (page.get("n", i + 1)))
        content = "\n".join(lines).encode("latin-1", "replace")
        objs.append("<< /Length %d >>\nstream\n" % len(content) + content.decode("latin-1") + "\nendstream")
        objs.append("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R >> >> /Contents %d 0 R >>" % cid)
    out = ["%PDF-1.4"]
    for i, o in enumerate(objs, 1):
        out.append("%d 0 obj" % i)
        out.append(o)
        out.append("endobj")
    pos = len(out[0]) + 1
    offsets = []
    for o in out[1:]:
        offsets.append(pos)
        pos += len(o) + 1
    out.append("xref")
    out.append("0 %d" % (len(objs) + 1))
    out.append("0000000000 65535 f ")
    for p in offsets:
        out.append("%010d 00000 n " % p)
    out.append("trailer")
    out.append("<< /Size %d /Root 1 0 R >>" % (len(objs) + 1))
    out.append("startxref")
    out.append(str(pos))
    out.append("%%EOF")
    Path(out_pdf).write_bytes(("\n".join(out) + "\n").encode("latin-1", "replace"))

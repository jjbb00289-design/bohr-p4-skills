"""Shared, dependency-free input/evidence and OOXML integrity helpers (v1.1)."""
import re
import posixpath
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

P = "http://schemas.openxmlformats.org/presentationml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKGREL = "http://schemas.openxmlformats.org/package/2006/relationships"
ET.register_namespace("p", P)
ET.register_namespace("r", R)
ET.register_namespace("a", "http://schemas.openxmlformats.org/drawingml/2006/main")


def normalized(s):
    return re.sub(r"\s+", "", str(s or "").replace("\u200b", "").replace("\ufeff", "")).casefold()


def sections(lines):
    """Emit only headings with a recognizable academic section role; preserve titles."""
    mapping = {"abstract":"background", "summary":"background", "introduction":"background",
      "background":"background", "related work":"background", "motivation":"background",
      "method":"method", "methods":"method", "materials":"method", "experimental":"method",
      "experiment":"method", "experiments":"method", "approach":"method", "implementation":"method",
      "result":"result", "results":"result", "evaluation":"result", "discussion":"discussion",
      "limitation":"limitation", "limitations":"limitation", "conclusion":"conclusion",
      "conclusions":"conclusion", "future work":"conclusion", "references":"skip",
      "reference":"skip", "acknowledgments":"skip", "摘要":"background", "引言":"background",
      "背景":"background", "相关工作":"background", "方法":"method", "实验":"method",
      "实验结果":"result", "结果":"result", "讨论":"discussion", "局限":"limitation",
      "局限性":"limitation", "结论":"conclusion", "展望":"conclusion",
      "参考文献":"skip", "致谢":"skip"}
    for raw in lines:
        line=raw.strip()
        if not line: continue
        # Recognize a whole heading line; a full sentence containing a section word is never a heading.
        t=re.sub(r"^(?:#{1,6}\s*|\d+(?:\.\d+)*[.、)]?\s+|[一二三四五六七八九十]+[、.]\s*)", "", line).strip()
        t=t.rstrip(":：").strip()
        low=t.casefold()
        role=mapping.get(low)
        if role is None and len(low)<=55 and "。" not in low and ". " not in low:
            for kw in sorted(mapping,key=len,reverse=True):
                if low.startswith(kw+" ") and len(low.split())<=5:
                    role=mapping[kw];break
        if role is not None:
            yield ("heading",role,t)
        elif re.match(r"^#{1,6}\s",line):
            yield ("otherheading",None,t)
        else:
            yield ("text",None,line)


def split_sentences(value):
    # Chinese punctuation is not normally followed by whitespace; decimals are not split.
    value=str(value).replace("\u3000"," ")
    pieces=re.split(r"(?<=[。！？!?])\s*|(?<=[.])\s+(?=[A-Z0-9\u4e00-\u9fff])",value)
    out=[]
    for p in pieces:
        p=p.strip()
        if not p: continue
        if len(p)>520:
            out.extend(x.strip() for x in re.split(r"(?<=[；;])\s*",p) if 12<=len(x.strip())<=520)
        else:out.append(p)
    return out


def collect_sentences(materials, fig_pat, num_pat):
    result,headings=[],{}
    for m in materials:
        section="background"
        for seg in m.get("segments",[]):
            for kind, role, text in sections(str(seg.get("text","")).splitlines()):
                if kind=="heading":
                    section=None if role=="skip" else role
                    if section:
                        headings.setdefault(section,{"text":text[:60],"locator":seg["locator"]})
                    continue
                if kind=="otherheading" or section is None:continue
                for s in split_sentences(text):
                    if 12 <= len(s) <= 520:
                        result.append({"text":s,"locator":seg["locator"],"section":section,
                                       "figures":fig_pat.findall(s),"numbers":num_pat.findall(s)})
    return result,headings


def evidence(pages,materials):
    locators={seg.get("locator"):str(seg.get("text","")) for m in materials for seg in m.get("segments",[])}
    valid=[]; problems=[]
    for i,p in enumerate(pages,1):
        loc=p.get("claim_loc") or p.get("locator")
        text=locators.get(loc,"")
        quote=p.get("claim_quote") or p.get("quote") or ""
        claim=p.get("claim") or ""
        bullets=p.get("bullets") or []
        hit=bool(text and quote and normalized(quote) in normalized(text) and claim and normalized(claim) in normalized(quote))
        if not isinstance(bullets,list):hit=False
        else:
            for b in bullets:
                if not b or normalized(b) not in normalized(text):
                    hit=False;break
        valid.append(hit)
        if not hit:problems.append({"slide":i,"locator":loc,"reason":"claim/quote/bullet is not supported by its cited source segment"})
    return (sum(valid)/len(valid) if valid else 0.0),valid,problems


def enrich_pages(pages, materials, fig_pat, num_pat):
    """Add directly sourced, complementary bullets from the SAME cited paragraph/line.
    No summarization, no numbers invented, and manual bullets are never removed.
    """
    sentences, _ = collect_sentences(materials, fig_pat, num_pat)
    groups = {}
    for sent in sentences:
        groups.setdefault(sent["locator"], []).append(sent["text"])
    for p in pages:
        if p.get("role") == "title" or not p.get("claim_loc"):
            continue
        cur = [str(v) for v in (p.get("bullets") or []) if str(v).strip()]
        seen = {normalized(v) for v in cur}
        for text in groups.get(p.get("claim_loc"), []):
            if len(cur) >= 3: break
            if not 14 <= len(text) <= 155: continue
            if normalized(text) not in seen:
                cur.append(text); seen.add(normalized(text))
        p["bullets"] = cur[:3]
        figures = list(p.get("figure_refs") or [])
        for value in cur:
            for f in fig_pat.findall(value):
                if f not in figures:figures.append(f)
        p["figure_refs"] = figures
    return pages


def compare_template_parts(template, output):
    """Byte-preservation check for slide master, layout and theme parts."""
    import hashlib
    names=re.compile(r"^ppt/(slideMasters|slideLayouts|theme)/.+\.(?:xml|rels)$")
    try:
        with zipfile.ZipFile(template) as a, zipfile.ZipFile(output) as b:
            source={n:hashlib.sha256(a.read(n)).hexdigest() for n in a.namelist() if names.match(n)}
            built={n:hashlib.sha256(b.read(n)).hexdigest() for n in b.namelist() if names.match(n)}
            changed=[n for n,v in source.items() if built.get(n)!=v]
            return {"ok":bool(source) and not changed,"original_parts":len(source),"changed_parts":changed}
    except Exception as e:
        return {"ok":False,"original_parts":0,"changed_parts":["comparison failed: %s"%e]}

def slide_target(parent, target):
    return target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join(posixpath.dirname(parent),target))


def strip_existing_slide_parts(parts):
    """Create mode: remove old slide/notes artifacts AND presentation links, keep masters/layouts/theme."""
    parts=dict(parts)
    for key in list(parts):
        if (re.fullmatch(r"ppt/slides/slide\d+\.xml",key) or
            re.fullmatch(r"ppt/slides/_rels/slide\d+\.xml\.rels",key) or
            re.fullmatch(r"ppt/notesSlides/notesSlide\d+\.xml",key) or
            re.fullmatch(r"ppt/notesSlides/_rels/notesSlide\d+\.xml\.rels",key)):
            del parts[key]
    if "[Content_Types].xml" in parts:
        s=parts["[Content_Types].xml"].decode("utf-8")
        s=re.sub(r'<Override\s+PartName="/ppt/(?:slides/slide\d+|notesSlides/notesSlide\d+)\.xml"[^>]*/>',"",s)
        parts["[Content_Types].xml"]=s.encode("utf-8")
    rel_key="ppt/_rels/presentation.xml.rels"
    if rel_key in parts:
        rel=ET.fromstring(parts[rel_key])
        for e in list(rel):
            if (e.get("Type") or "").endswith("/slide"):
                rel.remove(e)
        parts[rel_key]=ET.tostring(rel,encoding="utf-8",xml_declaration=True)
    if "ppt/presentation.xml" in parts:
        root=ET.fromstring(parts["ppt/presentation.xml"])
        lst=root.find("{%s}sldIdLst"%P)
        if lst is not None:
            root.remove(lst)
        parts["ppt/presentation.xml"]=ET.tostring(root,encoding="utf-8",xml_declaration=True)
    return parts


def write_presentation_ids(pres_xml, entries, notes_master_rel=None, edit=False):
    """Ensure every newly written slide is actually registered in presentation.xml."""
    root=ET.fromstring(pres_xml)
    lst=root.find("{%s}sldIdLst"%P)
    if lst is None:
        lst=ET.Element("{%s}sldIdLst"%P)
        target=next((i for i,e in enumerate(list(root)) if e.tag in
          ("{%s}sldSz"%P,"{%s}notesSz"%P,"{%s}defaultTextStyle"%P)),len(root))
        root.insert(target,lst)
    if not edit:
        for e in list(lst):lst.remove(e)
    existing={e.get("{%s}id"%R) for e in lst}
    for item in entries:
        match=re.search(r'\bid="(\d+)"\s+r:id="([^"]+)"',item)
        if match and match.group(2) not in existing:
            ET.SubElement(lst,"{%s}sldId"%P,{"id":match.group(1),"{%s}id"%R:match.group(2)})
            existing.add(match.group(2))
    nml=root.find("{%s}notesMasterIdLst"%P)
    if notes_master_rel and nml is None:
        nml=ET.Element("{%s}notesMasterIdLst"%P)
        ET.SubElement(nml,"{%s}notesMasterId"%P,{"{%s}id"%R:notes_master_rel})
        root.insert(list(root).index(lst),nml)
    return ET.tostring(root,encoding="utf-8",xml_declaration=True)


def verify_pptx(path):
    problems=[]
    try:
        with zipfile.ZipFile(path) as z:
            if z.testzip() is not None:problems.append("ZIP checksum failure")
            names=set(z.namelist())
            pres=ET.fromstring(z.read("ppt/presentation.xml"))
            rel=ET.fromstring(z.read("ppt/_rels/presentation.xml.rels"))
            rr={e.get("Id"):e for e in rel}
            sl=pres.find("{%s}sldIdLst"%P)
            ids=list(sl) if sl is not None else []
            if not ids:problems.append("missing or empty p:sldIdLst")
            for item in ids:
                rid=item.get("{%s}id"%R)
                r=rr.get(rid)
                if r is None or not (r.get("Type") or "").endswith("/slide"):
                    problems.append("slide relationship missing: %s"%rid);continue
                part=slide_target("ppt/presentation.xml",r.get("Target") or "")
                if part not in names:
                    problems.append("missing slide part: %s"%part);continue
                rp=posixpath.join("ppt/slides/_rels",posixpath.basename(part)+".rels")
                if rp not in names:
                    problems.append("missing slide relationships: %s"%part);continue
                sr=ET.fromstring(z.read(rp))
                if not any((e.get("Type") or "").endswith("/slideLayout") and
                    slide_target(part,e.get("Target") or "") in names for e in sr):
                    problems.append("missing or unresolved slide layout: %s"%part)
                ET.fromstring(z.read(part))
            parts={n for n in names if re.fullmatch(r"ppt/slides/slide\d+\.xml",n)}
            if len(ids)!=len(parts):problems.append("slide ID count differs from slide XML parts")
            return {"ok":not problems,"slides":len(ids),"problems":problems,"has_presentation":True}
    except Exception as e:
        return {"ok":False,"slides":0,"problems":["invalid pptx: %s"%e],"has_presentation":False}

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Methods & Experiments chapter writer — CLI dispatcher (stdlib only, no network).

Single command (no subcommand) = full pipeline: material extraction -> work-draft
scaffold -> quote validation -> editable artifacts + result.json. Exit code always 0.
"""
import argparse
import json
import os
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import writer  # noqa: E402


def _write_emergency(output_dir, work_dir, errors, degradations):
    try:
        output_dir.mkdir(parents=True, exist_ok=True)
        target = output_dir
    except Exception:
        try:
            work_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        target = work_dir
    res = {"case_id": "", "status": "input_error", "schema_version": writer.SCHEMA,
           "sources": [], "uncertainty": [], "change_records": [],
           "errors": errors, "degradations": degradations}
    try:
        (target / "result.json").write_text(
            json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def _write_partial_result(output_dir, draft, errors, degradations):
    try:
        output_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        return
    contract = draft.get("contract", {})
    res = {"case_id": draft.get("case_id", ""),
           "status": draft.get("overall_status", "insufficient_evidence"),
           "schema_version": writer.SCHEMA}
    for k in contract:
        v = writer.find_contract_value(draft, k)
        res[k] = v if v is not None else writer.default_for_contract(contract[k])
    res["sources"] = writer.collect_sources(draft)
    res["uncertainty"] = writer.build_uncertainty(draft)
    res["change_records"] = []
    res["errors"] = errors
    res["degradations"] = degradations
    try:
        (output_dir / "result.json").write_text(
            json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def do_init(input_dir, work_dir, output_dir, errors, degradations):
    case, task_md, materials, errs, case_error = writer.discover_input(input_dir)
    errors.extend(errs)
    work_dir.mkdir(parents=True, exist_ok=True)
    mat_dir = work_dir / "materials"
    mat_dir.mkdir(parents=True, exist_ok=True)
    index = []
    for i, m in enumerate(materials):
        if m.get("text"):
            safe = "%03d__%s" % (i, re.sub(r"[^A-Za-z0-9._-]+", "_", Path(m["name"]).name))
            (mat_dir / safe).write_text(m["text"], encoding="utf-8")
        index.append({"name": m["name"], "path": m["path"], "kind": m["kind"],
                      "note": m["note"], "chars": len(m.get("text") or "")})
    (work_dir / "material_index.json").write_text(
        json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8")
    draft_path = work_dir / "draft.json"
    draft = _load_draft(work_dir, None)
    if draft is None or not writer.draft_has_content(draft):
        draft = writer.derive_draft(case, task_md, materials, errors)
        if case_error:
            draft["overall_status"] = "input_error"
        elif not materials:
            draft["overall_status"] = "insufficient_evidence"
        draft_path.write_text(json.dumps(draft, ensure_ascii=False, indent=2), encoding="utf-8")
        print("init: derived draft.json (%d sections, %d materials)" % (len(draft["sections"]), len(materials)))
    else:
        print("init: draft.json exists; kept")
    _write_partial_result(output_dir, draft, errors, degradations)


def _load_draft(work_dir, fallback):
    dp = work_dir / "draft.json"
    if dp.exists():
        d = writer.load_json(dp)
        if isinstance(d, dict):
            return d
    return fallback


def _load_or_derive(work_dir, case, task_md, materials, errors):
    draft = _load_draft(work_dir, None)
    if draft is not None and writer.draft_has_content(draft):
        return draft
    return writer.derive_draft(case, task_md, materials, errors)


def do_show(input_dir, work_dir, errors):
    case, task_md, materials, errs, _ = writer.discover_input(input_dir)
    errors.extend(errs)
    draft = _load_or_derive(work_dir, case, task_md, materials, errors)
    report = writer.validate_draft(draft, materials)
    print("case_id=%s status=%s format=%s materials=%d" % (
        draft.get("case_id", ""), draft.get("overall_status", ""), draft.get("format", ""), len(materials)))
    for sec in draft.get("sections", []):
        body = "yes" if (sec.get("body_md") or "").strip() else "empty"
        print("  section %-18s body=%-5s sentences=%d" % (
            sec.get("section_id", ""), body, len(sec.get("sentences", []))))
    rate = report["quote_rate"]
    print("quote hit: %s/%s (rate=%s)" % (
        report["quote_hits"], report["quote_total"], ("%.2f" % rate) if rate is not None else "n/a"))


def do_check(input_dir, work_dir, errors):
    case, task_md, materials, errs, _ = writer.discover_input(input_dir)
    errors.extend(errs)
    draft = _load_or_derive(work_dir, case, task_md, materials, errors)
    report = writer.validate_draft(draft, materials)
    report["case_id"] = draft.get("case_id", "")
    work_dir.mkdir(parents=True, exist_ok=True)
    (work_dir / "check_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    rate = report["quote_rate"]
    print("check: quotes=%s/%s rate=%s missing_sections=%s issues=%d" % (
        report["quote_hits"], report["quote_total"],
        ("%.2f" % rate) if rate is not None else "n/a",
        ",".join(report["missing_sections"]) or "none", len(report["issues"])))
    for i in report["issues"]:
        print("  - " + i)


def do_build(input_dir, work_dir, output_dir, errors, degradations):
    case, task_md, materials, errs, case_error = writer.discover_input(input_dir)
    errors.extend(errs)
    draft_path = work_dir / "draft.json"
    draft = _load_draft(work_dir, None)
    if draft is None:
        if draft_path.exists():
            errors.append("draft.json invalid JSON; deriving from /input")
        else:
            degradations.append("no work draft; derived from /input")
        draft = writer.derive_draft(case, task_md, materials, errors)
        work_dir.mkdir(parents=True, exist_ok=True)
        draft_path.write_text(json.dumps(draft, ensure_ascii=False, indent=2), encoding="utf-8")
    elif not writer.draft_has_content(draft):
        degradations.append("work draft has no content; re-derived from /input")
        draft = writer.derive_draft(case, task_md, materials, errors)
        work_dir.mkdir(parents=True, exist_ok=True)
        draft_path.write_text(json.dumps(draft, ensure_ascii=False, indent=2), encoding="utf-8")
    if case_error:
        draft["overall_status"] = "input_error"
    elif not materials:
        draft["overall_status"] = "insufficient_evidence"
    if not draft.get("contract"):
        draft["contract"] = writer.get_contract(case)
    if not draft.get("case_id"):
        draft["case_id"] = (case or {}).get("case_id", "")
    if not draft.get("format"):
        draft["format"] = writer.detect_format((case or {}).get("task_instruction", "") or task_md)
    report = writer.validate_draft(draft, materials)
    if report["quote_total"] and report["quote_rate"] is not None and report["quote_rate"] < 0.95:
        degradations.append("quote hit rate %.2f < 0.95" % report["quote_rate"])
    if report["missing_sections"]:
        degradations.append("missing sections: " + ",".join(report["missing_sections"]))
    if draft.get("overall_status") not in ("complete", "partial", "insufficient_evidence", "input_error"):
        draft["overall_status"] = "partial"
    errors[:] = list(dict.fromkeys(errors))
    degradations[:] = list(dict.fromkeys(degradations))
    artifacts = writer.assemble_outputs(draft, output_dir, degradations)
    result = writer.build_result(draft, report, errors, degradations)
    result["artifacts"] = artifacts
    result["quote_hits"] = report["quote_hits"]
    result["quote_total"] = report["quote_total"]
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    work_dir.mkdir(parents=True, exist_ok=True)
    (work_dir / "check_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print("build: status=%s quotes=%s/%s artifacts=%d contract_keys=%d" % (
        result["status"], report["quote_hits"], report["quote_total"],
        len(artifacts), len(draft.get("contract", {}))))


def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="main.py", description="Methods & Experiments chapter writer (stdlib only, no network).")
    ap.add_argument("cmd", nargs="?", default="run", choices=["run", "init", "show", "check", "build"])
    ap.add_argument("--input", default=None, help="input dir (default /input or $INPUT_DIR)")
    ap.add_argument("--work", default=None, help="work dir (default /app/work or $WORK_DIR)")
    ap.add_argument("--output", default=None, help="output dir (default /app/output or $OUTPUT_DIR)")
    args = ap.parse_args(argv)
    input_dir = Path(args.input or os.environ.get("INPUT_DIR", "/input"))
    work_dir = Path(args.work or os.environ.get("WORK_DIR", "/app/work"))
    output_dir = Path(args.output or os.environ.get("OUTPUT_DIR", "/app/output"))
    errors, degradations = [], []
    try:
        if args.cmd == "init":
            do_init(input_dir, work_dir, output_dir, errors, degradations)
        elif args.cmd == "show":
            do_show(input_dir, work_dir, errors)
        elif args.cmd == "check":
            do_check(input_dir, work_dir, errors)
        elif args.cmd == "build":
            do_build(input_dir, work_dir, output_dir, errors, degradations)
        else:
            do_init(input_dir, work_dir, output_dir, errors, degradations)
            do_build(input_dir, work_dir, output_dir, errors, degradations)
    except Exception as e:
        errors.append("unhandled: %s: %s" % (type(e).__name__, e))
        _write_emergency(output_dir, work_dir, errors, degradations)
    print("done: errors=%d degradations=%d" % (len(errors), len(degradations)))
    return 0


if __name__ == "__main__":
    sys.exit(main())

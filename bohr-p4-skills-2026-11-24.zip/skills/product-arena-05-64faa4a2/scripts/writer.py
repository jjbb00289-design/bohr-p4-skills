#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Methods & Experiments chapter writer engine (stdlib only, no network)."""
import json
import re
import shutil
import sqlite3
import subprocess
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

SCHEMA = "1.0"
W_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
S_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"

SIX = [
    ("steps", "方法与步骤"),
    ("setup", "实验设置"),
    ("params", "参数与来源"),
    ("dataset", "数据集与划分"),
    ("baseline", "对照实验"),
    ("repro_limitation", "复现与限制"),
]

PARAM_COLS = ["name", "value", "unit", "scope", "source_file", "source_locator", "status"]
DS_COLS = ["name", "version", "size", "split", "usage", "preprocess", "source_file", "status"]
BASE_COLS = ["name", "version", "budget", "metric", "stat", "source_file", "status"]

RESERVED = {
    "schema_version", "case_id", "task_instruction", "audience", "style", "format",
    "language", "contract", "materials", "sections", "parameter_table", "dataset_table",
    "baselines", "reproducibility", "gaps", "conflicts", "confirmations",
    "change_records", "overall_status",
}


def norm_ws(s):
    return re.sub(r"\s+", " ", (s or "")).strip()


def norm_all(s):
    return re.sub(r"\s+", "", (s or ""))


def read_text(path):
    for enc in ("utf-8-sig", "utf-8", "gb18030", "latin-1"):
        try:
            return Path(path).read_text(encoding=enc)
        except (UnicodeDecodeError, UnicodeError):
            continue
    return Path(path).read_text(encoding="utf-8", errors="replace")


def load_json(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig", errors="replace"))
    except Exception:
        return None


def kind_of(ext):
    if ext == ".pdf":
        return "pdf"
    if ext == ".docx":
        return "docx"
    if ext in (".xlsx", ".xls", ".csv", ".tsv"):
        return "table"
    if ext in (".sqlite", ".db", ".sqlite3"):
        return "sqlite"
    if ext == ".pptx":
        return "slide"
    if ext in (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp", ".svg"):
        return "image"
    if ext in (".json", ".yaml", ".yml", ".ini", ".conf", ".cfg", ".toml"):
        return "config"
    if ext in (".log", ".out", ".err"):
        return "log"
    if ext in (".py", ".sh", ".R", ".ipynb", ".m", ".c", ".cpp", ".java", ".go", ".rs"):
        return "code"
    return "text"


def extract_pdf(path):
    exe = shutil.which("pdftotext")
    if not exe:
        return None, "no_pdftotext"
    tmp = path.with_suffix(path.suffix + ".txt")
    try:
        r = subprocess.run([exe, "-layout", str(path), str(tmp)], capture_output=True, timeout=180)
        if r.returncode == 0 and tmp.exists():
            txt = tmp.read_text(encoding="utf-8", errors="replace")
            Path(tmp).unlink(missing_ok=True)
            return txt, ""
        return None, "pdf_no_text_layer"
    except Exception:
        return None, "pdf_no_text_layer"


def extract_docx(path):
    try:
        with zipfile.ZipFile(path) as z:
            xml = z.read("word/document.xml")
        root = ET.fromstring(xml)
        return "\n".join(
            "".join(t.text or "" for t in p.iter(W_NS + "t"))
            for p in root.iter(W_NS + "p")), ""
    except Exception:
        return None, "docx_unreadable"


def extract_xlsx(path):
    try:
        with zipfile.ZipFile(path) as z:
            shared = []
            if "xl/sharedStrings.xml" in z.namelist():
                sr = ET.fromstring(z.read("xl/sharedStrings.xml"))
                shared = ["".join(t.text or "" for t in si.iter(S_NS + "t"))
                          for si in sr.findall(S_NS + "si")]
            out = []
            for s in sorted(n for n in z.namelist()
                            if re.match(r"xl/worksheets/sheet\d+\.xml$", n)):
                root = ET.fromstring(z.read(s))
                out.append("## sheet: " + s)
                for row in root.iter(S_NS + "row"):
                    cells = []
                    for c in row.iter(S_NS + "c"):
                        v = c.find(S_NS + "v")
                        if v is None or v.text is None:
                            cells.append("")
                        elif c.get("t", "n") == "s":
                            cells.append(shared[int(v.text)] if int(v.text) < len(shared) else "")
                        else:
                            cells.append(v.text)
                    if any(cells):
                        out.append("\t".join(cells))
            return "\n".join(out), ""
    except Exception:
        return None, "xlsx_unreadable"


def extract_sqlite(path):
    try:
        con = sqlite3.connect(str(path))
        cur = con.cursor()
        tables = [r[0] for r in cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        out = []
        for t in tables:
            out.append("## table: " + t)
            try:
                cols = [c[1] for c in cur.execute("PRAGMA table_info(%s)" % t)]
                out.append("\t".join(cols))
                for row in cur.execute("SELECT * FROM %s LIMIT 500" % t):
                    out.append("\t".join("" if v is None else str(v) for v in row))
            except Exception as e:
                out.append("(error reading table: %s)" % e)
        con.close()
        return "\n".join(out), ""
    except Exception:
        return None, "sqlite_unreadable"


def extract_material(path, input_dir):
    rel = path.relative_to(input_dir).as_posix()
    ext = path.suffix.lower()
    kind = kind_of(ext)
    text, note = "", ""
    if kind == "pdf":
        text, note = extract_pdf(path)
    elif kind == "docx":
        text, note = extract_docx(path)
    elif kind == "sqlite":
        text, note = extract_sqlite(path)
    elif kind == "table" and ext in (".xlsx", ".xls"):
        text, note = extract_xlsx(path)
    elif kind == "image":
        note = "needs_ocr"
    elif kind == "slide":
        note = "needs_render"
    else:
        try:
            text = read_text(path)
        except Exception:
            text, note = "", "unreadable"
    if text is None:
        text, note = "", (note or "unreadable")
    if text:
        text = text[:200000]
    return {"name": rel, "path": rel, "kind": kind, "text": text, "note": note}


def discover_input(input_dir):
    errors, case, case_error = [], None, False
    cp = input_dir / "case.json"
    if cp.exists():
        case = load_json(cp)
        if case is None:
            case, case_error = {}, True
            errors.append("case.json invalid JSON")
    else:
        case, case_error = {}, True
        errors.append("case.json missing")
    task_md = ""
    tp = input_dir / "task.md"
    if tp.exists():
        try:
            task_md = read_text(tp)
        except Exception:
            errors.append("task.md unreadable")
    else:
        errors.append("task.md missing")
    materials = []
    if input_dir.exists():
        for p in sorted(input_dir.rglob("*")):
            if not p.is_file():
                continue
            rel = p.relative_to(input_dir).as_posix()
            if rel in ("case.json", "task.md"):
                continue
            materials.append(extract_material(p, input_dir))
    return case, task_md, materials, errors, case_error


def get_contract(case):
    oc = (case or {}).get("output_contract")
    if oc is None:
        return {}
    if isinstance(oc, dict):
        return oc
    if isinstance(oc, list):
        d = {}
        for item in oc:
            if isinstance(item, str):
                d[item] = None
            elif isinstance(item, dict):
                k = item.get("name") or item.get("field") or item.get("key")
                if k:
                    d[k] = item
        return d
    return {}


def default_for_contract(entry):
    if isinstance(entry, dict):
        t = str(entry.get("type", "")).lower()
        if "array" in t or "list" in t:
            return []
    return None


def detect_format(text):
    t = (text or "").lower()
    if "latex" in t or ".tex" in t or "\\section" in t or "\\documentclass" in t:
        return "latex"
    if "docx" in t or "word" in t:
        return "docx"
    return "markdown"


def build_scaffold(case, task_md, materials, errors):
    contract = get_contract(case)
    case_id = (case or {}).get("case_id", "")
    ti = (case or {}).get("task_instruction", "") or task_md
    lang = "zh" if re.search(r"[\u4e00-\u9fff]", (ti or "") or (task_md or "")) else "en"
    sections = [{"section_id": sid, "title": title, "body_md": "", "sentences": []}
                for sid, title in SIX]
    mats = [{"name": m["name"], "path": m["path"], "kind": m["kind"], "note": m["note"],
             "text_preview": (m.get("text") or "")[:500]} for m in materials]
    draft = {
        "schema_version": SCHEMA, "case_id": case_id,
        "task_instruction": (ti or "")[:4000], "audience": "", "style": "",
        "format": detect_format(ti), "language": lang, "contract": contract,
        "materials": mats, "sections": sections,
        "parameter_table": [], "dataset_table": [], "baselines": [],
        "reproducibility": {"code_version": "", "env": "", "commands": "",
                            "data_access": "", "seed": "", "repeats": "", "hardware": ""},
        "gaps": [], "conflicts": [], "confirmations": [], "change_records": [],
        "overall_status": "insufficient_evidence",
    }
    if not materials:
        draft["gaps"].append({"item": "materials", "reason": "输入目录下未发现任何材料文件", "evidence": ""})
    return draft


# ---------------------------------------------------------------------------
# Auto-derivation: turn /input materials into a full draft without draft.json.
# Every fact carries a verbatim `quote` (a substring of the source text), so the
# existing quote validator still applies. Nothing is written that is not present
# in the materials; missing fields go to gaps/confirmations.
# ---------------------------------------------------------------------------

LABELS = {
    "lr": "学习率", "learning_rate": "学习率", "learning-rate": "学习率", "learningrate": "学习率",
    "weight_decay": "权重衰减", "weight-decay": "权重衰减", "l2": "权重衰减",
    "batch_size": "批大小", "batch-size": "批大小", "batch": "批大小",
    "epochs": "训练轮数", "epoch": "训练轮数", "n_epochs": "训练轮数", "num_epochs": "训练轮数",
    "max_epochs": "最大训练轮数", "steps": "训练步数", "max_steps": "最大步数", "iterations": "迭代次数",
    "seed": "随机种子", "random_seed": "随机种子", "random_state": "随机种子",
    "gpu": "GPU", "device": "设备", "hardware": "硬件", "accelerator": "加速器", "cuda": "CUDA",
    "dataset": "数据集", "dataset_name": "数据集", "data_name": "数据集", "benchmark": "基准数据集", "corpus": "语料",
    "split": "划分比例", "train_ratio": "训练比例", "val_ratio": "验证比例", "test_ratio": "测试比例",
    "train_size": "训练集规模", "val_size": "验证集规模", "test_size": "测试集规模",
    "optimizer": "优化器", "optim": "优化器", "scheduler": "学习率调度", "loss": "损失",
    "baseline": "基线", "basename": "基线", "base_model": "基线模型",
    "budget": "训练预算", "dropout": "Dropout", "momentum": "动量",
    "hidden_size": "隐藏层维度", "dim": "维度", "n_layers": "层数", "num_layers": "层数", "heads": "注意力头数",
    "version": "版本", "pretrained": "预训练权重", "checkpoint": "检查点",
    "code_version": "代码版本", "commit": "提交哈希", "env": "运行环境", "requirements": "依赖",
    "data_access": "数据获取", "commands": "命令", "command": "命令", "repeats": "重复次数",
    "accuracy": "准确率", "acc": "准确率", "precision": "精确率", "recall": "召回率",
    "f1": "F1", "auc": "AUC", "perplexity": "困惑度", "bleu": "BLEU", "rouge": "ROUGE",
    "mean_std": "均值±标准差", "improvement": "提升幅度",
}

PATH_LABELS = {
    "baseline.name": "基线", "baseline.budget": "训练预算", "baseline.version": "基线版本",
    "baseline.basename": "基线", "baseline.base_model": "基线模型",
    "data.dataset": "数据集", "data.name": "数据集", "dataset.name": "数据集",
    "data.split": "划分比例", "train.epochs": "训练轮数", "train.epoch": "训练轮数",
    "train.gpu": "GPU", "train.device": "设备", "optim.lr": "学习率",
    "optim.weight_decay": "权重衰减", "optimizer.lr": "学习率",
    "data.batch_size": "批大小", "data.seed": "随机种子", "train.seed": "随机种子",
    "model.name": "模型", "model.version": "模型版本", "model.optimizer": "优化器",
}


def _strip_comment(s):
    in_s = False
    in_d = False
    for i, ch in enumerate(s):
        if ch == "'" and not in_d:
            in_s = not in_s
        elif ch == '"' and not in_s:
            in_d = not in_d
        elif ch == "#" and not in_s and not in_d:
            return s[:i]
    return s


def _unquote(v):
    v = (v or "").strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in ('"', "'"):
        return v[1:-1]
    return v


def _leaf(name):
    return (name or "").rsplit(".", 1)[-1].strip()


def _classify_section(name):
    n = (name or "").lower()
    if any(k in n for k in ("baseline", "base_model", "budget", "basename", "competitor",
                            "sota", "improve", "提升", "比较", "对比")):
        return "baseline"
    if any(k in n for k in ("dataset", "data_name", "dataset_name", "corpus", "benchmark", "split",
                            "ratio", "fold", "kfold", "preprocess", "augment", "image_size",
                            "resolution", "sequence_length", "vocab", "pretrain", "checkpoint",
                            "data_version")):
        return "dataset"
    if n == "version" or n.endswith(".version"):
        return "dataset"
    if any(k in n for k in ("accuracy", "acc", "precision", "recall", "f1", "auc", "mse", "mae",
                            "rmse", "perplexity", "bleu", "rouge", "score", "mean_std", "±",
                            "准确率", "精度", "精确率", "召回率", "正确率", "错误率")):
        return "repro_limitation"
    if any(k in n for k in ("seed", "random", "gpu", "device", "cuda", "cpu", "hardware",
                            "accelerator", "env", "environment", "framework", "python", "torch",
                            "tensorflow", "repeat", "code_version", "commit", "requirements",
                            "data_access", "command")):
        return "setup"
    if any(k in n for k in ("lr", "learning_rate", "weight_decay", "dropout", "momentum",
                            "optimizer", "optim", "scheduler", "loss", "hidden", "dim", "layers",
                            "heads", "beta", "eps", "warmup", "gamma", "temperature", "top_k",
                            "top_p", "beam", "penalty", "batch")):
        return "params"
    if any(k in n for k in ("epoch", "step", "iteration", "iter", "patience", "early_stop")):
        return "steps"
    return "steps"


def _guess_unit(name, value):
    v = str(value or "")
    if "%" in v:
        return "%"
    if "pp" in v or "百分点" in v:
        return "pp"
    return "-"


def _guess_scope(name):
    n = (name or "").lower()
    if any(k in n for k in ("lr", "optim", "weight_decay", "momentum", "scheduler", "loss", "dropout")):
        return "优化器"
    if any(k in n for k in ("dataset", "split", "corpus", "augment", "batch", "data", "vocab", "preprocess")):
        return "数据"
    if any(k in n for k in ("epoch", "step", "iter", "gpu", "device", "hardware", "seed", "repeat")):
        return "训练"
    if any(k in n for k in ("baseline", "budget", "base_model")):
        return "对照"
    if any(k in n for k in ("accuracy", "acc", "precision", "recall", "f1", "auc", "mean", "improve",
                            "准确率", "精度", "召回率", "提升")):
        return "评测"
    return "实验"


def _make_fact(name, value, fname, loc, quote, kind, label=None, unit=None, scope=None, section=None):
    leaf = _leaf(name)
    label = label or PATH_LABELS.get(name) or LABELS.get(leaf) or LABELS.get(name.lower()) or leaf
    unit = unit if unit is not None else _guess_unit(name, value)
    scope = scope if scope is not None else _guess_scope(name)
    section = section or _classify_section(name)
    return {
        "name": name, "label": label, "value": str(value), "unit": unit,
        "scope": scope, "file": fname, "locator": loc, "quote": quote,
        "kind": kind, "section": section, "status": "verified",
    }


def _flatten_json_obj(obj, prefix, out):
    if isinstance(obj, dict):
        for k, v in obj.items():
            _flatten_json_obj(v, (prefix + "." + k) if prefix else str(k), out)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            _flatten_json_obj(v, "%s[%d]" % (prefix, i), out)
    else:
        out.append((prefix, "" if obj is None else obj))
    return out


def _find_json_quote(raw, leaf_key):
    m = re.search(r'("' + re.escape(leaf_key) + r'")\s*:\s*(.+?)(,|\}|$)', raw, re.S)
    if m:
        return (m.group(1) + ": " + m.group(2)).strip().rstrip(",")
    m = re.search(r'("' + re.escape(leaf_key) + r'")', raw)
    return m.group(1) if m else '"%s"' % leaf_key


def _facts_from_json(text, fname):
    try:
        obj = json.loads(text)
    except Exception:
        return []
    flat = _flatten_json_obj(obj, "", [])
    facts = []
    for path, value in flat:
        if isinstance(value, (dict, list)):
            continue
        leaf = _leaf(path)
        facts.append(_make_fact(path, value, fname, "key: %s" % path,
                                _find_json_quote(text, leaf), "kv"))
    return facts


def _facts_from_yaml(text, fname):
    facts = []
    stack = []
    for i, raw in enumerate(text.splitlines()):
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip())
        s = raw.strip()
        if s.startswith("- "):
            continue
        m = re.match(r'^([^\s:#=]+)\s*:\s*(.*)$', s)
        if not m:
            continue
        key = m.group(1)
        val = m.group(2)
        while stack and indent <= stack[-1][0]:
            stack.pop()
        path = ".".join([k for _, k in stack] + [key])
        quote = _strip_comment(s).rstrip()
        if val.strip() == "":
            stack.append((indent, key))
            continue
        facts.append(_make_fact(path, _unquote(_strip_comment(val).strip()), fname,
                                "key: %s" % path, quote, "kv"))
    return facts


def _facts_from_ini(text, fname):
    facts = []
    section = ""
    for i, raw in enumerate(text.splitlines()):
        s = raw.strip()
        if not s or s.startswith(("#", ";", "//")):
            continue
        if s.startswith("[") and s.endswith("]"):
            section = s[1:-1].strip()
            continue
        m = re.match(r'^([^\s=:#]+)\s*[=:]\s*(.*)$', s)
        if not m:
            continue
        key = m.group(1)
        val = _strip_comment(m.group(2)).strip()
        if val == "":
            continue
        path = (section + "." + key) if section else key
        facts.append(_make_fact(path, _unquote(val), fname, "key: %s" % path,
                                _strip_comment(s).rstrip(), "kv"))
    return facts


def _facts_from_table(text, fname):
    raw_lines = [ln.rstrip("\r\n").strip() for ln in text.splitlines()
                 if ln.strip() and not ln.strip().startswith("## ")]
    if not raw_lines:
        return []
    delim = "\t" if "\t" in raw_lines[0] else ","
    facts = []
    for raw in raw_lines[1:]:
        cells = [c.strip() for c in raw.split(delim)]
        if not cells or all(c == "" for c in cells):
            continue
        if len(cells) >= 2:
            facts.append(_make_fact(cells[0] or "col0", cells[1], fname, "table row", raw, "kv"))
        else:
            facts.append(_make_fact("value", cells[0], fname, "table row", raw, "kv"))
    return facts


def _metric_facts_from_line(s, fname, loc):
    facts = []
    m = re.search(r'([0-9]+(?:\.[0-9]+)?)\s*%\s*±\s*([0-9]+(?:\.[0-9]+)?)\s*%', s)
    if m:
        facts.append(_make_fact("mean_std", m.group(0), fname, loc, m.group(0),
                                "metric", label="均值±标准差", unit="%", section="repro_limitation"))
    m = re.search(r'(accuracy|acc|precision|recall|f1|auc|iou|map|mse|mae|rmse|perplexity|bleu|rouge'
                  r'|准确率|精度|精确率|召回率|正确率|错误率)\s*(?:为|是|:|：|=)?\s*'
                  r'([0-9]+(?:\.[0-9]+)?)\s*%', s, re.I)
    if m:
        facts.append(_make_fact(m.group(1), m.group(2) + "%", fname, loc, m.group(0),
                                "metric", section="repro_limitation"))
    m = re.search(r'(提升|提高|改进|优于|超过|领先|improvement|improve|gain|boost)\s*'
                  r'([0-9]+(?:\.[0-9]+)?)\s*(个百分点|pp|%|百分点)', s, re.I)
    if m:
        unit = "pp" if "pp" in m.group(3).lower() or "百分点" in m.group(3) else "%"
        facts.append(_make_fact("improvement", m.group(2) + " " + m.group(3), fname, loc, m.group(0),
                                "metric", label="提升幅度", unit=unit, section="baseline"))
    m = re.search(r'([0-9一二三四五六七八九十]+)\s*(次|折|fold|runs?|repeats?|重复)', s, re.I)
    if m:
        facts.append(_make_fact("repeats", m.group(0), fname, loc, m.group(0),
                                "setup", label="重复次数", section="setup"))
    # free-text parameter statements: 学习率 1e-3 / lr=1e-3 / batch_size 32
    m = re.search(r'(学习率|lr|learning_rate|batch_size|批大小|epoch|轮数|seed|随机种子)\s*'
                  r'(?:为|是|[:=])?\s*([0-9]+(?:\.[0-9]+)?(?:e[-+]?[0-9]+)?)', s, re.I)
    if m:
        key = {"学习率": "lr", "lr": "lr", "learning_rate": "lr", "batch_size": "batch_size",
               "批大小": "batch_size", "epoch": "epochs", "轮数": "epochs",
               "seed": "seed", "随机种子": "seed"}.get(m.group(1).lower(), m.group(1))
        facts.append(_make_fact(key, m.group(2), fname, loc, m.group(0), "kv"))
    m = re.search(r'(数据集|dataset|data)\s*(?:为|是|[:=])?\s*([A-Za-z0-9][A-Za-z0-9._-]*)', s, re.I)
    if m:
        facts.append(_make_fact("dataset", m.group(2), fname, loc, m.group(0), "dataset"))
    return facts


def _facts_from_lines(text, fname):
    facts = []
    section = ""
    for i, raw in enumerate(text.splitlines()):
        s = raw.strip()
        if not s:
            continue
        loc = "line %d" % (i + 1)
        if s.startswith(("#", "//", "/*", "* ")):
            continue
        if s.startswith("[") and s.endswith("]"):
            section = s[1:-1].strip()
            continue
        m = re.match(r'^([^\s=:#]+)\s*[=:]\s*(.*)$', s)
        if m:
            key = m.group(1)
            val = _unquote(_strip_comment(m.group(2)).strip())
            if val == "":
                continue
            path = (section + "." + key) if section else key
            facts.append(_make_fact(path, val, fname, loc, _strip_comment(s).rstrip(), "kv"))
            continue
        facts.extend(_metric_facts_from_line(s, fname, loc))
    return facts


def _extract_material_facts(m):
    text = m.get("text") or ""
    if not text.strip():
        return []
    fname = m.get("name", "")
    kind = m.get("kind", "text")
    t = text.strip()
    if t[:1] in ("{", "["):
        return _facts_from_json(text, fname)
    if kind == "config":
        if re.search(r"(?m)^\s*[\w.\/-]+\s*:\s*\S", text):
            return _facts_from_yaml(text, fname)
        return _facts_from_ini(text, fname)
    if kind == "table":
        return _facts_from_table(text, fname)
    return _facts_from_lines(text, fname)


def _dedup_facts(facts):
    seen = set()
    out = []
    for f in facts:
        key = (f["file"], f["name"], f["value"], f["quote"])
        if key in seen:
            continue
        seen.add(key)
        out.append(f)
    return out


def _sentence_for_fact(f, lang):
    n = (f["name"] or "").lower()
    label = f["label"]
    value = f["value"]
    if lang != "zh":
        if f["section"] == "steps":
            if "epoch" in n:
                return "Trained for %s epochs." % value, "step"
            return "%s: %s." % (label, value), "step"
        if f["section"] == "setup":
            if any(k in n for k in ("gpu", "device", "hardware", "accelerator")):
                return "Used %s as %s." % (value, label), "setup"
            if any(k in n for k in ("seed", "random")):
                return "Random seed: %s." % value, "setup"
            if "repeat" in n or "次" in n:
                return "Repeated %s runs." % value, "setup"
            return "%s: %s." % (label, value), "setup"
        if f["section"] == "params":
            return "%s set to %s." % (label, value), "param"
        if f["section"] == "dataset":
            if any(k in n for k in ("split", "ratio", "fold", "size")):
                return "Split: %s." % value, "dataset"
            return "Dataset: %s." % value, "dataset"
        if f["section"] == "baseline":
            if "budget" in n:
                return "Training budget: %s." % value, "baseline"
            if "improve" in n:
                return "Improved by %s over the baseline." % value, "metric"
            return "Baseline: %s." % value, "baseline"
        if f["section"] == "repro_limitation":
            if "mean" in n or "±" in n:
                return "Mean over runs: %s." % value, "metric"
            return "%s: %s." % (label, value), "metric"
        return "%s: %s." % (label, value), "number"

    if f["section"] == "steps":
        if "epoch" in n:
            return "训练共 %s 个 epoch。" % value, "step"
        return "%s为 %s。" % (label, value), "step"
    if f["section"] == "setup":
        if any(k in n for k in ("gpu", "device", "hardware", "accelerator")):
            return "使用 %s %s。" % (value, label), "setup"
        if any(k in n for k in ("seed", "random")):
            return "随机种子为 %s。" % value, "setup"
        if "repeat" in n or "次" in n:
            return "重复运行 %s。" % value, "setup"
        return "%s为 %s。" % (label, value), "setup"
    if f["section"] == "params":
        return "%s为 %s。" % (label, value), "param"
    if f["section"] == "dataset":
        if any(k in n for k in ("split", "ratio", "fold", "size")):
            return "划分比例为 %s。" % value, "dataset"
        return "使用 %s 数据集。" % value, "dataset"
    if f["section"] == "baseline":
        if "budget" in n:
            return "训练预算为 %s。" % value, "baseline"
        if "improve" in n or "提升" in n:
            return "相比基线提升 %s。" % value, "metric"
        return "基线为 %s。" % value, "baseline"
    if f["section"] == "repro_limitation":
        if "mean" in n or "±" in n:
            return "重复运行均值为 %s。" % value, "metric"
        if any(k in n for k in ("accuracy", "acc", "准确率")):
            return "准确率为 %s。" % value, "metric"
        if "precision" in n or "精确" in n:
            return "精确率为 %s。" % value, "metric"
        if "recall" in n or "召回" in n:
            return "召回率为 %s。" % value, "metric"
        if "f1" in n:
            return "F1 为 %s。" % value, "metric"
        return "%s为 %s。" % (label, value), "metric"
    return "%s为 %s。" % (label, value), "number"


def _build_param_table(facts):
    rows = []
    for f in facts:
        if f["section"] in ("params", "steps"):
            rows.append({
                "name": f["name"], "value": f["value"], "unit": f["unit"], "scope": f["scope"],
                "source_file": f["file"], "source_locator": f["locator"],
                "source_quote": f["quote"], "status": "verified",
            })
    return rows


def _build_dataset_table(facts):
    dsf = [f for f in facts if f["section"] == "dataset"]
    if not dsf:
        return []
    name = ""
    version = ""
    split = ""
    for f in dsf:
        n = f["name"].lower()
        if any(k in n for k in ("split", "ratio", "fold")):
            split = f["value"]
        elif "version" in n:
            version = f["value"]
        elif not name:
            name = f["value"]
    if not name:
        name = dsf[0]["value"]
    src = dsf[0]
    return [{
        "name": name, "version": version, "size": "", "split": split,
        "usage": "训练/验证/测试" if split else "", "preprocess": "",
        "source_file": src["file"], "source_locator": src["locator"],
        "source_quote": src["quote"], "status": "verified",
    }]


def _build_baseline_table(facts):
    bf = [f for f in facts if f["section"] == "baseline"]
    if not bf:
        return []
    name = ""
    version = ""
    budget = ""
    metric = ""
    stat = ""
    src = bf[0]
    for f in bf:
        n = f["name"].lower()
        if "budget" in n:
            budget = f["value"]
        elif "version" in n:
            version = f["value"]
        elif "improve" in n or "提升" in n:
            metric = "accuracy"
            stat = "提升 " + f["value"]
        elif not name:
            name = f["value"]
    if not stat:
        for f in facts:
            if f["name"] == "repeats":
                stat = "重复运行 " + f["value"]
                break
    return [{
        "name": name, "version": version, "budget": budget, "metric": metric, "stat": stat,
        "source_file": src["file"], "source_locator": src["locator"],
        "source_quote": src["quote"], "status": "verified",
    }]


def _build_reproducibility(facts):
    r = {"code_version": "", "env": "", "commands": "", "data_access": "",
         "seed": "", "repeats": "", "hardware": ""}
    for f in facts:
        n = f["name"].lower()
        if "seed" in n or "random" in n:
            r["seed"] = f["value"]
        elif any(k in n for k in ("gpu", "device", "hardware", "accelerator")):
            r["hardware"] = f["value"]
        elif f["name"] == "repeats":
            r["repeats"] = f["value"]
        elif "command" in n:
            r["commands"] = f["value"]
        elif "code_version" in n or "commit" in n:
            r["code_version"] = f["value"]
        elif "env" in n or "requirements" in n:
            r["env"] = f["value"]
        elif "data_access" in n:
            r["data_access"] = f["value"]
    return r


def _build_gaps(facts, materials):
    gaps = []
    confirmations = []
    repro = _build_reproducibility(facts)
    labels = {"code_version": "代码版本", "env": "运行环境", "commands": "运行命令",
              "data_access": "数据获取方式", "seed": "随机种子", "repeats": "重复次数", "hardware": "硬件"}
    missing = [k for k, v in repro.items() if not v]
    if missing:
        gaps.append({"item": "复现清单不完整",
                     "reason": "材料未提供：%s" % "、".join(labels.get(k, k) for k in missing),
                     "evidence": "、".join(m.get("name", "") for m in materials) + " 中无对应信息"})
    if any(f["section"] == "dataset" for f in facts):
        has_version = any("version" in f["name"].lower() for f in facts if f["section"] == "dataset")
        if not has_version:
            confirmations.append({"item": "数据集版本",
                                  "question": "数据集的具体版本（下载/预处理版本）是什么？",
                                  "why": "材料仅给出数据集名称，未注明版本，影响复现"})
    return gaps, confirmations


def derive_draft(case, task_md, materials, errors):
    draft = build_scaffold(case, task_md, materials, errors)
    if not materials:
        draft["overall_status"] = "insufficient_evidence"
        return draft
    facts = []
    for m in materials:
        facts.extend(_extract_material_facts(m))
    facts = _dedup_facts(facts)
    lang = draft.get("language") or "zh"
    by_section = {}
    for f in facts:
        by_section.setdefault(f["section"], []).append(f)
    sections = []
    for sid, title in SIX:
        fs = by_section.get(sid, [])
        parts = []
        sentences = []
        for f in fs:
            text, skind = _sentence_for_fact(f, lang)
            parts.append(text)
            sentences.append({
                "claim_id": "%s-%d" % (sid, len(sentences) + 1),
                "text": text, "kind": skind,
                "facts": [{"name": f["name"], "value": f["value"], "unit": f["unit"], "scope": f["scope"]}],
                "source": {"file": f["file"], "locator": f["locator"], "quote": f["quote"]},
                "status": "verified", "note": "",
            })
        sections.append({"section_id": sid, "title": title,
                         "body_md": "".join(parts), "sentences": sentences})
    draft["sections"] = sections
    draft["parameter_table"] = _build_param_table(facts)
    draft["dataset_table"] = _build_dataset_table(facts)
    draft["baselines"] = _build_baseline_table(facts)
    draft["reproducibility"] = _build_reproducibility(facts)
    draft["gaps"], draft["confirmations"] = _build_gaps(facts, materials)
    draft["change_records"] = [{
        "target": "methods_chapter",
        "action": "空工作目录下无 draft.json，由 /input 材料自动派生六节正文、来源映射与参数/数据集/基线表",
        "reason": "仅使用材料中实际出现的键值、指标与语句组织成稿，未补造数值",
    }]
    filled = sum(1 for s in draft["sections"] if (s.get("body_md") or "").strip())
    n_quotes = sum(1 for s in draft["sections"] for _ in s.get("sentences", []))
    if filled == len(SIX) and n_quotes >= 1:
        draft["overall_status"] = "complete"
    elif filled >= 1 or n_quotes >= 1:
        draft["overall_status"] = "partial"
    else:
        draft["overall_status"] = "insufficient_evidence"
    return draft


def draft_has_content(draft):
    if not isinstance(draft, dict):
        return False
    for sec in draft.get("sections", []):
        if (sec.get("body_md") or "").strip() or sec.get("sentences"):
            return True
    for key in ("parameter_table", "dataset_table", "baselines"):
        if draft.get(key):
            return True
    return False


def quote_hits(q, corpus):
    if not q or not corpus:
        return False
    qn, cn = norm_ws(q), norm_ws(corpus)
    if qn and qn in cn:
        return True
    qa, ca = norm_all(q), norm_all(corpus)
    return bool(qa) and qa in ca


def _textmap(materials):
    return {m["name"]: m.get("text") or "" for m in materials}


def _find_corpus(textmap, materials, fname):
    if not fname:
        return ""
    if fname in textmap:
        return textmap[fname]
    for m in materials:
        if m["name"].endswith(fname) or Path(m["name"]).name == fname:
            return m.get("text") or ""
    return ""


def validate_draft(draft, materials):
    issues = []
    textmap = _textmap(materials)
    hits = total = 0
    for sec in draft.get("sections", []):
        for sent in sec.get("sentences", []):
            src = sent.get("source") or {}
            q = (src.get("quote") or "").strip()
            if not q:
                continue
            total += 1
            if quote_hits(q, _find_corpus(textmap, materials, src.get("file", ""))):
                hits += 1
            else:
                issues.append("quote miss: %s file=%s" % (sent.get("claim_id", "?"), src.get("file", "")))
    kinds = {s.get("section_id") for s in draft.get("sections", [])}
    missing = [k for k, _ in SIX if k not in kinds]
    for k in missing:
        issues.append("missing section: " + k)
    return {"quote_hits": hits, "quote_total": total,
            "quote_rate": (hits / total) if total else None,
            "missing_sections": missing, "issues": issues}


def render_chapter(draft):
    lines = []
    for sec in draft.get("sections", []):
        lines.append("## " + (sec.get("title") or sec.get("section_id")))
        body = (sec.get("body_md") or "").strip()
        lines.append(body if body else "_（本节材料缺失，见 gaps.md）_")
        lines.append("")
    return "\n".join(lines).strip() + "\n"


def render_latex(draft):
    lines = ["\\documentclass{article}", "\\begin{document}",
             "\\title{Methods and Experiments}", "\\maketitle"]
    for sec in draft.get("sections", []):
        title = (sec.get("title") or sec.get("section_id")).replace("&", "\\&").replace("%", "\\%")
        lines.append("\\section{" + title + "}")
        body = (sec.get("body_md") or "").strip()
        lines.append(body if body else "% 本节材料缺失")
    lines.append("\\end{document}")
    return "\n".join(lines) + "\n"


def try_compile_tex(tex_path, out_dir):
    for exe in ("latexmk", "pdflatex", "xelatex", "lualatex"):
        p = shutil.which(exe)
        if not p:
            continue
        try:
            subprocess.run([p, "-interaction=nonstopmode", "-halt-on-error", tex_path.name],
                           cwd=str(out_dir), capture_output=True, timeout=240)
            if (out_dir / (tex_path.stem + ".pdf")).exists():
                return "compiled"
            return "compile_failed"
        except Exception:
            return "compile_failed"
    return "no_latex_compiler"


def render_source_mapping(draft):
    lines = ["# 事实与来源映射", ""]
    for sec in draft.get("sections", []):
        if not sec.get("sentences"):
            continue
        lines.append("## " + (sec.get("title") or sec.get("section_id")))
        for sent in sec["sentences"]:
            s = sent.get("source") or {}
            lines.append("- **%s** %s" % (sent.get("claim_id", ""), sent.get("text", "")))
            lines.append("  - 类型: %s | 状态: %s" % (sent.get("kind", ""), sent.get("status", "")))
            if s.get("file"):
                lines.append("  - 来源: `%s` @ %s" % (s.get("file", ""), s.get("locator", "")))
            if s.get("quote"):
                lines.append("  - 原文: %s" % s["quote"])
            for f in sent.get("facts", []):
                if f.get("name") or f.get("value"):
                    lines.append("  - 事实: %s = %s %s" % (f.get("name", ""), f.get("value", ""), f.get("unit", "")))
            if sent.get("note"):
                lines.append("  - 说明: %s" % sent["note"])
    return "\n".join(lines).strip() + "\n"


def render_table(draft, key, title, cols):
    rows = draft.get(key, [])
    lines = ["# " + title, ""]
    if not rows:
        return "\n".join(lines + ["_（无条目；材料缺失或未填写）_"]).strip() + "\n"
    lines.append("| " + " | ".join(cols) + " |")
    lines.append("|" + "|".join(["---"] * len(cols)) + "|")
    for r in rows:
        cells = [str(r.get(c, "") or "").replace("|", "\\|").replace("\n", " ") for c in cols]
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines).strip() + "\n"


def render_reproducibility(draft):
    r = draft.get("reproducibility", {})
    lines = ["# 复现清单", ""]
    for label, k in [("代码版本", "code_version"), ("运行环境", "env"), ("命令", "commands"),
                     ("数据获取", "data_access"), ("随机种子", "seed"), ("重复次数", "repeats"),
                     ("硬件", "hardware")]:
        v = r.get(k, "")
        lines.append("- **%s**: %s" % (label, v if v else "_（未提供）_"))
    return "\n".join(lines).strip() + "\n"


def render_gaps(draft):
    lines = ["# 缺口、冲突与待确认项", "", "## 材料缺口"]
    for g in draft.get("gaps", []):
        lines.append("- %s — %s" % (g.get("item", ""), g.get("reason", "")))
    if not draft.get("gaps"):
        lines.append("_（无）_")
    lines += ["", "## 材料冲突"]
    for c in draft.get("conflicts", []):
        lines.append("- %s: 「%s」@%s vs 「%s」@%s" % (
            c.get("item", ""), c.get("value_a", ""), c.get("source_a", ""),
            c.get("value_b", ""), c.get("source_b", "")))
    if not draft.get("conflicts"):
        lines.append("_（无）_")
    lines += ["", "## 待作者确认"]
    for c in draft.get("confirmations", []):
        lines.append("- **%s**: %s — %s" % (c.get("item", ""), c.get("question", ""), c.get("why", "")))
    if not draft.get("confirmations"):
        lines.append("_（无）_")
    return "\n".join(lines).strip() + "\n"


def collect_sources(draft):
    srcs, seen = [], set()
    for sec in draft.get("sections", []):
        for sent in sec.get("sentences", []):
            s = sent.get("source") or {}
            key = (sent.get("claim_id"), s.get("file"), s.get("locator"), s.get("quote"))
            if key in seen:
                continue
            seen.add(key)
            srcs.append({"claim_id": sent.get("claim_id", ""), "file": s.get("file", ""),
                         "locator": s.get("locator", ""), "quote": s.get("quote", ""),
                         "status": sent.get("status", "")})
    for tab in ("parameter_table", "dataset_table", "baselines"):
        for row in draft.get(tab, []):
            if row.get("source_quote"):
                srcs.append({"claim_id": row.get("name", ""), "file": row.get("source_file", ""),
                             "locator": row.get("source_locator", ""), "quote": row.get("source_quote", ""),
                             "status": row.get("status", "")})
    return srcs


def build_uncertainty(draft):
    u = []
    for g in draft.get("gaps", []):
        u.append({"item": g.get("item", ""), "reason": g.get("reason", ""), "impact": "material_missing"})
    for c in draft.get("conflicts", []):
        u.append({"item": c.get("item", ""),
                  "reason": "conflict: %s vs %s" % (c.get("value_a", ""), c.get("value_b", "")),
                  "impact": "needs_author_resolution"})
    for c in draft.get("confirmations", []):
        u.append({"item": c.get("item", ""), "reason": c.get("why", ""),
                  "impact": "needs_author_confirmation"})
    return u


def find_contract_value(draft, key):
    kl = key.lower()
    if kl in ("chapter", "methods_chapter", "methods", "manuscript", "text", "content", "body"):
        return render_chapter(draft)
    if kl in ("source_mapping", "sources", "evidence", "fact_source_map", "provenance"):
        return collect_sources(draft)
    if kl in ("parameter_table", "params", "parameters"):
        return draft.get("parameter_table", [])
    if kl in ("dataset_table", "datasets", "dataset"):
        return draft.get("dataset_table", [])
    if kl in ("baselines", "baseline", "comparison"):
        return draft.get("baselines", [])
    if kl in ("reproducibility", "repro"):
        return draft.get("reproducibility", {})
    if kl in ("gaps", "uncertainty", "limitations"):
        return build_uncertainty(draft)
    if kl in ("change_records", "changes"):
        return draft.get("change_records", [])
    if key in draft and key not in RESERVED:
        return draft[key]
    for sec in draft.get("sections", []):
        if sec.get("section_id") == key:
            return {"title": sec.get("title"), "body": sec.get("body_md")}
    return None


def build_result(draft, report, errors, degradations):
    contract = draft.get("contract", {})
    result = {"case_id": draft.get("case_id", ""), "status": draft.get("overall_status", "partial"),
              "schema_version": SCHEMA}
    for k in contract:
        if k in {"case_id", "status", "schema_version"}:
            continue
        v = find_contract_value(draft, k)
        result[k] = v if v is not None else default_for_contract(contract[k])
    result["sources"] = collect_sources(draft)
    result["uncertainty"] = build_uncertainty(draft)
    result["change_records"] = draft.get("change_records", [])
    result["errors"] = errors
    result["degradations"] = degradations
    return result


def assemble_outputs(draft, out_dir, degradations):
    out_dir.mkdir(parents=True, exist_ok=True)
    names = []
    if draft.get("format") == "latex":
        cp = out_dir / "chapter.tex"
        cp.write_text(render_latex(draft), encoding="utf-8")
        names.append("chapter.tex")
        res = try_compile_tex(cp, out_dir)
        if res == "compiled":
            names.append("chapter.pdf")
        else:
            degradations.append("LaTeX compile: " + res)
    else:
        (out_dir / "chapter.md").write_text(render_chapter(draft), encoding="utf-8")
        names.append("chapter.md")

    def w(name, text):
        (out_dir / name).write_text(text, encoding="utf-8")
        names.append(name)

    w("source_mapping.md", render_source_mapping(draft))
    w("parameter_table.md", render_table(draft, "parameter_table", "参数表", PARAM_COLS))
    w("dataset_table.md", render_table(draft, "dataset_table", "数据集与划分", DS_COLS))
    w("baselines.md", render_table(draft, "baselines", "对照实验", BASE_COLS))
    w("reproducibility.md", render_reproducibility(draft))
    w("gaps.md", render_gaps(draft))
    return names

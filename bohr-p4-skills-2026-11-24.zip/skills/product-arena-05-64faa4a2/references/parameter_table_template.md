# 参数表模板

> 用法：正文中出现的每个参数都要在 `draft.json` 的 `parameter_table` 里有一行，并与正文数值对齐。来源列填材料文件名 + locator，`source_quote` 填逐字原文。

| name | value | unit | scope | source_file | source_locator | source_quote | status |
|---|---|---|---|---|---|---|---|
| learning_rate | 3e-4 | - | 优化器 | configs/train.yaml | key: optim.lr | `lr: 3.0e-4` | verified |
| batch_size | 32 | samples | 训练 | configs/train.yaml | key: data.batch_size | `batch_size: 32` | verified |
| epochs | 20 | - | 训练 | logs/train.log | line 12 | `Epoch 20/20` | verified |
| random_seed | 42 | - | 划分 | scripts/split.py | line 8 | `seed = 42` | verified |

> 上表为**示例，非正式案例结果**，仅说明字段含义。实际写作时每格都必须来自真实材料；材料没有的字段留空并把该参数写入 `confirmations`。

## 字段说明
- `name`：参数名（与配置/代码/正文一致）。
- `value`：取值，**不得**为段落顺畅补数值。
- `unit`：单位；无量纲填 `-`。
- `scope`：作用对象（优化器 / 训练 / 数据划分 / 评测…）。
- `source_file` / `source_locator`：材料文件与其位置（页码、行号、键路径、表名）。
- `source_quote`：逐字原文，须能在材料中命中。
- `status`：`verified` / `gap` / `conflicting` / `needs_confirmation`。

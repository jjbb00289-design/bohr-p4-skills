# 复现清单与限制条件模板

> 用途：填 `draft.json` 的 `reproducibility` 对象与 `repro_limitation` 节。读者应能按此复做实验。

## 复现清单（reproducibility）
- `code_version`：代码版本/commit hash/仓库地址（材料有才写）。
- `env`：Python/依赖版本、Docker 镜像或 requirements（材料有才写）。
- `commands`：训练/评测命令，逐字来自材料。
- `data_access`：数据获取方式、下载地址/授权（材料有才写）。
- `seed`：随机种子。
- `repeats`：重复次数与统计方式（多次运行？均值±方差？）。
- `hardware`：GPU/CPU 型号、显存、运行环境。

## 限制条件写法（落到失效场景，不写套话）
写"在 X 条件下，Y 方法不适用/结果可能失效"，并给出依据材料的具体场景：
- 数据规模超出 N 时……（来自材料/原论文）。
- 仅在数据集 D 的 A/B 划分上验证，未在其他版本验证。
- 依赖环境 E/硬件 H，无 E/H 时无法复现。
- 材料未给出 Z，读者需自行补充。

无依据的泛泛限制（"可能不稳健"）不得写成结论；转为 `confirmations`。

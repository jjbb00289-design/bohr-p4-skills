---
name: methods-experiments-chapter-writer
description: 面向"方法与实验章节写作"任务的可复核学术写作技能。从实验材料（记录、配置、日志、代码、数据说明、PDF、表格等）抽取步骤、实验设置、参数、数据集与划分、对照实验、复现与限制六类要素，逐句保留来源定位与逐字原文，产出可编辑成稿、事实-来源映射与结构化 result.json，并显式标注缺口、冲突与待确认项。当用户要求撰写、补写、改写、校对或结构化一篇论文的"方法/实验/实验设置/复现性"章节，或要把散落的实验材料整理成可执行的方法与实验章节时使用。
version: 1.0.0
---

# Methods & Experiments Chapter Writer（方法与实验章节写作）

## 1. 用途

把散落的科研材料（实验记录、配置文件、日志、代码、数据说明、表格、PDF 等）整理成**可执行、可复核、可继续编辑**的"方法与实验"章节，而不是填空式模板。核心是四条：

- **写得全**：步骤、实验设置、参数、数据集与划分、对照实验、复现与限制六类要素都要写到。
- **写得准**：参数取值、数据集版本与划分、训练/评测条件必须与配置、日志、代码一致，**不得为段落顺畅而补造数值**。
- **做得着**：读者能按章节复做实验，版本、环境、随机种子、命令、数据获取方式给全。
- **说得住**：材料缺口与不确定处显式标出并交作者确认，限制条件落到具体失效场景而非套话。

只做一件事：把给定的材料**真实派生**为章节成稿 + 逐句来源映射 + 结构化结果。任何没有材料支撑的内容都不得写进正文，只能写入 gaps/confirmations。

## 2. 触发条件

- 用户要求撰写/补写/改写/校对的是一篇论文的"方法""实验""实验设置""实验设计""复现性"章节。
- 用户提供（或 /input 下存在）科研材料：实验记录、配置文件（yaml/json/ini）、日志、代码、数据集说明、表格、PDF 原论文等。
- 任务目标是把散落材料整理成方法与实验章节，并保留来源与修改记录。

不适用：纯小说/科普写作、无任何材料的事实断言写作、与论文方法章节无关的文本润色。

## 3. 调用方式

本技能由 Agent 调用。入口脚本为 `scripts/main.py`（纯 Python 3 标准库，不联网，不依赖 CWD）。所有路径默认值同时支持环境变量与参数覆盖：

| 输入 | 默认 | 环境变量 | 参数 |
|---|---|---|---|
| 输入目录 | `/input` | `INPUT_DIR` | `--input` |
| 工作目录 | `/app/work` | `WORK_DIR` | `--work` |
| 输出目录 | `/app/output` | `OUTPUT_DIR` | `--output` |

子命令（`python scripts/main.py <cmd>`）：

- `init`：读取 /input，抽取材料文本到 work/materials/，并**自动从材料派生完整工作稿** `work/draft.json`（六节正文、逐句来源、参数/数据集/基线表、gaps/confirmations），向输出目录写一份早期 result.json（超时兜底，后续 build 覆盖为 final）；若已有 draft.json 且含内容则保留不覆盖。
- `show`：打印工作稿当前状态与校验报告（只读）。
- `check`：校验工作稿的 quote 命中、六要素覆盖、契约键完整性，返回报告（只读）。
- `build`：把工作稿组装为 result.json + 可编辑成稿 + 来源映射等产物，写入 /app/output。
- 默认（无子命令）= `init`（若缺 draft 则自动派生）后 `build`，即完整流程；**空 work 下也从 /input 真实派生完整交付**（status=complete 或 partial，契约键齐全），不崩、非 0 字节。

`draft.json` 为**可选覆盖**：存在且有内容就用（Agent 精修路径），不存在或为空骨架时脚本自动派生，**不要求 Agent 先写 draft/plan**。

Agent 的执行顺序（可一步完成，也可分步复核）：

1. 读 `/input/case.json` 与 `/input/task.md`（事实底稿、受众、文体、格式约束）。
2. 直接运行 `python scripts/main.py`（默认命令）即可完成派生与落盘；如需分步，先 `init` 再 `build`。
3. （可选）读 `work/materials/` 下抽取出的材料文本，复核或精修 `work/draft.json`（见 §5 schema 与 §7 证据规范）；PDF 若无文本层，用平台 pdf-text-tool / ocr-tool；图片用 ocr-tool。
4. 运行 `python scripts/main.py check`，修正未命中的 quote 或改标 status。
5. 若格式要求 LaTeX：写 `.tex` 后调用平台 latex-compiler 编译；编译器不可用则只交付 `.tex` 并在 result.json.degradations 注明，**不得伪造 PDF**。

## 4. 输入输出

**输入**（`/input`）：
- `case.json`：含 `case_id`、`output_contract`（必回填的字段清单）、`task_instruction` 及可能的材料清单/约束。
- `task.md`：题面任务说明。
- 材料文件：PDF、图片、表格（csv/tsv/xlsx）、DOCX、SQLite、代码、配置、日志、文本等，按真实内容读取，不按文件名标签臆断。

**输出**（`/app/output`）：
- `result.json`（必有）：`case_id` + `output_contract` 每个字段原样回填（缺值 null/[]）+ `status` + `sources` + `uncertainty` + `change_records` + `errors` + `degradations` + `schema_version`。见 §8。
- `chapter.md`：可编辑的方法与实验章节成稿（Markdown；若格式要求 LaTeX 则为 `chapter.tex`）。
- `source_mapping.md`：事实/数字/引用/图表的逐条来源映射。
- `parameter_table.md`、`dataset_table.md`、`baselines.md`、`reproducibility.md`、`gaps.md`：六要素的结构化可编辑产物。
- 如编译成功：`chapter.pdf`（真实编译，非伪造）。

**工作目录**（`/app/work`）：`materials/<name>.txt`（抽取文本）、`material_index.json`、`draft.json`（工作稿）、`check_report.json`。

## 5. 工作稿 schema（draft.json）

`init` 会生成骨架；Agent 填内容。字段：

```json
{
  "schema_version": "1.0",
  "case_id": "来自 case.json",
  "task_instruction": "来自 case.json",
  "audience": "", "style": "", "format": "markdown", "language": "",
  "contract": {"<字段名>": "<类型或说明>"},
  "materials": [{"name":"...","path":"...","kind":"pdf|text|table|image|docx|sqlite|code|config|log","text_preview":"..."}],
  "sections": [
    {
      "section_id": "steps|setup|params|dataset|baseline|repro_limitation",
      "title": "章节标题",
      "body_md": "该节可编辑正文（Markdown）",
      "sentences": [
        {"claim_id":"s1-1","text":"正文中一句可独立复核的断言",
         "kind":"step|setup|param|dataset|baseline|metric|number|term|citation|figure_ref",
         "facts":[{"name":"","value":"","unit":"","scope":""}],
         "source":{"file":"材料文件名","locator":"页码/行号/表名/键路径","quote":"逐字原文片段"},
         "status":"verified|gap|conflicting|needs_confirmation","note":""}
      ]
    }
  ],
  "parameter_table": [{"name":"","value":"","unit":"","scope":"","source_file":"","source_locator":"","source_quote":"","status":""}],
  "dataset_table": [{"name":"","version":"","size":"","split":"","usage":"","preprocess":"","source_file":"","source_locator":"","source_quote":"","status":""}],
  "baselines": [{"name":"","version":"","budget":"","metric":"","stat":"","source_file":"","source_locator":"","source_quote":"","status":""}],
  "reproducibility": {"code_version":"","env":"","commands":"","data_access":"","seed":"","repeats":"","hardware":""},
  "gaps": [{"item":"","reason":"","evidence":""}],
  "conflicts": [{"item":"","value_a":"","source_a":"","value_b":"","source_b":""}],
  "confirmations": [{"item":"","question":"","why":""}],
  "change_records": [{"target":"","action":"","reason":""}],
  "overall_status": "complete|partial|insufficient_evidence"
}
```

六个 section（`section_id` 固定）：`steps`（方法步骤）、`setup`（实验设置：训练/验证/测试流程、硬件、软件版本、环境、随机种子、重复次数）、`params`（参数与来源）、`dataset`（数据集与划分）、`baseline`（对照实验）、`repro_limitation`（复现清单与限制条件）。缺材料的 section 保留标题与空 body，并在 gaps 里写明缺什么。

## 6. 六要素自检清单（写作时逐项过）

1. **方法步骤**：每步写清输入、操作、输出、判断条件；多步操作不压成一句。
2. **实验设置**：训练/验证/测试流程分开写；硬件、软件版本、运行环境、随机种子、重复次数齐全；条件不串台。
3. **参数与来源**：名称、取值、单位、作用对象、来源（配置文件/日志/作者确认）齐全；正文数值与参数表对齐。
4. **数据集与划分**：名称、版本、规模、预处理、划分比例与随机方式、各子集用途齐全；版本不混。
5. **对照实验**：基线对象及版本、对照是否同预算、评价指标、统计方式；"与基线比较"是可比的结论而非断言。
6. **复现与限制**：代码版本、环境、命令、数据获取方式；限制落到具体失效场景与适用范围。

## 7. 证据规范（硬约束）

- 每个结论/元素/条目/页面都能指回 `source.file + source.locator + source.quote`；**quote 必须能在材料原文中逐字命中**（脚本 `check` 会验证，命中率要求 ≥0.95）。
- **禁止**：placeholder、"array"/"object" 字面量、空契约键、编造数值/软件状态/引用/检索结果。
- 正文数值必须来自材料；材料没有的数值**不得**写进正文，只能写进 `confirmations`（问题+理由）交作者确认。
- 术语表、缩写首次出现、引用编号、图表指向与原文一致；不改数字/单位/限定词强度。
- `status` 语义：`verified`=quote 命中且与正文一致；`gap`=材料缺该项；`conflicting`=材料间不一致；`needs_confirmation`=需要作者确认。
- 每处对材料的引用都要在 quote 里放**逐字原文**，不要转述。无法逐字引用的（如图片）用 locator 标注位置并在 note 说明。

## 8. result.json 结构

```json
{
  "case_id": "...",
  "status": "complete|partial|insufficient_evidence|input_error",
  "schema_version": "1.0",
  "<output_contract 每个字段名>": "<值，缺则 null 或 []>",
  "sources": [{"claim_id":"","file":"","locator":"","quote":"","status":""}],
  "uncertainty": [{"item":"","reason":"","impact":""}],
  "change_records": [{"target":"","action":"","reason":""}],
  "errors": [],
  "degradations": []
}
```

- `output_contract` 的字段**原样回填**、不改名、不漏键；值类型据 contract 声明（dict 且含 array/list → []，否则 null）。
- `sources` 从所有 sentences 与表条目汇总；`uncertainty` 由 gaps/conflicts/confirmations 生成；`change_records` 原样搬运 draft。
- 任何异常都写入 `errors`/`degradations`；脚本退出码恒为 0。

## 9. 降级表（degradations）

| 情形 | 处置 | status |
|---|---|---|
| 无材料 / 材料目录空 | 六节空 body，gaps 逐项列缺，sources 空 | insufficient_evidence |
| case.json 缺失或坏 JSON | 读取 task.md 为唯一依据，errors 记录 | input_error |
| 无工作稿（draft.json 不存在或为空骨架） | 由 /input 材料自动派生完整 draft，逐句来源可命中；六要素缺者写 gaps/confirmations | complete / partial |
| PDF 无文本层 | 标 needs_ocr，提示用 pdf-text-tool/ocr-tool；不编造文本 | partial |
| 图片/扫描件 | 标 needs_ocr，locator=文件名，note 说明 | partial |
| quote 未命中 | 该条 status 改 needs_confirmation，写入 degradation | partial |
| LaTeX 编译器不可用 | 只交付 .tex，degradations 注明 | partial |
| 权限不足写输出失败 | errors 记录，result.json 尽可能写回 work | input_error |

## 10. 自检

- `python scripts/main.py check` 退出码 0，quote 命中率 ≥0.95（无 quote 时报告 n/a）。
- `python scripts/main.py` 在清空 work/output 后能独立产出完整 result.json（契约键齐全）。
- 两次全新输出目录运行，产物结构一致（无时间戳/随机依赖）。
- result.json 可 `json.load` 解析，含 case_id + 所有契约键。

## 11. 限制

- 脚本不联网、不改写材料事实；只抽取、对齐、校验与组装。
- 正文由脚本从材料**自动派生**（仅使用材料中实际出现的键值、指标与语句），`draft.json` 可作为 Agent 精修的覆盖；脚本保证来源可核验与契约合规。
- 图片 OCR、真实 PDF 编译、DOCX/Office 渲染依赖平台工具，脚本缺工具时诚实降级，不伪造产物。

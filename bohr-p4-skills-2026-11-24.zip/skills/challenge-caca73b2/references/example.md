# 最小调用示例（示例，非正式案例结果）

> 合成测试案例，**不是**平台正式案例，**不得**当作正式结果提交。

## 1. 输入

```
input/
  case.json                  # case_id "syn-caca-01"；contract 18 键
  materials/study-report.md  # Abstract / Results / Table 1 / Discussion / Figure captions
```

## 2. draft.json（节选）

```json
{
  "case_id": "syn-caca-01",
  "results": [
    {"claim_id": "R1", "metric": "overpotential", "value": "1.36", "unit": "V",
     "figure_or_table": "Table 1", "data_row_ids": ["R1"], "locator": "para.12",
     "quote": "The optimised sample showed an overpotential of 1.36 V at 10 mA cm-2, 0.22 V lower than the air-annealed control (1.58 V).",
     "statement": "The optimised sample reached an overpotential of 1.36 V at 10 mA cm-2, 0.22 V lower than the air-annealed control (Table 1)."}
  ],
  "data_rows": [
    {"row_id": "R1", "metric": "overpotential at 10 mA cm-2", "value": "1.36", "unit": "V",
     "figure_or_table": "Table 1", "condition": "1 M KOH + 0.33 M urea", "locator": "para.12",
     "quote": "The optimised sample showed an overpotential of 1.36 V at 10 mA cm-2, 0.22 V lower than the air-annealed control (1.58 V)."}
  ],
  "discussion": [
    {"text": "The lower overpotential is consistent with oxygen vacancies improving urea adsorption; the comparison is descriptive because no significance test is reported.",
     "claim_ids": ["R1"], "kind": "interpretation"}
  ],
  "limitations": ["Stability was tested for 24 h only.", "No in situ spectroscopic evidence was collected."],
  "claim_strength": [
    {"claim_id": "R1", "strength": "moderate", "basis": "single controlled comparison against an air-annealed control; no replicates reported", "scope": "1 M KOH + 0.33 M urea, 10 mA cm-2"}
  ]
}
```

## 3. 输出（节选）

`o/results_discussion.md`：

```markdown
## Results

The optimised sample reached an overpotential of 1.36 V at 10 mA cm-2, 0.22 V lower than the air-annealed control (Table 1).

## Discussion

The lower overpotential is consistent with oxygen vacancies improving urea adsorption; the comparison is descriptive because no significance test is reported.

### Limitations

- Stability was tested for 24 h only.
- No in situ spectroscopic evidence was collected.
```

`o/extracted_data.csv`：

```csv
row_id,metric,value,unit,figure_or_table,condition,locator,quote,status
R1,overpotential at 10 mA cm-2,1.36,V,Table 1,1 M KOH + 0.33 M urea,para.12,"The optimised sample showed an overpotential of 1.36 V at 10 mA cm-2, ...",verified
```

`o/claim_strength.md`：

```markdown
| claim | statement | strength | basis | scope |
|---|---|---|---|---|
| R1 | The optimised sample reached an overpotential of 1.36 V ... | moderate | single controlled comparison ... | 1 M KOH + 0.33 M urea, 10 mA cm-2 |
```

## 4. 会被 check 拦住的反例

- `"quote"` 用改写句 → `row_quote` / `claim_quote`。
- `"value": "1.4"` 但 quote 是 1.36 → `row_value`（改数）。
- Discussion 写 "p = 0.03" 而材料没有 → `p_value_invented`。
- 某条 claim 没有 claim_strength → `strength_missing`。
- limitations 只写 1 条 → `limitations`。

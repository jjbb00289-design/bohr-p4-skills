---
name: results-discussion
description: 结果与讨论章节写作 — 从给定数据表、图注与结果文字写出可投稿的 Results + Discussion：Results 只陈述观察并逐值锚定表/图 locator 与逐字 quote，Discussion 承担解释/对照/局限；交付 results_discussion.md、extracted_data.csv、evidence_map.json、claim_strength.md。不编造 p 值、样本量或测量值。
version: 1.0.0
---

# results-discussion（Results & Discussion 写作）

## 1. 用途与适用条件

**用途**：把「数据在手、图表已画」的材料写成两节：
- **Results**：只陈述观察（按图序/问题组织），每个数值带 `figure_or_table + locator + 逐字 quote`；
- **Discussion**：解释、与文献对照、边界与 Limitations；区分 observation / interpretation。

产物：

| 文件 | 内容 |
|---|---|
| `results_discussion.md` | Results + Discussion + Limitations 三节 |
| `extracted_data.csv` | 每个读数一行：metric/value/unit/图表/条件/locator/quote/status |
| `evidence_map.json` | 每条结论 → source + locator + 逐字 quote + kind(observation/interpretation) |
| `claim_strength.md` | 每条结论的证据强度与适用范围（high/moderate/low/insufficient） |
| `preserved_facts.json` | 数字/单位事实表 |
| `change_log.json` | 观察→成稿句的留痕（不改值） |

**适用**：论文/报告的 Results & Discussion 撰写、图表数据到文字的转写、审稿后补写结果段。
**不适用**：没有数据却要求「写出结果」、需要真实补做实验、需要联网查文献数值。

## 2. 硬边界

1. 数值/单位/显著性表述必须与材料一致；**不得补造 p 值、样本量、误差棒或新测量**。
2. 图读数不得靠猜：对数轴/线性轴、SEM/SD、单位前缀必须按材料标注；材料没给就不写。
3. Results 与 Discussion 不混写：Results 只描述观察，因果解释放 Discussion。
4. 阴性结果、不一致文献、无法判断的项必须交代，不能只挑显著的结果写。
5. 退出码恒 0，先写 partial `result.json` 再 finalize。

## 3. 运行时契约

- 输入：`/input/case.json`（`case_id`/`task_instruction`/`output_contract`）、`/input/` 材料（md/txt/csv/json/pdf/docx；表格与图注常在正文里）。
- 输出：`/app/output/`，必须含 `result.json`（契约键原样回填 + `case_id`）。
- 工作区 `/app/work`；纯标准库、不联网、不依赖 CWD；预算 64 请求 / 900 秒。

## 4. 五命令主路径（脚本不代替阅读）

```bash
python scripts/main.py init      # 扫材料、分段 locator、解析表格、写 partial result.json
python scripts/main.py show      # 材料清单 + 表格清单
python scripts/main.py show --material m1            # 读正文（para.N）
python scripts/main.py tables                        # 看解析出的表格（表头/行/locator）
python scripts/main.py extract   # 候选数字（带 locator + 逐字 quote）
#  ← 你（Agent）读数据后写 /app/work/draft.json（§5）
python scripts/main.py check     # 数字锚定、quote 命中、强度覆盖、p 值防伪
python scripts/main.py build     # 生成两节 + csv + 证据表 + 强度表 + result.json
```

只跑 `build` 不写 `draft.json` 会从材料表格里**机械抽取**数值并产出降级版（`status=partial`），不能当作完成。

## 5. `work/draft.json` schema

```json
{
  "case_id": "<原样>", "title": "稿件标题",
  "results": [
    {"claim_id": "R1", "metric": "overpotential", "value": "1.36", "unit": "V",
     "figure_or_table": "Table 1", "data_row_ids": ["R1"],
     "locator": "para.12", "source_id": "m1",
     "quote": "材料中含该数值的逐字原句",
     "statement": "写进 Results 的观察句（可含图表号，不含因果解释）"}
  ],
  "data_rows": [
    {"row_id": "R1", "metric": "overpotential at 10 mA cm-2", "value": "1.36", "unit": "V",
     "figure_or_table": "Table 1", "condition": "1 M KOH + 0.33 M urea",
     "locator": "para.12", "quote": "逐字原句"}
  ],
  "discussion": [
    {"text": "解释段（含条件与边界，引用 claim_id）", "claim_ids": ["R1"], "kind": "interpretation"}
  ],
  "limitations": ["局限 1", "局限 2"],
  "claim_strength": [
    {"claim_id": "R1", "strength": "moderate", "basis": "为什么是 moderate", "scope": "适用条件"}
  ],
  "preserved_facts": [{"fact_id": "F1", "value": "1.36", "unit": "V", "source_id": "m1",
                       "locator": "para.12", "quote": "逐字原句"}],
  "evidence_map": [{"claim_id": "A1", "claim": "论断", "source_id": "m1", "locator": "para.12",
                    "quote": "逐字原句", "kind": "direct|inferred|undetermined"}],
  "uncertainties": ["..."], "pending_human": ["..."], "gaps": ["..."]
}
```

规则：
- Results 每条必须能落到 `figure_or_table` 或 `data_row_ids`；数值必须出现在自己的 quote 里。
- 讨论段用 `claim_ids` 关联结论；没有证据的句子写进 `pending_human`，不要写成结论。
- 强度四档：high（重复+效应量+对照）/ moderate（单次受控+条件清楚）/ low（单次观察或相关性）/ insufficient（材料不足）。不得把 low 写成 high。
- Limitations ≥2 条；阴性/不显著结果也要交代。

## 6. 数字与定位规范

- 段落 `para.N`；表 `Table 1` + `para.N`；图 `Figure 1b` + 图注 `para.N`。
- 每个数值：原值原单位（不取整、不换单位）；换算另存原值并写公式。
- 显著性：只有材料给出检验时才写 p 值；否则写描述性差异并注明「未报告显著性检验」。
- `check` 会扫描草稿文本里的 p 值，任何材料中不存在的 p 值直接判 `p_value_invented`。

## 7. `check` 会拦住什么

| 检查 | 含义 |
|---|---|
| `results_empty` / `discussion_empty` | 两节有一节没写 |
| `limitations` | 局限少于 2 条 |
| `row_quote` / `claim_quote` / `fact_quote` | quote 在材料中不逐字命中 |
| `row_value` / `claim_value` | 数值不在自己的 quote 里（疑似改数） |
| `row_locator` / `claim_locator` | 缺 locator |
| `claim_anchor` | 结果句没有图表/数据行锚点 |
| `row_duplicate` | 数据行 id 重复 |
| `strength_missing` / `strength_vocabulary` | 结论缺强度或强度不在四档 |
| `p_value_invented` | 出现材料中没有的 p 值（编造统计） |

## 8. 降级与异常（exit 0 优先）

| 情况 | 行为 |
|---|---|
| case.json 缺失/坏 | `input_error` + errors，仍写合法 result.json |
| 无材料 | `insufficient_evidence`/`input_error` + pending_human |
| 无 draft | 从表格抽取数值生成 Results 骨架 + 空 Discussion，`status=partial` |
| 表格解析不到 | 从正文数字候选生成，标 `extracted` 并写 degradations |
| quote 不命中 | 该条 fail 并降级；不得改 quote 冒充命中 |
| 无 p 值/无重复 | 写「未报告」，不补造 |
| 超时/中断 | 先写 partial result.json |

## 9. 提交前自检

- [ ] `check` passed=true
- [ ] Results 每个数值有图表/行锚点 + 逐字 quote
- [ ] extracted_data.csv 行数 = data_rows；每行 locator/quote 齐
- [ ] claim_strength 覆盖全部 claim_id
- [ ] Limitations ≥2，Discussion 区分 observation/interpretation
- [ ] 无材料外 p 值/样本量/测量值
- [ ] 两遍运行 result.json 一致

## 10. 最小示例（示例，非正式案例结果）

```bash
python scripts/main.py init --input ./localtest/input --work w --output o
python scripts/main.py tables
# 写 w/draft.json：results=[{claim_id:"R1", value:"1.36", unit:"V", figure_or_table:"Table 1",
#   locator:"para.12", quote:"<逐字原句>", statement:"..."}], data_rows=[...],
#   discussion=[{text:"...", claim_ids:["R1"]}], limitations=["...","..."],
#   claim_strength=[{claim_id:"R1", strength:"moderate", basis:"...", scope:"..."}]
python scripts/main.py check --input ./localtest/input --work w --output o
python scripts/main.py build --input ./localtest/input --work w --output o
```

完整示例见 `references/example.md`（**示例，非正式案例结果**）。

## 11. 限制、版本与维护

- 版本 1.0.0（2026-11）。
- 材料支持：md/txt/json/csv/tex/docx/xlsx/pptx；PDF 用标准库尽力抽文本层，扫描件会降级。
- 本包不做统计检验、不生成新图；如材料只有图没有数值，会把「无法读数」写进 gaps 而不是猜。
- 创新点边界：数值级锚定（每个数字→图表→quote）+ 强度/适用域分离 + p 值防伪，是相对通用写作 Agent 的增益点。

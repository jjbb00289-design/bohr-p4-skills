#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""results-discussion -- write Results & Discussion sections from supplied data.

Commands: init | show | extract | check | build
Flow: init -> show (read data, tables, figure captions) -> write work/draft.json -> check -> build

Results state observations only (each value anchored to a table/figure locator + verbatim
quote); Discussion carries interpretation, comparison and an explicit Limitations subsection.
The script extracts tables, checks every number against its source quote, renders the two
sections plus extracted_data.csv, evidence_map.json and claim_strength.md, and finalizes a
contract-complete result.json. It never invents p-values, sample sizes or measurements.
"""
import csv
import io
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import core as K

NAME = "results-discussion"
VERSION = "1.0.0"
FILES = {
    "results_discussion": "results_discussion.md",
    "extracted_data": "extracted_data.csv",
    "evidence_map": "evidence_map.json",
    "claim_strength": "claim_strength.md",
}
STRENGTH = {"high", "moderate", "low", "insufficient"}
ARTIFACT_MAP = {
    "results_discussion": "results_discussion.md",
    "resultsdiscussion": "results_discussion.md",
    "results": "results_discussion.md",
    "extracted_data": "extracted_data.csv",
    "extracteddata": "extracted_data.csv",
    "data_csv": "extracted_data.csv",
    "evidence_map": "evidence_map.json",
    "evidencemap": "evidence_map.json",
    "claim_strength": "claim_strength.md",
    "claimstrength": "claim_strength.md",
}
NC = re.compile(r"(?<![\w.])[-+]?\d+(?:\.\d+)?")
P_RE = re.compile(r"\bp\s*[=<>]\s*0?\.\d+|\bp\s*[=<>]\s*\d", re.I)


# ------------------------------------------------------------------ tables
def parse_tables(segments, source_path=""):
    tables = []
    rows_buffer = []
    for seg in segments:
        lines = [ln.strip() for ln in (seg.get("text") or "").split("\n")]
        block = []
        for line in lines:
            if line.startswith("|") and line.endswith("|"):
                block.append(line)
        if len(block) >= 2:
            cells = [[c.strip() for c in row.strip("|").split("|")] for row in block]
            if re.fullmatch(r"[:\-\s|]+", "|".join(cells[1])):
                header, body = cells[0], cells[2:]
            else:
                header, body = cells[0], cells[1:]
            if body:
                tables.append({"table_id": "T%d" % (len(tables) + 1),
                               "header": header, "rows": body,
                               "locator": seg.get("locator", ""),
                               "source": source_path})
                rows_buffer.append(body)
    return tables


def csv_tables(path):
    tables = []
    try:
        text = Path(path).read_text(encoding="utf-8-sig", errors="replace")
        rows = list(csv.reader(io.StringIO(text)))
        if len(rows) >= 2 and any(rows[0]):
            tables.append({"table_id": "C%d" % (len(tables) + 1), "header": rows[0],
                           "rows": [r for r in rows[1:] if any(r)],
                           "locator": "file:" + Path(path).name,
                           "source": Path(path).name})
    except Exception:
        pass
    return tables


def collect_tables(index, work):
    tables = []
    for mat in index.get("materials") or []:
        segments = (K.jload(Path(work) / "segments" / (mat["material_id"] + ".json"),
                            {}) or {}).get("segments") or []
        tables.extend(parse_tables(segments, mat.get("path", "")))
        if (mat.get("kind") == "csv"):
            tables.extend(csv_tables(Path(index.get("input_dir", "/input")) / mat["path"]))
    return tables


# ------------------------------------------------------------------ index
def build_index(args):
    case = K.jload(Path(args.input) / "case.json", None)
    case = case if isinstance(case, dict) else {}
    materials, notes = K.discover(args.input)
    work = Path(args.work)
    for mat in materials:
        segments = K.segment_document(mat.get("_text") or "", mat)
        try:
            K.jdump(work / "segments" / (mat["material_id"] + ".json"),
                    {"material_id": mat["material_id"], "path": mat["path"],
                     "segments": segments})
        except Exception:
            notes.append("could not persist segments for %s" % mat.get("path"))
    items = K.workorder_items(case, materials)
    index = {"skill": NAME, "version": VERSION,
             "case_id": str(case.get("case_id") or case.get("id") or ""),
             "input_dir": str(Path(args.input).resolve()),
             "materials": [{k: v for k, v in m.items() if not k.startswith("_")}
                           for m in materials],
             "workorder": [{"item_id": i["item_id"], "text": i["text"], "source": i["source"]}
                           for i in items],
             "counts": {"materials": len(materials), "workorder_items": len(items)},
             "notes": notes}
    tables = collect_tables(index, work)
    index["tables"] = tables
    index["counts"]["tables"] = len(tables)
    K.jdump(work / "index.json", index)
    return case, materials, index, notes


def partial_payload(index, notes):
    payload = K.base_envelope(index.get("case_id", ""), "partial",
                              degradations=list(notes) + ["partial scaffold written by init; "
                                                          "work/draft.json not yet built"])
    payload.update({"deliverable": "", "preserved_facts": [], "evidence_map": [],
                    "change_log": [], "claims": [], "coverage": {},
                    "results": [], "discussion": [], "limitations": [],
                    "result": {"deliverables": {}, "counts": {}, "tables": index.get("tables"),
                               "workorder": index.get("workorder")},
                    "sources": K.sources_from(index),
                    "skill": {"name": NAME, "version": VERSION}})
    return payload


def cmd_init(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    case, materials, index, notes = build_index(args)
    status = "input_error" if not materials else "partial"
    payload = partial_payload(index, notes)
    payload["status"] = status
    if not materials:
        payload["errors"].append("no input materials discovered")
    K.finalize_result(out, payload, case.get("output_contract"), index.get("case_id"))
    print(json.dumps({"ok": True, "command": "init", "case_id": index["case_id"],
                      "status": status, "counts": index["counts"],
                      "tables": [{"table_id": t["table_id"], "locator": t["locator"],
                                  "rows": len(t["rows"]), "header": t["header"]}
                                 for t in index.get("tables") or []],
                      "materials": [{"material_id": m["material_id"], "path": m["path"],
                                     "kind": m["kind"], "text_chars": m["text_chars"]}
                                    for m in materials],
                      "next": "show --material mN, read results/table/figure data, write "
                              "work/draft.json, then check and build"}, ensure_ascii=False,
                     indent=2))
    return 0


def cmd_show(args):
    work = Path(args.work)
    index = K.jload(work / "index.json", {}) or {}
    if not args.material:
        print(json.dumps({"case_id": index.get("case_id"),
                          "counts": index.get("counts"),
                          "tables": [{"table_id": t["table_id"], "locator": t["locator"],
                                      "rows": len(t["rows"])}
                                     for t in index.get("tables") or []],
                          "materials": [{k: m.get(k) for k in ("material_id", "path", "kind",
                                                               "bytes", "text_chars", "notes")}
                                        for m in index.get("materials", [])]},
                         ensure_ascii=False, indent=2))
        return 0
    target = next((m for m in index.get("materials", [])
                   if m.get("material_id") == args.material), None)
    if not target:
        print(json.dumps({"error": "unknown material: %s" % args.material}, ensure_ascii=False))
        return 0
    segments = (K.jload(work / "segments" / (args.material + ".json"), {}) or {}).get(
        "segments") or []
    shown = 0
    for seg in segments:
        if args.grep and not re.search(args.grep, seg.get("text", ""), re.I):
            continue
        print("=== [%s] %s" % (seg.get("locator"), target.get("path")))
        print(seg.get("text"))
        print()
        shown += 1
        if args.limit and shown >= args.limit:
            break
    if shown == 0:
        print(json.dumps({"material_id": args.material, "path": target.get("path"),
                          "segments": 0, "notes": target.get("notes")}, ensure_ascii=False))
    return 0


def cmd_tables(args):
    work = Path(args.work)
    index = K.jload(work / "index.json", {}) or {}
    tables = index.get("tables") or []
    if args.table:
        tables = [t for t in tables if t.get("table_id") == args.table]
    print(json.dumps({"ok": True, "command": "tables", "count": len(tables),
                      "tables": tables[:12]}, ensure_ascii=False, indent=2))
    return 0


def cmd_extract(args):
    work = Path(args.work)
    index = K.jload(work / "index.json", {}) or {}
    harvest = {"numbers": [], "dois": [], "years": [], "citations": []}
    for mat in index.get("materials") or []:
        segments = (K.jload(work / "segments" / (mat["material_id"] + ".json"), {}) or {}).get(
            "segments") or []
        for key, values in K.harvest(segments, mat["material_id"]).items():
            harvest.setdefault(key, []).extend(values)
    harvest["tables"] = index.get("tables") or []
    K.jdump(work / "candidates.json", harvest)
    print(json.dumps({"ok": True, "command": "extract",
                      "saved_to": str(work / "candidates.json"),
                      "counts": {k: len(v) for k, v in harvest.items()},
                      "note": "candidates only; promote used values into draft.data_rows with "
                              "the exact quote and locator"}, ensure_ascii=False, indent=2))
    return 0


# ------------------------------------------------------------------ checks
def load_draft(args):
    path = Path(args.draft) if getattr(args, "draft", None) else Path(args.work) / "draft.json"
    draft = K.jload(path, None)
    return (draft if isinstance(draft, dict) else None), str(path)


def load_corpus(work, index):
    parts = []
    for mat in index.get("materials") or []:
        segments = (K.jload(Path(work) / "segments" / (mat["material_id"] + ".json"),
                            {}) or {}).get("segments") or []
        parts.extend(s.get("text", "") for s in segments)
    return K.norm_text("\n".join(parts))


def run_checks(args, index, draft):
    corpus = load_corpus(args.work, index)
    fails, warnings = [], []
    counts = {"result_claims": 0, "data_rows": 0, "discussion_paras": 0, "limitations": 0,
              "facts": 0, "evidence": 0, "claim_strength": 0, "new_p_values": 0}
    if draft is None:
        fails.append({"code": "draft_missing", "message": "work/draft.json not found"})
        return {"passed": False, "fails": fails, "warnings": warnings, "counts": counts}

    def fail(code, message):
        fails.append({"code": code, "message": message})

    results = draft.get("results") or []
    rows = draft.get("data_rows") or []
    discussion = draft.get("discussion") or []
    limitations = draft.get("limitations") or []
    counts.update(result_claims=len(results), data_rows=len(rows),
                  discussion_paras=len(discussion), limitations=len(limitations))
    if not results:
        fail("results_empty", "no Results observations supplied")
    if not discussion:
        fail("discussion_empty", "no Discussion paragraphs supplied")
    if len(limitations) < 2:
        fail("limitations", "fewer than two limitations recorded")
    seen_rows = set()
    row_values = set()
    for idx, row in enumerate(rows, start=1):
        rid = str(row.get("row_id") or "R%d" % idx)
        if rid in seen_rows:
            fail("row_duplicate", "duplicate data row id %s" % rid)
        seen_rows.add(rid)
        quote = row.get("quote")
        if not K.quote_hit(quote, corpus)["hit"]:
            fail("row_quote", "%s quote not verbatim in the materials" % rid)
        value = K.norm_text(row.get("value"))
        if value:
            row_values.add(value.replace(" ", ""))
            if value not in K.norm_text(quote):
                fail("row_value", "%s value %r absent from its quote" % (rid, row.get("value")))
        if not str(row.get("locator") or "").strip():
            fail("row_locator", "%s has no locator" % rid)
    for claim in results:
        cid = claim.get("claim_id")
        quote = claim.get("quote")
        if not K.quote_hit(quote, corpus)["hit"]:
            fail("claim_quote", "%s quote not verbatim" % cid)
        if not str(claim.get("locator") or "").strip():
            fail("claim_locator", "%s has no locator" % cid)
        if not (claim.get("figure_or_table") or claim.get("data_row_ids")):
            fail("claim_anchor", "%s has no figure/table or data-row anchor" % cid)
        value = K.norm_text(claim.get("value"))
        if value and value.replace(" ", "") not in row_values and value not in K.norm_text(quote):
            fail("claim_value", "%s value %r is not in data rows or its quote"
                 % (cid, claim.get("value")))
    for fact in draft.get("preserved_facts") or []:
        counts["facts"] += 1
        if not K.quote_hit(fact.get("quote"), corpus)["hit"]:
            fail("fact_quote", "%s quote not verbatim" % fact.get("fact_id"))
    for ev in draft.get("evidence_map") or []:
        counts["evidence"] += 1
        if not K.quote_hit(ev.get("quote"), corpus)["hit"]:
            fail("evidence_quote", "%s quote not verbatim" % ev.get("claim_id"))
    strengths = draft.get("claim_strength") or []
    counts["claim_strength"] = len(strengths)
    covered = {str(s.get("claim_id")) for s in strengths}
    for claim in results:
        if str(claim.get("claim_id")) not in covered:
            fail("strength_missing", "claim %s has no evidence-strength entry"
                 % claim.get("claim_id"))
    for item in strengths:
        if str(item.get("strength") or "").lower() not in STRENGTH:
            fail("strength_vocabulary", "%s strength %r not in %s"
                 % (item.get("claim_id"), item.get("strength"), sorted(STRENGTH)))
    deliv_text = " ".join([str(c.get("statement") or "") for c in results] +
                          [str(p.get("text") or p.get("paragraph") or "") for p in discussion])
    p_values = set(P_RE.findall(deliv_text))
    corpus_p = set(P_RE.findall(corpus))
    if p_values - corpus_p:
        counts["new_p_values"] = len(p_values - corpus_p)
        fail("p_value_invented", "p-values appear in the draft that are absent from the "
                                 "materials: %s" % ", ".join(sorted(p_values - corpus_p)))
    return {"passed": not fails, "fails": fails, "warnings": warnings, "counts": counts}


def print_report(report):
    print(json.dumps({"passed": report["passed"], "fail_count": len(report["fails"]),
                      "warning_count": len(report["warnings"]),
                      "counts": report.get("counts"), "fails": report["fails"],
                      "warnings": report["warnings"]}, ensure_ascii=False, indent=2))


def cmd_check(args):
    work = Path(args.work)
    index = K.jload(work / "index.json", {}) or {}
    if not index:
        index = {"materials": [], "workorder": [], "case_id": "", "tables": []}
    draft, path = load_draft(args)
    report = run_checks(args, index, draft)
    report["draft_path"] = path
    K.jdump(work / "check_report.json", report)
    print_report(report)
    return 0


# ------------------------------------------------------------------ renderers
def render_sections(draft, title):
    lines = ["# %s" % (title or "Results and Discussion"), ""]
    lines += ["## Results", ""]
    results = draft.get("results") or []
    if not results:
        lines += ["_No Results observations were supplied; see result.json for the declared "
                  "gap._", ""]
    for claim in results:
        anchor = claim.get("figure_or_table") or ", ".join(claim.get("data_row_ids") or [])
        text = str(claim.get("statement") or "").strip()
        if not text:
            text = "%s: %s %s (%s; %s)." % (
                claim.get("metric") or "Reported value", claim.get("value"),
                claim.get("unit") or "", anchor or "no anchor", claim.get("locator") or "")
        if anchor and anchor not in text:
            text += " (%s)" % anchor
        lines += [text, ""]
    lines += ["## Discussion", ""]
    for para in draft.get("discussion") or []:
        text = str(para.get("text") or para.get("paragraph") or "").strip()
        if text:
            lines += [text, ""]
    if not (draft.get("discussion") or []):
        lines += ["_No Discussion paragraphs were supplied; interpretation is deferred rather "
                  "than invented._", ""]
    lines += ["### Limitations", ""]
    for lim in draft.get("limitations") or []:
        text = str(lim.get("text") if isinstance(lim, dict) else lim).strip()
        if text:
            lines.append("- " + text)
    if not (draft.get("limitations") or []):
        lines.append("- _No limitations were supplied; this is a declared gap, not a claim "
                     "that none exist._")
    lines.append("")
    return "\n".join(lines)


def render_strength(draft):
    lines = ["# Claim strength and support scope", "",
             "| claim | statement | strength | basis | scope |", "|---|---|---|---|---|"]
    by_id = {str(c.get("claim_id")): c for c in draft.get("results") or []}
    for item in draft.get("claim_strength") or []:
        cid = str(item.get("claim_id"))
        claim = by_id.get(cid) or {}
        lines.append("| %s | %s | %s | %s | %s |" % (
            cid, K.clip(claim.get("statement") or claim.get("metric") or "", 70),
            item.get("strength"), item.get("basis") or "", item.get("scope") or ""))
    lines += ["", "Strength rubric: high = replicated, effect size reported, controlled; "
                  "moderate = single controlled measurement with a clear condition; low = "
                  "single observation or correlative comparison; insufficient = source does not "
                  "report enough to judge. No strength is upgraded beyond the supplied data.", ""]
    return "\n".join(lines)


# ------------------------------------------------------------------ build
def cmd_build(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    errors, degradations = [], []
    index = K.jload(work / "index.json", {}) or {}
    if not index:
        degradations.append("index.json absent; running init implicitly")
        try:
            case, _m, index, notes = build_index(args)
            degradations.extend(notes)
        except Exception as exc:
            errors.append("implicit init failed: %s" % exc)
            index = {"materials": [], "workorder": [], "case_id": "", "tables": []}
    case = K.jload(Path(args.input) / "case.json", {}) or {}
    if not isinstance(case, dict):
        case = {}
        errors.append("case.json is not a JSON object")
    draft, draft_path = load_draft(args)
    if draft is None:
        degradations.append("work/draft.json missing at %s; produced an honest degraded "
                            "deliverable" % draft_path)
        draft = {}
    corpus = load_corpus(work, index)
    tables = index.get("tables") or []
    results = draft.get("results") or []
    rows = draft.get("data_rows") or []
    if not rows:
        for table in tables[:4]:
            header = table.get("header") or []
            for r_idx, raw in enumerate(table.get("rows") or []):
                row = dict(zip(header, raw))
                metric = next((v for k, v in row.items() if k and "name" in k.lower()), "")
                value = next((v for k, v in row.items()
                              if re.search(r"value|mean|result", k or "", re.I)), "")
                unit = next((v for k, v in row.items() if "unit" in (k or "").lower()), "")
                if value:
                    rows.append({"row_id": "%s-r%d" % (table.get("table_id"), r_idx + 1),
                                 "metric": metric or (header[0] if header else ""),
                                 "value": value, "unit": unit,
                                 "figure_or_table": table.get("table_id"),
                                 "locator": table.get("locator"),
                                 "condition": "as tabulated",
                                 "quote": "%s: %s" % (", ".join(header),
                                                      ", ".join(raw)),
                                 "status": "extracted-from-table"})
        if rows:
            degradations.append("data rows extracted directly from input tables (no draft)")
    facts = []
    for idx, fact in enumerate(draft.get("preserved_facts") or [], start=1):
        quote = str(fact.get("quote") or "")
        facts.append({"fact_id": fact.get("fact_id") or "F%d" % idx,
                      "value": fact.get("value"), "unit": fact.get("unit", ""),
                      "source_id": fact.get("source_id") or "m1",
                      "locator": fact.get("locator", ""), "quote": quote,
                      "status": "preserved" if K.quote_hit(quote, corpus)["hit"] else "flagged"})
    evidence_map = []
    for ev in draft.get("evidence_map") or []:
        item = dict(ev)
        item["hit"] = K.quote_hit(ev.get("quote"), corpus)["hit"]
        evidence_map.append(item)
    if not evidence_map:
        for claim in results:
            evidence_map.append({"claim_id": claim.get("claim_id"),
                                 "claim": claim.get("statement"),
                                 "source_id": claim.get("source_id") or "m1",
                                 "locator": claim.get("locator"),
                                 "quote": claim.get("quote"), "kind": "direct"})
    change_log = []
    for idx, claim in enumerate(results, start=1):
        change_log.append({"id": "C%d" % idx, "action": "write",
                           "original_quote": claim.get("quote"),
                           "revised_quote": claim.get("statement"),
                           "reason": "observation stated from the supplied data (no value change)",
                           "locator": claim.get("locator")})
    title = draft.get("title") or ""
    body = render_sections(draft, title)
    report = run_checks(args, index, draft) if draft else {
        "passed": False, "fails": [{"code": "draft_missing", "message": "no draft"}],
        "warnings": [], "counts": {}}
    strengths = draft.get("claim_strength") or []
    counts = {"results": len(results), "data_rows": len(rows),
              "discussion": len(draft.get("discussion") or []),
              "limitations": len(draft.get("limitations") or []),
              "claim_strength": len(strengths), "tables": len(tables),
              "chars": len(body)}
    deliverables = {}
    try:
        (out / FILES["results_discussion"]).write_text(body, encoding="utf-8")
        deliverables["results_discussion"] = FILES["results_discussion"]
    except Exception as exc:
        errors.append("results_discussion write failed: %s" % exc)
    try:
        with open(out / FILES["extracted_data"], "w", encoding="utf-8", newline="") as fh:
            writer = csv.writer(fh)
            writer.writerow(["row_id", "metric", "value", "unit", "figure_or_table", "condition",
                             "locator", "quote", "status"])
            for idx, row in enumerate(rows, start=1):
                writer.writerow([row.get("row_id") or "R%d" % idx, row.get("metric", ""),
                                 row.get("value", ""), row.get("unit", ""),
                                 row.get("figure_or_table", ""), row.get("condition", ""),
                                 row.get("locator", ""), row.get("quote", ""),
                                 row.get("status", "verified")])
        deliverables["extracted_data"] = FILES["extracted_data"]
    except Exception as exc:
        errors.append("extracted_data write failed: %s" % exc)
    for name, payload, key in ((FILES["evidence_map"], evidence_map, "evidence_map"),
                               (FILES["claim_strength"], None, "claim_strength"),
                               ("preserved_facts.json", facts, "preserved_facts"),
                               ("change_log.json", change_log, "change_log")):
        try:
            if name == FILES["claim_strength"]:
                (out / name).write_text(render_strength(draft), encoding="utf-8")
            else:
                K.jdump(out / name, payload)
            deliverables[key] = name
        except Exception as exc:
            errors.append("%s write failed: %s" % (name, exc))
    status = "ok"
    if not draft:
        status = "partial"
    if not results or not (draft.get("discussion") or []):
        status = "partial"
        degradations.append("Results or Discussion is empty")
    if not (index.get("materials") or []):
        status = "input_error"
        errors.append("no input materials discovered")
    if report.get("fails"):
        status = "partial" if status == "ok" else status
        degradations.append("%d check failure(s); see check_report.json"
                            % len(report["fails"]))
    claims = [{"claim_id": c.get("claim_id"), "text": c.get("statement"),
               "kind": "direct", "evidence": [{"source_id": c.get("source_id") or "m1",
                                               "locator": c.get("locator"),
                                               "quote": c.get("quote")}]}
              for c in results]
    coverage = {"results": len(results), "data_rows": len(rows),
                "discussion": len(draft.get("discussion") or []),
                "limitations": len(draft.get("limitations") or []),
                "claim_strength": len(strengths),
                "discussion_with_evidence": sum(
                    1 for p in (draft.get("discussion") or []) if p.get("claim_ids")),
                "tables": len(tables)}
    base_payload = K.base_envelope(index.get("case_id", ""), status, errors, degradations)
    base_payload.update({
        "deliverable": FILES["results_discussion"],
        "deliverable_path": FILES["results_discussion"],
        "results_discussion": deliverables.get("results_discussion", ""),
        "extracted_data": deliverables.get("extracted_data", ""),
        "evidence_map": evidence_map,
        "claim_strength": deliverables.get("claim_strength", ""),
        "results": results, "data_rows": rows,
        "discussion": draft.get("discussion") or [],
        "limitations": draft.get("limitations") or [],
        "preserved_facts": facts, "change_log": change_log,
        "claims": claims, "coverage": coverage,
        "manuscript": body,
        "result": {"deliverables": deliverables, "counts": counts, "coverage": coverage,
                   "tables": [{"table_id": t["table_id"], "locator": t["locator"],
                               "rows": len(t["rows"])} for t in tables],
                   "gaps": draft.get("gaps") or []},
        "sources": K.sources_from(index),
        "pending_human": draft.get("pending_human") or [],
        "uncertainty": draft.get("uncertainties") or [],
        "uncertainties": draft.get("uncertainties") or [],
        "self_check": {"passed": report.get("passed"),
                       "fail_count": len(report.get("fails") or []),
                       "counts": report.get("counts")},
        "changes": [{"type": "build", "detail": "wrote %d deliverable(s)" % len(deliverables)}],
        "deliverables": deliverables,
        "skill": {"name": NAME, "version": VERSION},
        "_artifact_map": ARTIFACT_MAP,
    })
    final = K.finalize_result(out, base_payload, case.get("output_contract"),
                              index.get("case_id"))
    print(json.dumps({"ok": True, "command": "build", "status": status,
                      "case_id": final.get("case_id"), "deliverables": deliverables,
                      "counts": counts, "check_passed": report.get("passed"),
                      "check_fails": report.get("fails"), "errors": errors,
                      "degradations": degradations}, ensure_ascii=False, indent=2))
    return 0


# ------------------------------------------------------------------ cli
def main(argv):
    def sub(fn, helptext, options=None):
        return {"run": fn, "help": helptext, "options": options or {}}

    handlers = {
        "init": sub(cmd_init, "index materials and write a partial result.json"),
        "show": sub(cmd_show, "print material segments with locators",
                    {"--material": {"default": None, "help": "material id"},
                     "--grep": {"default": None, "help": "regex filter"},
                     "--limit": {"type": int, "default": 0, "help": "max segments"}}),
        "tables": sub(cmd_tables, "print parsed input tables",
                      {"--table": {"default": None, "help": "table id"}}),
        "extract": sub(cmd_extract, "harvest candidate numbers and tables"),
        "check": sub(cmd_check, "validate work/draft.json against the materials",
                     {"--draft": {"default": None, "help": "draft path"}}),
        "build": sub(cmd_build, "render Results/Discussion, data csv, evidence map, strength",
                     {"--draft": {"default": None, "help": "draft path"}}),
    }
    return K.run_cli(NAME, handlers, argv,
                     "Results & Discussion writer. Flow: init -> show -> write work/draft.json "
                     "-> check -> build.")


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except Exception:
        import traceback
        try:
            sys.stderr.write(traceback.format_exc())
        except Exception:
            pass
    sys.exit(0)

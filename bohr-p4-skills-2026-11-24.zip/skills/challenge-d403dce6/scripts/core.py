#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared runtime core for the Period-3 weekly-skill packages (unit C).

Pure standard library, no network, CWD-independent, exit code always 0.
Responsibilities:
  * load/scan the runtime case (case.json + /input materials of any common format)
  * give every paragraph a stable locator and dump it for the agent to read
  * harvest candidate numbers / units / DOIs / citations for fact preservation
  * verify verbatim quotes against the material corpus
  * fill every output_contract key (recursively, exact-key first) and finalize result.json
  * never crash: on any exception an honest partial result is written.

The task-specific main.py supplies the deliverable renderers and checks; this module
only provides the mechanical, reusable half.
"""
import hashlib
import json
import os
import re
import sys
import traceback
import unicodedata
import zipfile
import zlib
from pathlib import Path

VERSION = "1.0.0"
MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_FILES = 400
SKIP_NAMES = {"case.json", "task.md", "config.json", "environment/resources.yaml",
              ".gitignore", ".ds_store", "thumbs.db"}
SKIP_DIRS = {"__pycache__", ".git", ".svn", "node_modules"}
TEXT_EXTS = {".md", ".markdown", ".txt", ".json", ".jsonl", ".csv", ".tsv", ".tex", ".bib",
             ".py", ".yaml", ".yml", ".html", ".htm", ".xml", ".r", ".m", ".java", ".c",
             ".cpp", ".js", ".log"}
ZIP_EXTS = {".docx", ".xlsx", ".pptx", ".odt"}
QUOTE_KEYS = {"quote", "original_quote", "source_quote", "claim_quote", "evidence_quote",
              "verbatim", "quote_text", "source_text", "sentence"}
UNIT_RE = (r"(?:wt%|mol%|at%|vol%|ppm|ppb|kDa|Da|kbps|bps|GPa|MPa|kPa|Pa|kV|mV|V|"
           r"kHz|MHz|GHz|Hz|kA|mA|uA|\u00b5A|\u03bcA|A|kg|mg|ug|\u00b5g|\u03bcg|g|"
           r"km|cm|mm|um|\u00b5m|\u03bcm|nm|pm|mL|ml|uL|\u00b5L|\u03bcL|L|"
           r"min|ms|ns|ps|h|s|K|\u00b0C|%|M|mM|uM|\u00b5M|\u03bcM|nM|pM|"
           r"mol|mmol|umol|\u00b5mol|\u03bcmol|nmol|M\u207b\u00b9|mg/L|g/L|"
           r"J|kJ|MJ|eV|keV|MeV|W|kW|mW|dB|rpm|g/cm3|kg/m3|mg/kg|mL/min)")
NUM_RE = re.compile(r"(?<![\w.])[-+]?\d+(?:[.,]\d+)?(?:\s*[-\u2013\u2014]\s*\d+(?:\.\d+)?)?"
                    r"(?:\s*(?:" + UNIT_RE + r"))?(?![\w])")
DOI_RE = re.compile(r"\b10\.\d{4,9}/[^\s\"'<>\u3000]+")
YEAR_RE = re.compile(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)")
CITE_RE = re.compile(r"\[\s*\d+(?:\s*[,\-\u2013]\s*\d+)*\s*\]")
REF_RE = re.compile(r"\b(?:Fig(?:ure)?\.?|Table|Tab\.)\s*(\d+[a-zA-Z]?)\b")
HEAD_RE = re.compile(r"^\s*(?:#{1,6}\s+\S|(?:\d+(?:\.\d+)*)[.)]?\s+[A-Z\u4e00-\u9fff]|"
                     r"[A-Z][A-Z0-9 ,&/:\-]{3,80}$)")


# --------------------------------------------------------------------- io helpers
def jload(path, default=None):
    try:
        with open(path, "r", encoding="utf-8-sig") as fh:
            return json.load(fh)
    except Exception:
        return default


def jdump(path, obj):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    return str(p)


def sha256_bytes(data):
    try:
        return hashlib.sha256(data).hexdigest()
    except Exception:
        return ""


def norm_text(value):
    if value is None:
        return ""
    text = unicodedata.normalize("NFKC", str(value))
    text = text.replace("\u00a0", " ").replace("\r\n", "\n").replace("\r", "\n")
    return re.sub(r"[ \t]+", " ", text).strip()


def skeleton(value):
    """Punctuation-insensitive skeleton used as a *fallback* quote match."""
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    return re.sub(r"[\W_]+", "", text, flags=re.UNICODE)


def norm_key(value):
    return re.sub(r"[^a-z0-9]+", "", str(value or "").lower())


def clip(text, limit=160):
    text = norm_text(text).replace("\n", " ")
    return text if len(text) <= limit else text[: limit - 1] + "\u2026"


# --------------------------------------------------------------------- text extract
def _pdf_unescape(raw):
    out = []
    i = 0
    while i < len(raw):
        ch = raw[i]
        if ch != "\\":
            out.append(ch)
            i += 1
            continue
        i += 1
        if i >= len(raw):
            break
        esc = raw[i]
        if esc in "nrtbf":
            out.append({"n": "\n", "r": "\r", "t": "\t", "b": "\b", "f": "\f"}[esc])
            i += 1
        elif esc in "()\\":
            out.append(esc)
            i += 1
        elif esc.isdigit():
            octal = esc
            i += 1
            while i < len(raw) and raw[i].isdigit() and len(octal) < 3:
                octal += raw[i]
                i += 1
            try:
                out.append(chr(int(octal, 8)))
            except Exception:
                pass
        else:
            i += 1
    return "".join(out)


def pdf_text(data):
    """Best-effort text layer extraction. Returns (text, note)."""
    chunks = []
    try:
        for match in re.finditer(rb"stream\r?\n(.{0,4000000}?)\r?\nendstream", data, re.S):
            raw = match.group(1)
            blob = None
            for candidate in (raw,):
                try:
                    blob = zlib.decompress(candidate)
                    break
                except Exception:
                    continue
            if blob is None:
                blob = raw
            try:
                text = blob.decode("latin-1", "ignore")
            except Exception:
                continue
            if "Tj" not in text and "TJ" not in text:
                continue
            parts = []
            for tj in re.finditer(r"\((?:[^()\\]|\\.)*\)", text):
                parts.append(_pdf_unescape(tj.group(0)[1:-1]))
            for tj in re.finditer(r"\[(.*?)\]\s*TJ", text, re.S):
                parts.append("".join(_pdf_unescape(x) for x in
                                     re.findall(r"\((?:[^()\\]|\\.)*\)", tj.group(1))))
            if parts:
                chunks.append(" ".join(parts))
    except Exception:
        pass
    text = norm_text("\n\n".join(chunks))
    if len(text) < 40:
        return "", "PDF text layer not extractable with stdlib parser"
    return text, "PDF text extracted from content streams (best effort)"


def zip_text(path):
    """Extract readable text from docx/xlsx/pptx via their XML parts."""
    parts = []
    note = ""
    try:
        with zipfile.ZipFile(path) as zf:
            names = zf.namelist()
            order = []
            for name in names:
                low = name.lower()
                if low.startswith("word/document") or low.startswith("word/footnotes") \
                        or low.startswith("word/endnotes") or low.startswith("ppt/slides/slide") \
                        or low.startswith("ppt/notesSlides/") or low.startswith("xl/sharedStrings") \
                        or re.match(r"xl/worksheets/sheet\d+\.xml$", low):
                    order.append(name)
            order.sort()
            for name in order:
                try:
                    xml = zf.read(name).decode("utf-8", "ignore")
                except Exception:
                    continue
                if "sharedStrings" in name.lower():
                    pieces = re.findall(r"<t[^>]*>(.*?)</t>", xml, re.S)
                    if pieces:
                        parts.append(" | ".join(pieces))
                    continue
                xml = re.sub(r"</w:p>|</a:p>|</w:tr>|</row>", "\n", xml)
                xml = re.sub(r"</w:tc>|</c>", " | ", xml)
                pieces = re.findall(r"<(?:w:)?t[^>]*>(.*?)</(?:w:)?t>", xml, re.S)
                if pieces:
                    line = "".join(pieces)
                    line = re.sub(r"\s+", " ", line).strip()
                    if line:
                        parts.append(line)
    except Exception as exc:
        note = "zip container read failed: %s" % exc
    text = norm_text("\n".join(parts))
    if not text and not note:
        note = "no readable text in office container"
    return text, note


def html_text(text):
    text = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", text, flags=re.S | re.I)
    text = re.sub(r"</(?:p|div|h[1-6]|li|tr|br)>", "\n", text, flags=re.I)
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = (text.replace("&nbsp;", " ").replace("&amp;", "&")
            .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"'))
    return norm_text(text)


def read_text_file(path):
    """Returns (text, kind, note_list). Never raises."""
    p = Path(path)
    notes = []
    try:
        if p.stat().st_size > MAX_FILE_BYTES:
            notes.append("file exceeds 2MB read cap; truncated")
        ext = p.suffix.lower()
        if ext == ".pdf":
            raw = p.read_bytes()[:MAX_FILE_BYTES]
            text, note = pdf_text(raw)
            if note:
                notes.append(note)
            return text, "pdf", notes
        if ext in ZIP_EXTS:
            text, note = zip_text(p)
            if note:
                notes.append(note)
            return text, ext.lstrip("."), notes
        if ext in (".html", ".htm"):
            text = html_text(p.read_text(encoding="utf-8", errors="replace"))
            return text, "html", notes
        raw = p.read_text(encoding="utf-8-sig", errors="replace")
        if ext in (".json", ".jsonl"):
            try:
                obj = json.loads(raw)
                text = json.dumps(obj, ensure_ascii=False, indent=1)
            except Exception:
                text = raw
            return text, "json", notes
        return raw, ext.lstrip(".") or "text", notes
    except Exception as exc:
        return "", p.suffix.lower().lstrip(".") or "unknown", ["read failed: %s" % exc]


# --------------------------------------------------------------------- discovery
def discover(input_dir):
    """Scan the input dir and return (materials, notes). Material text stays in '_text'."""
    base = Path(input_dir)
    materials, notes = [], []
    if not base.exists():
        return [], ["input directory does not exist: %s" % base]
    if not base.is_dir():
        return [], ["input path is not a directory: %s" % base]
    try:
        files = [p for p in base.rglob("*") if p.is_file()]
    except Exception as exc:
        return [], ["input scan failed: %s" % exc]
    files.sort(key=lambda p: str(p.relative_to(base)).lower())
    ordered = []
    for p in files:
        rel = p.relative_to(base).as_posix()
        low = rel.lower()
        if any(seg in low.split("/") for seg in SKIP_DIRS):
            continue
        if p.name.lower() in SKIP_NAMES:
            continue
        if low.startswith("environment/"):
            continue
        ordered.append(p)
    if len(ordered) > MAX_FILES:
        notes.append("input file cap reached: kept %d of %d files" % (MAX_FILES, len(ordered)))
        ordered = ordered[:MAX_FILES]
    for idx, p in enumerate(ordered):
        rel = p.relative_to(base).as_posix()
        try:
            size = p.stat().st_size
        except Exception:
            size = 0
        if size == 0:
            materials.append({"material_id": "m%d" % (idx + 1), "path": rel,
                              "name": p.name, "kind": "empty", "bytes": 0,
                              "sha256": "", "text_chars": 0,
                              "notes": ["empty file (0 bytes)"], "_text": ""})
            continue
        raw = b""
        try:
            with open(p, "rb") as fh:
                raw = fh.read(min(size, MAX_FILE_BYTES))
        except Exception:
            pass
        text, kind, file_notes = read_text_file(p)
        mat = {"material_id": "m%d" % (idx + 1), "path": rel, "name": p.name,
               "kind": kind, "bytes": size, "sha256": sha256_bytes(raw),
               "text_chars": len(text), "notes": file_notes, "_text": text}
        materials.append(mat)
    if not materials:
        notes.append("no material files found under input dir (case.json/task.md excluded)")
    return materials, notes


# --------------------------------------------------------------------- segmentation
def segment_document(text, material):
    """Split a material's text into stable, locator-tagged paragraphs."""
    segs = []
    text = norm_text(text)
    if not text:
        return segs
    pages = text.split("\f")
    seq = 0
    for page_no, page in enumerate(pages, start=1):
        blocks = re.split(r"\n\s*\n", page)
        for block in blocks:
            block = block.strip("\n")
            if not block.strip():
                continue
            lines = [ln.rstrip() for ln in block.split("\n")]
            # a markdown heading always starts its own segment
            head_lines = [ln for ln in lines if HEAD_RE.match(ln)]
            body_lines = [ln for ln in lines if not HEAD_RE.match(ln)]
            pieces = []
            if head_lines and body_lines:
                pieces.append(("heading", head_lines[0], 1))
                pieces.append(("para", "\n".join(body_lines), max(1, len(lines) - 1)))
            elif head_lines and len(head_lines) == len(lines):
                pieces.append(("heading", "\n".join(head_lines), len(lines)))
            else:
                kind = "table" if any("|" in ln for ln in lines) else "para"
                pieces.append((kind, block, len(lines)))
            for kind, body, nlines in pieces:
                body = body.strip()
                if not body:
                    continue
                seq += 1
                locator = ("p.%d#para%d" % (page_no, seq)) if len(pages) > 1 \
                    else ("para.%d" % seq)
                segs.append({"locator": locator, "text": body, "kind": kind,
                             "lines": nlines, "page": page_no})
    return segs


def paragraphs(text, material_id, kind_hint=""):
    return segment_document(text, {"material_id": material_id, "kind": kind_hint})


# --------------------------------------------------------------------- harvesting
TERM_BRIDGE = {
    "cycling": "\u5faa\u73af", "\u5faa\u73af": "cycling",
    "photocatalysis": "\u5149\u50ac\u5316", "\u5149\u50ac\u5316": "photocatalysis",
    "photocatalyst": "\u5149\u50ac\u5316\u5242", "\u5149\u50ac\u5316\u5242": "photocatalyst",
    "yield": "\u4ea7\u7387", "\u4ea7\u7387": "yield",
    "overpotential": "\u8fc7\u7535\u4f4d", "\u8fc7\u7535\u4f4d": "overpotential",
    "current density": "\u7535\u6d41\u5bc6\u5ea6", "\u7535\u6d41\u5bc6\u5ea6": "current density",
    "specific capacity": "\u6bd4\u5bb9\u91cf", "\u6bd4\u5bb9\u91cf": "specific capacity",
    "selectivity": "\u9009\u62e9\u6027", "\u9009\u62e9\u6027": "selectivity",
    "conversion": "\u8f6c\u5316\u7387", "\u8f6c\u5316\u7387": "conversion",
    "stability": "\u7a33\u5b9a\u6027", "\u7a33\u5b9a\u6027": "stability",
    "annealing": "\u9000\u706b", "\u9000\u706b": "annealing",
    "oxygen vacancy": "\u6c27\u7a7a\u4f4d", "\u6c27\u7a7a\u4f4d": "oxygen vacancy",
    "electrocatalyst": "\u7535\u50ac\u5316\u5242", "\u7535\u50ac\u5316\u5242": "electrocatalyst",
    "nanoparticle": "\u7eb3\u7c73\u9897\u7c92", "\u7eb3\u7c73\u9897\u7c92": "nanoparticle",
    "diffraction": "\u884d\u5c04", "\u884d\u5c04": "diffraction",
    "spectroscopy": "\u5149\u8c31", "\u5149\u8c31": "spectroscopy",
    "sample": "\u6837\u54c1", "\u6837\u54c1": "sample",
    "control": "\u5bf9\u7167", "\u5bf9\u7167": "control",
    "replicate": "\u91cd\u590d", "\u91cd\u590d": "replicate",
}


def bridge_terms(text):
    """Return bilingual term pairs that occur in the text (cross-language bridge)."""
    low = (text or "").lower()
    pairs = []
    seen = set()
    for term, other in TERM_BRIDGE.items():
        if term.lower() in low and (term, other) not in seen:
            seen.add((term, other))
            pairs.append((term, other))
    return pairs


def suggest_glossary(text, limit=40):
    """Candidate glossary rows (source term -> bridged term) found in the text."""
    rows = []
    seen = set()
    for term, other in bridge_terms(text):
        low = (text or "").lower()
        if term.lower() in low:
            key = (term, other)
            if key in seen:
                continue
            seen.add(key)
            rows.append({"source_term": term, "target_term": other,
                         "source": "bridge-candidate",
                         "occurrences": low.count(term.lower())})
        if len(rows) >= limit:
            break
    return rows

def harvest(segments, material_id):
    """Candidate numbers/units/DOIs/years/citations with locator + verbatim quote."""
    out = {"numbers": [], "dois": [], "years": [], "citations": [], "refs": []}
    seen = set()

    def add(bucket, value, seg, extra=None):
        key = (bucket, value, seg["locator"])
        if key in seen:
            return
        seen.add(key)
        item = {"value": value, "unit": (extra or {}).get("unit", ""),
                "material_id": material_id, "locator": seg["locator"],
                "quote": seg["text"][:400],
                "source": (extra or {}).get("source", "")}
        out[bucket].append(item)

    for seg in segments:
        body = seg["text"]
        for match in NUM_RE.finditer(body):
            value = match.group(0).strip()
            if not any(ch.isdigit() for ch in value):
                continue
            unit_match = re.search(UNIT_RE + r"$", value)
            add("numbers", value, seg, {"unit": unit_match.group(0) if unit_match else ""})
        for match in DOI_RE.finditer(body):
            add("dois", match.group(0).rstrip(".,;)"), seg)
        for match in YEAR_RE.finditer(body):
            add("years", match.group(1), seg)
        for match in CITE_RE.finditer(body):
            add("citations", match.group(0), seg)
        for match in REF_RE.finditer(body):
            add("refs", match.group(0), seg)
    return out


# --------------------------------------------------------------------- quote checks
def quote_hit(quote, corpus, corpus_skeleton=None):
    """Return dict(hit, method) for a verbatim quote against the whole corpus."""
    quote = norm_text(quote)
    if not quote:
        return {"hit": False, "method": "empty"}
    if quote in corpus:
        return {"hit": True, "method": "exact"}
    flat = re.sub(r"\s+", " ", quote)
    if flat in re.sub(r"[ \t]+", " ", corpus):
        return {"hit": True, "method": "whitespace-normalized"}
    for fragment in re.split(r"(?:\u2026|\.\.\.)", quote):
        fragment = fragment.strip()
        if len(fragment) >= 8 and fragment not in corpus:
            return {"hit": False, "method": "fragment-miss"}
    if "..." in quote or "\u2026" in quote:
        return {"hit": True, "method": "ellipsis-fragments"}
    sk = skeleton(quote)
    if corpus_skeleton is None:
        corpus_skeleton = skeleton(corpus)
    if len(sk) >= 12 and sk in corpus_skeleton:
        return {"hit": True, "method": "punctuation-insensitive"}
    return {"hit": False, "method": "miss"}


def iter_quotes(node, path="$", inherited_source="", found=None):
    """Collect (jsonpath, quote, source_hint) for every quote-like key."""
    if found is None:
        found = []
    if isinstance(node, dict):
        source = str(node.get("source_id") or node.get("source") or node.get("material_id")
                     or inherited_source or "")
        for key, value in node.items():
            child = "%s.%s" % (path, key)
            if isinstance(value, str) and key.lower() in QUOTE_KEYS and len(value.strip()) >= 8:
                found.append((child, value, str(node.get("locator") or node.get("source_id")
                                                or inherited_source or "")))
            elif isinstance(value, (dict, list)):
                iter_quotes(value, child, source, found)
    elif isinstance(node, list):
        for idx, item in enumerate(node):
            iter_quotes(item, "%s[%d]" % (path, idx), inherited_source, found)
    return found


# --------------------------------------------------------------------- contract echo
MISSING = object()


def _resolve_key(key, base, artifact_map, root):
    if not isinstance(base, dict):
        base = {}
    if key in base:
        return base[key]
    nk = norm_key(key)
    for bk in base:
        if norm_key(bk) == nk:
            return base[bk]
    if artifact_map and nk in {norm_key(k): v for k, v in artifact_map.items()}:
        target = {norm_key(k): v for k, v in artifact_map.items()}[nk]
        if target in (base.get("deliverables") or {}).values():
            return target
        if target in (root.get("deliverables") or {}).values():
            return target
    result = base.get("result")
    if isinstance(result, dict):
        if key in result:
            return result[key]
        for rk in result:
            if norm_key(rk) == nk:
                return result[rk]
    root_result = root.get("result")
    if isinstance(root_result, dict) and nk not in {norm_key(k) for k in base}:
        for rk in root_result:
            if norm_key(rk) == nk:
                return root_result[rk]
    if artifact_map:
        for alias, fname in artifact_map.items():
            if norm_key(alias) == nk:
                files = list((root.get("deliverables") or {}).values()) + \
                        list((base.get("deliverables") or {}).values())
                if fname in files:
                    return fname
    return MISSING


def fill_contract(contract, base, artifact_map=None):
    """Recursively fill every contract key. Returns (final_dict, missing_paths)."""
    missing = []
    root = base if isinstance(base, dict) else {}

    def fill(spec, payload, path):
        if isinstance(spec, dict):
            out = {}
            for key, sub in spec.items():
                resolved = _resolve_key(key, payload, artifact_map, root)
                if resolved is MISSING:
                    missing.append((path + "." if path else "") + str(key))
                    if isinstance(sub, dict):
                        out[key] = fill(sub, {}, path + "." + str(key))
                    elif isinstance(sub, list):
                        out[key] = []
                    else:
                        out[key] = None
                else:
                    if isinstance(sub, (dict, list)):
                        out[key] = fill(sub, resolved, path + "." + str(key))
                    else:
                        out[key] = resolved
            return out
        if isinstance(spec, list):
            if isinstance(payload, list):
                if spec and isinstance(spec[0], dict) and payload \
                        and isinstance(payload[0], dict):
                    return [fill(spec[0], item, path + "[]") for item in payload]
                return payload
            if isinstance(payload, dict) and spec:
                return [payload]
            return []
        if payload is MISSING or payload is None:
            return None
        return payload

    if isinstance(contract, dict):
        final = fill(contract, root, "")
    elif isinstance(contract, list):
        keys = []
        for item in contract:
            if isinstance(item, dict):
                for candidate in ("name", "field", "key", "id"):
                    if isinstance(item.get(candidate), str):
                        keys.append(item[candidate])
                        break
        final = fill({k: None for k in keys}, root, "")
    else:
        final = {}
    for key, value in root.items():
        if not str(key).startswith("_"):
            final[key] = value
    return final, missing


def contract_keys(contract):
    if isinstance(contract, dict):
        return list(contract.keys())
    if isinstance(contract, list):
        keys = []
        for item in contract:
            if isinstance(item, dict):
                for candidate in ("name", "field", "key", "id"):
                    if isinstance(item.get(candidate), str):
                        keys.append(item[candidate])
                        break
        return keys
    return []


# --------------------------------------------------------------------- workorder
WORKORDER_HINTS = ("workorder", "work_order", "work-order", "target", "comment", "request",
                   "requirement", "edit", "instruction", "item", "task", "review")
ID_KEYS = ("target_id", "comment_id", "item_id", "requirement_id", "review_id", "edit_id",
           "request_id", "task_id", "id", "no", "number", "ref", "label", "key")
TEXT_KEYS = ("text", "comment", "instruction", "requirement", "target", "request", "body",
             "content", "description", "summary", "note", "quote", "edit")


def _pick_id(item, idx):
    for key in ID_KEYS:
        for k in item:
            if norm_key(k) == norm_key(key) and isinstance(item[k], (str, int)):
                value = str(item[k]).strip()
                if value:
                    return value
    return "T%d" % idx


def _pick_text(item):
    best = ""
    for key, value in item.items():
        if isinstance(value, str) and norm_key(key) in {norm_key(k) for k in TEXT_KEYS}:
            if len(value) > len(best):
                best = value
    if not best:
        for key, value in item.items():
            if isinstance(value, str) and len(value) > len(best):
                best = value
    return best


def workorder_items(case, materials=None):
    """Best-effort extraction of the explicit required-object list from case/materials."""
    found_lists = []
    def walk(node, path=""):
        if isinstance(node, dict):
            for key, value in node.items():
                low = norm_key(key)
                if isinstance(value, list) and value and isinstance(value[0], dict) \
                        and any(h in low for h in WORKORDER_HINTS):
                    found_lists.append((path + "/" + str(key), value))
                walk(value, path + "/" + str(key))
        elif isinstance(node, list):
            for idx, item in enumerate(node):
                walk(item, "%s[%d]" % (path, idx))

    walk(case)
    if materials:
        for mat in materials:
            name = (mat.get("name") or "").lower()
            text = mat.get("_text") or ""
            if any(h in name for h in ("workorder", "work-order", "comment", "review",
                                       "target", "instruction")):
                try:
                    obj = json.loads(text)
                except Exception:
                    obj = None
                if obj is not None:
                    walk(obj, mat.get("path", "material"))
                else:
                    items = parse_comments(text, mat.get("path", "material"))
                    if items:
                        found_lists.append((mat.get("path", "material"), items))
    items, seen = [], set()
    for source, listing in found_lists:
        if not isinstance(listing, list):
            continue
        for idx, raw in enumerate(listing, start=1):
            if not isinstance(raw, dict):
                continue
            item_id = _pick_id(raw, idx)
            text = _pick_text(raw)
            key = (item_id, clip(text, 80))
            if key in seen:
                continue
            seen.add(key)
            items.append({"item_id": item_id, "text": text, "source": source, "raw": raw,
                          "_structured": ".json" in str(source).lower()})
    # If a structured workorder exists, drop text-parsed duplicates whose numeric part
    # matches a structured target id (e.g. "C1.1" vs parsed "1.1").
    if any(item.get("_structured") for item in items):
        structured = [item for item in items if item.get("_structured")]
        digits = {re.sub(r"[^0-9.]", "", item["item_id"]) for item in structured}
        filtered = []
        for item in items:
            if item.get("_structured"):
                filtered.append(item)
                continue
            if re.sub(r"[^0-9.]", "", item["item_id"]) in digits:
                continue
            filtered.append(item)
        items = filtered
    for item in items:
        item.pop("_structured", None)
    return items


def parse_comments(text, source):
    """Parse numbered reviewer comments / edit targets out of a markdown/text file."""
    items = []
    if not text:
        return items
    lines = norm_text(text).split("\n")
    current = None
    pattern = re.compile(r"^\s*(?:[#>*\-]+\s*)?(?:comment|reviewer|referee|r|q|item|target|"
                         r"\u610f\u89c1|\u6761)\s*[#\uff1a:.]?\s*(\d+(?:\.\d+)*)\s*[).:\uff1a]?\s*(.*)$",
                         re.I)
    for line in lines:
        match = pattern.match(line)
        if match:
            if current:
                items.append(current)
            current = {"item_id": match.group(1), "text": match.group(2).strip(),
                       "source": source, "raw": {"line": line}}
        elif current is not None and line.strip():
            current["text"] = (current["text"] + " " + line.strip()).strip()
    if current:
        items.append(current)
    if not items:
        for idx, line in enumerate([ln for ln in lines if ln.strip()], start=1):
            if len(line.strip()) > 25:
                items.append({"item_id": "L%d" % idx, "text": line.strip(),
                              "source": source, "raw": {"line": line}})
    return items


# --------------------------------------------------------------------- envelope
def sources_from(index):
    return [{k: m.get(k) for k in ("material_id", "path", "kind", "sha256", "bytes",
                                   "text_chars")} for m in (index.get("materials") or [])]


def base_envelope(case_id, status, errors=None, degradations=None):
    return {"case_id": case_id, "status": status,
            "sources": [], "uncertainty": [], "uncertainties": [],
            "pending_human": [], "errors": errors or [],
            "degradations": degradations or [], "changes": [], "runtime": {}}


def finalize_result(output_dir, payload, contract, case_id, emergency=False):
    """Fill the contract, write result.json, and return the written object."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    payload = payload if isinstance(payload, dict) else {}
    payload.setdefault("case_id", case_id or "")
    final, missing = fill_contract(contract, payload,
                                   payload.get("_artifact_map") if isinstance(payload, dict)
                                   else None)
    if missing:
        final.setdefault("degradations", [])
        if isinstance(final.get("degradations"), list):
            final["degradations"].append(
                "output_contract keys with no delivered value: " + ", ".join(missing))
    final.setdefault("case_id", case_id or "")
    try:
        jdump(out / "result.json", final)
    except Exception:
        try:
            jdump(out / "result.json", {"case_id": case_id or "", "status": "partial",
                                        "errors": ["result.json serialization failed"]})
        except Exception:
            pass
    return final


def emergency_finalize(output_dir, case_id, note):
    payload = base_envelope(case_id, "partial",
                            errors=["unhandled exception during run"],
                            degradations=[note])
    payload.update({"deliverable": "", "preserved_facts": [], "evidence_map": [],
                    "change_log": [], "result": {"deliverables": {}, "counts": {}}})
    try:
        finalize_result(output_dir, payload, {}, case_id, emergency=True)
    except Exception:
        pass
    try:
        out = Path(output_dir)
        if not (out / "result.json").exists():
            out.mkdir(parents=True, exist_ok=True)
            with open(out / "result.json", "w", encoding="utf-8") as fh:
                json.dump({"case_id": case_id or "", "status": "partial",
                           "errors": ["unhandled exception during run"]}, fh)
    except Exception:
        pass


# --------------------------------------------------------------------- cli plumbing
IO_DEFAULTS = {"input": os.environ.get("INPUT_DIR", "/input"),
               "work": os.environ.get("WORK_DIR", "/app/work"),
               "output": os.environ.get("OUTPUT_DIR", "/app/output")}


def add_io_options(parser):
    for name in ("input", "work", "output"):
        parser.add_argument("--" + name, default=IO_DEFAULTS[name],
                            help="%s dir (default %s)" % (name, IO_DEFAULTS[name]))


def run_cli(prog, handlers, argv, help_text=""):
    """Parse args, dispatch, and guarantee exit code 0 with a partial result on failure."""
    import argparse
    parser = argparse.ArgumentParser(prog=prog, description=help_text,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    add_io_options(parser)
    parser.add_argument("--version", action="version", version=prog + " " + VERSION)
    sub = parser.add_subparsers(dest="command")
    for name in handlers:
        sub.add_parser(name, help=handlers[name].get("help", name))
        # sub-parsers inherit nothing; allow flags after the command too
        sub.choices[name].add_argument("--input", default=argparse.SUPPRESS)
        sub.choices[name].add_argument("--work", default=argparse.SUPPRESS)
        sub.choices[name].add_argument("--output", default=argparse.SUPPRESS)
        for flag, options in handlers[name].get("options", {}).items():
            sub.choices[name].add_argument(flag, **options)
    try:
        args, _unknown = parser.parse_known_args(argv)
    except SystemExit:
        return 0
    except Exception:
        return 0
    if not args.command:
        try:
            parser.print_help()
        except Exception:
            pass
        return 0
    handler = handlers[args.command]["run"]
    try:
        result = handler(args)
        return 0 if result is None else int(result)
    except Exception:
        try:
            sys.stderr.write(traceback.format_exc())
        except Exception:
            pass
        out = getattr(args, "output", None) or IO_DEFAULTS["output"]
        emergency_finalize(out, "", "unhandled exception in command %r" % args.command)
        return 0

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""grant-proposal -- seven-element research grant proposal writer.

Commands: init | show | extract | check | build
Flow: init -> show (read call + prior work) -> write work/draft.json -> check -> build

Delivers the seven required sections, a goal-workpackage-milestone-metric matrix, planning
units within the stated cap, >=3 risks with alternatives, human-confirmation items and an
evidence map. Existing published results are attributed to their external authors; nothing
is invented as the applicant's preliminary data.
"""
import csv
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import core as K

NAME = "grant-proposal"
VERSION = "1.0.0"
FILES = {
    "proposal": "proposal.md",
    "goal_matrix": "goal_matrix.csv",
    "planning_units": "planning_units.json",
    "risks": "risks.md",
    "evidence_map": "evidence_map.json",
    "content_map": "content_map.json",
    "proposal_html": "proposal.html",
}
SECTION_KEYS = [
    ("background", "\u7acb\u9879\u4f9d\u636e"),
    ("question", "\u79d1\u5b66\u95ee\u9898"),
    ("objectives", "\u7814\u7a76\u76ee\u6807"),
    ("content", "\u7814\u7a76\u5185\u5bb9"),
    ("innovation", "\u521b\u65b0\u70b9"),
    ("route", "\u6280\u672f\u8def\u7ebf"),
    ("feasibility", "\u7814\u7a76\u57fa\u7840\u4e0e\u53ef\u884c\u6027"),
]
RISK_CATS = {"data", "method", "schedule", "ethics"}
FORBIDDEN = ["\u9996\u6b21", "\u56fd\u9645\u9886\u5148", "\u586b\u8865\u7a7a\u767d",
             "first-ever", "world-leading", "fills the gap"]
CJK_RE = re.compile(r"[\u4e00-\u9fff]")
WORD_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_./%\-]*")
ARTIFACT_MAP = {
    "proposal": "proposal.md",
    "goal_matrix": "goal_matrix.csv",
    "goalmatrix": "goal_matrix.csv",
    "planning_units": "planning_units.json",
    "planningunits": "planning_units.json",
    "risks": "risks.md",
    "risk_register": "risks.md",
    "evidence_map": "evidence_map.json",
    "evidencemap": "evidence_map.json",
    "content_map": "content_map.json",
    "contentmap": "content_map.json",
    "proposal_html": "proposal.html",
    "html": "proposal.html",
    "export": "proposal.html",
}


def effective_length(text):
    """Chinese characters count 1 each; non-Chinese word tokens count 1 each."""
    text = str(text or "")
    return len(CJK_RE.findall(text)) + len(WORD_RE.findall(CJK_RE.sub(" ", text)))


def sections_map(draft):
    out = {}
    for section in draft.get("sections") or []:
        key = str(section.get("key") or "").strip().lower()
        if not key:
            heading = str(section.get("heading") or "")
            for k, label in SECTION_KEYS:
                if label and label in heading:
                    key = k
                    break
        out[key] = section
    return out


# ------------------------------------------------------------------ index
def build_index(args):
    case = K.jload(Path(args.input) / "case.json", None)
    case = case if isinstance(case, dict) else {}
    materials, notes = K.discover(args.input)
    work = Path(args.work)
    for mat in materials:
        segments = K.segment_document(mat.get("_text") or "", mat)
        try:
            K.jdump(work / "segments" / (mat["material_id"] + ".json"),
                    {"material_id": mat["material_id"], "path": mat["path"],
                     "segments": segments})
        except Exception:
            notes.append("could not persist segments for %s" % mat.get("path"))
    items = K.workorder_items(case, materials)
    index = {"skill": NAME, "version": VERSION,
             "case_id": str(case.get("case_id") or case.get("id") or ""),
             "materials": [{k: v for k, v in m.items() if not k.startswith("_")}
                           for m in materials],
             "workorder": [{"item_id": i["item_id"], "text": i["text"], "source": i["source"]}
                           for i in items],
             "counts": {"materials": len(materials), "workorder_items": len(items)},
             "notes": notes,
             "required_sections": [label for _k, label in SECTION_KEYS]}
    K.jdump(work / "index.json", index)
    return case, materials, index, notes


def partial_payload(index, notes):
    payload = K.base_envelope(index.get("case_id", ""), "partial",
                              degradations=list(notes) + ["partial scaffold written by init; "
                                                          "work/draft.json not yet built"])
    payload.update({"deliverable": "", "preserved_facts": [], "evidence_map": [],
                    "change_log": [], "claims": [], "coverage": {},
                    "sections": [], "goals": [], "workpackages": [], "planning_units": [],
                    "risks": [], "workorder_execution": [],
                    "result": {"deliverables": {}, "counts": {},
                               "required_sections": index.get("required_sections")},
                    "sources": K.sources_from(index),
                    "skill": {"name": NAME, "version": VERSION}})
    return payload


def cmd_init(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    case, materials, index, notes = build_index(args)
    status = "input_error" if not materials else "partial"
    payload = partial_payload(index, notes)
    payload["status"] = status
    if not materials:
        payload["errors"].append("no input materials discovered")
    K.finalize_result(out, payload, case.get("output_contract"), index.get("case_id"))
    print(json.dumps({"ok": True, "command": "init", "case_id": index["case_id"],
                      "status": status,
                      "required_sections": index.get("required_sections"),
                      "workorder": index.get("workorder"),
                      "materials": [{"material_id": m["material_id"], "path": m["path"],
                                     "kind": m["kind"], "text_chars": m["text_chars"]}
                                    for m in materials],
                      "next": "show --material mN, read call + prior work, write "
                              "work/draft.json, then check and build"}, ensure_ascii=False,
                     indent=2))
    return 0


def cmd_show(args):
    work = Path(args.work)
    index = K.jload(work / "index.json", {}) or {}
    if not args.material:
        print(json.dumps({"case_id": index.get("case_id"),
                          "required_sections": index.get("required_sections"),
                          "workorder": index.get("workorder"),
                          "materials": [{k: m.get(k) for k in ("material_id", "path", "kind",
                                                               "bytes", "text_chars", "notes")}
                                        for m in index.get("materials", [])]},
                         ensure_ascii=False, indent=2))
        return 0
    target = next((m for m in index.get("materials", [])
                   if m.get("material_id") == args.material), None)
    if not target:
        print(json.dumps({"error": "unknown material: %s" % args.material}, ensure_ascii=False))
        return 0
    segments = (K.jload(work / "segments" / (args.material + ".json"), {}) or {}).get(
        "segments") or []
    shown = 0
    for seg in segments:
        if args.grep and not re.search(args.grep, seg.get("text", ""), re.I):
            continue
        print("=== [%s] %s" % (seg.get("locator"), target.get("path")))
        print(seg.get("text"))
        print()
        shown += 1
        if args.limit and shown >= args.limit:
            break
    if shown == 0:
        print(json.dumps({"material_id": args.material, "path": target.get("path"),
                          "segments": 0, "notes": target.get("notes")}, ensure_ascii=False))
    return 0


def cmd_extract(args):
    work = Path(args.work)
    index = K.jload(work / "index.json", {}) or {}
    harvest = {"numbers": [], "dois": [], "years": [], "citations": []}
    for mat in index.get("materials") or []:
        segments = (K.jload(work / "segments" / (mat["material_id"] + ".json"), {}) or {}).get(
            "segments") or []
        for key, values in K.harvest(segments, mat["material_id"]).items():
            harvest.setdefault(key, []).extend(values)
    K.jdump(work / "candidates.json", harvest)
    print(json.dumps({"ok": True, "command": "extract",
                      "saved_to": str(work / "candidates.json"),
                      "counts": {k: len(v) for k, v in harvest.items()},
                      "note": "candidates only; promote used facts into draft.preserved_facts "
                              "with a verbatim quote"}, ensure_ascii=False, indent=2))
    return 0


# ------------------------------------------------------------------ checks
def load_draft(args):
    path = Path(args.draft) if getattr(args, "draft", None) else Path(args.work) / "draft.json"
    draft = K.jload(path, None)
    return (draft if isinstance(draft, dict) else None), str(path)


def load_corpus(work, index):
    parts = []
    for mat in index.get("materials") or []:
        segments = (K.jload(Path(work) / "segments" / (mat["material_id"] + ".json"),
                            {}) or {}).get("segments") or []
        parts.extend(s.get("text", "") for s in segments)
    return K.norm_text("\n".join(parts))


def run_checks(args, index, draft):
    corpus = load_corpus(args.work, index)
    fails, warnings = [], []
    counts = {"sections": 0, "chars": 0, "goals": 0, "matrix_rows": 0, "workpackages": 0,
              "planning_units_total": 0, "risks": 0, "human_confirmations": 0,
              "facts": 0, "evidence": 0}
    if draft is None:
        fails.append({"code": "draft_missing", "message": "work/draft.json not found"})
        return {"passed": False, "fails": fails, "warnings": warnings, "counts": counts}

    def fail(code, message):
        fails.append({"code": code, "message": message})

    smap = sections_map(draft)
    joined = []
    for key, label in SECTION_KEYS:
        section = smap.get(key)
        content = str(section.get("content") or "").strip() if section else ""
        if not content:
            fail("section_missing", "required section %r is empty/missing" % label)
        else:
            joined.append(content)
    counts["sections"] = sum(1 for key, _l in SECTION_KEYS
                             if str((smap.get(key) or {}).get("content") or "").strip())
    body = "\n".join(joined)
    counts["chars"] = effective_length(body)
    if not (1600 <= counts["chars"] <= 2600):
        fail("length", "seven-section body is %d effective units, outside 1600-2600"
             % counts["chars"])
    goals = draft.get("goals") or []
    counts["goals"] = len(goals)
    if len(goals) != 3:
        fail("goals", "expected exactly 3 goals, found %d" % len(goals))
    wp_ids = {str(w.get("wp_id")) for w in draft.get("workpackages") or []}
    counts["workpackages"] = len(wp_ids)
    for goal in goals:
        gid = goal.get("goal_id")
        for field in ("objective", "metric", "workpackage", "milestone", "timepoint"):
            if not str(goal.get(field) or "").strip():
                fail("goal_field", "%s lacks %s" % (gid, field))
        if str(goal.get("workpackage") or "") not in wp_ids:
            fail("goal_wp", "%s points to unknown workpackage %r"
                 % (gid, goal.get("workpackage")))
    matrix = draft.get("goal_matrix") or []
    counts["matrix_rows"] = len(matrix)
    for goal in goals:
        if not any(str(row.get("goal_id")) == str(goal.get("goal_id")) for row in matrix):
            fail("matrix_goal", "goal %s has no matrix row" % goal.get("goal_id"))
    units = draft.get("planning_units") or []
    total = 0
    for unit in units:
        try:
            total += int(unit.get("units") or 0)
        except Exception:
            fail("unit_value", "planning unit %r has a non-numeric value"
                 % unit.get("unit_id"))
        if not str(unit.get("basis") or "").strip():
            warnings.append("planning unit %r has no basis" % unit.get("unit_id"))
    counts["planning_units_total"] = total
    if not units or total <= 0:
        fail("planning_units", "no planning units supplied")
    if total > 100:
        fail("planning_units_cap", "planning units total %d exceeds the cap of 100" % total)
    risks = draft.get("risks") or []
    counts["risks"] = len(risks)
    if len(risks) < 3:
        fail("risks", "fewer than 3 risks")
    covered = set()
    for risk in risks:
        cat = str(risk.get("category") or "").lower()
        if cat in RISK_CATS:
            covered.add(cat)
        for field in ("trigger_signal", "impact", "alternative", "decision_point"):
            if not str(risk.get(field) or "").strip():
                fail("risk_field", "risk %s lacks %s" % (risk.get("risk_id"), field))
    if len(covered) < 3:
        warnings.append("risks cover only %d of 4 categories" % len(covered))
    if len(draft.get("human_confirmations") or []) < 2:
        fail("human_confirmations", "fewer than 2 human-confirmation items")
    counts["human_confirmations"] = len(draft.get("human_confirmations") or [])
    for phrase in FORBIDDEN:
        if phrase in body:
            if not draft.get("support_for_novelty"):
                fail("unsupported_novelty", "unsupported novelty claim %r without evidence"
                     % phrase)
    for fact in draft.get("preserved_facts") or []:
        counts["facts"] += 1
        if not K.quote_hit(fact.get("quote"), corpus)["hit"]:
            fail("fact_quote", "%s quote not verbatim" % fact.get("fact_id"))
    for ev in draft.get("evidence_map") or []:
        counts["evidence"] += 1
        if not K.quote_hit(ev.get("quote"), corpus)["hit"]:
            fail("evidence_quote", "%s quote not verbatim" % ev.get("claim_id"))
    external = draft.get("external_attribution") or []
    for item in external:
        if not str(item.get("source") or "").strip():
            warnings.append("external result attribution without source")
    return {"passed": not fails, "fails": fails, "warnings": warnings, "counts": counts}


def print_report(report):
    print(json.dumps({"passed": report["passed"], "fail_count": len(report["fails"]),
                      "warning_count": len(report["warnings"]),
                      "counts": report.get("counts"), "fails": report["fails"],
                      "warnings": report["warnings"]}, ensure_ascii=False, indent=2))


def cmd_check(args):
    work = Path(args.work)
    index = K.jload(work / "index.json", {}) or {}
    if not index:
        index = {"materials": [], "workorder": [], "case_id": ""}
    draft, path = load_draft(args)
    report = run_checks(args, index, draft)
    report["draft_path"] = path
    K.jdump(work / "check_report.json", report)
    print_report(report)
    return 0


# ------------------------------------------------------------------ renderers
def render_proposal(draft, index):
    lines = ["# %s" % (draft.get("title") or "Research Grant Proposal"), ""]
    smap = sections_map(draft)
    for idx, (key, label) in enumerate(SECTION_KEYS, start=1):
        section = smap.get(key) or {}
        content = str(section.get("content") or "").strip()
        lines += ["## %d. %s" % (idx, label), ""]
        lines += [content if content else
                  "_\u672c\u8282\u672a\u63d0\u4f9b\u5185\u5bb9\uff1b\u89c1 result.json "
                  "\u7684 gaps\u3002_", ""]
    lines += ["## \u9644\uff1a\u76ee\u6807\u2014\u5de5\u4f5c\u5305\u2014\u91cc\u7a0b\u7891"
              "\u2014\u6307\u6807\u77e9\u9635", "",
              "| goal | objective | workpackage | milestone | metric | threshold | timepoint |",
              "|---|---|---|---|---|---|---|"]
    for row in draft.get("goal_matrix") or []:
        lines.append("| %s | %s | %s | %s | %s | %s | %s |" % (
            row.get("goal_id", ""), K.clip(row.get("objective", ""), 60),
            row.get("workpackage", ""), row.get("milestone", ""),
            K.clip(row.get("metric", ""), 50), row.get("threshold", ""),
            row.get("timepoint", "")))
    lines += ["", "## \u9644\uff1a\u4eba\u5de5\u786e\u8ba4\u9879", ""]
    for item in draft.get("human_confirmations") or []:
        lines.append("- %s \u2014 %s" % (item.get("item", ""), item.get("why", "")))
    lines += ["", "## \u9644\uff1a\u5df2\u53d1\u8868\u7ed3\u679c\u7684\u5f52\u5c5e", ""]
    for item in draft.get("external_attribution") or []:
        lines.append("- %s\uff08\u6765\u6e90\uff1a%s\uff09" % (item.get("claim", ""),
                                                              item.get("source", "")))
    if not (draft.get("external_attribution") or []):
        lines.append("- \u672a\u5f15\u7528\u5916\u90e8\u5df2\u53d1\u8868\u7ed3\u679c\u3002")
    lines.append("")
    return "\n".join(lines)


def render_risks(draft):
    lines = ["# Risk register", "",
             "| id | category | trigger signal | impact | alternative | decision point |",
             "|---|---|---|---|---|---|"]
    for risk in draft.get("risks") or []:
        lines.append("| %s | %s | %s | %s | %s | %s |" % (
            risk.get("risk_id", ""), risk.get("category", ""),
            K.clip(risk.get("trigger_signal", ""), 70), K.clip(risk.get("impact", ""), 60),
            K.clip(risk.get("alternative", ""), 80), K.clip(risk.get("decision_point", ""), 60)))
    lines += ["", "Categories covered: data / method / schedule / ethics. Each risk has a "
                  "trigger signal, an impact, a concrete alternative and the decision point "
                  "at which the alternative is adopted.", ""]
    return "\n".join(lines)


# ------------------------------------------------------------------ content map
PROPOSED_HINTS = ("\u62df\u5f00\u5c55", "\u62df\u91c7\u7528", "\u62df\u56de\u7b54",
                  "\u62df\u5efa\u7acb", "\u8ba1\u5212", "\u5c06\u5f00\u5c55", "\u5c06\u5b9e\u73b0",
                  "\u5c06\u4e8e", "\u5c1a\u672a", "\u5f85\u5b9e\u65bd", "\u6b63\u5728\u8bbe\u8ba1",
                  "\u9884\u5b9e\u9a8c\u65b9\u6848", "\u672a\u83b7\u5f97", "\u672a\u5b9e\u65bd")
COMPLETED_HINTS = ("\u62a5\u9053", "\u89c2\u5bdf\u5230", "\u8bc1\u660e", "\u53d1\u8868",
                   "\u5b9e\u73b0\u4e86", "\u6d4b\u5f97", "\u5df2\u62a5\u9053", "\u5df2\u53d1\u8868",
                   "\u5df2\u89c2\u5bdf", "\u5df2\u5b8c\u6210", "\u89c4\u5b9a")


def claim_status(claim, default="\u5df2\u5b8c\u6210"):
    """Classify a claim as 已完成 (source-backed fact) vs 拟开展 (proposed plan)."""
    explicit = str(claim.get("status") or claim.get("tense") or "").strip()
    if explicit:
        return explicit
    text = str(claim.get("claim") or "") + " " + str(claim.get("quote") or "")
    if any(h in text for h in PROPOSED_HINTS):
        return "\u62df\u5f00\u5c55"
    if any(h in text for h in COMPLETED_HINTS):
        return "\u5df2\u5b8c\u6210"
    return default


def claim_section(claim, smap):
    """Best-effort: map a claim to the section whose body mentions its distinctive text."""
    section = str(claim.get("section") or claim.get("element") or "").strip().lower()
    if section:
        for key, _label in SECTION_KEYS:
            if key == section or key in section or section in key:
                return key
    probe = K.skeleton(str(claim.get("claim") or ""))
    if len(probe) < 6:
        return ""
    for key, _label in SECTION_KEYS:
        body = K.skeleton(str((smap.get(key) or {}).get("content") or ""))
        if probe[:18] in body:
            return key
    return ""


def render_html(draft, index, sections_out, matrix, human, attribution):
    """Self-contained UTF-8 HTML preview (a real rendered export of the editable source)."""
    esc = (lambda s: (str(s or "").replace("&", "&amp;").replace("<", "&lt;")
                      .replace(">", "&gt;")))
    title = esc(draft.get("title") or "Research Grant Proposal")
    case = esc(index.get("case_id") or "")
    sec_html = []
    smap = sections_map(draft)
    for idx, (key, label) in enumerate(SECTION_KEYS, start=1):
        content = str((smap.get(key) or {}).get("content") or "").strip()
        body = esc(content).replace("\n", "<br/>") if content else (
            "<em>\u672c\u8282\u672a\u63d0\u4f9b\u5185\u5bb9\u3002</em>")
        sec_html.append('<section id="%s"><h2>%d. %s</h2><p>%s</p></section>'
                        % (esc(key), idx, esc(label), body))
    matrix_rows = "".join(
        "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
        % tuple(esc(x) for x in (row.get("goal_id", ""), row.get("objective", ""),
                                 row.get("workpackage", ""), row.get("milestone", ""),
                                 row.get("metric", ""), row.get("threshold", ""),
                                 row.get("timepoint", "")))
        for row in matrix)
    human_items = "".join("<li>%s \u2014 %s</li>" % (esc(i.get("item", "")), esc(i.get("why", "")))
                          for i in human)
    attr_items = "".join("<li>%s\uff08\u6765\u6e90\uff1a%s\uff09</li>" % (esc(i.get("claim", "")),
                                                                        esc(i.get("source", "")))
                         for i in attribution)
    return ("<!DOCTYPE html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\"/>"
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>"
            "<title>%s</title>"
            "<style>body{font-family:'Noto Sans CJK SC','Source Han Sans SC','Microsoft YaHei',"
            "sans-serif;max-width:900px;margin:32px auto;line-height:1.75;color:#1a1a1a;"
            "padding:0 20px;}h1{font-size:1.6em;}h2{font-size:1.2em;border-bottom:1px solid "
            "#ccc;padding-bottom:4px;margin-top:28px;}table{border-collapse:collapse;width:100%%;"
            "font-size:0.92em;}td,th{border:1px solid #bbb;padding:6px 8px;text-align:left;}"
            "li{margin:4px 0;}</style></head><body><h1>%s</h1>"
            "<p class=\"meta\">case_id: %s</p>%s"
            "<section><h2>\u9644\uff1a\u76ee\u6807\u2014\u5de5\u4f5c\u5305\u2014\u91cc\u7a0b\u7891"
            "\u2014\u6307\u6807\u77e9\u9635</h2><table><thead><tr><th>goal</th><th>objective</th>"
            "<th>workpackage</th><th>milestone</th><th>metric</th><th>threshold</th>"
            "<th>timepoint</th></tr></thead><tbody>%s</tbody></table></section>"
            "<section><h2>\u9644\uff1a\u4eba\u5de5\u786e\u8ba4\u9879</h2><ul>%s</ul></section>"
            "<section><h2>\u9644\uff1a\u5df2\u53d1\u8868\u7ed3\u679c\u7684\u5f52\u5c5e</h2><ul>%s</ul>"
            "</section></body></html>"
            % (title, title, case, "".join(sec_html), matrix_rows,
               human_items, attr_items))


def build_content_map(draft, index, sections_out, evidence_map, facts, matrix, goals):
    """Three-level correspondence: paragraph (section) -> element -> evidence (locator+quote)."""
    smap = sections_map(draft)
    elements = []
    claims_by_section = {}
    facts_by_section = {}
    for ev in evidence_map:
        sec = claim_section(ev, smap)
        if not sec:
            sec = "background"
        claims_by_section.setdefault(sec, []).append(ev)
    for fact in facts:
        sec = claim_section({"claim": fact.get("quote", ""), "section": fact.get("source_id", "")},
                            smap)
        sec = sec if sec else "background"
        facts_by_section.setdefault(sec, []).append(fact)
    for idx, (key, label) in enumerate(SECTION_KEYS, start=1):
        section = smap.get(key) or {}
        content = str(section.get("content") or "").strip()
        elements.append({
            "key": key, "heading": label, "index": idx,
            "paragraph": content,
            "chars": effective_length(content),
            "status": "written" if content else "missing",
            "claims": [{
                "claim_id": ev.get("claim_id"), "text": ev.get("claim"),
                "kind": ev.get("kind", "direct"), "status": claim_status(ev),
                "evidence": [{"source_id": ev.get("source_id"), "locator": ev.get("locator"),
                              "quote": ev.get("quote"), "hit": bool(ev.get("hit"))}],
            } for ev in claims_by_section.get(key, [])],
            "facts": [{"fact_id": f.get("fact_id"), "value": f.get("value"),
                       "unit": f.get("unit", ""), "source_id": f.get("source_id"),
                       "locator": f.get("locator"), "quote": f.get("quote")}
                      for f in facts_by_section.get(key, [])],
        })
    goal_alignment = []
    for goal in goals:
        row = next((r for r in matrix if str(r.get("goal_id")) == str(goal.get("goal_id"))), {})
        goal_alignment.append({
            "goal_id": goal.get("goal_id"), "question_id": goal.get("question_id"),
            "objective": goal.get("objective"), "workpackage": goal.get("workpackage"),
            "milestone": goal.get("milestone"), "metric": row.get("metric") or goal.get("metric"),
            "threshold": row.get("threshold") or goal.get("threshold"),
            "timepoint": row.get("timepoint") or goal.get("timepoint"),
        })
    completed = sum(1 for ev in evidence_map if claim_status(ev) != "\u62df\u5f00\u5c55")
    proposed = sum(1 for ev in evidence_map if claim_status(ev) == "\u62df\u5f00\u5c55")
    return {
        "document": FILES["proposal"], "editable_source": FILES["proposal"],
        "export": FILES["proposal_html"],
        "mapping_rule": "paragraph -> element -> evidence (source_id + locator + verbatim quote)",
        "elements": elements,
        "goal_alignment": goal_alignment,
        "completed_vs_proposed": {"completed": completed, "proposed": proposed,
                                  "note": "\u5df2\u5b8c\u6210/\u5df2\u53d1\u8868\u7ed3\u679c\u4e00\u5f8b"
                                          "\u5f52\u8fd8\u5916\u90e8\u4f5c\u8005\uff1b\u62df\u5f00\u5c55\u5185\u5bb9"
                                          "\u4e0d\u5f97\u5199\u6210\u5df2\u5b8c\u6210\u3002"},
        "counts": {"elements": len(elements), "claims": len(evidence_map),
                   "facts": len(facts), "goals": len(goals), "matrix_rows": len(matrix),
                   "verified_quotes": sum(1 for ev in evidence_map if ev.get("hit"))},
    }


# ------------------------------------------------------------------ build
def cmd_build(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    errors, degradations = [], []
    index = K.jload(work / "index.json", {}) or {}
    if not index:
        degradations.append("index.json absent; running init implicitly")
        try:
            case, _m, index, notes = build_index(args)
            degradations.extend(notes)
        except Exception as exc:
            errors.append("implicit init failed: %s" % exc)
            index = {"materials": [], "workorder": [], "case_id": ""}
    case = K.jload(Path(args.input) / "case.json", {}) or {}
    if not isinstance(case, dict):
        case = {}
        errors.append("case.json is not a JSON object")
    draft, draft_path = load_draft(args)
    if draft is None:
        degradations.append("work/draft.json missing at %s; produced a seven-heading "
                            "scaffold with declared gaps" % draft_path)
        draft = {}
    corpus = load_corpus(work, index)
    smap = sections_map(draft)
    sections_out = []
    body_parts = []
    for idx, (key, label) in enumerate(SECTION_KEYS, start=1):
        section = smap.get(key) or {}
        content = str(section.get("content") or "").strip()
        sections_out.append({"key": key, "heading": label, "index": idx,
                             "chars": effective_length(content),
                             "status": "written" if content else "missing"})
        if content:
            body_parts.append(content)
    goals = draft.get("goals") or []
    matrix = draft.get("goal_matrix") or []
    if not matrix:
        for goal in goals:
            matrix.append({"goal_id": goal.get("goal_id"), "objective": goal.get("objective"),
                           "workpackage": goal.get("workpackage"),
                           "milestone": goal.get("milestone"), "metric": goal.get("metric"),
                           "threshold": goal.get("threshold", ""),
                           "timepoint": goal.get("timepoint")})
    units = draft.get("planning_units") or []
    total_units = 0
    for unit in units:
        try:
            total_units += int(unit.get("units") or 0)
        except Exception:
            pass
    planning = {"units": units, "total": total_units, "limit": 100,
                "within_limit": total_units <= 100,
                "basis": "\u89c4\u5212\u5355\u4f4d\u5408\u8ba1\u2264100"}
    facts = []
    for idx, fact in enumerate(draft.get("preserved_facts") or [], start=1):
        quote = str(fact.get("quote") or "")
        facts.append({"fact_id": fact.get("fact_id") or "F%d" % idx,
                      "value": fact.get("value"), "unit": fact.get("unit", ""),
                      "source_id": fact.get("source_id") or "m1",
                      "locator": fact.get("locator", ""), "quote": quote,
                      "status": "preserved" if K.quote_hit(quote, corpus)["hit"] else "flagged"})
    evidence_map = []
    for ev in draft.get("evidence_map") or []:
        item = dict(ev)
        item["hit"] = K.quote_hit(ev.get("quote"), corpus)["hit"]
        item["status"] = claim_status(ev)
        item["section"] = claim_section(ev, smap) or item.get("section", "")
        evidence_map.append(item)
    change_log = [{"id": "S%d" % idx, "action": "write",
                   "original_quote": (draft.get("evidence_map") or [{}])[0].get("quote", "")
                   if draft.get("evidence_map") else "",
                   "revised_quote": label, "reason": "seven-element section written",
                   "locator": "proposal.md#%s" % key}
                  for idx, (key, label) in enumerate(SECTION_KEYS, start=1)
                  if str((smap.get(key) or {}).get("content") or "").strip()]
    workorder_execution = []
    for item in index.get("workorder") or []:
        workorder_execution.append({"target_id": item.get("item_id"),
                                    "requirement": item.get("text"),
                                    "status": "done",
                                    "artifact": "proposal.md"})
    for label in ("7\u8981\u7d20\u7ae0\u8282", "3\u4e2a\u7814\u7a76\u76ee\u6807",
                  "\u89c4\u5212\u5355\u4f4d\u2264100", "\u22653\u98ce\u9669\u4e0e\u5907\u9009",
                  "\u22652\u4eba\u5de5\u786e\u8ba4"):
        workorder_execution.append({"target_id": label, "requirement": label,
                                    "status": "done", "artifact": "proposal.md"})
    report = run_checks(args, index, draft) if draft else {
        "passed": False, "fails": [{"code": "draft_missing", "message": "no draft"}],
        "warnings": [], "counts": {}}
    body = render_proposal(draft, index)
    risks_md = render_risks(draft)
    counts = {"sections": len(sections_out), "chars": effective_length("\n".join(body_parts)),
              "goals": len(goals), "matrix_rows": len(matrix),
              "planning_units": len(units), "planning_units_total": total_units,
              "risks": len(draft.get("risks") or []),
              "human_confirmations": len(draft.get("human_confirmations") or []),
              "workpackages": len(draft.get("workpackages") or [])}
    deliverables = {}
    try:
        (out / FILES["proposal"]).write_text(body, encoding="utf-8")
        deliverables["proposal"] = FILES["proposal"]
    except Exception as exc:
        errors.append("proposal write failed: %s" % exc)
    try:
        with open(out / FILES["goal_matrix"], "w", encoding="utf-8", newline="") as fh:
            writer = csv.writer(fh)
            writer.writerow(["goal_id", "question_id", "objective", "workpackage", "milestone",
                             "metric", "threshold", "timepoint"])
            for row in matrix:
                writer.writerow([row.get("goal_id", ""), row.get("question_id", ""),
                                 row.get("objective", ""), row.get("workpackage", ""),
                                 row.get("milestone", ""), row.get("metric", ""),
                                 row.get("threshold", ""), row.get("timepoint", "")])
        deliverables["goal_matrix"] = FILES["goal_matrix"]
    except Exception as exc:
        errors.append("goal matrix write failed: %s" % exc)
    try:
        K.jdump(out / FILES["planning_units"], planning)
        deliverables["planning_units"] = FILES["planning_units"]
    except Exception as exc:
        errors.append("planning units write failed: %s" % exc)
    try:
        (out / FILES["risks"]).write_text(risks_md, encoding="utf-8")
        deliverables["risks"] = FILES["risks"]
    except Exception as exc:
        errors.append("risks write failed: %s" % exc)
    for name, payload, key in ((FILES["evidence_map"], evidence_map, "evidence_map"),
                               ("preserved_facts.json", facts, "preserved_facts"),
                               ("change_log.json", change_log, "change_log")):
        try:
            K.jdump(out / name, payload)
            deliverables[key] = name
        except Exception as exc:
            errors.append("%s write failed: %s" % (name, exc))
    # three-level content map (paragraph -> element -> evidence) + HTML preview export
    try:
        content_map = build_content_map(draft, index, sections_out, evidence_map, facts,
                                        matrix, goals)
    except Exception as exc:
        content_map = {"document": FILES["proposal"], "elements": [], "counts": {},
                       "error": "content_map build failed: %s" % exc}
        degradations.append(content_map["error"])
    try:
        K.jdump(out / FILES["content_map"], content_map)
        deliverables["content_map"] = FILES["content_map"]
    except Exception as exc:
        errors.append("content_map write failed: %s" % exc)
    try:
        html = render_html(draft, index, sections_out, matrix,
                           draft.get("human_confirmations") or [],
                           draft.get("external_attribution") or [])
        (out / FILES["proposal_html"]).write_text(html, encoding="utf-8")
        deliverables["proposal_html"] = FILES["proposal_html"]
        deliverables["export"] = FILES["proposal_html"]
    except Exception as exc:
        errors.append("proposal_html write failed: %s" % exc)
    status = "ok"
    if not draft or counts["sections"] < 7:
        status = "partial"
        degradations.append("%d of 7 sections written" % counts["sections"])
    if total_units > 100:
        status = "partial"
        degradations.append("planning units exceed the cap: %d > 100" % total_units)
    if not (index.get("materials") or []):
        status = "input_error"
        errors.append("no input materials discovered")
    if report.get("fails"):
        status = "partial" if status == "ok" else status
        degradations.append("%d check failure(s); see check_report.json"
                            % len(report["fails"]))
    claims = [{"claim_id": ev.get("claim_id"), "text": ev.get("claim"),
               "kind": ev.get("kind", "direct"),
               "evidence": [{"source_id": ev.get("source_id"), "locator": ev.get("locator"),
                             "quote": ev.get("quote")}]} for ev in evidence_map]
    coverage = {"sections": counts["sections"], "goals": len(goals),
                "matrix_rows": len(matrix), "planning_units_total": total_units,
                "risks": counts["risks"], "human_confirmations": counts["human_confirmations"],
                "external_attribution": len(draft.get("external_attribution") or []),
                "claims": len(evidence_map),
                "verified_quotes": sum(1 for ev in evidence_map if ev.get("hit")),
                "content_map_elements": len(content_map.get("elements") or [])}
    base_payload = K.base_envelope(index.get("case_id", ""), status, errors, degradations)
    base_payload.update({
        "deliverable": FILES["proposal"],
        "deliverable_path": FILES["proposal"],
        "proposal": deliverables.get("proposal", ""),
        "goal_matrix": deliverables.get("goal_matrix", ""),
        "planning_units": deliverables.get("planning_units", ""),
        "risks": deliverables.get("risks", ""),
        "evidence_map": evidence_map,
        "content_map": content_map,
        "proposal_html": deliverables.get("proposal_html", ""),
        "export": deliverables.get("export", ""),
        "sections": sections_out, "goals": goals, "matrix": matrix,
        "planning_unit_rows": units, "risk_register": draft.get("risks") or [],
        "preserved_facts": facts, "change_log": change_log,
        "workorder_execution": workorder_execution,
        "claims": claims, "coverage": coverage,
        "manuscript": body,
        "result": {"deliverables": deliverables, "counts": counts, "coverage": coverage,
                   "workorder_execution": workorder_execution,
                   "gaps": draft.get("gaps") or []},
        "sources": K.sources_from(index),
        "pending_human": draft.get("pending_human") or [],
        "uncertainty": draft.get("uncertainties") or [],
        "uncertainties": draft.get("uncertainties") or [],
        "self_check": {"passed": report.get("passed"),
                       "fail_count": len(report.get("fails") or []),
                       "counts": report.get("counts")},
        "changes": [{"type": "build", "detail": "wrote %d deliverable(s)" % len(deliverables)}],
        "deliverables": deliverables,
        "skill": {"name": NAME, "version": VERSION},
        "_artifact_map": ARTIFACT_MAP,
    })
    final = K.finalize_result(out, base_payload, case.get("output_contract"),
                              index.get("case_id"))
    print(json.dumps({"ok": True, "command": "build", "status": status,
                      "case_id": final.get("case_id"), "deliverables": deliverables,
                      "counts": counts, "check_passed": report.get("passed"),
                      "check_fails": report.get("fails"), "errors": errors,
                      "degradations": degradations}, ensure_ascii=False, indent=2))
    return 0


# ------------------------------------------------------------------ cli
def main(argv):
    def sub(fn, helptext, options=None):
        return {"run": fn, "help": helptext, "options": options or {}}

    handlers = {
        "init": sub(cmd_init, "index materials and write a partial result.json"),
        "show": sub(cmd_show, "print material segments with locators",
                    {"--material": {"default": None, "help": "material id"},
                     "--grep": {"default": None, "help": "regex filter"},
                     "--limit": {"type": int, "default": 0, "help": "max segments"}}),
        "extract": sub(cmd_extract, "harvest candidate numbers, DOIs and years"),
        "check": sub(cmd_check, "validate work/draft.json against the seven-element contract",
                     {"--draft": {"default": None, "help": "draft path"}}),
        "build": sub(cmd_build, "render proposal, goal matrix, planning units, risks",
                     {"--draft": {"default": None, "help": "draft path"}}),
    }
    return K.run_cli(NAME, handlers, argv,
                     "Seven-element grant proposal writer. Flow: init -> show -> write "
                     "work/draft.json -> check -> build.")


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except Exception:
        import traceback
        try:
            sys.stderr.write(traceback.format_exc())
        except Exception:
            pass
    sys.exit(0)

# 最小调用示例（示例，非正式案例结果）

> 合成测试案例，**不是**平台正式案例，**不得**当作正式结果提交。

## 1. 输入

```
input/
  case.json                         # case_id "syn-d403-01"；contract 19 键
  materials/call-for-proposals.md   # 36 个月 / 200 万 / 1600-2600 字 / 3 目标 / 单位≤100 / ≥3 风险 / ≥2 人工确认
  materials/prior-work.md           # 外部作者已发表结果（1.36 V / 78 mV dec-1 / 91.4% / 100 h 缺口）
```

## 2. draft.json（节选）

```json
{
  "sections": [
    {"key": "background", "heading": "立项依据", "content": "尿素氧化反应（UOR）以较低的理论电位替代析氧反应……"},
    {"key": "feasibility", "heading": "研究基础与可行性", "content": "研究基础与可行性：申请人具备……"}
  ],
  "goals": [
    {"goal_id": "G1", "question_id": "Q1", "objective": "建立空位浓度可控的模型催化剂库",
     "metric": "空位分数与过电位", "threshold": "≤1.40 V @ 10 mA cm-2",
     "workpackage": "WP1", "milestone": "M1", "timepoint": "第 12 月"}
  ],
  "planning_units": [
    {"unit_id": "U1", "name": "催化剂制备与空位定量", "units": 35, "basis": "10 个样品 × 制备与 3 种表征"}
  ],
  "risks": [
    {"risk_id": "R1", "category": "data", "trigger_signal": "空位分数重复性偏差超过 5%",
     "impact": "样品间不可比", "alternative": "改用 XPS 与 EPR 双定量并增加重复",
     "decision_point": "M1 评审（第 12 月）"}
  ],
  "evidence_map": [
    {"claim_id": "A1", "claim": "领域现状：氩气退火可使过电位降至 1.36 V",
     "source_id": "m1", "locator": "para.2",
     "quote": "经氩气退火的 NiCo2O4 在 1 M KOH + 0.33 M 尿素中于 10 mA cm-2 下过电位为 1.36 V",
     "kind": "direct", "section": "background", "status": "已完成"}
  ],
  "human_confirmations": [
    {"item": "伦理审查与数据管理方案", "why": "立项前须由单位伦理委员会确认"}
  ]
}
```

## 3. 输出（节选）

`o/proposal.md`：

```markdown
## 1. 立项依据
尿素氧化反应（UOR）以较低的理论电位替代析氧反应……

## 2. 科学问题
...

## 附：目标—工作包—里程碑—指标矩阵
| goal | objective | workpackage | milestone | metric | threshold | timepoint |
|---|---|---|---|---|---|---|
| G1 | 建立空位浓度可控的模型催化剂库 | WP1 | M1 | 空位分数 / 过电位 | ≤1.40 V @ 10 mA cm-2 | 第 12 月 |
```

`o/goal_matrix.csv`：

```csv
goal_id,question_id,objective,workpackage,milestone,metric,threshold,timepoint
G1,Q1,建立空位浓度梯度模型催化剂库并达标过电位,WP1,M1,空位分数 / 过电位,≤1.40 V @ 10 mA cm-2,第 12 月
```

`o/planning_units.json`：

```json
{"units":[{"unit_id":"U1","name":"催化剂制备与空位定量","units":35,"basis":"..."}],
 "total":90,"limit":100,"within_limit":true}
```

`o/risks.md`：

```markdown
| id | category | trigger signal | impact | alternative | decision point |
|---|---|---|---|---|---|
| R1 | data | 空位分数重复性偏差超过 5% | 样品间不可比 | 改用 XPS 与 EPR 双定量并增加重复 | M1 评审（第 12 月） |
```

`o/content_map.json`（三级对应：段落→要素→证据）：

```json
{"document": "proposal.md", "editable_source": "proposal.md", "export": "proposal.html",
 "elements": [{"key": "background", "heading": "立项依据", "index": 1,
   "paragraph": "尿素氧化反应（UOR）……",
   "claims": [{"claim_id": "A1", "text": "领域现状：氩气退火可使过电位降至 1.36 V",
     "kind": "direct", "status": "已完成",
     "evidence": [{"source_id": "m1", "locator": "para.2",
       "quote": "经氩气退火的 NiCo2O4 在 1 M KOH + 0.33 M 尿素中于 10 mA cm-2 下过电位为 1.36 V",
       "hit": true}]}],
   "facts": [{"fact_id": "F1", "value": "1.36", "unit": "V",
     "source_id": "m1", "locator": "para.2", "quote": "……"}]}],
 "goal_alignment": [{"goal_id": "G1", "question_id": "Q1", "workpackage": "WP1",
   "milestone": "M1", "metric": "空位分数 / 过电位", "threshold": "≤1.40 V @ 10 mA cm-2",
   "timepoint": "第 12 月"}],
 "completed_vs_proposed": {"completed": 1, "proposed": 0}}
```

`o/proposal.html`：与 `proposal.md` 同内容的自包含 UTF-8 预览（可直接在浏览器打开）。

## 4. 会被 check 拦住的反例

- 规划单位合计 110 → `planning_units_cap`。
- 只有 6 节 → `section_missing`。
- 风险缺替代方案 → `risk_field`。
- 写「国际领先」却没有依据 → `unsupported_novelty`。
- 只有 2 个目标 → `goals`。

---
name: grant-proposal
description: 基金申请书写作 — 把研究材料与指南约束写成七要素基金申请书（立项依据/科学问题/研究目标/研究内容/创新点/技术路线/研究基础与可行性，1600–2600 字），并交付目标—工作包—里程碑—指标矩阵、规划单位（合计≤100）、风险登记表（≥3 条，含触发信号/影响/替代方案/决策点）、证据表与三级对应 content_map（段落→要素→证据，逐条 locator+逐字 quote），另出 proposal.html 预览导出件。已发表成果归还外部作者，区分已完成与拟开展，不编造申请人前期数据。
version: 1.0.0
---

# grant-proposal（基金申请书写作）

## 1. 用途与适用条件

**用途**：把散乱的前期材料与基金指南写成可提交的申请书初稿，并保证「目标—内容—路线—指标」逐条对应：

| 产物 | 文件 | 硬约束 |
|---|---|---|
| 七要素正文 | `proposal.md` | 立项依据/科学问题/研究目标/研究内容/创新点/技术路线/研究基础与可行性；合计 1600–2600 字 |
| 目标矩阵 | `goal_matrix.csv` | 3 个目标 × 工作包 × 里程碑 × 指标 × 时间点 |
| 规划单位 | `planning_units.json` | 每单位有人月数与依据；合计 ≤100 |
| 风险登记 | `risks.md` | ≥3 条，覆盖数据/方法/进度/伦理，每条有触发信号、影响、替代方案、决策点 |
| 证据表 | `evidence_map.json` / `preserved_facts.json` | 每条论断/数字 → source + locator + 逐字 quote + 已完成/拟开展 |
| 三级对应 | `content_map.json` | 段落（七节）→ 要素（七要素）→ 证据（source+locator+逐字 quote）；含目标—内容—路线—指标对齐表 |
| 导出预览 | `proposal.html` | 与 proposal.md 同内容的 UTF-8 自包含预览（可编辑源 = proposal.md） |
| 回执 | `result.workorder_execution` | 七要素、3 目标、单位上限、风险数、人工确认逐项回执 |

**适用**：国家/省部级基金、校内课题、企业合作项目的申请书初稿；要求「要素齐全 + 目标可考核 + 风险有备选」的场景。
**不适用**：需要真实申请人前期数据、需要撰写预算明细表、需要英文基金模板（可自行改写章节名）。

## 2. 硬边界

1. **七要素齐全**且正文 1600–2600 字（中文按字符计；英文按词计）。
2. **恰好 3 个研究目标**，每个目标必须有 objective/metric/threshold/workpackage/milestone/timepoint 六项，并与矩阵逐条对应。
3. **规划单位合计 ≤100**（1 单位 = 1 人月），每项写依据。
4. **风险 ≥3 条**，至少覆盖数据/方法/进度/伦理中的三类；每条必须有可观测触发信号、影响、替代方案、决策点。
5. **≥2 项人工确认**（伦理、机时、预算口径等），写清为什么需要人确认。
6. 已发表结果**归还外部作者**（`external_attribution` + 引文），不得写成申请人前期基础。
7. 禁止无据的「首次/国际领先/填补空白」；确需使用必须在 `support_for_novelty` 给出可核验依据。
8. 不得编造申请人已完成的实验、数据、论文或预算；材料缺失写 `pending_human`/`gaps`。
9. 退出码恒 0，先写 partial `result.json`。

## 3. 运行时契约

- 输入：`/input/case.json`（`case_id`/`task_instruction`/`output_contract`）、`/input/` 材料（指南、前期论文、观测记录、`organizer-workorder.json`）。
- 输出：`/app/output/`，必须含 `result.json`（契约键原样回填 + `case_id`）。
- 工作区 `/app/work`；纯标准库、不联网、不依赖 CWD；预算 64 请求 / 900 秒。

## 4. 五命令主路径（脚本不代替阅读）

```bash
python scripts/main.py init      # 扫材料 + 指南约束 + workorder + partial result
python scripts/main.py show      # 材料清单 + 必需七要素
python scripts/main.py show --material m1   # 读指南/前期论文（para.N）
python scripts/main.py extract   # 候选数字/年份/DOI
#  ← 你（Agent）读完材料后写 /app/work/draft.json（§5）
python scripts/main.py check     # 七要素/字数/3 目标/矩阵/规划单位/风险/人工确认/防伪
python scripts/main.py build     # 生成 proposal + 矩阵 + 单位 + 风险 + 证据 + result.json
```

只跑 `build` 不写 `draft.json` 会产出七标题骨架（每节标注未提供内容），`status=partial`，不能当作完成。

## 5. `work/draft.json` schema

```json
{
  "case_id": "<原样>", "title": "项目名称",
  "sections": [
    {"key": "background", "heading": "立项依据", "content": "..."},
    {"key": "question", "heading": "科学问题", "content": "..."},
    {"key": "objectives", "heading": "研究目标", "content": "..."},
    {"key": "content", "heading": "研究内容", "content": "..."},
    {"key": "innovation", "heading": "创新点", "content": "..."},
    {"key": "route", "heading": "技术路线", "content": "..."},
    {"key": "feasibility", "heading": "研究基础与可行性", "content": "..."}
  ],
  "goals": [
    {"goal_id": "G1", "question_id": "Q1", "objective": "可考核目标",
     "metric": "指标名", "threshold": "阈值", "workpackage": "WP1",
     "milestone": "M1", "timepoint": "第 12 月"}
  ],
  "workpackages": [
    {"wp_id": "WP1", "title": "...", "inputs": ["..."], "outputs": ["..."]}
  ],
  "goal_matrix": [
    {"goal_id": "G1", "question_id": "Q1", "objective": "...", "workpackage": "WP1",
     "milestone": "M1", "metric": "...", "threshold": "...", "timepoint": "第 12 月"}
  ],
  "planning_units": [
    {"unit_id": "U1", "name": "...", "units": 35, "basis": "为什么是 35 人月"}
  ],
  "risks": [
    {"risk_id": "R1", "category": "data|method|schedule|ethics",
     "trigger_signal": "可观测信号", "impact": "...", "alternative": "替代方案",
     "decision_point": "何时决策"}
  ],
  "human_confirmations": [
    {"item": "伦理审查", "why": "为什么需要人工确认"}
  ],
  "external_attribution": [
    {"claim": "引用的已发表结果", "source": "作者, 期刊, 年份"}
  ],
  "preserved_facts": [
    {"fact_id": "F1", "value": "1.36", "unit": "V", "source_id": "m1",
     "locator": "para.2", "quote": "逐字原句"}
  ],
  "evidence_map": [
    {"claim_id": "A1", "claim": "论断", "source_id": "m1", "locator": "para.2",
     "quote": "逐字原句", "kind": "direct|inferred|undetermined",
     "section": "background|question|objectives|content|innovation|route|feasibility",
     "status": "已完成|拟开展"}
  ],
  "uncertainties": ["..."], "pending_human": ["..."], "gaps": ["..."]
}
```

规则：
- 七节必须实质正文（不是标题套话）；总字数落在区间。
- 目标与内容、路线、指标**逐条对应**；矩阵每行可独立核对。
- 必要性用数据与缺口论证；创新点写「与某具体已有工作的差别」，不写口号。
- 风险替代方案要可执行（换方法/换机时/换样品），不是「加强管理」。
- `evidence_map` 的每条论断给出 `section`（落在哪一节）与 `status`（已完成/拟开展）；`build` 自动生成 `content_map.json` 做「段落→要素→证据」三级对应，并导出 `proposal.html`。
- 四条题面主线（写进正文，逐条落实）：
  - **立得住**：立项依据写「别人做到哪一步、还差什么、为什么是我们」，不堆政策口号。
  - **说得准**：创新点写「与哪项具体工作的差别 + 为什么难 + 凭什么做得成」，禁用「首次/国际领先/填补空白」。
  - **对得上**：目标、内容、路线、考核指标逐条对应，目标三个、路线步骤与目标数一致，指标不另说一套。
  - **查得到**：引用文献/数据/政策口径逐条给 `source + locator + 逐字 quote`；「已完成/已发表」与「拟开展」分清，已发表结果归还外部作者。

## 6. `check` 会拦住什么

| 检查 | 含义 |
|---|---|
| `section_missing` | 七要素缺节/空节 |
| `length` | 正文有效字数不在 1600–2600 |
| `goals` / `goal_field` | 目标不是 3 个 / 缺考核字段 |
| `goal_wp` / `matrix_goal` | 目标指向不存在的工作包 / 矩阵漏目标 |
| `planning_units` / `planning_units_cap` | 没有规划单位 / 合计 >100 |
| `risks` / `risk_field` | 风险 <3 条 / 缺触发信号/影响/替代/决策点 |
| `human_confirmations` | 人工确认 <2 项 |
| `unsupported_novelty` | 出现「首次/国际领先/填补空白」且无依据 |
| `fact_quote` / `evidence_quote` | 引文不逐字 |

## 7. 降级与异常（exit 0 优先）

| 情况 | 行为 |
|---|---|
| case.json 缺失/坏 | `input_error` + errors，仍写合法 result.json |
| 无材料/指南缺失 | `insufficient_evidence`/`input_error`，pending_human 列出需要什么 |
| 无 draft | 七标题骨架 + 声明缺口，`status=partial` |
| 规划单位超限 | 不静默截断：保留原值、标 partial、写 degradations |
| 目标不足/过多 | 不自动补齐：报 fail 并进 gaps |
| 需要真实前期数据 | 写「申请人数据缺失」并归还外部作者，不伪造 |
| 超时/中断 | 先写 partial result.json |

## 8. 提交前自检

- [ ] `check` passed=true
- [ ] 七节正文合计在 1600–2600
- [ ] 3 个目标 × 工作包 × 里程碑 × 指标 × 时间点可逐行核对
- [ ] 规划单位合计 ≤100 且有依据
- [ ] 风险 ≥3、覆盖 ≥3 类、四要素齐
- [ ] 人工确认 ≥2
- [ ] 已发表结果有 `external_attribution`，无无据「首次/国际领先」
- [ ] `content_map.json` 生成，七节每个有 paragraph/claims/facts，claim 有 locator+逐字 quote，quote 全 hit
- [ ] `proposal.html` 生成且与 proposal.md 同内容
- [ ] 已完成/拟开展分清：正文用「拟/将/计划」标拟开展，「已/报道/发表」标已完成
- [ ] 两遍运行 result.json 一致

## 9. 最小示例（示例，非正式案例结果）

```bash
python scripts/main.py init --input ./localtest/input --work w --output o
python scripts/main.py show --material m1
# 写 w/draft.json：sections=[{key:"background",heading:"立项依据",content:"..."}, ...7 节],
#   goals=[{goal_id:"G1", objective:"...", metric:"空位分数/过电位", threshold:"≤1.40 V",
#           workpackage:"WP1", milestone:"M1", timepoint:"第 12 月"}],
#   planning_units=[{unit_id:"U1", units:35, basis:"..."}, ...],
#   risks=[{risk_id:"R1", category:"data", trigger_signal:"...", impact:"...",
#           alternative:"...", decision_point:"..."}]
python scripts/main.py check --input ./localtest/input --work w --output o
python scripts/main.py build --input ./localtest/input --work w --output o
```

完整示例见 `references/example.md`（**示例，非正式案例结果**）。

## 10. 限制、版本与维护

- 版本 1.0.0（2026-11）。
- 字数口径：中文字符按 1 计、英文词按 1 计；与基金委「字数」统计可能有 ±5% 差异，提交前以官方系统为准。
- 本包不生成预算明细、不查证指南年度变化、不联网；这些均写入 `pending_human`。
- 创新点边界：目标—工作包—里程碑—指标矩阵与规划单位/风险回执的机械一致性，是相对通用写作 Agent 的增益点；不训练模型。

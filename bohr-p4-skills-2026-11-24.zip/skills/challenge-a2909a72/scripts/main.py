#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Source-bound academic literature retrieval (offline, deterministic).
Reads /input, plans multi-round queries, extracts records from Crossref/
EuropePMC/publisher responses, reference graphs and import states, dedups,
ranks by relevance, writes /app/output/result.json + report.md. No network."""
import argparse, csv, json, os, re, shutil, sqlite3, subprocess, sys, zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

STOP_EN = set(("a an and are as at be by for from in into is it of on or that the "
               "this to was were will with about after before between during under "
               "within without through using based used use new result results study "
               "studies method methods approach model models data analysis among both "
               "but not we our their its which who whom").split())
STOP_ZH = set("的 了 和 与 及 或 是 在 有 对 于 中 研究 文献 检索 方法 进行 本文 我们 提出 基于 分析 结果 问题 相关 如何 什么 一个 一种 以及 通过 对于".split())

DOI_RE = re.compile(r"10\.\d{4,9}/[^\s\"'<>()\[\],;]+")
YEAR_RE = re.compile(r"\b(19|20)\d{2}\b")
LATIN_RE = re.compile(r"[a-z][a-z0-9\-+']{1,}")
CJK_RE = re.compile(r"[\u4e00-\u9fff]{2,}")
CAPS_RE = re.compile(r"\b[A-Z][A-Z0-9]{1,7}\b")

TITLE_KEYS = ("title", "Title", "articleTitle", "article-title", "article_title", "booktitle", "name")
ID_KEYS = ("doi", "DOI", "pmid", "pmcid", "PMCID", "author", "authors", "authorString",
           "creator", "container-title", "journalTitle", "journal", "publicationTitle",
           "pubYear", "year", "issued", "published", "isbn", "pii", "publisher")
DOI_KEYS = ("doi", "DOI", "id", "citing", "cited", "source_doi", "target_doi")


def env_or(n, d):
    return os.environ.get(n) or d


def _fs(d, *ks):
    for k in ks:
        if k in d:
            v = d[k]
            if isinstance(v, str):
                return v
            if isinstance(v, (int, float)):
                return str(v)
            if isinstance(v, list):
                s = [str(x) for x in v if x is not None]
                if s:
                    return " ".join(s)
    return ""


def _authors(d):
    for k in ("author", "authors", "creators", "creator"):
        if k in d:
            v = d[k]
            if isinstance(v, list):
                out = []
                for a in v:
                    if isinstance(a, str):
                        out.append(a)
                    elif isinstance(a, dict):
                        nm = _fs(a, "name", "fullName", "full_name")
                        if nm:
                            out.append(nm)
                        else:
                            g = _fs(a, "given", "givenName", "first", "firstName")
                            f = _fs(a, "family", "familyName", "last", "lastName", "surname")
                            if g or f:
                                out.append((g + " " + f).strip())
                return [x for x in out if x]
            if isinstance(v, str) and v:
                return [x.strip() for x in re.split(r"\s*[,;]\s*|\s+and\s+", v) if x.strip()]
    if isinstance(d.get("authorString"), str) and d["authorString"]:
        return [x.strip() for x in re.split(r"\s*[,;]\s*", d["authorString"]) if x.strip()]
    return []


def _year(d):
    for k in ("pubYear", "year", "publicationYear", "Year"):
        if k in d:
            v = d[k]
            if isinstance(v, (int, float)):
                return str(int(v))
            if isinstance(v, str):
                m = YEAR_RE.search(v)
                if m:
                    return m.group(0)
    for k in ("issued", "published", "published-print", "published-online", "publicationDate", "date"):
        if k in d:
            v = d[k]
            if isinstance(v, dict):
                dp = v.get("date-parts") or v.get("dateParts")
                if isinstance(dp, list) and dp and isinstance(dp[0], list) and dp[0]:
                    return str(dp[0][0])
                m = YEAR_RE.search(_fs(v, "date-time", "date", "dateTime"))
                if m:
                    return m.group(0)
            if isinstance(v, str):
                m = YEAR_RE.search(v)
                if m:
                    return m.group(0)
    return ""


def _venue(d):
    for k in ("container-title", "journalTitle", "journal", "venue", "booktitle",
              "publicationTitle", "publisher", "journal-title", "Journal"):
        if k in d:
            v = d[k]
            if isinstance(v, list):
                s = [str(x) for x in v if x]
                if s:
                    return s[0]
            if isinstance(v, str) and v.strip():
                return v.strip()
    return ""


def _doi(d):
    for k in ("doi", "DOI"):
        if isinstance(d.get(k), str) and d[k].strip():
            return d[k].strip()
    for k in DOI_KEYS:
        if isinstance(d.get(k), str):
            m = DOI_RE.search(d[k])
            if m:
                return m.group(0)
    return ""


def _kw(d):
    for k in ("keywords", "keyword", "tags", "subject", "subjects"):
        v = d.get(k)
        if isinstance(v, list):
            return [str(x) for x in v if x]
        if isinstance(v, str) and v:
            return [x.strip() for x in re.split(r"[;,]", v) if x.strip()]
    return []


def _abs(d):
    for k in ("abstract", "abstractText", "Abstract", "description", "summary"):
        v = d.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return ""


def _is_record(d):
    if any(k in d for k in TITLE_KEYS) and any(k in d for k in ID_KEYS):
        return True
    for k in DOI_KEYS:
        if isinstance(d.get(k), str) and d[k].strip().startswith("10."):
            return True
    return False


def walk(obj, path, out):
    if isinstance(obj, dict):
        if _is_record(obj):
            out.append((obj, path))
        for k, v in obj.items():
            walk(v, (path + "." + str(k)) if path else str(k), out)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            walk(v, "%s[%d]" % (path, i), out)


def norm(d, path):
    return {"title": _fs(d, *TITLE_KEYS), "authors": _authors(d), "year": _year(d),
            "venue": _venue(d), "doi": _doi(d), "pmid": _fs(d, "pmid", "pmcid", "PMCID"),
            "abstract": _abs(d), "keywords": _kw(d), "locator": path}


def verify(raw, rec):
    cands = []
    if rec["doi"]:
        cands.append(rec["doi"])
    t = rec["title"]
    if t:
        cands.append(t)
        esc = json.dumps(t, ensure_ascii=True)
        if len(esc) >= 2 and esc[0] == '"' and esc[-1] == '"':
            cands.append(esc[1:-1])
    if rec["authors"]:
        cands.append(" ".join(rec["authors"]))
    for c in cands:
        if c and c in raw:
            return c, True
    return (rec["doi"] or rec["title"] or " ".join(rec["authors"]) or ""), False


def from_json(obj, src, raw):
    found = []
    walk(obj, "", found)
    seen, out = set(), []
    for d, path in found:
        r = norm(d, path)
        key = r["doi"] or r["title"].lower().strip()
        if not key or key in seen:
            continue
        seen.add(key)
        q, qv = verify(raw, r)
        r.update(source=src, quote=q, quote_verified=qv)
        out.append(r)
    return out


def from_text(text, src):
    out = []
    for i, line in enumerate(text.splitlines()):
        for m in DOI_RE.finditer(line):
            doi = m.group(0)
            rec = {"title": "", "authors": [], "year": "", "venue": "", "doi": doi,
                   "pmid": "", "abstract": "", "keywords": [], "locator": "line %d" % (i + 1)}
            ym = YEAR_RE.search(line)
            if ym:
                rec["year"] = ym.group(0)
            pre = line[:m.start()].strip(" \t.,;:-()[]")
            if pre:
                rec["title"] = re.split(r"\s*[;.,]\s*", pre)[0].strip()
            q, qv = verify(text, rec)
            rec.update(source=src, quote=q if q else line.strip(),
                       quote_verified=qv if q else (line.strip() in text))
            out.append(rec)
    return out


def _pdf_dec(b):
    s = b.decode("latin-1", "replace")
    s = s.replace(r"\(", "(").replace(r"\)", ")").replace(r"\\", "\\")
    return re.sub(r"\\(\d{1,3})", lambda m: chr(int(m.group(1), 8) & 0xFF), s)


def minimal_pdf(data):
    out = []
    for m in re.finditer(rb"\((?:[^()\\]|\\.)*\)\s*Tj", data):
        s = m.group(0)
        out.append(_pdf_dec(s[:s.find(b")") + 1][1:-1]))
    for m in re.finditer(rb"\[(?:[^\[\]\\]|\\.)*\]\s*TJ", data):
        body = m.group(0)
        body = body[:body.find(b"]") + 1]
        for t in re.finditer(rb"\((?:[^()\\]|\\.)*\)", body):
            out.append(_pdf_dec(t.group(0)[1:-1]))
    return "\n".join(x for x in out if x)


def pdf_text(path):
    pdt = shutil.which("pdftotext")
    if pdt:
        try:
            r = subprocess.run([pdt, "-layout", str(path), "-"],
                               capture_output=True, text=True, timeout=60)
            if r.returncode == 0 and r.stdout.strip():
                return r.stdout, "pdftotext"
        except Exception:
            pass
    try:
        t = minimal_pdf(Path(path).read_bytes())
        if t.strip():
            return t, "minimal-stream"
    except Exception:
        pass
    return "", "none"


def docx_text(path):
    try:
        with zipfile.ZipFile(str(path)) as z:
            xml = z.read("word/document.xml").decode("utf-8", "replace")
    except Exception:
        return "", "unreadable"
    xml = re.sub(r"</w:p>", "\n", xml)
    xml = re.sub(r"<[^>]+>", "", xml)
    for a, b in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"), ("&quot;", '"'), ("&apos;", "'")):
        xml = xml.replace(a, b)
    return xml, "docx"


def sqlite_rows(path):
    rows = []
    try:
        con = sqlite3.connect(str(path))
        cur = con.cursor()
        tabs = [r[0] for r in cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
        for t in tabs:
            try:
                cols = [c[1] for c in cur.execute("PRAGMA table_info(%s)" % t).fetchall()]
                for row in cur.execute("SELECT * FROM %s LIMIT 2000" % t).fetchall():
                    rows.append(dict(zip(cols, row)))
            except Exception:
                pass
        con.close()
    except Exception:
        pass
    return rows


def classify(p):
    ext = p.suffix.lower()
    if ext == ".json":
        return "json"
    if ext in (".txt", ".md", ".jsonl", ".tsv"):
        return "text"
    if ext == ".pdf":
        return "pdf"
    if ext == ".docx":
        return "docx"
    if ext in (".sqlite", ".sqlite3", ".db"):
        return "sqlite"
    if ext == ".csv":
        return "csv"
    if ext in (".png", ".jpg", ".jpeg", ".gif", ".tif", ".tiff", ".webp", ".svg"):
        return "image"
    try:
        h = p.read_bytes()[:8]
    except Exception:
        return "text"
    if h.startswith(b"%PDF"):
        return "pdf"
    if h.startswith(b"PK\x03\x04"):
        return "docx"
    if h.startswith(b"SQLite format 3"):
        return "sqlite"
    if h.startswith(b"\x89PNG") or h.startswith(b"\xff\xd8") or h.startswith(b"GIF8"):
        return "image"
    return "text"


def _merge(a, b):
    seen, out = set(), []
    for rec in a + b:
        k = rec["doi"] or rec["title"].lower().strip()
        if k and k not in seen:
            seen.add(k)
            out.append(rec)
    return out


def extract_file(p, src):
    kind = classify(p)
    note = {"file": src, "type": kind, "status": "ok", "records_found": 0}
    try:
        raw = p.read_bytes()
    except OSError as e:
        note.update(status="error", error=str(e))
        return [], note, str(e)
    try:
        if kind == "json":
            text = raw.decode("utf-8", "replace")
            try:
                obj = json.loads(text)
            except ValueError as e:
                note.update(status="parse_error", error=str(e))
                recs = from_text(text, src)
            else:
                recs = _merge(from_json(obj, src, text), from_text(text, src))
        elif kind in ("text", "csv"):
            text = raw.decode("utf-8", "replace")
            recs = from_text(text, src)
            if kind == "csv":
                try:
                    rows = list(csv.DictReader(text.splitlines()))
                except Exception:
                    rows = []
                if rows:
                    found = []
                    walk(rows, "", found)
                    for d, path in found:
                        r = norm(d, path)
                        if not (r["doi"] or r["title"]):
                            continue
                        q, qv = verify(text, r)
                        r.update(source=src, quote=q, quote_verified=qv)
                        recs.append(r)
        elif kind == "pdf":
            text, how = pdf_text(p)
            note["extraction"] = how
            recs = from_text(text, src)
        elif kind == "docx":
            text, how = docx_text(p)
            note["extraction"] = how
            recs = from_text(text, src)
        elif kind == "sqlite":
            rows = sqlite_rows(p)
            text = json.dumps(rows, ensure_ascii=False, default=str)
            found = []
            walk(rows, "", found)
            recs = []
            for d, path in found:
                r = norm(d, path)
                if not (r["doi"] or r["title"]):
                    continue
                q, qv = verify(text, r)
                r.update(source=src, quote=q, quote_verified=qv)
                recs.append(r)
            recs = _merge(recs, from_text(text, src))
        elif kind == "image":
            note.update(status="needs_ocr", error="image material requires OCR; no text layer")
            return [], note, "image needs OCR"
        else:
            recs = from_text(raw.decode("utf-8", "replace"), src)
    except Exception as e:
        note.update(status="error", error=str(e))
        return [], note, str(e)
    note["records_found"] = len(recs)
    return recs, note, None


def lexicon():
    p = ROOT / "references" / "term_lexicon.json"
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def extract_terms(text):
    t = text.lower()
    terms = [m.group(0) for m in LATIN_RE.finditer(t) if len(m.group(0)) > 1]
    terms += [m.group(0) for m in CJK_RE.finditer(t)]
    terms = [w for w in terms if w not in STOP_EN and w not in STOP_ZH and not w.isdigit()]
    return terms, [a + " " + b for a, b in zip(terms, terms[1:])]


def build_qp(question, lx):
    terms, bigrams = extract_terms(question)
    core = sorted(set(terms), key=lambda x: (-len(x), x))
    syn, abb, xl = {}, {}, {}
    for t in core:
        for name, out, src in (("synonyms", syn, "synonyms"), ("abbreviations", abb, "abbreviations"),
                               ("cross_language", xl, "cross_language")):
            m = lx.get(src, {})
            if t in m:
                out[t] = [x for x in m[t] if x != t]
    for m in CAPS_RE.finditer(question):
        w = m.group(0).lower()
        if w not in core and w not in STOP_EN:
            core.append(w)
    return {"terms": core, "bigrams": bigrams, "synonyms": syn,
            "abbreviations": abb, "cross_language": xl}


def rec_text(rec):
    return ((rec.get("title") or "") + " " + " ".join(rec.get("keywords") or []) + " " +
            (rec.get("abstract") or "") + " " + (rec.get("venue") or "") + " " +
            " ".join(rec.get("authors") or [])).lower()


def score(rec, qp):
    title = (rec.get("title") or "").lower()
    kw = " ".join(rec.get("keywords") or []).lower()
    ab = (rec.get("abstract") or "").lower()
    ven = (rec.get("venue") or "").lower()
    txt = rec_text(rec)
    s, matched = 0.0, []
    for t in qp["terms"]:
        w = 0.8 if (t in qp["synonyms"] or t in qp["abbreviations"] or t in qp["cross_language"]) else 1.0
        if t in title:
            s += 3.0 * w
            matched.append(t)
        elif t in kw:
            s += 3.0 * w
            matched.append(t)
        elif t in ab:
            s += 2.0 * w
            matched.append(t)
        elif t in ven:
            s += 1.0 * w
            matched.append(t)
        elif t in txt:
            s += 0.5 * w
            matched.append(t)
    for b in qp["bigrams"]:
        if b in title:
            s += 2.0
            matched.append(b)
        elif b in ab:
            s += 1.0
            matched.append(b)
    return s, matched


def dedupe(records):
    groups, order = {}, []
    for rec in records:
        doi = (rec.get("doi") or "").strip().lower()
        k = "doi:" + doi if doi else "title:" + (rec.get("title") or "").strip().lower()
        if k in groups:
            groups[k]["merged"].append(rec.get("source", ""))
            cur = groups[k]["rec"]
            if len(rec.get("authors") or []) > len(cur.get("authors") or []) \
                    or (not cur.get("venue") and rec.get("venue")) \
                    or (not cur.get("year") and rec.get("year")):
                groups[k]["rec"] = rec
        else:
            groups[k] = {"rec": rec, "merged": [rec.get("source", "")]}
            order.append(k)
    out, notes = [], []
    for k in order:
        g = groups[k]
        rec = dict(g["rec"])
        rec["sources"] = sorted(set(g["merged"]))
        out.append(rec)
        if len(g["merged"]) > 1:
            notes.append({"key": k, "merged_sources": sorted(set(g["merged"])),
                          "kept_source": rec.get("source", "")})
    return out, notes


def read_case(indir):
    cp = Path(indir) / "case.json"
    if not cp.exists():
        return None, "case.json not found", None
    try:
        case = json.loads(cp.read_text(encoding="utf-8"))
    except (ValueError, OSError) as e:
        return None, "case.json invalid/unreadable: %s" % e, None
    task = ""
    tp = Path(indir) / "task.md"
    if tp.exists():
        try:
            task = tp.read_text(encoding="utf-8")
        except OSError:
            pass
    return case, None, task


def run(indir, workdir, outdir):
    Path(workdir).mkdir(parents=True, exist_ok=True)
    Path(outdir).mkdir(parents=True, exist_ok=True)
    changes, errors, degradations = [], [], []
    result = {"case_id": None, "status": "partial"}
    changes.append({"step": 1, "action": "start", "status": "ok"})
    case, err, task_text = read_case(indir)
    if err:
        errors.append(err)
        result.update(status="input_error", gaps=[{"kind": "input", "detail": err}])
        changes.append({"step": 2, "action": "read_case", "status": "error", "detail": err})
        _write(result, outdir, workdir, changes, errors, degradations, {})
        return
    case_id = case.get("case_id") or case.get("id") or None
    contract = case.get("output_contract", {})
    instr = case.get("task_instruction") or case.get("instruction") or ""
    question = (instr + "\n" + (task_text or "")).strip()
    result.update(case_id=case_id)
    changes.append({"step": 2, "action": "read_case", "status": "ok", "detail": str(case_id)})
    _write(result, outdir, workdir, changes, errors, degradations, contract)

    files = []
    skip = {"case.json", "task.md", "output", "work"}
    try:
        for p in sorted(Path(indir).rglob("*")):
            if not p.is_file():
                continue
            rel = p.relative_to(Path(indir))
            if rel.parts and rel.parts[0] in skip:
                continue
            if rel.name in skip:
                continue
            files.append(p)
    except OSError as e:
        errors.append("material discovery failed: %s" % e)
    if not files:
        degradations.append("no material files found under /input")

    records, sources = [], []
    for p in files:
        rel = str(p.relative_to(Path(indir)))
        recs, note, e2 = extract_file(p, rel)
        if e2:
            errors.append("%s: %s" % (rel, e2))
        records.extend(recs)
        sources.append(note)
    changes.append({"step": 3, "action": "extract", "status": "ok",
                    "detail": "%d files, %d records" % (len(files), len(records))})

    qp = build_qp(question, lexicon())
    srcs = [s["file"] for s in sources]
    rounds = [
        {"round": 1, "goal": "core terms", "query": " ".join(qp["terms"]), "terms": qp["terms"],
         "synonyms": [], "abbreviations": [], "cross_language": [], "sources": srcs,
         "results_count": 0, "note": "primary recall"},
        {"round": 2, "goal": "synonyms", "query": " ".join(qp["terms"] + [x for v in qp["synonyms"].values() for x in v]),
         "terms": qp["terms"], "synonyms": qp["synonyms"], "abbreviations": [], "cross_language": [],
         "sources": srcs, "results_count": 0, "note": "vocabulary expansion"},
        {"round": 3, "goal": "abbrev/lang", "query": " ".join(qp["terms"] + [x for v in qp["abbreviations"].values() for x in v] + [x for v in qp["cross_language"].values() for x in v]),
         "terms": qp["terms"], "synonyms": [], "abbreviations": qp["abbreviations"],
         "cross_language": qp["cross_language"], "sources": srcs, "results_count": 0,
         "note": "acronym & language variants"},
    ]

    uniq, dedup_notes = dedupe(records)
    scored = []
    for rec in uniq:
        s, matched = score(rec, qp)
        rec["relevance_score"] = round(s, 3)
        rec["matched_terms"] = sorted(set(matched))
        scored.append(rec)
    scored.sort(key=lambda r: (-r["relevance_score"], (r.get("title") or "").lower(),
                               (r.get("doi") or "").lower()))

    for rnd in rounds:
        terms = list(rnd["terms"])
        for key in ("synonyms", "abbreviations", "cross_language"):
            v = rnd[key]
            if isinstance(v, dict):
                terms += [x for lst in v.values() for x in lst]
        rnd["results_count"] = sum(1 for rec in scored if any(t in rec_text(rec) for t in terms))

    candidates = [r for r in scored if r["relevance_score"] > 0]
    excluded = [r for r in scored if r["relevance_score"] <= 0]
    degraded = False
    if not candidates and scored:
        candidates = scored
        excluded = []
        degradations.append("no term overlap; returning all extracted records as low-confidence candidates")
        degraded = True

    no_result = [{"round": r["round"], "query": r["query"],
                  "explanation": "no material record matched this round"} for r in rounds if r["results_count"] == 0]
    coverage = {
        "covered": [{"doi": r.get("doi") or "", "title": r.get("title") or "", "year": r.get("year") or ""}
                    for r in candidates],
        "excluded": [{"doi": r.get("doi") or "", "title": r.get("title") or "",
                      "reason": "no term overlap with research question"} for r in excluded],
        "no_result_queries": no_result,
        "total_records_seen": len(scored), "total_candidates": len(candidates),
        "deduplication": dedup_notes,
    }
    summary = {"total_material_files": len(files), "total_raw_records": len(records),
               "total_unique_records": len(scored), "total_candidates": len(candidates),
               "excluded_records": len(excluded), "no_result_queries": len(no_result)}
    bad = [s for s in sources if s.get("status") in ("error", "needs_ocr", "parse_error")]
    if bad or degraded:
        result["status"] = "partial"
        if bad:
            degradations.append("unreadable/OCR-needed materials: %s" % ", ".join(s["file"] for s in bad))
    elif not files:
        result["status"] = "insufficient_evidence"
    else:
        result["status"] = "complete"

    uncertainty = []
    for s in sources:
        if s.get("status") == "needs_ocr":
            uncertainty.append({"item": s["file"], "detail": "image not OCR'd; records inside not counted"})
        if s.get("extraction") == "minimal-stream":
            uncertainty.append({"item": s["file"], "detail": "PDF stream extraction; layout may be lossy"})
    if not question:
        uncertainty.append({"item": "research_question", "detail": "task_instruction empty"})
    if any(not r.get("quote_verified") for r in candidates):
        uncertainty.append({"item": "evidence_quote", "detail": "some quotes reconstructed (escaped JSON)"})

    method = {
        "decomposition": "stopword-free tokenization (Latin + CJK) + bigrams",
        "query_planning": "3 rounds: core / synonyms / abbreviations+cross-language against all local sources",
        "ranking": "weighted field match: title 3.0, keywords 3.0, abstract 2.0, venue 1.0, other 0.5, bigram +2.0/+1.0; nDCG/Precision@k orientation",
        "deduplication": "normalized DOI first, else normalized lower-case title",
        "traceability": "source file + JSON path/locator + verbatim quote",
        "limitations": "offline, source-bound; no live queries; no fabricated metadata",
    }
    result.update(
        research_question={"statement": instr or "(empty)", "context": task_text or ""},
        query_plan=rounds, candidates=candidates, excluded=excluded,
        deduplication=dedup_notes, ranking={"method": method["ranking"],
        "score_field": "relevance_score", "note": "ordered descending"},
        coverage_and_gaps=coverage, method=method, summary=summary, sources=sources,
        uncertainty=uncertainty)
    changes.append({"step": 4, "action": "finalize", "status": "ok",
                    "detail": "%d candidates" % len(candidates)})
    _write(result, outdir, workdir, changes, errors, degradations, contract)
    _report(result, outdir)


def _write(result, outdir, workdir, changes, errors, degradations, contract):
    final = dict(result)
    final["change_records"] = changes
    final["errors"] = errors
    final["degradations"] = degradations
    merged = {"case_id": final.get("case_id"), "status": final.get("status")}
    merged.update(fill_contract(contract, final))
    for k, v in final.items():
        merged.setdefault(k, v)
    ordered = {"case_id": merged["case_id"], "status": merged["status"]}
    for k, v in merged.items():
        if k not in ordered:
            ordered[k] = v
    Path(outdir).mkdir(parents=True, exist_ok=True)
    (Path(outdir) / "result.json").write_text(json.dumps(ordered, ensure_ascii=False, indent=2), encoding="utf-8")
    (Path(workdir) / "state.json").write_text(json.dumps(
        {"phase": "finalized", "candidate_count": len(final.get("candidates", [])),
         "status": final.get("status")}, ensure_ascii=False, indent=2), encoding="utf-8")


def _stype(spec):
    if isinstance(spec, dict):
        return str(spec.get("type") or ("array" if "items" in spec else "object"))
    if isinstance(spec, list):
        return "array"
    if isinstance(spec, str):
        return spec
    return "object"


def _default(spec):
    t = _stype(spec)
    return [] if t == "array" else {} if t == "object" else "" if t == "string" else None


CMAP = {"candidates": "candidates", "results": "candidates", "papers": "candidates",
        "literature": "candidates", "candidate_papers": "candidates", "candidate_set": "candidates",
        "paper_list": "candidates", "query_plan": "query_plan", "queries": "query_plan",
        "query": "query_plan", "research_question": "research_question", "question": "research_question",
        "coverage": "coverage_and_gaps", "gaps": "coverage_and_gaps", "omissions": "coverage_and_gaps",
        "coverage_and_gaps": "coverage_and_gaps", "deduplication": "deduplication", "dedup": "deduplication",
        "ranking": "ranking", "summary": "summary", "sources": "sources", "method": "method",
        "methodology": "method", "excluded": "excluded"}


def fill_contract(contract, canonical):
    out = {}
    items = contract.items() if isinstance(contract, dict) else \
        ((str(k), None) for k in contract) if isinstance(contract, list) else ()
    for k, spec in items:
        kl = k.lower()
        out[k] = canonical[CMAP[kl]] if (kl in CMAP and CMAP[kl] in canonical) else _default(spec)
    return out


def _cell(x):
    x = str(x).replace("|", "\\|").replace("\n", " ")
    return x[:117] + "..." if len(x) > 120 else x


def _report(result, outdir):
    L = ["# Source-bound literature retrieval report", "",
         "- case_id: `%s`" % (result.get("case_id") or "null"),
         "- status: `%s`" % result.get("status")]
    s = result.get("summary", {})
    L.append("- materials: %s | raw: %s | unique: %s | candidates: %s"
             % (s.get("total_material_files", 0), s.get("total_raw_records", 0),
                s.get("total_unique_records", 0), s.get("total_candidates", 0)))
    L += ["", "## Research question", ((result.get("research_question", {}) or {}).get("statement") or "(empty)")[:2000],
          "", "## Query plan"]
    for r in result.get("query_plan", []):
        L.append("- Round %s [%s]: `%s` -> %d hits" % (r.get("round"), r.get("goal"),
                 r.get("query"), r.get("results_count", 0)))
    L += ["", "## Candidates (ranked)",
          "| # | Title | Year | Venue | DOI | Source | Locator | Quote |",
          "|---|---|---|---|---|---|---|---|"]
    for i, c in enumerate(result.get("candidates", []), 1):
        L.append("| %d | %s | %s | %s | %s | %s | %s | %s |" % (i, _cell(c.get("title") or ""),
                 c.get("year") or "", c.get("venue") or "", c.get("doi") or "", c.get("source") or "",
                 c.get("locator") or "", _cell(c.get("quote") or "")))
    cov = result.get("coverage_and_gaps", {})
    L += ["", "## Coverage & gaps",
          "- no-result queries: %s" % len(cov.get("no_result_queries", []))]
    for q in cov.get("no_result_queries", []):
        L.append("  - round %s: `%s`" % (q.get("round"), q.get("query")))
    L.append("- excluded (no term overlap): %s" % len(cov.get("excluded", [])))
    L.append("- deduplicated groups: %s" % len(cov.get("deduplication", [])))
    if result.get("degradations"):
        L += ["", "## Degradations"] + ["- %s" % d for d in result["degradations"]]
    if result.get("errors"):
        L += ["", "## Errors"] + ["- %s" % e for e in result["errors"]]
    (Path(outdir) / "report.md").write_text("\n".join(L) + "\n", encoding="utf-8")


def cmd_init(workdir):
    Path(workdir).mkdir(parents=True, exist_ok=True)
    draft = {"schema_version": 1, "case_id": None, "status": "not_started",
             "research_question": None, "query_plan": [], "candidates": [],
             "deduplication": [], "coverage_and_gaps": {}, "sources": [],
             "uncertainty": [], "change_records": [],
             "note": "draft scaffold; default run regenerates everything from /input"}
    (Path(workdir) / "state.json").write_text(json.dumps(draft, ensure_ascii=False, indent=2), encoding="utf-8")
    print("initialized work draft at %s" % (Path(workdir) / "state.json"))


def cmd_show(outdir, workdir):
    rp = Path(outdir) / "result.json"
    if rp.exists():
        try:
            r = json.loads(rp.read_text(encoding="utf-8"))
        except ValueError:
            print("result.json is invalid JSON")
            return
        print("status=%s case_id=%s candidates=%d errors=%d degradations=%d"
              % (r.get("status"), r.get("case_id"), len(r.get("candidates", [])),
                 len(r.get("errors", [])), len(r.get("degradations", []))))
        return
    sp = Path(workdir) / "state.json"
    print(sp.read_text(encoding="utf-8") if sp.exists() else "no result.json or state.json yet")


def cmd_check(indir, outdir):
    rp = Path(outdir) / "result.json"
    if not rp.exists():
        print("CHECK FAIL: result.json missing")
        return 1
    try:
        r = json.loads(rp.read_text(encoding="utf-8"))
    except ValueError as e:
        print("CHECK FAIL: result.json invalid: %s" % e)
        return 1
    problems = []
    for k in ("case_id", "status", "sources", "uncertainty", "change_records"):
        if k not in r:
            problems.append("missing key %s" % k)
    case, err, _ = read_case(indir)
    if err:
        problems.append("case re-read failed: %s" % err)
    elif isinstance(case.get("output_contract"), dict):
        for k in case["output_contract"]:
            if k not in r:
                problems.append("contract key %s missing" % k)
    total = hit = 0
    for c in r.get("candidates", []):
        total += 1
        src, q = c.get("source"), c.get("quote")
        if not src or not q:
            problems.append("candidate missing source/quote: %s" % (c.get("doi") or c.get("title")))
            continue
        sp = Path(indir) / src
        if not sp.exists():
            problems.append("source file missing: %s" % src)
            continue
        try:
            raw = sp.read_bytes().decode("utf-8", "replace")
        except OSError:
            problems.append("source unreadable: %s" % src)
            continue
        if q in raw:
            hit += 1
        else:
            problems.append("quote miss in %s: %r" % (src, q[:80]))
    rate = (hit / total) if total else 1.0
    print("CHECK: candidates=%d quote_hit=%d/%d (%.3f) problems=%d" % (total, hit, total, rate, len(problems)))
    for p in problems[:30]:
        print("  - %s" % p)
    return 1 if problems else 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="main.py",
        description="Source-bound academic literature retrieval (offline).")
    ap.add_argument("command", nargs="?", default="run", help="run|init|show|check|build")
    ap.add_argument("--input", default=env_or("INPUT_DIR", "/input"))
    ap.add_argument("--work", default=env_or("WORK_DIR", "/app/work"))
    ap.add_argument("--output", default=env_or("OUTPUT_DIR", "/app/output"))
    a = ap.parse_args(argv)
    code = 0
    try:
        if a.command == "init":
            cmd_init(a.work)
        elif a.command == "show":
            cmd_show(a.output, a.work)
        elif a.command == "check":
            code = cmd_check(a.input, a.output)
        else:
            run(a.input, a.work, a.output)
    except SystemExit:
        raise
    except Exception as e:
        try:
            out = Path(a.output)
            out.mkdir(parents=True, exist_ok=True)
            (out / "result.json").write_text(json.dumps({
                "case_id": None, "status": "input_error",
                "errors": ["unhandled exception: %r" % e], "sources": [],
                "uncertainty": [], "change_records": [], "degradations": ["unhandled exception"]},
                ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
        sys.stderr.write("error: %r\n" % e)
    return code


if __name__ == "__main__":
    sys.exit(main())

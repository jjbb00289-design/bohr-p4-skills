---
name: source-bound-literature-search
description: >-
  Offline, source-bound academic literature retrieval. Decompose a research
  question, plan multi-round queries with synonym/abbreviation/cross-language
  expansion, extract candidate papers from provided Crossref/EuropePMC/publisher
  responses, reference graphs and local import states, de-duplicate, rank by
  relevance, and return traceable results with per-item source locator and
  verbatim evidence quote. Never invents DOIs/authors/years/venues/full text;
  never calls the live network.
version: 1.0.0
---

# 学术文献检索（离线、source-bound）

## 用途
围绕给定科研问题，在**组织方提供的本地材料**（Crossref / EuropePMC / publisher 响应、reference graph、本地增量导入状态、PDF/DOCX/SQLite/CSV 等）上完成检索：问题拆解 → 多轮查询规划（同义词/缩写/跨语言扩展）→ 候选召回 → 去重与来源记录 → 相关性排序 → 覆盖与遗漏说明。输出可被复核的 `result.json` 与人类可读 `report.md`。

本技能**不联网**，不声称"实时检索/最新文献"，不编造 DOI、作者、年份、期刊、全文、软件状态或检索结果。

## 触发条件
- 任务要求"围绕科研问题检索并筛选文献、输出可追溯候选集与筛选依据"。
- 输入为 `/input/case.json` + `/input/task.md` + 材料文件，需要产出 `result.json`。
- 材料以本地文件给出（Crossref/EuropePMC/publisher 响应、引用图、导入状态），而非实时联网检索。

## 调用方式（默认单命令 = 完整流程）
```
python /skills/weekly-skill/scripts/main.py
```
默认读取 `/input`，工作目录 `/app/work`，产物目录 `/app/output`。可用环境变量或参数覆盖：
```
INPUT_DIR=/path/to/input WORK_DIR=/path/to/work OUTPUT_DIR=/path/to/output python scripts/main.py
# 或
python scripts/main.py --input ... --work ... --output ...
```
子命令：`init`（生成空工作稿）| `show`（查看状态）| `check`（校验 result.json）| `build`（等价完整流程）。无工作稿时默认命令也会从 `/input` 真实派生完整交付。

Agent 执行步骤（供 Harness 遵循）：
1. 若有 PDF/DOCX/图片等二进制材料且脚本未能抽取文本，先用平台提供的 pdf-text-tool / ocr-tool 预抽取到 `/app/work`，再将文本放入 `/input`（或运行 `main.py`，脚本自带 pdftotext/DOCX/SQLite 抽取）。
2. 运行 `python scripts/main.py` 完成全流程。
3. 运行 `python scripts/main.py check` 校验产物；若有问题按校验输出修正输入或降级说明。
4. 退出码恒为 0；异常均落入 `errors`/`degradations`，不崩溃、不产生 0 字节结果。

## 输入输出
- 输入：`/input/case.json`（含 `case_id`、`task_instruction`、`output_contract`）、`/input/task.md`、若干材料文件。
- 中间：`/app/work/state.json`（工作稿状态）。
- 输出：`/app/output/result.json`（主交付，回填 output_contract 每个字段 + `case_id`/`status`/`sources`/`uncertainty`/`change_records`/`errors`/`degradations`）+ `/app/output/report.md`。

## 工作稿 schema（work/state.json）
```json
{
  "schema_version": 1,
  "case_id": null,
  "status": "not_started",
  "research_question": null,
  "query_plan": [],
  "candidates": [],
  "deduplication": [],
  "coverage_and_gaps": {},
  "sources": [],
  "uncertainty": [],
  "change_records": []
}
```
`init` 仅生成脚手架；默认命令不依赖该草稿，始终从 `/input` 重新派生。

## 证据规范（每条候选必须可复核）
每条 candidate 至少含：
- `source`：材料文件相对路径；
- `locator`：JSON 路径（如 `message.items[3]`）或文本行号 `line N`；
- `quote`：材料原文中逐字命中的片段（标题/DOI/authors，按原始编码回退匹配）；
- `quote_verified`：布尔，标记 quote 是否在原文逐字命中；
- `matched_terms`：命中该记录的查询词；
- `relevance_score`：相关性得分。

红线：每个结论/条目都要能指回 `source` + `locator` + `quote`；无结果的 query 也保留在 `coverage_and_gaps.no_result_queries` 并说明；禁止 placeholder / "array"/"object" / 空契约键（缺值用 `null`/`[]`）。

## 降级表
| 情况 | 识别 | 处置 | status |
|---|---|---|---|
| 空输入（无 case.json） | `/input/case.json` 不存在 | 写合法 partial，`errors` 记录 | `input_error` |
| 坏 JSON | `case.json` 解析失败 | 同上，注明错误 | `input_error` |
| 缺材料 | 无任何材料文件 | `degradations` 说明 | `insufficient_evidence` |
| 材料不可读/权限不足 | 读取抛 OSError | 该源标 `error`，其余继续 | `partial` |
| 图片/表格无文本层 | 需要 OCR | 该源标 `needs_ocr`，`uncertainty` 记录 | `partial` |
| PDF 无文本层/无 pdftotext | 抽取为空 | 标 `extraction=none`，`uncertainty` 记录 | `partial` |
| 无查询词命中 | 记录相关性全为 0 | 返回全部抽取记录并注明低置信 | `partial` |
| 重复记录 | DOI/标题归一化冲突 | 合并，记入 `deduplication` | 不变 |

## 自检
- `python scripts/main.py --help` 正常退出。
- `python scripts/main.py check` 校验 result.json：契约键齐全、quote 逐字命中率 ≥0.95。
- 两次全新输出目录各跑一次，产物结构一致（确定性，无时间戳/随机）。

## 限制
- 仅 source-bound：候选只来自本地材料，不联网补全、不生成"最新"文献。
- 不负责单篇全文解析、写作润色、资料库整理。
- 术语扩展依赖 `references/term_lexicon.json`（起步词表，非穷尽）。
- 图片内文献需外部 OCR 工具；纯 stdlib 无法识别。

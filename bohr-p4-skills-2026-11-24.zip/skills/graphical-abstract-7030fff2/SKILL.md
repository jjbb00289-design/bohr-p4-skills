---
name: graphical-abstract-figure
description: Compress a paper or study description into a single-page graphical abstract: a four-panel reading path (study system, mechanism, key result, implication) whose nodes and arrows come from the material text, each with a locator and verbatim quote, so every element can be traced back to the source.
version: 6.0
---

# Graphical abstract generator

Produces one figure that carries the study's system, its mechanism, the key
result and the implication, laid out as a four-panel reading path. Panels and
arrows are filled from the material itself: nothing is invented to make the
picture look complete.

## One command

```bash
python3 scripts/main.py
```

`init`, `build`, `check`, `selfcheck` are aliases:
`python3 scripts/main.py build --input /input --work /work --output /output`.

## Reading path (four panels)

| panel | holds | chosen from |
|---|---|---|
| a | study system — the entities named first | entities by first mention |
| b | mechanism — entities linked by activation/inhibition/binding | next group in mention order |
| c | key result — entities tied to a direction (increase / reduce) | next group |
| d | implication — downstream entities and their targets | last group |

Panel titles are the first entity of that panel, so the header text is itself a
traceable term rather than a fixed label.

## What is derived, and how

1. **Text** — linear PDF content-stream scanner (correct spacing, restored ligatures)
   plus markdown/text/CSV/DOCX/PPTX readers.
2. **Chunks** — locator-bearing chunks (`m1#p4`); short study notes use a lower
   frequency floor so they still yield their entities.
3. **Entities** — acronyms, capitalised phrases and noun phrases headed by
   system/process words (`cascade`, `membrane`, `complex`, `pathway`, `loop`,
   `apoptosis`, `block`, `nucleus`, …). Word-bounded matching keeps `EGF` and
   `EGFR` distinct.
4. **Relations** — every relation verb in a sentence is considered; source is the
   nearest entity before the verb, target the nearest after it. No verb, or only
   one side → no arrow.
5. **Style** — activation solid blue arrow, inhibition blunt red bar, binding
   dashed with circle, transformation amber arrow, composition/association grey.
   The legend lists exactly the types drawn.

## Provenance and verification

- Each relation's quote is a 12–20 word contiguous span, verified by word-level
  containment against the material and against a second naive extractor;
  `quote_hit_rate >= 0.95` or the run downgrades to `status=partial`.
- Relations scoring below 0.9 are dropped instead of drawn.
- Placeholder tokens (`Entity`, `Node`, `Item`, `TBD`, `示例`, `占位`) are rejected
  as labels.
- `figure.svg` carries `<text>` plus layered `<g id="layer-…">`; `figure.png` is
  rendered with an embedded 5x7 font so the raster shows the labels.

## Outputs

`figure.svg`, `figure.png`, `figure.pdf`, `figure_model.json`, `content_map.json`
(every label → locator + quote), `compliance_checks.json`,
`edit_record.json`, `self_check.json`, `run.log`, `result.json` (with `case_id`,
`status`, `result`, `claims`, `coverage`).

## Degraded inputs

Empty, malformed or material-free input still writes every contract key, exits 0,
and reports `status=partial` (`input_error` when nothing was scanned) with a
`gaps` list — never a fabricated panel.

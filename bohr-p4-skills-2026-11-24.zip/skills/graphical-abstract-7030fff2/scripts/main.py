"""Figure skill entry point.

One command (`python3 scripts/main.py`) runs the whole pipeline: scan /input,
extract text, derive entities/relations with verbatim provenance, render
SVG/PNG/PDF, verify quotes and write result.json. `init` / `build` / `check` /
`selfcheck` are aliases over the same pipeline so the platform harness can call
any of them.

Contract: always exits 0 and always leaves a result.json that echoes every
output_contract key, including degraded/empty inputs.
"""
import argparse
import json
import re
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import extract as X          # noqa: E402
import pdftext as P          # noqa: E402
import render as R           # noqa: E402

VERSION = "6.0"
CONTRACT_KEYS = ["case_id", "status", "result", "claims", "coverage"]
PLACEHOLDER = re.compile(r"\b(Entity|Node|Item|Slide|TBD|TODO|Lorem|placeholder|示例|占位)\b", re.I)
TEXT_EXT = {".md", ".txt", ".csv", ".tsv", ".json", ".yaml", ".yml", ".rst", ".tex"}
SKIP = {"case.json"}


def jdump(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True),
                          encoding="utf-8")


def jload(path, default=None):
    try:
        raw = Path(path).read_bytes()
    except Exception:
        return default
    for enc in ("utf-8-sig", "utf-8", "gb18030", "latin-1"):
        try:
            return json.loads(raw.decode(enc))
        except Exception:
            continue
    return default


def parse_args(argv):
    cmd = "auto"
    ns = {"input": None, "work": None, "output": None}
    i = 0
    while i < len(argv):
        a = argv[i]
        hit = False
        for k in ("input", "work", "output"):
            if a == "--" + k and i + 1 < len(argv):
                ns[k] = argv[i + 1]
                i += 2
                hit = True
                break
            if a.startswith("--" + k + "="):
                ns[k] = a.split("=", 1)[1]
                i += 1
                hit = True
                break
        if hit:
            continue
        if not a.startswith("-") and cmd == "auto":
            cmd = a
        i += 1
    return cmd, ns


def resolve(ns):
    def pick(key, default):
        raw = ns.get(key) or default
        p = Path(raw)
        if raw == default and not p.exists():
            alt = Path(default.lstrip("/"))
            if alt.exists():
                return alt.resolve()
        return p.resolve()
    return pick("input", "/input"), pick("work", "/work"), pick("output", "/output")


def read_text_file(path, limit=3_000_000):
    try:
        raw = Path(path).read_bytes()
    except Exception:
        return ""
    for enc in ("utf-8", "utf-8-sig", "gb18030", "latin-1"):
        try:
            return raw.decode(enc)[:limit]
        except Exception:
            continue
    return raw.decode("utf-8", "replace")[:limit]


def office_text(path):
    try:
        with zipfile.ZipFile(path) as zf:
            names = [n for n in zf.namelist() if n.endswith(".xml")]
            chunks = []
            for n in sorted(names)[:40]:
                body = zf.read(n).decode("utf-8", "replace")
                chunks += re.findall(r"<a:t>(.*?)</a:t>|<w:t[^>]*>(.*?)</w:t>", body)
            flat = []
            for tup in chunks:
                flat.append(tup[0] or tup[1])
            return "\n".join(x for x in flat if x)
    except Exception:
        return ""


def discover(inp):
    mats = []
    root = Path(inp)
    if not root.exists():
        return mats
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.name.startswith(".") or p.name in SKIP:
            continue
        suffix = p.suffix.lower()
        rec = {"material_id": "m%d" % (len(mats) + 1), "rel": p.name, "suffix": suffix,
               "bytes": p.stat().st_size, "text": "", "kind": "other"}
        try:
            if suffix == ".pdf":
                rec["text"], rec["pages"], ratio = P.pdf_text(p)
                rec["kind"] = "pdf"
                rec["alpha_ratio"] = round(ratio, 3)
                try:
                    rec["naive"] = P.naive_text(p)
                except Exception:
                    rec["naive"] = ""
            elif suffix in TEXT_EXT:
                rec["text"] = read_text_file(p)
                rec["kind"] = "table" if suffix in (".csv", ".tsv") else "text"
            elif suffix in (".docx", ".pptx"):
                rec["text"] = office_text(p)
                rec["kind"] = "office"
            elif suffix == ".svg":
                body = read_text_file(p)
                rec["text"] = " ".join(re.findall(r"<text[^>]*>(.*?)</text>", body, re.S))
                rec["kind"] = "svg"
        except Exception as exc:
            rec["error"] = str(exc)
        rec["text_chars"] = len(rec["text"] or "")
        mats.append(rec)
    return mats


def case_terms(case):
    out = []
    if not isinstance(case, dict):
        return out
    for key in ("workorder", "entities", "nodes", "objects", "targets"):
        val = case.get(key)
        if isinstance(val, list):
            for v in val:
                if isinstance(v, str):
                    out.append(v)
                elif isinstance(v, dict):
                    for k in ("label", "name", "id", "term"):
                        if isinstance(v.get(k), str):
                            out.append(v[k])
    return out[:20]


def merge_models(models):
    """Merge per-material models into one canonical graph."""
    canon, order, first = {}, [], {}
    chunks = {}
    rels, seen = [], set()
    for mod in models:
        for c in mod.get("chunks") or []:
            chunks[c["locator"]] = c["text"]
        for e in mod.get("entities") or []:
            low = e.lower()
            if low not in canon:
                canon[low] = e
                order.append(e)
        for e in mod.get("entities") or []:
            lab = canon[e.lower()]
            if lab not in first and e in (mod.get("first") or {}):
                first[lab] = mod["first"][e]
        for r in mod.get("relations") or []:
            src, tgt = canon.get(r["source"].lower()), canon.get(r["target"].lower())
            if not src or not tgt or src == tgt:
                continue
            key = (src, tgt, r["type"])
            if key in seen:
                continue
            seen.add(key)
            item = dict(r, source=src, target=tgt)
            rels.append(item)
    return {"entities": order, "relations": rels, "first": first, "chunks": chunks}


def derive(mats, case):
    terms = case_terms(case)
    ref_raw = [m.get("naive") or m.get("text") or "" for m in mats]
    reference = re.sub(r"\s+", "", "\n".join(ref_raw)).lower()
    models = []
    for m in mats:
        text = m.get("text") or ""
        if len(text.strip()) < 40:
            continue
        models.append(X.build_model(text, case_terms=terms, prefix=m["material_id"],
                                    reference=reference))
    return merge_models(models)


def from_plan(plan, mats):
    """Agent-authored plan: same schema as the derived model."""
    ents, rels, first, chunks = [], [], {}, {}
    for m in mats:
        for c in X.chunk_text(X.strip_refs(X.normalize(m.get("text") or "")),
                              prefix=m["material_id"]):
            chunks[c["locator"]] = c["text"]
    for e in plan.get("entities") or []:
        if isinstance(e, str):
            ents.append(e)
        elif isinstance(e, dict):
            label = e.get("label") or e.get("name") or e.get("id")
            if label:
                ents.append(label)
                if e.get("locator"):
                    first[label] = (e["locator"], e.get("quote") or "")
    for r in plan.get("relations") or []:
        src = r.get("source") or r.get("from")
        tgt = r.get("target") or r.get("to")
        if not src or not tgt:
            continue
        rels.append({"source": src, "target": tgt, "type": r.get("type") or "association",
                     "verb": r.get("verb") or r.get("label") or "associates",
                     "locator": r.get("locator") or "", "quote": r.get("quote") or "",
                     "source_sentence": r.get("source_sentence") or r.get("quote") or ""})
    return {"entities": ents, "relations": rels, "first": first, "chunks": chunks}


def content_map(model):
    """Every drawn label -> provenance (locator + verbatim quote)."""
    out = []
    first = model.get("first") or {}
    for e in model.get("entities") or []:
        loc, quote = first.get(e, ("", ""))
        out.append({"text": e, "kind": "node", "locator": loc, "quote": quote[:220]})
    for r in model.get("relations") or []:
        out.append({"text": r.get("verb") or r["type"], "kind": "edge",
                    "locator": r.get("locator"), "quote": (r.get("quote") or "")[:220]})
    types = []
    for r in model.get("relations") or []:
        if r["type"] not in types:
            types.append(r["type"])
            out.append({"text": r["type"], "kind": "legend", "locator": r.get("locator"),
                        "quote": (r.get("quote") or "")[:220]})
    return out


def run(cmd, ns):
    inp, work, out = resolve(ns)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)

    case = jload(inp / "case.json", None)
    case_id = ""
    if isinstance(case, dict):
        case_id = str(case.get("case_id") or case.get("id") or "")

    prof = jload(HERE.parent / "references" / "figure_profile.json", None)
    if isinstance(prof, dict) and prof.get("extra_verbs"):
        X.set_extra_verbs(prof["extra_verbs"])
    panel_count = int(prof.get("panel_count", 2)) if isinstance(prof, dict) else 2

    mats = discover(inp) if cmd != "selfcheck" else discover(inp)
    errors, gaps = [], []

    # ---- plan (agent-authored) takes precedence
    plan = jload(work / "plan.json", None)
    if plan is not None and not isinstance(plan, dict):
        gaps.append("work/plan.json is not a JSON object; ignored")
        plan = None

    if isinstance(plan, dict) and (plan.get("entities") or plan.get("relations")):
        model = from_plan(plan, mats)
        source = "plan"
    else:
        model = derive(mats, case)
        source = "derived"

    if not [m for m in mats if (m.get("text_chars") or 0) > 0]:
        gaps.append("no readable text material was found in the input")

    # ---- provenance verification
    chunk_map = model.get("chunks") or {}
    pairs = [((r.get("locator") or ""), r.get("quote") or "") for r in model["relations"]]
    pairs += [((e.get("locator") or ""), e.get("quote") or "") for e in content_map(model)]
    ver = X.verify_quotes([p for p in pairs if p[1]], chunk_map)

    labels = [e for e in model["entities"]]
    bad_labels = [l for l in labels if PLACEHOLDER.search(l)]
    if bad_labels:
        gaps.append("placeholder-like labels rejected: %s" % bad_labels[:3])

    if len(model["entities"]) < 2:
        gaps.append("fewer than 2 entities could be derived")
    if len(model["relations"]) < 1:
        gaps.append("no relation with both endpoints and a relation verb was found")
    if ver["quote_hit_rate"] < 0.95:
        gaps.append("quote hit rate %.2f below 0.95" % ver["quote_hit_rate"])

    if not mats:
        status = "input_error"
    elif not [m for m in mats if (m.get("text_chars") or 0) > 0]:
        status = "insufficient_evidence"
    elif gaps:
        status = "partial"
    else:
        status = "ok"

    # ---- render
    title = (case.get("title") if isinstance(case, dict) else "") or "Figure 1"
    model_out = {
        "figure_id": "Figure 1",
        "title": str(title)[:90],
        "subtitle": "%d entities / %d relations derived from %s" % (
            len(model["entities"]), len(model["relations"]),
            ", ".join(m["rel"] for m in mats[:3]) or "no material"),
        "entities": model["entities"],
        "relations": model["relations"],
        "panels": [],
        "legend": [],
        "footer": "source locators: %s | quote hit rate %.2f | %s" % (
            source, ver["quote_hit_rate"], VERSION),
        "panel_count": panel_count,
    }
    model["panel_count"] = panel_count
    panels, nodes, order = R.layout(model)
    model_out["panels"] = [{"id": p["id"], "badge": p["badge"], "title": p["title"],
                            "count": p["count"]} for p in panels]
    types = []
    for r in model["relations"]:
        if r["type"] not in types:
            types.append(r["type"])
    model_out["legend"] = types

    exports, artifacts = {}, {}
    try:
        exports["svg"] = R.render_svg(model_out, out / "figure.svg")
        artifacts["svg"] = "figure.svg"
    except Exception as exc:
        errors.append("svg render failed: %s" % exc)
    try:
        exports["png"] = R.render_png(model_out, out / "figure.png")
        artifacts["png"] = "figure.png"
    except Exception as exc:
        errors.append("png render failed: %s" % exc)
    try:
        exports["pdf"] = R.render_pdf(model_out, out / "figure.pdf")
        artifacts["pdf"] = "figure.pdf"
    except Exception as exc:
        errors.append("pdf render failed: %s" % exc)

    c_map = content_map(model)
    jdump(out / "content_map.json", c_map)
    jdump(out / "figure_model.json", model_out)
    artifacts.update({"content_map": "content_map.json", "figure_model": "figure_model.json"})
    jdump(work / "index.json", [{"material_id": m["material_id"], "rel": m["rel"],
                                 "kind": m["kind"], "text_chars": m.get("text_chars", 0),
                                 "bytes": m["bytes"]} for m in mats])

    # ---- export instrumentation (what the artefacts actually contain)
    svg_text_count = 0
    if (out / "figure.svg").exists():
        svg_text_count = (out / "figure.svg").read_text(encoding="utf-8",
                                                        errors="replace").count("<text")
    pdf_tj_count = 0
    if (out / "figure.pdf").exists():
        pdf_tj_count = len(re.findall(rb"(?:Tj|TJ)", (out / "figure.pdf").read_bytes()))
    png_ratio = (exports.get("png") or {}).get("nonwhite_ratio", 0.0)
    png_ok = (out / "figure.png").exists() and \
        (out / "figure.png").read_bytes()[:8] == b"\x89PNG\r\n\x1a\n"
    pdf_ok = (out / "figure.pdf").exists() and \
        (out / "figure.pdf").read_bytes()[:5] == b"%PDF-"

    compliance = {
        "svg_text_count": svg_text_count,
        "pdf_tj_count": pdf_tj_count,
        "png_nonwhite_ratio": png_ratio,
        "entities": len(model["entities"]),
        "relations": len(model["relations"]),
        "quote_hit_rate": ver["quote_hit_rate"],
        "png_header_ok": png_ok,
        "pdf_header_ok": pdf_ok,
        "layers": 6,
        "checks": [
            {"id": "svg_has_text", "ok": svg_text_count >= max(1, len(model["entities"])),
             "detail": "%d <text> for %d entities" % (svg_text_count, len(model["entities"]))},
            {"id": "pdf_has_text_ops", "ok": pdf_tj_count >= min(4, max(1, len(model["entities"]))),
             "detail": "%d Tj/TJ operators" % pdf_tj_count},
            {"id": "png_draws_labels", "ok": png_ratio >= 0.03,
             "detail": "non-white pixel ratio %.3f" % png_ratio},
            {"id": "quotes_verbatim", "ok": ver["quote_hit_rate"] >= 0.95,
             "detail": "%d/%d quotes hit" % (ver["hits"], ver["checked"])},
            {"id": "no_placeholder_labels", "ok": not bad_labels,
             "detail": "placeholder labels: %s" % (bad_labels[:3] or "none")},
        ],
    }
    jdump(out / "compliance_checks.json", compliance)
    artifacts["compliance_checks"] = "compliance_checks.json"

    edit_record = {
        "case_id": case_id,
        "mode": source,
        "source_materials": [{"material_id": m["material_id"], "rel": m["rel"],
                              "kind": m["kind"], "text_chars": m.get("text_chars", 0),
                              "bytes": m["bytes"]} for m in mats],
        "created": [{"path": "figure.svg", "kind": "vector",
                     "labels": svg_text_count},
                    {"path": "figure.png", "kind": "raster",
                     "nonwhite_ratio": png_ratio},
                    {"path": "figure.pdf", "kind": "text-layer pdf",
                     "text_operators": pdf_tj_count}],
        "changes": [{"what": "entity graph", "detail": "%d entities, %d relations" % (
            len(model["entities"]), len(model["relations"]))},
            {"what": "panels", "detail": "%d panels (%s)" % (
                len(panels), ", ".join(p["badge"] for p in panels))}],
        "provenance": {"quotes_checked": ver["checked"], "quotes_hit": ver["hits"],
                       "quote_hit_rate": ver["quote_hit_rate"]},
        "untouched": "no material was modified; the figure is additive only",
    }
    jdump(out / "edit_record.json", edit_record)
    artifacts["edit_record"] = "edit_record.json"

    self_check = {
        "passed": bool(compliance["checks"] and all(c["ok"] for c in compliance["checks"])),
        "checks": compliance["checks"],
        "status": status,
        "gaps": gaps,
        "errors": errors,
    }
    jdump(out / "self_check.json", self_check)
    artifacts["self_check"] = "self_check.json"

    run_lines = [
        "figure pipeline %s" % VERSION,
        "command: %s" % cmd,
        "materials: %d (%d with text)" % (len(mats), sum(1 for m in mats if m.get("text_chars"))),
        "text chars: %d" % sum(m.get("text_chars") or 0 for m in mats),
        "mode: %s" % source,
        "entities: %d, relations: %d, panels: %d" % (
            len(model["entities"]), len(model["relations"]), len(panels)),
        "quotes: %d checked, %d hit, rate %.3f" % (ver["checked"], ver["hits"],
                                                   ver["quote_hit_rate"]),
        "exports: svg %d <text>, png nonwhite %.3f, pdf %d Tj" % (
            svg_text_count, png_ratio, pdf_tj_count),
        "status: %s" % status,
        "gaps: %s" % ("; ".join(gaps) if gaps else "none"),
        "errors: %s" % ("; ".join(errors) if errors else "none"),
    ]
    (out / "run.log").write_text("\n".join(run_lines) + "\n", encoding="utf-8")
    artifacts["run_log"] = "run.log"

    # ---- status
    claims = [{"claim": "%s %s %s" % (r["source"], r.get("verb") or r["type"], r["target"]),
               "locator": r.get("locator"), "quote": (r.get("quote") or "")[:300],
               "evidence": {"type": "sentence", "id": r.get("locator")},
               "relation_type": r["type"]} for r in model["relations"]]

    coverage = {
        "materials": len(mats),
        "text_materials": sum(1 for m in mats if (m.get("text_chars") or 0) > 0),
        "text_chars": sum(m.get("text_chars") or 0 for m in mats),
        "entities": len(model["entities"]),
        "relations": len(model["relations"]),
        "relation_types": types,
        "quotes_checked": ver["checked"],
        "quotes_hit": ver["hits"],
        "quote_hit_rate": ver["quote_hit_rate"],
        "labels": len(c_map),
        "labels_with_provenance": sum(1 for c in c_map if c.get("quote")),
        "panels": len(panels),
    }

    base = {
        "case_id": case_id,
        "status": status,
        "result": {"deliverable": "figure.svg",
                   "vector": "figure.svg", "raster": "figure.png", "pdf": "figure.pdf",
                   "entities": len(model["entities"]), "relations": len(model["relations"]),
                   "panels": len(panels), "legend_items": len(types)},
        "claims": claims,
        "coverage": coverage,
        "figure_model": model_out,
        "content_map": c_map,
        "exports": {
            "svg": {"path": "figure.svg", "layers": 6,
                    "text_elements": (exports.get("svg") or {}).get("text_elements", 0)},
            "png": {"path": "figure.png",
                    "header_ok": (out / "figure.png").exists()
                    and (out / "figure.png").read_bytes()[:8] == b"\x89PNG\r\n\x1a\n"},
            "pdf": {"path": "figure.pdf",
                    "pages": 1,
                    "header_ok": (out / "figure.pdf").exists()
                    and (out / "figure.pdf").read_bytes()[:5] == b"%PDF-"},
        },
        "provenance": {"quote_checked": ver["checked"], "quote_misses": ver["misses"][:5],
                       "quote_hit_rate": ver["quote_hit_rate"]},
        "gaps": gaps,
        "errors": errors,
        "materials": [{"material_id": m["material_id"], "rel": m["rel"], "kind": m["kind"],
                       "text_chars": m.get("text_chars", 0)} for m in mats],
        "pipeline": {"mode": source, "version": VERSION,
                     "steps": ["scan", "extract", "derive", "verify", "render", "report"]},
        "skill": {"name": "research-figure", "version": VERSION},
    }
    contract = (case or {}).get("output_contract") if isinstance(case, dict) else None
    if isinstance(contract, dict):
        for k, v in contract.items():
            base.setdefault(k, v)
    for k in CONTRACT_KEYS:
        base.setdefault(k, "" if k != "result" else {})
    base["case_id"] = case_id

    jdump(out / "result.json", base)
    print(json.dumps({"ok": True, "command": cmd, "status": status, "case_id": case_id,
                      "entities": len(model["entities"]), "relations": len(model["relations"]),
                      "quote_hit_rate": ver["quote_hit_rate"], "panels": len(panels),
                      "gaps": gaps[:4], "errors": errors[:4]},
                     ensure_ascii=False, indent=2, sort_keys=True))
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    cmd, ns = parse_args(argv)
    try:
        return run(cmd, ns)
    except Exception as exc:                                    # noqa: BLE001
        try:
            _, _, out = resolve(ns)
            out.mkdir(parents=True, exist_ok=True)
            case = jload(out / "result.json", {}) or {}
            base = {"case_id": case.get("case_id", ""), "status": "partial",
                    "result": {}, "claims": [], "coverage": {},
                    "errors": ["fatal: %s" % exc], "gaps": ["pipeline aborted"]}
            for k in CONTRACT_KEYS:
                base.setdefault(k, "" if k != "result" else {})
            jdump(out / "result.json", base)
            print(json.dumps({"ok": True, "status": "partial", "error": str(exc)},
                             ensure_ascii=False))
        except Exception:                                       # noqa: BLE001
            pass
        return 0


if __name__ == "__main__":
    sys.exit(main())

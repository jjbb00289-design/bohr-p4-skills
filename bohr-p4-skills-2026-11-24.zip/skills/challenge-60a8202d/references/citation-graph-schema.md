# 引文追踪可复用参考：字段别名、来源分类与去重键

供 SKILL.md 与脚本实现对齐。字段名大小写不敏感。

## 1. 文献字段别名（取首个非空）

- 标题：title / article-title / article_title / paper_title / name / item_title / publication_title（列表取第 0 项）
- DOI：doi / prism:doi / doi_url；`id` 字段若匹配 `10.\d{4,9}/...` 也视为 DOI
- 作者：author / authors / creator / creators / authorString（字符串按 `,;and` 切分；对象取 family+given）
- 年份：year / pubyear / pub_year / publication_year / published_year / issue_year；或 published/issued/created/published-print/published-online/date 的 `date-parts[0][0]` 或四位数
- 出处：container-title / container_title / journal / journal_title / journalInfo / venue / source / publication / booktitle

## 2. 来源分类（按结构特征，不按文件名）

- Crossref：`message.items[]`，含 `reference[]`（后向）、`is-referenced-by-count`（前向计数）
- EuropePMC：`resultList.result[]`，含 `references[]`、`citedByCount`
- 出版商：`records/items/citations/references/cited_by` 等容器
- 引用图：`nodes`（节点）+ `edges/links`（边，`from/source/citing → to/target/cited`）
- 增量导入状态：`imported/pending/state/batch/updated` 状态字段，仅作状态证据，不产生候选

## 3. 引用边方向判定（逐条回指材料）

- `reference(s)/citations/cited_references/bibliography` = 后向（本论文 → 被引文献）
- `cited_by/citedBy/citing/is-referenced-by` = 前向（施引文献 → 本论文）
- 引用图边 `from→to` 默认 `from cites to`；若只有被引列表无方向，记 `dir=unknown` 并说明
- 方向冲突时以更明确的字段为准，冲突记入 uncertainty

## 4. 身份去重键（顺序匹配，命中即合并）

1. DOI 精确（规范化：小写、去尾标点、去 `doi:` 前缀）
2. 标题归一 + 第一作者姓 + 年份（±1）
3. 标题 token Jaccard ≥ 0.85 + 作者交集 ≥1 + 年份窗口

同名不同文（DOI 不同）不得合并；合并组必须保留逐条 source+locator+title/doi 证据。

## 5. 证据规范

每条候选/边带 `source_file`（相对 /input 的路径）+ `locator`（JSON 路径 / 行号 / 页号 / 表名）+ 逐字 `quote`；quote 在材料原文中可命中（忽略大小写与空白折叠）。

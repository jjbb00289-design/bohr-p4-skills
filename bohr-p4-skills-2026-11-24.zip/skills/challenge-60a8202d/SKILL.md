---
name: citation-tracing
description: 从种子论文出发，基于本地 Crossref/EuropePMC/出版商响应、引用图与增量导入状态做前向/后向引文追踪、身份合并与关联文献发现，输出可追溯候选集与证据。当任务要求沿引用关系扩展文献、去重合并论文版本、解释引用路径或发现关联文献时使用。
version: 1.0.0
---

# 引文追踪与关联文献发现（source-bound / 离线）

## 1. 用途与适用条件

本 Skill 完成「顺藤摸瓜」式科研检索：以一篇或多篇种子论文为起点，利用**组织方已放置在本地的真实数据**（Crossref / EuropePMC / 出版商响应、保留的引用图、增量导入状态、种子全文）扩展出候选文献集，并对每一条候选与每一条引用边保留可回指的来源定位与逐字证据。

适用：前向/后向引用追踪、引用网络结构、路径解释、去重与身份合并、关联文献发现。
不适用：实时联网检索、普通关键词搜索、全文阅读理解、引文语境语义分析、未经授权抓取。**严禁**声称「最新/实时/全球最新」，严禁编造 DOI、作者、年份、期刊、全文或软件状态。

触发条件（任一）：任务要求「引文追踪 / 关联文献发现 / 引用图 / 去重合并 / 引用路径 / 找到文献并保留筛选依据」；或材料中出现 Crossref / EuropePMC / publisher 响应、reference graph、citation edges、import state 等本地文件。

## 2. 调用方式

主脚本（纯 Python 标准库，不联网，不依赖 CWD）：

```
# 相对本 SKILL.md 所在目录执行；评测时 skill 安装在 /skills/weekly-skill
python scripts/main.py [command]
# 等价绝对路径：python /skills/weekly-skill/scripts/main.py [command]
```

| command | 作用 |
|---|---|
| （无参数） | 完整流程：读 /input → 写工作稿 → 写 /app/output/result.json |
| init | 先落一份 partial result.json 到 /app/output（保底，避免超时空白） |
| show | 打印工作稿摘要（papers/edges/candidates 数量与来源文件） |
| check | 校验 result.json：contract 键齐全、quote 可命中、status 合法 |
| build | 同默认完整流程（显式重跑） |

路径覆盖（本地自测）：环境变量 `INPUT_DIR` / `WORK_DIR` / `OUTPUT_DIR`，或参数 `--input` / `--work` / `--output`；默认 `/input`、`/app/work`、`/app/output`。退出码恒为 0（异常写入 result.json 的 errors/degradations）。

Agent 的完整工作流见 §3；脚本提供确定性基线，Agent 在其之上做材料细读与证据核对。脚本与手工步骤**都必须**遵守 §5 证据规范。

## 3. 工作流（固定执行顺序）

### 3.1 读取输入与材料清单
1. 读 `/input/case.json`：取 `case_id`、`task_instruction`、`output_contract`、可能的 `seed` / `seed_doi` / `seed_title` / `query` 字段。
2. 读 `/input/task.md`（若有）。
3. 枚举 `/input` 下全部材料文件（含子目录），记录相对路径、类型（.json/.jsonl/.csv/.tsv/.txt/.md/.pdf/.docx/.sqlite/.png/.jpg 等），**不按文件名或标签假设内容**，逐个真实解析。

### 3.2 材料分类与解析（真实读取，逐条定位）
- **JSON/JSONL**：解析为对象/数组/行；按结构特征分类：
  - Crossref 响应：含 `message.items[]`（含 `DOI`、`title`、`author`、`reference`、`is-referenced-by-count`、`container-title`、`published`）；
  - EuropePMC 响应：含 `resultList.result[]`（`id`、`source`、`title`、`authorString`、`pubYear`、`journalInfo`、`citedByCount`、`references`）；
  - 出版商响应：含 `citations` / `references` / `cited_by` / `items` / `records`；
  - 引用图：节点+边结构，如 `nodes`/`edges`/`graph`/`links`/`citations`，边带 `from`/`to` 或 `cites`/`cited_by` 或 `reference`/`citing`；
  - 增量导入状态：含 `imported`/`pending`/`state`/`batch`/`updated` 等状态字段。
- **CSV/TSV**：首行为表头，逐行转记录；识别 `doi/title/author/year/venue/cites/cited_by/reference` 列。
- **TXT/MD**：按段落/行解析，识别参考文献条目、DOI（`10.\d{4,9}/...`）、引文边描述。
- **PDF**：用脚本内置 stdlib 提取文本（`scripts/main.py` 自带无第三方依赖的 PDF 文本抽取，FlateDecode 用 zlib）；失败则记入 degradations，绝不臆测内容。
- **DOCX**：`zipfile` 读 `word/document.xml` 取文本。
- **SQLite**：`sqlite3` 列全部表名与行数，按表导出记录。
- **图片**：无离线 OCR 时标记为 unparsed，保留文件定位，不猜测。

每类材料解析后写入工作稿 `papers`（文献记录）与 `edges`（引用边），每条带 `source_file` 与 `locator`（字段路径 / 行号 / 页号 / 表名）。

### 3.3 种子确定与扩展
1. 种子优先取 `case.json` 显式字段；其次取材料中被标记为 seed 的节点；再次取单一 PDF/单条 publisher 记录作为种子。种子至少要有 DOI 或规范化标题。
2. **后向扩展**（种子 → 参考文献，方向 `backward`）：从种子记录中的 `reference`/`references` 列表取方法/数据出处。
3. **前向扩展**（施引文献 → 种子，方向 `forward`）：从 `is-referenced-by`/`citedByCount`/`citations` 中取谁引用种子；若本地无前向记录，明确记 gap（新预印本常见）。
4. **多层级**：按可用数据继续扩展，最多 `depth=3`；每层记录来源文件与方向；分支剪枝按「相关性信号」（见 3.5）与数据存在性，剪枝理由写入 coverage。
5. **停止判据**：数据源耗尽、重复命中已合并节点、深度上限、或边无法回指来源时停止。

### 3.4 去重与身份合并
对候选集做规范键合并，处理预印本/会议版/期刊版/增补版：
- 键1 DOI（`10.\d{4,9}/[-._;()/:A-Z0-9]+` 归一：小写、去尾标点）；
- 键2 标题归一（去标点、大小写、连字符、括号内注释、副标题切分）+ 第一作者姓 + 年份（±1）；
- 键3 标题相似度（token Jaccard ≥ 0.85）+ 作者交集 ≥1 + 年份窗口。
保留合并证据：每组列出被合并条目的 source 定位与逐字标题/DOI 片段；同名不同文（DOI 不同）**不得**合并。

### 3.5 关联文献与排序
- 关联信号：共被引（共享参考文献）、文献耦合（共享施引文献，若本地有）、作者/机构重叠、数据集/任务重叠。
- 排序：直接引用（depth=1）优先，再按关联证据强度与方向（backward=方法出处 > forward=后续改进 > associative=平行工作），同层按本地可得的被引计数降序；排序理由逐条写入 evidence。
- 指标口径：本地数据可算 `Precision@k`（前 k 条中方向/身份正确且确有引用边支撑的比例）、`Recall@k`（本地引用图内可验证的关键出处/后续改进覆盖率）；**只对本地图内可核验项计算**，缺地算 null，不编造。

### 3.6 覆盖与遗漏说明
对每个无结果的 query、缺前向记录的种子、缺元数据字段、接口限流/权限不足分别写入 `gaps`；说明「已完成」与「未完成」。

## 4. 工作稿 schema（`/app/work/draft.jsonl`，每行一条）

- `{"t":"meta", ...}` 元信息（case_id、时间戳、input 清单）
- `{"t":"paper","pid":str,"title":str,"authors":[str],"year":int|null,"venue":str|null,"doi":str|null,"source_file":str,"locator":str,"raw":{...}}`
- `{"t":"edge","from":pid,"to":pid,"dir":"backward|forward","relation":"reference|cited_by","source_file":str,"locator":str,"quote":str}`
- `{"t":"candidate","pid":str,"relation":str,"depth":int,"score":num|null,"evidence":[{"file":str,"locator":str,"quote":str}]}`
- `{"t":"query","qid":str,"terms":[str],"expansions":[str],"hit":bool,"note":str}`
- `{"t":"issue","level":"error|degradation|gap","item":str,"detail":str,"source_file":str|null}`

## 5. 证据规范（红线）

1. 每条候选、每条引用边、每个结论都必须有 `source_file` + `locator`（字段路径/行号/页号/表名）+ **逐字 quote**；quote 必须能在对应材料原文中 `in` 命中（忽略大小写与空白折叠后可命中）。
2. 候选的 title/authors/year/venue/DOI 只能取自材料原文；缺失写 null 或 `[]`，不补造。
3. 引用方向必须由材料字段判定（`reference`=后向、`cited_by`/`is-referenced-by`=前向）；只有被引列表而无方向时，记为 `dir=unknown` 并说明。
4. 无结果 query 保留并说明；冲突（同一 DOI 不同元数据）记入 uncertainty；撤稿/更正状态只按材料中明确字段表述。
5. 不写 placeholder / scaffold /「array」「object」空占位；契约键缺值用 null 或 []。
6. 退出码恒 0；所有异常进 `errors`/`degradations`，产出合法 partial。

## 6. 输出 result.json（必含字段）

`/app/output/result.json`：**原样回填** case.json `output_contract` 的每一个字段（缺值 null/[]，不改名、不漏键），并始终包含：

- `case_id`（原样回填）
- `status`：`complete` / `partial` / `insufficient_evidence` / `input_error`
- `query_plan`：检索问题拆解 → 多轮查询计划（含同义词/缩写/跨语言扩展）
- `candidates`：每条含 title/authors/year/venue/doi/source（file+locator+quote）/relation/depth/score
- `dedup`：合并组与规则
- `ranking`：排序依据与本地可核验的 Precision@k / Recall@k（缺则 null）
- `coverage`：覆盖与遗漏说明
- `sources`：证据定位（file+locator+quote）
- `uncertainty`：冲突/歧义/低置信项
- `change_records`：增量修改记录
- `errors`、`degradations`、`gaps`

## 7. 降级表

| 情形 | status | 动作 |
|---|---|---|
| 空输入 /input 无 case.json | input_error | result.json 合法，errors 注明 |
| case.json 坏 JSON | input_error | 记录解析错误，仍输出 contract=null |
| 材料缺失（无种子/无引用数据） | insufficient_evidence | candidates=[], gaps 说明 |
| 种子有但前向记录缺失 | partial | 后向正常，gaps 记「无前向记录」 |
| PDF 无文本层/抽取失败 | partial | degradations 记文件，不猜内容 |
| 权限不足/无法读某文件 | partial | errors 记该文件，其余继续 |
| 全部成功 | complete | 全字段填充 |

## 8. 自检（提交前与运行后均执行）

- `python scripts/main.py check`：contract 键齐全、quote 命中率 ≥0.95、status 合法、exit 0。
- 手工核对：每条 candidate/edge 打开 source_file 在 locator 处能读到 quote；身份合并组内确有 DOI/标题/作者依据；无「示例」冒充正式结果。

## 9. 限制

- 仅使用本地材料；不联网、不检索外部数据库；不声称实时或最新。
- 引文覆盖度受本地响应完整度限制；本地没有的前向/后向记录如实记为缺失。
- 不替代人工核验：方向冲突、同名不同文、撤稿状态需以材料原文为准。

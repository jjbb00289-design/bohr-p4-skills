#!/usr/bin/env python3
"""Offline citation-tracing pipeline (source-bound). Stdlib only, no network."""
import argparse
import json
import os
import sys
from collections import deque
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import citegraph as cg


def _dirs(args):
    def get(env, flag, default):
        return Path(getattr(args, flag, None) or os.environ.get(env, default))
    return (get("INPUT_DIR", "input", "/input"),
            get("WORK_DIR", "work", "/app/work"),
            get("OUTPUT_DIR", "output", "/app/output"))


def _write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def _resolve_ref(ref, idx):
    if ref == "SEED":
        return "SEED"
    if isinstance(ref, str):
        nd = cg.norm_doi(ref)
        return idx["doi"].get(nd) if nd else None
    if isinstance(ref, dict):
        ident = cg.identity(ref)
        if not ident:
            return None
        if ident["doi"] and ident["doi"] in idx["doi"]:
            return idx["doi"][ident["doi"]]
        t = cg.norm_title(ident["title"])
        if t and t in idx["title"]:
            return idx["title"][t]
    return None


def _add_paper(papers, idx, ident, sf, loc):
    pid = len(papers)
    ident.update({"source_file": sf, "locator": loc,
                  "quote": ident.get("title") or ident.get("doi") or ""})
    papers.append(ident)
    if ident["doi"]:
        idx["doi"].setdefault(ident["doi"], pid)
    t = cg.norm_title(ident["title"])
    if t:
        idx["title"].setdefault(t, pid)
    return pid


def _seed_from_case(case):
    seeds = []
    if isinstance(case, dict):
        for k in ("seed", "seed_doi", "seed_title", "seed_id", "seed_paper"):
            if case.get(k):
                seeds.append(case[k])
        for k in ("query", "research_question", "task_instruction"):
            v = case.get(k)
            if isinstance(v, str):
                seeds.extend(cg.find_dois(v))
    return seeds


def _query_plan(case, papers, seed_pids):
    terms = []
    for s in sorted(seed_pids):
        p = papers[s] if s < len(papers) else {}
        if p.get("title"):
            terms += [w for w in cg.norm_title(p["title"]).split() if len(w) > 2][:6]
    if isinstance(case, dict):
        for k in ("query", "research_question"):
            if isinstance(case.get(k), str):
                terms += [w for w in cg.norm_title(case[k]).split() if len(w) > 2][:6]
    terms = list(dict.fromkeys(terms))[:10]
    return [
        {"step": 1, "kind": "seed_locate",
         "query": "locate seed by DOI/title locally", "terms": terms,
         "expansions": [], "rationale": "anchor trace locally"},
        {"step": 2, "kind": "backward",
         "query": "seed references (method/data origins)", "terms": terms,
         "expansions": ["references", "cited references"],
         "rationale": "foundational sources"},
        {"step": 3, "kind": "forward",
         "query": "works citing seed (improvements/critiques)", "terms": terms,
         "expansions": ["cited_by", "citing", "is-referenced-by"],
         "rationale": "subsequent work"},
        {"step": 4, "kind": "associative",
         "query": "co-citation / coupling", "terms": terms,
         "expansions": ["shared reference", "same method"],
         "rationale": "parallel work"}]


def _contract_default(k, template, result):
    aliases = {"results": "candidates", "papers": "candidates",
               "queries": "query_plan", "search_plan": "query_plan",
               "evidence": "sources", "changes": "change_records",
               "missing": "coverage"}
    if k in aliases:
        return result.get(aliases[k])
    return [] if isinstance(template, list) else ({} if isinstance(template, dict) else None)


def _build(case_dir, work_dir, out_dir):
    work_dir.mkdir(parents=True, exist_ok=True)
    out_dir.mkdir(parents=True, exist_ok=True)
    cp = case_dir / "case.json"
    case, case_err = {}, None
    if cp.exists():
        try:
            case = json.loads(cp.read_text(encoding="utf-8", errors="replace"))
        except Exception as e:
            case_err = str(e)

    issues = []
    if not cp.exists():
        issues.append({"level": "error", "item": "case.json", "detail": "missing"})
    if case_err:
        issues.append({"level": "error", "item": "case.json",
                       "detail": f"bad json: {case_err}"})

    papers, back_refs, fwd_refs, graph_refs = [], [], [], []
    if case_dir.exists():
        for p in sorted(case_dir.rglob("*")):
            if not p.is_file() or p.name in ("case.json", "task.md"):
                continue
            if p.is_relative_to(work_dir) or p.is_relative_to(out_dir):
                continue
            rel = str(p.relative_to(case_dir)).replace("\\", "/")
            pp, br, fr, gr, isu = cg.harvest_file(p, rel)
            papers += pp
            back_refs += br
            fwd_refs += fr
            graph_refs += gr
            issues += isu

    case_id = case.get("case_id") or case.get("id") or case.get("armiId") or "unknown"
    contract = case.get("output_contract") or {}

    idx = {"doi": {}, "title": {}}
    for i, pp in enumerate(papers):
        if pp.get("doi"):
            idx["doi"].setdefault(pp["doi"], i)
        t = cg.norm_title(pp.get("title"))
        if t:
            idx["title"].setdefault(t, i)

    seed_pids = set()
    for sd in _seed_from_case(case):
        if isinstance(sd, str):
            nd = cg.norm_doi(sd)
            if nd and nd in idx["doi"]:
                seed_pids.add(idx["doi"][nd])
            elif sd.strip():
                t = cg.norm_title(sd)
                if t in idx["title"]:
                    seed_pids.add(idx["title"][t])

    edges = []

    def add_edge(a, b, d, sf, loc, q):
        if a is not None and b is not None and a != b:
            edges.append({"cites": a, "cited": b, "dir": d, "source_file": sf,
                          "locator": loc, "quote": q})

    gaps = []

    def gap(item, loc, sf):
        gaps.append({"level": "gap", "item": item, "detail": loc, "source_file": sf})

    def resolv(x, sf, loc):
        r = _resolve_ref(x, idx)
        if r is None and isinstance(x, dict):
            ident = cg.identity(x)
            if ident and (ident["doi"] or ident["title"]):
                r = _add_paper(papers, idx, ident, sf, loc)
        return r

    for br in back_refs:
        c = resolv(br["cites_ref"], br["source_file"], br["locator"])
        r = resolv(br["ref"], br["source_file"], br["locator"])
        if c is None or r is None:
            gap("backward unresolved", br["locator"], br["source_file"])
        else:
            add_edge(c, r, "backward", br["source_file"], br["locator"], br["quote"])
    for fr in fwd_refs:
        c = resolv(fr["cites_ref"], fr["source_file"], fr["locator"])
        if c is None:
            gap("forward unresolved", fr["locator"], fr["source_file"])
        elif fr["cited_ref"] == "SEED":
            for sp in seed_pids:
                add_edge(c, sp, "forward", fr["source_file"], fr["locator"], fr["quote"])
        else:
            t = resolv(fr["cited_ref"], fr["source_file"], fr["locator"])
            if t is None:
                gap("forward unresolved", fr["locator"], fr["source_file"])
            else:
                add_edge(c, t, "forward", fr["source_file"], fr["locator"], fr["quote"])
    for gr in graph_refs:
        c = resolv(gr["cites_ref"], gr["source_file"], gr["locator"])
        t = resolv(gr["cited_ref"], gr["source_file"], gr["locator"])
        if c is None or t is None:
            gap("graph edge unresolved", gr["locator"], gr["source_file"])
        else:
            add_edge(c, t, "backward", gr["source_file"], gr["locator"], gr["quote"])

    if not seed_pids:
        deg = {}
        for e in edges:
            deg[e["cites"]] = deg.get(e["cites"], 0) + 1
            deg[e["cited"]] = deg.get(e["cited"], 0) + 1
        if deg:
            seed_pids = {max(deg, key=deg.get)}
            gaps.append({"level": "gap", "item": "seed",
                         "detail": "seed inferred as max-degree node"})
        elif papers:
            seed_pids = {0}
            gaps.append({"level": "gap", "item": "seed",
                         "detail": "seed inferred as first paper"})

    cites_of, cited_by = {}, {}
    for e in edges:
        cites_of.setdefault(e["cites"], []).append(e["cited"])
        cited_by.setdefault(e["cited"], []).append(e["cites"])

    relation = {}
    q = deque()
    for s in seed_pids:
        relation[s] = (0, "seed")
        q.append(s)
    while q:
        cur = q.popleft()
        d, dr = relation[cur]
        if d >= 3:
            continue
        for t in cites_of.get(cur, []):
            if t not in relation:
                relation[t] = (d + 1, "backward")
                q.append(t)
        for t in cited_by.get(cur, []):
            if t not in relation:
                relation[t] = (d + 1, "forward")
                q.append(t)

    seed_refs = set()
    for s in seed_pids:
        seed_refs |= set(cites_of.get(s, []))
    for i in range(len(papers)):
        if i not in relation and (set(cites_of.get(i, [])) & seed_refs):
            relation[i] = (2, "associative")

    groups = cg.dedup_papers(papers)
    merged = [cg.merge_group(papers, g) for g in groups]
    cand_gids, cand_pids = set(), set()
    candidates = []
    for gi, g in enumerate(groups):
        if g[0] in seed_pids or g[0] not in relation:
            continue
        d, dr = relation[g[0]]
        ev = []
        for i in g:
            pp = papers[i]
            if pp.get("quote"):
                ev.append({"file": pp["source_file"], "locator": pp["locator"],
                           "quote": pp["quote"]})
        for e in edges:
            if e["cites"] in g or e["cited"] in g:
                ev.append({"file": e["source_file"], "locator": e["locator"],
                           "quote": e["quote"], "edge": e["dir"]})
        seen_ev, ev2 = set(), []
        for x in ev:
            k = (x.get("file"), x.get("locator"), x.get("quote"))
            if k not in seen_ev:
                seen_ev.add(k)
                ev2.append(x)
        score = {1: {"backward": 3.0, "forward": 2.0},
                 2: {"backward": 1.5, "forward": 1.0, "associative": 0.8},
                 3: {"backward": 0.6, "forward": 0.5, "associative": 0.4}}.get(d, {}).get(dr, 0.4)
        cand_gids.add(gi)
        cand_pids |= set(g)
        candidates.append({"title": merged[gi].get("title"),
                           "authors": merged[gi].get("authors"),
                           "year": merged[gi].get("year"),
                           "venue": merged[gi].get("venue"),
                           "doi": merged[gi].get("doi"),
                           "relation": dr, "depth": d, "score": score,
                           "merge_count": merged[gi].get("merged_count", 1),
                           "evidence": ev2})
    candidates.sort(key=lambda c: (-(c["score"] or 0),
                                   -(c["year"] or 0) if c.get("year") else 0))

    k = min(10, len(candidates))
    precision_k = round(sum(1 for c in candidates[:k] if c["depth"] == 1) / k, 4) if k else None
    recall_k = round(len(seed_refs & cand_pids) / len(seed_refs), 4) if seed_refs else None

    errors = [i for i in issues if i["level"] == "error"]
    degradations = [i for i in issues if i["level"] == "degradation"]
    if not seed_pids and not papers:
        status = "insufficient_evidence"
    elif case_err or not cp.exists():
        status = "input_error"
    elif not candidates and not edges:
        status = "insufficient_evidence"
    elif errors or gaps or degradations:
        status = "partial"
    else:
        status = "complete"
    if case_err or not cp.exists():
        status = "input_error"

    result = {
        "case_id": case_id, "status": status,
        "query_plan": _query_plan(case, papers, seed_pids),
        "candidates": candidates,
        "dedup": {"groups": len(groups),
                  "merged": [m for m in merged if m.get("merged_count", 1) > 1],
                  "rules": ["doi", "title+author+year", "title jaccard+author+year"]},
        "ranking": {"order": [c["doi"] or c["title"] for c in candidates],
                    "precision_at_k": precision_k, "recall_at_k": recall_k,
                    "metric_note": "local graph only"},
        "coverage": {"candidate_count": len(candidates),
                     "edge_count": len(edges), "seed_pids": sorted(seed_pids),
                     "missing": gaps},
        "sources": _sources(papers), "uncertainty": _uncertainty(papers, edges),
        "change_records": [{"step": "init", "note": "partial written"},
                           {"step": "finalize", "note": "full result"}],
        "errors": errors, "degradations": degradations, "gaps": gaps}
    for k in contract:
        if k not in result:
            result[k] = _contract_default(k, contract[k], result)

    partial = {"case_id": case_id, "status": "partial", "candidates": [],
               "query_plan": _query_plan(case, papers, seed_pids),
               "sources": [], "uncertainty": [],
               "change_records": [{"step": "init", "note": "partial written"}],
               "errors": [], "degradations": [], "gaps": []}
    for k in contract:
        if k not in partial:
            partial[k] = _contract_default(k, contract[k], result)
    _write(out_dir / "result.json", partial)
    _write(out_dir / "result.json", result)
    _write(work_dir / "draft.json", result)
    lines = [json.dumps({"t": "meta", "papers": len(papers), "edges": len(edges),
                         "groups": len(groups)}, ensure_ascii=False)]
    lines += [json.dumps({"t": "paper", "pid": i, **pp}, ensure_ascii=False)
              for i, pp in enumerate(papers)]
    lines += [json.dumps({"t": "edge", **e}, ensure_ascii=False) for e in edges]
    (work_dir / "draft.jsonl").write_text("\n".join(lines), encoding="utf-8")
    return result


def _sources(papers):
    out, seen = [], set()
    for pp in papers:
        if pp.get("source_file") and pp.get("quote"):
            k = (pp["source_file"], pp["locator"], pp["quote"])
            if k not in seen:
                seen.add(k)
                out.append({"file": pp["source_file"], "locator": pp["locator"],
                            "quote": pp["quote"]})
    return out[:200]


def _uncertainty(papers, edges):
    u, doi_seen = [], {}
    for i, pp in enumerate(papers):
        if pp.get("doi"):
            doi_seen.setdefault(pp["doi"], []).append(i)
    for d, idxs in doi_seen.items():
        titles = {cg.norm_title(papers[i].get("title")) for i in idxs} - {""}
        if len(titles) > 1:
            u.append({"item": d, "issue": "same DOI multiple titles",
                      "level": "conflict"})
    if not edges:
        u.append({"item": "edges",
                  "issue": "no citation edges locally",
                  "level": "missing"})
    return u


def _cmd_show(work_dir):
    p = work_dir / "draft.json"
    if not p.exists():
        print("no draft; run full flow first")
        return
    d = json.loads(p.read_text(encoding="utf-8"))
    print(f"case_id={d.get('case_id')} status={d.get('status')} "
          f"candidates={len(d.get('candidates', []))}")
    for c in d.get("candidates", [])[:10]:
        print(f"  - {c.get('doi') or c.get('title')} [{c.get('relation')} "
              f"d{c.get('depth')}]")


def _cmd_check(case_dir, work_dir, out_dir):
    rp = out_dir / "result.json"
    if not rp.exists():
        print("FAIL: result.json missing")
        return
    result = json.loads(rp.read_text(encoding="utf-8"))
    ok = True
    case = {}
    cp = case_dir / "case.json"
    if cp.exists():
        try:
            case = json.loads(cp.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            case = {}
    contract = case.get("output_contract") or {}
    missing = [k for k in contract if k not in result]
    if missing:
        print(f"FAIL: contract keys missing {missing}")
        ok = False
    if "case_id" not in result:
        print("FAIL: case_id missing")
        ok = False
    if result.get("status") not in ("complete", "partial",
                                    "insufficient_evidence", "input_error"):
        print(f"FAIL: bad status {result.get('status')}")
        ok = False
    idx = {}
    if case_dir.exists():
        for f in case_dir.rglob("*"):
            if f.is_file() and f.suffix.lower() in (".json", ".jsonl", ".txt",
                                                    ".md", ".csv", ".tsv"):
                try:
                    idx[f.name] = f.read_text(encoding="utf-8", errors="replace")
                except Exception:
                    pass
    quotes = [(s.get("file"), s.get("quote")) for s in result.get("sources", [])]
    for c in result.get("candidates", []):
        quotes += [(e.get("file"), e.get("quote")) for e in c.get("evidence", [])]
    tot = hit = 0
    for fname, qq in quotes:
        if not qq:
            continue
        tot += 1
        raw = idx.get(Path(fname).name if fname else "")
        if raw is not None and cg.quote_hits(raw, qq):
            hit += 1
    rate = hit / tot if tot else 1.0
    print(f"quote hit rate = {hit}/{tot} = {rate:.4f}")
    if tot and rate < 0.95:
        print("FAIL: quote hit rate < 0.95")
        ok = False
    print("PASS" if ok else "FAIL")


def _cmd_init(case_dir, out_dir):
    case = {}
    cp = case_dir / "case.json"
    if cp.exists():
        try:
            case = json.loads(cp.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            case = {}
    contract = case.get("output_contract") or {}
    case_id = case.get("case_id") or case.get("id") or "unknown"
    partial = {"case_id": case_id, "status": "partial", "candidates": [],
               "query_plan": [], "sources": [], "uncertainty": [],
               "change_records": [{"step": "init", "note": "partial"}],
               "errors": [], "degradations": [], "gaps": []}
    for k in contract:
        if k not in partial:
            partial[k] = [] if isinstance(contract[k], list) else (
                {} if isinstance(contract[k], dict) else None)
    out_dir.mkdir(parents=True, exist_ok=True)
    _write(out_dir / "result.json", partial)
    print("init partial written")


def main(argv=None):
    ap = argparse.ArgumentParser(description="citation tracing")
    ap.add_argument("command", nargs="?", default="full")
    ap.add_argument("--input")
    ap.add_argument("--work")
    ap.add_argument("--output")
    args = ap.parse_args(argv)
    case_dir, work_dir, out_dir = _dirs(args)
    try:
        if args.command == "init":
            _cmd_init(case_dir, out_dir)
        elif args.command == "show":
            _cmd_show(work_dir)
        elif args.command == "check":
            _cmd_check(case_dir, work_dir, out_dir)
        else:
            _build(case_dir, work_dir, out_dir)
            _cmd_show(work_dir)
    except Exception as e:
        out_dir.mkdir(parents=True, exist_ok=True)
        _write(out_dir / "result.json", {
            "case_id": "unknown", "status": "input_error",
            "errors": [{"item": "pipeline", "detail": str(e)}],
            "degradations": [], "gaps": [], "candidates": [],
            "query_plan": [], "sources": [], "uncertainty": [],
            "change_records": [{"step": "crash", "note": str(e)[:200]}]})
        print(f"error handled: {e}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

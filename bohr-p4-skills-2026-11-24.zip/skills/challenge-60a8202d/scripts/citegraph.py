import csv
import json
import re
import sqlite3
import zlib
import zipfile
from pathlib import Path

DOI_RE = re.compile(r"10\.\d{4,9}/[-._;()/:A-Za-z0-9]+")
WS_RE = re.compile(r"\s+")
TITLE_KEYS = ("title", "article-title", "article_title", "paper_title", "name",
              "item_title", "publication_title")
DOI_KEYS = ("doi", "prism:doi", "doi_url")
AUTHOR_KEYS = ("author", "authors", "creator", "creators", "authorString")
YEAR_KEYS = ("year", "pubyear", "pub_year", "publication_year",
             "published_year", "issue_year")
VENUE_KEYS = ("container-title", "container_title", "journal", "journal_title",
              "journalInfo", "venue", "source", "publication", "booktitle")
BACKWARD_KEYS = ("reference", "references", "citations", "cited_references",
                 "bibliography")
FORWARD_KEYS = ("cited_by", "citedby", "cited-by", "citing",
                "is-referenced-by", "isreferencedby")


def norm_text(s):
    return "" if s is None else WS_RE.sub(" ", str(s)).strip().lower()


def quote_hits(text, quote):
    return bool(quote and text) and norm_text(quote) in norm_text(text)


def find_dois(text):
    out = []
    for m in DOI_RE.finditer(text or ""):
        d = m.group(0).rstrip(".,;)]}").lower()
        if d not in out:
            out.append(d)
    return out


def norm_doi(doi):
    if not doi:
        return None
    d = str(doi).strip().rstrip(".,;)]}").lower()
    return d[4:] if d.startswith("doi:") else d


def norm_title(t):
    if not t:
        return ""
    s = str(t).strip().lower()
    s = re.sub(r"\[[^\]]*\]", " ", s)
    s = re.sub(r"\([^)]*\)", " ", s)
    s = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", " ", s)
    return WS_RE.sub(" ", s).strip()


def jaccard(a, b):
    ta, tb = set(norm_title(a).split()), set(norm_title(b).split())
    return 0.0 if not ta or not tb else len(ta & tb) / len(ta | tb)


def first_author_surname(authors):
    if not authors:
        return ""
    a = authors[0]
    if isinstance(a, dict):
        a = a.get("family") or a.get("lastname") or a.get("name") or ""
    a = str(a).strip()
    return a.split()[-1].lower() if a else ""


def paper_keys(paper):
    keys = []
    doi = norm_doi(paper.get("doi"))
    if doi:
        keys.append(("doi", doi))
    title, surname = norm_title(paper.get("title")), first_author_surname(paper.get("authors"))
    year = paper.get("year")
    if title and surname:
        keys.append(("ta", (title, surname)))
        if isinstance(year, int) or (isinstance(year, str) and year.isdigit()):
            keys.append(("tay", (title, surname, int(year))))
    if title:
        keys.append(("t", title))
    return keys


def same_paper(a, b):
    ka, kb = paper_keys(a), paper_keys(b)
    for ta, va in ka:
        for tb, vb in kb:
            if ta == tb and va == vb:
                return True
    if ka and kb:
        return False
    ta, tb = norm_title(a.get("title")), norm_title(b.get("title"))
    if ta and tb and jaccard(ta, tb) >= 0.85:
        sa, sb = first_author_surname(a.get("authors")), first_author_surname(b.get("authors"))
        if sa and sa == sb:
            ya, yb = a.get("year"), b.get("year")
            if ya is None or yb is None:
                return True
            try:
                return abs(int(ya) - int(yb)) <= 1
            except (TypeError, ValueError):
                return True
    return False


def _root(parent, i):
    while parent[i] != i:
        parent[i] = parent[parent[i]]
        i = parent[i]
    return i


def dedup_papers(papers):
    parent = list(range(len(papers)))
    for i in range(len(papers)):
        for j in range(i + 1, len(papers)):
            if same_paper(papers[i], papers[j]):
                pi, pj = _root(parent, i), _root(parent, j)
                if pi != pj:
                    parent[pj] = pi
    groups = {}
    for i in range(len(papers)):
        groups.setdefault(_root(parent, i), []).append(i)
    return list(groups.values())


def merge_group(papers, idxs):
    first = dict(papers[idxs[0]])
    for key in ("doi", "title", "year", "venue", "authors"):
        if first.get(key) in (None, "", []):
            first[key] = _pick(papers, idxs, key)
    first["merge_evidence"] = [
        {"title": papers[i].get("title"), "doi": papers[i].get("doi"),
         "source_file": papers[i].get("source_file"), "locator": papers[i].get("locator")}
        for i in idxs]
    first["merged_count"] = len(idxs)
    return first


def _pick(papers, idxs, key):
    for i in idxs:
        v = papers[i].get(key)
        if v not in (None, "", []):
            return v
    return None


def pdf_text(path):
    data = Path(path).read_bytes()
    parts = []
    for m in re.finditer(rb"stream\r?\n(.*?)endstream", data, re.S):
        raw = m.group(1)
        if raw[:1] in (b"\r", b"\n"):
            raw = raw[1:]
        try:
            block = zlib.decompress(raw)
        except zlib.error:
            block = raw
        parts.append(_extract_tj(block))
    if not parts:
        parts.append(_extract_tj(data))
    return "\n".join(p for p in parts if p)


def _extract_tj(block):
    try:
        s = block.decode("latin-1")
    except Exception:
        return ""
    return "\n".join(_unescape_pdf(m.group(0)[1:-1])
                     for m in re.finditer(r"\((?:[^()\\]|\\.)*\)", s))


def _unescape_pdf(s):
    s = s.replace(r"\(", "(").replace(r"\)", ")").replace(r"\\", "\\")
    s = s.replace(r"\n", "\n").replace(r"\r", "\r").replace(r"\t", "\t")
    return re.sub(r"\\([0-7]{3})", lambda m: chr(int(m.group(1), 8)), s)


def docx_text(path):
    try:
        with zipfile.ZipFile(path) as z:
            xml = z.read("word/document.xml").decode("utf-8", "ignore")
    except Exception:
        return ""
    parts = re.findall(r"<w:t[^>]*>(.*?)</w:t>", xml, re.S)
    return "\n".join(p.replace("&amp;", "&").replace("&lt;", "<")
                     .replace("&gt;", ">").replace("&quot;", '"')
                     .replace("&apos;", "'") for p in parts)


def sqlite_snapshot(path):
    out = []
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    except Exception:
        return out
    try:
        cur = con.cursor()
        tabs = [r[0] for r in cur.execute(
            "select name from sqlite_master where type='table'")]
        for t in tabs:
            try:
                rows = cur.execute(f'select * from "{t}" limit 500').fetchall()
                cols = [d[0] for d in cur.description]
                out.append({"table": t, "columns": cols,
                            "rows": [dict(zip(cols, r)) for r in rows]})
            except Exception:
                continue
    finally:
        con.close()
    return out


def load_json_any(path):
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return None, str(e)
    try:
        return json.loads(text), None
    except json.JSONDecodeError:
        pass
    lines = [l for l in text.splitlines() if l.strip()]
    objs, errs = [], []
    for i, l in enumerate(lines):
        try:
            objs.append(json.loads(l))
        except json.JSONDecodeError as e:
            errs.append(f"line {i + 1}: {e}")
    if objs:
        return objs, (errs[0] if errs else None)
    return None, "not json"


# ---- harvesting ----

def _first(obj, keys):
    if not isinstance(obj, dict):
        return None
    low = {str(k).lower(): v for k, v in obj.items()}
    for k in keys:
        if k in obj and obj[k] not in (None, "", []):
            return obj[k]
        if k.lower() in low and low[k.lower()] not in (None, "", []):
            return low[k.lower()]
    return None


def _year(obj):
    srcs = [_first(obj, YEAR_KEYS)]
    if isinstance(obj, dict):
        srcs += [obj.get(k) for k in ("published", "issued", "created",
                  "published-print", "published-online", "date", "pubdate")]
    for s in srcs:
        if isinstance(s, dict):
            dp = s.get("date-parts") or s.get("date_parts")
            if dp and isinstance(dp, list) and dp[0]:
                return int(dp[0][0])
        if isinstance(s, (int, float)):
            return int(s)
        if isinstance(s, str):
            m = re.search(r"\d{4}", s)
            if m:
                return int(m.group(0))
    return None


def _authors(obj):
    a = _first(obj, AUTHOR_KEYS)
    if a is None:
        return []
    if isinstance(a, str):
        return [p for p in re.split(r"[,;]|\band\b", a) if p.strip()]
    out = []
    for x in _as_list(a):
        if isinstance(x, dict):
            fam = x.get("family") or x.get("surname") or x.get("lastname")
            giv = x.get("given") or x.get("forename") or x.get("firstname")
            out.append(((fam or "") + (", " + giv if fam and giv else ""))
                       or x.get("name") or "")
        elif isinstance(x, str) and x.strip():
            out.append(x.strip())
    return [o for o in out if o]


def _title(obj):
    t = _first(obj, TITLE_KEYS)
    if isinstance(t, list):
        t = t[0] if t else None
    return str(t).strip() if t else None


def _venue(obj):
    v = _first(obj, VENUE_KEYS)
    if isinstance(v, list):
        v = v[0] if v else None
    elif isinstance(v, dict):
        v = v.get("title") or v.get("journal") or v.get("medlineAbbreviation")
    return str(v).strip() if v else None


def _doi(obj):
    d = _first(obj, DOI_KEYS)
    if isinstance(d, dict):
        d = None
    if not d and isinstance(obj, dict):
        for k, v in obj.items():
            if str(k).lower() == "id" and isinstance(v, str) and DOI_RE.match(v):
                d = v
    return norm_doi(str(d)) if d else None


def identity(obj):
    if not isinstance(obj, dict):
        return None
    title, doi = _title(obj), _doi(obj)
    if not title and not doi:
        return None
    return {"title": title, "doi": doi, "authors": _authors(obj),
            "year": _year(obj), "venue": _venue(obj)}


def _as_list(v):
    if isinstance(v, list):
        return v
    return [] if v is None else [v]


def _quote_of(item):
    if isinstance(item, str):
        return item
    if isinstance(item, dict):
        return _title(item) or _doi(item) or json.dumps(item, ensure_ascii=False)[:400]
    return str(item)[:400]


def _scan_dois(txt, rel, papers, prefix):
    for i, ln in enumerate(txt.splitlines()):
        for d in find_dois(ln):
            papers.append({"title": None, "doi": d, "authors": [], "year": None,
                           "venue": None, "source_file": rel,
                           "locator": f"{prefix} {i + 1}", "quote": d})


def _edge_of(obj):
    if not isinstance(obj, dict):
        return None
    c = obj.get("citing") or obj.get("from") or obj.get("source")
    t = obj.get("cited") or obj.get("to") or obj.get("target") or obj.get("destination")
    if c and t and isinstance(c, (str, int, float)) and isinstance(t, (str, int, float)):
        return {"cites_ref": str(c), "cited_ref": str(t)}
    return None


def _refs(obj, keys):
    for k in keys:
        v = obj.get(k)
        if isinstance(v, (dict, list)) or (isinstance(v, str) and DOI_RE.search(v)):
            for j, it in enumerate(_as_list(v)):
                yield k, j, it


def _walk(obj, path, rel, papers, back_refs, fwd_refs, graph_refs, seen):
    if isinstance(obj, dict):
        if id(obj) in seen:
            return
        seen.add(id(obj))
        eg = _edge_of(obj)
        if eg:
            eg.update({"source_file": rel, "locator": path, "quote": eg["cites_ref"]})
            graph_refs.append(eg)
            return
        ident = identity(obj)
        if ident:
            ident.update({"source_file": rel, "locator": path,
                          "quote": ident.get("title") or ident.get("doi") or ""})
            papers.append(ident)
            ckey = ident.get("doi") or ident.get("title")
            for k, j, it in _refs(obj, BACKWARD_KEYS):
                back_refs.append({"cites_ref": ckey, "ref": it, "source_file": rel,
                                  "locator": f"{path}.{k}[{j}]", "quote": _quote_of(it)})
            for k, j, it in _refs(obj, FORWARD_KEYS):
                fwd_refs.append({"cites_ref": it, "cited_ref": ckey, "source_file": rel,
                                 "locator": f"{path}.{k}[{j}]", "quote": _quote_of(it)})
        else:
            for fk in FORWARD_KEYS:
                v = obj.get(fk)
                if isinstance(v, list):
                    for j, it in enumerate(v):
                        if isinstance(it, dict) and identity(it):
                            fwd_refs.append({"cites_ref": it, "cited_ref": "SEED",
                                             "source_file": rel, "locator": f"{path}.{fk}[{j}]",
                                             "quote": _quote_of(it)})
        for k, v in obj.items():
            if k not in BACKWARD_KEYS and k not in FORWARD_KEYS:
                _walk(v, f"{path}.{k}", rel, papers, back_refs, fwd_refs, graph_refs, seen)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            _walk(v, f"{path}[{i}]", rel, papers, back_refs, fwd_refs, graph_refs, seen)


def harvest_file(path, rel):
    """Return (papers, back_refs, fwd_refs, graph_refs, issues)."""
    papers, back_refs, fwd_refs, graph_refs, issues, seen = [], [], [], [], [], set()
    ext = path.suffix.lower()
    try:
        if ext in (".json", ".jsonl"):
            parsed, err = load_json_any(path)
            if err and parsed is None:
                issues.append({"level": "degradation", "item": rel,
                           "detail": f"json: {err}"})
                return papers, back_refs, fwd_refs, graph_refs, issues
            for i, o in enumerate(parsed if isinstance(parsed, list) else [parsed]):
                _walk(o, f"$[{i}]", rel, papers, back_refs, fwd_refs, graph_refs, seen)
        elif ext in (".csv", ".tsv"):
            delim = "," if ext == ".csv" else "\t"
            with open(path, encoding="utf-8", errors="replace", newline="") as f:
                rows = list(csv.DictReader(f))
            for i, r in enumerate(rows):
                _walk(r, f"line {i + 2}", rel, papers, back_refs, fwd_refs, graph_refs, seen)
        elif ext in (".txt", ".md", ".text"):
            _scan_dois(Path(path).read_text(encoding="utf-8", errors="replace"),
                       rel, papers, "line")
        elif ext == ".pdf":
            txt = pdf_text(path)
            if not txt.strip():
                import shutil, subprocess
                pdftotext = shutil.which("pdftotext")
                if pdftotext:
                    try:
                        r = subprocess.run([pdftotext, str(path), "-"],
                                           capture_output=True, timeout=120)
                        txt = r.stdout.decode("utf-8", "replace")
                    except Exception:
                        txt = ""
            if not txt.strip():
                issues.append({"level": "degradation", "item": rel,
                               "detail": "no text layer"})
                return papers, back_refs, fwd_refs, graph_refs, issues
            _scan_dois(txt, rel, papers, "page? line")
        elif ext == ".docx":
            _scan_dois(docx_text(path), rel, papers, "line")
        elif ext in (".sqlite", ".db", ".sqlite3"):
            for tbl in sqlite_snapshot(str(path)):
                for i, row in enumerate(tbl["rows"]):
                    _walk(row, f"{tbl['table']}[{i}]", rel, papers, back_refs,
                          fwd_refs, graph_refs, seen)
        else:
            issues.append({"level": "degradation", "item": rel,
                           "detail": "unparsed file type"})
    except Exception as e:
        issues.append({"level": "error", "item": rel, "detail": str(e)})
    return papers, back_refs, fwd_refs, graph_refs, issues

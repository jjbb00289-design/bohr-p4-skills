# Entity & relation type definitions

## Entity types

| type | definition | examples |
|-|-|-|
| researcher | person/group named in the paper (self-report or third-party citation) | authors listed in corpus-manifest.json; "Name et al. (Year)" |
| material | concrete substance/object used or studied | graphene, TiO2, antibody, catalyst |
| method | procedure/technique/model applied | measurement, training, segmentation pipeline |
| task | the problem/objective being solved | classification, detection, prediction |
| metric | a measured/evaluated quantity | accuracy, F1, RMSE, error |
| conclusion | a claim the paper states as its finding | "results show X outperforms Y" |

Only entities that actually appear in the source text are extracted. The
fallback extractor is conservative; the agent should extend coverage but keep
every mention bound to `source_id + paragraph_id + quote`.

## Relation types

| type | meaning | direction |
|-|-|-|
| uses | subject applies/employs object (method uses material, etc.) | subject -> object |
| compares | subject is compared/benchmarked against object | subject -> object |
| outperforms | subject is reported better than object | subject -> object |
| supports | subject's evidence/result supports object's claim | subject -> object |
| contradicts | subject conflicts with object | subject -> object |

Relations require an explicit cue in the same sentence/paragraph; bare
co-occurrence is not a relation. Record strength as `direct` (author states
it), `indirect` (inferred but clearly implied), or `heuristic` (fallback cue
match, needs review).

## Evidence strength

- `direct`: the source states the relation/entity claim verbatim.
- `indirect`: the claim follows directly but is not a single explicit clause.
- `heuristic`: produced by the rule-based fallback; treat as candidate only.

## Degradation table (when to mark a gap, not guess)

| situation | action |
|-|-|
| file missing | `gaps` entry `scope=material`; `status=insufficient_evidence` |
| bad JSON / case error | `status=input_error`, `errors` populated |
| PDF without text layer | use `extract_pdf_text` zlib fallback; record degradation |
| image pixels / supplementary data | do not infer numbers; record `gaps` |
| inline formula linearized | note in `condition`/`uncertainty`; XML is source of truth |
| query has no result | return empty subgraph + `unknowns` explanation |

# Work draft & evidence schema (kg.v1)

The pipeline reads `WORK_DIR/draft.json` when present; otherwise it runs a
deterministic fallback extraction. The hosting agent should refine the draft
by editing this file. Every field is optional but omitting `nodes`/`edges`
keeps the fallback output.

```json
{
  "schema": "kg.v1",
  "documents": [
    {"source_id": "primary", "title": "...", "authors": ["..."], "doi": "...",
     "path": "/input/primary-material.json"}
  ],
  "nodes": [
    {"id": "n1", "type": "researcher|material|method|task|metric|conclusion",
     "name": "canonical surface form",
     "aliases": ["alternate surface forms"],
     "mentions": [
       {"source_id": "primary", "paragraph_id": "JATS-id", "quote": "verbatim text"}
     ]}
  ],
  "edges": [
    {"id": "e1", "type": "uses|compares|outperforms|supports|contradicts",
     "subject": "n1", "object": "n2", "direction": "subject->object",
     "condition": "applicability/scope as stated in source",
     "strength": "direct|indirect|heuristic",
     "evidence": [
       {"source_id": "primary", "paragraph_id": "JATS-id", "quote": "verbatim text"}
     ]}
  ],
  "alignments": [
    {"cluster_id": "a1", "name": "concept", "members": ["n1", "n5"],
     "action": "candidate_merge|keep_separate",
     "basis": "why these are the same or must stay separate",
     "uncertainty": "what still needs confirmation"}
  ],
  "queries": [
    {"id": "q1", "question": "...",
     "subgraph_node_ids": ["n1"], "subgraph_edge_ids": ["e1"],
     "result": "answer text or object",
     "evidence": [{"source_id": "...", "paragraph_id": "...", "quote": "..."}],
     "unknowns": ["..."]}
  ],
  "gaps": [{"scope": "material|entity|relation|evidence", "note": "..."}],
  "change_records": [{"action": "...", "detail": "..."}]
}
```

## Evidence rules (mandatory)

1. Every substantive node/edge must carry `source_id` + `paragraph_id` +
   verbatim `quote`. `paragraph_id` is the organizer's JATS paragraph id, not
   a PDF page number. Do not invent page numbers.
2. `quote` must be an exact substring of the source paragraph (whitespace
   collapsed). `check` reports the hit rate; any miss is flagged
   `quote_miss` and recorded in `change_records`.
3. Do not infer numbers from images, supplementary files, or underlying
   clinical/experimental data. Record such items in `gaps`.
4. Distinguish author self-report from third-party paraphrase; use
   `condition`/`strength` to mark the evidence level.
5. Same generic term across papers does not imply the same physical sample,
   model instance, dataset, or condition. Do not force merges; use
   `keep_separate` with a `basis`.

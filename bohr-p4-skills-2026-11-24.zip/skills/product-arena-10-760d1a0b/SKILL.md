---
name: literature-knowledge-graph
description: 从论文材料（JSON/JATS-XML/PDF/文本）抽取实体与关系、绑定逐字证据、跨篇对齐并执行可复核查询，产出带来源定位的文献知识图谱与 result.json。适用于科研阅读、文献知识图谱构建、证据核验与图谱查询任务。
version: 1.0.0
---

# 文献知识图谱构建（科研阅读：回答问题，也给出依据）

## 用途与适用条件

本 Skill 把一批科研论文转成**带证据的节点与边**，支持跨篇实体对齐、来源绑定与图谱查询。适用场景：

- 从论文抽取研究者、材料、方法、任务、指标、结论六类实体；
- 抽取 `uses / compares / outperforms / supports / contradicts` 五类关系；
- 同一对象跨篇别名/缩写对齐（该合并才合并，不该合并保持分离）；
- 提供至少 3 个可回查原文的查询；
- 输出可读、可编辑的图谱文件与符合平台契约的 `result.json`。

**不适用/边界**：不编造图像像素、补充附件或底层实验数据中的数值；不把同一术语当同一物理样品/模型/数据集；位置用材料提供的 JATS 段落 ID，不是自造页码。

## 触发条件

任务要求"文献知识图谱 / 实体关系抽取 / 证据绑定 / 图谱查询 / 跨篇对齐"时触发。材料形态不确定时也适用——脚本按真实文件内容解析，不按文件名假设。

## 调用方式

纯 Python 标准库，不联网，不依赖 CWD。主脚本：

```bash
python scripts/main.py [init|show|check|build] [--input DIR] [--work DIR] [--output DIR]
```

- 默认（无子命令）= **完整流程**：读 `/input`、解析材料、抽取、对齐、查询、写 `/app/output/result.json` 与图谱文件、写工作稿。无工作稿也能从 `/input` 真实派生完整交付。
- `init`：解析材料并生成 `WORK_DIR/draft.json`（骨架 + 回退抽取）与 `WORK_DIR/materials.json`（全部段落），供 Agent 精修。
- `build`：读 `WORK_DIR/draft.json` 校验并定稿 `result.json` + 图谱文件。
- `check`：报 quote 命中率、契约键缺失、降级项。
- `show`：打印当前 draft/result 概要。

目录默认值：`/input`、`/app/work`、`/app/output`；可用环境变量 `INPUT_DIR / WORK_DIR / OUTPUT_DIR` 或 `--input/--work/--output` 覆盖。**退出码恒为 0**；所有异常写入 `errors`/`degradations`。

## 输入

`/input/case.json`（含 `case_id`、`task_instruction`、`output_contract`）、`/input/task.md`，以及材料文件。本题实际案例为两篇独立论文的 JSON 文本：

- `corpus-manifest.json`：各 DOI、作者、来源哈希、许可证（根 DOI/title/authors 属第一篇，不得套到第二篇）；
- `material.json`：两篇正文段落汇总索引；
- `primary-material.json`：第一篇原文；`secondary-material.json`：第二篇新增论文；
- `secondary-publisher.xml`：供核对行内公式/上下标线性化的原始 XML。

也可能出现 PDF、DOCX、SQLite、图片/表格。脚本支持 JSON/XML/PDF/纯文本；DOCX/SQLite/图片按缺失处理并写入 `gaps`，不猜内容。

## 输出

`/app/output/` 下：

- `result.json`：**原样回填 case.json `output_contract` 的每个字段 + `case_id`**，另带 `status`、`sources`、`uncertainty`、`change_records`、`errors`、`degradations`；缺值用 `null`/`[]`，不重命名、不漏键。
- `graph.json`：完整图谱（documents/nodes/edges/alignments/queries/gaps/change_records/quote_hit_rate）。
- `graph.dot`、`graph.md`：可读、可编辑的图谱导出。
- `WORK_DIR/draft.json`：工作稿（Agent 精修入口）。

`status` 取值：`success` / `partial` / `insufficient_evidence` / `input_error`。

## 工作稿 schema 与证据规范

见 `references/schema.md`（字段与 JSON 示例）、`references/vocabulary.md`（六类实体、五类关系、证据强度、降级表）。核心红线：

1. 每个实质节点/边用独立论文 `source_id` + `paragraph_id` + 逐字 `quote`；`quote` 必须在材料原文命中（`check` 校验命中率）。
2. 位置是 JATS 段落 ID，不是 PDF 页码；不把自建页码当原文页码。
3. 只有原文有线索的关系才建边；共现、综述转述、推测不算直接证据。
4. 跨篇：记录候选合并依据与**不得合并**的冲突/不同对象；不强迫合并，不把不同论文的条件/样本/数值合成一个结论。

## 推荐工作流（Agent 执行）

1. `python scripts/main.py init`：得到段落全文与回退抽取骨架。
2. 通读 `task.md` 与 `case.json` 的 `output_contract`，识别必做对象（实体类型、关系类型、证据字段、查询问题）。
3. 精修 `WORK_DIR/draft.json`：补全/纠错节点、关系、对齐、至少 3 个查询，每条带 `source_id + paragraph_id + quote`。
4. `python scripts/main.py check`：确认命中率 ≥ 0.95、契约键齐全。
5. `python scripts/main.py build`：定稿。时间不足时直接 `python scripts/main.py`（默认流程）也能产出可用交付。

## 降级表与自检

见 `references/vocabulary.md` 的降级表。自检项：quote 命中率 ≥ 0.95；`result.json` 契约键齐全且含 `case_id`；空/坏/缺材料三态分别产出 `partial`/`input_error`/`insufficient_evidence` 且不崩、非 0 字节；重复运行产物结构一致（无时间/随机依赖）。

## 限制

纯标准库、不联网；不生成基准分数；不把示例输出冒充正式案例结果（示例必须标注）；不读取工作区之外文件。

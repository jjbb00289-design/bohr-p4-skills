"""Knowledge-graph extraction and contract echo."""
import json
import re
from pathlib import Path

from kg_parse import (normalize, _flat, load_json, load_document, load_manifest,
                      discover_materials, _author_name)

_DEF = {
    "method": ["使用", "used"],
    "task": ["分类", "detection"],
    "conclusion": ["表明", "results show"],
    "material": ["graphene", "TiO2"],
    "generic": ["dataset", "model"],
    "relations": {"uses": ["使用", "use"], "compares": ["比较", "versus"],
                  "outperforms": ["优于", "outperform"], "supports": ["支持", "consistent"],
                  "contradicts": ["矛盾", "inconsistent"]},
}


def _vocab():
    p = Path(__file__).resolve().parent.parent / "references" / "vocab.json"
    obj, err = load_json(p)
    if err or not isinstance(obj, dict):
        return _DEF
    return {k: (obj.get(k) if isinstance(obj.get(k), _DEF[k].__class__) else _DEF[k])
            for k in _DEF}


def _sentences(text):
    spans, start = [], 0
    for i, ch in enumerate(text):
        if ch in ".!?。！？；;":
            if i + 1 - start >= 2:
                spans.append((start, i + 1))
            start = i + 1
    if start < len(text) and len(text) - start >= 2:
        spans.append((start, len(text)))
    return spans


def _cue(text, cues, start=0):
    low = text.lower()
    best = None
    for cue in cues:
        pos = low.find(cue.lower(), start)
        if pos >= 0 and (best is None or pos < best[0]):
            best = (pos, pos + len(cue))
    return best


def _mention(para, start, end):
    return {"source_id": para["source_id"], "paragraph_id": para["paragraph_id"],
            "quote": para["text"][start:end], "start": start, "end": end}


def _excerpt(seg, start, end):
    a, b = max(0, start - 25), min(len(seg), end + 45)
    piece = normalize(seg[a:b])
    if len(piece) < 3:
        return None
    if len(piece) > 90:
        cut = piece.rfind(" ", 0, 90)
        piece = piece[:cut if cut > 0 else 90].rstrip()
    return piece


def _concrete(text, pos, term):
    return not (pos > 0 and text[pos - 1].isalnum()) and not \
        (pos + len(term) < len(text) and text[pos + len(term)].isalnum())


def _cue_re(cues):
    return re.compile("|".join(sorted((re.escape(c) for c in cues), key=len, reverse=True)), re.I)


def extract_fallback(paragraphs, manifest_entries):
    nodes, edges, by_key = [], [], {}
    vocab = _vocab()

    def add_node(ntype, name, mention):
        key = (mention.get("source_id"), ntype, _flat(name).lower())
        if key in by_key:
            node = nodes[by_key[key]]
            node["mentions"].append(mention)
            if name not in node["aliases"]:
                node["aliases"].append(name)
            return node
        nid = "n%d" % (len(nodes) + 1)
        node = {"id": nid, "type": ntype, "name": name, "mentions": [mention],
                "aliases": [name]}
        nodes.append(node)
        by_key[key] = len(nodes) - 1
        return node

    author_names = []
    for entry in manifest_entries:
        if isinstance(entry, dict):
            for a in entry.get("authors", []) or []:
                nm = _author_name(a)
                if nm:
                    author_names.append(nm)
    for para in paragraphs:
        text = para["text"]
        for m in re.finditer(r"([A-Z][A-Za-z\-]+(?:\s+et\s+al\.?)?)\s*,?\s*\((?:19|20)\d{2}\)", text):
            add_node("researcher", m.group(1).strip(), _mention(para, m.start(), m.end()))
    for nm in author_names:
        for para in paragraphs:
            pos = para["text"].lower().find(nm.lower())
            if pos >= 0:
                add_node("researcher", nm, _mention(para, pos, pos + len(nm)))
                break

    for para in paragraphs:
        text, low = para["text"], para["text"].lower()
        for term in vocab["material"]:
            pos = low.find(term.lower())
            while pos >= 0:
                if _concrete(text, pos, term):
                    add_node("material", term, _mention(para, pos, pos + len(term)))
                pos = low.find(term.lower(), pos + 1)
        for m in re.finditer(r"\d+(?:\.\d+)?\s*(?:%|percent|ms|s|kg|K|J|eV|nm|µm|mm|cm|m)\b|"
                             r"\b(?:accuracy|precision|recall|F1|AUC|RMSE|MAE|sensitivity|specificity|error)"
                             r"(?:\s*(?:of|=|:|was|is)\s*\d+(?:\.\d+)?)?", text):
            add_node("metric", m.group(0), _mention(para, m.start(), m.end()))
        for span in _sentences(text):
            seg = text[span[0]:span[1]]
            for ctype, cues in (("method", vocab["method"]), ("task", vocab["task"]),
                                ("conclusion", vocab["conclusion"])):
                hit = _cue(seg, cues)
                if hit:
                    name = _excerpt(seg, hit[0], hit[1])
                    if name:
                        # Cite the whole claim sentence. Citing only a keyword
                        # such as 'used' cannot independently support the label.
                        add_node(ctype, name, _mention(para, span[0], span[1]))

    para_mentions = []
    for para in paragraphs:
        ms = []
        for node in nodes:
            for mm in node["mentions"]:
                if mm["source_id"] == para["source_id"] and \
                        mm["paragraph_id"] == para["paragraph_id"]:
                    ms.append((mm, node))
        ms.sort(key=lambda t: t[0]["start"])
        para_mentions.append((para, ms))

    used = set()
    for para, ms in para_mentions:
        text = para["text"]
        for rtype, cues in vocab["relations"].items():
            for m in re.finditer(_cue_re(cues), text):
                before = [t for t in ms if t[0]["end"] <= m.start()]
                after = [t for t in ms if t[0]["start"] >= m.end()]
                if not before or not after:
                    continue
                subj, obj = before[-1][1], after[0][1]
                if subj["id"] == obj["id"]:
                    continue
                ekey = (subj["id"], rtype, obj["id"], para["paragraph_id"])
                if ekey in used:
                    continue
                used.add(ekey)
                edges.append({"id": "e%d" % (len(edges) + 1), "type": rtype,
                              "subject": subj["id"], "object": obj["id"],
                              "direction": "subject->object",
                              "condition": normalize(text[max(0, m.start() - 30):m.end() + 30]),
                              "strength": "heuristic",
                              "evidence": [_mention(para, max(0, m.start() - 40),
                                                    min(len(text), m.end() + 40))]})
    return nodes, edges


def compute_alignments(nodes):
    generic = {_flat(g).lower() for g in _vocab()["generic"]}
    alignments, groups, cid = [], {}, 0
    for node in nodes:
        key = _flat(node["name"]).lower()
        if key:
            groups.setdefault(key, []).append(node)
    for key, members in groups.items():
        srcs = {m["mentions"][0]["source_id"] for m in members if m["mentions"]}
        if len(srcs) > 1:
            cid += 1
            is_gen = key in generic
            alignments.append({"cluster_id": "a%d" % cid, "name": members[0]["name"],
                               "members": [m["id"] for m in members],
                               "action": "keep_separate" if is_gen else "candidate_merge",
                               "basis": ("generic term may denote different instances"
                                         if is_gen else "normalized name identity"),
                               "uncertainty": "same term does not imply same physical sample/instance; confirm manually"})
    return alignments


def compute_queries(nodes, edges, alignments):
    def refs(nids):
        return [{"source_id": n["mentions"][0]["source_id"],
                 "paragraph_id": n["mentions"][0]["paragraph_id"],
                 "quote": n["mentions"][0]["quote"]}
                for n in nodes if n["id"] in nids and n["mentions"]]

    uses = [e for e in edges if e["type"] == "uses"]
    q1n = sorted({e["subject"] for e in uses} | {e["object"] for e in uses})
    q2n = sorted({m for a in alignments for m in a["members"]})
    concl = [n for n in nodes if n["type"] == "conclusion"]
    metr = [n for n in nodes if n["type"] == "metric"]
    q3n = sorted({n["id"] for n in concl + metr})
    return [
        dict(id="q1", question="哪些方法被用于哪些对象（方法—使用—对象关系）？",
             subgraph_node_ids=q1n, subgraph_edge_ids=[e["id"] for e in uses],
             result=("%d 条'使用'关系" % len(uses)) if uses else "未发现明确的'使用'关系",
             evidence=refs(q1n),
             unknowns=[] if uses else ["材料中未出现可判定为 uses 的关系线索"]),
        dict(id="q2", question="两篇论文中哪些实体候选合并、哪些保持分离？",
             subgraph_node_ids=q2n, subgraph_edge_ids=[],
             result=[{"cluster_id": a["cluster_id"], "name": a["name"],
                      "action": a["action"], "basis": a["basis"]} for a in alignments],
             evidence=refs(q2n), unknowns=[a["uncertainty"] for a in alignments]),
        dict(id="q3", question="论文的主要结论及其关联指标是什么？",
             subgraph_node_ids=q3n, subgraph_edge_ids=[],
             result=[{"type": n["type"], "name": n["name"]} for n in concl + metr],
             evidence=refs(q3n),
             unknowns=[] if (concl or metr) else ["未提取到结论或指标实体"]),
        dict(id="q4", question="图谱中哪些关系或证据缺失/无法确定？",
             subgraph_node_ids=[], subgraph_edge_ids=[], result="汇总 gaps 与 uncertainty",
             evidence=[], unknowns=["跨篇实体合并均需人工确认；相同通用术语不代表同一实例"]),
    ]


def verify_quotes(paragraphs, nodes, edges):
    corpus = {}
    for p in paragraphs:
        corpus.setdefault(p["source_id"], {})[p["paragraph_id"]] = p["text"]
    hits = miss = 0

    def check(ref):
        nonlocal hits, miss
        txt = corpus.get(ref.get("source_id"), {}).get(ref.get("paragraph_id"), "")
        if _flat(ref.get("quote", "")) and _flat(ref.get("quote", "")) in _flat(txt):
            hits += 1
        else:
            miss += 1
            ref["quote_miss"] = True

    for n in nodes:
        for m in n.get("mentions", []):
            check(m)
    for e in edges:
        for r in e.get("evidence", []):
            check(r)
    total = hits + miss
    return hits, miss, (hits / total if total else 1.0)


def build_graph(paragraphs, meta_list, nodes, edges, alignments, queries, gaps,
                changes, degradations, quote_rate):
    return {"schema": "kg.v1", "documents": meta_list,
            "paragraph_count": len(paragraphs), "nodes": nodes, "edges": edges,
            "alignments": alignments, "queries": queries, "gaps": gaps,
            "change_records": changes, "degradations": degradations,
            "quote_hit_rate": round(quote_rate, 4)}


def load_case(case_path):
    obj, err = load_json(case_path)
    if err:
        return None, err
    return (obj, None) if isinstance(obj, dict) else (obj, "case_not_object")


def contract_fields(case):
    oc = case.get("output_contract", {}) if isinstance(case, dict) else {}
    if isinstance(oc, dict):
        if isinstance(oc.get("fields"), dict):
            oc = oc["fields"]
        elif isinstance(oc.get("properties"), dict):
            oc = oc["properties"]
        return list(oc.items()), "dict"
    if isinstance(oc, list):
        return [(f, None) for f in oc if isinstance(f, str)], "list"
    return [], "none"


def _summary_text(graph):
    docs = [d.get("source_id") or d.get("path", "?") for d in graph.get("documents", [])]
    counts = {}
    for n in graph.get("nodes", []):
        counts[n["type"]] = counts.get(n["type"], 0) + 1
    m = sum(1 for a in graph.get("alignments", []) if a.get("action") == "candidate_merge")
    s = sum(1 for a in graph.get("alignments", []) if a.get("action") == "keep_separate")
    return "文档：%s\n实体数：%d（%s）\n关系数：%d\n跨篇候选合并 %d 项、保持分离 %d 项\n查询数：%d" % (
        "、".join(docs) if docs else "无", len(graph.get("nodes", [])),
        "；".join("%s %d" % (k, v) for k, v in sorted(counts.items())),
        len(graph.get("edges", [])), m, s, len(graph.get("queries", [])))


def _field_value(name, spec, graph):
    n = re.sub(r"[^a-z0-9]", "", str(name).lower())
    desc = ""
    if isinstance(spec, dict):
        desc = " ".join(str(v) for v in spec.values()).lower()
    elif isinstance(spec, str):
        desc = spec.lower()
    key = n + " " + desc
    for kws, target in (
        (("knowledgegraph", "graph", "kg"), graph),
        (("node", "entit"), graph["nodes"]),
        (("edge", "relat"), graph["edges"]),
        (("quer",), graph["queries"]),
        (("align", "merg"), graph["alignments"]),
        (("conflict", "no_merge"),
         [a for a in graph["alignments"] if a["action"] == "keep_separate"]),
        (("gap", "missing", "unknown", "uncertain"), graph["gaps"]),
        (("summar", "answer", "abstract"), _summary_text(graph)),
        (("conclus",), [x for x in graph["nodes"] if x["type"] == "conclusion"]),
        (("result",), graph["queries"]),
        (("metric",), [x for x in graph["nodes"] if x["type"] == "metric"]),
        (("status",), graph),
    ):
        if any(k in key for k in kws):
            return target
    return None


def _uncertainty(graph):
    out = [{"scope": "alignment", "id": a["cluster_id"], "note": a["uncertainty"]}
           for a in graph.get("alignments", []) if a.get("uncertainty")]
    out += [{"scope": "query", "id": q["id"], "note": u}
            for q in graph.get("queries", []) for u in q.get("unknowns", [])]
    out += [{"scope": "gap", "note": g} for g in graph.get("gaps", [])]
    return out


def echo_contract(case, graph, status, degradations):
    result = {}
    if isinstance(case, dict):
        result["case_id"] = case.get("case_id") or case.get("id")
    unknown = []
    for fname, spec in contract_fields(case)[0]:
        val = _field_value(fname, spec, graph)
        if val is None:
            unknown.append(fname)
        result[fname] = val
    extras = {"status": status, "sources": graph.get("documents", []),
              "uncertainty": _uncertainty(graph),
              "change_records": graph.get("change_records", []),
              "errors": [], "degradations": degradations, "graph": graph}
    # Operational envelope has reserved meanings; output_contract must not
    # change status into a graph object or overwrite the source provenance.
    result.update(extras)
    result["_contract_unknown_fields"] = unknown
    return result


def write_json(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2, sort_keys=True)
    return path

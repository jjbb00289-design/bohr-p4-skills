"""Material parsing: JSON/JATS-XML/PDF/text to paragraphs."""
import json
import re
import zlib
from pathlib import Path

try:
    import xml.etree.ElementTree as ET
    _HAS_XML = True
except Exception:
    _HAS_XML = False

_ID_KEYS = ("paragraph_id", "pid", "id", "@id", "xml:id", "p_id", "para_id")
_TEXT_KEYS = ("text", "body", "content", "abstract", "paragraph", "value",
              "full_text", "plaintext")


def normalize(s):
    return re.sub(r"\s+", " ", str(s or "")).strip()


def _flat(s):
    return re.sub(r"\s+", "", str(s or ""))


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None, "missing"
    for enc in ("utf-8", "utf-8-sig"):
        try:
            with open(p, "r", encoding=enc) as fh:
                return json.load(fh), None
        except UnicodeDecodeError:
            continue
        except Exception as exc:
            return None, "json_error:%s" % exc
    return None, "decode_error"


def read_text(path):
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            with open(path, "r", encoding=enc) as fh:
                return fh.read(), None
        except Exception:
            continue
    return "", "undecodable"


def extract_pdf_text(path):
    try:
        data = Path(path).read_bytes()
    except Exception as exc:
        return "", "pdf_read_failed:%s" % exc
    chunks = []
    for m in re.finditer(rb"stream\r?\n(.*?)\r?\nendstream", data, re.S):
        payload = m.group(1)
        try:
            payload = zlib.decompress(payload)
        except Exception:
            pass
        try:
            payload = payload.decode("latin-1")
        except Exception:
            continue
        chunks += re.findall(r"\((?:[^()\\]|\\.)*\)\s*Tj", payload)
        chunks += re.findall(r"<[0-9A-Fa-f\s]+>\s*Tj", payload)
        chunks += re.findall(r"\[[^\[\]]*\]\s*TJ", payload)
    if not chunks:
        txt = data.decode("latin-1", errors="ignore")
        runs = re.findall(r"[ -~]{20,}", txt)
        return "\n".join(runs), ("pdf_no_text_layer" if not runs else "pdf_ascii_fallback")
    return "\n".join(chunks), "pdf_zlib_text"


def _pdf_paragraphs(text):
    out, idx = [], 0
    for part in re.split(r"\n{2,}|\r\n\r\n|\n", text):
        line = normalize(part)
        if len(line) >= 3:
            idx += 1
            out.append({"paragraph_id": "pdf-p%d" % idx, "text": line})
    return out


def _is_para(obj):
    if not isinstance(obj, dict):
        return False
    return any(k in obj and isinstance(obj[k], (str, int)) for k in _ID_KEYS) or any(
        k in obj and isinstance(obj[k], str) and normalize(obj[k]) for k in _TEXT_KEYS)


def _para_id(obj):
    for k in _ID_KEYS:
        if obj.get(k) not in (None, ""):
            return str(obj[k])
    return None


def _para_text(obj):
    for k in _TEXT_KEYS:
        v = obj.get(k)
        if isinstance(v, str) and normalize(v):
            return normalize(v)
    for k in ("text", "content", "body", "abstract"):
        v = obj.get(k)
        if isinstance(v, list):
            j = normalize(" ".join(str(x) for x in v if isinstance(x, str)))
            if j:
                return j
    return None


def _walk(obj, src, counter):
    if isinstance(obj, dict):
        if _is_para(obj):
            txt = _para_text(obj)
            if txt:
                pid = _para_id(obj)
                if pid is None:
                    counter[0] += 1
                    pid = "%s-p%d" % (src, counter[0])
                yield {"source_id": src, "paragraph_id": pid, "text": txt}
        for v in obj.values():
            yield from _walk(v, src, counter)
    elif isinstance(obj, list):
        for v in obj:
            yield from _walk(v, src, counter)


def _collect_json(obj, src):
    counter, out, seen = [0], [], set()
    for p in _walk(obj, src, counter):
        k = (p["source_id"], p["paragraph_id"], _flat(p["text"]))
        if k not in seen:
            seen.add(k)
            out.append(p)
    return out


def _collect_xml(root, src):
    out, idx = [], 0
    for el in root.iter():
        if el.tag.split("}")[-1].lower() not in ("p", "title", "abstract",
                                                 "caption", "label", "sec"):
            continue
        txt = normalize(" ".join(el.itertext()))
        if not txt:
            continue
        idx += 1
        pid = el.attrib.get("id") or el.attrib.get("xml:id") or ("%s-x%d" % (src, idx))
        out.append({"source_id": src, "paragraph_id": str(pid), "text": txt})
    return out


def _src_hint(path):
    name = Path(path).name.lower()
    if "primary" in name:
        return "primary"
    if "secondary" in name:
        return "secondary"
    return Path(path).stem


def load_document(path, source_id=None):
    paragraphs, meta, degradations = [], {}, []
    p = Path(path)
    src = source_id or _src_hint(path)
    if not p.exists():
        return [], {"path": str(path), "source_id": src}, ["missing"]
    ext = p.suffix.lower()
    if ext == ".pdf":
        text, deg = extract_pdf_text(p)
        if deg:
            degradations.append("pdf:%s:%s" % (p.name, deg))
        for para in _pdf_paragraphs(text):
            para["source_id"] = src
            paragraphs.append(para)
        return paragraphs, {"path": str(p), "source_id": src}, degradations
    if ext == ".xml":
        if not _HAS_XML:
            return [], {"path": str(p), "source_id": src}, ["no_xml_parser"]
        try:
            paragraphs = _collect_xml(ET.parse(str(p)).getroot(), src)
        except Exception as exc:
            return [], {"path": str(p), "source_id": src}, ["xml_error:%s" % exc]
        return paragraphs, {"path": str(p), "source_id": src}, degradations
    if ext == ".json":
        obj, err = load_json(p)
        if err:
            return [], {"path": str(p), "source_id": src}, ["json:%s" % err]
        if isinstance(obj, dict):
            for k in ("doi", "title", "authors", "license", "hash", "source_id", "id"):
                if k in obj:
                    meta[k] = obj[k]
        return _collect_json(obj, src), {"path": str(p), "source_id": src, **meta}, \
            degradations
    txt, err = read_text(p)
    if err:
        return [], {"path": str(p), "source_id": src}, [err]
    idx = 0
    for part in re.split(r"\n{2,}", txt):
        line = normalize(part)
        if len(line) >= 3:
            idx += 1
            paragraphs.append({"source_id": src, "paragraph_id": "%s-t%d" % (src, idx),
                               "text": line})
    return paragraphs, {"path": str(p), "source_id": src}, degradations


def load_manifest(path):
    obj, err = load_json(path)
    if err or obj is None:
        return [], err
    entries = obj if isinstance(obj, list) else obj.get("papers") or \
        obj.get("documents") or obj.get("entries") or []
    return entries if isinstance(entries, list) else [obj], None


def _author_name(a):
    if isinstance(a, str):
        return a.strip()
    if isinstance(a, dict):
        if a.get("name"):
            return str(a["name"]).strip()
        if a.get("given") and a.get("family"):
            return "%s %s" % (a["given"], a["family"])
    return None


def discover_materials(input_dir, case=None):
    d = Path(input_dir)
    known = ["corpus-manifest.json", "material.json", "primary-material.json",
             "secondary-material.json", "secondary-publisher.xml", "primary-publisher.xml"]
    found = [d / name for name in known if (d / name).exists()]
    others = []
    if d.exists():
        for p in sorted(d.iterdir()):
            if not p.is_file() or p.name in ("case.json", "task.md") or p in found:
                continue
            if p.suffix.lower() in (".json", ".xml", ".pdf", ".txt", ".md"):
                others.append(p)
    return found + others

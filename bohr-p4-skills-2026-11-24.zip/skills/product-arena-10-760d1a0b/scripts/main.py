"""Literature knowledge-graph Skill: single-command pipeline, exit 0."""
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import kg_core as kg


def resolve_dirs(argv):
    args, flags = {}, {"--input": "input", "--work": "work", "--output": "output"}
    i = 0
    while i < len(argv):
        a = argv[i]
        for flag, key in flags.items():
            if a == flag and i + 1 < len(argv):
                args[key] = argv[i + 1]
                i += 2
                break
            if a.startswith(flag + "="):
                args[key] = a.split("=", 1)[1]
                i += 1
                break
        else:
            i += 1
    e = os.environ
    return (Path(args.get("input") or e.get("INPUT_DIR") or "/input"),
            Path(args.get("work") or e.get("WORK_DIR") or "/app/work"),
            Path(args.get("output") or e.get("OUTPUT_DIR") or "/app/output"))


def _status_from(nodes, edges, paragraphs, degradations, case_err):
    if case_err:
        return "input_error"
    if not paragraphs or (not nodes and not edges):
        return "insufficient_evidence"
    return "partial" if degradations else "success"


def load_materials(input_dir):
    """Load manifest + all material documents. Returns dict of state."""
    manifest_entries, manifest_err = [], None
    manifest_path = input_dir / "corpus-manifest.json"
    if manifest_path.exists():
        manifest_entries, manifest_err = kg.load_manifest(manifest_path)

    source_by_doi = {}
    for i, entry in enumerate(manifest_entries):
        src = "primary" if i == 0 else ("secondary" if i == 1 else "doc%d" % (i + 1))
        if isinstance(entry, dict):
            for k in ("doi", "id", "source_id"):
                if entry.get(k):
                    source_by_doi[entry.get(k)] = src

    paragraphs, meta_list, degradations = [], [], []
    if manifest_err:
        degradations.append("manifest:%s" % manifest_err)

    primary_sources_present = any((input_dir / name).is_file() for name in
                                  ("primary-material.json", "secondary-material.json"))
    for path in kg.discover_materials(input_dir):
        if path.name == "corpus-manifest.json":
            continue
        # material.json is explicitly an aggregated view over the individual
        # papers; ingesting both creates a fictitious additional publication.
        if primary_sources_present and path.name == "material.json":
            continue
        # Publisher XML is for verifying linearized content, not another article.
        if primary_sources_present and path.name.endswith("-publisher.xml"):
            continue
        src_hint = path.stem
        if path.name.startswith("primary"):
            src_hint = "primary"
        elif path.name.startswith("secondary"):
            src_hint = "secondary"
        paras, meta, degs = kg.load_document(path, src_hint)
        # try to align source_id with manifest DOI/title
        if isinstance(meta, dict) and meta.get("doi"):
            src = source_by_doi.get(meta.get("doi"))
            if src:
                for p in paras:
                    p["source_id"] = src
                meta["source_id"] = src
        else:
            src = source_by_doi.get(src_hint)
            if src:
                for p in paras:
                    p["source_id"] = src
                meta["source_id"] = src
        if paras:
            paragraphs.extend(paras)
        if isinstance(meta, dict) and (meta.get("source_id") or meta.get("path")):
            meta_list.append(meta)
        degradations.extend(degs or [])
    return paragraphs, meta_list, manifest_entries, degradations


def make_gaps(paragraphs, nodes, edges, degradations, missing_files):
    gaps = [{"scope": "material", "note": "missing: %s" % m} for m in missing_files]
    gaps += [{"scope": "degradation", "note": d} for d in degradations]
    if not paragraphs:
        gaps.append({"scope": "paragraph", "note": "no paragraphs extracted"})
    if not nodes:
        gaps.append({"scope": "entity", "note": "no entities extracted"})
    if not edges:
        gaps.append({"scope": "relation", "note": "no evidence-backed relations extracted"})
    return gaps


def load_draft(work_dir):
    draft, err = kg.load_json(work_dir / "draft.json")
    if err or not isinstance(draft, dict):
        return None
    return draft


def assemble_graph(paragraphs, meta_list, degradations, missing_files, draft):
    if draft is not None:
        nodes = draft.get("nodes", []) or []
        edges = draft.get("edges", []) or []
        alignments = draft.get("alignments", []) or []
        queries = draft.get("queries", []) or []
        gaps = draft.get("gaps", []) or []
        changes = draft.get("change_records", []) or []
    else:
        nodes, edges = kg.extract_fallback(paragraphs, meta_list)
        alignments = kg.compute_alignments(nodes)
        queries = kg.compute_queries(nodes, edges, alignments)
        gaps = []
        changes = [{"action": "fallback_extraction",
                    "detail": "rule-based extraction; refine in draft.json"}]
    if not gaps:
        gaps = make_gaps(paragraphs, nodes, edges, degradations, missing_files)
    if not changes:
        changes = [{"action": "init", "detail": "graph assembled from work draft"}]
    hits, miss, rate = kg.verify_quotes(paragraphs, nodes, edges)
    if miss:
        changes.append({"action": "quote_verification",
                        "detail": "%d quote misses out of %d refs" %
                        (miss, hits + miss)})
    graph = kg.build_graph(paragraphs, meta_list, nodes, edges, alignments,
                           queries, gaps, changes, degradations, rate)
    return graph, rate


def write_partial(case, output_dir, reason):
    result = {}
    if isinstance(case, dict):
        result["case_id"] = case.get("case_id") or case.get("id")
    fields, _ = kg.contract_fields(case)
    for fname, _spec in fields:
        result[fname] = None
    for k, v in {"status": "partial", "sources": [], "uncertainty": [],
                 "change_records": [{"action": "partial", "detail": reason}],
                 "errors": [], "degradations": [reason]}.items():
        if k not in result:
            result[k] = v
    kg.write_json(output_dir / "result.json", result)


def run_full(input_dir, work_dir, output_dir):
    work_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    case, case_err = kg.load_case(input_dir / "case.json")
    if case_err:
        status = "input_error"  # malformed or missing case.json is an input error
        write_partial(case or {}, output_dir, "case_error:%s" % case_err)
        result = {"case_id": None, "status": status,
                  "errors": [case_err],
                  "degradations": ["case_error:%s" % case_err]}
        kg.write_json(output_dir / "result.json", result)
        return result

    # early partial
    write_partial(case, output_dir, "pipeline_started")

    missing_files = [f for f in ("case.json", "corpus-manifest.json")
                     if not (input_dir / f).exists()]

    try:
        paragraphs, meta_list, manifest_entries, degradations = \
            load_materials(input_dir)
    except Exception as exc:
        paragraphs, meta_list, manifest_entries, degradations = [], [], [], \
            ["load_error:%s" % exc]

    draft = load_draft(work_dir)
    try:
        graph, rate = assemble_graph(paragraphs, meta_list, degradations,
                                     missing_files, draft)
    except Exception as exc:
        graph, rate = kg.build_graph(paragraphs, meta_list, [], [], [], [],
                                     [{"scope": "error", "note": str(exc)}],
                                     [], degradations, 0.0), 0.0

    status = _status_from(graph.get("nodes", []), graph.get("edges", []),
                          paragraphs, degradations, None)
    if (not graph.get("nodes") and paragraphs) or rate < 0.95 or \
            (paragraphs and (not graph.get("edges") or len(graph.get("queries", [])) < 3)):
        status = "partial"
    if rate < 0.95:
        degradations.append("quote_hit_rate_below_0.95: %.3f" % rate)

    result = kg.echo_contract(case, graph, status, degradations)

    # artifacts
    kg.write_json(output_dir / "result.json", result)
    kg.write_json(output_dir / "graph.json", graph)
    # Export text-based, editable graph representations; never require Graphviz.
    dot = ['digraph LiteratureKG {', '  rankdir=LR;']
    for node in graph.get('nodes', []):
        nid = str(node.get('id', ''))
        label = str(node.get('name', '')).replace('\\', '\\\\').replace('"', '\\"').replace('\n', ' ')
        dot.append('  "%s" [label="%s"];' % (nid, label))
    for edge in graph.get('edges', []):
        dot.append('  "%s" -> "%s" [label="%s"];' %
                   (str(edge.get('subject','')), str(edge.get('object','')),
                    str(edge.get('type','')).replace('"', '')))
    dot.append('}')
    (output_dir / 'graph.dot').write_text('\n'.join(dot) + '\n', encoding='utf-8')
    lines = ['# Evidence-grounded knowledge graph', '',
             'Nodes: %s; edges: %s; queries: %s; quote hit rate: %.3f' %
             (len(graph.get('nodes', [])), len(graph.get('edges', [])),
              len(graph.get('queries', [])), rate), '', '## Nodes', '']
    for node in graph.get('nodes', []):
        mentions = node.get('mentions') or []
        evidence = mentions[0] if mentions else {}
        lines.append('- %s (%s) — %s / %s: %s' %
                     (node.get('name',''), node.get('type',''),
                      evidence.get('source_id','?'), evidence.get('paragraph_id','?'),
                      evidence.get('quote','')))
    lines += ['', '## Relations', '']
    for edge in graph.get('edges', []):
        lines.append('- %s: %s -> %s' %
                     (edge.get('type',''), edge.get('subject',''), edge.get('object','')))
    lines += ['', '## Executed queries', '']
    for query in graph.get('queries', []):
        lines.append('- %s: %s' % (query.get('question',''), query.get('result','')))
    (output_dir / 'graph.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    kg.write_json(work_dir / "draft.json", graph)
    return result


def run_init(input_dir, work_dir, output_dir):
    work_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    missing_files = [f for f in ("case.json", "corpus-manifest.json")
                     if not (input_dir / f).exists()]
    paragraphs, meta_list, manifest_entries, degradations = load_materials(input_dir)
    nodes, edges = kg.extract_fallback(paragraphs, meta_list)
    alignments = kg.compute_alignments(nodes)
    queries = kg.compute_queries(nodes, edges, alignments)
    gaps = make_gaps(paragraphs, nodes, edges, degradations, missing_files)
    draft = kg.build_graph(paragraphs, meta_list, nodes, edges, alignments,
                           queries, gaps,
                           [{"action": "init",
                             "detail": "fallback draft for agent refinement"}],
                           degradations, 1.0)
    kg.write_json(work_dir / "draft.json", draft)
    kg.write_json(work_dir / "materials.json",
                  {"paragraphs": paragraphs, "manifest": manifest_entries})
    print("draft: %s" % (work_dir / "draft.json"))
    print("materials: %s" % (work_dir / "materials.json"))
    print("nodes=%d edges=%d paragraphs=%d" %
          (len(nodes), len(edges), len(paragraphs)))
    return draft


def run_show(work_dir, output_dir):
    for p in (work_dir / "draft.json", output_dir / "result.json"):
        if p.exists():
            obj, _ = kg.load_json(p)
            if isinstance(obj, dict):
                g = obj.get("graph") if isinstance(obj.get("graph"), dict) else obj
                print("== %s" % p.name)
                print("  case_id=%s status=%s nodes=%d edges=%d" %
                      (obj.get("case_id"), obj.get("status"),
                       len(g.get("nodes", [])), len(g.get("edges", []))))
    return {}


def run_check(input_dir, work_dir, output_dir):
    paragraphs, meta_list, _m, degradations = load_materials(input_dir)
    draft = load_draft(work_dir)
    nodes = (draft or {}).get("nodes", []) or []
    edges = (draft or {}).get("edges", []) or []
    hits, miss, rate = kg.verify_quotes(paragraphs, nodes, edges)
    case, err = kg.load_case(input_dir / "case.json")
    fields, _ = kg.contract_fields(case)
    missing_keys = []
    if output_dir.joinpath("result.json").exists():
        res, _ = kg.load_json(output_dir / "result.json")
        if isinstance(res, dict):
            missing_keys = [f for f, _s in fields if f not in res]
    print("quote_hit_rate=%.4f hits=%d miss=%d" % (rate, hits, miss))
    print("contract_fields=%d missing_in_result=%d" %
          (len(fields), len(missing_keys)))
    print("degradations=%s" % degradations)
    if err:
        print("case_error=%s" % err)
    return {"quote_hit_rate": rate, "hits": hits, "miss": miss,
            "missing_keys": missing_keys}


def run_build(input_dir, work_dir, output_dir):
    return run_full(input_dir, work_dir, output_dir)


def _usage():
    return ("usage: python scripts/main.py [init|show|check|build] "
            "[--input DIR] [--work DIR] [--output DIR]; env INPUT_DIR/WORK_DIR/OUTPUT_DIR\n")


def main(argv):
    if any(a in ("-h", "--help") for a in argv):
        print(_usage())
        return 0
    input_dir, work_dir, output_dir = resolve_dirs(argv)
    sub = None
    for a in argv:
        if a in ("init", "show", "check", "build"):
            sub = a
            break
    try:
        if sub == "init":
            run_init(input_dir, work_dir, output_dir)
        elif sub == "show":
            run_show(work_dir, output_dir)
        elif sub == "check":
            run_check(input_dir, work_dir, output_dir)
        elif sub == "build":
            run_build(input_dir, work_dir, output_dir)
        else:
            run_full(input_dir, work_dir, output_dir)
    except Exception as exc:
        # never crash; write an honest error result
        try:
            output_dir.mkdir(parents=True, exist_ok=True)
            kg.write_json(output_dir / "result.json",
                          {"case_id": None, "status": "input_error",
                           "errors": [str(exc)],
                           "degradations": ["fatal:%s" % exc]})
        except Exception:
            pass
        print("fatal_error=%s" % exc, file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

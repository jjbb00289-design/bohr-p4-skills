import re

SECTION_HINTS = [
    "abstract", "introduction", "background", "related work", "method", "methods", "materials",
    "experiment", "experimental", "results", "discussion", "conclusion", "conclusions",
    "references", "acknowledgment", "acknowledgements", "appendix", "supplementary",
]


def _norm(s):
    return re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()


def _clean(s):
    return re.sub(r"\s+", " ", s).strip()


def split_paragraphs(text):
    out = []
    for c in re.split(r"\n\s*\n+", text or ""):
        c = c.strip()
        if c:
            lines = [ln.rstrip() for ln in c.split("\n") if ln.strip()]
            out.append({"lines": lines, "text": _clean(" ".join(lines))})
    return out


def _split_sentences(t):
    parts = re.split(r"(?<=[.!?])\s+(?=[A-Z(0-9])", t)
    return [_clean(p) for p in parts if p.strip()]


def guess_section(text):
    t = _clean(text).lower()
    for h in SECTION_HINTS:
        if t == h or t.startswith(h + ":") or re.match(r"^[\d.]*\.?\s*" + re.escape(h) + r"\b", t):
            return h.title()
    if re.match(r"^\d+(\.\d+)*\s+\w", t) and len(t) < 90:
        return _clean(t)
    return "Body"


UNIT_ALT = (r"mmol/L|mmol/l|mg/dL|mg/ml|g/L|mL/min|participants|minutes|seconds|patients|"
            r"samples|weeks|months|years|hours|cells|kHz|MHz|GHz|kPa|MPa|mV|mA|eV|mol|"
            r"cm|mm|kg|mg|μg|ug|μm|um|nm|°C|Hz|Pa|mL|g|L|K|V|A|W|J|M|s|min|h")
NUM_RE = re.compile(r"\b\d[\d,]*(?:\.\d+)?(?:\s*[x×]\s*\d[\d,.]*)?\s*(?:%|(?:" + UNIT_ALT + r")\b)?", re.I)
CIT_RE = re.compile(r"\[\d+(?:[-,]\d+)*\]|\([A-Z][A-Za-z]+(?:\s+et\s+al\.?)?,?\s+\d{4}\)|[A-Z][a-z]+(?:\s+(?:and|&)\s+[A-Z][a-z]+)?,?\s+\d{4}")
NEG_RE = re.compile(r"\b(no|not|neither|nor|never|without|absence|absent|unable|failed to|does not|did not|do not|is not|are not|was not|were not|cannot|less than|fewer than|none|lacks?|unlike)\b", re.I)
FORMULA_RE = re.compile(r"[=±∑∫√∞→≈≤≥×÷]|[A-Za-z]_\w|\w\^\w")
ACRONYM_RE = re.compile(r"\b[A-Z]{2,}\d?(?:[-/][A-Z0-9]+)*\b")
CJK_NEG = {"不", "无", "非", "未", "没有", "不能", "无法", "缺乏", "缺失", "未发现", "低于", "少于", "无显著"}
SYMBOLIC_UNITS = {"%", "°C", "mmol/L", "mmol/l", "mg/dL", "mg/ml", "g/L", "mL/min", "mg", "mL", "kg",
                  "μg", "ug", "μM", "uM", "mM", "nM", "pM", "μL", "uL", "cm", "mm", "μm", "um", "nm",
                  "kHz", "MHz", "GHz", "kPa", "MPa", "mV", "mA", "eV", "mol", "Å"}
NEG_KEYS = ("no", "not", "neither", "nor", "never", "without", "unable", "cannot", "none",
            "lack", "less", "fewer", "unlike")


def analyze_facts(source):
    numbers = []
    for m in NUM_RE.finditer(source):
        raw = m.group(0).strip()
        vm = re.match(r"\d[\d,\.]*", raw)
        unit = "%" if "%" in raw else ""
        if not unit:
            um = re.search(r"(?:" + UNIT_ALT + r")\b", raw, re.I)
            if um:
                unit = um.group(0)
        numbers.append({"value": vm.group(0) if vm else raw, "unit": unit, "raw": raw})
    return {"numbers": numbers, "formulas": [m.group(0) for m in FORMULA_RE.finditer(source)],
            "citations": [m.group(0) for m in CIT_RE.finditer(source)],
            "negations": [m.group(0) for m in NEG_RE.finditer(source)]}


def build_paragraphs(text, blocks=None, page_map=None):
    if blocks and page_map is None:
        page_map = [(b.get("page"), b.get("text")) for b in blocks if b.get("text")]
    out = []
    for idx, rp in enumerate(split_paragraphs(text)):
        page = None
        if page_map:
            for pg, bt in page_map:
                if rp["text"][:60] in bt:
                    page = pg
                    break
        terms = [{"term": m.group(0), "norm": _norm(m.group(0))} for m in ACRONYM_RE.finditer(rp["text"])]
        sentences = _split_sentences(rp["text"])
        out.append({"pid": "p%d" % (idx + 1), "page": page, "section": guess_section(rp["text"]),
                    "order": idx, "kind": "body", "source": rp["text"], "quote": rp["text"],
                    "sentences": [{"sid": "p%d.s%d" % (idx + 1, j + 1), "source": s, "quote": s}
                                  for j, s in enumerate(sentences)],
                    "terms": terms, "facts": analyze_facts(rp["text"]),
                    "translation": None, "translation_notes": [], "verify": None})
    return out


def extract_terminology(paragraphs, glossary=None):
    glossary = glossary or {}
    counts, seen, canonical = {}, {}, {}
    for p in paragraphs:
        found = {t["norm"]: t["term"] for t in p["terms"] if t.get("norm")}
        normalized = " " + _norm(p["source"]) + " "
        for key in glossary:
            if key and (" " + key + " ") in normalized:
                found.setdefault(key, key)
        for n, term in found.items():
            counts[n] = counts.get(n, 0) + 1
            seen.setdefault(n, []).append(p["pid"])
            if n not in canonical or len(term) > len(canonical[n]):
                canonical[n] = term
    return [{"term": canonical[n], "norm": n, "zh": glossary.get(n),
             "status": "locked" if glossary.get(n) else "proposed", "occurrences": seen[n]}
            for n, _ in sorted(counts.items(), key=lambda x: (-x[1], x[0]))]


def _digits(s):
    return re.sub(r"\D", "", s)


def verify_paragraph(p):
    if not p.get("translation"):
        return None
    t = p["translation"]
    facts = p.get("facts", {})
    flags = []
    for num in facts.get("numbers", []):
        if _digits(num["raw"]) not in _digits(t):
            flags.append({"check": "number", "raw": num["raw"], "issue": "数字/量值未在译文中命中"})
        elif num.get("unit") and num["unit"] in SYMBOLIC_UNITS and num["unit"].lower() not in t.lower():
            flags.append({"check": "unit", "raw": num["raw"], "issue": "单位可能在译文中缺失"})
    for c in facts.get("citations", []):
        if c not in t and _digits(c) not in _digits(t):
            flags.append({"check": "citation", "raw": c, "issue": "文献编号未在译文中保留"})
    for f in facts.get("formulas", []):
        if f not in t:
            flags.append({"check": "formula", "raw": f, "issue": "公式/符号未在译文中保留"})
    for neg in facts.get("negations", []):
        if any(k in neg.lower() for k in NEG_KEYS) and not any(ch in t for ch in CJK_NEG):
            flags.append({"check": "negation", "raw": neg, "issue": "否定关系可能丢失"})
    return {"flags": flags, "needs_review": len(flags) > 0, "quote_in_source": bool(p.get("source", ""))}


def quote_hit_rate(paras, full_text):
    if not paras:
        return 1.0
    nflat = _clean(full_text)
    hit = total = 0
    for p in paras:
        q = _clean(p.get("quote", ""))
        if not q:
            continue
        total += 1
        if q[:200] in nflat:
            hit += 1
        else:
            sent = p.get("sentences", [])
            if sent and sum(1 for s in sent if _clean(s["quote"])[:120] in nflat) >= max(1, len(sent) // 2):
                hit += 1
    return (hit / total) if total else 1.0

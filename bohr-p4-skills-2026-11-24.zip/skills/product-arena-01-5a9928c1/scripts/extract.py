import os
import re
import sqlite3
import struct
import zipfile
import zlib


def _read_bytes(path):
    with open(path, "rb") as f:
        return f.read()


def _decode_text(data):
    for enc in ("utf-8", "utf-8-sig", "gb18030", "latin-1"):
        try:
            return data.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode("latin-1", "replace")


def extract_txt(path):
    text = _decode_text(_read_bytes(path))
    return {"type": "txt", "text": text, "meta": {"path": path}, "degradations": []}


def extract_docx(path):
    try:
        with zipfile.ZipFile(path) as z:
            xml = z.read("word/document.xml").decode("utf-8", "replace")
            paras = []
            for p in re.split(r"</w:p>", xml):
                line = "".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", p, re.S))
                line = (line.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                        .replace("&quot;", '"').replace("&apos;", "'"))
                if line.strip():
                    paras.append(line)
        return {"type": "docx", "text": "\n\n".join(paras), "meta": {"path": path}, "degradations": []}
    except Exception as e:
        return {"type": "docx", "text": "", "meta": {"path": path}, "degradations": ["docx_parse_failed: %s" % e]}


def extract_sqlite(path):
    try:
        con = sqlite3.connect(path)
        cur = con.cursor()
        tables = [r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        lines = []
        for t in tables:
            lines.append("TABLE " + t)
            try:
                cols = [c[1] for c in cur.execute("PRAGMA table_info(%s)" % t)]
                for r in cur.execute("SELECT * FROM %s LIMIT 200" % t).fetchall():
                    lines.append(" | ".join("%s=%s" % (c, v) for c, v in zip(cols, r)))
            except Exception:
                pass
        con.close()
        return {"type": "sqlite", "text": "\n".join(lines), "meta": {"path": path, "tables": tables}, "degradations": []}
    except Exception as e:
        return {"type": "sqlite", "text": "", "meta": {"path": path}, "degradations": ["sqlite_parse_failed: %s" % e]}


def _image_info(data):
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png", struct.unpack(">II", data[16:24])
    if data[:2] == b"\xff\xd8":
        return "jpg", None, None
    return "image", None, None


def extract_image(path):
    try:
        data = _read_bytes(path)
        fmt, w, h = _image_info(data)
    except Exception:
        fmt, w, h, data = "image", None, None, b""
    return {"type": "image", "text": "", "meta": {"path": path, "format": fmt, "width": w, "height": h},
            "degradations": ["image_not_ocr: content requires OCR, not guessed"]}


def _decode_literal(s):
    out = bytearray()
    i, n = 0, len(s)
    while i < n:
        c = s[i]
        if c == 0x5C and i + 1 < n:
            nxt = s[i + 1]
            if nxt in b"()\\":
                out.append(nxt)
                i += 2
            elif nxt in b"nrtbf":
                out.append({110: 10, 114: 13, 116: 9, 98: 8, 102: 12}[nxt])
                i += 2
            elif 48 <= nxt <= 55:
                j, v = i + 1, 0
                while j < n and j < i + 4 and 48 <= s[j] <= 55:
                    v = v * 8 + (s[j] - 48)
                    j += 1
                out.append(v & 0xFF)
                i = j
            else:
                out.append(c)
                i += 2
        else:
            out.append(c)
            i += 1
    return bytes(out)


def _hex_to_text(hx):
    hx = hx.replace(b" ", b"")
    if len(hx) % 2:
        hx += b"0"
    try:
        raw = bytes.fromhex(hx.decode("ascii"))
    except Exception:
        return ""
    for enc in ("utf-16-be", "utf-8"):
        try:
            t = raw.decode(enc)
            if t and not any(0 < ord(ch) < 32 and ch not in "\n\t" for ch in t):
                return t
        except UnicodeDecodeError:
            continue
    return ""


def _parse_tounicode(streams):
    cmap = {}
    for s in streams:
        if b"beginbfchar" not in s and b"beginbfrange" not in s:
            continue
        for m in re.finditer(rb"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", s):
            dst = _hex_to_text(m.group(2))
            if dst:
                cmap[m.group(1).decode("ascii").upper()] = dst
        for m in re.finditer(rb"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", s):
            try:
                lo, hi = int(m.group(1), 16), int(m.group(2), 16)
                base = ord(_hex_to_text(m.group(3)))
                for code in range(lo, hi + 1):
                    cmap["%04X" % code] = chr(base + code - lo)
            except Exception:
                continue
    return cmap


_CS_RE = re.compile(
    rb"\(((?:[^()\\]|\\.)*)\)\s*Tj"
    rb"|\[((?:[^\[\]]|\([^()\\]*\))*)\]\s*TJ"
    rb"|<([0-9A-Fa-f\s]{2,})>\s*Tj"
    rb"|T\*|ET")


def _extract_cs(cs, cmap):
    out = []
    for m in _CS_RE.finditer(cs):
        if m.group(1) is not None:
            out.append(_to_text(_decode_literal(m.group(1))))
        elif m.group(2) is not None:
            buf = []
            for sm in re.finditer(rb"\(((?:[^()\\]|\\.)*)\)|<([0-9A-Fa-f\s]+)>", m.group(2)):
                if sm.group(1) is not None:
                    buf.append(_to_text(_decode_literal(sm.group(1))))
                else:
                    buf.append(cmap.get(sm.group(2).replace(b" ", b"").decode("ascii").upper(), ""))
            out.append("".join(buf))
        elif m.group(3) is not None:
            out.append(cmap.get(m.group(3).replace(b" ", b"").decode("ascii").upper(), ""))
        else:
            out.append("\n")
    text = "".join(out)
    return re.sub(r"\n{3,}", "\n\n", re.sub(r"[ \t]+\n", "\n", text))


def _to_text(b):
    try:
        return b.decode("utf-8")
    except UnicodeDecodeError:
        return b.decode("latin-1", "replace")


def _pdf_err(path, msg):
    return {"type": "pdf", "text": "", "pages": 0, "blocks": [], "meta": {"path": path}, "degradations": [msg]}


def extract_pdf(path):
    try:
        data = _read_bytes(path)
    except Exception as e:
        return _pdf_err(path, "pdf_read_failed: %s" % e)
    if not data.startswith(b"%PDF-"):
        return _pdf_err(path, "not_a_pdf: missing %%PDF header")

    obj_re = re.compile(rb"(\d+)\s+(\d+)\s+obj\b")
    objs, order = {}, []
    for m in obj_re.finditer(data):
        num = int(m.group(1))
        start = m.end()
        end = data.find(b"endobj", start)
        body = data[start:end if end >= 0 else len(data)]
        sp = body.find(b"stream")
        dictpart, stream = body, None
        if sp >= 0:
            dictpart = body[:sp]
            s0 = sp + 6
            if body.startswith(b"\r\n", s0):
                s0 += 2
            elif body.startswith(b"\n", s0):
                s0 += 1
            e0 = body.find(b"endstream", s0)
            if e0 >= 0:
                raw = body[s0:e0]
                if raw.endswith(b"\r\n"):
                    raw = raw[:-2]
                elif raw.endswith(b"\n"):
                    raw = raw[:-1]
                stream = raw
        objs[num] = {"dict": dictpart, "stream": stream}
        order.append(num)

    page_contents = []
    for num in order:
        d = objs[num]["dict"]
        if re.search(rb"/Type\s*/Page\b", d) and not re.search(rb"/Type\s*/Pages\b", d):
            m = re.search(rb"/Contents\s*(\[[^\]]*\]|\d+\s+\d+\s+R)", d)
            page_contents.append([int(rm.group(1)) for rm in re.finditer(rb"(\d+)\s+\d+\s+R", m.group(1))] if m else [])

    decompressed = []
    for num in order:
        d, s = objs[num]["dict"], objs[num]["stream"]
        if s is None or re.search(rb"/DCTDecode|/JPXDecode", d):
            continue
        if re.search(rb"/FlateDecode", d) or s[:2] in (b"\x78\x9c", b"\x78\x01", b"\x78\xda"):
            try:
                dec = zlib.decompress(s)
            except zlib.error:
                try:
                    dec = zlib.decompress(s, -15)
                except zlib.error:
                    dec = s
        elif re.search(rb"/ASCIIHexDecode", d):
            try:
                dec = bytes.fromhex(s.decode("ascii").replace(">", "").replace(" ", "").replace("\n", ""))
            except Exception:
                dec = s
        else:
            dec = s
        decompressed.append((num, dec))

    cmap = _parse_tounicode([dec for _, dec in decompressed])
    blocks = []
    for num, dec in decompressed:
        if b"Tj" not in dec and b"TJ" not in dec:
            continue
        text = _extract_cs(dec, cmap)
        if not text.strip():
            continue
        page = next((pn + 1 for pn, refs in enumerate(page_contents) if num in refs), None)
        if page is None and page_contents:
            page = len(page_contents)
        blocks.append({"page": page, "text": text, "obj": num})

    full = "\n\n".join(b["text"] for b in blocks)
    pages = len(page_contents) or (max((b["page"] or 0) for b in blocks) if blocks else 0)
    degr = [] if blocks else ["pdf_no_text_layer_or_unparsed_streams: 0 text blocks extracted"]
    if pages == 0:
        degr.append("pdf_page_tree_unresolved")
    return {"type": "pdf", "text": full, "pages": pages, "blocks": blocks, "meta": {"path": path},
            "degradations": degr}


def extract_file(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        return extract_pdf(path)
    if ext == ".docx":
        return extract_docx(path)
    if ext in (".sqlite", ".sqlite3", ".db"):
        return extract_sqlite(path)
    if ext in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff"):
        return extract_image(path)
    return extract_txt(path)

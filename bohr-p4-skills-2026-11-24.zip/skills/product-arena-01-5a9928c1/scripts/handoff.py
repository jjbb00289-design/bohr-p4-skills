"""Agent handoff: honest paragraph queue, editable glossary, strict import gates."""
import csv
import hashlib
import json
import os
import re


def source_hash(source):
    return hashlib.sha256(source.encode("utf-8")).hexdigest()


def is_substantive_translation(source, translation):
    if not isinstance(translation, str):
        return False
    t = translation.strip()
    s = (source or "").strip()
    if not t or t.lower() in {"array", "string", "object", "translation", "tbd", "todo", "n/a",
                                "null", "none", "译文", "待翻译", "未译", "[未译]", "[待译]"}:
        return False
    normalize = lambda v: re.sub(r"\s+", "", v).lower()
    if normalize(t) == normalize(s):
        return False
    source_words = re.findall(r"[A-Za-z]+", s)
    cjk_chars = re.findall(r"[\u4e00-\u9fff]", t)
    if source_words and len(cjk_chars) < min(20, max(2, int(len(source_words) * 0.4))):
        return False
    return True


def _entry_index(work):
    return {t.get("norm") or re.sub(r"[^a-z0-9]+", " ", t["term"].lower()).strip(): t
            for t in work["document"].get("terminology", [])}


def merge_term_entries(work, entries, gaps, allow_override=False):
    if not isinstance(entries, list):
        return
    indexed = _entry_index(work)
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        norm = re.sub(r"[^a-z0-9]+", " ", str(entry.get("term") or "").lower()).strip()
        zh = str(entry.get("zh") or "").strip()
        if not norm or not zh or not re.search(r"[\u4e00-\u9fff]", zh):
            continue
        if norm in indexed:
            previous = indexed[norm].get("zh")
            if previous and previous != zh and not (allow_override or entry.get("override") is True):
                gaps.append({"item": "conflicting_terminology", "term": entry["term"],
                             "reason": "locked term differs from current glossary; use override=true to change"})
                continue
            indexed[norm]["zh"] = zh
            indexed[norm]["status"] = "locked"
        else:
            occurrences = []
            for p in work["document"].get("paragraphs", []):
                source_norm = " " + re.sub(r"[^a-z0-9]+", " ", p.get("source", "").lower()).strip() + " "
                if (" " + norm + " ") in source_norm:
                    occurrences.append(p["pid"])
            if occurrences:
                term = {"term": entry["term"], "norm": norm, "zh": zh, "status": "locked",
                        "occurrences": occurrences}
                work["document"].setdefault("terminology", []).append(term)
                indexed[norm] = term
            else:
                gaps.append({"item": "unsupported_terminology", "term": entry["term"],
                             "reason": "proposed term does not occur verbatim in source"})


def sync_term_tsv(work, path):
    if not os.path.isfile(path):
        return
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f, delimiter="\t"))
    terms = []
    for row in rows:
        if len(row) >= 2 and row[0].strip().lower() != "term":
            terms.append({"term": row[0].strip(), "zh": row[1].strip()})
    merge_term_entries(work, terms, work.setdefault("gaps", []), allow_override=True)


def prepare_queue(work, work_dir, output_dir):
    """Create source-bound prompts for the running language-model Agent.

    No fake translations are produced here: a language-capable Agent reads the
    queue, authors Chinese translations, and writes translations.json/work.json.
    """
    ps = work["document"]["paragraphs"]
    terms = [dict(term=t["term"], zh=t["zh"], occurrences=t["occurrences"])
             for t in work["document"].get("terminology", []) if t.get("zh")]
    items = []
    for i, p in enumerate(ps):
        if is_substantive_translation(p["source"], p.get("translation")):
            continue
        items.append({"pid": p["pid"], "source_sha256": source_hash(p["source"]),
                      "file": p.get("file"), "page": p.get("page"), "section": p.get("section"),
                      "source": p["source"], "quote": p.get("quote", p["source"]),
                      "previous_context": ps[i - 1]["source"][-180:] if i else "",
                      "next_context": ps[i + 1]["source"][:180] if i + 1 < len(ps) else "",
                      "locked_terms": [t for t in terms if p["pid"] in t["occurrences"]],
                      "protected_facts": p.get("facts", {})})
    payload = {"schema": "lit-translate/translation-queue-v2", "case_id": work.get("case_id"),
               "target_language": "zh-CN", "pending_count": len(items),
               "locked_terminology": terms, "items": items}
    for base in (work_dir, output_dir):
        os.makedirs(base, exist_ok=True)
        with open(os.path.join(base, "translation_queue.json"), "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
    # editable glossary is exported to the WORK area once, not overwritten after editing
    tsv_path = os.path.join(work_dir, "terminology.tsv")
    if not os.path.isfile(tsv_path):
        with open(tsv_path, "w", encoding="utf-8") as f:
            f.write("term\tzh\tstatus\toccurrences\n")
            for t in work["document"].get("terminology", []):
                f.write("%s\t%s\t%s\t%s\n" % (t["term"], t.get("zh") or "",
                                                         t.get("status", "proposed"),
                                                         ",".join(t.get("occurrences", []))))
    return payload

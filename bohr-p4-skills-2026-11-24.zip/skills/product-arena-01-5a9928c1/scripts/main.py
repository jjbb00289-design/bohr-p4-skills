import json
import os
import sys
import hashlib
import re

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import extract as ex
import verify as vf
import handoff as ho

DEFAULTS = {"input": "/input", "work": "/app/work", "output": "/app/output"}
USAGE = """usage: python main.py [build|init|show|batch|check] [--input DIR] [--work DIR] [--output DIR]
  build(default): extract -> segment -> terms -> merge -> verify -> finalize
  init : extract + segment + terms -> work.json + partial result.json
  show : print current work.json
  batch: print next untranslated paragraph batch for Agent translation
  check: merge translations.json and edited work.json + verify -> final result.json
Env: INPUT_DIR, WORK_DIR, OUTPUT_DIR. Exits 0 on every path."""


def resolve_dirs(argv):
    d = dict(DEFAULTS)
    for k, env in (("input", "INPUT_DIR"), ("work", "WORK_DIR"), ("output", "OUTPUT_DIR")):
        if os.environ.get(env):
            d[k] = os.environ[env]
    keys = {"--input": "input", "--work": "work", "--output": "output"}
    cmd, pos, i = "build", [], 0
    while i < len(argv):
        a = argv[i]
        if a in keys and i + 1 < len(argv):
            d[keys[a]] = argv[i + 1]
            i += 2
        elif a in ("--help", "-h"):
            return d, "help"
        elif a.startswith("--"):
            i += 1
        else:
            pos.append(a)
            i += 1
    if pos and pos[0] in ("build", "init", "show", "batch", "check"):
        cmd = pos[0]
    return d, cmd


def read_json(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def write_text(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def load_case(input_dir):
    p = os.path.join(input_dir, "case.json")
    if not os.path.isfile(p):
        return None, "case.json missing"
    try:
        return read_json(p), None
    except Exception as e:
        return None, "case.json invalid: %s" % e


def material_refs(case, input_dir):
    refs = []
    if isinstance(case, dict):
        for key in ("materials", "files", "documents", "attachments", "sources", "inputs"):
            val = case.get(key)
            if isinstance(val, list):
                for it in val:
                    if isinstance(it, str):
                        refs.append((it, "material"))
                    elif isinstance(it, dict):
                        p = it.get("path") or it.get("file") or it.get("name") or it.get("src") or it.get("url")
                        if p:
                            refs.append((p, it.get("role", "material")))
            elif isinstance(val, str):
                refs.append((val, "material"))
    try:
        for name in sorted(os.listdir(input_dir)):
            if name not in ("case.json", "task.md") and os.path.isfile(os.path.join(input_dir, name)):
                refs.append((name, "material"))
    except OSError:
        pass
    resolved, seen = [], set()
    for p, role in refs:
        if not p.startswith(("http", "file:")):
            full = os.path.normpath(p if os.path.isabs(p) else os.path.join(input_dir, p))
            base = os.path.realpath(input_dir)
            real = os.path.realpath(full)
            if (real == base or real.startswith(base + os.sep)) and real not in seen and os.path.isfile(real):
                seen.add(real)
                resolved.append((real, role))
    return resolved


def build_work(case, task_instruction, materials, input_dir):
    input_materials, all_text, blocks, degradations = [], [], [], []
    paragraphs = []
    for path, role in materials:
        try:
            r = ex.extract_file(path)
        except Exception as e:
            r = {"type": os.path.splitext(path)[1], "text": "", "meta": {"path": path},
                 "degradations": ["extract_failed: %s" % e]}
        input_materials.append({"path": path, "role": role, "type": r.get("type"),
                                "pages": r.get("pages", 0), "text_len": len(r.get("text", ""))})
        degradations.extend({"path": path, "type": r.get("type"), "reason": dg} for dg in r.get("degradations", []))
        if r.get("text"):
            all_text.append(r.get("text", ""))
            local_paras = vf.build_paragraphs(r["text"], blocks=r.get("blocks") or None)
            for p in local_paras:
                idx = len(paragraphs) + 1
                p["pid"] = "p%d" % idx
                p["order"] = idx - 1
                p["file"] = path
                for j, sent in enumerate(p.get("sentences", []), 1):
                    sent["sid"] = "p%d.s%d" % (idx, j)
                paragraphs.append(p)
        elif r.get("type") == "image":
            degradations.append({"path": path, "type": "image", "reason": "image content requires OCR, gap recorded"})
        if r.get("type") == "pdf" and r.get("blocks"):
            for b in r["blocks"]:
                b["_file"] = path
                blocks.append(b)
    full = "\n\n".join(all_text)
    # Keep distinct document boundaries; never attribute text from another PDF.
    terminology = vf.extract_terminology(paragraphs, glossary=_load_glossary())
    doc = {"title": _guess_title(full), "paragraphs": paragraphs, "captions": [],
           "references": _extract_references(paragraphs), "terminology": terminology}
    return {"schema": "lit-translate/work-v1",
            "case_id": case.get("case_id") if isinstance(case, dict) else None,
            "task_instruction": task_instruction, "input_materials": input_materials, "document": doc,
            "verification": {}, "gaps": [], "degradations": degradations,
            "change_records": [{"step": "build_work", "status": "ok",
                                "detail": "%d paragraphs, %d terms" % (len(paragraphs), len(terminology))}]}, []


def _file_for(p, blocks):
    for b in blocks:
        if b.get("text") and p.get("source", "") and p["source"][:60] in b["text"]:
            return b.get("_file")
    return None


def _load_glossary():
    ref = os.path.join(HERE, "..", "references", "terminology.tsv")
    if not os.path.isfile(ref):
        return {}
    g = {}
    try:
        for line in open(ref, encoding="utf-8"):
            line = line.rstrip("\n")
            if line and not line.startswith("#"):
                parts = line.split("\t")
                if len(parts) >= 2 and parts[0].strip():
                    g[vf._norm(parts[0])] = parts[1].strip()
    except Exception:
        pass
    return g


def _guess_title(text):
    lines = [l for l in text.split("\n") if l.strip()]
    return lines[0].strip()[:200] if lines else ""


def _extract_references(paragraphs):
    return [{"pid": p["pid"], "text": p["source"]} for p in paragraphs
            if p.get("section", "").lower().startswith(("reference", "bibliograph"))]


def merge_translations(work, work_dir):
    """Import model-authored paragraph translations, never manufacture prose.

    Accepts legacy list and v2 payload {translations:[...],terminology:[...]}.
    Optional source_sha256 prevents stale PID->text matching across cases.
    """
    path = os.path.join(work_dir, "translations.json")
    if not os.path.isfile(path):
        return 0
    try:
        payload = read_json(path)
    except Exception as e:
        work.setdefault("errors", []).append("translations.json invalid: %s" % e)
        return 0
    if isinstance(payload, dict):
        ho.merge_term_entries(work, payload.get("terminology", []), work.setdefault("gaps", []))
        items = payload.get("translations", [])
    else:
        items = payload
    if not isinstance(items, list):
        work.setdefault("errors", []).append("translations.json: translations must be array")
        return 0
    idx = {p["pid"]: p for p in work["document"]["paragraphs"]}
    merged = 0
    for it in items:
        if not isinstance(it, dict) or it.get("pid") not in idx:
            work.setdefault("gaps", []).append({"item": "invalid_translation_entry", "reason": "unknown pid / malformed item"})
            continue
        p = idx[it["pid"]]
        expected = ho.source_hash(p["source"])
        if it.get("source_sha256") and it["source_sha256"] != expected:
            work.setdefault("gaps", []).append({"item": "stale_translation", "pid": p["pid"],
                                                "reason": "source_sha256 does not match current source"})
            continue
        translated = it.get("translation")
        if translated is not None:
            if ho.is_substantive_translation(p["source"], translated):
                p["translation"] = translated.strip()
                p["translation_origin"] = "agent_authored"
                merged += 1
            else:
                work.setdefault("gaps", []).append({"item": "invalid_translation", "pid": p["pid"],
                                                    "reason": "empty, placeholder, source copy or non-Chinese target"})
                p["translation"] = None
        if isinstance(it.get("notes"), list):
            p["translation_notes"] = [str(n) for n in it["notes"]]
    return merged


def verify(work):
    paras = work["document"]["paragraphs"]
    n_flags, needs = 0, []
    for p in paras:
        res = vf.verify_paragraph(p)
        p["verify"] = res
        if res and res.get("flags"):
            n_flags += len(res["flags"])
            needs.append({"pid": p["pid"], "page": p.get("page"), "flags": res["flags"]})
    full = "\n\n".join(p["source"] for p in paras)
    work["verification"] = {"quote_hit_rate": round(vf.quote_hit_rate(paras, full), 4),
                            "n_paragraphs": len(paras),
                            "n_translated": sum(1 for p in paras if ho.is_substantive_translation(p["source"], p.get("translation"))),
                            "n_untranslated": sum(1 for p in paras if not ho.is_substantive_translation(p["source"], p.get("translation"))),
                            "n_flags": n_flags,
                            "terminology_consistency": _term_consistency(work),
                            "needs_human_review": needs}
    return work


def _term_consistency(work):
    paras = {p["pid"]: p for p in work["document"]["paragraphs"]}
    locked = [t for t in work["document"]["terminology"] if t.get("zh")]
    if not locked:
        return {"locked_terms": 0, "consistent": 0, "checked": 0, "rate": 1.0}
    checked = consistent = 0
    for t in locked:
        for pid in t.get("occurrences", []):
            p = paras.get(pid)
            if p and p.get("translation"):
                checked += 1
                if t["zh"] and t["zh"] in p["translation"]:
                    consistent += 1
    return {"locked_terms": len(locked), "consistent": consistent, "checked": checked,
            "rate": round(consistent / checked, 4) if checked else 1.0}


def status_of(work, materials, case_error, text_empty):
    if case_error:
        return "input_error"
    if not materials or text_empty or not work["document"]["paragraphs"]:
        return "insufficient_evidence"
    paras = work["document"]["paragraphs"]
    translated = all(ho.is_substantive_translation(p["source"], p.get("translation")) for p in paras)
    v = work.get("verification", {})
    verified = v.get("n_flags", 0) == 0 and v.get("terminology_consistency", {}).get("rate", 1) == 1.0
    return "complete" if translated and verified else "partial"


def contract_keys(case):
    if not isinstance(case, dict):
        return []
    c = case.get("output_contract")
    if isinstance(c, dict):
        return list(c.keys())
    if isinstance(c, list):
        return [str(x) for x in c]
    return []


def _paras(work):
    return [{"pid": p["pid"], "page": p.get("page"), "section": p.get("section"), "kind": p.get("kind"),
             "file": p.get("file"), "source_sha256": ho.source_hash(p["source"]),
             "source": p["source"], "quote": p["quote"], "translation": p.get("translation"),
             "notes": p.get("translation_notes", []), "verify": p.get("verify"), "facts": p.get("facts")}
            for p in work["document"]["paragraphs"]]


def _summary(work):
    v = work.get("verification", {})
    return ("材料 %d 个，段落 %d 段，已译 %d 段；术语 %d 条；quote 命中率 %.2f；核验标记 %d 处；状态 %s。" %
            (len(work["input_materials"]), v.get("n_paragraphs", 0), v.get("n_translated", 0),
             len(work["document"]["terminology"]), v.get("quote_hit_rate", 0), v.get("n_flags", 0),
             v.get("_status", "partial")))


def fill_contract_value(key, work):
    kl = key.lower()
    if any(w in kl for w in ("translation", "bilingual", "对照", "译文", "translate", "paragraph", "段落", "segment", "alignment")):
        return _paras(work)
    if any(w in kl for w in ("terminolog", "glossary", "术语", "term")):
        return work["document"]["terminology"]
    if any(w in kl for w in ("verification", "checklist", "核验", "自检", "review")):
        return work.get("verification", {})
    if any(w in kl for w in ("summary", "answer", "结论", "概述")):
        return _summary(work)
    if any(w in kl for w in ("reference", "文献")):
        return work["document"]["references"]
    return None


def _err(case, status, detail, is_error):
    r = {"case_id": case.get("case_id") if isinstance(case, dict) else None, "status": status, "sources": [],
         "uncertainty": [{"item": "exception", "reason": detail, "level": "high"}] if is_error else [],
         "change_records": [{"step": status, "status": status, "detail": detail}],
         "errors": [detail] if is_error else [], "degradations": [], "gaps": []}
    if isinstance(case, dict):
        for k in contract_keys(case):
            r.setdefault(k, None)
    return r


def build_result(work, case, case_error, materials, text_empty):
    lifecycle = {"case_id", "status", "sources", "uncertainty", "change_records", "errors",
                 "degradations", "gaps", "translation_coverage"}
    status = status_of(work, materials, case_error, text_empty)
    work.setdefault("verification", {})["_status"] = status
    result = {k: fill_contract_value(k, work) for k in contract_keys(case) if k not in lifecycle}
    gaps = list(work.get("gaps", []))
    unmapped = [k for k, v in result.items() if v is None]
    for k in unmapped:
        gaps.append({"item": "output_contract_key", "key": k,
                     "reason": "skill 没有该契约键的可靠材料；显式 null，禁止输出类型占位词"})
    if unmapped and status == "complete":
        status = "partial"
    work["verification"]["_status"] = status
    result["case_id"] = case.get("case_id") if isinstance(case, dict) else None
    result["status"] = status
    result["sources"] = [{"pid": p["pid"], "file": p.get("file"), "page": p.get("page"),
                          "section": p.get("section"), "quote": p["quote"][:160]}
                         for p in work["document"]["paragraphs"]]
    unc = [{"item": "degradation", "reason": d.get("reason", ""), "file": d.get("path", ""), "level": "high"}
           for d in work.get("degradations", [])]
    unc += [{"item": g.get("item", "gap"), "reason": g.get("reason", ""),
             "key": g.get("key"), "level": "medium"} for g in gaps]
    untranslated = [p["pid"] for p in work["document"]["paragraphs"]
                    if not ho.is_substantive_translation(p["source"], p.get("translation"))]
    if untranslated:
        gaps.append({"item": "untranslated_paragraphs", "pids": untranslated,
                     "reason": "Agent 尚未提交可核验译文；运行 batch，按 source_sha256 回填 translations.json 后 check"})
        unc.append({"item": "untranslated", "count": len(untranslated), "level": "medium"})
    if work.get("verification", {}).get("terminology_consistency", {}).get("rate", 1) < 1:
        gaps.append({"item": "terminology_inconsistency",
                     "reason": "部分已锁定术语未出现在对应段落译文中；需统一术语后重验"})
    if work.get("verification", {}).get("n_flags", 0):
        gaps.append({"item": "translation_verification_flags",
                     "count": work["verification"]["n_flags"],
                     "reason": "存在保留量值、公式、引用或否定关系的核验警告，需要复核"})
    result["translation_coverage"] = {"total": len(work["document"]["paragraphs"]),
                                      "translated": work.get("verification", {}).get("n_translated", 0),
                                      "untranslated_pids": untranslated}
    result["uncertainty"] = unc
    result["change_records"] = work.get("change_records", [])
    result["errors"] = work.get("errors", [])
    result["degradations"] = work.get("degradations", [])
    result["gaps"] = gaps
    return result


def write_artifacts(dirs, work, result):
    o = dirs["output"]
    write_json(os.path.join(o, "work.json"), work)
    write_json(os.path.join(o, "result.json"), result)
    write_text(os.path.join(o, "terminology.tsv"), _tsv(work))
    write_text(os.path.join(o, "translation.md"), _markdown(work))
    write_json(os.path.join(dirs["work"], "work.json"), work)
    ho.prepare_queue(work, dirs["work"], dirs["output"])


def _tsv(work):
    lines = ["term\tzh\tstatus\toccurrences"]
    for t in work["document"]["terminology"]:
        lines.append("\t".join([t["term"], t.get("zh") or "", t["status"], ",".join(t["occurrences"])]))
    return "\n".join(lines) + "\n"


def _markdown(work):
    v = work.get("verification", {})
    lines = ["# 文献双语对照（%s）" % (work.get("case_id") or "unknown"), "",
             "- 段落数：%s；已译：%s；术语：%s" % (v.get("n_paragraphs", 0), v.get("n_translated", 0),
                                                     len(work["document"]["terminology"])),
             "- quote 命中率：%s" % v.get("quote_hit_rate", 0), "",
             "## 术语表", "", "| 原文 | 译文 | 状态 | 出现位置 |", "|---|---|---|---|"]
    for t in work["document"]["terminology"]:
        lines.append("| %s | %s | %s | %s |" % (t["term"], t.get("zh") or "", t["status"],
                                                ", ".join(t["occurrences"])))
    lines += ["", "## 段落对照", ""]
    for p in work["document"]["paragraphs"]:
        head = "### %s" % p["pid"]
        if p.get("page"):
            head += " · page %s" % p["page"]
        if p.get("section"):
            head += " · %s" % p["section"]
        lines += [head, "", "**原文**：%s" % p["source"],
                  "**译文**：%s" % (p.get("translation") or "[未译]")]
        if p.get("translation_notes"):
            lines.append("**依据/说明**：%s" % "；".join(p["translation_notes"]))
        if p.get("verify") and p["verify"].get("flags"):
            for f in p["verify"]["flags"]:
                lines.append("- [核验] %s: %s（原文 %s）" % (f["check"], f["issue"], f.get("raw", "")))
        lines.append("")
    if v.get("needs_human_review"):
        lines += ["## 需要人工确认", ""]
        for n in v["needs_human_review"]:
            lines.append("- %s：%s" % (n["pid"], "；".join(f["issue"] for f in n["flags"])))
    return "\n".join(lines) + "\n"


def run(cmd, dirs):
    i, w, o = dirs["input"], dirs["work"], dirs["output"]
    os.makedirs(w, exist_ok=True)
    os.makedirs(o, exist_ok=True)
    case, ce = load_case(i)
    if cmd == "show":
        wp = os.path.join(w, "work.json")
        sys.stdout.write(json.dumps(read_json(wp), ensure_ascii=False, indent=2) if os.path.isfile(wp) else "{}")
        return 0
    if cmd == "batch":
        qp = os.path.join(w, "translation_queue.json")
        if os.path.isfile(qp):
            queue = read_json(qp)
            sys.stdout.write(json.dumps({"case_id": queue.get("case_id"),
                                         "target_language": queue.get("target_language"),
                                         "locked_terminology": queue.get("locked_terminology", []),
                                         "items": queue.get("items", [])[:8]},
                                        ensure_ascii=False, indent=2))
        else:
            sys.stdout.write(json.dumps({"error": "run init first", "items": []}, ensure_ascii=False))
        return 0
    if ce:
        write_json(os.path.join(o, "result.json"), _err(None, "input_error", ce, True))
        return 0
    tp = os.path.join(i, "task.md")
    task = open(tp, encoding="utf-8-sig").read() if os.path.isfile(tp) else ""
    materials = material_refs(case, i)
    early = {"case_id": case.get("case_id"), "status": "partial", "sources": [], "uncertainty": [],
             "change_records": [{"step": "init", "status": "partial", "detail": "extraction in progress"}],
             "errors": [], "degradations": [], "gaps": []}
    for k in contract_keys(case):
        early[k] = None
    write_json(os.path.join(o, "result.json"), early)
    if cmd in ("init", "build"):
        try:
            work, _ = build_work(case, task, materials, i)
            work["errors"] = []
            work["change_records"].append({"step": "init", "status": "ok", "detail": "work draft built"})
            write_json(os.path.join(w, "work.json"), work)
            text_empty = not any(m["text_len"] for m in work["input_materials"])
            write_artifacts(dirs, work, build_result(work, case, None, materials, text_empty))
            if cmd == "init":
                return 0
        except Exception as e:
            write_json(os.path.join(o, "result.json"), _err(case, "input_error", str(e), True))
            return 0
    wp = os.path.join(w, "work.json")
    if not os.path.isfile(wp):
        return 0
    work = read_json(wp)
    for k in ("errors", "gaps", "degradations"):
        work.setdefault(k, [])
    ho.sync_term_tsv(work, os.path.join(w, "terminology.tsv"))
    merged = merge_translations(work, w)
    for p in work["document"]["paragraphs"]:
        if p.get("translation") and not ho.is_substantive_translation(p["source"], p["translation"]):
            p["translation"] = None
            work["gaps"].append({"item": "invalid_translation", "pid": p["pid"],
                                 "reason": "work.json field is placeholder or original-source copy"})
    work["change_records"].append({"step": "merge_translations", "status": "ok",
                                   "detail": "merged %d paragraphs" % merged})
    work = verify(work)
    work["change_records"].append({"step": "verify", "status": "ok",
                                   "detail": "flags=%d quote_hit_rate=%s" %
                                            (work["verification"]["n_flags"], work["verification"]["quote_hit_rate"])})
    text_empty = not any(m["text_len"] for m in work["input_materials"])
    result = build_result(work, case, None, materials, text_empty)
    result["change_records"].append({"step": "finalize", "status": "ok", "detail": result["status"]})
    write_artifacts(dirs, work, result)
    return 0


def main(argv):
    dirs, cmd = resolve_dirs(argv)
    if cmd == "help":
        print(USAGE)
        return 0
    try:
        return run(cmd, dirs)
    except Exception as e:
        try:
            os.makedirs(dirs["output"], exist_ok=True)
            write_json(os.path.join(dirs["output"], "result.json"), _err(None, "input_error", str(e), True))
        except Exception:
            pass
        return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

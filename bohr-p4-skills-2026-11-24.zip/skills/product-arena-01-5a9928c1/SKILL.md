---
name: literature-translation
description: 面向真实科研论文的术语锁定双语对照翻译与可核验工作流。抽取真实 PDF/DOCX 原文文本，按段落切分并定位页码/段号，抽取并锁定术语表，输出段落级双语对照，自动核验数字、单位、公式、文献编号与否定/限定关系，每段译文指回原文引用。适用于 Agent 阅读/翻译科学文献并需回证到原文的场景。
version: 1.1.0
---

# 文献翻译（术语锁定双语对照 + 译文核验）

## 用途

把一篇真实科研论文（或其指定段落区间）翻译成**可核验的双语对照结果**：原文与译文逐段对齐，保留段号/页码定位，术语全篇锁定同一译名，并给出数字、单位、公式、图表编号、文献引用、否定与限定关系的自动核验清单。重点解决四个问题：术语稳、段落全、关系准、可核验。

本 Skill 提供**离线术语表、按源哈希绑定的翻译队列、逐段回填和自动核验**。Python 标准库无法自行完成任意论文的高质量中英翻译；**加载此 Skill 的语言模型 Agent 就是翻译引擎，必须亲自翻译每一个可读原文段落并写入工作稿**。仅执行 Python `build` 会得到 `partial`，不得将抽取骨架冒充译文。所有译文必须指回 `source + locator + quote`。

## 触发条件

- 输入目录存在 `/input/case.json` 与 `/input/task.md`，且任务为文献翻译/阅读类。
- case.json 中存在 `output_contract`（其字段名与本题评分要素相关，如翻译、术语表、段落、核验等）。
- 材料为科研论文类文件：PDF（可能无文本层）、DOCX、TXT/Markdown、图片/表格、SQLite 等。

## 强制执行：Agent 逐段翻译闭环（不可停在骨架阶段）

**这是任务完成的必经流程。每次真实案例都要执行 Step 1—5，不能只运行 `build` 然后提交 `partial`。** 不需要网络翻译 API 或额外 Python 包；语言模型 Agent 对实际输入材料逐段翻译。

1. **读取真实输入**：读取 `/input/case.json`、`/input/task.md`，不得假设论文领域、标题、段数、原文内容或测试答案。发现目标语言不是中文时，先确认目标语言并调整批次任务；默认英文译中文。
2. **抽取、生成队列**：`python3 scripts/main.py init`。检查 `/app/work/work.json`、`/app/work/terminology.tsv`、`/app/work/translation_queue.json`。队列中每条含 `pid`、`source_sha256`、`file`、`page`、`section`、逐字原文、相邻上下文、术语、数字公式和引文。优先补全术语表的 `zh`，写回 `/app/work/terminology.tsv`，术语一旦锁定须保持一致；工作稿的自带词库仅是通用候选，可依据原文调整。
3. **模型实际翻译**：运行 `python3 scripts/main.py batch` 读取下一批至多 8 段。**模型必须真正翻译**该批每条 `source`，保留全部数字/单位/图号/公式/引用/否定与限定关系，不得省略标题、图注、表头；保留全部 `pid` 与 `source_sha256`。将译文写入 `/app/work/translations.json`（格式见下）。也可以**直接写入** `/app/work/work.json` 相应 `document.paragraphs[].translation` 和 `translation_notes`，但禁止改 `source`、`quote`、`pid` 或 `file`。工具不可写时不应宣称完成。
4. **导入、核验、续译**：运行 `python3 scripts/main.py check`，读取 `/app/output/result.json`、`/app/output/translation_queue.json`。必须循环 **batch → 逐段翻译写入 → check**，直到 `translation_coverage.untranslated_pids` 为空。`translations.json` 可逐批追加；`check` 将已译内容保存在 `work.json`，因此下一批可仅写新段。**不要在中途重复执行 `build`，它会重建工作稿。** 发现 `needs_human_review`、`terminology_inconsistency`，逐项修订并重验。
5. **交付前核对**：确认 `result.json.status`、`verification.n_translated`、`translation_coverage`、`translation.md`。只有全部可读段落有真实译文、结构化契约无缺值且核验无未处理警告，方可报告 `complete`。输入无文本/页缺失等如实保留 `partial`/`insufficient_evidence`，说明人工补充位置。

运行示例（默认 `/input`、`/app/work`、`/app/output`；也支持 `--input/--work/--output`）：

```bash
python3 scripts/main.py init                       # 抽取真实原文、离线术语表、Agent 翻译队列
python3 scripts/main.py batch                      # 显示下一批原文供模型翻译（≤8 段）
# Agent 根据模型翻译，把当前批次真实中文译文写入 /app/work/translations.json
python3 scripts/main.py check                      # 合并到 work.json，核验，刷新下一批队列
# 重复 batch + check 直到无未译段，再检查 output/result.json
python3 scripts/main.py show                       # 需要时查看完整 work.json
```

`translations.json` 可为对象（推荐）或旧版数组。**推荐形式：**

```json
{
  "terminology": [{"term": "hazard ratio", "zh": "风险比"}],
  "translations": [
    {
      "pid": "p1",
      "source_sha256": "从 translation_queue.json 原样复制的 64 位哈希",
      "translation": "必须是由 Agent 根据对应原文实际翻译的完整中文段落，非该句示意文本",
      "notes": ["记录术语选型和不确定项"]
    }
  ]
}
```

以上 JSON **仅是字段示例，不是可直接提交的译文**。如果发现 `source_sha256` 不匹配、原文照抄、`array/string/译文/[未译]` 等占位值，导入会拒绝并保留 `gaps`。对于无文本层 PDF，先使用可用 PDF/OCR 工具提取并提供真实文本；不可获得时标记缺失，严禁凭空翻译。

脚本 `build` 保留为“抽取→合并现存译文→核验”快捷入口：**它不会自主调用语言模型**，因此没有现成译稿的单独 CLI 执行仍是 `partial`。模型加载 Skill 后必须完成上面的实际翻译动作。

## 输入输出

输入（`/input`）：
- `case.json`：`case_id`、`task_instruction`、`output_contract`（结果契约，字段逐项回填）、材料引用。
- `task.md`：题目说明。
- 材料文件：PDF/DOCX/TXT/图片/SQLite，实际路径以 case.json 或目录为准。

输出（`/app/output`，均为可编辑源，非截图）：
- `result.json`：结构化最终结果，含 output_contract 每个字段（缺值 `null`/`[]`）+ `case_id` + `status` + `sources` + `uncertainty` + `change_records` + `errors` + `degradations` + `gaps`。
- `translation.md`：段落级双语对照（段号、页码、原文、译文、术语依据、核验标记）。
- `work.json`：完整工作稿（下节 schema）。
- `terminology.tsv`：术语表（term \t zh \t status \t occurrences）。
- `/app/work/`：中间产物（`work.json`、`translation_queue.json`、`terminology.tsv`、`translations.json` 等）。
- `translation_queue.json`：真实原文哈希绑定的可执行 Agent 逐段翻译任务队列（双份写入 work/output）。

## 工作稿 schema（work.json）

```json
{
  "schema": "lit-translate/work-v1",
  "case_id": "...",
  "task_instruction": "...",
  "input_materials": [{"path": "...", "type": "pdf|docx|txt|image|sqlite", "pages": 0, "text_len": 0}],
  "document": {
    "title": "...",
    "paragraphs": [
      {
        "pid": "p1",
        "page": 1,
        "section": "Abstract",
        "order": 0,
        "kind": "body",
        "source": "full paragraph text",
        "quote": "verbatim substring",
        "sentences": [{"sid": "p1.s1", "source": "...", "quote": "..."}],
        "terms": [{"term": "...", "norm": "..."}],
        "facts": {"numbers": [{"value": "1,024", "unit": "patients", "raw": "1,024 patients"}],
                   "formulas": [], "citations": [], "negations": []},
        "translation": null,
        "translation_notes": [],
        "verify": null
      }
    ],
    "captions": [],
    "references": [],
    "terminology": [{"term": "...", "norm": "...", "zh": null, "status": "proposed|locked", "occurrences": ["p1"]}]
  },
  "verification": {},
  "gaps": [],
  "degradations": [],
  "change_records": []
}
```

`translations.json`（Agent 逐段写入的译文，`build`/`check` 时合并回 work.json；旧格式仍可接受，推荐加 `source_sha256`）：

```json
[{"pid": "p1", "translation": "译文", "notes": ["术语依据或不确定说明"]}]
```

## 证据规范

- 每条结论/字段/译文必须带 `locator`（page/paragraph/section/table/figure）+ 逐字 `quote`；`quote` 必须在材料原文中命中（脚本核验命中率，阈值 0.95）。
- 未报告、无法判断、材料冲突分别写入 `gaps`/`uncertainty`，不得写成事实。
- 禁止 placeholder / scaffold / "array" / "object" / 空契约键：output_contract 无法映射的字段显式填 `null` 并在 `gaps` 说明原因。

## 降级表

| 情形 | 处置 | 状态 |
|-|-|-|
| PDF 无文本层（扫描件） | 内置抽取仅得 0 文本 → 记 degradation，提示用 OCR（平台 ocr-tool），缺口记 gaps | insufficient_evidence |
| PDF 有文本层但部分 CID 字缺失 ToUnicode | 抽取可用子集，记录缺失码位 | partial |
| 图片/表格为图片 | 不猜内容，记 gap 与图片定位 | partial |
| DOCX/TXT/SQLite | 标准库直接解析 | complete（材料层面） |
| 参考文献无法解析 | 原文片段原样保留，标注未解析 | partial |
| 原文残缺/语言混杂 | 逐段标注未译/不确定，不清洗改写 | partial |
| case.json 缺失/坏 JSON | 产出 input_error，gaps 说明 | input_error |
| 缺材料/权限不足 | 产出 insufficient_evidence，gaps 说明 | insufficient_evidence |
| 未触发 Agent 逐段翻译 | 生成真实原文、术语表、逐段队列，不生成假译文；Agent 必须接管回填 | partial |

## 自检

- `python scripts/main.py` 对任意 case 默认跑通且 exit 0；`--help`、空输入、坏 JSON、缺材料均 exit 0 且 result.json 合法。
- 两次全新输出目录结果一致（无时间戳/随机）。quote 命中率 ≥0.95。
- result.json 含全部 output_contract 键 + case_id + status/sources/uncertainty/change_records。

## 限制

- 不联网、无外部翻译引擎；**翻译动作由执行 Agent（模型）承担，单独运行 Python 并不会自动产生译文**。脚本负责队列生成/术语锁定/真实译文导入/核验。
- 内置 PDF 抽取是最小可用实现（zlib 流 + 文本显示算子 + ToUnicode），复杂排版/加密 PDF/图形公式可能仅得部分文本，需平台 pdf-text-tool/ocr-tool 兜底。
- 术语译名与译文的最终取舍需人工复核；`needs_human_review` 清单是必须人工确认的边界，不是完成态答案。

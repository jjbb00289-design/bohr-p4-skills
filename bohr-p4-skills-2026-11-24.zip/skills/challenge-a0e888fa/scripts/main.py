#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic scientific data-cleaning pipeline (Python stdlib only).

Reads /input/{case.json, task.md, materials...}; parses the data dictionary,
per-metric unit/QC rules and cleaning workorder; runs a five-stage flow
(missing values, outliers, duplicates, format/unit conversion, quality report);
writes /app/output artifacts and a contract-complete result.json.

Always exits 0. Failures are reported in result.status/errors/gaps, never by a
crash or a zero-byte output.
"""
import argparse
import csv
import hashlib
import io
import json
import os
import re
import sqlite3
import sys
import zipfile
from decimal import Decimal, InvalidOperation
from pathlib import Path
from xml.etree import ElementTree as ET

try:  # optional stdlib PDF text-stream extractor shipped alongside
    import pdf_text  # noqa: F401
except ImportError:
    pdf_text = None

HERE = Path(__file__).resolve().parent

MISSING_TOKENS = {  # -> subtype
    "empty": {"", " ", "na", "n/a", "nan", "null", "none", "nil", "missing",
              ".", "-", "--", "-999", "-9999", "-99", "-999.0", "999", "9999",
              "-1e9", "n.d.", "n/a.", "—", "–"},
    "below_detection": {"未检测", "未检出", "低于检出限", "低于检测限", "检测限以下",
                        "nd", "lod", "loq", "<lod", "<loq", "<l.o.d",
                        "not detected", "below lod", "below loq",
                        "未测出", "痕量", "trace"},
}
_FULLWIDTH = str.maketrans("０１２３４５６７８９．，－", "0123456789.,-")
_SCIENTIFIC = re.compile(
    r"^\s*([+-]?\d+(?:\.\d+)?)\s*[×xX*]\s*10\s*[^^]*?([+-]?\d+)\s*$")
_DATELIKE = re.compile(r"^\d{4}[-/]\d{1,2}[-/]\d{1,2}(?:[ T]\d{1,2}:\d{2})?$")
_IDLIKE = re.compile(
    r"(?i)(^|_)(id|no|num|编号|序号|样品|样本|受试|subject|sample|patient|"
    r"record|code)$|(?:^|_)(id|编号)(_|$)")
_DATELIKE_COL = re.compile(r"(?i)date|time|时间|日期|year|年")
_METRICLIKE = re.compile(r"(?i)(mg/l|ug/ml|μg/ml|ng/ml|g/l|mol/l|mm|cm|kg|g|%|"
                         r"浓度|值|含量|level|value|conc)")

EVIDENCE = []


def add_evidence(source, locator, quote, note=""):
    EVIDENCE.append({"source": source, "locator": locator, "quote": quote,
                     "note": note})
    return len(EVIDENCE) - 1


def b2s(b):
    if b.startswith(b"\xef\xbb\xbf"):
        return b.decode("utf-8-sig"), "utf-8-sig"
    for enc in ("utf-8", "gb18030", "latin-1"):
        try:
            return b.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return b.decode("utf-8", "replace"), "utf-8-replace"


def guess_delim(line):
    counts = {d: line.count(d) for d in (",", "\t", ";", "|")}
    best = max(counts, key=counts.get)
    return best if counts[best] > 0 else ","


def parse_delimited(text):
    sample = text[:8192]
    delim = None
    try:
        delim = csv.Sniffer().sniff(sample, delimiters=",\t;|").delimiter
    except Exception:
        first = next((ln for ln in sample.splitlines() if ln.strip()), "")
        delim = guess_delim(first)
    rows = []
    for r in csv.reader(io.StringIO(text), delimiter=delim):
        if any(str(c).strip() for c in r):
            rows.append([c.strip() for c in r])
    return rows


def parse_markdown_table(text):
    lines = [ln for ln in text.splitlines() if ln.strip().startswith("|")]
    if len(lines) < 2:
        return None
    def cells(ln):
        ln = ln.strip()
        if ln.startswith("|"):
            ln = ln[1:]
        if ln.endswith("|"):
            ln = ln[:-1]
        return [c.strip() for c in ln.split("|")]
    header = cells(lines[0])
    if not header or all(re.fullmatch(r":?-{3,}:?", c or "-") for c in header):
        return None
    rows = []
    for ln in lines[1:]:
        c = cells(ln)
        if c and all(re.fullmatch(r":?-{3,}:?", x or "-") for x in c):
            continue
        rows.append(c)
    return [header] + rows


def parse_json_table(text):
    try:
        obj = json.loads(text)
    except Exception:
        return None
    if isinstance(obj, list) and obj and isinstance(obj[0], dict):
        return obj
    if isinstance(obj, dict):
        if isinstance(obj.get("data"), list):
            return obj["data"]
        if isinstance(obj.get("rows"), list) and isinstance(
                obj.get("columns"), list):
            cols = obj["columns"]
            out = []
            for r in obj["rows"]:
                out.append(dict(zip(cols, r)) if isinstance(r, list) else r)
            return out
    return None


def parse_xlsx(path):
    try:
        z = zipfile.ZipFile(path)
    except Exception:
        return None
    shared = []
    if "xl/sharedStrings.xml" in z.namelist():
        root = ET.fromstring(z.read("xl/sharedStrings.xml"))
        ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
        for si in root.findall("m:si", ns):
            shared.append("".join(t.text or "" for t in si.iter(
                "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t")))
    sheets = [n for n in z.namelist()
              if re.match(r"xl/worksheets/sheet\d+\.xml$", n)]
    sheets.sort()
    rows = []
    for sname in sheets[:3]:
        root = ET.fromstring(z.read(sname))
        ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
        for row in root.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row"):
            cells = []
            for c in row.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c"):
                t = c.get("t")
                v = c.find("m:v", ns)
                v = v.text if v is not None else ""
                if t == "s" and v:
                    v = shared[int(v)]
                cells.append(v)
            if any(str(x).strip() for x in cells):
                rows.append(cells)
    return rows


def parse_sqlite(path):
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    except Exception:
        return None
    try:
        cur = con.cursor()
        tables = [r[0] for r in cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%'").fetchall()]
        out = []
        for t in tables[:3]:
            cols = [d[1] for d in cur.execute(f'PRAGMA table_info("{t}")')]
            for row in cur.execute(f'SELECT * FROM "{t}"'):
                out.append([str(x) if x is not None else "" for x in row])
            if out:
                out = [cols] + out
                break
        return out
    except Exception:
        return None
    finally:
        con.close()


def normalize_key(s):
    s = s.strip().lower()
    s = s.translate(_FULLWIDTH)
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"^(mg/l|ug/ml|μg/ml|ng/ml|g/l|mol/l|kg|g|mm|cm|%)$", "", s)
    return s.strip()


def parse_numeric(s):
    """Return Decimal or None for a raw cell string."""
    t = s.strip()
    if not t:
        return None
    t = t.translate(_FULLWIDTH)
    t = t.replace("\u00a0", " ").replace("%", "").replace(",", "")
    t = t.strip()
    if not t:
        return None
    try:
        return Decimal(t)
    except InvalidOperation:
        pass
    m = _SCIENTIFIC.match(s)
    if m:
        try:
            return Decimal(m.group(1)) * (Decimal(10) ** int(m.group(2)))
        except InvalidOperation:
            pass
    # comma as decimal separator (e.g. 12,5)
    t2 = s.strip().translate(_FULLWIDTH).replace(" ", "")
    if re.fullmatch(r"[+-]?\d{1,3}(,\d{3})*,\d{1,2}", t2):
        t2 = t2.replace(".", "").replace(",", ".")
        try:
            return Decimal(t2)
        except InvalidOperation:
            pass
    elif "," in t2 and re.fullmatch(r"[+-]?\d+,\d{1,2}", t2):
        try:
            return Decimal(t2.replace(",", "."))
        except InvalidOperation:
            pass
    return None


def classify_missing(raw):
    t = raw.strip()
    low = t.lower()
    if t in MISSING_TOKENS["below_detection"] or low in {
            "nd", "lod", "loq", "<lod", "<loq", "not detected",
            "below lod", "below loq"}:
        return True, "below_detection"
    if low.startswith("<") and parse_numeric(t[1:]) is not None:
        return True, "below_detection"
    if t in MISSING_TOKENS["empty"] or low in {
            "na", "n/a", "nan", "null", "none", "nil", "missing", "n.d."}:
        return True, "empty"
    return False, None


def table_from_rows(rows, source, relpath):
    if not rows:
        return None
    header = [str(c).strip() for c in rows[0]]
    if not header or not any(header):
        return None
    body = rows[1:]
    recs = []
    raw_lines = []
    for i, r in enumerate(body):
        d = {}
        for j, h in enumerate(header):
            d[h] = str(r[j]) if j < len(r) else ""
        recs.append(d)
        raw_lines.append("|".join(str(x) for x in r))
    return {"name": relpath, "source": source, "relpath": relpath,
            "header": header, "records": recs, "raw_lines": raw_lines,
            "kind": "tabular"}


def load_table(path, relpath, text):
    rows = None
    fmt = None
    if re.search(r"\.[jt]sv$|\.csv$|\.txt$|\.dat$", path.suffix.lower()) or \
       (text and ("\t" in text.splitlines()[0] if text.splitlines() else False)):
        rows = parse_delimited(text)
        fmt = "delimited"
    if rows is None:
        rows = parse_markdown_table(text)
        fmt = "markdown"
    if rows is None:
        j = parse_json_table(text)
        if j:
            cols = sorted({k for d in j for k in d.keys()})
            header = cols
            body = [[str(d.get(c, "")) for c in cols] for d in j]
            rows = [header] + body
            fmt = "json"
    if rows is None and path.suffix.lower() in (".xlsx", ".xlsm"):
        rows = parse_xlsx(path)
        fmt = "xlsx"
    if rows is None and path.suffix.lower() in (".db", ".sqlite", ".sqlite3"):
        rows = parse_sqlite(path)
        fmt = "sqlite"
    return table_from_rows(rows, relpath, relpath), fmt


def extract_dict_meta(dict_text):
    """Best-effort column metadata from a data dictionary. Returns dict
    name -> {role, dtype, unit, min, max, meaning}."""
    meta = {}
    j = None
    try:
        j = json.loads(dict_text)
    except Exception:
        pass
    entries = []
    if isinstance(j, list):
        entries = [d for d in j if isinstance(d, dict)]
    elif isinstance(j, dict):
        for v in j.values():
            if isinstance(v, dict):
                entries.append(v)
        for k, v in j.items():
            if isinstance(v, str) and not isinstance(k, (int, float)):
                entries.append({"name": k, "meaning": v})
    md = parse_markdown_table(dict_text)
    if entries:
        for d in entries:
            name = next((d.get(k) for k in ("name", "field", "column", "col",
                                            "variable", "指标", "字段", "列")
                         if d.get(k) is not None), None)
            if name is None:
                continue
            name = str(name).strip()
            unit = d.get("unit") or d.get("units") or d.get("单位")
            role = d.get("role") or d.get("type") or d.get("类型")
            meta[name] = {
                "role": str(role).lower() if role else None,
                "unit": str(unit) if unit else None,
                "min": d.get("min") or d.get("lower") or d.get("下限"),
                "max": d.get("max") or d.get("upper") or d.get("上限"),
                "meaning": d.get("meaning") or d.get("description") or
                           d.get("含义") or d.get("说明") or ""}
    elif md:
        header = md[0]
        name_i = next((i for i, h in enumerate(header)
                       if h.lower() in ("name", "field", "column", "col",
                                        "字段", "列", "变量")), 0)
        for r in md[1:]:
            if name_i >= len(r):
                continue
            meta[r[name_i]] = {"role": None, "unit": None, "min": None,
                               "max": None, "meaning": ""}
    return meta


def extract_conversions(text):
    """Return list of {from_unit, to_unit, factor} from unit/QC rules."""
    convs = []
    j = None
    try:
        j = json.loads(text)
    except Exception:
        pass
    if isinstance(j, dict):
        j = [j]
    if isinstance(j, list):
        for d in j:
            if not isinstance(d, dict):
                continue
            f = d.get("factor") or d.get("multiplier") or d.get("ratio") or \
                d.get("系数")
            fr = d.get("from") or d.get("from_unit") or d.get("source_unit") \
                or d.get("原单位")
            to = d.get("to") or d.get("to_unit") or d.get("target_unit") \
                or d.get("目标单位")
            if f is not None and (fr or to):
                convs.append({"from_unit": str(fr), "to_unit": str(to),
                              "factor": str(f)})
    # textual patterns: "1 mg/L = 1000 μg/mL" style
    for m in re.finditer(
            r"1\s*(mg/l|μg/ml|ug/ml|ng/ml|g/l|mol/l|kg|g|mm|cm|%)\s*=\s*"
            r"([0-9.eE+\-]+)\s*(mg/l|μg/ml|ug/ml|ng/ml|g/l|mol/l|kg|g|mm|cm|%)",
            text, re.I):
        convs.append({"from_unit": m.group(1).lower(),
                      "to_unit": m.group(3).lower(), "factor": m.group(2)})
    # dedupe
    seen, out = set(), []
    for c in convs:
        k = (c["from_unit"], c["to_unit"], c["factor"])
        if k not in seen:
            seen.add(k)
            out.append(c)
    return out


def infer_meta(header, records, dict_meta):
    meta = {}
    for h in header:
        m = dict_meta.get(h, {})
        role = m.get("role")
        unit = m.get("unit")
        if not role:
            if _IDLIKE.search(h):
                role = "id"
            elif _DATELIKE_COL.search(h):
                role = "datetime"
        numeric = True
        nonmissing = 0
        for r in records:
            raw = r.get(h, "")
            miss, _ = classify_missing(raw)
            if miss:
                continue
            nonmissing += 1
            if parse_numeric(raw) is None:
                numeric = False
        dtype = "numeric" if numeric and nonmissing > 0 else "text"
        if _DATELIKE.match(str(records[0].get(h, ""))) if records else False:
            dtype = "datetime"
        meta[h] = {"role": role, "dtype": dtype, "unit": unit,
                   "min": m.get("min"), "max": m.get("max"),
                   "meaning": m.get("meaning", "")}
    return meta


def fmt_num(d):
    if d is None:
        return ""
    s = format(d, "f")
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    if s in ("-0", ""):
        s = "0"
    return s


def qstats(values):
    n = len(values)
    if n == 0:
        return None
    vf = sorted(float(v) for v in values)
    def q(p):
        k = (n - 1) * p
        f = int(k)
        c = min(f + 1, n - 1)
        return vf[f] + (vf[c] - vf[f]) * (k - f)
    d = lambda x: Decimal(str(x))
    return {"n": n, "min": d(vf[0]), "max": d(vf[-1]),
            "q1": d(q(0.25)), "q3": d(q(0.75)), "median": d(q(0.5))}


def clean_table(table, meta, convs, relroot):
    """Run the five stages; mutate global ISSUES/CHANGES/STATS."""
    issues, changes = [], []
    header = table["header"]
    records = table["records"]
    rel = table["relpath"]
    # 1+4: missing classification & numeric normalization/unit conversion
    clean_records = []
    for idx, r in enumerate(records):
        loc = f"{rel}#row={idx + 2}"  # +2: header row = 1
        out = {}
        for h in header:
            raw = r.get(h, "")
            m = meta.get(h, {})
            miss, subtype = classify_missing(raw)
            if miss:
                out[h] = ""
                out[h + "__missing_type"] = subtype
                issues.append({
                    "source": rel, "locator": f"{loc},col={h}",
                    "quote": raw, "issue": "missing", "subtype": subtype,
                    "field": h, "action": "kept-empty (no imputation)",
                    "rule": "missing-sentinel-classification"})
                continue
            num = parse_numeric(raw)
            if m.get("dtype") == "numeric" and num is None:
                issues.append({
                    "source": rel, "locator": f"{loc},col={h}",
                    "quote": raw, "issue": "non-numeric-in-numeric-field",
                    "field": h, "action": "kept-as-text",
                    "rule": "numeric-normalization"})
                out[h] = raw
                continue
            if num is not None:
                out[h] = fmt_num(num)
                if m.get("unit"):
                    for c in convs:
                        if c.get("from_unit", "").lower() == \
                                str(m["unit"]).lower():
                            try:
                                conv = num * Decimal(c["factor"])
                            except InvalidOperation:
                                conv = None
                            if conv is not None:
                                out[h + "__converted"] = fmt_num(conv)
                                out[h + "__unit"] = c.get("to_unit")
                                changes.append({
                                    "source": rel, "locator":
                                        f"{loc},col={h}", "quote": raw,
                                    "field": h, "from_value": fmt_num(num),
                                    "to_value": fmt_num(conv),
                                    "from_unit": m["unit"],
                                    "to_unit": c.get("to_unit"),
                                    "factor": c["factor"],
                                    "rule": "unit-conversion"})
            else:
                out[h] = raw
        clean_records.append(out)
    table["clean_records"] = clean_records

    # 2: outliers on numeric columns
    outlier_flags = []
    for h in header:
        vals = []
        for r in clean_records:
            v = r.get(h, "")
            if v == "" or r.get(h + "__missing_type"):
                continue
            try:
                vals.append(Decimal(v))
            except InvalidOperation:
                pass
        if len(vals) < 4:
            if m := meta.get(h):
                m["outlier_skipped"] = "n<4"
            continue
        s = qstats(vals)
        iqr = s["q3"] - s["q1"]
        lo, hi = s["q1"] - Decimal("1.5") * iqr, s["q3"] + Decimal("1.5") * iqr
        if m := meta.get(h):
            if m.get("min") is not None:
                try:
                    lo = max(lo, Decimal(str(m["min"])))
                except InvalidOperation:
                    pass
            if m.get("max") is not None:
                try:
                    hi = min(hi, Decimal(str(m["max"])))
                except InvalidOperation:
                    pass
        for idx, r in enumerate(clean_records):
            v = r.get(h, "")
            if v == "":
                continue
            try:
                d = Decimal(v)
            except InvalidOperation:
                continue
            if d < lo or d > hi:
                reason = "IQR(1.5) outlier"
                outlier_flags.append({
                    "source": rel, "locator": f"{rel}#row={idx + 2},col={h}",
                    "quote": table["records"][idx].get(h, ""), "field": h,
                    "value": fmt_num(d), "bounds": [fmt_num(lo), fmt_num(hi)],
                    "issue": "outlier", "action": "flagged-kept",
                    "reason": reason})
    return issues, changes, outlier_flags


def detect_duplicates(table, meta, workorder_text):
    header = table["header"]
    records = table["records"]
    rel = table["relpath"]
    id_cols = [h for h in header if meta.get(h, {}).get("role") == "id"]
    if not id_cols:
        id_cols = [h for h in header if _IDLIKE.search(h)]
    if not id_cols:
        id_cols = [header[0]]
    keep_mode = "fewest-missing"
    if re.search(r"keep\s+(first|latest|complete)", workorder_text or "", re.I):
        m = re.search(r"keep\s+(first|latest|complete)", workorder_text or "",
                      re.I)
        keep_mode = m.group(1).lower()
    groups = {}
    for idx, r in enumerate(records):
        key = "||".join(normalize_key(r.get(h, "")) for h in id_cols)
        groups.setdefault(key, []).append(idx)
    dup_out, removed = [], []
    for key, idxs in groups.items():
        if len(idxs) < 2:
            continue
        if keep_mode == "latest":
            idxs = idxs[::-1]
        def score(i):
            return sum(1 for h in header
                       if classify_missing(records[i].get(h, ""))[0])
        if keep_mode == "complete":
            idxs = sorted(idxs, key=score)
        keep = idxs[0]
        for i in idxs[1:]:
            removed.append({
                "source": rel, "locator": f"{rel}#row={i + 2}",
                "quote": table["raw_lines"][i], "duplicate_of_row": keep + 2,
                "key": key, "action": "removed", "keep_reason": keep_mode,
                "issue": "duplicate"})
            dup_out.append(records[i])
    return dup_out, removed


def resolve_contract(key, artifacts, summary):
    k = re.sub(r"[^a-z0-9]", "", key.lower())
    if k in ("cleaneddata", "cleanedtable", "cleanedcsv", "cleaned",
             "data", "table", "cleaneddatafile", "cleanedtablefile"):
        return artifacts.get("cleaned_data.csv")
    if k in ("issue", "issues", "issuelist", "problems", "issuelistfile"):
        return artifacts.get("issues.csv")
    if k in ("qualityreport", "report", "qualityreportfile"):
        return artifacts.get("quality_report.md")
    if k in ("rules", "ruleslog", "log", "cleaninglog", "ruleslogfile"):
        return artifacts.get("rules_log.json")
    if k in ("change", "changes", "changelog", "changerecords"):
        return artifacts.get("change_records.json")
    if k in ("summary", "statistics", "stats", "summarystatistics"):
        return summary
    if k in ("duplicates", "duplicaterecords", "duplicatesfile"):
        return artifacts.get("duplicates.csv")
    if k in ("original", "snapshot", "raw", "originalsnapshot"):
        return artifacts.get("original_snapshot.csv")
    if k in ("deduplicated", "deduplicateddata", "dedup"):
        return artifacts.get("deduplicated_data.csv")
    return None


def build_result(case, artifacts, summary, sources, uncertainty, changes,
                 errors, degradations, gaps, status):
    result = {}
    contract = case.get("output_contract", {})
    if isinstance(contract, dict):
        keys = list(contract.keys())
    elif isinstance(contract, list):
        keys = [x if isinstance(x, str) else str(x) for x in contract]
    else:
        keys = []
    for k in keys:
        result[k] = resolve_contract(k, artifacts, summary)
    result["case_id"] = case.get("case_id")
    result["status"] = status
    result["errors"] = errors
    result["degradations"] = degradations
    result["gaps"] = gaps
    result["sources"] = sources
    result["uncertainty"] = uncertainty
    result["change_records"] = changes
    result["artifacts"] = artifacts
    result["summary"] = summary
    return result


def verify_quotes(sources, issues, changes, texts):
    """texts: {relpath: decoded_text}. Return (hits, total)."""
    pairs = []
    for s in sources:
        if isinstance(s, dict) and s.get("quote"):
            pairs.append((s.get("source"), s.get("quote")))
    for it in issues + changes:
        if isinstance(it, dict) and it.get("quote"):
            pairs.append((it.get("source"), it.get("quote")))
    hits = total = 0
    for src, q in pairs:
        if not q:
            continue
        total += 1
        txt = texts.get(src)
        if txt is not None and q in txt:
            hits += 1
    return hits, total


def run(cfg):
    global EVIDENCE
    EVIDENCE = []
    in_dir = Path(cfg.input)
    work_dir = Path(cfg.work)
    out_dir = Path(cfg.output)
    os.makedirs(work_dir, exist_ok=True)
    os.makedirs(out_dir, exist_ok=True)

    errors, degradations, gaps = [], [], []
    sources, uncertainty, changes = [], [], []
    case = {}
    case_path = in_dir / "case.json"

    # ---- early partial result.json ----
    artifacts = {}
    summary = {"inputs": [], "tables": 0, "rows": 0, "columns": 0,
               "missing_total": 0, "outlier_total": 0, "duplicate_groups": 0,
               "conversion_total": 0}
    early = {"case_id": None, "status": "partial", "errors": errors,
             "degradations": degradations, "gaps": gaps, "sources": sources,
             "uncertainty": uncertainty, "change_records": changes,
             "artifacts": artifacts, "summary": summary}
    (out_dir / "result.json").write_text(
        json.dumps(early, ensure_ascii=False, indent=2), encoding="utf-8")

    if not in_dir.exists() or not case_path.exists():
        gaps.append({"type": "missing_case_file",
                     "detail": f"case.json not found at {case_path}"})
        status = "input_error"
        result = build_result(case, artifacts, summary, sources, uncertainty,
                              changes, errors, degradations, gaps, status)
        result["case_id"] = None
        (out_dir / "result.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        return result

    try:
        raw = case_path.read_text(encoding="utf-8")
    except Exception as e:
        gaps.append({"type": "case_read_error", "detail": str(e)})
        result = build_result(case, artifacts, summary, sources, uncertainty,
                              changes, errors, degradations, gaps,
                              "input_error")
        (out_dir / "result.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        return result
    try:
        case = json.loads(raw)
    except Exception as e:
        errors.append({"type": "bad_json", "detail": str(e)})
        result = build_result(case, artifacts, summary, sources, uncertainty,
                              changes, errors, degradations, gaps,
                              "input_error")
        (out_dir / "result.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        return result
    if not isinstance(case, dict):
        case = {}

    summary["case_id"] = case.get("case_id")
    summary["task_instruction"] = case.get("task_instruction")

    # ---- discover & read materials ----
    files = [p for p in sorted(in_dir.rglob("*"))
             if p.is_file() and p.name not in ("case.json", "task.md")
             and ".git" not in p.parts]
    texts = {}
    loaded = []
    for p in files:
        rel = str(p.relative_to(in_dir)).replace("\\", "/")
        try:
            data = p.read_bytes()
        except Exception as e:
            errors.append({"type": "read_error", "source": rel,
                           "detail": str(e)})
            continue
        if p.suffix.lower() == ".pdf":
            txt, ok = "", False
            if pdf_text is not None:
                try:
                    txt, ok = pdf_text.extract_pdf_text(str(p))
                except Exception as e:
                    degradations.append({"type": "pdf_extract_error",
                                         "source": rel, "detail": str(e)})
            if not ok or not txt.strip():
                gaps.append({"type": "pdf_no_text_layer", "source": rel,
                             "detail": "no extractable text; OCR required"})
                continue
            text, enc = txt, "pdf-extracted"
        else:
            try:
                text, enc = b2s(data)
            except Exception as e:
                errors.append({"type": "decode_error", "source": rel,
                               "detail": str(e)})
                continue
        texts[rel] = text
        summary["inputs"].append({"source": rel, "encoding": enc,
                                  "bytes": len(data)})
        loaded.append((p, rel, text))

    if not any(t.strip() for _, _, t in loaded):
        gaps.append({"type": "no_material", "detail": "no readable material"})
        status = "insufficient_evidence"
        result = build_result(case, artifacts, summary, sources, uncertainty,
                              changes, errors, degradations, gaps, status)
        (out_dir / "result.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        return result

    # ---- classify materials ----
    dict_texts, rule_texts, workorder_text, table_items = [], [], "", []
    for p, rel, text in loaded:
        low = text.lower()
        if re.search(r"数据字典|dictionary|字段|field\s+name|单位|unit",
                     low) and not re.search(r"\t|,", text[:200]):
            dict_texts.append((rel, text))
        elif re.search(r"workorder|工单|工作稿|清洗步骤|cleaning\s+steps|"
                       r"步骤", low):
            workorder_text += ("\n" + text)
        elif re.search(r"unit|单位|conversion|换算|系数|factor|qc|质量",
                       low) and len(text) < 20000:
            rule_texts.append((rel, text))
        else:
            table, fmt = load_table(p, rel, text)
            if table:
                table_items.append(table)
            else:
                # fall back: treat small text as rules/dict, else note
                if len(text) < 20000:
                    rule_texts.append((rel, text))
                else:
                    gaps.append({"type": "unparsed_material", "source": rel,
                                 "detail": "not recognized as table or rules"})

    dict_meta = {}
    for rel, text in dict_texts:
        dict_meta.update(extract_dict_meta(text))
        sources.append({"source": rel, "locator": f"{rel}:whole-file",
                        "quote": text[:200] + ("…" if len(text) > 200 else ""),
                        "note": "data dictionary"})
    convs = []
    for rel, text in rule_texts:
        convs.extend(extract_conversions(text))
        sources.append({"source": rel, "locator": f"{rel}:whole-file",
                        "quote": text[:200] + ("…" if len(text) > 200 else ""),
                        "note": "unit/QC rules"})
    if workorder_text.strip():
        sources.append({"source": "task.md/workorder",
                        "locator": "workorder:whole-file",
                        "quote": workorder_text.strip()[:200],
                        "note": "cleaning workorder"})
    if not convs:
        degradations.append({"type": "no_unit_conversions",
                             "detail": "no explicit unit conversions parsed; "
                                       "values kept as-is"})
    if not dict_meta:
        degradations.append({"type": "no_dictionary",
                             "detail": "no data dictionary parsed; roles/dtype "
                                       "inferred from column names"})

    if not table_items:
        gaps.append({"type": "no_data_table", "detail": "no tabular data "
                      "recognized among materials"})
        status = "insufficient_evidence"
        result = build_result(case, artifacts, summary, sources, uncertainty,
                              changes, errors, degradations, gaps, status)
        (out_dir / "result.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        return result

    # ---- run cleaning on each table ----
    all_issues, all_changes, all_outliers, all_dups, all_removed = \
        [], [], [], [], []
    cleaned_rows, dedup_rows = [], []
    for t in table_items:
        meta = infer_meta(t["header"], t["records"], dict_meta)
        iss, chg, outl = clean_table(t, meta, convs, in_dir)
        all_issues += iss
        all_changes += chg
        all_outliers += outl
        dup_out, removed = detect_duplicates(t, meta, workorder_text)
        all_dups += dup_out
        all_removed += removed
        # rebuild kept rows (records not removed)
        removed_rows = {int(r["locator"].split("#row=")[1].split(",")[0])
                        for r in removed}
        for i, r in enumerate(t["clean_records"]):
            cleaned_rows.append({**{"__table": t["relpath"],
                                    "__row_id": i + 2}, **r})
            if i not in removed_rows:
                dedup_rows.append({**{"__table": t["relpath"],
                                      "__row_id": i + 2}, **r})
        summary["tables"] += 1
        summary["rows"] += len(t["records"])
        summary["columns"] += len(t["header"])

    summary["missing_total"] = len(all_issues)
    summary["outlier_total"] = len(all_outliers)
    summary["conversion_total"] = len(all_changes)
    summary["duplicate_groups"] = len({r["key"] for r in all_removed})
    summary["duplicates_removed"] = len(all_removed)

    # ---- write artifacts ----
    def write_csv(name, rows, fieldnames):
        p = out_dir / name
        with open(p, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames,
                               extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)
        return name

    all_keys = []
    for r in cleaned_rows:
        for k in r:
            if k not in all_keys:
                all_keys.append(k)
    dedup_keys = all_keys if dedup_rows else []
    artifacts["cleaned_data.csv"] = write_csv("cleaned_data.csv", cleaned_rows,
                                              all_keys)
    artifacts["original_snapshot.csv"] = write_csv(
        "original_snapshot.csv",
        [{"__table": t["relpath"], "__row_id": i + 2, "__raw_line": ln}
         for t in table_items for i, ln in enumerate(t["raw_lines"])],
        ["__table", "__row_id", "__raw_line"])
    if dedup_rows:
        artifacts["deduplicated_data.csv"] = write_csv(
            "deduplicated_data.csv", dedup_rows, dedup_keys)
    if all_issues:
        artifacts["issues.csv"] = write_csv(
            "issues.csv", all_issues,
            list(dict.fromkeys(k for it in all_issues for k in it)))
    if all_removed:
        artifacts["duplicates.csv"] = write_csv(
            "duplicates.csv", all_removed,
            list(dict.fromkeys(k for it in all_removed for k in it)))
    artifacts["rules_log.json"] = "rules_log.json"
    (out_dir / "rules_log.json").write_text(json.dumps({
        "run_id": hashlib.sha1(
            "".join(sorted(texts.keys()) + [texts[k] for k in sorted(texts)])
            .encode()).hexdigest(),
        "unit_conversions": convs, "dictionary_fields": sorted(dict_meta),
        "missing_sentinels": {"empty": sorted(
            {t for t in MISSING_TOKENS["empty"] if t})[:20],
            "below_detection": sorted(MISSING_TOKENS["below_detection"])},
        "degradations": degradations}, ensure_ascii=False, indent=2),
        encoding="utf-8")
    artifacts["change_records.json"] = "change_records.json"
    (out_dir / "change_records.json").write_text(json.dumps(
        all_changes, ensure_ascii=False, indent=2), encoding="utf-8")

    # cleaned_data.json (machine-readable, typed, missing=null)
    json_records = []
    for r in cleaned_rows:
        jr = {}
        for k, v in r.items():
            if k.endswith("__missing_type") or k.endswith("__converted") or \
               k.endswith("__unit"):
                continue
            miss_t = r.get(k + "__missing_type")
            if miss_t:
                jr[k] = None
                jr[k + "__missing_type"] = miss_t
            elif v == "":
                jr[k] = None
            else:
                jr[k] = v
        json_records.append(jr)
    artifacts["cleaned_data.json"] = "cleaned_data.json"
    (out_dir / "cleaned_data.json").write_text(json.dumps(
        json_records, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---- quality report (single stats source) ----
    hits, total = verify_quotes(sources, all_issues, all_changes, texts)
    hit_rate = (hits / total) if total else 1.0
    summary["quote_hits"] = hits
    summary["quote_total"] = total
    summary["quote_hit_rate"] = round(hit_rate, 4)
    self_check = "pass"
    # recompute missing total from cleaned_data.json
    try:
        rec = json.loads((out_dir / "cleaned_data.json").read_text(
            encoding="utf-8"))
        miss_recount = sum(1 for r in rec for k, v in r.items()
                           if k.endswith("__missing_type"))
        if miss_recount != summary["missing_total"]:
            self_check = "fail"
            degradations.append({"type": "report_mismatch",
                                 "detail": "missing count mismatch"})
    except Exception as e:
        self_check = "unverified"
        degradations.append({"type": "self_check_error", "detail": str(e)})
    summary["self_check"] = self_check

    lines = ["# 数据清洗质量报告", "",
             f"- 案例：{case.get('case_id')}", "",
             "## 输入", ""]
    for s in summary["inputs"]:
        lines.append(f"- {s['source']}（{s['encoding']}, {s['bytes']} B）")
    lines += ["", "## 汇总", "",
              f"- 数据表：{summary['tables']}", f"- 原始行数：{summary['rows']}",
              f"- 字段数：{summary['columns']}",
              f"- 缺失值条目：{summary['missing_total']}",
              f"- 异常值条目：{summary['outlier_total']}",
              f"- 重复组：{summary['duplicate_groups']}（移除 "
              f"{summary['duplicates_removed']} 行）",
              f"- 单位换算：{summary['conversion_total']}",
              f"- 逐字证据命中：{summary['quote_hits']}/{summary['quote_total']}"
              f" = {summary['quote_hit_rate']}",
              f"- 报告与结果表自检：{self_check}", "",
              "## 降级", ""]
    lines += [f"- {d['type']}: {d.get('detail','')}" for d in degradations] \
        or ["- 无"]
    lines += ["", "## 规则", ""]
    for c in convs:
        lines.append(f"- 1 {c['from_unit']} = {c['factor']} {c['to_unit']}")
    if not convs:
        lines.append("- 无显式单位换算（值保持原样，见 uncertainty）")
    report = "\n".join(lines)
    artifacts["quality_report.md"] = "quality_report.md"
    (out_dir / "quality_report.md").write_text(report, encoding="utf-8")

    status = "complete" if not errors and not gaps else \
        ("partial" if not errors else "partial")
    if errors:
        status = "partial"
    if not table_items and not errors:
        status = "insufficient_evidence"

    result = build_result(case, artifacts, summary, sources, uncertainty,
                          all_changes, errors, degradations, gaps, status)
    (out_dir / "result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="main.py",
        description="Deterministic scientific data-cleaning pipeline")
    ap.add_argument("command", nargs="?", default="build",
                    choices=["build", "show", "check", "init"])
    ap.add_argument("--input", default=None)
    ap.add_argument("--work", default=None)
    ap.add_argument("--output", default=None)
    args = ap.parse_args(argv)

    def resolve_default(cand):
        for c in cand:
            if c and Path(c).exists():
                return c
        return cand[-1]

    args.input = args.input or resolve_default(
        [os.environ.get("SKILL_INPUT"), "/input", "input"])
    args.work = args.work or os.environ.get("SKILL_WORK") or \
        ("/app/work" if Path("/app").exists() else "work")
    args.output = args.output or os.environ.get("SKILL_OUTPUT") or \
        ("/app/output" if Path("/app").exists() else "output")

    if args.command == "show":
        in_dir = Path(args.input)
        print("input dir:", in_dir.resolve())
        if in_dir.exists():
            for p in sorted(in_dir.rglob("*")):
                if p.is_file():
                    print(" ", p.name, p.stat().st_size, "bytes")
        else:
            print("  (not found)")
        return 0

    if args.command == "init":
        print("init: nothing to scaffold; run `build` (default) to process "
              "/input. Usage: python main.py [build|show|check]")
        return 0

    result = run(argparse.Namespace(input=args.input, work=args.work,
                                    output=args.output))
    print(json.dumps({"case_id": result.get("case_id"),
                      "status": result.get("status"),
                      "errors": len(result.get("errors", [])),
                      "degradations": len(result.get("degradations", [])),
                      "gaps": len(result.get("gaps", [])),
                      "artifacts": list(result.get("artifacts", {}).keys())},
                     ensure_ascii=False))
    if args.command == "check":
        s = result.get("summary", {})
        print("quote check:", s.get("quote_hits"), "/", s.get("quote_total"),
              "=", s.get("quote_hit_rate"),
              "| self_check:", s.get("self_check"))
    return 0


if __name__ == "__main__":
    sys.exit(main())

---
name: research-data-cleaning
description: >-
  Deterministic, evidence-traced scientific data cleaning for research tables.
  Reads /input/{case.json,task.md,materials}, parses the data dictionary,
  per-metric unit/QC rules and cleaning workorder, then applies a five-stage
  pipeline (missing values, outliers, duplicates, format/unit conversion,
  quality report) and emits cleaned CSV/JSON, a field-level issue list, a
  rules/log, a quality report whose numbers match the cleaned table, and a
  contract-complete result.json. Pure Python standard library; no network.
version: 1.0.0
---

# research-data-cleaning

科研数据清洗与处理的确定性、可复核流水线。面向“仪器导出的宽表/已发表汇总表转录”场景：
缺失值有空格、`-999`、`未检测/低于检出限` 等多种写法；同一样品跨表重复；单位一处 `mg/L`、一处 `μg/mL`；
异常值可能是真实高值也可能是加样失误；质量报告数字必须与清洗后结果表一致。

## 触发条件（何时使用）

- 任务要求对科研表格做**清洗、统计、去重、单位/格式转换、质量报告**。
- 输入含 `case.json`（带 `case_id` 与 `output_contract`）与若干材料（数据表、数据字典、单位/QC 规则、清洗工单）。
- 需要把每个字段的处理规则、每处修改都能指回 `source + locator + 逐字 quote`，供他人复算。

## 调用方式

平台运行时材料位于 `/input`，产物写 `/app/work`（中间）与 `/app/output`（最终，含 `result.json`）。

```bash
# 单命令 = 完整流程（推荐，无工作稿也会从 /input 真实派生完整交付）
python /skills/weekly-skill/scripts/main.py

# 显式指定目录（本地自测用）
python scripts/main.py --input <in> --work <work> --output <out>

# 查看已识别输入与分类
python scripts/main.py show --input <in>

# 结构校验 + 逐字 quote 命中率自检
python scripts/main.py check --input <in> --work <work> --output <out>
```

`main.py` 不联网、只用标准库、不依赖 CWD（脚本目录由 `Path(__file__).resolve().parent` 决定）、退出码恒 0。

## 五阶段处理流程（脚本自动执行）

1. **缺失值**：区分 `empty`（录入缺失：空串/空白/`NA`/`null`/`-999` 等哨兵）、`below_detection`（未检测/低于检出限/`<LOD`/`ND`）与真值 `0`（不视为缺失）。**不填补、不推断**：缺失保留为空并记入 issue，绝不均值/中位数插补。
2. **异常值**：数值列基于分布（IQR `Q1-1.5·IQR / Q3+1.5·IQR`，样本过少时降级并注明）+ 字典/规则给定的物理上下限；**标记为主，不擅自删除**（工单明示才删除），保留理由。
3. **重复记录**：按数据字典中的真实主键（样品号/受试者/时间戳）识别；键归一化处理大小写、空白、全角、单位写法差异的近似重复；保留规则：字典/工单优先，否则保留缺失最少的一条，其余记录入 `duplicates.csv` 并写明依据。
4. **格式/单位转换**：编码探测与统一（UTF-8 输出）、分隔符识别、科学计数法/千分位/逗号小数/全角数字归一化、按规则单位换算（因子显式，`Decimal` 保精度，可逆：保留原值+换算值+因子映射）。
5. **质量报告**：字段级问题清单（缺失率、异常条数、重复组、转换记录），**所有数字由单一统计结构生成并与结果表交叉自检**，杜绝“报告与表对不上”。

## 输入输出

输入（只读）：
- `/input/case.json`：`case_id`、`output_contract`（每个字段必须原样回填进 `result.json`）、`task_instruction`。
- `/input/task.md`：任务说明。
- 材料：数据表（CSV/TSV/JSON 数组/XLSX/SQLite/Markdown 表/可抽文本 PDF）、数据字典、单位/QC 规则、清洗工单。

输出（`/app/output`）：
- `result.json`：`case_id` + 原样回填 `output_contract` 全部字段 + `status`、`errors`、`degradations`、`gaps`、`sources`（证据定位）、`uncertainty`、`change_records`、`artifacts`、`summary`。
- `cleaned_data.csv`：清洗后表（数值归一化/单位换算后，缺失为空，重复标记）。
- `cleaned_data.json`：机器可用结构化结果（缺失=`null` + `missing_type` 标记）。
- `deduplicated_data.csv`：去重后保留行。
- `issues.csv`：字段级问题清单（source/locator/逐字 quote/issue 类型/规则/动作）。
- `duplicates.csv`：被去除的重复记录与保留依据。
- `rules_log.json`：应用过的规则、换算映射、编码/分隔符修复。
- `quality_report.md`：质量报告，数字与结果表一致，含自检结论。
- `original_snapshot.csv`：原始快照（verbatim），供复算。

## 证据规范

- 每个 issue / change / 规则条目必须携带 `source`（材料相对路径）、`locator`（`file#row=N,col=NAME` 或 `file:line=N`）、`quote`（材料原文逐字串，可被原文命中）。
- `sources` 汇总全部证据定位；`uncertainty` 记录无法判断、单位不明、样本过小、PDF 需 OCR 等；`change_records` 记录每处原始值→清洗值及其规则。
- 空输入/坏 JSON/缺材料/权限不足 → 分别产出合法 `partial`，`status=partial / insufficient_evidence / input_error`，并写 `gaps`，绝不 0 字节、绝不崩溃。

## 降级表

| 情形 | status | 动作 |
|-|-|-|
| `case.json` 缺失/空 | `input_error` | 写空契约 result.json + gaps，退出码 0 |
| `case.json` 坏 JSON | `input_error` | 记录解析错误，其余字段 null/[] |
| 无数据表材料 | `insufficient_evidence` | 输出报告 + gaps，说明缺材料 |
| 缺列/类型错/空表/坏 CSV | `partial` | 处理可解析部分，逐项写 gaps |
| 字典/规则/工单缺失 | `partial`（或 complete+degradation） | 用默认判据并注明不确定性 |
| PDF 无文本层 | `partial` | 提示用 pdf-text-tool/OCR 后再跑 |
| 权限不足 | `partial` | 记录 error，写可写部分 |

## 自检（脚本内建）

- 先写 `partial result.json`，再增量 `finalize`；全部异常捕获写入 `errors/degradations`，退出码恒 0。
- 输出后逐字校验：对每个 `quote` 检查其是否命中对应源文件原文，命中率记入 `quality_report.md` 与 `result.json`（目标 ≥0.95）。
- 报告数字从单一 `summary` 生成并与 `cleaned_data.csv` 重算值比对（`self_check: pass/fail`）。

## 限制

- 不做统计建模/假设检验、不做出版级排版、不推断总体统计量、**不插补缺失或无效源值**（按题面明确要求）。
- 单位换算只使用规则/字典中显式给出的因子；缺失规则时保留原值并标注，不猜测。
- 需 OCR 的扫描 PDF/图片表格须由 Agent 用平台 `pdf-text-tool`/`ocr-tool` 先抽文本，再交由本流水线处理。

---
name: workflow-figure
description: Turn an apparatus list, protocol, methods paragraph or research plan into a source-bound experimental-setup / technical-route figure. Each part becomes a component, each relation becomes a typed directed connection, and numbered phases/steps become stages; every drawn element carries a locator plus a verbatim quote, and the package ships an editable layered SVG plus real PNG and PDF exports.
version: 7.0
---

# Experimental setup & technical-route figure builder (`workflow-figure`)

Build a component–connection–stage diagram from the supplied materials. Parts,
modules, materials and steps become **components**; relations between them become
**connections** (directed, typed); explicit numbered phases/stages/steps become
**stages** (the columns of the route). Nothing is drawn that the text does not state.

## One command

```bash
python3 scripts/main.py
```

`init`, `build`, `check`, `selfcheck` are aliases over the same pipeline:
`python3 scripts/main.py build --input /input --work /work --output /output`.
`show --material m1` prints the locator-bearing text chunks so quotes can be copied
verbatim.

## How the three primitives are derived

1. **Text** — PDFs go through a linear content-stream scanner (correct word spacing,
   restored `fi`/`fl` ligatures, `Tm`/`Td` line ordering, headers/footnotes/references
   dropped); markdown/text/CSV/DOCX/PPTX/SVG are read directly. `pdf-text-tool`/OCR
   output can be dropped under `/app/work/text/` and merged.
2. **Components** — acronyms, capitalised phrases and noun phrases headed by
   part/process words (`reactor`, `chamber`, `electrode`, `catalyst`, `pump`, `valve`,
   `column`, `detector`, `sample`, `solution`, `model`, `policy`, `dataset`, …).
   Matching is word-bounded, so `EGF` never merges into `EGFR`. Frequency and
   co-occurrence floors keep a six-line protocol from collapsing to one node.
3. **Connections** — every relation verb in a sentence is considered, not just the
   first: source = nearest component before the verb, target = nearest component after.
   A verb with no component on both sides produces no edge.
4. **Stages** — the longest explicit numbered list (`three phases: 1) … 2) … 3) …`,
   `steps: 1. … 2. … 3. …`) becomes the stage columns. When the material lists fewer
   than three, Setup/Procedure/Readout stages are synthesised and recorded as a gap —
   never presented as a quoted claim.

## Connection semantics (apparatus / route grammar)

| relation_type | meaning | marker |
|---|---|---|
| `flow` | material/data moves A → B | filled blue arrowhead |
| `transport` | physical transfer, pump, reflux | dashed teal arrow |
| `activation` | a step enables the next | filled green arrowhead |
| `inhibition` | a step blocks a branch | flat red bar |
| `containment` | a module holds a part | dotted grey, no head |
| `upstream` | sequence order without transport | dashed grey arrowhead |
| `transformation` | produces / converts / fits / trains | filled amber arrowhead |

Every connection names its relation type; the edge label is the relation verb from the
material (`optimizes`, `feeds`, `produces`, …), never an invented process name. Every
relation type used in the figure appears in the legend.

## Provenance gate

Every component and connection is checked against the material with word-level
containment (robust to hyphenation and spacing), and against a second, naive extractor.
`quote_hit_rate` must reach 0.95; relations scoring below 0.9 are dropped rather than
drawn. Placeholder tokens (`Entity`, `Node`, `TBD`, `示例`, `占位`, …) are rejected as
labels. Every component in `content_map.json` carries `locator` + `quote`.

## Outputs

`figure.svg` (layered `<g id="layer-…">` + real `<text>`, one id per element),
`figure.png` (labels blitted with an embedded 5×7 font so the raster is never blank),
`figure.pdf` (text layer, `Tj` operators), `figure_model.json` (the rendered model),
`content_map.json` (every stage/component/connection/legend item → locator + verbatim
quote), `compliance_checks.json`, `edit_record.json`, `self_check.json`, `run.log`, and
a contract-complete `result.json` (`case_id`, `status`, `result`, `claims`, `coverage`,
`editable_source`, `export_artifact`, `content_map`, `compliance_checks`, `exceptions`,
`sources`, `uncertainty`, `gaps`, `degradations`).

## Hard acceptance metrics (reported by `self_check`)

- ≥ 6 components, ≥ 5 connections, ≥ 3 stages;
- every component has a `locator` + verbatim `quote`;
- SVG has layered `<g id="layer-…">` and ≥ 6 `<text>` elements;
- PNG is a real PNG with ≥ 3% non-white pixels (labels actually drawn);
- PDF is a real PDF with ≥ 4 `Tj`/`TJ` text operators;
- two runs over the same input produce byte-identical artefacts (deterministic layout).

## Degraded inputs

Empty, malformed or material-free input still writes every contract key, exits 0 and
reports `status=partial` (`input_error` when nothing was scanned) with `gaps`,
`uncertainty` and `degradations`. A component is never invented to fill the canvas; a
missing stage is labelled inferred rather than quoted.

## Boundaries

This skill extracts and lays out what the material states. It does not judge whether the
experiment was well designed, does not fit data, and does not beautify a figure beyond
the grammar above. When the material does not support a claim, the figure says less —
and `exceptions`/`uncertainty` says why.

"""Component / connection / stage extraction for apparatus & technical-route figures.

This is the workflow-track engine. It keeps the v6 prose scanner (verbatim
locator + quote provenance, quote windows that survive an independent PDF
extractor) and adds the three workflow primitives:

  * component  (part / module / material / model / step)  -> drawn as a box
  * connection (directed relation with a relation type)    -> drawn as an arrow
  * stage      (explicit numbered phase/stage/step list)   -> drawn as a panel

Nothing is invented: a component is emitted only when the text names it, a
connection only when both endpoints and a relation verb occur in one sentence,
and a stage only when the text states a numbered phase/stage/step list (or the
component ordering is used as a last-resort fallback, which is then recorded as
a gap instead of a claim).
"""
import re
from collections import Counter

STOP = set("""THE AND FOR WITH FROM THIS THAT THESE THOSE ARE WAS WERE HAS HAVE HAD NOT BUT ITS OUR
THEIR THEY THEM THEN THAN INTO OVER SUCH MORE MOST ALSO ONLY BOTH EACH OTHER USING USED USE CAN MAY
WILL WOULD COULD SHOULD ABOUT WHICH WHILE WHERE WHEN WHAT HOW ALL ANY SOME ONE TWO NEW VIA PER FIG
TABLE EQ SECTION APPENDIX ARXIV HTTP HTTPS URL DOI ET AL IE EG VS""".split())

GENERIC = set("""step steps phase phases stage stages method method methods
model models function functions dataset datasets policy policies
learning training objective objectives loss losses reward rewards feedback preference preferences
algorithm algorithms classifier classifiers optimization data paper section figure table equation
appendix result results approach approaches task tasks example examples input inputs output outputs
performance analysis problem value values number numbers form forms type types case cases way ways
part parts work works study studies order terms term end start time times process processes""".split())

DET = ("the ", "a ", "an ", "this ", "that ", "these ", "those ", "its ", "their ", "our ")

AFFIL = re.compile(r"University|Institute|College|Department|States|Linguistics|Proceedings|"
                   r"Conference|Workshop|Press|arXiv", re.I)

# Workflow relation types (apparatus / technical-route grammar). The verb lists are
# deliberately typed: flow is movement of matter/data, transport is a physical
# transfer, upstream is pure sequence order, transformation is produce/convert/fit.
REL = {
    "flow": "flow flows flowed feed feeds fed enter enters entered pass passes passed move moves moved "
            "output outputs outputted emit emits emitted supply supplies supplied deliver delivers delivered "
            "route routes routed pipe pipes piped inject injects injected withdraw withdraws withdrawn",
    "transport": "transport transports transported convey conveys conveyed carry carries carried pumps "
                 "pumped circulate circulates circulated return returns returned reflux refluxes transfer "
                 "transfers transferred",
    "activation": "activate activates activated enable enables enabled drive drives driven trigger triggers "
                  "triggered promote promotes promoted stimulate stimulates stimulated induce induces induced",
    "inhibition": "inhibit inhibits inhibited suppress suppresses suppressed block blocks blocked prevent "
                  "prevents prevented stop stops stopped reduce reduces reduced decrease decreases decreased",
    "containment": "contain contains contained comprise comprises comprised consist consists consisted "
                   "include includes included hold holds held house houses housed mount mounts mounted "
                   "assemble assembles assembled",
    "upstream": "precede precedes preceded follow follows followed subsequently finally",
    "transformation": "convert converts converted transform transforms transformed synthesize synthesizes "
                      "synthesized produce produces produced generate generates generated yield yields yielded "
                      "fit fits fitted train trains trained optimize optimizes optimized compute computes "
                      "computed extract extracts extracted derive derives derived catalyze catalyzes catalyzed",
}
VERB2TYPE = {}
for _t, _words in REL.items():
    for _w in _words.split():
        VERB2TYPE[_w] = _t

TYPE_LABEL = {"flow": "flow / feeds", "transport": "transports / pumps",
              "activation": "activates / enables", "inhibition": "inhibits / blocks",
              "containment": "contains / holds", "upstream": "precedes / then",
              "transformation": "produces / converts"}

STYLE_TYPES = tuple(REL.keys())

# Head words that make a noun phrase a workflow component candidate.
HEADS = (r"models?|polic(?:y|ies)|objectives?|preferences?|datasets?|feedback|training|"
         r"loss(?:es)?|rewards?|classifiers?|functions?|optimization|modules?|pipelines?|"
         r"cascades?|membranes?|nucleus|complex(?:es)?|receptors?|pathways?|blocks?|loops?|"
         r"factors?|proteins?|kinases?|transcription|signall?ing|dimeri[sz]ation|"
         r"phosphorylation|apoptosis|ectodomain|chambers?|reactors?|electrodes?|"
         r"catalysts?|samples?|columns?|detectors?|pumps?|valves?|sensors?|solutions?|"
         r"precursors?|solvents?|substrates?|products?|vessels?|furnaces?|stages?|steps?|"
         r"phases?|labelers?|prompts?|answers?|responses?|completions?|models?|"
         r"objectives?|controllers?|mixers?|separators?|condensers?|heaters?|coolers?")


def normalize(text):
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\u00ad", "")
    return re.sub(r"[ \t]+", " ", text)


def strip_refs(text):
    low = text.lower()
    for marker in ("\nreferences\n", "\nreference\n", "\nbibliography\n"):
        i = low.rfind(marker)
        if i > len(text) * 0.5:
            return text[:i]
    return text


def squeeze(s):
    return re.sub(r"\s+", " ", s).strip()


def split_sentences(block):
    block = squeeze(block)
    return [x.strip() for x in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])", block) if x.strip()]


def good_sentence(s):
    toks = re.findall(r"[A-Za-z][A-Za-z\-]+", s)
    if len(toks) < 6:
        return False
    if sum(1 for ch in s if ch.isalpha()) / float(len(s)) < 0.62:
        return False
    if sum(1 for t in toks if len(t) <= 2) / float(len(toks)) > 0.4:
        return False
    if sum(s.count(c) for c in "();") > 0.09 * len(s):
        return False
    raw = s.split()
    if raw and sum(1 for t in raw if len(t) == 1) / float(len(raw)) > 0.15:
        return False
    return True


def _paragraphs(text):
    lines = [ln.strip() for ln in text.split("\n")]
    out, buf = [], []
    for ln in lines:
        if not ln:
            if buf:
                out.append(" ".join(buf))
                buf = []
            out.append("")
            continue
        buf.append(ln)
        if ln.endswith((".", "!", "?", ":")) and len(" ".join(buf)) > 240:
            out.append(" ".join(buf))
            buf = []
    if buf:
        out.append(" ".join(buf))
    return [x for x in out if x.strip()]


def chunk_text(text, size=1500, prefix="m1"):
    chunks, buf, loc = [], "", 1
    for p in _paragraphs(text):
        if len(buf) + len(p) + 1 > size and buf.strip():
            chunks.append({"locator": "%s#p%d" % (prefix, loc), "text": buf.strip()})
            loc += 1
            buf = p
        else:
            buf = (buf + " " + p) if buf else p
    if buf.strip():
        chunks.append({"locator": "%s#p%d" % (prefix, loc), "text": buf.strip()})
    return chunks


def cand_components(sents):
    c = Counter()
    text = " ".join(s for _, s in sents)
    for m in re.finditer(r"\b[A-Z][A-Z0-9]{1,7}\b", text):
        w = m.group(0)
        if w in STOP or w in GENERIC or w.isdigit():
            continue
        c[w] += 1
    for m in re.finditer(r"\b[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,}){1,3}\b", text):
        c[m.group(0)] += 1
    pat = (r"\b(?:(?:the|a|an)\s+)?(?:[a-z][a-z-]+\s){0,2}(" + HEADS + r")\b")
    for m in re.finditer(pat, text, re.I):
        ph = m.group(0).strip().lower()
        for d in DET:
            if ph.startswith(d):
                ph = ph[len(d):]
        if ph.startswith(("of ", "in ", "for ", "to ", "with ", "on ", "by ", "from ",
                          "as ", "at ", "that ", "which ", "and ", "or ")):
            continue
        if ph and ph not in GENERIC and not re.search(r"\b(?:to|for|with|of|from|into|by)\b", ph):
            c[ph] += 1
    for m in re.finditer(r"[“\"]([A-Za-z][^”\"]{2,40})[”\"]", text):
        c[m.group(1).strip()] += 1
    return c


def choose_components(sents, limit=12):
    c = cand_components(sents)
    n_chunks = len({loc for loc, _ in sents})
    locs = {}
    for loc, s in sents:
        low = s.lower()
        for k in c:
            if k.lower() in low:
                locs.setdefault(k, set()).add(loc)
    keep2 = {"RL", "RM", "LM", "KL", "AI", "ML", "NN"}
    min_freq = 2 if n_chunks >= 3 else 1
    items = []
    for k, v in c.items():
        if not (2 <= len(k) <= 40) or v < min_freq:
            continue
        if len(k) == 2 and k.isupper() and k not in keep2:
            continue
        if k.lower() in GENERIC or AFFIL.search(k):
            continue
        # Page headings merged with adjacent prose are not apparatus entities.
        toks = k.lower().split()
        if len(toks) > 1 and (toks[0] in {"results", "result", "conclusion", "conclusions",
                                        "introduction", "abstract", "background", "discussion",
                                        "method", "methods", "references"}
                              or toks[-1] in {"the", "a", "an", "these", "those"}):
            continue
        if any(w in VERB2TYPE for w in k.lower().split()):
            continue
        if n_chunks >= 3 and len(locs.get(k, ())) < 2:
            continue
        items.append((k, v))
    items.sort(key=lambda kv: (-kv[1], -len(kv[0])))
    chosen = []
    for k, _v in items:
        kl = k.lower()
        if any(kl == x.lower() for x in chosen):
            continue
        chosen.append(k)
        if len(chosen) >= limit:
            break
    return chosen


def _mention_re(term):
    return re.compile(r"(?<![A-Za-z0-9])" + re.escape(term) + r"(?![A-Za-z0-9])", re.I)


def word_score(quote, ntext):
    words = [w for w in re.findall(r"[A-Za-z][A-Za-z0-9\-]{2,}", quote or "")]
    if not words:
        return 1.0
    hit = sum(1 for w in words if w.lower() in ntext)
    return hit / float(len(words))


def _words(s):
    return [(m.start(), m.end()) for m in re.finditer(r"\S+", s)]


def _window(s, spans, start, end):
    start = max(0, min(start, len(spans) - 1))
    end = max(start, min(end, len(spans) - 1))
    return s[spans[start][0]:spans[end][1]].strip()


def _verb_index(s, spans, verb):
    vpos = s.lower().find(verb.lower())
    for i, (a, b) in enumerate(spans):
        if a <= vpos < b:
            return i
    return 0


def quote_window(s, src, tgt, verb, lo=12, hi=20):
    spans = _words(s)
    if not spans:
        return s
    vi = _verb_index(s, spans, verb)
    si = ti = None
    for i, (a, b) in enumerate(spans):
        if i <= vi and s[a:b].lower().startswith(src.lower()[:10]):
            si = i
    for i, (a, b) in enumerate(spans):
        if i >= vi and s[a:b].lower().startswith(tgt.lower()[:10]):
            ti = i
            break
    start = si if si is not None else max(0, vi - 3)
    end = ti if ti is not None else min(len(spans) - 1, vi + 3)
    start, end = min(start, vi), max(end, vi)
    while end - start + 1 < lo and (start > 0 or end < len(spans) - 1):
        if start > 0:
            start -= 1
        if end - start + 1 < lo and end < len(spans) - 1:
            end += 1
    while end - start + 1 > hi:
        if vi - start >= end - vi and start < vi:
            start += 1
        elif end > vi:
            end -= 1
        else:
            break
    return _window(s, spans, start, end)


def best_quote(s, src, tgt, verb, reference=""):
    spans = _words(s)
    if not spans:
        return s
    vi = _verb_index(s, spans, verb)
    cands = [quote_window(s, src, tgt, verb)]
    for radius in (6, 8, 10):
        cands.append(_window(s, spans, vi - radius, vi + radius))
    for lo, hi in ((12, 20), (12, 16), (14, 20)):
        cands.append(quote_window(s, src, tgt, verb, lo=lo, hi=hi))
    if not reference:
        return cands[0]
    best, best_score = cands[0], word_score(cands[0], reference)
    for cand in cands[1:]:
        if not cand:
            continue
        sc = word_score(cand, reference)
        n = len(cand.split())
        if sc > best_score or (sc == best_score and 12 <= n <= 20 and
                               len(best.split()) > 20):
            best, best_score = cand, sc
    return best


def parse_numbered_items(s):
    """Parse ``1) aaa; 2) bbb and 3) ccc`` into a list of item strings."""
    marks = [(m.start(), m.group(1)) for m in re.finditer(r'(\d+)\)\s*', s)]
    if len(marks) < 2:
        return []
    items = []
    for i, (pos, num) in enumerate(marks):
        end = marks[i + 1][0] if i + 1 < len(marks) else len(s)
        text = s[pos:end]
        text = re.sub(r'^\d+\)\s*', '', text)
        text = text.strip()
        text = re.sub(r'[\s;,]+$', '', text)
        text = re.sub(r'\s+and$', '', text)
        text = re.sub(r'[.\s]+$', '', text)
        if text and len(text) <= 300:
            items.append(text)
    return items


def extract_stages(sents, limit=6):
    """Find explicit numbered phase/stage/step lists; return [] when absent."""
    numbered = []
    for loc, sentence in sents:
        m = re.match(r"^\s*(?:step|phase|stage)\s*(\d{1,2})\s*[:.)-]\s*(.+)$", sentence, re.I)
        if m:
            numbered.append((int(m.group(1)), loc, squeeze(m.group(2)), squeeze(sentence)))
    unique = {}
    for num, loc, title, quote in numbered:
        unique.setdefault(num, (loc, title, quote))
    if len(unique) >= 2:
        stages = []
        for i, num in enumerate(sorted(unique)[:limit], 1):
            loc, title, quote = unique[num]
            stages.append({"id": "s%d" % i, "title": title[:150],
                           "role": "method", "locator": loc, "quote": quote})
        return stages
    best = []
    for loc, s in sents:
        if not re.search(r'\b(phases?|stages?|steps?)\b', s, re.I):
            continue
        if ')' not in s:
            continue
        items = parse_numbered_items(s)
        if len(items) >= 2:
            if len(items) > len(best):
                best = items
                best_loc, best_s = loc, s
    if len(best) < 2:
        return []
    roles = ["problem"] + ["method"] * max(0, len(best) - 2) + ["result"]
    stages = []
    for i, item in enumerate(best[:limit]):
        stages.append({
            "id": "s%d" % (i + 1),
            "title": item,
            "role": roles[i] if i < len(roles) else "method",
            "locator": best_loc,
            "quote": squeeze(best_s)[:360],
        })
    return stages


def _contains_term(text, term):
    return re.search(r'(?<![A-Za-z0-9])' + re.escape(term) + r'(?![A-Za-z0-9])',
                     text, re.I) is not None


def assign_stages(components, stages, first):
    """Map each component to a stage id. Explicit title match first; otherwise a
    deterministic first-mention position rule (before/at/after the stage list)."""
    mapping = {}
    n = len(stages)
    stage_texts = [(s["title"] + " " + s["quote"]).lower() for s in stages]
    stage_locs = [s.get("locator", "") for s in stages]
    for c in components:
        cl = c.lower()
        hit = None
        for si, st in enumerate(stage_texts):
            if _contains_term(st, cl):
                hit = si
                break
        if hit is not None:
            mapping[c] = stages[hit]["id"]
            continue
        # fallback: compare first-mention locator with the stage list locator
        floc = (first.get(c) or ("", ""))[0]
        if floc and stage_locs:
            if floc < stage_locs[0]:
                mapping[c] = stages[0]["id"]
            elif n > 2 and floc > stage_locs[-1]:
                mapping[c] = stages[-1]["id"]
            else:
                mapping[c] = stages[min(n - 1, n // 2)]["id"]
        else:
            mapping[c] = stages[0]["id"]
    return mapping


def build_model(text, case_terms=None, limit=12, prefix="m1", reference=""):
    """Derive components/connections from prose; stages are handled by the caller
    because they need the merged material view. Each connection is anchored to a
    verbatim quote."""
    text = strip_refs(normalize(text))
    chunks = chunk_text(text, prefix=prefix)
    sents = []
    for ch in chunks:
        for s in split_sentences(ch["text"]):
            if good_sentence(s) or re.match(r"^\s*(?:step|stage|phase)\s*\d+\s*[:.)-]", s, re.I):
                sents.append((ch["locator"], s))

    ents = choose_components(sents, limit)
    have = {e.lower() for e in ents}
    for term in (case_terms or []):
        term = str(term).strip()
        if term and 2 <= len(term) <= 40 and term.lower() not in have:
            if any(term.lower() in s.lower() for _, s in sents):
                ents.append(term)
                have.add(term.lower())

    first = {}
    for loc, s in sents:
        for e in ents:
            if e not in first and e.lower() in s.lower():
                first[e] = (loc, s)

    relations, seen = [], set()
    for loc, s in sents:
        present = []
        for e in ents:
            for m in _mention_re(e).finditer(s):
                present.append((m.start(), e))
        if len(present) < 2:
            continue
        present.sort()
        for vm in re.finditer(r"[A-Za-z][A-Za-z\-]*", s):
            w = vm.group(0).lower()
            if w not in VERB2TYPE:
                continue
            vpos, vtype, vword = vm.start(), VERB2TYPE[w], w
            before = [e for (p, e) in present if p < vpos]
            after = [e for (p, e) in present if p > vpos]
            if not before or not after:
                continue
            src, tgt = before[-1], after[0]
            if src == tgt:
                continue
            key = (src, tgt, vtype)
            if key in seen:
                continue
            seen.add(key)
            quote = best_quote(s, src, tgt, vword, reference)
            if reference and word_score(quote, reference) < 0.9:
                continue
            relations.append({"source": src, "target": tgt, "type": vtype, "verb": vword,
                              "locator": loc, "quote": quote, "source_sentence": quote})

    return {"chunks": chunks, "sentences": sents, "entities": ents,
            "relations": relations, "first": first}


def verify_quotes(pairs, chunk_map):
    checked = hits = 0
    misses = []
    for loc, quote in pairs:
        if not quote:
            continue
        checked += 1
        body = chunk_map.get(loc, "")
        if squeeze(quote) and squeeze(quote) in squeeze(body):
            hits += 1
        else:
            misses.append({"locator": loc, "quote": quote[:120]})
    rate = hits / float(checked) if checked else 0.0
    return {"checked": checked, "hits": hits, "misses": misses,
            "quote_hit_rate": round(rate, 4)}

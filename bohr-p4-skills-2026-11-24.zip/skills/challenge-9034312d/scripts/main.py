"""Source-grounded apparatus and technical-route diagram generator."""
import argparse
import json
import re
import sys
import zipfile
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import extract as X          # noqa: E402
import pdftext as P          # noqa: E402
import render as R           # noqa: E402
VERSION = "7.0"
CONTRACT_KEYS = ["case_id", "status", "result", "claims", "coverage"]
HONESTY_KEYS = ["sources", "uncertainty", "gaps", "degradations"]
PLACEHOLDER = re.compile(r"\b(Entity|Node|Item|Slide|TBD|TODO|Lorem|placeholder|示例|占位)\b", re.I)
TEXT_EXT = {".md", ".txt", ".csv", ".tsv", ".json", ".yaml", ".yml", ".rst", ".tex"}
SKIP = {"case.json", "task.md"}  # task instructions are not observational evidence
DEVICE_SUFFIX = ("reactor", "chamber", "pump", "valve", "column", "detector", "electrode",
                 "sensor", "vessel", "furnace", "mixer", "separator", "condenser", "heater",
                 "cooler", "membrane", "loop", "block")
MATERIAL_SUFFIX = ("solution", "precursor", "solvent", "substrate", "sample", "product",
                   "catalyst", "complex", "dataset", "feedback")
def jdump(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True),
                          encoding="utf-8")
def jload(path, default=None):
    try:
        raw = Path(path).read_bytes()
    except Exception:
        return default
    for enc in ("utf-8-sig", "utf-8", "gb18030", "latin-1"):
        try:
            return json.loads(raw.decode(enc))
        except Exception:
            continue
    return default
def parse_args(argv):
    cmd = "auto"
    ns = {"input": None, "work": None, "output": None, "material": None}
    i = 0
    while i < len(argv):
        a = argv[i]
        hit = False
        for k in ("input", "work", "output", "material"):
            if a == "--" + k and i + 1 < len(argv):
                ns[k] = argv[i + 1]
                i += 2
                hit = True
                break
            if a.startswith("--" + k + "="):
                ns[k] = a.split("=", 1)[1]
                i += 1
                hit = True
                break
        if hit:
            continue
        if not a.startswith("-") and cmd == "auto":
            cmd = a
        i += 1
    return cmd, ns
def resolve(ns):
    def pick(key, default):
        raw = ns.get(key) or default
        p = Path(raw)
        if raw == default and not p.exists():
            alt = Path(default.lstrip("/"))
            if alt.exists():
                return alt.resolve()
        return p.resolve()
    return pick("input", "/input"), pick("work", "/work"), pick("output", "/output")
def read_text_file(path, limit=3_000_000):
    try:
        raw = Path(path).read_bytes()
    except Exception:
        return ""
    for enc in ("utf-8", "utf-8-sig", "gb18030", "latin-1"):
        try:
            return raw.decode(enc)[:limit]
        except Exception:
            continue
    return raw.decode("utf-8", "replace")[:limit]
def office_text(path):
    try:
        with zipfile.ZipFile(path) as zf:
            names = [n for n in zf.namelist() if n.endswith(".xml")]
            chunks = []
            for n in sorted(names)[:40]:
                body = zf.read(n).decode("utf-8", "replace")
                chunks += re.findall(r"<a:t>(.*?)</a:t>|<w:t[^>]*>(.*?)</w:t>", body)
            flat = []
            for tup in chunks:
                flat.append(tup[0] or tup[1])
            return "\n".join(x for x in flat if x)
    except Exception:
        return ""
def discover(inp):
    mats = []
    root = Path(inp)
    if not root.exists():
        return mats
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.name.startswith(".") or p.name in SKIP:
            continue
        suffix = p.suffix.lower()
        rec = {"material_id": "m%d" % (len(mats) + 1), "rel": p.name, "suffix": suffix,
               "bytes": p.stat().st_size, "text": "", "kind": "other"}
        try:
            if suffix == ".pdf":
                rec["text"], rec["pages"], ratio = P.pdf_text(p)
                rec["kind"] = "pdf"
                rec["alpha_ratio"] = round(ratio, 3)
                try:
                    rec["naive"] = P.naive_text(p)
                except Exception:
                    rec["naive"] = ""
            elif suffix in TEXT_EXT:
                rec["text"] = read_text_file(p)
                rec["kind"] = "table" if suffix in (".csv", ".tsv") else "text"
            elif suffix in (".docx", ".pptx"):
                rec["text"] = office_text(p)
                rec["kind"] = "office"
            elif suffix == ".svg":
                body = read_text_file(p)
                rec["text"] = " ".join(re.findall(r"<text[^>]*>(.*?)</text>", body, re.S))
                rec["kind"] = "svg"
        except Exception as exc:
            rec["error"] = str(exc)
        rec["text_chars"] = len(rec["text"] or "")
        mats.append(rec)
    return mats
def case_terms(case):
    out = []
    if not isinstance(case, dict):
        return out
    for key in ("workorder", "entities", "nodes", "objects", "targets"):
        val = case.get(key)
        if isinstance(val, list):
            for v in val:
                if isinstance(v, str):
                    out.append(v)
                elif isinstance(v, dict):
                    for k in ("label", "name", "id", "term"):
                        if isinstance(v.get(k), str):
                            out.append(v[k])
    return out[:20]
def merge_models(models):
    """Merge per-material models into one canonical component/connection graph."""
    canon, order, first = {}, [], {}
    chunks, sentences = {}, []
    rels, seen = [], set()
    for mod in models:
        for c in mod.get("chunks") or []:
            chunks[c["locator"]] = c["text"]
        for loc, s in mod.get("sentences") or []:
            sentences.append((loc, s))
        for e in mod.get("entities") or []:
            low = e.lower()
            if low not in canon:
                canon[low] = e
                order.append(e)
        for e in mod.get("entities") or []:
            lab = canon[e.lower()]
            if lab not in first and e in (mod.get("first") or {}):
                first[lab] = mod["first"][e]
        for r in mod.get("relations") or []:
            src, tgt = canon.get(r["source"].lower()), canon.get(r["target"].lower())
            if not src or not tgt or src == tgt:
                continue
            key = (src, tgt, r["type"])
            if key in seen:
                continue
            seen.add(key)
            rels.append(dict(r, source=src, target=tgt))
    return {"components": order, "connections": rels, "first": first,
            "chunks": chunks, "sentences": sentences}
def derive(mats, case):
    terms = case_terms(case)
    ref_raw = [m.get("naive") or m.get("text") or "" for m in mats]
    reference = re.sub(r"\s+", "", "\n".join(ref_raw)).lower()
    models = []
    for m in mats:
        text = m.get("text") or ""
        if len(text.strip()) < 40:
            continue
        models.append(X.build_model(text, case_terms=terms, prefix=m["material_id"],
                                    reference=reference))
    return merge_models(models)
def loc_key(loc):
    m = re.match(r"(\w+)#p(\d+)", loc or "")
    if m:
        return (m.group(1), int(m.group(2)))
    return (loc or "", 0)
def classify(label):
    low = str(label).lower()
    if any(low.endswith(w) for w in DEVICE_SUFFIX):
        return "device"
    if any(low.endswith(w) for w in MATERIAL_SUFFIX):
        return "material"
    if re.fullmatch(r"[A-Z][A-Z0-9]{1,7}", str(label)):
        return "method"
    if low.endswith(("model", "policy", "reward", "objective", "loss")):
        return "model"
    return "process"
def extract_stages(sentences):
    """Extract the longest explicit numbered stage/phase/step list."""
    return X.extract_stages(sentences)
def ensure_stages(stages, components):
    """Return >=3 stages: explicit first, otherwise synthesise Setup/Procedure/
    Readout and record that the extra stages are inferred, not quoted."""
    inferred = False
    while len(stages) < 3:
        inferred = True
        labels = ["Setup", "Procedure", "Readout"]
        roles = ["problem", "method", "result"]
        i = len(stages)
        stages.append({"id": "s%d" % (i + 1), "title": labels[min(i, 2)],
                       "role": roles[min(i, 2)], "locator": "", "quote": "",
                       "inferred": True})
    return stages, inferred
def assign_components(components, stages, first):
    """Explicit title match first; remaining components are spread by first-mention
    order across the stages so no stage is left empty. Deterministic."""
    mapping = {}
    matched = set()
    for c in components:
        for s in stages:
            if X._contains_term(s["title"], c):
                mapping[c] = s["id"]
                matched.add(c)
                break
    remaining = [c for c in components if c not in matched]
    remaining.sort(key=lambda c: (loc_key((first.get(c) or ("", ""))[0]), c.lower()))
    for i, c in enumerate(remaining):
        mapping[c] = stages[i % len(stages)]["id"]
    return mapping
def build_figure_model(components, connections, stages, mapping, first, title, subtitle, footer):
    comps = []
    idx = {c: i for i, c in enumerate(components)}
    for i, c in enumerate(components):
        loc, quote = first.get(c, ("", ""))
        comps.append({
            "id": "c%d" % (i + 1),
            "label": c,
            "entity_type": classify(c),
            "stage": mapping.get(c, (stages[0]["id"] if stages else "s1")),
            "source": {"locator": loc, "quote": (quote or "")[:240]},
        })
    conns = []
    for i, r in enumerate(connections):
        conns.append({
            "id": "e%d" % (i + 1),
            "from": "c%d" % (idx[r["source"]] + 1),
            "to": "c%d" % (idx[r["target"]] + 1),
            "relation_type": r["type"],
            "verb": r.get("verb") or r["type"],
            "source": {"locator": r.get("locator") or "", "quote": (r.get("quote") or "")[:240]},
        })
    types = []
    for r in connections:
        if r["type"] not in types:
            types.append(r["type"])
    if len(stages) >= 2 and "upstream" not in types:
        types.append("upstream")
    model = {
        "figure_type": "workflow",
        "figure_id": "Figure 1",
        "title": str(title)[:90] or "Technical route figure",
        "subtitle": str(subtitle)[:120],
        "stages": stages,
        "components": comps,
        "connections": conns,
        "legend": types,
        "footer": footer,
    }
    return model, comps, conns, types
def content_map(model):
    out = []
    for s in model.get("stages") or []:
        out.append({"kind": "stage", "id": s.get("id"), "text": s.get("title"),
                    "locator": s.get("locator") or "", "quote": (s.get("quote") or "")[:240]})
    for c in model.get("components") or []:
        src = c.get("source") or {}
        out.append({"kind": "component", "id": c.get("id"), "text": c.get("label"),
                    "locator": src.get("locator") or "", "quote": (src.get("quote") or "")[:240]})
    first_quote = {}
    for r in model.get("connections") or []:
        src = r.get("source") or {}
        t = r.get("relation_type")
        first_quote.setdefault(t, (src.get("locator") or "", src.get("quote") or ""))
        out.append({"kind": "connection", "id": r.get("id"),
                    "text": r.get("verb") or r.get("relation_type"),
                    "locator": src.get("locator") or "", "quote": (src.get("quote") or "")[:240]})
    for t in model.get("legend") or []:
        loc, quote = first_quote.get(t, ("", ""))
        out.append({"kind": "legend", "text": t, "locator": loc, "quote": (quote or "")[:240]})
    return out
def from_plan(plan, mats):
    """Agent-authored plan takes precedence (same workflow schema)."""
    comps, conns, stages = [], [], []
    first = {}
    for e in plan.get("components") or plan.get("nodes") or []:
        if isinstance(e, str):
            label = e
        elif isinstance(e, dict):
            label = e.get("label") or e.get("name") or e.get("id")
        if not label:
            continue
        comps.append(label)
        if isinstance(e, dict) and e.get("source"):
            first[label] = (e["source"].get("locator") or "", e["source"].get("quote") or "")
    for s in plan.get("stages") or plan.get("panels") or []:
        if isinstance(s, str):
            stages.append({"id": "s%d" % (len(stages) + 1), "title": s, "role": "method",
                           "locator": "", "quote": ""})
        elif isinstance(s, dict):
            stages.append({"id": s.get("id") or "s%d" % (len(stages) + 1),
                           "title": s.get("title") or s.get("label") or "",
                           "role": s.get("role") or "method",
                           "locator": (s.get("source") or {}).get("locator") or "",
                           "quote": (s.get("source") or {}).get("quote") or ""})
    for r in plan.get("connections") or plan.get("edges") or []:
        src = r.get("from") or r.get("source")
        tgt = r.get("to") or r.get("target")
        if not src or not tgt:
            continue
        conns.append({"source": src, "target": tgt, "type": r.get("relation_type") or r.get("type") or "flow",
                      "verb": r.get("verb") or r.get("label") or r.get("relation_type") or "flow",
                      "locator": (r.get("source_obj") or r.get("source") or {}).get("locator")
                      if isinstance(r.get("source"), dict) else r.get("locator") or "",
                      "quote": (r.get("source_obj") or r.get("source") or {}).get("quote")
                      if isinstance(r.get("source"), dict) else r.get("quote") or ""})
    return {"components": comps, "connections": conns, "stages": stages, "first": first}
def run(cmd, ns):
    inp, work, out = resolve(ns)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    case = jload(inp / "case.json", None)
    case_id = ""
    if isinstance(case, dict):
        case_id = str(case.get("case_id") or case.get("id") or "")
    mats = discover(inp)
    errors, gaps = [], []
    if not isinstance(case, dict):
        errors.append("case.json missing, invalid JSON, or not a JSON object")
    plan = jload(work / "plan.json", None)
    if plan is not None and not isinstance(plan, dict):
        gaps.append("work/plan.json is not a JSON object; ignored")
        plan = None
    if isinstance(plan, dict) and (plan.get("components") or plan.get("nodes") or
                                   plan.get("connections") or plan.get("edges")):
        model = from_plan(plan, mats)
        source = "plan"
    else:
        model = derive(mats, case)
        source = "derived"
    components = model.get("components") or []
    connections = model.get("connections") or []
    first = model.get("first") or {}
    chunks = model.get("chunks") or {}
    sentences = model.get("sentences") or []
    if not [m for m in mats if (m.get("text_chars") or 0) > 0]:
        gaps.append("no readable text material was found in the input")
    stages = extract_stages(sentences)
    if isinstance(model.get("stages"), list) and model["stages"]:
        stages = model["stages"]
    stages, inferred_stages = ensure_stages(stages, components)
    if inferred_stages and source != "plan":
        gaps.append("material has fewer than 3 explicit stages; remaining stages synthesised "
                    "as Setup/Procedure/Readout (inferred, not quoted)")
    mapping = assign_components(components, stages, first)
    pairs = [((r.get("locator") or ""), r.get("quote") or "") for r in connections]
    pairs += [((first.get(e) or ("", ""))[0], (first.get(e) or ("", ""))[1]) for e in components]
    ver = X.verify_quotes([p for p in pairs if p[1]], chunks)
    bad_labels = [l for l in components if PLACEHOLDER.search(l)]
    if bad_labels:
        gaps.append("placeholder-like labels rejected: %s" % bad_labels[:3])
    hard_metrics = {
        "components": len(components), "connections": len(connections),
        "stages": len(stages),
    }
    if hard_metrics["components"] < 6:
        gaps.append("fewer than 6 components were derived (%d)" % len(components))
    if hard_metrics["connections"] < 5:
        gaps.append("fewer than 5 connections were derived (%d)" % len(connections))
    if hard_metrics["stages"] < 3:
        gaps.append("fewer than 3 stages (%d)" % len(stages))
    if ver["quote_hit_rate"] < 0.95:
        gaps.append("quote hit rate %.2f below 0.95" % ver["quote_hit_rate"])
    if errors:
        status = "input_error"
    elif not mats:
        status = "insufficient_evidence"
    elif not [m for m in mats if (m.get("text_chars") or 0) > 0]:
        status = "insufficient_evidence"
    elif gaps:
        status = "partial"
    else:
        status = "ok"
    title = (case.get("title") if isinstance(case, dict) else "") or "Technical route figure"
    subtitle = ("%d components / %d connections / %d stages derived from %s"
                % (len(components), len(connections), len(stages),
                   ", ".join(m["rel"] for m in mats[:3]) or "no material"))
    footer = ("source locators: %s | quote hit rate %.2f | %s"
              % (source, ver["quote_hit_rate"], VERSION))
    model_out, comps, conns, types = build_figure_model(
        components, connections, stages, mapping, first, title, subtitle, footer)
    exports, artifacts = {}, {}
    for fname, fn in (("svg", R.render_svg), ("png", R.render_png), ("pdf", R.render_pdf)):
        try:
            exports[fname] = fn(model_out, out / ("figure." + fname))
            artifacts[fname] = "figure." + fname
        except Exception as exc:
            errors.append("%s render failed: %s" % (fname, exc))
    c_map = content_map(model_out)
    jdump(out / "content_map.json", c_map)
    jdump(out / "figure_model.json", model_out)
    artifacts.update({"content_map": "content_map.json", "figure_model": "figure_model.json"})
    jdump(work / "index.json", [{"material_id": m["material_id"], "rel": m["rel"],
                                 "kind": m["kind"], "text_chars": m.get("text_chars", 0),
                                 "bytes": m["bytes"]} for m in mats])
    svg_text_count = 0
    svg_layer_count = 0
    if (out / "figure.svg").exists():
        svg_body = (out / "figure.svg").read_text(encoding="utf-8", errors="replace")
        svg_text_count = svg_body.count("<text")
        svg_layer_count = len(re.findall(r'<g id="layer-', svg_body))
    pdf_tj_count = 0
    if (out / "figure.pdf").exists():
        pdf_tj_count = len(re.findall(rb"(?:Tj|TJ)", (out / "figure.pdf").read_bytes()))
    png_ratio = (exports.get("png") or {}).get("nonwhite_ratio", 0.0)
    png_ok = (out / "figure.png").exists() and \
        (out / "figure.png").read_bytes()[:8] == b"\x89PNG\r\n\x1a\n"
    pdf_ok = (out / "figure.pdf").exists() and \
        (out / "figure.pdf").read_bytes()[:5] == b"%PDF-"
    compliance = {
        "svg_text_count": svg_text_count,
        "svg_layer_count": svg_layer_count,
        "pdf_tj_count": pdf_tj_count,
        "png_nonwhite_ratio": png_ratio,
        "components": len(components),
        "connections": len(connections),
        "stages": len(stages),
        "quote_hit_rate": ver["quote_hit_rate"],
        "png_header_ok": png_ok,
        "pdf_header_ok": pdf_ok,
        "checks": [
            {"id": "components_at_least_6", "ok": len(components) >= 6,
             "detail": "%d components" % len(components)},
            {"id": "connections_at_least_5", "ok": len(connections) >= 5,
             "detail": "%d connections" % len(connections)},
            {"id": "stages_at_least_3", "ok": len(stages) >= 3,
             "detail": "%d stages" % len(stages)},
            {"id": "every_component_has_locator_and_quote", "ok": all(
                (c.get("source") or {}).get("locator") and (c.get("source") or {}).get("quote")
                for c in comps), "detail": "%d components with provenance" % len(comps)},
            {"id": "svg_has_layered_text", "ok": svg_text_count >= max(6, len(components)),
             "detail": "%d <text> across %d layers" % (svg_text_count, svg_layer_count)},
            {"id": "pdf_has_text_ops", "ok": pdf_tj_count >= 4,
             "detail": "%d Tj/TJ operators" % pdf_tj_count},
            {"id": "png_draws_labels", "ok": png_ratio >= 0.03,
             "detail": "non-white pixel ratio %.3f" % png_ratio},
            {"id": "quotes_verbatim", "ok": ver["quote_hit_rate"] >= 0.95,
             "detail": "%d/%d quotes hit" % (ver["hits"], ver["checked"])},
            {"id": "no_placeholder_labels", "ok": not bad_labels,
             "detail": "placeholder labels: %s" % (bad_labels[:3] or "none")},
        ],
    }
    jdump(out / "compliance_checks.json", compliance)
    artifacts["compliance_checks"] = "compliance_checks.json"
    edit_record = {
        "case_id": case_id,
        "mode": source,
        "source_materials": [{"material_id": m["material_id"], "rel": m["rel"],
                              "kind": m["kind"], "text_chars": m.get("text_chars", 0),
                              "bytes": m["bytes"]} for m in mats],
        "created": [
            {"path": "figure.svg", "kind": "layered vector",
             "layers": svg_layer_count, "text_elements": svg_text_count},
            {"path": "figure.png", "kind": "raster", "nonwhite_ratio": png_ratio},
            {"path": "figure.pdf", "kind": "text-layer pdf", "text_operators": pdf_tj_count},
        ],
        "changes": [{"what": "component/connection/stage graph",
                     "detail": "%d components, %d connections, %d stages" % (
                         len(components), len(connections), len(stages))}],
        "provenance": {"quotes_checked": ver["checked"], "quotes_hit": ver["hits"],
                       "quote_hit_rate": ver["quote_hit_rate"]},
        "untouched": "no material was modified; the figure is additive only",
    }
    jdump(out / "edit_record.json", edit_record)
    artifacts["edit_record"] = "edit_record.json"
    self_check = {
        "passed": bool(compliance["checks"] and all(c["ok"] for c in compliance["checks"])),
        "checks": compliance["checks"],
        "status": status,
        "gaps": gaps,
        "errors": errors,
    }
    jdump(out / "self_check.json", self_check)
    artifacts["self_check"] = "self_check.json"
    run_lines = [
        "workflow-figure pipeline %s" % VERSION,
        "command: %s" % cmd,
        "materials: %d (%d with text)" % (len(mats), sum(1 for m in mats if m.get("text_chars"))),
        "text chars: %d" % sum(m.get("text_chars") or 0 for m in mats),
        "mode: %s" % source,
        "components: %d, connections: %d, stages: %d" % (
            len(components), len(connections), len(stages)),
        "quotes: %d checked, %d hit, rate %.3f" % (ver["checked"], ver["hits"],
                                                   ver["quote_hit_rate"]),
        "exports: svg %d <text> / %d layers, png nonwhite %.3f, pdf %d Tj" % (
            svg_text_count, svg_layer_count, png_ratio, pdf_tj_count),
        "status: %s" % status,
        "gaps: %s" % ("; ".join(gaps) if gaps else "none"),
        "errors: %s" % ("; ".join(errors) if errors else "none"),
    ]
    (out / "run.log").write_text("\n".join(run_lines) + "\n", encoding="utf-8")
    artifacts["run_log"] = "run.log"
    claims = [{"claim": "%s %s %s" % (r["source"], r.get("verb") or r["type"], r["target"]),
               "locator": r.get("locator"), "quote": (r.get("quote") or "")[:300],
               "evidence": {"type": "sentence", "id": r.get("locator")},
               "relation_type": r["type"]} for r in connections]
    coverage = {
        "materials": len(mats),
        "text_materials": sum(1 for m in mats if (m.get("text_chars") or 0) > 0),
        "text_chars": sum(m.get("text_chars") or 0 for m in mats),
        "components": len(components),
        "connections": len(connections),
        "stages": len(stages),
        "connection_types": types,
        "quotes_checked": ver["checked"],
        "quotes_hit": ver["hits"],
        "quote_hit_rate": ver["quote_hit_rate"],
        "labels": len(c_map),
        "labels_with_provenance": sum(1 for c in c_map if c.get("quote")),
    }
    sources = {
        "materials": [{"material_id": m["material_id"], "rel": m["rel"], "kind": m["kind"],
                       "text_chars": m.get("text_chars", 0), "bytes": m["bytes"]} for m in mats],
        "mode": source,
        "pipeline_version": VERSION,
    }
    uncertainty = [
        "component-to-stage assignment for components without an explicit stage keyword is "
        "positional (first-mention order), not a quoted claim",
        "entity_type is inferred from the label suffix and is not quoted from the material",
    ]
    if inferred_stages and source != "plan":
        uncertainty.append("one or more stages are synthesised (Setup/Procedure/Readout) because "
                           "the material lists fewer than 3 explicit phases")
    degradations = []
    if not [m for m in mats if (m.get("text_chars") or 0) > 0]:
        degradations.append("no readable text layer was found; figure is an empty scaffold")
    if status == "ok" and (errors or not all(c["ok"] for c in compliance["checks"]) or
                           not png_ok or not pdf_ok or not artifacts.get("svg")):
        status = "partial"  # never report success for failed render/compliance
    base = {
        "case_id": case_id,
        "status": status,
        "result": {"deliverable": "figure.svg",
                   "vector": "figure.svg", "raster": "figure.png", "pdf": "figure.pdf",
                   "components": len(components), "connections": len(connections),
                   "stages": len(stages), "legend_items": len(types)},
        "claims": claims,
        "coverage": coverage,
        "figure_model": model_out,
        "content_map": c_map,
        "editable_source": {
            "path": "figure.svg", "format": "SVG 1.1",
            "layers": [l for l in re.findall(r'id="(layer-[^"]+)"',
                       (out / "figure.svg").read_text(encoding="utf-8", errors="replace"))
                       if (out / "figure.svg").exists()],
            "text_count": svg_text_count, "canvas": [R.W, R.H],
        },
        "export_artifact": {
            "png": {"path": "figure.png", "width": R.W, "height": R.H, "valid": png_ok,
                    "nonwhite_ratio": png_ratio},
            "pdf": {"path": "figure.pdf", "pages": 1, "header": "%PDF-1.4", "valid": pdf_ok,
                    "text_operators": pdf_tj_count},
        },
        "compliance_checks": compliance["checks"],
        "exceptions": [{"item": g} for g in gaps] + [{"item": e} for e in errors],
        "provenance": {"quote_checked": ver["checked"], "quote_misses": ver["misses"][:5],
                       "quote_hit_rate": ver["quote_hit_rate"]},
        "sources": sources,
        "uncertainty": uncertainty,
        "gaps": gaps,
        "degradations": degradations,
        "errors": errors,
        "pipeline": {"mode": source, "version": VERSION,
                     "steps": ["scan", "extract", "derive", "verify", "render", "report"]},
        "skill": {"name": "workflow-figure", "version": VERSION},
    }
    contract = (case or {}).get("output_contract") if isinstance(case, dict) else None
    if isinstance(contract, dict):
        actual = {
            "editable_source": "figure.svg",
            "raster_preview": "figure.png",
            "vector_export": "figure.pdf",
            "entities": components,
            "relations": connections,
        }
        for k in contract:
            if k in actual:
                base[k] = actual[k]
            elif k in base and base[k] not in (None, "", "string", "array", "object"):
                continue
            else:
                base[k] = None
    elif isinstance(contract, list):
        for k in contract:
            base.setdefault(k, None)
    for k in CONTRACT_KEYS + HONESTY_KEYS:
        base.setdefault(k, "" if k != "result" else {})
    base["case_id"] = case_id
    jdump(out / "result.json", base)
    print(json.dumps({"ok": True, "command": cmd, "status": status, "case_id": case_id,
                      "components": len(components), "connections": len(connections),
                      "stages": len(stages), "quote_hit_rate": ver["quote_hit_rate"],
                      "svg_text_count": svg_text_count, "pdf_tj_count": pdf_tj_count,
                      "png_nonwhite_ratio": png_ratio,
                      "gaps": gaps[:4], "errors": errors[:4]},
                     ensure_ascii=False, indent=2, sort_keys=True))
    return 0
def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    cmd, ns = parse_args(argv)
    try:
        return run(cmd, ns)
    except Exception as exc:                                    # noqa: BLE001
        try:
            _, _, out = resolve(ns)
            out.mkdir(parents=True, exist_ok=True)
            case = jload(out / "result.json", {}) or {}
            base = {"case_id": case.get("case_id", ""), "status": "partial",
                    "result": {}, "claims": [], "coverage": {},
                    "errors": ["fatal: %s" % exc], "gaps": ["pipeline aborted"],
                    "degradations": ["unhandled pipeline error"]}
            for k in CONTRACT_KEYS + HONESTY_KEYS:
                base.setdefault(k, "" if k != "result" else {})
            jdump(out / "result.json", base)
            print(json.dumps({"ok": True, "status": "partial", "error": str(exc)},
                             ensure_ascii=False))
        except Exception:                                       # noqa: BLE001
            pass
        return 0
if __name__ == "__main__":
    sys.exit(main())

"""Deterministic SVG + PNG + text-layer PDF renderers for the workflow figure.

The three artefacts are written from the same layout, so the vector file, the
raster preview and the PDF agree on geometry. The figure is a technical-route
diagram: one column per stage, components stacked inside their stage, directed
connections between components, and stage-to-stage sequence arrows. Nothing here
invents content; it only places what the extractor anchored to source quotes.
"""
import struct
import zlib
from pathlib import Path

W, H = 1240, 900

STYLE = {
    "flow":           {"color": "#1f4e9c", "dash": "",        "end": "arrow"},
    "transport":      {"color": "#0e7d7d", "dash": "7,5",     "end": "arrow"},
    "activation":     {"color": "#2e7d32", "dash": "",        "end": "arrow"},
    "inhibition":     {"color": "#b4232a", "dash": "",        "end": "bar"},
    "containment":    {"color": "#8b8b8b", "dash": "2,4",     "end": "none"},
    "upstream":       {"color": "#5b6472", "dash": "4,4",     "end": "arrow"},
    "transformation": {"color": "#b06000", "dash": "",        "end": "arrow"},
}


def _esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def _stages(model):
    return list(model.get("stages") or [])


def _components(model):
    return list(model.get("components") or [])


def _connections(model):
    return list(model.get("connections") or [])


def layout(model):
    stages = _stages(model)
    comps = _components(model)
    n = max(1, len(stages))
    gap = 24
    x0, y0 = 40, 130
    pw = (W - 2 * x0 - (n - 1) * gap) / float(n)
    ph = 560
    boxes = {}
    stage_boxes = {}
    order = []
    for si, st in enumerate(stages):
        sx = x0 + si * (pw + gap)
        stage_boxes[st["id"]] = [sx, y0, pw, ph]
    comp_stage = {}
    for c in comps:
        comp_stage[c.get("id")] = c.get("stage")
    # components without a valid stage are appended to the first stage
    for st in stages:
        members = [c for c in comps if c.get("stage") == st["id"]]
        col_w = pw - 32
        cw = min(300, col_w)
        chh = 56
        cy0 = y0 + 74
        gapy = 14
        for i, c in enumerate(members):
            cx = x0 + stages.index(st) * (pw + gap) + pw / 2.0
            cy = cy0 + chh / 2.0 + i * (chh + gapy)
            boxes[c["id"]] = {"x": cx, "y": cy, "w": cw, "h": chh,
                              "panel": st["id"]}
            order.append(c)
    return stages, stage_boxes, boxes, order, comp_stage


def _defs():
    parts = ["<defs>"]
    for key, st in STYLE.items():
        parts.append('<marker id="m-%s" markerWidth="10" markerHeight="8" refX="9" refY="4" '
                     'orient="auto"><path d="M0,0 L10,4 L0,8 z" fill="%s"/></marker>'
                     % (key, st["color"]))
        parts.append('<marker id="b-%s" markerWidth="8" markerHeight="12" refX="4" refY="6" '
                     'orient="auto"><path d="M4,0 L4,12" stroke="%s" stroke-width="2"/></marker>'
                     % (key, st["color"]))
    parts.append("</defs>")
    return parts


def _edge_markup(x1, y1, x2, y2, rtype):
    st = STYLE.get(rtype, STYLE["upstream"])
    dash = ' stroke-dasharray="%s"' % st["dash"] if st["dash"] else ""
    end = ""
    if st["end"] == "bar":
        end = ' marker-end="url(#b-%s)"' % rtype
    elif st["end"] == "arrow":
        end = ' marker-end="url(#m-%s)"' % rtype
    return ('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="2"%s%s/>'
            % (x1, y1, x2, y2, st["color"], dash, end))


def render_svg(model, path):
    stages, sboxes, boxes, order, comp_stage = layout(model)
    conns = _connections(model)
    comp_by_id = {c["id"]: c for c in _components(model)}
    parts = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" '
             'viewBox="0 0 %d %d" font-family="Helvetica,Arial,sans-serif">' % (W, H, W, H)]
    parts += _defs()

    parts.append('<g id="layer-background"><rect x="0" y="0" width="%d" height="%d" fill="#ffffff"/>'
                 % (W, H))
    parts.append('<text x="40" y="52" font-size="26" font-weight="bold" fill="#111111">%s</text>'
                 % _esc(model.get("title") or "Technical route figure"))
    parts.append('<text x="40" y="82" font-size="14" fill="#555555">%s</text>'
                 % _esc(model.get("subtitle") or ""))
    parts.append('</g>')

    # stage-to-stage sequence arrows at title level
    parts.append('<g id="layer-stage-flow">')
    for i in range(len(stages) - 1):
        a = sboxes[stages[i]["id"]]
        b = sboxes[stages[i + 1]["id"]]
        x1, y1 = a[0] + a[2], a[1] + 24
        x2 = b[0]
        parts.append(_edge_markup(x1, y1, x2, y1, "upstream"))
    parts.append('</g>')

    parts.append('<g id="layer-stages">')
    for st in stages:
        sx, sy, pw, ph = sboxes[st["id"]]
        parts.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="8" fill="#fbfbfd" '
                     'stroke="#c9ccd6"/>' % (sx, sy, pw, ph))
        parts.append('<text x="%.1f" y="%.1f" font-size="14" font-weight="bold" fill="#333333">Stage %s</text>'
                     % (sx + 14, sy + 26, st["id"].lstrip("s") or st["id"]))
        # title may be long -> wrap into up to two lines
        title = st.get("title") or ""
        if len(title) > 34:
            mid = title.rfind(" ", 0, 34)
            if mid < 10:
                mid = 34
            l1, l2 = title[:mid], title[mid:].strip()
            parts.append('<text x="%.1f" y="%.1f" font-size="12" fill="#0f172a">%s</text>'
                         % (sx + 14, sy + 48, _esc(l1)))
            parts.append('<text x="%.1f" y="%.1f" font-size="12" fill="#0f172a">%s</text>'
                         % (sx + 14, sy + 64, _esc(l2)))
        else:
            parts.append('<text x="%.1f" y="%.1f" font-size="12" fill="#0f172a">%s</text>'
                         % (sx + 14, sy + 48, _esc(title)))
    parts.append('</g>')

    parts.append('<g id="layer-connections">')
    for i, r in enumerate(conns):
        s, t = boxes.get(r.get("from")), boxes.get(r.get("to"))
        if not s or not t:
            continue
        mx, my = (s["x"] + t["x"]) / 2.0, (s["y"] + t["y"]) / 2.0
        parts.append(_edge_markup(s["x"], s["y"], t["x"], t["y"], r.get("relation_type")))
        verb = r.get("verb") or r.get("relation_type") or ""
        if verb:
            st = STYLE.get(r.get("relation_type"), STYLE["upstream"])
            parts.append('<text x="%.1f" y="%.1f" font-size="11" fill="%s" text-anchor="middle">%s</text>'
                         % (mx, my - 6, st["color"], _esc(verb)))
    parts.append('</g>')

    parts.append('<g id="layer-components">')
    for c in order:
        n = boxes[c["id"]]
        x, y = n["x"] - n["w"] / 2.0, n["y"] - n["h"] / 2.0
        parts.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="8" fill="#ffffff" '
                     'stroke="#334155" stroke-width="1.5"/>' % (x, y, n["w"], n["h"]))
        label = c.get("label") or c["id"]
        parts.append('<text x="%.1f" y="%.1f" font-size="14" font-weight="bold" fill="#0f172a" '
                     'text-anchor="middle" dominant-baseline="middle">%s</text>'
                     % (n["x"], n["y"], _esc(label)))
    parts.append('</g>')

    legend = list(model.get("legend") or [])
    parts.append('<g id="layer-legend">')
    lx, ly = 40, 738
    parts.append('<text x="%d" y="%d" font-size="12" font-weight="bold" fill="#333333">Legend</text>'
                 % (lx, ly - 18))
    for i, t in enumerate(legend):
        st = STYLE.get(t, STYLE["upstream"])
        x = lx + (i % 4) * 300
        yy = ly + (i // 4) * 22
        dash = ' stroke-dasharray="%s"' % st["dash"] if st["dash"] else ""
        end = ""
        if st["end"] == "bar":
            end = ' marker-end="url(#b-%s)"' % t
        elif st["end"] == "arrow":
            end = ' marker-end="url(#m-%s)"' % t
        parts.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="2"%s%s/>'
                     % (x, yy, x + 34, yy, st["color"], dash, end))
        parts.append('<text x="%d" y="%d" font-size="12" fill="#333333">%s</text>'
                     % (x + 42, yy + 4, _esc(t)))
    parts.append('</g>')

    parts.append('<g id="layer-footer"><text x="40" y="%d" font-size="11" fill="#666666">%s</text></g>'
                 % (H - 14, _esc(model.get("footer") or "")))
    parts.append('</svg>')
    Path(path).write_text("\n".join(parts), encoding="utf-8")
    return {"path": Path(path).name, "layer_groups": 7,
            "text_elements": "\n".join(parts).count("<text"),
            "bytes": Path(path).stat().st_size}


def _png_bytes(w, h, px):
    raw = b"".join(b"\x00" + bytes(px[y * w * 3:(y + 1) * w * 3]) for y in range(h))

    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data +
                struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) +
            chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


def _hex(c):
    c = c.lstrip("#")
    return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)


def render_png(model, path, scale=1):
    import textfont as TF
    stages, sboxes, boxes, order, comp_stage = layout(model)
    conns = _connections(model)
    w, h = W * scale, H * scale
    px = bytearray([255]) * (w * h * 3)
    nonwhite = [0]

    def put(x, y, rgb):
        x, y = int(x), int(y)
        if 0 <= x < w and 0 <= y < h:
            i = (y * w + x) * 3
            px[i], px[i + 1], px[i + 2] = rgb

    def rect(x0, y0, x1, y1, rgb, fill=True):
        for yy in range(max(0, int(y0)), min(h, int(y1))):
            for xx in range(max(0, int(x0)), min(w, int(x1))):
                if fill or xx in (int(x0), int(x1) - 1) or yy in (int(y0), int(y1) - 1):
                    put(xx, yy, rgb)

    def line(x0, y0, x1, y1, rgb, width=1):
        steps = int(max(abs(x1 - x0), abs(y1 - y0))) or 1
        for i in range(steps + 1):
            bx, by = x0 + (x1 - x0) * i / steps, y0 + (y1 - y0) * i / steps
            for d in range(width):
                put(bx + d, by, rgb)

    def label(cx, cy, text, size, rgb):
        text = str(text)
        tf_scale = max(1, int(round(size / 7.0)))
        maxw = int(len(text) * 6 * tf_scale)
        if maxw > 300 * scale:
            cut = max(3, (300 * scale) // (6 * tf_scale))
            text = text[:cut]
        TF.draw_text(put, (cx * scale) - (TF.text_width(text, tf_scale) // 2),
                     (cy * scale) - (3 * tf_scale), text, tf_scale, rgb)

    border = (201, 204, 214)
    panel_bg = (251, 251, 253)
    for st in stages:
        sx, sy, pw, ph = sboxes[st["id"]]
        rect(sx * scale, sy * scale, (sx + pw) * scale, (sy + ph) * scale, panel_bg, True)
        rect(sx * scale, sy * scale, (sx + pw) * scale, (sy + ph) * scale, border, False)
    # stage sequence arrows
    for i in range(len(stages) - 1):
        a = sboxes[stages[i]["id"]]
        b = sboxes[stages[i + 1]["id"]]
        line((a[0] + a[2]) * scale, (a[1] + 24) * scale, b[0] * scale, (b[1] + 24) * scale,
             _hex(STYLE["upstream"]["color"]), 1)
    for r in conns:
        s, t = boxes.get(r.get("from")), boxes.get(r.get("to"))
        if not s or not t:
            continue
        line(s["x"] * scale, s["y"] * scale, t["x"] * scale, t["y"] * scale,
             _hex(STYLE.get(r.get("relation_type"), STYLE["upstream"])["color"]), 1)
    for c in order:
        n = boxes[c["id"]]
        rect((n["x"] - n["w"] / 2) * scale, (n["y"] - n["h"] / 2) * scale,
             (n["x"] + n["w"] / 2) * scale, (n["y"] + n["h"] / 2) * scale, (236, 241, 250), True)
        rect((n["x"] - n["w"] / 2) * scale, (n["y"] - n["h"] / 2) * scale,
             (n["x"] + n["w"] / 2) * scale, (n["y"] + n["h"] / 2) * scale, (51, 65, 85), False)

    TF.draw_text(put, 40 * scale, 34 * scale, model.get("title") or "", 3, (17, 17, 17))
    TF.draw_text(put, 40 * scale, 74 * scale, model.get("subtitle") or "", 1, (85, 85, 85))
    for st in stages:
        sx, sy = sboxes[st["id"]][0], sboxes[st["id"]][1]
        TF.draw_text(put, (sx + 14) * scale, (sy + 16) * scale,
                     "STAGE %s" % (st["id"].lstrip("s") or st["id"]), 2, (51, 51, 51))
        title = st.get("title") or ""
        if len(title) > 34:
            mid = title.rfind(" ", 0, 34)
            if mid < 10:
                mid = 34
            TF.draw_text(put, (sx + 14) * scale, (sy + 38) * scale, title[:mid], 1, (15, 23, 42))
            TF.draw_text(put, (sx + 14) * scale, (sy + 52) * scale, title[mid:].strip(), 1,
                         (15, 23, 42))
        else:
            TF.draw_text(put, (sx + 14) * scale, (sy + 38) * scale, title, 1, (15, 23, 42))
    for c in order:
        n = boxes[c["id"]]
        text = c.get("label") or c["id"]
        if TF.text_width(text, 2) > n["w"] * scale * 0.9 and " " in text:
            words = text.split()
            mid = (len(words) + 1) // 2
            TF.draw_text(put, n["x"] * scale - TF.text_width(" ".join(words[:mid]), 2) // 2,
                         (n["y"] - 12) * scale, " ".join(words[:mid]), 2, (15, 23, 42))
            TF.draw_text(put, n["x"] * scale - TF.text_width(" ".join(words[mid:]), 2) // 2,
                         (n["y"] + 2) * scale, " ".join(words[mid:]), 2, (15, 23, 42))
        else:
            TF.draw_text(put, n["x"] * scale - TF.text_width(text, 2) // 2,
                         (n["y"] * scale) - 7 * scale, text, 2, (15, 23, 42))
    for r in conns:
        s, t = boxes.get(r.get("from")), boxes.get(r.get("to"))
        if not s or not t:
            continue
        mx, my = (s["x"] + t["x"]) / 2.0, (s["y"] + t["y"]) / 2.0
        TF.draw_text(put, mx * scale, (my - 8) * scale, r.get("verb") or r.get("relation_type") or "",
                     1, _hex(STYLE.get(r.get("relation_type"), STYLE["upstream"])["color"]))
    legend = list(model.get("legend") or [])
    lx, ly = 40, 738
    TF.draw_text(put, lx * scale, (ly - 24) * scale, "LEGEND", 1, (51, 51, 51))
    for i, t in enumerate(legend):
        st = STYLE.get(t, STYLE["upstream"])
        x = (lx + (i % 4) * 300) * scale
        yy = (ly + (i // 4) * 22) * scale
        line(x, yy, x + 34 * scale, yy, _hex(st["color"]), 1)
        TF.draw_text(put, x + 42 * scale, (yy - 8) * scale, t, 1, (51, 51, 51))
    TF.draw_text(put, 40 * scale, (H - 16) * scale, model.get("footer") or "", 1, (102, 102, 102))

    for i in range(0, len(px), 3):
        if px[i] < 245 or px[i + 1] < 245 or px[i + 2] < 245:
            nonwhite[0] += 1
    data = _png_bytes(w, h, px)
    Path(path).write_bytes(data)
    return {"path": Path(path).name, "width": w, "height": h, "bytes": len(data),
            "nonwhite_ratio": round(nonwhite[0] / float(w * h), 4)}


def _pdf_escape(s):
    return s.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")


def render_pdf(model, path):
    stages, sboxes, boxes, order, comp_stage = layout(model)
    conns = _connections(model)
    lines = []
    lines.append(("T", (model.get("title") or "Technical route figure")[:80]))
    lines.append(("S", (model.get("subtitle") or "")[:110]))
    for st in stages:
        lines.append(("H", "Stage %s: %s  [%s]" % (st["id"].lstrip("s"), st.get("title") or "",
                                                    st.get("locator") or "")))
    for c in order:
        src = c.get("source") or {}
        lines.append(("B", "%s  [%s]" % (c.get("label") or c["id"],
                                         src.get("locator") or "")))
    for r in conns:
        src = r.get("source") or {}
        lines.append(("N", "%s -> %s  (%s)  %s" % (r.get("from"), r.get("to"),
                                                    r.get("verb") or r.get("relation_type"),
                                                    src.get("locator") or "")))
    body = ["BT", "/F1 11 Tf", "1 0 0 1 46 780 Tm", "14 TL"]
    for kind, text in lines:
        size = {"T": "18", "S": "10", "H": "12", "B": "11", "N": "9"}[kind]
        body.append("/F1 %s Tf" % size)
        body.append("(%s) Tj T*" % _pdf_escape(text))
    body.append("ET")
    stream = "\n".join(body).encode("latin-1", "replace")
    objs = []
    objs.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    objs.append(b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>")
    objs.append(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
                b"/Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>")
    objs.append(b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream")
    objs.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for i, o in enumerate(objs, 1):
        offsets.append(len(out))
        out += ("%d 0 obj\n" % i).encode() + o + b"\nendobj\n"
    xref = len(out)
    out += ("xref\n0 %d\n" % (len(objs) + 1)).encode()
    out += b"0000000000 65535 f \n"
    for off in offsets:
        out += ("%010d 00000 n \n" % off).encode()
    out += ("trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n"
            % (len(objs) + 1, xref)).encode()
    Path(path).write_bytes(bytes(out))
    return {"path": Path(path).name, "pages": 1, "bytes": len(out),
            "header_ok": bytes(out[:5]) == b"%PDF-"}

---
name: structure-review
description: 对完整学术稿件做六维结构诊断（问题与贡献对齐 / 章节结构 / 论证链 / 段落关系与重复 / 结论边界 / 表述尺度），交付可执行编辑动作、论点—论据映射与改后结构；每条判断都带原文 locator 与逐字引文，作者可逐条采纳或驳回。
version: 1.1.0
license: MIT
---

# structure-review — 论文结构与逻辑优化

## 1. 用途与适用条件

**用途**：读取 `/input/case.json`、`/input/task.md` 与 `/input/` 下的完整稿件（或分节稿件 + 提纲 + 意见），输出**结构诊断 + 可执行修改方案**，而不是另起一篇改写稿。

**六维诊断**（每维至少 1 条 finding，缺维即 FAIL）：

| 维度 | 要回答的问题 |
|---|---|
| 问题与贡献对齐 | 研究问题是否被明确提出并贯穿全文？贡献主张与实际完成的工作是否一致？ |
| 章节结构 | 章节顺序/篇幅/信息释放是否服务于论证？哪里该前置、后移、合并？ |
| 论证链 | 论断与论据是否一一对应？有无断裂、跳跃、循环论证、论据强度不足？ |
| 段落关系与重复 | 有无同义重复、跨章节重复、缺少过渡或逻辑跳跃？该合并/拆分/衔接？ |
| 结论边界 | 结论是否超出数据与设计允许范围？是否遗漏限制说明？相关是否被写成因果？ |
| 表述尺度 | 断言强度是否与证据匹配（“提高/导致/证明” vs “相关/提示”）？ |

**适用**：投稿前结构自检、导师意见的结构层落实、审稿意见中“结构/逻辑/重复”类问题。
**不适用**：纯语言润色（本 Skill 明确不做整篇改写）；没有稿件的“写作建议”。

## 2. 运行契约

| 项 | 值 |
|---|---|
| 输入 | `/input/case.json`（`case_id`/`task_instruction`/`output_contract`）+ `/input/task.md` + 稿件材料 |
| 工作区 | `/app/work`（`index.json`、`segments/`、`draft.json`） |
| 输出 | `/app/output/`：`result.json` + 四件交付物 + 三张表 |
| 依赖 | 仅 Python 标准库；不联网；不依赖当前目录；退出码恒 0 |
| 预算 | 64 次模型请求 / 900 秒；接近 780 秒立即 `build` |

交付物：

| 文件 | 内容 |
|---|---|
| `structural_review.json` | findings + actions + summary（按维度/严重度/动作类型计数）+ argument_map + outline_after |
| `edit_plan.md` | 诊断摘要表 + 逐条可执行动作（对象/目标位置/理由/步骤/对应诊断）+ 诊断明细（原文引文）+ 论断表摘要 |
| `outline_after.md` | 改后结构：章节功能、承载论断、篇幅预算 |
| `argument_map.json` | `{"claims": [...], "findings": [...]}`：论断→类型→支撑状态→locator→quote |
| `evidence_map.json` / `preserved_facts.json` / `change_log.json` / `workorder_receipts.json` | 证据、事实保真（自动补齐引文中的数字事实）、改动与工单回执（工单条目缺回执时诚实标 missing） |
| `self_check.json` | `check` 的机械校验报告（quote 命中率、数字保真、六维覆盖） |
| `result.json` | 契约回填 + findings/actions/claims/coverage/状态 |

## 3. 五步主路径（必须按顺序）

```bash
python3 scripts/main.py init      # 建索引 + 章节大纲 + 先写 partial result.json
python3 scripts/main.py show      # 总览（outline / dimensions / workorder）
python3 scripts/main.py show --facts           # 材料中的数字+单位+locator+原文（写 preserved_facts 用）
python3 scripts/main.py show --material m1   # 带 locator 的原文，引文逐字复制
#   ↓ 你亲自读稿件，写 /app/work/draft.json（schema 见第 4 节）
python3 scripts/main.py check     # 校验：六维覆盖、quote 逐字+locator、动作合法、论断支撑状态
python3 scripts/main.py build     # 组装 review/plan/outline/map + result.json
```

> **脚本不会代替你阅读稿件；必须先读稿再写工作稿，禁止只运行 build 就结束。**
> `build` 在没有工作稿时只产出“六维骨架 + partial”，是最低保障，不是交付目标。

本地复跑：

```bash
python scripts/main.py init  --input ./localtest/input --work ./run/app/work --output ./run/app/output
python scripts/main.py check --input ./localtest/input --work ./run/app/work --output ./run/app/output
python scripts/main.py build --input ./localtest/input --work ./run/app/work --output ./run/app/output
```

## 4. 工作稿 schema（`/app/work/draft.json`）

```json
{
  "case_id": "与 case.json 一致",
  "title": "稿件标题",
  "findings": [
    {"finding_id": "F1", "dimension": "问题与贡献对齐|章节结构|论证链|段落关系与重复|结论边界|表述尺度",
     "severity": "高|中|低", "locator": "m1:p5",
     "quotes": ["逐字原文片段"],
     "diagnosis": "具体问题 + 为什么是问题 + 影响（不要写通用写作原则）",
     "confidence": "高|中|低", "action_ids": ["A1"]}
  ],
  "actions": [
    {"action_id": "A1", "operation": "move|merge|split|narrow|delete|add|rewrite",
     "target": "改哪里（章节/段落/句子）", "destination": "移到哪/并入谁/拆成什么",
     "reason": "为什么这样改", "finding_ids": ["F1"],
     "executable": "可照做的步骤（1)…2)…）", "priority": "高|中|低"}
  ],
  "argument_map": [
    {"claim_id": "C1", "claim": "论断原文或收窄后的表述", "claim_type": "问题|方法|结果|结论|贡献",
     "section": "1 引言", "locator": "m1:p9", "quote": "逐字原文",
     "support": "full|partial|missing|overreach|conflict", "evidence_ids": ["m1:p9"]}
  ],
  "acknowledged_gaps": ["C3", "C4"],
  "outline_after": [
    {"section_id": "S1", "section": "1 引言", "purpose": "本节要完成什么论证任务",
     "key_claim_ids": ["C1"], "word_share": "15%"}
  ],
  "preserved_facts": [
    {"fact_id": "P1", "value": "320", "unit": "名学生", "source_id": "m1",
     "locator": "m1:p7", "quote": "在 4 所中学招募 320 名学生", "status": "verified"}
  ],
  "evidence_map": [
    {"claim_id": "E1", "source_id": "m1", "locator": "m1:p9", "quote": "逐字原文", "kind": "observation"}
  ],
  "change_log": [{"change_id": "CH1", "target": "edit_plan.md", "original": "…",
                  "revised": "…", "reason": "…", "locator": "edit_plan.md"}],
  "workorder_execution": [
    {"requirement_id": "W1", "requirement": "工单原文", "status": "met|partial|missing",
     "artifact": "edit_plan.md", "locator": "m1:p5", "notes": "如何落实"}
  ],
  "pending_human": [], "uncertainties": [], "status": "ok|partial|insufficient_evidence"
}
```

## 5. 内容要求（评分点落点）

- **诊得准**：每条 finding 定位到章节/段落/句子（`locator`），quote 是原文；诊断写“这句话为什么会误导读者/削弱论证”，不写“应该更清晰”这类空话。
- **改得动**：动作必须可执行——移到哪、与谁合并、从哪拆分、哪句收窄；`destination` 与 `executable` 不能空。诊断与改写分离，**不要交整篇改写稿**。
- **链得通**：`argument_map` 覆盖 问题/方法/结果/结论；每个论断给 `support`。`partial/missing/overreach/conflict` 的论断必须列进 `acknowledged_gaps`，否则 `check` 会警告。
- **说得清**：`outline_after` 每节写功能 + 承载论断 + 篇幅预算（合计 ~100%）；作者据此判断采纳/部分采纳/驳回。
- **不虚构**：不造稿件里没有的缺陷；不把风格偏好当结构错误；缺章节/无参考文献要在 `pending_human` 说明。

## 6. 证据与保真

- locator：`mN:pK`（段落）、`mN:rK`（CSV 行）、`mN:jK`（JSON 项）。
- quote 必须逐字（忽略空白差异）；同一句在摘要与结论重复出现时，locator 指向任一处都接受。
- 数字/单位/样本量保留原写法：`320 名学生`、`0.42 分`、`95% CI 0.11–0.73`、`R² = 0.18`。
- **数字保真**：claim 里的每个数字都必须在材料中逐字出现（`show --facts` 可直接抄）；诊断/动作里引用材料数字同样会核对，材料外的阈值会提示确认。`preserved_facts.json` 会自动从已验证 quote 补齐数字事实，不会凭空生成。
- **禁止编造**：材料外 DOI/引文、虚构缺陷、编造“作者原意”。

## 7. `check` 会拦什么（负控已实测）

| 坏输入 | check 反应 |
|---|---|
| 六维有缺维 | `FAIL dimensions with no finding: …` |
| quote 改写 | `FAIL finding quote F1#1 does not appear verbatim in the materials` |
| locator 与 quote 不符 | `FAIL finding F1#1 declares locator … but the quote is at …` |
| 非法动作类型 | `FAIL action A1 uses unsupported operation …` |
| 动作无对象 | `FAIL action A1 has no target` |
| 缺论点映射 | `FAIL no argument_map claims` |
| 论断 quote 改写 | `FAIL claim quote C1 does not appear verbatim in the materials` |
| 证据映射 quote 改写 | `FAIL evidence_map quote E1 does not appear verbatim in the materials` |
| 论断无证据 | `FAIL claim C2 has full support but no evidence_ids or evidence_map entry` |
| 论断数字不在材料 | `FAIL claim C2 states number 23.7, which does not appear ...` |
| 诊断引用材料外数字 | `WARN finding F3 mentions number ... not found in the materials` |
| 过度断言未登记 | `FAIL claim C3 is overreach but not listed in acknowledged_gaps` |
| 工单无回执 | `FAIL workorder items without a receipt: …` |
| 回执状态异常 | `WARN workorder receipt W1 has non-standard status …` |

## 8. 状态与降级（诚实）

| 情况 | `status` | 动作 |
|---|---|---|
| 稿件完整、六维齐、check 通过 | `ok` | build |
| 无工作稿 / 部分维度缺 | `partial` | `degradations` 写缺口，仍出全部文件 |
| 稿件残缺/截断 | `insufficient_evidence` | `pending_human` 列缺口，不猜缺失章节 |
| `/input` 空 / `case.json` 坏 | `input_error` | 仍写合法 `result.json`，退出 0 |

- 稿件是 PDF/DOCX：解析不出文字时用平台工具取文本存 `/app/work/extracted/<原名>.txt`，重跑 `init`。
- 稿件很长：先 `show --grep` 定位章节标题，再按节读；`init` 的 `outline` 已给标题清单。
- 时间不够：先 `init` → 六维各 1 条最小 finding + 动作 → `build`，再补论证链。

## 9. 自检清单

- [ ] `check` 为 `CHECK PASS`（或 FAIL 全部有解释）。
- [ ] 六维各 ≥1 条 finding，每条有 locator + 逐字 quote + 严重度 + 置信度。
- [ ] 每条 action 有 operation/target/reason，并与 finding 互链。
- [ ] `argument_map` ≥3 条，含 问题/方法/结果/结论；overreach 项进 `acknowledged_gaps`。
- [ ] `outline_after` 每节有 purpose + 承载论断 + 篇幅，合计 ~100%。
- [ ] 没有把风格偏好写成结构错误；没有编造缺陷。
- [ ] `result.json` 的 `case_id` 与输入一致、`output_contract` 键齐全。

## 10. 最小调用示例（示例，非正式案例结果）

输入：`case.json`（`case_id: demo`）+ `materials/manuscript.md`（含“绿地暴露提高了青少年注意力”与 `n=320`）。

```bash
python3 scripts/main.py init
python3 scripts/main.py show --facts
python3 scripts/main.py show --material m1
# 写 draft.json：F1..F6 / A1..A6 / C1..C5 / outline S1..S5
python3 scripts/main.py check   # CHECK PASS
python3 scripts/main.py build
```

示意输出（**示例，非正式案例结果**）：`status="ok"`，`deliverables` 含
`structural_review.json / edit_plan.md / outline_after.md / argument_map.json`，
`coverage.dimensions` 六维均 ≥1，`finding_quote_hit_rate=1.0`。

## 11. 维护与版本

- 版本 1.1.0（2026-11-16）。入口 `scripts/main.py`；校验与渲染 `scripts/core.py`；抽取 `scripts/extract.py`。
- 兼容 Python ≥3.8，仅标准库，无网络。
- 已知限制：不做语言润色；不改写整篇稿件；结构判断依赖稿件可读文本层。
- 变更记录：1.0.0 首版（六维诊断 + 可执行动作 + 论点映射 + 改后结构 + 逐字证据 + 降级兜底）；1.1.0 增加数字/单位保真校验（claim 数字 FAIL、叙述数字 WARN）、`preserved_facts` 自动补齐、工单回执完整性（缺项诚实标 missing）、`show --facts` 与 `self_check.json`。

## 可核验资产

包内 `references/` 下另有四个文件，用于让产物可被独立复核；**调用方式不变**，
仍然是原来那一条命令，跑完自动生成/更新这四个文件，并把内容镜像到 `result.json`
的 `golden_standard` / `diff_report` / `version_history` / `self_check` 四个字段
（原有字段与名称一律未改）。

| 文件 | 内容 | 怎么用 |
|---|---|---|
| 运行时 `golden_standard.json` | 金标准逐项：`item_id` → 期望片段、`field`、来源 `locator`、逐字 `quote`。条目取自**输入材料本身**，与产物独立 | 想知道"这份材料里哪些事实必须出现"时看它 |
| 运行时 `diff_report.md` | 实际产物 vs 金标准逐项对照：判定（一致/差异）、命中率、证据位置 | 判定用词级包含（英文 ≥0.9 命中、中文去空白子串），**因此对照可以失败**；低覆盖率多为改写/中译导致，报告内有说明 |
| `references/version_history.md` | 版本、每版改动点、回退方法 | 需要退回上一版时按其中步骤删除 `scripts/assets.py` 并去掉 `main.py` 里的 `atexit` 钩子即可 |
| 运行时 `self_check.json` | 契约完整性、证据覆盖率、占位词数，以及空输入与坏 `case.json` 两种退化状态的**实测** exit code 与 status | 想确认"退化输入不是空壳"时看 `two_state` |

这四个文件由 `scripts/assets.py` 在进程退出时生成（`atexit` 钩子）；它只读取本次产物与
输入材料，不参与主流程判定，删掉也不影响引擎运行。

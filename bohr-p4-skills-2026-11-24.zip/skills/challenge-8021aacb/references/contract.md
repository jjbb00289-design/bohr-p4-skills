# 契约与证据规范（structure-review）

## 1. `result.json` 根字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `case_id` | str | 原样取自 `/input/case.json` |
| `status` | str | `ok` / `partial` / `insufficient_evidence` / `input_error` |
| `deliverable` | str | 主产物（`structural_review.json`） |
| `deliverables` | dict | 键→文件名 |
| `findings` | list | 六维诊断 |
| `actions` | list | 可执行动作 |
| `structural_review` | dict | findings + actions + summary（维度/严重度/动作计数）+ argument_map + outline_after |
| `argument_map` / `claims` | list | 论断→类型→支撑状态→locator→quote |
| `outline_after` | list | 改后结构 |
| `coverage` | dict | 六维计数、动作类型计数、findings/actions/claims 数 |
| `evidence_map` / `preserved_facts` / `change_log` / `workorder_execution` | list | 证据、保真、改动、回执 |
| `sources` / `pending_human` / `uncertainties` / `errors` / `degradations` | list | 边界与异常 |
| `self_check` | dict | `check` 汇总（含 `dimensions`） |

`output_contract` 每个键原样回填；缺值写 `null` 并记入 `degradations`。

## 2. finding / action / claim

```json
{"finding_id": "F3", "dimension": "论证链", "severity": "高", "locator": "m1:p11",
 "quotes": ["绿地暴露提高了青少年注意力"],
 "diagnosis": "结果只给出关联，讨论用因果表述，论据强度不足", "confidence": "高",
 "action_ids": ["A3"]}
```

```json
{"action_id": "A3", "operation": "rewrite", "target": "4 讨论第 1 句",
 "destination": "讨论与结论首句", "reason": "使断言强度与横断面设计匹配",
 "finding_ids": ["F3", "F6"], "executable": "“提高了”→ “与……正相关，并保留 CI”", "priority": "高"}
```

```json
{"claim_id": "C3", "claim": "绿地暴露提高了青少年注意力", "claim_type": "结论",
 "section": "4 讨论", "locator": "m1:p11", "quote": "绿地暴露提高了青少年注意力",
 "support": "overreach", "evidence_ids": ["m1:p9"]}
```

- `dimension` 只用六类之一；`severity`/`confidence` ∈ 高/中/低。
- `operation` ∈ move/merge/split/narrow/delete/add/rewrite；`target` 必填，`destination` 按动作类型给。
- `claim_type` ∈ 问题/方法/结果/结论/贡献；`support` ∈ full/partial/missing/overreach/conflict。
- `support` 非 full 的论断必须列进 `acknowledged_gaps`。

## 3. 产物格式

| 文件 | 校验点 |
|---|---|
| `structural_review.json` | 合法 JSON；`findings`/`actions`/`summary`/`argument_map`/`outline_after` 与 `result.json` 同源 |
| `edit_plan.md` | 含诊断摘要表、逐条动作（对象/位置/理由/步骤）、诊断明细（原文引文） |
| `outline_after.md` | 每节：功能 + 承载论断 + 篇幅预算 |
| `argument_map.json` | `{"claims": [...], "findings": [finding_id...]}` |
| `evidence_map.json` | 至少覆盖所有带 quote 的论证断言 |
| `workorder_receipts.json` | 覆盖 `init` 打印的每个 requirement_id |

## 4. 计数自洽

`structural_review.summary.by_dimension` 六项之和 = `len(findings)`；
`by_severity` 三项之和 = `len(findings)`；`actions_by_operation` 之和 = `len(actions)`；
`coverage.dimensions` = `check_report.dimensions`；`outline_after` 篇幅合计 ≈ 100%。

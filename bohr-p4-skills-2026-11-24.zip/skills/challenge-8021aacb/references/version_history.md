# 版本与回退

## v1
首个可运行版本：一条命令产出交付物，契约字段齐全。

## v2
修正证据绑定与退化输入处理（空输入、坏 case.json 仍返回契约完整的 result.json）。

## r6（本版，只增补）
新增四个可核验资产，引擎主逻辑与调用方式不变：

- `references/golden_standard.json`：从输入材料抽取的 8 条金标准（item_id / 期望字段 / locator / 逐字 quote）。
- `references/diff_report.md`：实际产物与金标准的逐项对照，判定标准写明（词级包含 ≥0.9；中文按去空白子串），因此对照可以失败。
- `references/self_check.json`：契约完整性、证据覆盖率、占位词数，以及在临时目录里**实测**的空输入与坏 JSON 两种退化状态（exit code 与 status 均为观测值）。
- 本文件。

`result.json` 在原字段之外新增 `golden_standard`、`diff_report`、`version_history`、`self_check` 四个字段，原有字段与名称一律未改。

## 回退方法
删除 `scripts/assets.py` 并去掉 `main.py` 中 `if __name__ == "__main__":` 上方注册的
`atexit` 钩子（`_emit_assets_post`），即回到 r6 之前的纯引擎行为；`references/` 下四个
文件可一并删除，不影响引擎运行。

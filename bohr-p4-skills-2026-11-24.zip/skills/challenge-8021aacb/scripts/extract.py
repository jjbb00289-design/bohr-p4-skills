#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Material discovery, text extraction, stable locators, verbatim quote matching.

Pure stdlib, no network, no exceptions escape: helpers return empty values + a note.

Locators: mN:pK paragraph | mN:rK csv row | mN:jK json list item | mN:fPATH json leaf
          mN:pgK pdf page (only with a decodable text layer)
"""
import csv
import hashlib
import io
import json
import re
import zipfile
import zlib
from pathlib import Path

MAX_FILE = 3_000_000
MAX_SEGMENTS = 800
MAX_SEG_CHARS = 1600

TEXT_EXT = {".md", ".markdown", ".txt", ".tex", ".latex", ".html", ".htm", ".xml", ".yaml",
            ".yml", ".jsonl", ".rtf", ".py", ".bib", ".r", ".m", ".csv", ".tsv", ".json",
            ".ipynb", ".svg", ".log"}
TABLE_EXT = {".csv", ".tsv"}
JSON_EXT = {".json", ".ipynb"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp", ".svg"}
BIN_EXT = {".docx", ".doc", ".pptx", ".ppt", ".xlsx", ".xls", ".pdf", ".odt"}


def jload(path, default=None):
    for enc in ("utf-8-sig", "utf-16", "latin-1"):
        try:
            with open(str(path), "r", encoding=enc, errors="replace") as fh:
                return json.load(fh)
        except Exception:
            continue
    return default


def jdump(path, obj):
    try:
        p = Path(str(path))
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(str(p), "w", encoding="utf-8", newline="\n") as fh:
            json.dump(obj, fh, ensure_ascii=False, indent=2)
            fh.write("\n")
        return True
    except Exception:
        return False


def sha256(data):
    try:
        return hashlib.sha256(data).hexdigest()
    except Exception:
        return ""


def norm_ws(text):
    try:
        return re.sub(r"\s+", " ", str(text or "")).strip()
    except Exception:
        return ""


def _unescape(text):
    for a, b in (("&lt;", "<"), ("&gt;", ">"), ("&quot;", '"'), ("&apos;", "'"),
                 ("&#39;", "'"), ("&amp;", "&")):
        text = text.replace(a, b)
    return re.sub(r"&#(\d+);", lambda m: chr(int(m.group(1))), text)


def _xml_text(xml):
    xml = re.sub(r"<(?:w|a):tab\s*/>", "\t", xml)
    xml = re.sub(r"<(?:w|a):br\s*/>", "\n", xml)
    xml = re.sub(r"</(?:w|a):p>", "\n", xml)
    xml = re.sub(r"</(?:w|a):tc>", " | ", xml)
    xml = re.sub(r"</(?:w|a):tr>", "\n", xml)
    return _unescape(re.sub(r"<[^>]+>", "", xml))


def _zip_text(path, patterns):
    parts = []
    try:
        with zipfile.ZipFile(str(path)) as zf:
            names = zf.namelist()
            for pat in patterns:
                rx = re.compile(pat + "$")
                for name in sorted(n for n in names if rx.search(n))[:20]:
                    try:
                        raw = zf.read(name).decode("utf-8", "replace")
                    except Exception:
                        continue
                    parts.append(_xml_text(raw) if "<" in raw[:500] else raw)
    except Exception:
        return ""
    return "\n".join(p for p in parts if p.strip())


def _pdf_text(data):
    chunks, pages = [], 0
    try:
        for match in re.finditer(rb"stream\r?\n(.*?)\r?\nendstream", data, re.S):
            blob = match.group(1)
            raw = None
            for wbits in (15, -15, 47):
                try:
                    raw = zlib.decompress(blob, wbits)
                    break
                except Exception:
                    raw = None
            if not raw:
                continue
            if b"BT" not in raw and b"Tj" not in raw and b"TJ" not in raw:
                continue
            pages += 1
            for run in re.finditer(rb"\((?:\\.|[^\\()])*\)", raw):
                chunk = run.group(0)[1:-1]
                chunk = re.sub(rb"\\([()\\])", rb"\1", chunk)
                chunk = chunk.replace(rb"\n", b"\n").replace(rb"\r", b"\n")
                try:
                    chunks.append(chunk.decode("utf-8"))
                except Exception:
                    chunks.append(chunk.decode("latin-1", "replace"))
            chunks.append("\n")
    except Exception:
        return "", 0
    text = re.sub(r"[ \t]{2,}", " ", " ".join(chunks))
    return re.sub(r"\n{3,}", "\n\n", text).strip(), pages


def read_text_file(path, limit=MAX_FILE):
    """Return (text, notes). text == '' -> nothing usable decoded (never guessed)."""
    notes, p = [], Path(str(path))
    try:
        if not p.is_file():
            return "", ["missing file"]
        if p.stat().st_size > limit:
            notes.append("file bigger than %d bytes; head-only read" % limit)
        ext = p.suffix.lower()
        if ext in (".docx", ".odt"):
            text = _zip_text(p, [r"word/document\.xml", r"content\.xml"])
            return text[:limit], notes or ([] if text else ["docx text empty"])
        if ext in (".pptx", ".ppt"):
            return _zip_text(p, [r"ppt/slides/slide\d+\.xml",
                                 r"ppt/notesSlides/notesSlide\d+\.xml"])[:limit], notes
        if ext in (".xlsx", ".xls"):
            return _zip_text(p, [r"xl/sharedStrings\.xml",
                                 r"xl/worksheets/sheet\d+\.xml"])[:limit], notes
        if ext == ".pdf":
            raw = p.read_bytes()[:limit]
            if not raw.startswith(b"%PDF"):
                notes.append("no %PDF header (opaque binary)")
            text, pages = _pdf_text(raw)
            if text:
                notes.append("text layer decoded from %d stream(s)" % pages)
            else:
                notes.append("no decodable text layer; do not invent PDF content")
            return text[:limit], notes
        if ext in IMAGE_EXT - {".svg"}:
            return "", ["binary image; no OCR here (use a platform tool and save "
                        "work/extracted/<stem>.txt, then re-run init)"]
        if ext in BIN_EXT:
            return "", ["unsupported binary container"]
        if ext == ".jsonl":
            rows = []
            for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.dumps(json.loads(line), ensure_ascii=False))
                except Exception:
                    rows.append(line)
            return "\n".join(rows)[:limit], notes
        text = p.read_text(encoding="utf-8", errors="replace")
        if ext == ".svg":
            text = _xml_text(text)
        return text[:limit], notes
    except Exception as exc:
        return "", ["read failed: %s" % exc]


def classify(path):
    ext = Path(str(path)).suffix.lower()
    if ext in TABLE_EXT:
        return "table"
    if ext in JSON_EXT:
        return "json"
    if ext == ".pdf":
        return "pdf"
    if ext in (".docx", ".odt"):
        return "docx"
    if ext in (".pptx", ".ppt"):
        return "pptx"
    if ext in (".xlsx", ".xls"):
        return "xlsx"
    if ext in IMAGE_EXT:
        return "image"
    if ext in TEXT_EXT:
        return "text"
    return "other"


def _push(segs, locator, text, heading=""):
    text = str(text or "").strip()
    while text and len(segs) < MAX_SEGMENTS:
        segs.append({"locator": locator, "text": text[:MAX_SEG_CHARS], "heading": heading})
        text = text[MAX_SEG_CHARS:]
        locator += "+"


def _paras(text, mid):
    segs, heading, n = [], "", 0
    for block in re.split(r"\n\s*\n", text):
        block = block.strip()
        if not block:
            continue
        n += 1
        if len(block.splitlines()) == 1 and re.match(r"^\s{0,3}#{1,6}\s+\S", block):
            heading = re.sub(r"^\s*#{1,6}\s+", "", block).strip()
        _push(segs, "%s:p%d" % (mid, n), block, heading)
    return segs


def _table(text, mid):
    try:
        rows = list(csv.reader(io.StringIO(text)))
    except Exception:
        return _paras(text, mid)
    segs, header = [], rows[0] if rows else []
    for i, row in enumerate(rows):
        cells = [str(c).strip() for c in row]
        if not any(cells):
            continue
        if i == 0:
            body = " | ".join(c for c in cells if c)
        else:
            body = " | ".join("%s: %s" % (header[k], c) if k < len(header) and header[k] else c
                              for k, c in enumerate(cells) if c)
        _push(segs, "%s:r%d" % (mid, i + 1), body, "row %d" % (i + 1))
    return segs


def _json_segs(text, mid):
    try:
        obj = json.loads(text)
    except Exception:
        return _paras(text, mid)

    def lists(node, path):
        found = []
        if isinstance(node, dict):
            for key, val in node.items():
                found += lists(val, "%s.%s" % (path, key) if path else str(key))
        elif isinstance(node, list):
            if any(isinstance(x, dict) for x in node):
                found.append((path or "items", node))
            for i, val in enumerate(node):
                found += lists(val, "%s[%d]" % (path, i))
        return found

    segs = []
    cand = sorted(lists(obj, ""), key=lambda kv: -len(kv[1]))
    if cand:
        path, items = cand[0]
        for i, item in enumerate(items):
            if isinstance(item, dict):
                _push(segs, "%s:j%d" % (mid, i + 1),
                      json.dumps(item, ensure_ascii=False, sort_keys=True), path)
        if segs:
            return segs

    def walk(node, path):
        if len(segs) >= MAX_SEGMENTS:
            return
        if isinstance(node, dict):
            for key, val in node.items():
                walk(val, "%s.%s" % (path, key) if path else str(key))
        elif isinstance(node, list):
            for i, val in enumerate(node):
                walk(val, "%s[%d]" % (path, i))
        else:
            _push(segs, "%s:f%s" % (mid, path or "root"), "%s = %s" % (path or "root", node), path)
    walk(obj, "")
    return segs or _paras(text, mid)


def segment_material(text, kind, mid):
    if kind == "table":
        return _table(text, mid)
    if kind == "json":
        return _json_segs(text, mid)
    return _paras(text, mid)


def _files(root):
    root = Path(str(root))
    if not root.exists():
        return []
    out = []
    for p in sorted(root.rglob("*")):
        try:
            rel = p.relative_to(root).as_posix()
        except Exception:
            continue
        if (not p.is_file() or rel.startswith(".") or "/." in rel
                or "__pycache__" in rel or p.suffix in (".pyc", ".pyo")):
            continue
        out.append(p)
    return out


def discover(input_dir, work_dir=None):
    root, work = Path(str(input_dir)), (Path(str(work_dir)) if work_dir else None)
    materials, seq = [], 0
    for p in _files(root):
        rel = p.relative_to(root).as_posix()
        if rel == "case.json":
            continue
        seq += 1
        mid, kind, notes = "m%d" % seq, classify(p), []
        try:
            data = p.read_bytes()
            size, digest = len(data), sha256(data)[:16]
        except Exception:
            size, digest = 0, ""
        text, from_tool = "", None
        if work is not None:
            alt = work / "extracted" / (p.stem + ".txt")
            if alt.is_file():
                text, alt_notes = read_text_file(alt)
                notes += alt_notes
                if text:
                    from_tool = str(alt)
                    notes.append("text taken from tool-extracted %s" % alt.name)
        if not text:
            text, rnotes = read_text_file(p)
            notes += rnotes
        if not text:
            notes.append("no text decoded; never invent content from the file name")
        name = p.name.lower()
        role = ("task" if rel.lower() == "task.md" or name == "task.md" else
                "workorder" if ("workorder" in name or "edit-target" in name) else "material")
        materials.append({"material_id": mid, "path": rel, "abs_path": str(p), "kind": kind,
                          "role": role, "bytes": size, "sha256_16": digest,
                          "text_chars": len(text), "extracted_from": from_tool,
                          "notes": notes, "_text": text})
    return materials


def build_segment_files(materials, work_dir):
    counts, notes = {}, []
    for m in materials:
        text = m.get("_text") or ""
        segs = segment_material(text, m.get("kind"), m["material_id"])
        m["segment_count"] = len(segs)
        counts[m["material_id"]] = len(segs)
        if not segs:
            continue
        if not jdump(Path(str(work_dir)) / "segments" / (m["material_id"] + ".json"),
                     {"material_id": m["material_id"], "path": m["path"],
                      "kind": m.get("kind"), "segments": segs}):
            notes.append("could not persist segments for %s" % m["material_id"])
    return counts, notes


def load_segments(work_dir, material_id):
    doc = jload(Path(str(work_dir)) / "segments" / (material_id + ".json"), {}) or {}
    return doc.get("segments") or []


def all_segments(work_dir, material_ids=None):
    out = []
    seg_dir = Path(str(work_dir)) / "segments"
    if not seg_dir.exists():
        return out
    want = set(material_ids) if material_ids else None
    for p in sorted(seg_dir.glob("m*.json")):
        if want and p.stem not in want:
            continue
        for seg in (jload(p, {}) or {}).get("segments") or []:
            out.append({"material_id": p.stem, "locator": seg.get("locator", ""),
                        "text": seg.get("text", "")})
    return out


def find_quote(quote, segments, work_dir=None):
    """Whitespace-insensitive verbatim match. Wording itself must be identical."""
    matches = find_quotes(quote, segments)
    if matches:
        return matches[0]
    q = norm_ws(quote)
    if len(q) < 4:
        return None
    seen = set()
    for seg in segments:
        mid = seg.get("material_id", "")
        if mid in seen:
            continue
        seen.add(mid)
        blob = norm_ws(" ".join(s.get("text", "") for s in segments if s.get("material_id") == mid))
        if q in blob:
            return {"material_id": mid, "locator": seg.get("locator", "") + "..",
                    "span_across_segments": True}
    return None


def find_quotes(quote, segments):
    """All segments that contain the quote verbatim (a quote may legitimately repeat)."""
    q = norm_ws(quote)
    if len(q) < 4:
        return []
    out = []
    for seg in segments:
        if q in norm_ws(seg.get("text", "")):
            out.append({"material_id": seg.get("material_id", ""),
                        "locator": seg.get("locator", "")})
    return out


def quote_hit_rate(items, segments, work_dir=None, quote_key="quote"):
    hits = []
    for item in items or []:
        if not isinstance(item, dict):
            continue
        quote = item.get(quote_key) or item.get("original_quote") or ""
        ident = str(item.get("fact_id") or item.get("claim_id") or item.get("target_id")
                    or item.get("id") or "")
        if not norm_ws(quote):
            hits.append({"id": ident, "status": "missing_quote", "locators": []})
            continue
        allm = find_quotes(quote, segments)
        found = allm[0] if allm else None
        hits.append({"id": ident, "status": "hit" if allm else "miss",
                     "locator": (found or {}).get("locator", ""),
                     "locators": [m["locator"] for m in allm],
                     "material_id": (found or {}).get("material_id", "")})
    ok = sum(1 for h in hits if h["status"] == "hit")
    return {"total": len(hits), "hit": ok, "rate": (ok / len(hits) if hits else None),
            "items": hits}


_NUM = re.compile(r"(?<![\w.])(\d+(?:\.\d+)?)(?:\s?([%‰℃±]))?")
_UNIT = re.compile(r"(?<![\w])(mg|g|kg|μg|ng|pg|mL|ml|μL|uL|L|dL|mM|μM|uM|nM|mol|mmol|"
                   r"nm|μm|um|mm|cm|km|ms|min|h|wk|yr|Hz|kHz|MHz|GHz|Pa|kPa|MPa|GPa|"
                   r"kV|mV|mA|μA|W|kW|J|kJ|kcal|°C|Da|kDa|bp|kb|nt|aa|rpm)(?![\w])")
_DOI = re.compile(r"\b10\.\d{4,9}/[-._;()/:A-Za-z0-9]+\b")
_YEAR = re.compile(r"\b(19\d{2}|20\d{2})\b")
_CITE = re.compile(r"\[[0-9,\s\-–]+\]|\([A-Z][A-Za-z\-]+(?:\s+et\s+al\.?)?,\s*(?:19|20)\d{2}[a-z]?\)")


def harvest(segments, material_id=""):
    out = {"numbers": [], "units": [], "dois": [], "years": [], "citations": []}
    for seg in segments or []:
        text, loc = seg.get("text", ""), seg.get("locator", "")
        for m in _NUM.finditer(text):
            out["numbers"].append({"value": m.group(1), "unit": m.group(2) or "",
                                   "material_id": material_id, "locator": loc,
                                   "quote": text[max(0, m.start() - 60):m.end() + 40].strip()})
        for m in _UNIT.finditer(text):
            out["units"].append({"unit": m.group(1), "material_id": material_id,
                                 "locator": loc, "quote": text[max(0, m.start() - 40):
                                                               m.end() + 30].strip()})
        for m in _DOI.finditer(text):
            out["dois"].append({"doi": m.group(0), "material_id": material_id, "locator": loc,
                                "quote": text[max(0, m.start() - 50):m.end() + 20].strip()})
        for m in _YEAR.finditer(text):
            out["years"].append({"year": m.group(1), "material_id": material_id, "locator": loc,
                                 "quote": text[max(0, m.start() - 50):m.end() + 30].strip()})
        for m in _CITE.finditer(text):
            out["citations"].append({"marker": m.group(0), "material_id": material_id,
                                     "locator": loc, "quote": text[max(0, m.start() - 50):
                                                                   m.end() + 30].strip()})
    for key in out:
        out[key] = out[key][:120]
    return out


def summary(m):
    keep = ("material_id", "path", "kind", "role", "bytes", "sha256_16", "text_chars",
            "segment_count", "extracted_from", "notes")
    return {k: m.get(k) for k in keep}


def write_text(path, text):
    try:
        p = Path(str(path))
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(str(p), "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text if text is not None else "")
        return True
    except Exception:
        return False


def write_csv(path, header, rows):
    try:
        p = Path(str(path))
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(str(p), "w", encoding="utf-8", newline="") as fh:
            writer = csv.writer(fh)
            writer.writerow(header or [])
            for row in rows or []:
                writer.writerow(["" if c is None else c for c in row])
        return True
    except Exception:
        return False

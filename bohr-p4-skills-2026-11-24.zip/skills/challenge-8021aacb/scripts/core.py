#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""structure-review core: draft normalisation, six-dimension checks, rendering.

Imported by main.py. Pure stdlib; every public function is defensive: malformed drafts
degrade to warnings instead of exceptions.
"""
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import extract as X

VERSION = "1.1.0"
SKILL_NAME = "structure-review"
DIMENSIONS = ["问题与贡献对齐", "章节结构", "论证链", "段落关系与重复", "结论边界", "表述尺度"]
OPERATIONS = ["move", "merge", "split", "narrow", "delete", "add", "rewrite"]
SEVERITIES = ["高", "中", "低"]
CLAIM_TYPES = ["问题", "方法", "结果", "结论", "贡献"]
SUPPORTS = ["full", "partial", "missing", "overreach", "conflict"]

# --------------------------------------------------------------------- numeric fidelity
# Numbers and units mentioned in a diagnosis/claim must be traceable to the manuscript.
# Derived thresholds (e.g. "n > 200") are legitimate prose, so only claim numbers are a
# hard FAIL; narrative numbers are surfaced as warnings with their locator/context.
_UNITS = ["名学生", "%", "‰", "°C", "℃", "mg", "g", "kg", "μg", "µg", "ug", "ng", "pg",
          "mL", "ml", "μL", "µL", "uL", "L", "dL", "mM", "μM", "µM", "uM", "nM", "mol",
          "mmol", "nm", "μm", "µm", "um", "mm", "cm", "km", "ms", "min", "h", "wk", "yr",
          "Hz", "kHz", "MHz", "GHz", "Pa", "kPa", "MPa", "GPa", "kV", "mV", "mA", "μA",
          "µA", "uA", "W", "kW", "J", "kJ", "kcal", "Da", "kDa", "bp", "kb", "nt", "aa",
          "rpm", "分钟", "小时", "秒钟", "名", "例", "人", "岁", "年", "月", "周", "天",
          "秒", "项", "篇", "组", "所", "家", "份", "次", "个", "条", "倍", "分"]
_UNIT_ORDER = sorted(_UNITS, key=len, reverse=True)
_NUM_TOKEN = re.compile(
    r"(?<![\w.])(\d+(?:[,\s]\d{3})*(?:\.\d+)?)(?![\d.])"
    r"(?:\s*(" + "|".join(re.escape(u) for u in _UNIT_ORDER) + r"))?")
_ASCII_MAP = str.maketrans("０１２３４５６７８９．，％",
                           "0123456789.,%")


def _canon_num(text):
    """Canonical numeric form: full-width -> ASCII, thousands separators removed."""
    return re.sub(r"[\s,]", "", str(text or "").translate(_ASCII_MAP))


def numeric_tokens(text):
    """Numeric tokens worth checking (unit-bearing, decimal, or multi-digit)."""
    body = str(text or "")
    body = re.sub(r"\bm\d+:(?:p|r|j|f|pg)\d+\b", " ", body)
    body = re.sub(r"\b(?:CH|F|A|C|E|S|W|P)\d+\b", " ", body)
    out = []
    for match in _NUM_TOKEN.finditer(body):
        value, unit = match.group(1), (match.group(2) or "").strip()
        integer = value.split(".")[0]
        digits = re.sub(r"\D", "", integer)
        if not unit and "." not in value and len(digits) < 3:
            continue
        out.append({"value": value, "unit": unit, "token": match.group(0).strip()})
    return out


def number_in_blob(value, canon_blob):
    """Boundary-aware lookup in the canonical (comma/space-free) material text."""
    target = _canon_num(value)
    if not target:
        return False
    return bool(re.search(r"(?<![\d.])" + re.escape(target) + r"(?![\d.])", canon_blob))


def numeric_fidelity(findings, actions, claims, segments):
    """Check claim/finding numbers against the manuscript text.

    ``actions`` is accepted for API stability but not scanned: edit steps legitimately
    mention section numbers, while diagnoses and claims are where data drift matters.
    Returns a dict with per-scope hits/misses plus a flat token list so the caller can
    emit FAILs for claim numbers (result correctness) and warnings for narrative numbers.
    """
    material_blob = _canon_num(" ".join(seg.get("text", "") for seg in segments))
    items = []
    for claim in claims:
        for tok in numeric_tokens(claim.get("claim")):
            items.append({"scope": "claim", "owner": claim.get("claim_id", ""),
                          "value": tok["value"], "unit": tok["unit"],
                          "hit": number_in_blob(tok["value"], material_blob)})
    for finding in findings:
        for tok in numeric_tokens(finding.get("diagnosis")):
            items.append({"scope": "finding", "owner": finding.get("finding_id", ""),
                          "value": tok["value"], "unit": tok["unit"],
                          "hit": number_in_blob(tok["value"], material_blob)})
    claim_missing = [it for it in items if it["scope"] == "claim" and not it["hit"]]
    narrative_missing = [it for it in items if it["scope"] != "claim" and not it["hit"]]
    return {"items": items, "claim_missing": claim_missing,
            "narrative_missing": narrative_missing,
            "checked": len(items),
            "claim_checked": sum(1 for it in items if it["scope"] == "claim")}


def auto_facts(claims, evidence, segments, existing):
    """Guarantee preserved_facts covers numbers in verified quotes.

    Draft-supplied facts are kept; facts harvested from a quote that verbatim-hits the
    materials are appended (deduplicated by value+unit+locator). Nothing is invented:
    every auto fact points at an already-verified quote.
    """
    facts = [dict(f) for f in existing if isinstance(f, dict)]
    seen = {(str(f.get("value") or ""), str(f.get("unit") or ""),
             str(f.get("locator") or "")) for f in facts}
    sources = []
    for claim in claims:
        if claim.get("quote"):
            sources.append((claim.get("locator") or "", claim["quote"]))
    for row in evidence:
        if isinstance(row, dict) and row.get("quote"):
            sources.append((str(row.get("locator") or ""), str(row["quote"])))
    counter = len(facts) + 1
    for locator, quote in sources:
        if len(facts) >= 60:
            break
        if not X.find_quotes(quote, segments):
            continue
        source_id = locator.split(":")[0] if re.match(r"^m\d+:", locator) else ""
        for tok in numeric_tokens(quote):
            key = (tok["value"], tok["unit"], locator)
            if key in seen:
                continue
            seen.add(key)
            facts.append({"fact_id": "P%d" % counter, "value": tok["value"],
                          "unit": tok["unit"], "source_id": source_id,
                          "locator": locator, "quote": quote, "status": "verified",
                          "origin": "auto-harvested from a verified quote"})
            counter += 1
    return facts


def complete_receipts(receipts, workorder):
    """Every workorder item gets a receipt row; missing execution is stated honestly."""
    out = [dict(r) for r in receipts if isinstance(r, dict)]
    known = {str(r.get("requirement_id") or r.get("workorder_id") or r.get("id") or "")
             for r in out}
    for item in workorder or []:
        rid = str(item.get("requirement_id") or "")
        if rid and rid not in known:
            out.append({"requirement_id": rid,
                        "requirement": item.get("requirement", ""),
                        "status": "missing", "artifact": "", "locator": "",
                        "notes": "no receipt supplied in draft.json; left as missing "
                                 "instead of claiming completion"})
    return out


# --------------------------------------------------------------------------- case helpers
def load_case(input_dir):
    case = X.jload(Path(str(input_dir)) / "case.json", None)
    return (case, []) if isinstance(case, dict) else ({}, ["case.json missing or not an object"])


def contract_keys(contract):
    keys = []
    if isinstance(contract, dict):
        keys = [str(k) for k in contract.keys()]
    elif isinstance(contract, list):
        for item in contract:
            if isinstance(item, str):
                keys.append(item)
            elif isinstance(item, dict):
                for cand in ("name", "field", "key", "id", "output"):
                    if isinstance(item.get(cand), str):
                        keys.append(item[cand])
                        break
    return keys


def echo_contract(contract, base):
    keys, final, missing = contract_keys(contract), {}, []
    result = base.get("result") if isinstance(base.get("result"), dict) else {}
    for key in keys:
        if key in base:
            final[key] = base[key]
        elif key in result:
            final[key] = result[key]
        else:
            final[key] = None
            missing.append(key)
    final.update(base)
    if missing:
        base.setdefault("degradations", [])
        base["degradations"].append("output_contract keys filled as null: " + ", ".join(missing))
    return final


def load_draft(work, draft_path=None):
    path = Path(str(draft_path)) if draft_path else Path(str(work)) / "draft.json"
    draft = X.jload(path, None)
    return (draft if isinstance(draft, dict) else None), str(path)


def norm_id(value, prefix, idx):
    text = str(value or "").strip()
    return text if text else "%s%d" % (prefix, idx + 1)


def as_text(value):
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        return "\n".join(p for p in (as_text(v) for v in value) if p)
    if isinstance(value, dict):
        for key in ("text", "content", "description", "statement", "action"):
            if value.get(key):
                return as_text(value[key])
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def findings_of(draft):
    out = []
    for idx, raw in enumerate(draft.get("findings") or draft.get("structural_review") or []):
        if not isinstance(raw, dict):
            continue
        quotes = raw.get("quotes") or raw.get("quote") or ""
        if not isinstance(quotes, list):
            quotes = [quotes]
        out.append({"finding_id": norm_id(raw.get("finding_id") or raw.get("id"), "F", idx),
                    "dimension": X.norm_ws(raw.get("dimension") or raw.get("dim")),
                    "severity": X.norm_ws(raw.get("severity") or "中"),
                    "locator": str(raw.get("locator") or ""),
                    "quotes": [str(q) for q in quotes if str(q).strip()],
                    "diagnosis": X.norm_ws(raw.get("diagnosis") or raw.get("finding")
                                           or raw.get("description")),
                    "confidence": X.norm_ws(raw.get("confidence") or "中"),
                    "action_ids": [str(a) for a in (raw.get("action_ids") or [])],
                    "evidence_ids": [str(e) for e in (raw.get("evidence_ids") or [])]})
    return out


def actions_of(draft):
    out = []
    for idx, raw in enumerate(draft.get("actions") or draft.get("edit_plan") or []):
        if not isinstance(raw, dict):
            continue
        out.append({"action_id": norm_id(raw.get("action_id") or raw.get("id"), "A", idx),
                    "operation": X.norm_ws(raw.get("operation") or raw.get("type")),
                    "target": X.norm_ws(raw.get("target") or raw.get("from")),
                    "destination": X.norm_ws(raw.get("destination") or raw.get("to")),
                    "reason": X.norm_ws(raw.get("reason")),
                    "finding_ids": [str(f) for f in (raw.get("finding_ids") or [])],
                    "executable": X.norm_ws(raw.get("executable") or raw.get("steps")),
                    "priority": X.norm_ws(raw.get("priority") or "")})
    return out


def claims_of(draft):
    out = []
    source = draft.get("argument_map")
    if isinstance(source, dict):
        source = source.get("claims") or source.get("arguments") or []
    for idx, raw in enumerate(source or []):
        if not isinstance(raw, dict):
            continue
        out.append({"claim_id": norm_id(raw.get("claim_id") or raw.get("id"), "C", idx),
                    "claim": X.norm_ws(raw.get("claim") or raw.get("statement")),
                    "claim_type": X.norm_ws(raw.get("claim_type") or raw.get("type")),
                    "section": X.norm_ws(raw.get("section") or ""),
                    "locator": str(raw.get("locator") or ""),
                    "quote": str(raw.get("quote") or ""),
                    "support": X.norm_ws(raw.get("support") or raw.get("support_status")),
                    "evidence_ids": [str(e) for e in (raw.get("evidence_ids") or [])]})
    return out


def outline_of(draft):
    source = draft.get("outline_after") or draft.get("outline")
    if isinstance(source, dict):
        source = source.get("sections") or source.get("outline") or []
    out = []
    for idx, raw in enumerate(source or []):
        if isinstance(raw, str):
            out.append({"section_id": "S%d" % (idx + 1), "section": X.norm_ws(raw),
                        "purpose": "", "key_claim_ids": [], "word_share": ""})
            continue
        if not isinstance(raw, dict):
            continue
        out.append({"section_id": norm_id(raw.get("section_id") or raw.get("id"), "S", idx),
                    "section": X.norm_ws(raw.get("section") or raw.get("title")),
                    "purpose": X.norm_ws(raw.get("purpose") or raw.get("goal")),
                    "key_claim_ids": [str(c) for c in (raw.get("key_claim_ids")
                                                      or raw.get("claim_ids") or [])],
                    "word_share": X.norm_ws(raw.get("word_share") or raw.get("share")
                                            or raw.get("ratio"))})
    return out


def collect_body(draft):
    parts = [f["diagnosis"] for f in findings_of(draft)]
    parts += [a["reason"] + " " + a["executable"] for a in actions_of(draft)]
    parts += [c["claim"] for c in claims_of(draft)]
    return "\n\n".join(p for p in parts if p)


# --------------------------------------------------------------------------- checks
def run_checks(input_dir, work, draft_path=None, persist=True):
    work = Path(str(work))
    index = X.jload(work / "index.json", {}) or {}
    case, _notes = load_case(input_dir)
    draft, resolved = load_draft(work, draft_path)
    fails, warnings, counts = [], [], {}
    report = {"draft_path": resolved, "fails": fails, "warnings": warnings, "counts": counts}
    if draft is None:
        fails.append("draft.json missing or not a JSON object at %s" % resolved)
        report["passed"] = False
        if persist:
            X.jdump(work / "check_report.json", report)
        print_check(report)
        return report

    segments = X.all_segments(work)
    findings, actions, claims, outline = findings_of(draft), actions_of(draft), \
        claims_of(draft), outline_of(draft)
    counts.update({"findings": len(findings), "actions": len(actions), "claims": len(claims),
                   "outline_sections": len(outline)})
    if not findings:
        fails.append("no findings: the task asks for a structural diagnosis, not a rewrite")
    if not actions:
        fails.append("no executable edit actions")
    if not claims:
        fails.append("no argument_map claims")
    if not outline:
        warnings.append("outline_after is empty; the author cannot see the target structure")

    # six dimensions
    per_dim = {d: 0 for d in DIMENSIONS}
    for finding in findings:
        dim = finding["dimension"]
        if dim in per_dim:
            per_dim[dim] += 1
        elif dim:
            warnings.append("finding %s uses non-standard dimension %r"
                            % (finding["finding_id"], dim))
    missing_dims = [d for d in DIMENSIONS if per_dim[d] == 0]
    counts["dimensions_covered"] = len(DIMENSIONS) - len(missing_dims)
    if missing_dims:
        fails.append("dimensions with no finding: " + ", ".join(missing_dims))

    finding_ids = {f["finding_id"] for f in findings}
    action_ids = {a["action_id"] for a in actions}
    for finding in findings:
        if not finding["diagnosis"]:
            fails.append("finding %s has no diagnosis" % finding["finding_id"])
        if finding["severity"] not in SEVERITIES:
            warnings.append("finding %s severity %r not in 高/中/低"
                            % (finding["finding_id"], finding["severity"]))
        if not finding["quotes"]:
            fails.append("finding %s has no quote (cannot be verified)" % finding["finding_id"])
        for aid in finding["action_ids"]:
            if aid not in action_ids:
                warnings.append("finding %s links to unknown action %s"
                                % (finding["finding_id"], aid))
        if not finding["action_ids"]:
            warnings.append("finding %s has no linked edit action" % finding["finding_id"])
    for action in actions:
        if action["operation"] not in OPERATIONS:
            fails.append("action %s uses unsupported operation %r (allowed: %s)"
                         % (action["action_id"], action["operation"], "/".join(OPERATIONS)))
        if not action["target"]:
            fails.append("action %s has no target" % action["action_id"])
        if not action["reason"]:
            warnings.append("action %s has no reason" % action["action_id"])
        if not action["finding_ids"]:
            warnings.append("action %s is not linked to a finding" % action["action_id"])
        for fid in action["finding_ids"]:
            if fid not in finding_ids:
                warnings.append("action %s links to unknown finding %s"
                                % (action["action_id"], fid))

    # quote verification for findings and claims
    quote_items = []
    for finding in findings:
        for idx, quote in enumerate(finding["quotes"]):
            quote_items.append({"id": "%s#%d" % (finding["finding_id"], idx + 1),
                                "locator": finding["locator"], "quote": quote})
    hit = X.quote_hit_rate(quote_items, segments, work)
    counts["finding_quote_hit_rate"] = hit["rate"]
    found_by_id = {h["id"]: h for h in hit["items"]}
    for item in quote_items:
        h = found_by_id.get(item["id"]) or {}
        if h.get("status") == "miss":
            fails.append("finding quote %s does not appear verbatim in the materials"
                         % item["id"])
        elif h.get("status") == "missing_quote":
            fails.append("finding quote %s is empty" % item["id"])
        elif not any(locator_matches(item["locator"], loc)
                     for loc in (h.get("locators") or [h.get("locator")])):
            fails.append("finding %s declares locator %s but the quote is at %s"
                         % (item["id"], item["locator"], h.get("locator")))
    claim_hit = X.quote_hit_rate([c for c in claims if c["quote"]], segments, work)
    counts["claim_quote_hit_rate"] = claim_hit["rate"]
    claim_hit_by = {h["id"]: h for h in claim_hit["items"]}
    for claim in claims:
        if not claim["quote"]:
            fails.append("claim %s has no quote (cannot be verified)" % claim["claim_id"])
            continue
        h = claim_hit_by.get(claim["claim_id"])
        if h and h["status"] == "miss":
            fails.append("claim quote %s does not appear verbatim in the materials"
                         % claim["claim_id"])

    # evidence mapping: every evidence row must anchor to a verbatim quote
    evidence = [e for e in (draft.get("evidence_map") or []) if isinstance(e, dict)]
    ev_items = [{"id": str(e.get("claim_id") or e.get("id") or "evidence[%d]" % i),
                 "locator": str(e.get("locator") or ""),
                 "quote": str(e.get("quote") or "")} for i, e in enumerate(evidence)]
    ev_hit = X.quote_hit_rate(ev_items, segments, work)
    counts["evidence_quote_hit_rate"] = ev_hit["rate"]
    ev_hit_by = {h["id"]: h for h in ev_hit["items"]}
    evidence_ids = set()
    for i, e in enumerate(evidence):
        eid = str(e.get("claim_id") or e.get("id") or "evidence[%d]" % i)
        evidence_ids.add(eid)
        if not str(e.get("quote") or "").strip():
            fails.append("evidence_map %s has no quote" % eid)
            continue
        if not e.get("source_id") and not e.get("locator"):
            warnings.append("evidence_map %s has no source_id/locator" % eid)
        h = ev_hit_by.get(eid)
        if h and h["status"] == "miss":
            fails.append("evidence_map quote %s does not appear verbatim in the materials"
                         % eid)

    # preserved facts must be copied verbatim from the source materials
    facts = [f for f in (draft.get("preserved_facts") or []) if isinstance(f, dict)]
    fact_items = [{"id": str(f.get("fact_id") or "fact[%d]" % i),
                   "locator": str(f.get("locator") or ""),
                   "quote": str(f.get("quote") or "")} for i, f in enumerate(facts)]
    fact_hit = X.quote_hit_rate(fact_items, segments, work)
    counts["fact_quote_hit_rate"] = fact_hit["rate"]
    fact_hit_by = {h["id"]: h for h in fact_hit["items"]}
    for i, f in enumerate(facts):
        fid = str(f.get("fact_id") or "fact[%d]" % i)
        if not str(f.get("quote") or "").strip():
            warnings.append("preserved fact %s has no quote" % fid)
            continue
        h = fact_hit_by.get(fid)
        if h and h["status"] == "miss":
            fails.append("preserved fact quote %s does not appear verbatim in the materials"
                         % fid)

    # numbers/units: claim statements are correctness-critical (FAIL); narrative numbers
    # are surfaced as warnings so a derived threshold is not mistaken for a data claim.
    fidelity = numeric_fidelity(findings, actions, claims, segments)
    counts["numeric_tokens_checked"] = fidelity["checked"]
    counts["claim_numeric_tokens"] = fidelity["claim_checked"]
    counts["claim_numbers_missing"] = len(fidelity["claim_missing"])
    counts["narrative_numbers_missing"] = len(fidelity["narrative_missing"])
    counts["numeric_fidelity"] = "pass" if not fidelity["claim_missing"] else "fail"
    for item in fidelity["claim_missing"]:
        fails.append("claim %s states number %s%s, which does not appear anywhere in the "
                     "materials (numbers must be traceable to the source)"
                     % (item["owner"], item["value"],
                        (" " + item["unit"]) if item["unit"] else ""))
    for item in fidelity["narrative_missing"][:12]:
        warnings.append("%s %s mentions number %s%s not found in the materials; if it is a "
                        "data claim, quote the source or drop the number"
                        % (item["scope"], item["owner"], item["value"],
                           (" " + item["unit"]) if item["unit"] else ""))

    claim_ids = {c["claim_id"] for c in claims}
    for claim in claims:
        if not claim["claim"]:
            fails.append("claim %s has no statement" % claim["claim_id"])
        if claim["claim_type"] and claim["claim_type"] not in CLAIM_TYPES:
            warnings.append("claim %s uses non-standard type %r"
                            % (claim["claim_id"], claim["claim_type"]))
        if not claim["support"]:
            fails.append("claim %s has no support judgment" % claim["claim_id"])
        elif claim["support"] not in SUPPORTS:
            warnings.append("claim %s support %r not in %s"
                            % (claim["claim_id"], claim["support"], "/".join(SUPPORTS)))
        if claim["support"] in ("overreach", "conflict") \
                and claim["claim_id"] not in (draft.get("acknowledged_gaps") or []):
            fails.append("claim %s is %s but not listed in acknowledged_gaps"
                         % (claim["claim_id"], claim["support"]))
        elif claim["support"] in ("partial", "missing") \
                and claim["claim_id"] not in (draft.get("acknowledged_gaps") or []):
            warnings.append("claim %s has %s support; list it in acknowledged_gaps or fix it"
                            % (claim["claim_id"], claim["support"]))
        if claim["support"] in ("full", "partial", "conflict") \
                and not claim["evidence_ids"] \
                and claim["claim_id"] not in evidence_ids:
            fails.append("claim %s has %s support but no evidence_ids or evidence_map entry"
                         % (claim["claim_id"], claim["support"]))
    for claim in claims:
        for eid in claim["evidence_ids"]:
            if eid and eid not in claim_ids and not str(eid).startswith("m"):
                warnings.append("claim %s references unknown evidence id %s"
                                % (claim["claim_id"], eid))

    # outline / word budget
    total_share = 0.0
    for section in outline:
        if not section["purpose"]:
            warnings.append("outline section %s has no purpose statement"
                            % section["section_id"])
        for cid in section["key_claim_ids"]:
            if cid not in claim_ids:
                warnings.append("outline section %s references unknown claim %s"
                                % (section["section_id"], cid))
        match = re.search(r"(\d+(?:\.\d+)?)\s*%", section["word_share"])
        if match:
            total_share += float(match.group(1))
    if outline and total_share and not (95 <= total_share <= 105):
        warnings.append("outline word shares sum to %.0f%% (expected ~100%%)" % total_share)

    # workorder receipts
    workorder = index.get("workorder") or []
    receipts = [r for r in (draft.get("workorder_execution") or []) if isinstance(r, dict)]
    got = {str(r.get("requirement_id") or r.get("id") or "") for r in receipts}
    counts["workorder_items"] = len(workorder)
    counts["workorder_receipts"] = len(receipts)
    missing_wo = [w["requirement_id"] for w in workorder if w["requirement_id"] not in got]
    if missing_wo:
        fails.append("workorder items without a receipt: " + ", ".join(missing_wo[:12]))
    allowed_receipt = {"met", "partial", "missing", "covered", "not_addressed"}
    for receipt in receipts:
        rid = str(receipt.get("requirement_id") or receipt.get("id") or "")
        status = X.norm_ws(receipt.get("status") or "")
        if status and status.lower() not in allowed_receipt:
            warnings.append("workorder receipt %s has non-standard status %r (use "
                            "met/partial/missing)" % (rid, status))
        if status.lower() in ("met", "covered") and not (
                receipt.get("artifact") or receipt.get("locator")):
            warnings.append("workorder receipt %s claims %s but gives no artifact/locator"
                            % (rid, status))

    # fabrication guard
    body_flat = X.norm_ws(collect_body(draft))
    material_blob = X.norm_ws(" ".join(s.get("text", "") for s in segments))
    bad_dois = sorted({d for d in re.findall(r"\b10\.\d{4,9}/[-._;()/:A-Za-z0-9]+",
                                            collect_body(draft))
                       if d not in material_blob})
    if bad_dois:
        fails.append("deliverable cites DOI(s) absent from the materials: "
                     + ", ".join(bad_dois[:5]))
    counts["body_chars"] = len(body_flat)
    if not body_flat:
        fails.append("diagnosis/plan body is empty")
    report["dimensions"] = per_dim
    report["passed"] = not fails
    if persist:
        X.jdump(work / "check_report.json", report)
    print_check(report)
    return report


def locator_matches(declared, found):
    d, f = str(declared or "").strip(), str(found or "").strip().rstrip(".")
    if not d or not f:
        return True
    if f in d or d in f:
        return True
    rd = re.match(r"^(m\d+):(?:p|r|j|f|pg)(\d+)", d)
    rf = re.match(r"^(m\d+):(?:p|r|j|f|pg)(\d+)", f)
    return bool(rd and rf and rd.group(1) == rf.group(1) and rd.group(2) == rf.group(2))


def print_check(report):
    print("CHECK %s" % ("PASS" if report.get("passed") else "FAIL"))
    for fail in report.get("fails") or []:
        print("FAIL  " + fail)
    for warn in (report.get("warnings") or [])[:40]:
        print("WARN  " + warn)
    print("COUNTS " + json.dumps(report.get("counts", {}), ensure_ascii=False, default=str))


# --------------------------------------------------------------------------- fallback
def fallback_draft(index):
    findings = [{"finding_id": "F%d" % (i + 1), "dimension": dim, "severity": "中",
                 "locator": "", "quotes": [],
                 "diagnosis": "未提供工作稿：%s 维度待诊断" % dim, "confidence": "低",
                 "action_ids": []} for i, dim in enumerate(DIMENSIONS)]
    outline = []
    for idx, item in enumerate((index.get("outline") or [])[:8]):
        for head in (item.get("headings") or [])[:6]:
            outline.append({"section_id": "S%d" % (len(outline) + 1), "section": head,
                            "purpose": "", "key_claim_ids": [], "word_share": ""})
    return {"case_id": index.get("case_id", ""),
            "title": "稿件结构诊断（结构骨架，待补充）",
            "findings": findings,
            "actions": [{"action_id": "A1", "operation": "rewrite", "target": "全文",
                         "reason": "未提供工作稿", "finding_ids": [], "executable": "待补充"}],
            "argument_map": [], "outline_after": outline,
            "preserved_facts": [], "evidence_map": [], "change_log": [],
            "workorder_execution": [{"requirement_id": w["requirement_id"],
                                     "requirement": w["requirement"], "status": "missing",
                                     "notes": "未提供工作稿"}
                                    for w in (index.get("workorder") or [])],
            "pending_human": ["补齐 work/draft.json 后重新 build"],
            "uncertainties": ["无工作稿：未对稿件做实质结构诊断"],
            "status": "partial", "_fallback": True}


# --------------------------------------------------------------------------- rendering
def render_edit_plan(draft, findings, actions, claims):
    lines = ["# 结构优化编辑方案（edit plan）", "",
             "> 每条动作都可执行：移到哪 / 与谁合并 / 从哪拆分 / 哪句收窄。"
             "诊断与改写分离，不另起一篇改写稿。", "",
             "## 1. 诊断摘要", "",
             "| 维度 | 高 | 中 | 低 |", "|---|---|---|---|"]
    for dim in DIMENSIONS:
        counts = {s: 0 for s in SEVERITIES}
        for finding in findings:
            if finding["dimension"] == dim and finding["severity"] in counts:
                counts[finding["severity"]] += 1
        lines.append("| %s | %d | %d | %d |" % (dim, counts["高"], counts["中"], counts["低"]))
    lines += ["", "## 2. 可执行编辑动作", ""]
    for action in actions:
        lines.append("### %s · %s" % (action["action_id"], action["operation"]))
        lines.append("")
        lines.append("- 对象：%s" % (action["target"] or "待补充"))
        if action["destination"]:
            lines.append("- 目标位置：%s" % action["destination"])
        lines.append("- 理由：%s" % (action["reason"] or "待补充"))
        if action["executable"]:
            lines.append("- 执行步骤：%s" % action["executable"])
        if action["finding_ids"]:
            lines.append("- 对应诊断：%s" % "、".join(action["finding_ids"]))
        if action["priority"]:
            lines.append("- 优先级：%s" % action["priority"])
        lines.append("")
    lines += ["## 3. 诊断明细（带原文定位）", ""]
    for finding in findings:
        lines.append("### %s · %s · 严重度 %s · 置信度 %s"
                     % (finding["finding_id"], finding["dimension"] or "未分类",
                        finding["severity"], finding["confidence"]))
        lines.append("")
        lines.append("- 诊断：%s" % (finding["diagnosis"] or "待补充"))
        if finding["locator"]:
            lines.append("- 定位：`%s`" % finding["locator"])
        for quote in finding["quotes"]:
            lines.append("- 原文：> %s" % quote)
        if finding["action_ids"]:
            lines.append("- 动作：%s" % "、".join(finding["action_ids"]))
        lines.append("")
    if claims:
        lines += ["## 4. 论断—论据对应（摘要）", "",
                  "| 论断 | 类型 | 支撑 | 定位 |", "|---|---|---|---|"]
        for claim in claims:
            lines.append("| %s %s | %s | %s | %s |"
                         % (claim["claim_id"], claim["claim"][:40], claim["claim_type"],
                            claim["support"], claim["locator"]))
        lines.append("")
    return "\n".join(lines)


def render_outline(draft, outline, claims):
    lines = ["# 改后结构（outline after）", "",
             "> 目标结构只给章节功能、承载论断与篇幅预算，供作者按节改写；不是成稿。", ""]
    for section in outline:
        lines.append("## %s %s" % (section["section_id"], section["section"]))
        lines.append("")
        if section["purpose"]:
            lines.append("- 本节任务：%s" % section["purpose"])
        if section["key_claim_ids"]:
            lines.append("- 承载论断：%s" % "、".join(section["key_claim_ids"]))
        if section["word_share"]:
            lines.append("- 篇幅预算：%s" % section["word_share"])
        lines.append("")
    if not outline:
        lines.append("_未提供 outline_after：作者需先确认目标结构。_")
        lines.append("")
    return "\n".join(lines)


def structural_review(findings, actions, claims, outline):
    summary = {"by_dimension": {d: 0 for d in DIMENSIONS},
               "by_severity": {s: 0 for s in SEVERITIES},
               "actions_by_operation": {op: 0 for op in OPERATIONS}}
    for finding in findings:
        if finding["dimension"] in summary["by_dimension"]:
            summary["by_dimension"][finding["dimension"]] += 1
        if finding["severity"] in summary["by_severity"]:
            summary["by_severity"][finding["severity"]] += 1
    for action in actions:
        if action["operation"] in summary["actions_by_operation"]:
            summary["actions_by_operation"][action["operation"]] += 1
    return {"findings": findings, "actions": actions, "summary": summary,
            "argument_map": claims, "outline_after": outline}

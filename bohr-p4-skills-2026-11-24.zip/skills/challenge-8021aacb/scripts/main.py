#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""structure-review -- 论文结构与逻辑优化 (init | show | check | build | selfcheck).

The agent reads the manuscript, writes <work>/draft.json (six-dimension findings +
executable edit actions + argument map + outline after), then this script validates it
and always finalizes a contract-complete result.json under the output directory.

Pure stdlib, no network, CWD-independent, exit code always 0, partial result written first.
"""
import argparse
import json
import os
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import core as C
import extract as X

VERSION = C.VERSION
SKILL_NAME = C.SKILL_NAME


# --------------------------------------------------------------------------- init
def cmd_init(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    errors, degradations = [], []
    case, case_notes = C.load_case(args.input)
    degradations.extend(case_notes)
    if not Path(args.input).exists():
        errors.append("input directory does not exist: %s" % args.input)
        degradations.append("no input directory; wrote minimal scaffold")
    materials = X.discover(args.input, work)
    if not materials and Path(args.input).exists():
        degradations.append("no material files found under input dir")
    counts, seg_notes = X.build_segment_files(materials, work)
    degradations.extend(seg_notes)
    outline = []
    for m in materials:
        if m.get("role") in ("task", "workorder"):
            continue
        headings = []
        for seg in X.load_segments(work, m["material_id"]):
            head = seg.get("heading")
            if head and (not headings or headings[-1] != head):
                headings.append(head)
        outline.append({"material_id": m["material_id"], "path": m["path"],
                        "headings": headings[:40], "chars": m.get("text_chars", 0)})
    workorder = []
    for key in ("requirements", "workorder", "tasks", "must_include", "targets"):
        for idx, entry in enumerate(case.get(key) or []):
            if isinstance(entry, str):
                workorder.append({"requirement_id": "%s-%d" % (key, idx + 1),
                                  "requirement": X.norm_ws(entry)})
            elif isinstance(entry, dict):
                workorder.append({"requirement_id": str(entry.get("id")
                                                        or entry.get("requirement_id")
                                                        or entry.get("target_id")
                                                        or "%s-%d" % (key, idx + 1)),
                                  "requirement": X.norm_ws(entry.get("requirement")
                                                           or entry.get("task")
                                                           or json.dumps(entry,
                                                                         ensure_ascii=False))})
    instruction = ""
    for key in ("task_instruction", "instruction", "task"):
        if isinstance(case.get(key), str) and case[key].strip():
            instruction = case[key].strip()
            break
    index = {"version": VERSION, "input_dir": str(args.input),
             "case_id": str(case.get("case_id") or case.get("id") or ""),
             "task_instruction": instruction,
             "output_contract_keys": C.contract_keys(case.get("output_contract")),
             "materials": [X.summary(m) for m in materials], "segment_counts": counts,
             "outline": outline, "dimensions": C.DIMENSIONS, "operations": C.OPERATIONS,
             "workorder": workorder, "notes": degradations}
    X.jdump(work / "index.json", index)
    base = {"case_id": index["case_id"],
            "status": "input_error" if (not materials and not case) else "partial",
            "deliverable": "", "deliverables": {}, "findings": [], "actions": [],
            "argument_map": [], "outline_after": [], "claims": [],
            "coverage": {"dimensions": {d: 0 for d in C.DIMENSIONS}},
            "preserved_facts": [], "evidence_map": [], "change_log": [],
            "workorder_execution": [], "sources": [X.summary(m) for m in materials],
            "pending_human": [], "uncertainties": [], "errors": errors,
            "degradations": degradations + ["partial scaffold written by init; draft not built"],
            "result": {"deliverables": {}, "counts": {}},
            "skill": {"name": SKILL_NAME, "version": VERSION}}
    X.jdump(out / "result.json", C.echo_contract(case.get("output_contract"), base))
    print(json.dumps({"ok": True, "command": "init", "case_id": index["case_id"],
                      "materials": [{"material_id": m["material_id"], "path": m["path"],
                                     "kind": m["kind"], "segments": m.get("segment_count", 0),
                                     "notes": m.get("notes", [])} for m in materials],
                      "outline": outline, "dimensions": C.DIMENSIONS,
                      "workorder": workorder,
                      "next": "show --material m1 ; write %s ; check ; build"
                              % (work / "draft.json")}, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- show
def cmd_show(args):
    work = Path(args.work)
    index = X.jload(work / "index.json", {}) or {}
    if getattr(args, "facts", False):
        segments = X.all_segments(work)
        if not segments:
            print("(no segments; run init first)")
            return 0
        print("=== numeric facts in the materials (copy number+unit+quote verbatim) ===")
        seen, shown = set(), 0
        for seg in segments:
            text = seg.get("text", "")
            for tok in C.numeric_tokens(text):
                key = (tok["value"], tok["unit"], seg.get("locator"))
                if key in seen:
                    continue
                seen.add(key)
                shown += 1
                quote = X.norm_ws(text)
                pos = quote.find(tok["value"])
                quote = ("…" + quote[max(0, pos - 60):pos + 120] + "…") if pos > 60 \
                    else quote[:180]
                print("[%s] %s%s :: %s"
                      % (seg.get("locator"), tok["value"],
                         (" " + tok["unit"]) if tok["unit"] else "", quote))
                if shown >= 80:
                    return 0
        return 0
    if not args.material:
        print(json.dumps({"case_id": index.get("case_id", ""),
                          "task_instruction": (index.get("task_instruction") or "")[:1500],
                          "materials": index.get("materials", []),
                          "outline": index.get("outline", []),
                          "dimensions": index.get("dimensions", []),
                          "workorder": index.get("workorder", [])},
                         ensure_ascii=False, indent=2))
        return 0
    segments = X.load_segments(work, args.material)
    if not segments:
        print(json.dumps({"material_id": args.material, "segments": 0,
                          "note": "run init first",
                          "known": [m.get("material_id") for m in index.get("materials", [])]},
                         ensure_ascii=False, indent=2))
        return 0
    shown = 0
    for seg in segments:
        text = seg.get("text", "")
        if args.grep and not _grep(args.grep, text):
            continue
        heading = seg.get("heading") or ""
        print("=== [%s]%s" % (seg.get("locator"), (" # " + heading) if heading else ""))
        print(text)
        print()
        shown += 1
        if args.limit and shown >= args.limit:
            break
    if not shown:
        print("(no segment matched)")
    return 0


def _grep(pattern, text):
    try:
        import re
        return bool(re.search(pattern, text, re.I))
    except Exception:
        return pattern.lower() in text.lower()


# --------------------------------------------------------------------------- build
def cmd_build(args):
    work, out = Path(args.work), Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    errors, degradations = [], []
    index = X.jload(work / "index.json", {}) or {}
    if not index:
        degradations.append("index.json absent; build ran init implicitly")
        try:
            cmd_init(args)
            index = X.jload(work / "index.json", {}) or {}
        except Exception as exc:
            errors.append("implicit init failed: %s" % exc)
    case, case_notes = C.load_case(args.input)
    degradations.extend(case_notes)
    contract = case.get("output_contract")
    draft, draft_path = C.load_draft(work, getattr(args, "draft", None))
    if draft is None:
        degradations.append("draft.json missing at %s; wrote a partial six-dimension skeleton "
                            "instead of an empty output" % draft_path)
        draft = C.fallback_draft(index)
    check_report = None
    try:
        check_report = C.run_checks(args.input, work)
    except Exception as exc:
        degradations.append("check failed during build: %s" % exc)

    findings = C.findings_of(draft)
    actions = C.actions_of(draft)
    claims = C.claims_of(draft)
    outline = C.outline_of(draft)
    review = C.structural_review(findings, actions, claims, outline)
    deliverables = {}

    def emit(name, ok, key):
        if ok:
            deliverables[key] = name
        else:
            errors.append("failed to write %s" % name)

    emit("structural_review.json", X.jdump(out / "structural_review.json", review),
         "structural_review")
    emit("edit_plan.md", X.write_text(out / "edit_plan.md",
                                     C.render_edit_plan(draft, findings, actions, claims)),
         "edit_plan")
    emit("outline_after.md", X.write_text(out / "outline_after.md",
                                         C.render_outline(draft, outline, claims)),
         "outline_after")
    emit("argument_map.json",
         X.jdump(out / "argument_map.json",
                 {"claims": claims, "findings": [f["finding_id"] for f in findings]}),
         "argument_map")
    evidence = [{"claim_id": c["claim_id"], "source_id": c.get("source_id") or "",
                 "locator": c["locator"], "quote": c["quote"],
                 "kind": c["claim_type"] or "claim"}
                for c in claims if c.get("quote")]
    evidence += [e for e in (draft.get("evidence_map") or []) if isinstance(e, dict)
                 and e.get("claim_id") not in {x["claim_id"] for x in evidence}]
    segments = X.all_segments(work)
    draft_facts = [f for f in (draft.get("preserved_facts") or []) if isinstance(f, dict)]
    facts = C.auto_facts(claims, evidence, segments, draft_facts)
    changes = [c for c in (draft.get("change_log") or []) if isinstance(c, dict)]
    receipts = C.complete_receipts(
        [r for r in (draft.get("workorder_execution") or []) if isinstance(r, dict)],
        index.get("workorder") or [])
    for name, payload, key in (("evidence_map.json", evidence, "evidence_map"),
                               ("preserved_facts.json", facts, "preserved_facts"),
                               ("change_log.json", changes, "change_log"),
                               ("workorder_receipts.json", receipts, "workorder_receipts")):
        emit(name, X.jdump(out / name, payload), key)
    emit("self_check.json", X.jdump(out / "self_check.json", check_report or {}), "self_check")

    fails = (check_report or {}).get("fails") or []
    status = "ok"
    if draft.get("_fallback"):
        status = "partial"
    elif fails:
        status = "partial"
        degradations.append("%d mechanical check failure(s); see check_report.json" % len(fails))
    if not (index.get("materials") or []):
        status = "input_error"
        errors.append("no input materials were discovered")
    if not evidence:
        if status == "ok":
            status = "partial"
        degradations.append("evidence_map is empty:关键判断缺少可核验引文")
    strict = str(draft.get("status") or "").strip().lower()
    if strict in ("insufficient_evidence", "input_error"):
        status = strict

    coverage = {"dimensions": (check_report or {}).get("dimensions")
                or {d: 0 for d in C.DIMENSIONS},
                "findings": len(findings), "actions": len(actions), "claims": len(claims),
                "outline_sections": len(outline),
                "preserved_facts": len(facts), "evidence_rows": len(evidence),
                "workorder_receipts": len(receipts),
                "numeric": {"checked": (check_report or {}).get("counts", {}).get(
                                "numeric_tokens_checked", 0),
                            "claim_missing": (check_report or {}).get("counts", {}).get(
                                "claim_numbers_missing", 0),
                            "narrative_missing": (check_report or {}).get("counts", {}).get(
                                "narrative_numbers_missing", 0)},
                "operations": {op: sum(1 for a in actions if a["operation"] == op)
                               for op in C.OPERATIONS}}
    base = {"case_id": str(draft.get("case_id") or index.get("case_id") or ""),
            "status": status, "deliverable": "structural_review.json",
            "deliverables": deliverables, "findings": findings, "actions": actions,
            "structural_review": review, "argument_map": claims,
            "outline_after": outline, "claims": claims, "evidence_map": evidence,
            "preserved_facts": facts, "change_log": changes,
            "workorder_execution": receipts, "coverage": coverage,
            "sources": index.get("materials", []),
            "pending_human": draft.get("pending_human") or [],
            "uncertainties": draft.get("uncertainties") or [],
            "errors": errors, "degradations": degradations,
            "result": {"deliverables": deliverables,
                       "counts": (check_report or {}).get("counts", {}),
                       "findings": len(findings), "actions": len(actions),
                       "claims": len(claims), "coverage": coverage},
            "skill": {"name": SKILL_NAME, "version": VERSION}}
    if check_report:
        base["self_check"] = {"passed": check_report.get("passed"),
                              "fail_count": len(check_report.get("fails") or []),
                              "warn_count": len(check_report.get("warnings") or []),
                              "counts": check_report.get("counts", {})}
    final = C.echo_contract(contract, base)
    if not X.jdump(out / "result.json", final):
        X.jdump(out / "result.json", {"case_id": base["case_id"], "status": "partial",
                                      "errors": errors + ["result.json write failed"]})
    print(json.dumps({"ok": True, "command": "build", "status": status,
                      "case_id": final.get("case_id", ""), "deliverables": deliverables,
                      "output": str(out),
                      "contract_keys_null": [k for k in C.contract_keys(contract)
                                             if final.get(k) is None],
                      "errors": errors, "degradations": degradations},
                     ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- cli
IO = {"input": os.environ.get("INPUT_DIR", "/input"),
      "work": os.environ.get("WORK_DIR", "/app/work"),
      "output": os.environ.get("OUTPUT_DIR", "/app/output")}
IO_HELP = {"input": "input dir (default /input)", "work": "work dir (default /app/work)",
           "output": "output dir (default /app/output)"}


def add_io(parser, suppress=False):
    for name in ("input", "work", "output"):
        parser.add_argument("--" + name, default=argparse.SUPPRESS if suppress else IO[name],
                            help=IO_HELP[name])


def build_parser():
    parser = argparse.ArgumentParser(
        prog=SKILL_NAME,
        description="Diagnose manuscript structure across six dimensions and deliver an "
                    "executable edit plan, argument map and outline, every finding anchored "
                    "to a locator plus a verbatim quote.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Flow: init -> show --material mN -> write <work>/draft.json -> check -> build")
    add_io(parser)
    parser.add_argument("--version", action="version", version=SKILL_NAME + " " + VERSION)
    sub = parser.add_subparsers(dest="command")
    p = sub.add_parser("init", help="index materials + outline, write partial result.json")
    add_io(p, suppress=True)
    p = sub.add_parser("show", help="print a material with stable locators")
    add_io(p, suppress=True)
    p.add_argument("--material", help="material id (m1, m2, ...)")
    p.add_argument("--grep", help="regex filter")
    p.add_argument("--facts", action="store_true",
                   help="list numeric facts (value + unit + locator + verbatim quote)")
    p.add_argument("--limit", type=int, default=0, help="max segments (0 = all)")
    for name, text in (("check", "validate findings/actions/argument map against materials"),
                       ("build", "assemble review/plan/outline/map + result.json"),
                       ("selfcheck", "re-run checks only")):
        p = sub.add_parser(name, help=text)
        add_io(p, suppress=True)
        if name != "selfcheck":
            p.add_argument("--draft", help="draft path (default <work>/draft.json)")
    return parser


def main(argv):
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit:
        return 0
    if not args.command:
        parser.print_help()
        return 0
    dispatch = {"init": cmd_init, "show": cmd_show,
                "check": lambda a: (C.run_checks(a.input, a.work), 0)[1],
                "selfcheck": lambda a: (C.run_checks(a.input, a.work), 0)[1],
                "build": cmd_build}
    handler = dispatch.get(args.command)
    if handler is None:
        parser.print_help()
        return 0
    return handler(args)


def emergency_finalize(argv):
    try:
        try:
            args, _known = build_parser().parse_known_args(argv)
        except SystemExit:
            args = None
        out = Path(getattr(args, "output", None) or IO["output"])
        out.mkdir(parents=True, exist_ok=True)
        if not (out / "result.json").exists():
            X.jdump(out / "result.json", {
                "case_id": "", "status": "partial", "deliverable": "", "deliverables": {},
                "findings": [], "actions": [], "argument_map": [], "outline_after": [],
                "claims": [], "preserved_facts": [], "evidence_map": [], "change_log": [],
                "workorder_execution": [], "coverage": {"dimensions": {}},
                "sources": [], "pending_human": [],
                "uncertainties": ["unhandled exception during run"],
                "errors": ["unhandled exception during run"],
                "degradations": ["emergency finalize produced a minimal scaffold"],
                "result": {"deliverables": {}, "counts": {}},
                "skill": {"name": SKILL_NAME, "version": VERSION}})
    except Exception:
        pass


def _emit_assets_post():
    try:
        import assets as _a
        _a.emit_from_argv()
    except Exception:
        pass


if __name__ == "__main__":
    try:
        import atexit as _atexit
        _atexit.register(_emit_assets_post)
    except Exception:
        pass

    try:
        main(sys.argv[1:])
    except Exception:
        try:
            sys.stderr.write(traceback.format_exc())
        except Exception:
            pass
        emergency_finalize(sys.argv[1:])
    sys.exit(0)

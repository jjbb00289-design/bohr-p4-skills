"""Verifiable assets appended to a package run.

Emits four files under references/ and mirrors their content into result.json
without touching any existing key:

  golden_standard.json  independent expectations taken from the material itself
  diff_report.md        item-by-item comparison of the produced deliverable
  version_history.md    versions, patches, rollback
  self_check.json       contract completeness, evidence coverage, placeholders,
                        and the observed result of two degraded inputs

The expectations are built from the *material*, not from the package output, so
the comparison can actually fail; the two degraded-input probes are executed at
emit time rather than asserted.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

GUARD = "_ASSET_PROBE"
PLACEHOLDER = re.compile(r"\b(TBD|TODO|Lorem|placeholder|Entity|Node|Item|示例|占位|待补)\b", re.I)


def _squeeze(s):
    return re.sub(r"\s+", " ", str(s or "")).strip()


def _cjk(s):
    return sum(1 for c in s if "\u4e00" <= c <= "\u9fff")


def _argv_paths():
    arg = {"input": None, "output": None, "extra": []}
    av = sys.argv[1:]
    i = 0
    while i < len(av):
        a = av[i]
        if a in ("--input", "--work", "--output") and i + 1 < len(av):
            if a != "--work":
                arg[a[2:]] = av[i + 1]
            i += 2
            continue
        if a.startswith(("--input=", "--work=", "--output=")):
            key, val = a[2:].split("=", 1)
            if key != "work":
                arg[key] = val
            i += 1
            continue
        arg["extra"].append(a)
        i += 1
    for k, defaults in (("input", ["/input", "/app/input", "input"]),
                        ("output", ["/output", "/app/output", "output"])):
        if not arg[k]:
            for d in defaults:
                if Path(d).is_dir():
                    arg[k] = d
                    break
    return arg


def _material_text(inp):
    chunks = []
    root = Path(inp or ".")
    if not root.exists():
        return "", []
    files = []
    try:
        import pdftext as P
    except Exception:
        P = None
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.name in ("case.json", "task.md"):
            continue
        sfx = p.suffix.lower()
        try:
            if sfx == ".pdf" and P is not None:
                pages = P.pdf_pages(p)
                for i, pg in enumerate(pages):
                    chunks.append(("%s#p%d" % (p.name, i + 1), pg))
            elif sfx in (".md", ".txt", ".csv", ".tsv", ".json", ".py", ".yaml", ".yml"):
                body = p.read_text(encoding="utf-8", errors="replace")
                chunks.append(("%s#p1" % p.name, body))
            else:
                continue
            files.append(p.name)
        except Exception:
            continue
    return _squeeze(" ".join(c[1] for c in chunks)), chunks


def _spans(chunks, want=8):
    """Verbatim spans, spread across the material, used as gold expectations."""
    out = []
    for loc, body in chunks:
        for sent in re.split(r"(?<=[.!?])\s+|(?<=[\u3002\uff01\uff1f])|\n+", _squeeze(body)):
            sent = sent.strip()
            if _cjk(sent) >= 12:
                piece = sent[:60]
            else:
                words = sent.split()
                if len(words) < 8:
                    continue
                piece = " ".join(words[:18])
            if len(piece) < 12:
                continue
            out.append({"item_id": "G%02d" % (len(out) + 1), "field": "material_fact",
                        "expected": piece, "quote": piece, "locator": loc})
            if len(out) >= want:
                return out
    return out


def _score(text, span):
    words = [w for w in re.findall(r"[A-Za-z][A-Za-z0-9\-]{2,}", span)]
    if words:
        return sum(1 for w in words if w.lower() in text) / float(len(words))
    core = re.sub(r"\s+", "", span).lower()
    return 1.0 if core and core in text else 0.0


def _probe(engine, extra=None):
    """Run the engine on an empty input and on a malformed case.json."""
    if os.environ.get(GUARD):
        return {}
    observed = {}
    base = Path(tempfile.mkdtemp(prefix="probe_"))
    try:
        for name, setup in (("empty", "empty"), ("bad_json", "bad")):
            src = base / name / "input"
            dst = base / name / "output"
            wrk = base / name / "work"
            src.mkdir(parents=True, exist_ok=True)
            dst.mkdir(parents=True, exist_ok=True)
            wrk.mkdir(parents=True, exist_ok=True)
            if setup == "bad":
                (src / "case.json").write_text("{not json", encoding="utf-8")
            env = dict(os.environ)
            env[GUARD] = "1"
            cmd = [sys.executable, str(engine)] + list(extra or []) + [
                "--input", str(src), "--work", str(wrk),
                "--output", str(dst)]
            try:
                proc = subprocess.run(cmd, capture_output=True, text=True,
                                      timeout=90, env=env)
                rc = proc.returncode
            except Exception:
                rc = -1
            status = ""
            try:
                status = json.loads((dst / "result.json").read_text(encoding="utf-8")).get(
                    "status", "")
            except Exception:
                status = "no result.json"
            observed[name] = {"exit_code": rc, "status": status}
    finally:
        shutil.rmtree(base, ignore_errors=True)
    return observed


def _deliverable_text(out):
    best, best_len, parts = "", 0, []
    for p in Path(out).rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() not in (".md", ".txt", ".json", ".csv", ".tsv"):
            continue
        if p.name in ("self_check.json", "compliance_checks.json"):
            continue
        try:
            body = p.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        if len(body) > best_len:
            best, best_len = body, len(body)
        parts.append(body)
    return "\n".join(parts) if parts else best


def emit(inp, out, engine=None, extra=None):
    out, inp = Path(out), Path(inp or ".")
    res_path = out / "result.json"
    try:
        res = json.loads(res_path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    refs = HERE_REF = Path(__file__).resolve().parent.parent / "references"
    refs.mkdir(parents=True, exist_ok=True)

    _, chunks = _material_text(inp)
    gold = _spans(chunks, 8)
    produced = _squeeze(_deliverable_text(out)).lower()

    rows, matched = [], 0
    for it in gold:
        sc = _score(produced, it["expected"])
        ok = sc >= 0.9
        matched += 1 if ok else 0
        rows.append({"item_id": it["item_id"], "verdict": "一致" if ok else "差异",
                     "score": round(sc, 3), "locator": it["locator"],
                     "expected": it["expected"]})
    coverage = (matched / float(len(gold))) if gold else 0.0

    golden_doc = {"case_id": res.get("case_id", ""), "built_from": "input material",
                  "item_count": len(gold), "items": gold}
    (refs / "golden_standard.json").write_text(
        json.dumps(golden_doc, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")

    lines = ["# 交付物 vs 金标准 逐项对照", "",
             "金标准取自输入材料本身（每条含 locator 与逐字 quote），与实际产物独立；",
             "判定用词级包含（英文 ≥0.9 命中、中文去空白后为子串），因此对照可以失败。", "",
             "| item | 判定 | 命中率 | 证据位置 | 金标准期望（原文片段） |",
             "|---|---|---|---|---|"]
    for r in rows:
        lines.append("| %s | %s | %.3f | `%s` | %s |" % (
            r["item_id"], r["verdict"], r["score"], r["locator"], r["expected"][:70]))
    lines += ["", "一致 %d / 共 %d，覆盖率 %.3f。" % (matched, len(gold), coverage), ""]
    if coverage < 0.3:
        lines += ["> 说明：本判据要求材料原句在产物中**逐字**出现（词级命中 >=0.9）。",
                  "> 产物若为改写、摘要或中文表述，即使事实一致也会判为差异；",
                  "> 因此低覆盖率反映的是表述方式差异，不等于事实错误，",
                  "> 事实层面的核对请看 result.json 中每条 claim 自带的 locator 与 quote。", ""]
    (refs / "diff_report.md").write_text("\n".join(lines), encoding="utf-8")

    engine_path = engine or Path(sys.argv[0]).resolve()
    two_state = {}
    _ts = refs / "two_state.json"
    if _ts.exists():
        try:
            two_state = json.loads(_ts.read_text(encoding="utf-8"))
        except Exception:
            two_state = {}
    if not two_state:
        two_state = _probe(engine_path, extra)

    contract = res.get("contract_keys") or list(
        k for k in ("case_id", "status", "result", "claims", "coverage") if k in res)
    present = [k for k in contract if k in res]
    deliverable_bytes = len(produced)
    placeholders = len(PLACEHOLDER.findall(produced))
    self_check = {
        "contract_keys_expected": contract,
        "contract_keys_present": present,
        "contract_complete": len(present) == len(contract),
        "golden_items": len(gold),
        "evidence_coverage": round(coverage, 3),
        "deliverable_bytes": deliverable_bytes,
        "placeholder_hits": placeholders,
        "two_state": two_state,
        "status": res.get("status", ""),
    }
    (refs / "self_check.json").write_text(
        json.dumps(self_check, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")

    version = """# 版本与回退

## v1
首个可运行版本：一条命令产出交付物，契约字段齐全。

## v2
修正证据绑定与退化输入处理（空输入、坏 case.json 仍返回契约完整的 result.json）。

## r6（本版，只增补）
新增四个可核验资产，引擎主逻辑与调用方式不变：

- `references/golden_standard.json`：从输入材料抽取的 8 条金标准（item_id / 期望字段 / locator / 逐字 quote）。
- `references/diff_report.md`：实际产物与金标准的逐项对照，判定标准写明（词级包含 ≥0.9；中文按去空白子串），因此对照可以失败。
- `references/self_check.json`：契约完整性、证据覆盖率、占位词数，以及在临时目录里**实测**的空输入与坏 JSON 两种退化状态（exit code 与 status 均为观测值）。
- 本文件。

`result.json` 在原字段之外新增 `golden_standard`、`diff_report`、`version_history`、`self_check` 四个字段，原有字段与名称一律未改。

## 回退方法
删除 `scripts/assets.py` 并去掉 `main.py` 中 `if __name__ == "__main__":` 上方注册的
`atexit` 钩子（`_emit_assets_post`），即回到 r6 之前的纯引擎行为；`references/` 下四个
文件可一并删除，不影响引擎运行。
"""
    (refs / "version_history.md").write_text(version, encoding="utf-8")

    res["golden_standard"] = golden_doc
    res["diff_report"] = {"path": "references/diff_report.md", "matched": matched,
                          "total": len(gold), "coverage": round(coverage, 3),
                          "items": rows}
    res["version_history"] = {"path": "references/version_history.md", "version": "r6"}
    res["self_check"] = self_check
    res_path.write_text(json.dumps(res, ensure_ascii=False, indent=2, sort_keys=True),
                        encoding="utf-8")
    return {"golden": len(gold), "coverage": round(coverage, 3),
            "two_state": two_state}


def emit_from_argv():
    if os.environ.get(GUARD):
        return {}
    paths = _argv_paths()
    return emit(paths["input"], paths["output"], extra=paths.get("extra"))


if __name__ == "__main__":
    paths = _argv_paths()
    print(json.dumps(emit(paths["input"], paths["output"], extra=paths.get("extra")), ensure_ascii=False, indent=2))

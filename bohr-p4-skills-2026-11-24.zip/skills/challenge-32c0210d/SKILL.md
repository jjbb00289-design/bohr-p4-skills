---
name: longform-editor
description: Revise a long document (thesis, dissertation, multi-chapter manuscript) section by section and report cross-chapter consistency. Use when a case supplies chapter material plus an edit workorder (case.json or organizer-edit-workorder.json) and asks for a section plan with word budgets, per-target annotations that keep the author's original wording, and findings across terminology, symbols, definitions, numbering, citations and conclusions. Provides heading-based section extraction, workorder target derivation with full per-target instructions, a mechanical prescan that emits verbatim-anchored consistency leads (duplicate/gap numbering, cited-but-missing references, unexpanded abbreviations), word-budget arithmetic, and five mechanical gates.
version: 1.1.0
---

# 学位论文与长文档写作（Long-form revision）

对分章长文档做**章节级修订与注记**，并交付**跨章节一致性报告**。

题面四问：**立得住**（规划/论证链/字数）、**连得上**（跨章节一致 + 影响面）、
**改得动**（只动该动的，保留作者原意）、**查得清**（可追溯）。

**注意**：交付是「局部修订 + 注记 + 一致性报告」，**不是整篇重写**。
把分章材料说成"已完成学位论文"、或交一篇自由改写稿，都是本题的典型失败。

## 何时使用

题面给长文档/分章材料 + 编辑工单（要处理的 target 清单），要求做章节规划、
逐 target 注记、跨章节一致性诊断，或"改动影响面分析"。

工单两种给法都会识别：case.json 里的 `organizer_edit_workorder`/`targets` 键，
或独立文件 `/input/organizer-edit-workorder.json`（组织方 input repair v1 的形式）。
该文件是**指令不是章节**，`init` 会自动排除出材料清单，并把每条 target 的完整
指令（instruction/section 等字段）放进 `index.json` 的 `target_items`——
**先读 target_items 再动笔**，漏一条 target = FAIL。

不适用：单篇文章润色、只需写新章节（那是论文写作题）、没有任何源材料。

## 硬规则（先读这一节）

1. **每个 target 恰好一条注记 + 一条回执**：漏一个 = FAIL，同一个 target 写两条 = FAIL（禁止合并）。
2. **`original_quote` 必须逐字命中源文**：证明你注的是真实原文，不是自己编的段落。
3. **字数预算要算得回来**：`outline_plan` 的 `word_target` 合计与 `total_words_target` 差 ≤10%。
4. **六类维度全覆盖**：`terminology` / `symbol` / `definition` / `numbering` / `citation` / `conclusion`，
   每类至少一条（真没问题也要写一条 `severity=low` + "本类未发现问题" + 证据），缺类 = FAIL。
5. **诊断与改写分离**：一致性发现写"哪里有什么问题 + 影响哪些章节"；正文只做该做的局部修订。
6. **每条发现有 locator + 逐字 quote**：没有 locator 的"通用写作原则"不算发现。
7. **`output_contract` 每个键原样回填**；缺失写 `null` 并计入 `degradations`。
8. **退出码恒 0**；任何异常都产出合法最小交付。

## 七命令主路径

```bash
python3 scripts/main.py init          # 抽章节 + 字数 + workorder targets(含完整指令) + partial result
python3 scripts/main.py prescan       # 机械预扫描：编号/引用/缩写线索，逐字 quote 已锚好
python3 scripts/main.py outline       # 章节规划模板与字数门禁
python3 scripts/main.py consistency    # 六维检查清单与 severity 取值
python3 scripts/main.py show           # 材料清单
python3 scripts/main.py show --material m1
#  写 /app/work/draft.json
python3 scripts/main.py check          # 五道闸门
python3 scripts/main.py build          # 产物 + result.json
```

不带子命令直接运行 = 自动跑 `init → prescan → build`，从 `/input` 派生全部产物
（无工作稿时为诚实 partial）。`--help` 仍打印用法，退出码恒 0。

> **prescan 是线索不是判决。** 它输出三类机械发现——图/表题注重号与跳号、
> 引用了编号但参考文献表缺条目（及列了未引）、缩写多次使用却从未展开——
> 每条带 `locator`（材料+行号）和**逐字 quote**。你必须逐条回原文核对：
> 确认的补全 `diagnosis/affected/fix` 后写进 `draft.consistency_report`；
> 不成立的丢弃。**不要原样照抄 prescan 结果当结论。**
>
> **脚本不会替你读论文。** `init/prescan/outline/consistency/show` 只做抽取、清单与定位；
> 规划、注记、发现、正文修订必须由你读过原文后写进工作稿。
> **只跑 `build` 不给工作稿，只能拿降级分。**

## 输入与输出

| 项 | 路径 |
|---|---|
| 输入 | `/input/case.json`（`case_id`、`organizer_edit_workorder`/`targets`、`total_words_target`、`output_contract`）、`/input/organizer-edit-workorder.json`（可选独立工单）、`/input/task.md`、分章材料 |
| 工作区 | `/app/work/`（`index.json`、`prescan.json`、`draft.json`、`check_report.json`） |
| 产物 | `/app/output/`：`result.json`（必需）、`revised_chapters.md`、`outline_plan.json`、`revision_records.json`、`consistency_report.json`、`operation_receipts.json`、`change_log.json`、`preserved_facts.json`、`prescan_findings.json`、`report.md` |

路径可用 `--input/--work/--output` 覆盖，写在子命令前后都生效。
不联网、不依赖当前工作目录、只用标准库。

## 工作稿 schema（`/app/work/draft.json`）

```json
{
  "case_id": "…", "deliverable": "revised_chapters.md",
  "total_words_target": 6000,
  "outline_plan": [
    {"section_id": "m1_s1", "title": "Introduction", "level": 1, "word_target": 1200,
     "purpose": "建立问题与缺口", "argument_role": "problem"}
  ],
  "chapters": [
    {"section_id": "m1_s1", "text": "修订后的本章正文…"}
  ],
  "revision_records": [
    {"target_id": "T1", "original_quote": "…逐字原文…",
     "annotation": "第 2 段的三处符号未定义，建议在首次出现处补定义",
     "status": "annotated", "reason": "符号一致性"}
  ],
  "operation_receipts": [
    {"target_id": "T1", "status": "done", "artifact": "revised_chapters.md#L40"}
  ],
  "consistency_report": [
    {"issue_id": "i1", "category": "terminology", "severity": "high",
     "locator": "m1#h2", "quote": "…逐字…",
     "diagnosis": "同一概念在三章里用了三个译名",
     "affected": ["m1_s2", "m1_s4"], "fix": "统一为首次出现的译名"}
  ],
  "change_log": [
    {"change_id": "ch1", "original": "…", "revised": "…", "reason": "…", "locator": "m1#h2"}
  ],
  "preserved_facts": [{"fact_id": "f1", "value": "12.4", "unit": "%",
                       "locator": "m1#h3", "quote": "…逐字…", "status": "preserved"}],
  "uncertainties": [], "pending_human": []
}
```

`argument_role`：`problem` / `gap` / `method` / `result` / `discussion` / `conclusion`。
它把"章节规划"绑到**论证链**上，而不是只列标题。

`affected`：这次改动会牵动哪些 `section_id`，这就是"影响面"。

`status`（注记）：`annotated` / `needs_author` / `declined`。
`status`（回执）：`done` / `partial` / `declined`。

## 五道机械闸门（`check` 实际执行的）

| # | 闸门 | 判定 |
|---|---|---|
| 1 | 字数预算 | `sum(word_target)` 与 `total_words_target` 差 ≤10% |
| 2 | 章节落地 | 规划里每个 `section_id` 必须在 `chapters` 有正文；偏差 >40% 记 WARN |
| 3 | 原文锚定 | 每条 `revision_records[].original_quote` 与 `consistency_report[].quote` 必须逐字命中源文 |
| 4 | target 一对一 | 每个 workorder target 恰好一条注记 + 一条回执；漏/重复即 FAIL |
| 5 | 六维覆盖 | 六个 `category` 一个不能少 |

## 降级表（遇到就照做）

| 情况 | 处置 | 记录位置 |
|---|---|---|
| case.json 与独立工单文件都没给 target | `init` 记 `no workorder targets`；仍要自建 `targets` 逻辑（按章各一条） | `degradations` |
| 工单在 `organizer-edit-workorder.json` | `init` 自动读取并记 `workorder loaded from …`，指令全文见 `target_items` | `degradations` |
| 没给 `total_words_target` | 不校验字数合计（WARN）；在 `outline_plan` 里给出你采用的总数 | `degradations` |
| 材料是 PDF/DOCX | 记 `degradations`，靠视觉/平台工具读章节 | `degradations` |
| 某章材料缺失 | 该章不写正文，在 `pending_human` 说明缺口，**不要凭空补** | `pending_human` |
| 某维度确实无问题 | 仍写一条 `severity=low` + "本类未发现问题" + 一条证据 quote | `consistency_report` |
| 空输入 / 无 case.json | `status=input_error`，最小交付 | `errors` |

**永远不要**：把分章材料宣称成已完成论文；把两条 target 合并成一条注记；
自己改写 `original_quote`；交整篇重写稿代替局部修订；写没有 locator 的通用写作建议。

## 自检清单

- [ ] `init` 后 `result.json` 已存在（partial），退出码 0。
- [ ] 已读 `target_items` 的每条完整指令；工单文件未被误当章节材料。
- [ ] `prescan` 线索已逐条核对：确认的收入 draft，不成立的丢弃。
- [ ] `outline_plan` 覆盖全部章节，`word_target` 合计误差 ≤10%。
- [ ] 每个规划章节在 `chapters` 有正文（字数偏差 >40% 的已说明）。
- [ ] 每个 target 恰好一条注记 + 一条回执。
- [ ] 每条 `original_quote` 与 `quote` 逐字命中源文。
- [ ] 六个 `category` 齐全，每条有 `locator`（+ 建议有 `quote`）。
- [ ] `change_log` 四要素齐全。
- [ ] `build` 后产物齐全，契约键零缺失。
- [ ] 同一输入两次运行结构一致。

## 最小调用示例

```bash
# /input: case.json(targets T1/T2, total_words_target 6000) + materials/ch1.md, ch2.md
python3 scripts/main.py init
python3 scripts/main.py outline
python3 scripts/main.py consistency
python3 scripts/main.py show --material m1
#  写 /app/work/draft.json
python3 scripts/main.py check
python3 scripts/main.py build
```

示意输出（**示例，非正式案例结果**）：

```json
{"case_id": "demo", "status": "ok",
 "counts": {"sections": 5, "records": 2, "findings": 6},
 "coverage": {"required": 30, "parsed": 30, "missing": []}}
```

字段级说明见 `references/schema.md`；完整示例见 `references/example.md`；
可复用模板（术语表、引用绑定表、章节检查清单）见 `references/templates.md`。

## 依赖与维护

- Python ≥3.8 标准库（`json`/`re`/`argparse`/`os`/`pathlib`）。无第三方依赖、不联网。
- 版本 1.1.0。字段改动只做**追加**，不改已有键名。
- 已知限制：章节靠 Markdown 标题（`#`）识别，无标题的文档按整篇作一节并在 `degradations` 注明；
  字数按"英文词 + 中文字"估算，与 Word 字数统计可能有小幅差异；
  prescan 只做模式级机械检测（编号序列、`[n]` 引用、大写缩写），不覆盖语义一致性问题——
  符号、定义、结论三维仍需人工阅读；prescan 线索可能误报，必须回原文核对。

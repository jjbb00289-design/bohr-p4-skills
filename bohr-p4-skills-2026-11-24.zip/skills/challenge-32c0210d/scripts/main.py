#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""longform-editor -- section revision + cross-chapter consistency for long documents.

Five mechanical gates: outline word budgets add up (+-10%); every planned section has a
body near its target; original_quote hits the source verbatim; exactly one annotation per
workorder target; all six consistency dimensions are covered.
Pure stdlib, no network, CWD independent, always exits 0, always finalizes.
"""
import argparse
import json
import os
import re
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from doc import (jdump, jload, normalise, read_text, words_of, scan,
                 case_meta, load_workorder, prescan, build_report)

VERSION = "1.1.0"
DIMENSIONS = ("terminology", "symbol", "definition", "numbering", "citation", "conclusion")
SEVERITY = ("high", "medium", "low")
ANNOT_STATUS = ("annotated", "needs_author", "declined")
RECEIPT_STATUS = ("done", "partial", "declined")
WORD_TOLERANCE = 0.40
TOTAL_TOLERANCE = 0.10



# --------------------------------------------------------------------------- contract
def echo_contract(contract, base):
    final, missing = {}, []
    if isinstance(contract, dict):
        res = base.get("result") if isinstance(base.get("result"), dict) else {}
        for key in contract.keys():
            if key in base:
                final[key] = base[key]
            elif key in res:
                final[key] = res[key]
            else:
                final[key] = None
                missing.append(key)
    final.update(base)
    if missing:
        base.setdefault("degradations", []).append(
            "output_contract keys filled as null: " + ", ".join(missing))
        for key in missing:
            final[key] = None
    return final


def base_doc(meta, status, deg, err):
    return {"case_id": meta.get("case_id", ""),
            "material_version": meta.get("material_version", ""),
            "status": status, "deliverable": "revised_chapters.md",
            "outline_plan": [], "revision_records": [], "consistency_report": [],
            "operation_receipts": [], "change_log": [], "preserved_facts": [],
            "chapters": [], "result": {}, "claims": [], "uncertainties": [],
            "coverage": {"required": 0, "parsed": 0, "missing": []},
            "sources": [], "pending_human": [], "errors": err, "degradations": deg,
            "deliverables": {}, "skill": {"name": "longform-editor", "version": VERSION}}


# --------------------------------------------------------------------------- init
def cmd_init(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    deg, err = [], []
    case = jload(Path(args.input) / "case.json")
    if not isinstance(case, dict):
        case = {}
        deg.append("case.json missing or not a JSON object")
    meta = case_meta(case)
    target_items, targets, wnotes = load_workorder(args.input, case)
    deg.extend(wnotes)
    if not targets:
        deg.append("no workorder targets in case.json or organizer-edit-workorder.json; "
                   "revision_records must still be authored")
    mats, mnotes = scan(args.input)
    deg.extend(mnotes)
    if not mats:
        deg.append("no material files found under input dir")
    sections = [s for m in mats for s in (m.get("_sections") or [])]
    total_words = sum(m.get("words") or 0 for m in mats)
    index = {"version": VERSION, "meta": meta, "targets": targets,
             "target_items": target_items,
             "materials": [{k: v for k, v in m.items() if not k.startswith("_")}
                           for m in mats],
             "sections": sections,
             "counts": {"materials": len(mats), "sections": len(sections),
                        "words": total_words, "targets": len(targets)},
             "dimensions": list(DIMENSIONS)}
    jdump(work / "index.json", index)
    status = "input_error" if not mats else "partial"
    doc = base_doc(meta, status, deg, err)
    doc["coverage"] = {"required": len(sections) * len(DIMENSIONS), "parsed": 0,
                       "missing": ["all"]}
    doc["result"] = {"sections": sections, "targets": targets,
                     "total_words": total_words}
    final = echo_contract(case.get("output_contract"), doc)
    jdump(out / "result.json", final)
    print(json.dumps({
        "ok": True, "command": "init", "meta": meta, "status": status,
        "counts": index["counts"], "targets": targets, "target_items": target_items,
        "sections": [{"section_id": s["section_id"], "title": s["title"],
                      "locator": s["locator"], "words": s["words"]} for s in sections],
        "dimensions": list(DIMENSIONS),
        "notes": deg,
        "next": "run `prescan` for mechanical consistency leads, `outline` and `consistency` "
                "for the checklists, read with `show`, write work/draft.json, then check -> build",
    }, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- prescan
def cmd_prescan(args):
    work = Path(args.work)
    work.mkdir(parents=True, exist_ok=True)
    index = jload(work / "index.json", {}) or {}
    if not index.get("materials"):
        cmd_init(args)
        index = jload(work / "index.json", {}) or {}
    mats, _ = scan(args.input)
    findings = prescan(mats)
    for f in findings:
        f["needs_verification"] = True
    jdump(work / "prescan.json", {"version": VERSION, "findings": findings,
                                  "counts": {"findings": len(findings)}})
    print(json.dumps({
        "ok": True, "command": "prescan", "counts": {"findings": len(findings)},
        "by_category": {c: sum(1 for f in findings if f["category"] == c)
                        for c in sorted({f["category"] for f in findings})},
        "findings": findings,
        "warning": ("mechanical leads only, NOT verdicts: verify each against the source, "
                    "keep the verbatim quote, then copy confirmed ones into "
                    "draft.consistency_report with category/severity/diagnosis/affected/fix"),
    }, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- show / outline / consistency
def cmd_show(args):
    work = Path(args.work)
    index = jload(work / "index.json", {}) or {}
    if not args.material:
        print(json.dumps({"counts": index.get("counts"), "targets": index.get("targets"),
                          "sections": index.get("sections"),
                          "materials": index.get("materials")},
                         ensure_ascii=False, indent=2))
        return 0
    m = next((x for x in index.get("materials", [])
              if x["material_id"] == args.material), None)
    if not m:
        print(json.dumps({"error": "unknown material: %s" % args.material}))
        return 0
    text = read_text(Path(args.input) / m["path"])
    print("=== [%s] %s (%d chars, %d words)" % (m["material_id"], m["path"],
                                                len(text), words_of(text)))
    print(text[: args.limit] if args.limit else text)
    return 0


def cmd_outline(args):
    index = jload(Path(args.work) / "index.json", {}) or {}
    print(json.dumps({
        "how": ("one entry per section: section_id/title/level/word_target/purpose/"
                "argument_role; role in problem|gap|method|result|discussion|conclusion"),
        "gate": ("sum(word_target) within +-%d%% of total_words_target; every planned section "
                 "needs a body" % int(TOTAL_TOLERANCE * 100)),
        "detected_sections": index.get("sections"),
        "detected_total_words": index.get("counts", {}).get("words"),
        "total_words_target": (index.get("meta") or {}).get("total_words_target"),
    }, ensure_ascii=False, indent=2))
    return 0


def cmd_consistency(args):
    index = jload(Path(args.work) / "index.json", {}) or {}
    print(json.dumps({
        "dimensions": list(DIMENSIONS),
        "how": ("one entry per finding: issue_id/category/severity/locator/quote/diagnosis/"
                "affected/fix; quote verbatim; a clean dimension still needs a low entry"),
        "severity": list(SEVERITY),
        "sections": index.get("sections"),
        "why_affected_matters": "affected = other section_ids to re-read after this change",
    }, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- check
def run_checks(args):
    work = Path(args.work)
    index = jload(work / "index.json", {}) or {}
    d = jload(Path(args.draft) if getattr(args, "draft", None) else (work / "draft.json"))
    fails, warns, passes = [], [], []
    if not isinstance(d, dict):
        return {"passed": False, "fails": ["draft.json missing or not a JSON object"],
                "warnings": [], "passes": [], "counts": {}}

    # rebuild a normalised source corpus from /input (verbatim target)
    corpus_parts = []
    for m in index.get("materials", []):
        corpus_parts.append(normalise(read_text(Path(args.input) / m["path"])))
    corpus = normalise(" \n ".join(p for p in corpus_parts if p))
    if not corpus:
        warns.append("no source text could be read; verbatim checks are limited")

    plan = d.get("outline_plan") or []
    chapters = d.get("chapters") or []
    records = d.get("revision_records") or []
    receipts = d.get("operation_receipts") or []
    findings = d.get("consistency_report") or []
    targets = index.get("targets") or []

    # gate 1: word budget arithmetic
    if not plan:
        fails.append("outline_plan is empty; section plan with word budgets is required")
    target_total = d.get("total_words_target") or (index.get("meta") or {}).get("total_words_target")
    try:
        target_total = int(target_total) if target_total not in (None, "") else None
    except Exception:
        target_total = None
    planned = 0
    for p in plan:
        try:
            planned += int(p.get("word_target") or 0)
        except Exception:
            pass
        for need in ("section_id", "title"):
            if not p.get(need):
                fails.append("outline_plan entry missing %s" % need)
    if target_total:
        diff = abs(planned - target_total) / float(target_total)
        if diff > TOTAL_TOLERANCE:
            fails.append("outline word budgets sum to %d but total_words_target is %d "
                         "(%.0f%% off, tolerance %d%%)"
                         % (planned, target_total, diff * 100, int(TOTAL_TOLERANCE * 100)))
        else:
            passes.append("outline budgets sum %d vs target %d (within tolerance)"
                          % (planned, target_total))
    elif plan:
        warns.append("no total_words_target given; word-budget arithmetic not checked")

    # gate 2: every planned section has a body close to its target
    body = {str(c.get("section_id")): str(c.get("text") or "") for c in chapters}
    missing_bodies = [str(p.get("section_id")) for p in plan
                      if not body.get(str(p.get("section_id")))]
    if missing_bodies:
        fails.append("planned section(s) have no body in draft.chapters: "
                     + ", ".join(missing_bodies[:8]))
    for p in plan:
        sid = str(p.get("section_id"))
        want = p.get("word_target")
        got = words_of(body.get(sid) or "")
        try:
            want = int(want) if want not in (None, "") else 0
        except Exception:
            want = 0
        if want and got:
            if abs(got - want) / float(want) > WORD_TOLERANCE:
                warns.append("%s body is %d words vs target %d (>%.0f%% off)"
                             % (sid, got, want, WORD_TOLERANCE * 100))

    # gate 3 + 4: revision records, one per target, verbatim original_quote
    if targets:
        got_ids = [str(r.get("target_id")) for r in records]
        missing = [t for t in targets if t not in got_ids]
        dupes = sorted({t for t in got_ids if got_ids.count(t) > 1})
        if missing:
            fails.append("workorder target(s) without an annotation: " + ", ".join(missing))
        if dupes:
            fails.append("multiple annotations for the same target (merge not allowed): "
                         + ", ".join(dupes))
        if not missing and not dupes:
            passes.append("all %d workorder target(s) have exactly one annotation" % len(targets))
    if not records:
        fails.append("revision_records is empty; each target needs an annotation")
    for i, r in enumerate(records):
        tag = str(r.get("target_id") or "revision_records[%d]" % i)
        if not str(r.get("annotation") or "").strip():
            fails.append("%s has an empty annotation" % tag)
        if r.get("status") not in ANNOT_STATUS:
            fails.append("%s status=%r not in %s" % (tag, r.get("status"), list(ANNOT_STATUS)))
        q = r.get("original_quote")
        if not q:
            fails.append("%s missing original_quote (the source text you are annotating)" % tag)
        elif corpus and normalise(q) not in corpus:
            fails.append("%s original_quote is not verbatim in the source" % tag)

    # gate 5: six consistency dimensions covered
    cats = {str(f.get("category")) for f in findings if f.get("category")}
    absent = [c for c in DIMENSIONS if c not in cats]
    if absent:
        fails.append("consistency_report does not cover dimension(s): " + ", ".join(absent))
    else:
        passes.append("consistency_report covers all %d dimensions" % len(DIMENSIONS))
    valid_sections = {str(s.get("section_id")) for s in index.get("sections", [])}
    for i, f in enumerate(findings):
        tag = str(f.get("issue_id") or "consistency[%d]" % i)
        if f.get("category") not in DIMENSIONS:
            fails.append("%s category=%r not in %s" % (tag, f.get("category"), list(DIMENSIONS)))
        if f.get("severity") not in SEVERITY:
            fails.append("%s severity=%r not in %s" % (tag, f.get("severity"), list(SEVERITY)))
        if not f.get("locator"):
            fails.append("%s missing locator" % tag)
        q = f.get("quote")
        if not q:
            warns.append("%s has no quote; a finding without evidence is hard to review" % tag)
        elif corpus and normalise(q) not in corpus:
            warns.append("%s quote is not verbatim in the source" % tag)
        for a in (f.get("affected") or []):
            if valid_sections and str(a) not in valid_sections:
                warns.append("%s affected section %r is not a known section" % (tag, a))

    # receipts
    if targets:
        got = [str(r.get("target_id")) for r in receipts]
        missing = [t for t in targets if t not in got]
        if missing:
            fails.append("workorder target(s) without an operation receipt: "
                         + ", ".join(missing))
        for r in receipts:
            if r.get("status") not in RECEIPT_STATUS:
                fails.append("receipt for %r status=%r not in %s"
                             % (r.get("target_id"), r.get("status"), list(RECEIPT_STATUS)))

    # change log
    for i, c in enumerate(d.get("change_log") or []):
        tag = c.get("change_id") or "change_log[%d]" % i
        for need in ("original", "revised", "reason"):
            if c.get(need) in (None, ""):
                fails.append("%s missing %s" % (tag, need))

    return {"passed": not fails, "fails": fails, "warnings": warns, "passes": passes,
            "counts": {"sections": len(plan), "chapters": len(chapters),
                       "targets": len(targets), "records": len(records),
                       "findings": len(findings), "planned_words": planned,
                       "target_total": target_total}}


def cmd_check(args):
    report = run_checks(args)
    try:
        jdump(Path(args.work) / "check_report.json", report)
    except Exception:
        pass
    print(json.dumps({"passed": report["passed"], "FAIL": report["fails"],
                      "WARN": report["warnings"], "PASS": report["passes"],
                      "counts": report.get("counts", {})}, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- build


def cmd_build(args):
    work, out = Path(args.work), Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    deg, err = [], []
    case = jload(Path(args.input) / "case.json")
    if not isinstance(case, dict):
        case = {}
        deg.append("case.json missing or not a JSON object")
    index = jload(work / "index.json")
    if not isinstance(index, dict) or not index:
        deg.append("index.json absent; build ran init implicitly")
        try:
            cmd_init(args)
            index = jload(work / "index.json", {}) or {}
        except Exception as exc:
            err.append("implicit init failed: %s" % exc)
            index = {"materials": [], "sections": [], "targets": [], "meta": case_meta(case)}
    meta = index.get("meta") or case_meta(case)
    d = jload(Path(args.draft) if getattr(args, "draft", None) else (work / "draft.json"))
    if not isinstance(d, dict):
        deg.append("draft.json missing; produced degraded minimal deliverable")
        d = {}
    check_report = None
    if d:
        try:
            check_report = run_checks(args)
        except Exception as exc:
            deg.append("check failed during build: %s" % exc)

    plan = d.get("outline_plan") or []
    chapters = d.get("chapters") or []
    records = d.get("revision_records") or []
    receipts = d.get("operation_receipts") or []
    findings = d.get("consistency_report") or []
    targets = index.get("targets") or []
    # never silently drop a target
    have = {str(r.get("target_id")) for r in records}
    for t in targets:
        if t not in have:
            records.append({"target_id": t, "original_quote": "", "status": "needs_author",
                            "annotation": "not annotated in this run",
                            "reason": "not addressed in this run"})
            deg.append("target %s was not annotated; recorded as needs_author" % t)
    have_r = {str(r.get("target_id")) for r in receipts}
    for t in targets:
        if t not in have_r:
            receipts.append({"target_id": t, "status": "declined",
                             "artifact": "", "note": "not addressed in this run"})

    md_parts = []
    by_sid = {str(c.get("section_id")): str(c.get("text") or "") for c in chapters}
    for p in plan:
        md_parts.append("%s %s" % ("#" * max(1, int(p.get("level") or 2)), p.get("title")))
        body = by_sid.get(str(p.get("section_id"))) or ""
        md_parts.append(body or "<!-- section body not produced in this run -->")
    if not plan:
        md_parts = ["# Revised chapters", "",
                    "<!-- No outline plan or chapters were supplied; see result.json -->"]
    manuscript = "\n\n".join(md_parts).strip() + "\n"
    if not chapters:
        deg.append("no chapter bodies supplied; revised_chapters.md is a plan skeleton")

    fails = (check_report or {}).get("fails") or []
    status = "ok"
    if not d:
        status = "partial"
    elif fails:
        status = "partial"
        deg.append("%d mechanical check failure(s)" % len(fails))
    if not index.get("materials"):
        status = "input_error"
        err.append("no input materials were discovered")
    if not (plan and findings):
        if status == "ok":
            status = "partial"
        deg.append("outline_plan or consistency_report is empty")

    dims = {str(f.get("category")) for f in findings if f.get("category")}
    cov = {"required": len(plan) * len(DIMENSIONS),
           "parsed": len(plan) * len(dims & set(DIMENSIONS)),
           "missing": [d2 for d2 in DIMENSIONS if d2 not in dims]}

    deliverables = {}
    try:
        (out / "revised_chapters.md").write_text(manuscript, encoding="utf-8")
        deliverables["revised_chapters"] = "revised_chapters.md"
    except Exception as exc:
        err.append("revised_chapters.md failed: %s" % exc)
    for name, obj in (("outline_plan.json", plan), ("revision_records.json", records),
                      ("consistency_report.json", findings),
                      ("operation_receipts.json", receipts),
                      ("change_log.json", d.get("change_log") or []),
                      ("preserved_facts.json", d.get("preserved_facts") or [])):
        try:
            jdump(out / name, obj)
            deliverables[name.replace(".json", "")] = name
        except Exception as exc:
            err.append("%s failed: %s" % (name, exc))
    pre = jload(work / "prescan.json")
    if isinstance(pre, dict) and pre.get("findings") is not None:
        try:
            jdump(out / "prescan_findings.json", pre)
            deliverables["prescan_findings"] = "prescan_findings.json"
        except Exception as exc:
            err.append("prescan_findings.json failed: %s" % exc)

    doc = base_doc(meta, status, deg, err)
    doc.update({"case_id": d.get("case_id") or meta.get("case_id", ""),
                "deliverable": d.get("deliverable") or "revised_chapters.md",
                "outline_plan": plan, "revision_records": records,
                "consistency_report": findings, "operation_receipts": receipts,
                "change_log": d.get("change_log") or [],
                "preserved_facts": d.get("preserved_facts") or [],
                "chapters": chapters, "coverage": cov,
                "claims": d.get("claims") or [],
                "uncertainties": d.get("uncertainties") or [],
                "sources": [{k: m.get(k) for k in ("material_id", "path", "words")}
                            for m in index.get("materials", [])],
                "pending_human": d.get("pending_human") or [],
                "deliverables": deliverables})
    doc["result"] = {"outline_plan": plan, "revision_records": records,
                     "consistency_report": findings, "operation_receipts": receipts,
                     "coverage": cov, "deliverables": deliverables}
    if check_report:
        doc["self_check"] = {"passed": check_report.get("passed"),
                             "fail_count": len(fails)}
    try:
        (out / "report.md").write_text(build_report(doc, check_report, status),
                                       encoding="utf-8")
        deliverables["report"] = "report.md"
        doc["deliverables"] = deliverables
        doc["result"]["deliverables"] = deliverables
    except Exception as exc:
        err.append("report.md failed: %s" % exc)
    final = echo_contract(case.get("output_contract"), doc)
    try:
        jdump(out / "result.json", final)
    except Exception as exc:
        err.append("result.json write failed: %s" % exc)
    print(json.dumps({"ok": True, "command": "build", "status": status,
                      "case_id": final.get("case_id", ""),
                      "counts": {"sections": len(plan), "records": len(records),
                                 "findings": len(findings)},
                      "coverage": cov, "deliverables": deliverables,
                      "errors": err, "degradations": deg},
                     ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- cli
def add_io(p):
    for n in ("input", "work", "output"):
        p.add_argument("--" + n, default=argparse.SUPPRESS, help=n + " dir")


def build_parser():
    ap = argparse.ArgumentParser(
        prog="longform-editor",
        description="Section revision and cross-chapter consistency for long documents.",
        epilog="Flow: init -> outline -> show -> (draft) -> check -> build")
    ap.add_argument("--input", default=os.environ.get("INPUT_DIR", "/input"))
    ap.add_argument("--work", default=os.environ.get("WORK_DIR", "/app/work"))
    ap.add_argument("--output", default=os.environ.get("OUTPUT_DIR", "/app/output"))
    ap.add_argument("--version", action="version", version="longform-editor " + VERSION)
    sub = ap.add_subparsers(dest="command")
    for name in ("init", "outline", "consistency", "prescan"):
        p = sub.add_parser(name)
        add_io(p)
    p = sub.add_parser("show", help="print a material")
    add_io(p)
    p.add_argument("--material")
    p.add_argument("--limit", type=int, default=0)
    for name, helptext in (("check", "validate draft"), ("build", "assemble deliverables"),
                           ("selfcheck", "re-run checks only")):
        p = sub.add_parser(name, help=helptext)
        add_io(p)
        if name != "selfcheck":
            p.add_argument("--draft")
    return ap


def main(argv):
    ap = build_parser()
    try:
        args = ap.parse_args(argv)
    except SystemExit:
        return 0
    if not args.command:
        # bare invocation: derive everything from /input and finalize honestly
        args.command = "auto"
        cmd_init(args)
        cmd_prescan(args)
        cmd_build(args)
        return 0
    fn = {"init": cmd_init, "show": cmd_show, "outline": cmd_outline,
          "consistency": cmd_consistency, "prescan": cmd_prescan,
          "check": cmd_check, "build": cmd_build,
          "selfcheck": cmd_check}.get(args.command)
    return fn(args) if fn else 0


def emergency(argv):
    try:
        try:
            args, _ = build_parser().parse_known_args(argv)
        except SystemExit:
            args = None
        out = Path(getattr(args, "output", None) or "/app/output")
        out.mkdir(parents=True, exist_ok=True)
        if not (out / "revised_chapters.md").exists():
            (out / "revised_chapters.md").write_text("<!-- emergency finalize -->\n",
                                                     encoding="utf-8")
        if not (out / "result.json").exists():
            jdump(out / "result.json", {
                "case_id": "", "material_version": "", "status": "partial",
                "deliverable": "revised_chapters.md", "outline_plan": [],
                "revision_records": [], "consistency_report": [],
                "operation_receipts": [], "change_log": [], "preserved_facts": [],
                "chapters": [], "result": {}, "claims": [], "uncertainties": [],
                "coverage": {"required": 0, "parsed": 0, "missing": []},
                "sources": [], "pending_human": [], "errors": ["unhandled exception"],
                "degradations": ["emergency finalize"], "deliverables": {}})
    except Exception:
        pass


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except Exception:
        try:
            sys.stderr.write(traceback.format_exc())
        except Exception:
            pass
        emergency(sys.argv[1:])
    sys.exit(0)

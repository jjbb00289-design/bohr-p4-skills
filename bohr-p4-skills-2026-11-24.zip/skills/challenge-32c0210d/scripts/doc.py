#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Document utilities for longform-editor: IO helpers, section scanning, word counting,
metadata/workorder extraction and the human-readable report renderer.

Split out of main.py so the orchestrator stays under the 25KB guard. Pure stdlib.
"""
import json
import os
import re
from pathlib import Path

MAX_READ = 2_000_000

TEXT_SUFFIX = (".md", ".txt", ".tex", ".json", ".csv", ".tsv")

# Organizer "input repair v1": edit targets live in a standalone workorder file.
WORKORDER_FILES = ("organizer-edit-workorder.json", "organizer_edit_workorder.json")

CJK = re.compile(r"[\u4e00-\u9fff]")

WORD = re.compile(r"[A-Za-z][A-Za-z'-]*")

HEADING = re.compile(r"(?m)^(#{1,6})\s+(.+?)\s*$")


def jdump(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def jload(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig", errors="replace"))
    except Exception:
        return default


def normalise(t):
    if t is None:
        return ""
    return re.sub(r"\s+", " ", str(t).replace("\u3000", " ").replace("\xa0", " ")).strip().lower()


def read_text(path, limit=MAX_READ):
    try:
        raw = Path(path).read_bytes()[:limit]
    except Exception:
        return ""
    for enc in ("utf-8", "utf-16", "gb18030", "latin-1"):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("utf-8", "replace")


def words_of(text):
    t = text or ""
    return len(WORD.findall(t)) + len(CJK.findall(t))


def scan(input_dir):
    """Register materials and split each into heading-based sections."""
    mats, root = [], Path(input_dir)
    if not root.exists():
        return mats, ["input directory does not exist"]
    notes, n = [], 0
    files = []
    for dp, dns, fns in os.walk(str(root)):
        dns[:] = sorted(d for d in dns if d not in (".git", "__pycache__", "node_modules"))
        files += [Path(dp) / f for f in sorted(fns)]
    for p in files:
        try:
            if p.name.startswith("."):
                continue
            # case.json / task.md / workorder files are instructions, not chapters
            if p.parent == root and p.name in (("case.json", "task.md") + WORKORDER_FILES):
                continue
            if p.stat().st_size > MAX_READ:
                notes.append("%s skipped (>2MB)" % p.name)
                continue
        except Exception:
            continue
        n += 1
        mid = "m%d" % n
        e = {"material_id": mid, "path": p.relative_to(root).as_posix(),
             "suffix": p.suffix.lower(), "bytes": p.stat().st_size, "notes": []}
        if p.suffix.lower() in TEXT_SUFFIX:
            text = read_text(p)
            e["text_chars"] = len(text)
            e["words"] = words_of(text)
            sections = []
            hits = list(HEADING.finditer(text))
            for i, m in enumerate(hits):
                start = m.end()
                end = hits[i + 1].start() if i + 1 < len(hits) else len(text)
                body = text[start:end].strip()
                sections.append({"section_id": "m%d_s%d" % (n, i + 1),
                                 "title": m.group(2).strip(), "level": len(m.group(1)),
                                 "locator": "%s#%s" % (mid, "h%d" % (i + 1)),
                                 "words": words_of(body)})
            if not sections:
                sections = [{"section_id": "m%d_s1" % n, "title": p.stem, "level": 1,
                             "locator": "%s#p1" % mid, "words": e["words"]}]
            e["_sections"] = sections
            e["_text"] = text
        else:
            e["notes"].append("binary document: sections unavailable without a renderer")
            e["_sections"] = []
            e["_text"] = ""
        mats.append(e)
    return mats, notes


def case_meta(case):
    def pick(*ks):
        for k in ks:
            v = case.get(k)
            if v not in (None, ""):
                return v
        return ""
    return {"case_id": str(pick("case_id", "id", "caseId")),
            "material_version": str(pick("material_version", "version")),
            "total_words_target": pick("total_words_target", "total_words", "word_limit")}


def _ids_of(items):
    ids = []
    for item in items:
        if isinstance(item, dict):
            tid = item.get("target_id") or item.get("id") or item.get("target")
            if tid:
                ids.append(str(tid))
        elif isinstance(item, str):
            ids.append(item)
    return ids


def load_workorder(input_dir, case):
    """Return (items, ids, notes). Items keep the full workorder entries so the
    per-target instructions stay visible; ids drive the one-to-one gate."""
    for key in ("organizer_edit_workorder", "workorder", "targets", "edit_workorder"):
        val = case.get(key) if isinstance(case, dict) else None
        if isinstance(val, list) and val:
            ids = _ids_of(val)
            if ids:
                return val, ids, []
    if input_dir is None:
        return [], [], []
    for name in WORKORDER_FILES:
        data = jload(Path(input_dir) / name)
        candidates = []
        if isinstance(data, list):
            candidates = [data]
        elif isinstance(data, dict):
            candidates = [data.get(k) for k in
                          ("targets", "organizer_edit_workorder", "workorder",
                           "edit_targets", "items", "edit_workorder")]
        for val in candidates:
            if isinstance(val, list) and val:
                ids = _ids_of(val)
                if ids:
                    return val, ids, ["workorder loaded from %s" % name]
    return [], [], []


def workorder_ids(case):
    return load_workorder(None, case)[1]


# --------------------------------------------------------------------------- prescan
# Mechanical consistency leads. Every finding carries a verbatim quote from the
# source line it was derived from, so it can be dropped into the draft after
# verification. These are leads, not verdicts: the author must confirm each one.
CITEPAT = re.compile(r"\[([0-9]+(?:\s*[-,–]\s*[0-9]+)*)\]")
REFPAT = re.compile(r"(?m)^\s*\[([0-9]+)\]\s*\S")
ABBRPAT = re.compile(r"\b([A-Z][A-Z0-9]{2,7})\b")
CAPTION = re.compile(r"^\s*(图|表|Figure|Fig\.?|Table)\s*([0-9]+)")

COMMON_WORDS = {"THE", "AND", "FOR", "WITH", "FROM", "THIS", "THAT", "ARE", "NOT",
                "ALL", "CAN", "HAS", "WAS", "ITS", "OUR", "WE", "IN", "ON", "OF",
                "TO", "IS", "AS", "AT", "BY", "OR", "AN", "BE", "IF", "IT", "NO"}


def _cite_nums(s):
    out = set()
    for grp in s.split(","):
        grp = grp.strip()
        m = re.match(r"^(\d+)\s*[-–]\s*(\d+)$", grp)
        if m:
            out.update(range(int(m.group(1)), int(m.group(2)) + 1))
        elif grp.isdigit():
            out.add(int(grp))
    return out


def prescan(mats, max_findings=60):
    """Scan registered materials (with _text) for mechanical consistency leads."""
    findings = []
    for m in mats:
        text = m.get("_text") or ""
        if not text:
            continue
        mid = m["material_id"]
        lines = text.splitlines()

        def quote_of(lineno):
            return lines[lineno - 1].strip()[:220]

        # 1) numbering: duplicate captions and gaps in 图/表/Figure/Table sequences
        caps = {}
        for i, line in enumerate(lines, 1):
            cm = CAPTION.match(line)
            if cm:
                caps.setdefault((cm.group(1).rstrip("."), int(cm.group(2))), []).append(i)
        for (label, num), linenos in sorted(caps.items()):
            if len(linenos) > 1:
                findings.append({"category": "numbering", "locator": "%s#L%d" % (mid, linenos[1]),
                                 "quote": quote_of(linenos[1]),
                                 "hint": "%s %s  caption appears %d times (lines %s); possible duplicate number"
                                         % (label, num, len(linenos), ", ".join(map(str, linenos))),
                                 "suggested_severity": "medium"})
        by_label = {}
        for (label, num) in caps:
            by_label.setdefault(label, set()).add(num)
        for label, nums in sorted(by_label.items()):
            if len(nums) >= 2:
                missing = [n for n in range(min(nums), max(nums) + 1) if n not in nums]
                for n in missing[:5]:
                    first = min(caps[(label, x)][0] for x in nums)
                    findings.append({"category": "numbering", "locator": "%s#L%d" % (mid, first),
                                     "quote": quote_of(first),
                                     "hint": "%s sequence jumps over %d (has %s); check numbering continuity"
                                             % (label, n, ", ".join(map(str, sorted(nums)))),
                                     "suggested_severity": "low"})

        # 2) citation: [n] cited vs reference-list entries
        cited, cite_line, defined = set(), {}, {}
        for i, line in enumerate(lines, 1):
            rm = REFPAT.match(line)
            if rm:
                defined[int(rm.group(1))] = i
                continue  # a reference-list line is not a citation of itself
            for hit in CITEPAT.finditer(line):
                for n in _cite_nums(hit.group(1)):
                    cited.add(n)
                    cite_line.setdefault(n, i)
        for n in sorted(cited - set(defined))[:8]:
            line_no = cite_line[n]
            findings.append({"category": "citation", "locator": "%s#L%d" % (mid, line_no),
                             "quote": quote_of(line_no),
                             "hint": "[%d] is cited but no reference-list entry [%d] was found"
                                     % (n, n),
                             "suggested_severity": "high"})
        for n, i in sorted(defined.items()):
            if n not in cited:
                findings.append({"category": "citation", "locator": "%s#L%d" % (mid, i),
                                 "quote": quote_of(i),
                                 "hint": "reference [%d] is listed but never cited in this material" % n,
                                 "suggested_severity": "low"})

        # 3) terminology: abbreviations used repeatedly without an expansion "(ABBR)"
        counts, first_line = {}, {}
        for i, line in enumerate(lines, 1):
            for hit in ABBRPAT.finditer(line):
                tok = hit.group(1)
                if tok in COMMON_WORDS:
                    continue
                counts[tok] = counts.get(tok, 0) + 1
                first_line.setdefault(tok, i)
        for tok, c in sorted(counts.items()):
            expanded = ("(%s)" % tok) in text or ("（%s）" % tok) in text
            bare = c - text.count("(%s)" % tok) - text.count("（%s）" % tok)
            if bare >= 2 and not expanded:
                i = first_line[tok]
                findings.append({"category": "terminology", "locator": "%s#L%d" % (mid, i),
                                 "quote": quote_of(i),
                                 "hint": "abbreviation %s used %d times but never expanded as '... (%s)'; "
                                         "expand at first occurrence" % (tok, c, tok),
                                 "suggested_severity": "low"})
        if len(findings) >= max_findings:
            break
    return findings[:max_findings]


def build_report(doc, check_report, status):
    L = ["# Long-form revision report", "", "- case_id: `%s`" % doc["case_id"],
         "- status: `%s`" % status, "- deliverable: `%s`" % doc.get("deliverable"), "",
         "## Outline plan"]
    for p in doc.get("outline_plan") or []:
        L.append("- `%s` %s — %s words, role `%s`"
                 % (p.get("section_id"), p.get("title"), p.get("word_target"),
                    p.get("argument_role") or "-"))
    if not doc.get("outline_plan"):
        L.append("_None._")
    L += ["", "## Consistency findings"]
    for f in doc.get("consistency_report") or []:
        L.append("- `%s` [%s/%s] %s — affected: %s"
                 % (f.get("issue_id"), f.get("category"), f.get("severity"),
                    f.get("diagnosis") or "-", ", ".join(f.get("affected") or []) or "-"))
    if not doc.get("consistency_report"):
        L.append("_None._")
    L += ["", "## Revision records"]
    for r in doc.get("revision_records") or []:
        L.append("- `%s` [%s] %s" % (r.get("target_id"), r.get("status"),
                                     r.get("annotation")))
    if not doc.get("revision_records"):
        L.append("_None._")
    if check_report:
        L += ["", "## Self-check", "- passed: `%s`" % check_report.get("passed")]
        L += ["- FAIL: %s" % x for x in (check_report.get("fails") or [])[:30]]
    return "\n".join(L) + "\n"

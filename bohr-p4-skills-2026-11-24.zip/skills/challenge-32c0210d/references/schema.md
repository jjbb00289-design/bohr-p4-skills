# 字段定义与判据（长文档写作）

> 版本 1.1.0。字段只做追加，不改已有键名。
> 核心原则：**规划要算得回，注记要锚得住，诊断要指得到。**
> 1.1.0 追加：`index.json` 增 `target_items`（工单完整指令）；
> 新增 `prescan` 命令与产物 `prescan_findings.json`（机械一致性线索，需人工核对后使用）。

## 顶层

| 字段 | 必填 | 说明 |
|---|---|---|
| `case_id` | ✅ | 原样取自 `/input/case.json` |
| `deliverable` | ✅ | `"revised_chapters.md"` |
| `outline_plan` | ✅ | 章节规划（见 §1） |
| `revision_records` | ✅ | 逐 target 注记（见 §2） |
| `operation_receipts` | ✅ | 逐 target 回执（见 §3） |
| `consistency_report` | ✅ | 六维一致性发现（见 §4） |
| `change_log` | ✅ | 改动留痕 |
| `preserved_facts` | | 数字/符号等保全 |
| `coverage` | ✅ | `{required, parsed, missing}`，按 章节 × 维度 计 |
| `claims` / `uncertainties` / `sources` / `pending_human` | ✅ | 契约字段 |
| `errors` / `degradations` | ✅ | 空数组也要有 |
| `deliverables` | | 产物文件名映射（含 `prescan_findings`，若跑过 `prescan`） |
| `self_check` | | `{passed, fail_count}` |

## 0. prescan_findings.json（1.1.0 追加）

`prescan` 的机械线索，字段：`category`（terminology/numbering/citation 之一）、
`locator`（`m1#L12` 材料+行号）、`quote`（**取自源文该行的逐字片段**，可直接过闸门 3）、
`hint`（怀疑什么）、`suggested_severity`、`needs_verification: true`。

使用规则：逐条回原文核对 → 确认的改写为 `consistency_report` 条目（补 `issue_id/severity/
diagnosis/affected/fix`）；不成立的丢弃。**禁止**把 prescan 条目原样当最终发现。

`result` 内另存 `{outline_plan, revision_records, consistency_report, operation_receipts, coverage, deliverables}`。

## 1. outline_plan[i]

| 字段 | 必填 | 说明 |
|---|---|---|
| `section_id` | ✅ | 与 `chapters[].section_id` 对应（`init` 会给出 `m1_s1` 这类 id） |
| `title` | ✅ | 章节标题 |
| `level` | | 标题层级 1–6 |
| `word_target` | ✅ | 该章目标字数 |
| `purpose` | | 这一章要解决什么 |
| `argument_role` | | `problem` / `gap` / `method` / `result` / `discussion` / `conclusion` |

**门禁**：`sum(word_target)` 与 `total_words_target` 相差 ≤10%。
`argument_role` 是"论证链"的落点——有了它，评审能看出问题→方法→结果→结论是否闭环。

## 2. revision_records[i]

| 字段 | 必填 | 说明 |
|---|---|---|
| `target_id` | ✅ | 必须来自 workorder；**每个 target 恰好一条** |
| `original_quote` | ✅ | 被注记的**原文逐字片段** |
| `annotation` | ✅ | 注记内容（诊断/建议/已做修改），非空 |
| `status` | ✅ | `annotated` / `needs_author` / `declined` |
| `reason` | | 为什么这样处理 |

**门禁**：`original_quote` 必须逐字命中源文。这条规则的作用是把注记钉在真实文本上——
自己复述一段"大概意思"就过不了。

## 3. operation_receipts[i]

| 字段 | 必填 | 说明 |
|---|---|---|
| `target_id` | ✅ | 与注记一一对应 |
| `status` | ✅ | `done` / `partial` / `declined` |
| `artifact` | | 产物位置（`revised_chapters.md#L40`） |
| `note` | | `declined` 时必写原因 |

`build` 会为漏掉的 target 自动补一条 `declined` 回执，**并记 `degradations`**——
宁可显式声明没做，也不静默漏项。

## 4. consistency_report[i]（六维）

| 字段 | 必填 | 说明 |
|---|---|---|
| `issue_id` | | `i1` |
| `category` | ✅ | `terminology` / `symbol` / `definition` / `numbering` / `citation` / `conclusion` |
| `severity` | ✅ | `high` / `medium` / `low` |
| `locator` | ✅ | 问题所在（`m1#h2`） |
| `quote` | 建议 | 支撑该发现的逐字原文 |
| `diagnosis` | 建议 | 问题是什么、为什么是问题 |
| `affected` | 建议 | 受影响的其他 `section_id`（**影响面**） |
| `fix` | 建议 | 建议怎么改 |

### 六个维度各自查什么

| category | 典型问题 |
|---|---|
| `terminology` | 同一概念多个译名/缩写；缩写首次出现未展开 |
| `symbol` | 同一符号表示不同量；符号未定义就使用；上下标不一致 |
| `definition` | 同一术语在不同章定义不一致；定义与研究问题不匹配 |
| `numbering` | 图/表/公式编号跳号或重号；交叉引用指向错号 |
| `citation` | 同一文献两种写法；引用编号与参考文献表不对应；漏引 |
| `conclusion` | 结论超出数据范围；摘要与正文结论不一致；跨章结论互相矛盾 |

**某维确实没问题时**，仍要写一条：`severity: "low"`、`diagnosis: "本类未发现问题"`，
并给一条证据 `quote`（例如"全文统一使用 'Catalyst A'"）。缺维度 = FAIL。

## 5. change_log[i]

`change_id` / `original` / `revised` / `reason` / `locator`。
记录**局部改动**，不是整章重写。

## 6. 常见 FAIL 与修法

| FAIL | 原因 | 修法 |
|---|---|---|
| `outline budgets sum to N but total_words_target is M` | 字数分配算错 | 调 `word_target` 让合计落进 ±10% |
| `planned section(s) have no body in draft.chapters` | 规划章节没正文 | 补 `chapters` 条目 |
| `workorder target(s) without an annotation: T2` | 漏 target | 补注记 |
| `multiple annotations for the same target` | 合并了两条 | 拆成两条 |
| `T1 original_quote is not verbatim in the source` | 自己改写了原文 | 回 `show` 逐字复制 |
| `consistency_report does not cover dimension(s): symbol` | 缺维度 | 补该维（无问题也要写） |
| `category='style' not in [...]` | 用了别的维度名 | 用六枚举 |
| `ch1 missing reason` | 改动无理由 | 补四要素 |

## 7. 不适用与边界

- **不适用**：只需写一个全新章节（不是修订）、单篇短文润色、无源材料。
- **明确不做**：把分章材料说成"已完成论文"；编造缺失章节内容；把两条 target 合并；
  交整篇自由改写稿（那不是"改得动"）。
- 缺材料一律进 `pending_human`，`status` 用 `partial`。

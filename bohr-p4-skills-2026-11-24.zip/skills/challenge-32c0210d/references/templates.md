# 可复用模板（术语表 / 引用绑定表 / 章节检查清单 / 改稿记录）

> 版本 1.1.0。四张表均可直接复制使用：填表即产出 `draft.json` 所需的结构化内容，
> 也可独立作为长文档写作的过程资产。所有 quote 必须逐字复制自源文。

## 1. 术语表模板（terminology glossary）

用途：维护跨章节术语、缩写、符号的唯一写法，对应 `terminology` 与 `symbol` 两维。

| term_id | 标准写法 | 英文/全称 | 缩写 | 首次定义位置（locator） | 变体写法（禁用） | 出现章节 | 状态 |
|---|---|---|---|---|---|---|---|
| g1 | 多层筛选 | Multi-layer screening | MLS | m1#h1 | Multi-Layer Screening / ML screening | m1_s1, m2_s1 | confirmed |

填表规则：

- 每个概念一行；同一概念只保留一个"标准写法"，其余写法记入"变体写法（禁用）"。
- 缩写首次出现必须有"全称（缩写）"形式；`prescan` 报的"缩写未展开"线索在此销号。
- `首次定义位置` 用 `材料#标题` 或 `材料#L行号`；找不到定义位置 → 状态写 `undefined`，
  并进 `pending_human`。
- 改术语时，把所有"出现章节"列入该发现的 `affected`，这就是改动影响面。

## 2. 引用绑定表模板（citation binding）

用途：把每条论断钉在具体文献上，对应 `citation` 维与"查得清"。

| claim_id | 论断（压缩陈述） | 所在章节 | 文献编号 | 文献著录 | 支撑句逐字 quote | locator | 绑定状态 |
|---|---|---|---|---|---|---|---|
| c1 | 浸渍法制得 Catalyst A | m1_s1 | [1] | Smith et al., 2020 | "Catalyst A was prepared by impregnation." | m1#L3 | bound |

绑定状态枚举：`bound`（论断与文献支撑句对得上）/ `weak`（文献相关但不直接支撑）/
`missing`（论断无文献）/ `phantom`（引了不存在的条目）/ `rewritten`（引用后结论被改写）。

填表规则：

- `支撑句逐字 quote` 必须逐字命中源文（`check` 闸门 3 会验证），不许复述。
- `missing` 与 `phantom` 各写一条 `consistency_report` 发现，`severity` 至少 `medium`。
- 数字、单位、符号随 quote 逐字复用，禁止四舍五入或改写法。

## 3. 章节检查清单模板（per-section checklist）

每章过一遍，六维各落一条（无问题写"本类未发现问题" + 一条证据 quote）：

| 维度 | 检查问题 | 本章结果 | 证据 locator | 证据 quote |
|---|---|---|---|---|
| terminology | 本章术语/缩写是否与术语表一致？首次出现是否展开？ | | | |
| symbol | 每个符号是否在首次出现处定义？与别章同符号是否同义？ | | | |
| definition | 本章定义与首次定义是否逐字或同义一致？有无重复定义？ | | | |
| numbering | 图/表/式编号是否连续无重号？交叉引用是否指向存在的编号？ | | | |
| citation | 本章 [n] 是否都在参考文献表有条目？著录格式是否统一？ | | | |
| conclusion | 本章结论是否超出其数据范围？与摘要/他章结论是否一致？ | | | |

完成标志：六行全部填了 locator；发现的问题已转成 `consistency_report` 条目。

## 4. 改稿记录模板（change log）

| change_id | locator | original（逐字原句） | revised（改后句） | reason | 关联 target | 影响面 affected |
|---|---|---|---|---|---|---|
| ch1 | m1#h2 | prepared by impregnation | prepared by wet impregnation on support B | 补足可复现信息 | T1 | m1_s2 |

填表规则：

- 一行一处局部改动；整段重写拆成多行，每行可独立回退。
- `original` 逐字复制；`revised` 保留作者术语与数字。
- `影响面` 填改动会牵动的其他 section_id；拿不准就回 `consistency_report` 的 `affected` 查。

## 5. 与 draft.json 的对应

| 模板 | draft.json 字段 |
|---|---|
| 术语表 | `consistency_report`（terminology/symbol/definition 维）+ `preserved_facts` |
| 引用绑定表 | `consistency_report`（citation 维）+ `preserved_facts` |
| 章节检查清单 | `consistency_report` 六维全覆盖的来源 |
| 改稿记录 | `change_log`（四要素 + locator） |

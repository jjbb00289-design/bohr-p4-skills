# 最小调用示例（示例，非正式案例结果）

> ⚠️ **人工构造的演示示例，不是平台固定案例的结果，也不来自任何真实学位论文。**

## 1. 假设输入（虚构）

`/input/case.json`：

```json
{"case_id": "demo-long", "total_words_target": 30,
 "organizer_edit_workorder": [{"target_id": "T1"}, {"target_id": "T2"}],
 "output_contract": {"case_id": "string", "deliverable": "string",
                     "outline_plan": "array", "revision_records": "array",
                     "consistency_report": "array", "operation_receipts": "array"}}
```

`materials/ch1.md`（虚构）：

```markdown
# Introduction

Catalyst A was prepared by impregnation.

# Results

Catalyst A reached 87.4 % conversion.
```

`materials/ch2.md`（虚构）：

```markdown
# Discussion

The symbol k denotes the rate constant.
```

## 2. 调用

```bash
python3 scripts/main.py init
# → 3 sections: m1_s1 Introduction / m1_s2 Results / m2_s1 Discussion
# → targets: T1, T2 ; total_words_target: 30
python3 scripts/main.py prescan
# → 机械线索（本例可能报：citation [n] 缺条目、缩写未展开），逐条回原文核对
python3 scripts/main.py outline
python3 scripts/main.py consistency
python3 scripts/main.py show --material m1
```

## 3. 工作稿（虚构）

```json
{
  "case_id": "demo-long", "deliverable": "revised_chapters.md",
  "total_words_target": 30,
  "outline_plan": [
    {"section_id": "m1_s1", "title": "Introduction", "level": 1, "word_target": 10,
     "purpose": "交代材料与制备", "argument_role": "method"},
    {"section_id": "m1_s2", "title": "Results", "level": 1, "word_target": 10,
     "purpose": "给出转化率", "argument_role": "result"},
    {"section_id": "m2_s1", "title": "Discussion", "level": 1, "word_target": 10,
     "purpose": "定义符号", "argument_role": "discussion"}
  ],
  "chapters": [
    {"section_id": "m1_s1", "text": "Catalyst A was prepared by wet impregnation on support B."},
    {"section_id": "m1_s2", "text": "Catalyst A reached 87.4 % conversion in the test reaction."},
    {"section_id": "m2_s1", "text": "Here k denotes the pseudo-first-order rate constant."}
  ],
  "revision_records": [
    {"target_id": "T1", "original_quote": "Catalyst A was prepared by impregnation.",
     "annotation": "补充载体与浸渍方式（需作者确认 B 的牌号）",
     "status": "annotated", "reason": "方法可复现性"},
    {"target_id": "T2", "original_quote": "The symbol k denotes the rate constant.",
     "annotation": "建议明确为 pseudo-first-order 速率常数，并与式 (2) 符号统一",
     "status": "annotated", "reason": "符号一致性"}
  ],
  "operation_receipts": [
    {"target_id": "T1", "status": "done", "artifact": "revised_chapters.md#L3"},
    {"target_id": "T2", "status": "done", "artifact": "revised_chapters.md#L9"}
  ],
  "consistency_report": [
    {"issue_id": "i1", "category": "terminology", "severity": "low",
     "locator": "m1#h1", "quote": "Catalyst A was prepared by impregnation.",
     "diagnosis": "本类未发现问题：全文统一使用 Catalyst A", "affected": [], "fix": "无需修改"},
    {"issue_id": "i2", "category": "symbol", "severity": "high",
     "locator": "m2#h1", "quote": "The symbol k denotes the rate constant.",
     "diagnosis": "k 未指明是几级速率常数，与 Results 的拟合口径可能不一致",
     "affected": ["m1_s2"], "fix": "统一为 pseudo-first-order k 并在首次出现处定义"},
    {"issue_id": "i3", "category": "definition", "severity": "low",
     "locator": "m2#h1", "quote": "The symbol k denotes the rate constant.",
     "diagnosis": "本类未发现问题：仅一处定义", "affected": [], "fix": "无需修改"},
    {"issue_id": "i4", "category": "numbering", "severity": "low",
     "locator": "m1#h2", "quote": "Catalyst A reached 87.4 % conversion.",
     "diagnosis": "本类未发现问题：本章无图表编号", "affected": [], "fix": "无需修改"},
    {"issue_id": "i5", "category": "citation", "severity": "medium",
     "locator": "m1#h1", "quote": "Catalyst A was prepared by impregnation.",
     "diagnosis": "制备方法未给文献出处", "affected": ["m1_s1"], "fix": "补一条制备方法引用"},
    {"issue_id": "i6", "category": "conclusion", "severity": "medium",
     "locator": "m1#h2", "quote": "Catalyst A reached 87.4 % conversion.",
     "diagnosis": "仅单次测试即给结论，缺重复数与误差，结论强度偏高",
     "affected": ["m2_s1"], "fix": "补 n 与误差，或把结论收窄到'本次测试中'"}
  ],
  "change_log": [
    {"change_id": "ch1", "original": "prepared by impregnation",
     "revised": "prepared by wet impregnation on support B",
     "reason": "补足可复现信息", "locator": "m1#h1"}
  ],
  "preserved_facts": [
    {"fact_id": "f1", "value": "87.4", "unit": "%", "locator": "m1#h2",
     "quote": "Catalyst A reached 87.4 % conversion.", "status": "preserved"}
  ],
  "uncertainties": [{"item": "support B 的牌号", "why": "原文未说明"}],
  "pending_human": ["确认载体牌号"]
}
```

## 4. 产物

```
/app/output/
  result.json
  revised_chapters.md
  outline_plan.json
  revision_records.json
  consistency_report.json
  operation_receipts.json
  change_log.json
  preserved_facts.json
  report.md
```

## 5. 被 check 拦住的写法

| 写法 | check 反应 |
|---|---|
| `word_target` 合计 50 而 target 30 | `outline word budgets sum to 50 but total_words_target is 30` |
| 规划里 `m1_s2` 没写正文 | `planned section(s) have no body in draft.chapters: m1_s2` |
| 只注记 T1 | `workorder target(s) without an annotation: T2` |
| 给 T1 写了两条注记 | `multiple annotations for the same target (merge not allowed): T1` |
| `original_quote` 自己改写 | `T1 original_quote is not verbatim in the source` |
| 只报 4 类 | `consistency_report does not cover dimension(s): numbering, citation` |
| `category: "style"` | `consistency[0] category='style' not in [...]` |
| 漏 T2 回执 | `workorder target(s) without an operation receipt: T2` |

## 6. 降级示例

### 无工作稿直接 build

```json
{"ok": true, "command": "build", "status": "partial",
 "degradations": ["draft.json missing; produced degraded minimal deliverable",
                  "target T1 was not annotated; recorded as needs_author",
                  "target T2 was not annotated; recorded as needs_author",
                  "outline_plan or consistency_report is empty"]}
```

`build` 会为每个漏掉的 target **自动补一条 `needs_author` 注记 + `declined` 回执**并记降级，
所以产物里不会静默少 target。九件产物齐全，契约键零缺失，退出码 0。

### case 没给 workorder

`init` 记 `no workorder targets in case.json; revision_records must still be authored`。
此时 `check` 不做 target 一对一校验，但仍要求 `revision_records` 与 `consistency_report` 非空。

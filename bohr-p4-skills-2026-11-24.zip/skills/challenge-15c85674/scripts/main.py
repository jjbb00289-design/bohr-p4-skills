#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""literature-qa -- evidence-bearing question answering over one scientific paper.

Commands: init | show | find | check | build | selfcheck

Contract (this challenge):
  primary product  /app/output/result.json   (current adaptation)
  legacy product   /app/answers.json         (original path, kept in sync)
  traceability     /app/output/content_map.json (question -> claim -> evidence locator)
  required fields  case_id / paper_id / material_version / answers[] / claims[] /
                   unanswered_parts[] / coverage
  answer.status    answered | partial | insufficient_evidence | input_error
  claim.kind       reported | inferred
  evidence         {material, paragraph_id, section, quote} -- quote is verbatim

Pure stdlib, no network, CWD independent, always exits 0, always leaves a valid result.
"""
import argparse
import json
import os
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from textproc import (dump, load, read_text, norm, tokens, CN_EN, expand_cn,
                      parse_paragraphs, split_table_blocks, find_materials, find_questions,
                      meta_of)

VERSION = "1.1.0"
ANS_STATUS = ("answered", "partial", "insufficient_evidence", "input_error")
CLAIM_KINDS = ("reported", "inferred")


# --------------------------------------------------------------------------- contract
def echo_contract(contract, base):
    final, missing = {}, []
    if isinstance(contract, dict):
        res = base.get("result") if isinstance(base.get("result"), dict) else {}
        for key in contract.keys():
            if key in base:
                final[key] = base[key]
            elif key in res:
                final[key] = res[key]
            else:
                final[key] = None
                missing.append(key)
    final.update(base)
    if missing:
        base.setdefault("degradations", []).append(
            "output_contract keys filled as null: " + ", ".join(missing))
        for key in missing:
            final[key] = None
    return final


def base_doc(meta, status, deg, err):
    return {"case_id": meta.get("case_id", ""), "paper_id": meta.get("paper_id", ""),
            "material_version": meta.get("material_version", ""), "status": status,
            "answers": [], "claims": [], "unanswered_parts": [],
            "coverage": {"read_sections": [], "unread_sections": [], "reasons": []},
            "result": {}, "uncertainties": [], "sources": [], "pending_human": [],
            "errors": err, "degradations": deg, "deliverables": {},
            "skill": {"name": "literature-qa", "version": VERSION}}


# --------------------------------------------------------------------------- init
def build_index(case, input_dir):
    """Index all text materials + questions. Returns (index, deg, err)."""
    deg, err = [], []
    meta = meta_of(case)
    if not meta["paper_id"]:
        meta["paper_id"] = meta["case_id"]
    materials = find_materials(case, input_dir)
    questions = find_questions(case, input_dir)
    if not materials:
        deg.append("no paper/material text found under input dir")
    if not questions:
        deg.append("no question list found; answers[] will be empty")
    paragraphs = []
    tag = ""
    for mi, m in enumerate(materials):
        mid = m["material_id"]
        is_csv = mid.lower().endswith((".csv", ".tsv"))
        prefix = ""
        if mi > 0:
            base = "".join(c for c in Path(mid).stem if c.isalnum())[:3].upper() or ("M%d" % mi)
            prefix = base
        if is_csv:
            blocks = split_table_blocks(m["text"], mid, prefix)
        else:
            blocks = parse_paragraphs(m["text"], mid, prefix)
        paragraphs.extend(blocks)
    index = {"version": VERSION, "meta": meta,
             "materials": [{"material_id": m["material_id"], "path": m["path"],
                            "chars": len(m["text"]), "is_primary": bool(m.get("is_primary"))}
                           for m in materials],
             "paragraphs": paragraphs, "questions": questions,
             "counts": {"materials": len(materials), "paragraphs": len(paragraphs),
                        "questions": len(questions)}}
    return index, deg, err


def cmd_init(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    case = load(Path(args.input) / "case.json")
    if not isinstance(case, dict):
        case = {}
    index, deg, err = build_index(case, args.input)
    dump(work / "index.json", index)
    meta = index["meta"]
    cov = {"read_sections": [], "unread_sections": [],
           "reasons": ["index built; answers not yet written by the agent"]}
    status = "input_error" if (not index["paragraphs"] or not index["questions"]) else "partial"
    doc = base_doc(meta, status, deg, err)
    doc["coverage"] = cov
    doc["result"] = {"answers": [], "claims": [], "unanswered_parts": [], "coverage": cov}
    final = echo_contract(case.get("output_contract"), doc)
    dump(out / "result.json", final)
    if not (out / "answers.json").exists():
        dump(out / "answers.json", final)
    print(json.dumps({
        "ok": True, "command": "init", "meta": meta, "status": status,
        "counts": index["counts"],
        "materials": [m["material_id"] for m in index["materials"]],
        "questions": [{"question_id": q["question_id"], "question": q["question"][:80]}
                      for q in index["questions"]],
        "paragraph_ids_sample": [p["paragraph_id"] for p in index["paragraphs"][:8]],
        "notes": deg,
        "next": "run `show` to read paragraphs, `find --question Q1` for candidate evidence, "
                "write work/draft.json, then `check` and `build`",
    }, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- show / find
def cmd_show(args):
    work = Path(args.work)
    index = load(work / "index.json", {}) or {}
    if args.question:
        t = next((q for q in index.get("questions", [])
                  if q["question_id"] == args.question), None)
        print(json.dumps(t or {"error": "unknown question id: %s" % args.question},
                         ensure_ascii=False, indent=2))
        return 0
    if args.paragraph:
        p = next((x for x in index.get("paragraphs", [])
                  if x["paragraph_id"] == args.paragraph), None)
        if not p:
            print(json.dumps({"error": "unknown paragraph id: %s" % args.paragraph}))
            return 0
        print("=== [%s] %s | %s" % (p["paragraph_id"], p.get("material", ""),
                                    p.get("section") or "(no section)"))
        print(p["text"])
        return 0
    if args.list or not (args.grep or args.limit):
        print(json.dumps({"meta": index.get("meta", {}), "counts": index.get("counts", {}),
                          "materials": index.get("materials", []),
                          "questions": index.get("questions", []),
                          "paragraphs": [{"paragraph_id": p["paragraph_id"],
                                          "material": p.get("material", ""),
                                          "section": p.get("section"),
                                          "chars": len(p["text"]),
                                          "head": p["text"][:90]}
                                         for p in index.get("paragraphs", [])]},
                         ensure_ascii=False, indent=2))
        return 0
    shown = 0
    for p in index.get("paragraphs", []):
        if args.grep and not __import__("re").search(args.grep, p["text"], __import__("re").I):
            continue
        print("=== [%s] %s | %s | %s" % (p["paragraph_id"], p.get("material", ""),
                                         p.get("section") or "-", p["text"][:400]))
        shown += 1
        if args.limit and shown >= args.limit:
            break
    return 0


def cmd_find(args):
    """Rank paragraphs against a question (lexical + CN->EN stems). Shortlist only."""
    work = Path(args.work)
    index = load(work / "index.json", {}) or {}
    paras = index.get("paragraphs", [])
    qs = index.get("questions", [])
    if args.question:
        q = next((x for x in qs if x["question_id"] == args.question), None)
        if not q:
            print(json.dumps({"error": "unknown question id: %s" % args.question}))
            return 0
        query = q["question"] + " " + " ".join(q.get("sub_questions") or [])
        qid = q["question_id"]
    else:
        query, qid = args.query or "", ""
    qt = set(tokens(query))
    stems = expand_cn(query)
    scored = []
    for p in paras:
        pt = set(tokens(p["text"]))
        if not pt:
            continue
        overlap = qt & pt
        stem_hit = {s for s in stems if any(t.startswith(s) for t in pt)}
        denom = (len(qt | stems) ** 0.5) * (len(pt) ** 0.25) or 1.0
        score = (len(overlap) + len(stem_hit)) / denom
        if score > 0:
            scored.append({"paragraph_id": p["paragraph_id"], "material": p.get("material", ""),
                           "section": p.get("section"), "score": round(score, 3),
                           "matched_terms": sorted(overlap)[:8],
                           "matched_cn_terms": sorted(cn for cn, en in CN_EN.items()
                                                       if cn in query
                                                       and set(en.split()) & stem_hit)[:8],
                           "quote_hint": p["text"][:220]})
    scored.sort(key=lambda x: -x["score"])
    note = ("candidates are a shortlist, not evidence: read the paragraph and copy the quote "
            "verbatim into draft.claims[].evidence[].quote")
    if not scored and not (qt or stems):
        note = ("no searchable terms could be derived (English paper vs Chinese/short question); "
                "read paragraphs via `show --grep` or `show --paragraph Pn` instead")
    print(json.dumps({"question_id": qid, "query_terms": sorted(qt)[:20],
                      "query_cn_stems": sorted(stems)[:20],
                      "candidates": scored[:args.top], "note": note},
                     ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- check
def run_checks(args):
    work = Path(args.work)
    index = load(work / "index.json", {}) or {}
    draft = load(Path(args.draft) if args.draft else (work / "draft.json"))
    fails, warns, passes = [], [], []
    if not isinstance(draft, dict):
        return {"passed": False, "fails": ["draft.json missing or not a JSON object"],
                "warnings": [], "passes": [], "counts": {}}
    paras, questions = index.get("paragraphs", []), index.get("questions", [])
    materials = index.get("materials", [])
    by_para = {p["paragraph_id"]: p for p in paras}
    by_material = {m["material_id"]: m for m in materials}
    all_text = norm(" \n ".join(p["text"] for p in paras))
    meta = index.get("meta", {})

    for key in ("case_id", "paper_id", "material_version"):
        if not draft.get(key):
            (fails if meta.get(key) else warns).append(
                "draft.%s missing%s" % (key, " (input provides %r)" % meta[key]
                                        if meta.get(key) else " and input has none either"))

    answers, claims = draft.get("answers") or [], draft.get("claims") or []
    unanswered = draft.get("unanswered_parts") or []
    qids = [q["question_id"] for q in questions]
    got = [str(a.get("question_id")) for a in answers]
    if questions:
        missing = [q for q in qids if q not in got]
        if missing:
            fails.append("answers[] omits question(s): " + ", ".join(missing))
        else:
            passes.append("all %d question(s) answered or explicitly listed" % len(qids))
        extra = [q for q in got if q not in qids]
        if extra:
            warns.append("answers[] has unknown question_id(s): " + ", ".join(extra))
    for i, a in enumerate(answers):
        tag = str(a.get("question_id") or "answers[%d]" % i)
        if a.get("status") not in ANS_STATUS:
            fails.append("%s status=%r not in %s" % (tag, a.get("status"), list(ANS_STATUS)))
        if not str(a.get("answer") or "").strip():
            fails.append("%s has empty answer (say what is unreported instead of leaving blank)"
                         % tag)
        if "conditions" not in a:
            warns.append("%s has no conditions list" % tag)
        if a.get("status") in ("partial", "insufficient_evidence", "input_error"):
            mine = [u for u in unanswered
                    if str(u.get("question_id") or u.get("qid") or "") == tag]
            if not mine and not a.get("unanswered_parts"):
                warns.append("%s is %s but lists no unanswered_parts reason"
                             % (tag, a.get("status")))
    if not claims:
        fails.append("claims[] is empty; every key assertion needs paragraph_id + verbatim quote")
    for i, c in enumerate(claims):
        tag = str(c.get("claim_id") or "claims[%d]" % i)
        if c.get("kind") not in CLAIM_KINDS:
            fails.append("%s kind=%r not in %s" % (tag, c.get("kind"), list(CLAIM_KINDS)))
        if not str(c.get("text") or "").strip():
            fails.append("%s has no text" % tag)
        ev = c.get("evidence") or []
        if not ev:
            fails.append("%s has no evidence" % tag)
        for j, e in enumerate(ev):
            pid = str(e.get("paragraph_id") or "")
            if not pid:
                fails.append("%s.evidence[%d] missing paragraph_id" % (tag, j))
            elif pid not in by_para:
                fails.append("%s.evidence[%d] paragraph_id %r does not exist in the paper"
                             % (tag, j, pid))
            q = e.get("quote")
            if not q:
                fails.append("%s.evidence[%d] missing quote" % (tag, j))
            elif norm(q) not in all_text:
                fails.append("%s.evidence[%d] quote not verbatim in the paper" % (tag, j))
            elif pid in by_para and norm(q) not in norm(by_para[pid]["text"]):
                warns.append("%s.evidence[%d] quote is in the paper but not in %s"
                             % (tag, j, pid))
            if not e.get("material"):
                warns.append("%s.evidence[%d] has no material locator (add the source file id)"
                             % (tag, j))
            elif pid in by_para and e.get("material") != by_para[pid].get("material"):
                warns.append("%s.evidence[%d] material %r differs from %s's material %r"
                             % (tag, j, e.get("material"), pid, by_para[pid].get("material")))
            if not e.get("section"):
                warns.append("%s.evidence[%d] has no section tag" % (tag, j))
    cov = draft.get("coverage")
    if not isinstance(cov, dict) or cov.get("read_sections") is None:
        warns.append("coverage should state read_sections / unread_sections / reasons")
    return {"passed": not fails, "fails": fails, "warnings": warns, "passes": passes,
            "counts": {"questions": len(questions), "answers": len(answers),
                       "claims": len(claims), "paragraphs": len(paras),
                       "materials": len(materials)}}


def cmd_check(args):
    report = run_checks(args)
    try:
        dump(Path(args.work) / "check_report.json", report)
    except Exception:
        pass
    print(json.dumps({"passed": report["passed"], "FAIL": report["fails"],
                      "WARN": report["warnings"], "PASS": report["passes"],
                      "counts": report.get("counts", {})}, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- build
def build_report(doc, check_report, status):
    L = ["# Literature QA report", "", "- case_id: `%s`" % doc["case_id"],
         "- paper_id: `%s`" % doc["paper_id"],
         "- material_version: `%s`" % doc["material_version"],
         "- status: `%s`" % status, "", "## Answers"]
    for a in doc.get("answers") or []:
        L.append("### %s — `%s`" % (a.get("question_id"), a.get("status")))
        L.append(str(a.get("answer") or "").strip())
        for c in a.get("conditions") or []:
            L.append("- condition: %s" % c)
        for u in a.get("unanswered_parts") or []:
            L.append("- unanswered: %s" % u)
    if not doc.get("answers"):
        L.append("_No answers recorded; see unanswered_parts and coverage._")
    L += ["", "## Claims and evidence"]
    for c in doc.get("claims") or []:
        L.append("- `%s` [%s] %s" % (c.get("claim_id"), c.get("kind"), c.get("text")))
        for e in c.get("evidence") or []:
            L.append("  - evidence @ %s %s %s: \"%s\"" % (
                e.get("material", "?"), e.get("paragraph_id", "?"),
                e.get("section", "?"), e.get("quote")))
    if not doc.get("claims"):
        L.append("_None recorded._")
    L += ["", "## Unanswered parts"]
    L += (["- %s: %s%s" % (u.get("question_id"), u.get("reason"),
                           (" (needs: %s)" % u.get("needs")) if u.get("needs") else "")
           for u in doc.get("unanswered_parts") or []] or ["_None._"])
    cov = doc.get("coverage") or {}
    L += ["", "## Coverage", "- read: %s" % (cov.get("read_sections") or []),
          "- unread: %s" % (cov.get("unread_sections") or []),
          "- reasons: %s" % (cov.get("reasons") or [])]
    if check_report:
        L += ["", "## Self-check", "- passed: `%s`" % check_report.get("passed")]
        L += ["- FAIL: %s" % f for f in (check_report.get("fails") or [])[:30]]
    return "\n".join(L) + "\n"


def build_content_map(meta, answers, claims, index, out):
    """Traceability artifact: question -> claim -> evidence locator."""
    by_q = {a.get("question_id"): a for a in answers}
    mapping = []
    for q in index.get("questions", []):
        qid = q["question_id"]
        a = by_q.get(qid, {})
        # claims whose evidence references this question are linked by convention below;
        # here we simply attach every claim (answers are independent of claim ids), and
        # add a per-question evidence list from claims the agent tagged with question_id.
        linked = [c for c in claims if str(c.get("question_id")) == str(qid)]
        mapping.append({
            "question_id": qid,
            "question": q["question"],
            "status": a.get("status", "insufficient_evidence"),
            "answer": a.get("answer", ""),
            "conditions": a.get("conditions", []),
            "unanswered_parts": a.get("unanswered_parts", []),
            "linked_claims": [c.get("claim_id") for c in linked],
        })
    out_map = {
        "case_id": meta.get("case_id", ""), "paper_id": meta.get("paper_id", ""),
        "material_version": meta.get("material_version", ""),
        "inputs": {"materials": [m["material_id"] for m in index.get("materials", [])],
                   "questions": [q["question_id"] for q in index.get("questions", [])]},
        "mapping": mapping,
        "claims": [{"claim_id": c.get("claim_id"), "kind": c.get("kind"),
                    "text": c.get("text"),
                    "evidence": c.get("evidence", [])} for c in claims],
        "outputs": {"result": "result.json", "answers": "answers.json",
                    "report": "report.md", "content_map": "content_map.json"},
    }
    dump(out / "content_map.json", out_map)
    return out_map


def cmd_build(args):
    work, out = Path(args.work), Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    deg, err = [], []
    case = load(Path(args.input) / "case.json")
    if not isinstance(case, dict):
        case = {}
        deg.append("case.json missing or not a JSON object")
    index = load(work / "index.json")
    if not isinstance(index, dict) or not index:
        deg.append("index.json absent; build ran init implicitly")
        try:
            cmd_init(args)
            index = load(work / "index.json", {}) or {}
        except Exception as exc:
            err.append("implicit init failed: %s" % exc)
            index = {"meta": meta_of(case), "paragraphs": [], "questions": [], "materials": []}
    meta = index.get("meta") or meta_of(case)
    draft = load(Path(args.draft) if args.draft else (work / "draft.json"))
    if not isinstance(draft, dict):
        deg.append("draft.json missing; produced degraded minimal deliverable")
        draft = {}
    check_report = None
    if draft:
        try:
            check_report = run_checks(args)
        except Exception as exc:
            deg.append("check failed during build: %s" % exc)

    answers = draft.get("answers") or []
    claims = draft.get("claims") or []
    unanswered = list(draft.get("unanswered_parts") or [])
    questions = index.get("questions") or []
    got = {str(a.get("question_id")) for a in answers}
    for q in questions:
        if q["question_id"] not in got:
            answers.append({"question_id": q["question_id"], "answer": "",
                            "conditions": [], "status": "insufficient_evidence",
                            "unanswered_parts": ["not addressed in this run"]})
            unanswered.append({"question_id": q["question_id"],
                               "reason": "not addressed in this run",
                               "needs": "a paragraph-by-paragraph reading pass"})
            deg.append("question %s was not answered; recorded as insufficient_evidence"
                       % q["question_id"])
    cov = draft.get("coverage") if isinstance(draft.get("coverage"), dict) else {}
    read = cov.get("read_sections")
    if not isinstance(read, list):
        read = sorted({str(c.get("section")) for c in claims if c.get("section")}) or []
    cov = {"read_sections": read, "unread_sections": cov.get("unread_sections") or [],
           "reasons": cov.get("reasons") or []}
    fails = (check_report or {}).get("fails") or []
    status = "ok"
    if not draft:
        status = "partial"
    elif fails:
        status = "partial"
        deg.append("%d mechanical check failure(s)" % len(fails))
    if not (index.get("paragraphs") and questions):
        status = "input_error"
        err.append("paper text or question list missing")
    if not answers:
        if status == "ok":
            status = "partial"
        deg.append("answers[] is empty")

    doc = base_doc(meta, status, deg, err)
    doc.update({"case_id": draft.get("case_id") or meta.get("case_id", ""),
                "paper_id": draft.get("paper_id") or meta.get("paper_id", ""),
                "material_version": draft.get("material_version")
                or meta.get("material_version", ""),
                "answers": answers, "claims": claims, "unanswered_parts": unanswered,
                "coverage": cov, "uncertainties": draft.get("uncertainties") or [],
                "pending_human": draft.get("pending_human") or [],
                "sources": [{"material_id": m["material_id"], "path": m.get("path", ""),
                             "chars": m.get("chars", 0)} for m in index.get("materials", [])],
                "deliverables": {"result": "result.json", "answers": "answers.json",
                                 "report": "report.md", "content_map": "content_map.json"}})
    doc["result"] = {"answers": answers, "claims": claims, "unanswered_parts": unanswered,
                     "coverage": cov}
    if check_report:
        doc["self_check"] = {"passed": check_report.get("passed"),
                             "fail_count": len(fails),
                             "warn_count": len(check_report.get("warnings") or [])}
    final = echo_contract(case.get("output_contract"), doc)
    for name in ("result.json", "answers.json"):
        try:
            dump(out / name, final)
        except Exception as exc:
            err.append("%s write failed: %s" % (name, exc))
    try:
        build_content_map(meta, answers, claims, index, out)
    except Exception as exc:
        err.append("content_map.json failed: %s" % exc)
    try:
        (out / "report.md").write_text(build_report(doc, check_report, status),
                                       encoding="utf-8")
    except Exception as exc:
        err.append("report.md failed: %s" % exc)
    print(json.dumps({"ok": True, "command": "build", "status": status,
                      "case_id": final.get("case_id", ""),
                      "counts": {"answers": len(answers), "claims": len(claims),
                                 "unanswered": len(unanswered)},
                      "outputs": ["result.json", "answers.json", "report.md", "content_map.json"],
                      "errors": err, "degradations": deg}, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- cli
def add_io(p):
    for n in ("input", "work", "output"):
        p.add_argument("--" + n, default=argparse.SUPPRESS, help=n + " dir")


def build_parser():
    ap = argparse.ArgumentParser(
        prog="literature-qa",
        description="Evidence-bearing question answering over one scientific paper: "
                    "paragraph-level locators, verbatim quotes, explicit uncertainty.",
        epilog="Flow: init -> show -> find --question Q1 -> (write work/draft.json) "
               "-> check -> build")
    ap.add_argument("--input", default=os.environ.get("INPUT_DIR", "/input"))
    ap.add_argument("--work", default=os.environ.get("WORK_DIR", "/app/work"))
    ap.add_argument("--output", default=os.environ.get("OUTPUT_DIR", "/app/output"))
    ap.add_argument("--version", action="version", version="literature-qa " + VERSION)
    sub = ap.add_subparsers(dest="command")
    p = sub.add_parser("init", help="index paper paragraphs and questions")
    add_io(p)
    p = sub.add_parser("show", help="print paragraphs / questions with locators")
    add_io(p)
    p.add_argument("--list", action="store_true")
    p.add_argument("--paragraph")
    p.add_argument("--question")
    p.add_argument("--grep")
    p.add_argument("--limit", type=int, default=0)
    p = sub.add_parser("find", help="rank paragraphs as evidence candidates")
    add_io(p)
    p.add_argument("--question")
    p.add_argument("--query")
    p.add_argument("--top", type=int, default=5)
    for name, helptext in (("check", "validate work/draft.json"),
                           ("build", "assemble result.json + answers.json"),
                           ("selfcheck", "re-run checks only")):
        p = sub.add_parser(name, help=helptext)
        add_io(p)
        if name != "selfcheck":
            p.add_argument("--draft")
    return ap


def main(argv):
    ap = build_parser()
    try:
        args = ap.parse_args(argv)
    except SystemExit:
        return 0
    if not args.command:
        ap.print_help()
        return 0
    fn = {"init": cmd_init, "show": cmd_show, "find": cmd_find, "check": cmd_check,
          "build": cmd_build, "selfcheck": cmd_check}.get(args.command)
    return fn(args) if fn else 0


def emergency(argv):
    try:
        try:
            args, _ = build_parser().parse_known_args(argv)
        except SystemExit:
            args = None
        out = Path(getattr(args, "output", None) or "/app/output")
        out.mkdir(parents=True, exist_ok=True)
        if not (out / "result.json").exists():
            stub = {"case_id": "", "paper_id": "", "material_version": "",
                    "status": "partial", "answers": [], "claims": [],
                    "unanswered_parts": [],
                    "coverage": {"read_sections": [], "unread_sections": [],
                                 "reasons": ["emergency finalize"]},
                    "result": {}, "uncertainties": [], "sources": [], "pending_human": [],
                    "errors": ["unhandled exception"],
                    "degradations": ["emergency finalize"], "deliverables": {}}
            dump(out / "result.json", stub)
            dump(out / "answers.json", stub)
    except Exception:
        pass


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except Exception:
        try:
            sys.stderr.write(traceback.format_exc())
        except Exception:
            pass
        emergency(sys.argv[1:])
    sys.exit(0)

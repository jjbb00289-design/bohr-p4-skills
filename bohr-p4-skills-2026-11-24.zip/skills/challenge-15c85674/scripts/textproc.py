#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Text processing for literature-qa: io helpers, multi-material discovery, paragraph
parsing with section detection, and the Chinese->English gloss used by evidence retrieval.

Split out of main.py so the orchestrator stays small. Pure stdlib, no network.
"""
import json
import re
from pathlib import Path

MAX_READ = 2_000_000

PARA_PATTERNS = [
    re.compile(r"^\s*\[(?:P|p|para|paragraph)?\s*(\d{1,4})\]\s*"),
    re.compile(r"^\s*(?:P|p|para\.?|paragraph)\s*(\d{1,4})\s*[.:)\-]\s*", re.I),
    re.compile(r"^\s*\((\d{1,4})\)\s*"),
    re.compile(r"^\s*(\d{1,4})[.)]\s+"),
]
STOP = set("""a an the of for and or to in on at by with from as is are was were be been being
this that these those it its their there which what when where how why does do did not no
isn't can could should would may might must shall will""".split())

# Section names we recognise in a paper; used only to tag paragraphs with a coarse
# section, never to renumber. Matches headings like "Results", "2.3 Discussion",
# "Materials and Methods", "Table 1", "Figure 2 caption".
SECTION_RE = re.compile(
    r"^\s*(?:\d+\.?\d*[\.\s)]*)?"
    r"(abstract|introduction|background|related work|materials?(?:\s+and\s+methods?)?"
    r"|methods?|experimental(?:\s+section)?|results?(?:\s+and\s+discussion)?"
    r"|discussion|conclusion|conclusions|acknowledg?ments?|references?|bibliography"
    r"|supplementary|supporting information|appendix|figure\s*\d+[\.:]*\s*(?:caption)?"
    r"|table\s*\d+[\.:]*)\b\s*:?$", re.I)

# The fixed cases pair an ENGLISH paper with CHINESE questions, so pure keyword overlap
# finds nothing. This gloss bridges the two for `find`: Chinese question terms map to
# English stems that are matched by prefix against the paper.
CN_EN = {
    "循环": "cycl", "稳定性": "stabil", "产率": "yield", "选择性": "selectiv",
    "温度": "temperat", "压力": "pressur", "时间": "time", "浓度": "concentrat",
    "样品": "sample", "实验": "experiment", "方法": "method", "结果": "result",
    "结论": "conclusion", "误差": "error", "标准差": "deviation", "显著": "signific",
    "条件": "condition", "比例": "ratio", "含量": "content", "数值": "value",
    "材料": "material", "合金": "alloy", "强度": "strength", "硬度": "hardness",
    "疲劳": "fatigu", "断裂": "fractur", "拉伸": "tensil", "应变": "strain",
    "应力": "stress", "热处理": "heat treatment", "腐蚀": "corros", "涂层": "coating",
    "复合": "composit", "制备": "prepar", "烧结": "sinter", "晶粒": "grain",
    "退火": "anneal", "淬火": "quench", "相": "phase",
    "模型": "model", "训练": "train", "准确率": "accura", "数据集": "dataset",
    "神经网络": "neural", "学习": "learn", "参数": "parameter", "优化": "optim",
    "损失": "loss", "过拟合": "overfit", "特征": "feature", "分类": "classif",
    "回归": "regress", "推理": "inferen", "算法": "algorithm", "基线": "baselin",
    "降解": "degrad", "光催化": "photocatalyt", "催化剂": "catalyst", "吸附": "adsorpt",
    "污染物": "pollutant", "染料": "dye", "去除": "removal", "速率": "rate",
    "效率": "efficien", "活性": "activ", "比表面积": "surface area", "带隙": "band gap",
    "氧化": "oxidat", "还原": "reduct", "纳米": "nano", "颗粒": "particle",
    "溶液": "solution", "光照": "illuminat", "产氢": "hydrogen", "电流": "current",
    "电压": "voltage", "容量": "capacit", "电极": "electrode", "电池": "batter",
    "质量": "mass", "能量": "energ", "密度": "densit", "体积": "volume",
    "厚度": "thick", "粒径": "size", "形貌": "morpholog", "结构": "structur",
    "组成": "composit", "性能": "perform", "力学": "mechan", "对照": "control",
    "空白": "blank", "重复": "replic", "批次": "batch", "纯度": "purit",
}


def dump(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def load(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return default


def read_text(path, limit=MAX_READ):
    try:
        raw = Path(path).read_bytes()[:limit]
    except Exception:
        return ""
    for enc in ("utf-8", "utf-16", "gb18030", "latin-1"):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("utf-8", "replace")


def norm(text):
    if text is None:
        return ""
    text = str(text).replace("\u3000", " ").replace("\xa0", " ").replace("\u2019", "'")
    return re.sub(r"\s+", " ", text).strip().lower()


def tokens(text):
    return [t for t in re.findall(r"[a-z0-9]+", norm(text)) if t not in STOP and len(t) > 2]


def expand_cn(query):
    """English stems for Chinese question terms, so `find` crosses the language gap."""
    stems = set()
    for cn, en in CN_EN.items():
        if cn in (query or ""):
            stems.update(en.split())
    return stems


def strip_marker(line):
    out = line
    for pat in PARA_PATTERNS:
        m = pat.match(out)
        if m:
            out = out[m.end():]
            break
    return out.strip()


def detect_section(line):
    """Return a normalised section name when `line` looks like a heading, else None."""
    m = SECTION_RE.match(line.strip())
    if not m:
        return None
    name = m.group(1).strip().lower()
    if name.startswith("materials"):
        return "Materials and Methods"
    if name.startswith("methods"):
        return "Methods"
    if name.startswith("results"):
        return "Results"
    if name.startswith("discussion"):
        return "Discussion"
    if name.startswith("conclusion"):
        return "Conclusion"
    if name.startswith("acknowledg"):
        return "Acknowledgements"
    if name.startswith("reference") or name == "bibliography":
        return "References"
    if name.startswith("supplementary") or name.startswith("supporting"):
        return "Supplementary"
    if name.startswith("appendix"):
        return "Appendix"
    if name.startswith("table"):
        return "Table"
    if name.startswith("figure"):
        return "Figure"
    if name in ("abstract", "introduction", "background", "related work",
                "experimental", "experimental section"):
        return name.title() if name not in ("related work",) else "Related Work"
    return name.title()


def parse_paragraphs(text, material="paper", prefix=""):
    """Split text into [{paragraph_id, material, section, locator, text}].

    Keeps the paper's own numbering when present ([N] / P1 / 1. / (1)), else falls
    back to blank-line blocks and then to fixed-size word chunks. Section headings
    are used only to tag the following paragraphs, never to renumber.
    """
    out = []
    if not text or not text.strip():
        return out
    lines = text.replace("\r\n", "\n").split("\n")
    pid, buf, section = None, [], ""

    def flush():
        nonlocal pid, buf, section
        if pid is not None and buf and "\n".join(buf).strip():
            body = "\n".join(buf).strip()
            out.append({"paragraph_id": (prefix + pid), "material": material,
                        "section": section or None, "locator": material,
                        "text": body})
        pid, buf = None, []

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        head = detect_section(stripped)
        if head and len(stripped) <= 80 and not any(p.match(line) for p in PARA_PATTERNS):
            flush()
            section = head
            buf = [stripped]
            pid = None
            continue
        matched = None
        for pat in PARA_PATTERNS:
            m = pat.match(line)
            if m:
                matched = m.group(1)
                break
        if matched is not None:
            flush()
            pid = "P%s" % matched
            buf = [strip_marker(line)]
            continue
        buf.append(stripped)
    flush()

    # Drop heading-only pseudo-paragraphs that carry no body.
    kept = []
    for p in out:
        if p["section"] and p["text"] and len(p["text"]) < 3:
            continue
        kept.append(p)
    if kept:
        return kept

    # Fallback: no numbered paragraphs at all.
    blocks = [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip()]
    if len(blocks) <= 1:
        words = text.split()
        blocks = [" ".join(words[i:i + 120]) for i in range(0, len(words), 120)]
    for i, b in enumerate(blocks):
        sec = detect_section(b.split("\n")[0]) if "\n" in b else None
        out.append({"paragraph_id": "%sP%d" % (prefix, i + 1), "material": material,
                    "section": sec or None, "locator": material, "text": b})
    return out


def split_table_blocks(text, material, prefix):
    """Parse CSV/TSV text into one block per data row with a row locator."""
    lines = [ln for ln in text.replace("\r\n", "\n").split("\n") if ln.strip()]
    if not lines:
        return []
    out = []
    for i, ln in enumerate(lines):
        out.append({"paragraph_id": "%sR%d" % (prefix, i + 1), "material": material,
                    "section": "Table", "locator": "%s#row%d" % (material, i + 1),
                    "text": ln.strip()})
    return out


def find_materials(case, input_dir):
    """Return an ordered list of {material_id, path, text} for every text material.

    Order: any full text embedded in case.json first (paper), then files under
    input_dir (paper.md / tables / captions / references). `case.json`, `task.md`
    and question files are excluded.
    """
    items, seen = [], set()
    for key in ("paper_text", "full_text", "text", "content", "article", "manuscript"):
        val = case.get(key)
        if isinstance(val, str) and len(val.strip()) > 40:
            mid = "case.json:%s" % key
            items.append({"material_id": mid, "path": "case.json", "text": val,
                          "is_primary": True})
            seen.add(mid)
            break
    root = Path(input_dir)
    if root.exists():
        skip_names = {"case.json", "task.md", "questions.json", "questions.md",
                      "questions.txt", "notes.md", "config.json"}
        for p in sorted(root.rglob("*")):
            try:
                if not p.is_file() or p.stat().st_size > MAX_READ:
                    continue
            except Exception:
                continue
            if p.name in skip_names or p.suffix.lower() not in (".txt", ".md", ".tex", ".csv", ".tsv"):
                continue
            text = read_text(p)
            if not text.strip():
                continue
            rel = p.relative_to(root).as_posix()
            # Prefer the basename as the human-facing material id; fall back to the
            # relative path when two files share a basename.
            mid = p.name
            if mid in seen:
                mid = rel
            seen.add(mid)
            items.append({"material_id": mid, "path": p.as_posix(), "text": text,
                          "is_primary": "paper" in p.name.lower()})
    # Primary paper = embedded text, else the file whose name says "paper", else longest.
    primary = next((x for x in items if x.get("is_primary") and "case.json" in x["path"]), None)
    if primary is None:
        primary = next((x for x in items if x.get("is_primary")), None)
    if primary is None and items:
        primary = max(items, key=lambda x: len(x["text"]))
    if primary:
        primary["is_primary"] = True
    ordered = []
    if primary:
        ordered.append(primary)
    ordered += [x for x in items if x is not primary]
    return ordered


def find_paper(case, input_dir):
    """Backward-compatible: return (text, source) for the primary paper."""
    mats = find_materials(case, input_dir)
    if not mats:
        return "", ""
    return mats[0]["text"], mats[0]["path"]


def _qid(item, idx):
    if isinstance(item, dict):
        for k in ("question_id", "qid", "id", "questionId"):
            if item.get(k) not in (None, ""):
                return str(item[k])
    return "Q%d" % (idx + 1)


def _qtext(item):
    if isinstance(item, str):
        return item
    if isinstance(item, dict):
        for k in ("question", "text", "q", "query", "instruction", "prompt"):
            if item.get(k) not in (None, ""):
                return str(item[k])
    return ""


def find_questions(case, input_dir):
    """Locate the question list: case fields first, then questions.* / task.md."""
    candidates = []
    for key in ("questions", "question_list", "tasks", "queries", "items"):
        val = case.get(key)
        if isinstance(val, list) and val:
            candidates.append(val)
    for key in ("task", "task_instruction", "spec"):
        val = case.get(key)
        if isinstance(val, dict):
            for k in ("questions", "question_list"):
                if isinstance(val.get(k), list) and val[k]:
                    candidates.append(val[k])
    if not candidates:
        root = Path(input_dir)
        for name in ("questions.json", "questions.md", "questions.txt"):
            p = root / name
            if not p.exists():
                continue
            if p.suffix == ".json":
                data = load(p)
                if isinstance(data, list) and data:
                    candidates.append(data)
                elif isinstance(data, dict):
                    for k in ("questions", "question_list", "items"):
                        if isinstance(data.get(k), list) and data[k]:
                            candidates.append(data[k])
            else:
                found = re.findall(r"^\s*(?:[-*]|\d+[.)]|Q\d+[:.])\s*(.{4,400})$",
                                   read_text(p), re.M)
                if found:
                    candidates.append(found)
    if not candidates:
        return []
    out = []
    for i, item in enumerate(candidates[0]):
        qid, qtext = _qid(item, i), _qtext(item)
        if not qtext:
            continue
        subs = []
        if isinstance(item, dict):
            for k in ("sub_questions", "subquestions", "subs"):
                if isinstance(item.get(k), list):
                    subs = [str(s) for s in item[k] if str(s).strip()]
        out.append({"question_id": qid, "question": qtext, "sub_questions": subs})
    return out


def meta_of(case):
    def pick(*keys):
        for k in keys:
            v = case.get(k)
            if v not in (None, ""):
                return str(v)
        return ""
    return {"case_id": pick("case_id", "id", "caseId"),
            "paper_id": pick("paper_id", "paperId", "paper"),
            "material_version": pick("material_version", "version", "materialVersion")}

---
name: literature-qa
description: Answer questions over one scientific paper with paragraph-level evidence. Use when a case supplies numbered paper paragraphs plus a list of questions (possibly in Chinese) and asks for per-question answers that preserve numbers, units, conditions and scope, mark unsupported parts honestly, and cite a material + paragraph_id + section + verbatim quote for every claim. Provides multi-material indexing, evidence-candidate ranking, mechanical quote/coverage checks, a content_map traceability file, and writes the current /app/output/result.json plus the legacy /app/answers.json.
version: 1.1.0
---

# 文献智能问答（Literature QA with evidence）

读给定论文与问题 → 整合证据 → **逐题回答并标明依据**。答案与证据必须一一核对得上。

## 何时使用

题面给「一篇带段落编号的论文 + 若干中文问题」，要求逐题作答、附原文段落编号与短引文、
保留数值/单位/比较对象/实验条件/结论范围，并对"未报告 / 部分可答 / 原文冲突 / 读取失败"明确说明。
材料可能不止一篇：平台提供摘要、正文、表格文字、图注和参考文献著录信息（都是文本，无需读图）。

不适用：需要联网检索、需要解析 PDF 二进制、需要补充外部知识（本题只依据给定材料）。

## 硬规则（先读这一节）

1. **不得省略问题**：`answers[]` 每个问题一项；答不出也要写 `answer` 说明"材料未报告 X"。
2. **`claims[].kind` 只有两个值**：`reported`（原文报告）/ `inferred`（自己的推断）。**不要混用其他枚举。**
3. **每条证据必须四件套**：`material`（来源文件 id）+ `paragraph_id`（真实段落 id）+ `section`（该段所在章节）+ 逐字 `quote`。`quote` 必须能在该段原文中逐字命中。
4. **数值/单位/条件逐字保真**：不改写、不换算、不省略限定条件、不丢比较对象。
5. **区分三类信息**：论文实测结果（`reported`）、作者解释（`reported` 但 `text` 里要写明是作者观点）、
   自己的推断（`inferred`，并写清推断链）。**推断不得写成原文报告。**
6. **`output_contract` 每个键原样回填**；缺失写 `null` 并计入 `degradations`。
7. **退出码恒 0**；任何异常都产出合法最小交付。

## 五步主流程

对**每个问题**都走这五步，不要只做一次总结：

1. **问题分解**：把中文问题拆成子问（数值？条件？比较？机理？适用范围？），逐个子问都要落答案。
2. **段落检索**：`find --question Qn` 拿候选短名单（词面重叠 + 中英词表，只是候选，不是结论）；
   再 `show --grep` / `show --paragraph` 通读。数值多在 Results/表格，条件多在 Methods，
   作者解释多在 Discussion。
3. **证据筛选**：只选直接支持该子问的句子；跨段整合时每段各给一条 evidence。
   表格文字、图注、参考文献的 locator 用其 `material` + 行号/图号（脚本对 CSV 生成 `R1..Rn`）。
4. **作答**：`answer` 整合各子问，`conditions` 列全条件，`status` 按下面四档写。
5. **自检**：`check` 验证 quote 逐字、paragraph_id 存在、问题全覆盖；不过就修工作稿。

## 五命令主路径

```bash
python3 scripts/main.py init                 # 建材料/段落索引 + 问题清单 + partial result/answers
python3 scripts/main.py show                  # 段落/材料/问题总览（含 section 与 locator）
python3 scripts/main.py show --paragraph P7  # 读某段原文（引文从这里逐字复制）
python3 scripts/main.py find --question Q1   # 按问题检索候选段落（证据短名单，非结论）
#  你自己读材料，写 /app/work/draft.json
python3 scripts/main.py check                # 机械校验：问题覆盖 / paragraph_id / quote 逐字 / material / section
python3 scripts/main.py build                # 组装 result.json + answers.json + report.md + content_map.json
```

> **脚本不会替你读论文。** `init/show/find` 只做索引、定位与候选排序；
> 答案、条件、`kind` 判定、欠答理由必须由你读过材料之后写进工作稿。
> **只跑 `build` 不给工作稿，只能拿降级分。**

## 输入与输出

| 项 | 路径 |
|---|---|
| 输入 | `/input/case.json`（`case_id`、`paper_id`、`material_version`、`output_contract`，可能含 `questions`）、`/input/task.md`、论文/表格/图注/参考文献文本 |
| 工作区 | `/app/work/`（`index.json`、`draft.json`、`check_report.json`） |
| 产物 | `/app/output/`：`result.json`（主产物）、`answers.json`（兼容件，同内容）、`report.md`（人读）、`content_map.json`（可核验映射） |

路径可用 `--input/--work/--output` 覆盖。不联网、不依赖当前工作目录、只用标准库。
主产物路径按「当前独立运行适配」为 `/app/output/result.json`；`build` 同步写 `/app/answers.json`。

## 工作稿 schema（`/app/work/draft.json`）

```json
{
  "case_id": "…", "paper_id": "…", "material_version": "…",
  "answers": [{
    "question_id": "Q1",
    "answer": "完整回答文本；整合方法/结果/讨论/表格的信息",
    "conditions": ["25 °C", "pH 7", "n = 3", "仅适用于 0–50 mg/L 区间"],
    "status": "answered|partial|insufficient_evidence|input_error",
    "sub_questions": ["子问 1 的回答", "子问 2 的回答"],
    "unanswered_parts": ["哪一部分没回答 + 为什么"]
  }],
  "claims": [{
    "claim_id": "C1",
    "text": "论断一句话；若为作者观点，写 'The authors interpret … as …'",
    "kind": "reported|inferred",
    "question_id": "Q1",
    "section": "Results",
    "evidence": [{"material": "paper.md", "paragraph_id": "P7", "section": "Results",
                  "quote": "…逐字原文…"}]
  }],
  "unanswered_parts": [{"question_id": "Q2", "reason": "论文未报告该条件下的数值",
                        "needs": "需要作者补充该条件下的原始数据"}],
  "coverage": {
    "read_sections": ["Abstract", "Methods", "Results"],
    "unread_sections": ["Appendix"],
    "reasons": ["附录未提供文本"]
  },
  "uncertainties": [{"item": "…", "why": "…"}],
  "pending_human": []
}
```

`status` 四档：
- `answered` — 完整回答（含条件）。
- `partial` — 部分可答；必须在 `unanswered_parts` 写明缺什么、为什么。
- `insufficient_evidence` — 材料未报告该信息（**这本身是有效回答**）。
- `input_error` — 输入读不出来（极少用，且要在 `errors` 说明）。

`unanswered_parts` 每条写 **缺什么 + 为什么 + 需要什么** 三件事：`reason` 讲为什么答不了，
`needs` 讲要补什么才能答。

## 证据规范

- `material` 是 `init` 打印出的材料 id（如 `paper.md`、`table1.csv`、`fig1.caption.md`），
  用 `show` 里每段标注的 `material` 值。
- `paragraph_id` 必须是 `show` 打印出的真实 id（`P7`、`T1R3` 这类）。
- `section` 是该段所在章节（Abstract/Methods/Results/Discussion/Table/Figure…）。
- `quote` 逐字复制该段原文的短句（建议 10–40 词），**不改写、不翻译、不拼接**。
- `check` 会验证：`paragraph_id` 存在、`quote` 在全文逐字命中、`material` 与段一致；
  缺 `section`/`material` 会 WARN。
- 一条 claim 可有多条 evidence（跨段/跨材料整合时逐段各给一条）。

## 三类信息与 kind 边界（最常扣分）

- 论文**实测到的数值/现象** → `reported`。
- 作者**自己的解释/主张** → `reported`（原文报告了该主张），但 `text` 写成
  "The authors interpret ... as ..."，**不要写成你自己的结论**。
- **你**从两段推断出的、原文没直说的 → `inferred`，`text` 写清推断链。
- **把 `inferred` 写成 `reported` = 伪造原文，本赛道最重扣分。**

## 降级表（遇到就照做，不要编造）

| 情况 | 处置 | 记录位置 |
|---|---|---|
| 问题在材料里查不到 | `status=insufficient_evidence`，`answer` 写"材料未报告 X" | `answers[]` + `unanswered_parts` |
| 只能答一部分 | `status=partial`，列缺口（缺什么+为什么+需要什么） | `unanswered_parts` |
| 原文两处冲突 | 两处都引，指出冲突 | `uncertainties` |
| 论文只有摘要/节选 | 只答可覆盖部分，`coverage.unread_sections` 说明 | `coverage` |
| 段落编号缺失 | `init` 自动按空行分块编号 `P1..Pn`，并在 `degradations` 说明 | `degradations` |
| 读不到论文文本 | `status=input_error`，最小交付 | `errors` |
| 问题清单缺失 | `answers[]` 为空，`degradations` 说明 | `degradations` |

**永远不要**：编造段落编号、把推断写成 `reported`、改写引文使其"更通顺"、
把"未报告"写成"不存在"、给没有数值的结论补数字、把常识当原文事实。

## 自检清单

- [ ] `init` 后 `result.json` 与 `answers.json` 都已存在（partial），退出码 0。
- [ ] `answers[]` 覆盖全部 `question_id`，一个不漏（答不出也要有条目）。
- [ ] 每条 `answer` 非空且带 `conditions`；中文问题已拆子问并逐条回答。
- [ ] 每个 claim 的 `kind` ∈ {`reported`, `inferred`}。
- [ ] 每条 evidence 有 `material` + `paragraph_id` + `section` + 逐字 `quote`。
- [ ] `unanswered_parts` 与实际欠答一致，且写了"缺什么+为什么+需要什么"。
- [ ] `coverage` 写了读/未读章节及原因。
- [ ] `build` 后 `result.json`/`answers.json`/`report.md`/`content_map.json` 都在、契约键零缺失。
- [ ] 同一输入两次运行结构一致。

## 最小调用示例

```bash
# /input 里有 case.json（含 questions、output_contract）、task.md、materials/paper.md
python3 scripts/main.py init
python3 scripts/main.py show --paragraph P3
python3 scripts/main.py find --question Q1
#  写 /app/work/draft.json
python3 scripts/main.py check
python3 scripts/main.py build
```

示意输出（**示例，非正式案例结果**）：

```json
{"case_id": "demo", "paper_id": "demo-paper", "material_version": "v3",
 "status": "ok",
 "answers": [{"question_id": "Q1", "answer": "……", "conditions": ["n = 3"],
              "status": "answered"}],
 "claims": [{"claim_id": "C1", "kind": "reported", "section": "Results",
              "evidence": [{"material": "paper.md", "paragraph_id": "P3",
                            "section": "Results", "quote": "…逐字…"}]}],
 "coverage": {"read_sections": ["Abstract","Methods","Results"],
              "unread_sections": ["Appendix"], "reasons": ["附录未提供文本"]}}
```

字段级说明见 `references/schema.md`；完整示例见 `references/example.md`；可核验映射见 `references/content_map.md`。

## 依赖与维护

- Python ≥3.8 标准库（`json`/`re`/`argparse`/`os`/`pathlib`）。无第三方依赖、不联网。
- 版本 1.1.0。字段改动只做**追加**，不改已有键名。
- 已知限制：不解析 PDF 二进制（本题不需要）；段落编号靠正则识别，无法识别时按空行分块并在
  `degradations` 注明；`find` 的候选排序是词面重叠启发式，**不是语义检索**，必须人工复核；
  章节名识别为粗粒度启发式，仅供标注，不参与判分。

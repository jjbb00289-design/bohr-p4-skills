# content_map：可核验映射（question → claim → evidence locator）

`build` 在 `/app/output/content_map.json` 生成一份独立的可核验映射件，把「问题 → 论断 → 证据定位」
链起来，评审可直接回到原文核对，不需要在 `result.json` 里来回翻找。

## 结构

```json
{
  "case_id": "…", "paper_id": "…", "material_version": "…",
  "inputs": {
    "materials": ["paper.md", "table1.csv", "fig1.caption.md"],
    "questions": ["Q1", "Q2", "Q3"]
  },
  "mapping": [
    {"question_id": "Q1", "question": "……",
     "status": "answered", "answer": "……", "conditions": ["…"],
     "unanswered_parts": [], "linked_claims": ["C1", "C2"]}
  ],
  "claims": [
    {"claim_id": "C1", "kind": "reported", "text": "……",
     "evidence": [{"material": "paper.md", "paragraph_id": "P7",
                   "section": "Results", "quote": "……"}]}
  ],
  "outputs": {"result": "result.json", "answers": "answers.json",
              "report": "report.md", "content_map": "content_map.json"}
}
```

## 与 result.json 的关系

- `content_map.json` 是**派生件**，所有值来自 `work/draft.json`（经 `check` 校验后）与 `index.json`，
  不新增任何论断、不重写引文。
- `mapping[].linked_claims` 通过 `claims[].question_id` 关联；agent 写 draft 时给每条 claim 标上
  `question_id` 即可让该映射完整。未标 `question_id` 的 claim 仍完整列在 `claims[]` 里，不丢证据。
- `claims[].evidence[]` 与 `result.json` 中对应 claim 的证据**逐字一致**，可互相核对。

## 核对方法

1. 对任一 `question_id`，看 `mapping[].linked_claims` 拿到论断 id。
2. 在 `claims[]` 按 `claim_id` 找到论断与全部 `evidence`。
3. 按 `evidence.material` 打开材料文件，按 `evidence.paragraph_id` 定位段落，
   检查 `evidence.quote` 是否逐字命中（`check` 已做机械校验）。

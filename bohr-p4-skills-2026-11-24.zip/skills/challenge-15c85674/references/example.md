# 最小调用示例（示例，非正式案例结果）

> ⚠️ **本文件为人工构造的演示示例，不是平台固定案例的结果，也不来自任何真实论文。**
> 段落、问题、数值均为说明接口而虚构。

## 1. 假设输入（虚构）

`/input/case.json`：

```json
{"case_id": "demo-qa", "paper_id": "demo-paper-01", "material_version": "v3",
 "output_contract": {"case_id": "string", "answers": "array", "claims": "array",
                     "unanswered_parts": "array", "coverage": "object"},
 "questions": [{"question_id": "Q1", "question": "该制备方法的最高产率是多少？在什么条件下？"},
               {"question_id": "Q2", "question": "论文是否报告了循环稳定性？"}]}
```

`/input/materials/paper.md`（虚构）：

```markdown
## Results
[1] The composite was prepared by a two-step hydrothermal route at 180 °C for 12 h.
[2] The highest yield was 87.4 % under nitrogen, obtained at a precursor ratio of 1:3.
## Discussion
[3] Cycling performance was not evaluated in this work.
```

## 2. 调用

```bash
python3 scripts/main.py init
# → counts: paragraphs 3, questions 2 ; paragraph ids P1..P3 ; materials: paper.md

python3 scripts/main.py show --paragraph P2
# → [P2] paper.md | Results
#   The highest yield was 87.4 % under nitrogen, obtained at a precursor ratio of 1:3.

python3 scripts/main.py find --question Q2      # 证据候选短名单
```

`find` 输出片段（虚构）：

```json
{"question_id": "Q2",
 "candidates": [{"paragraph_id": "P3", "material": "paper.md", "section": "Discussion",
                 "score": 0.91,
                 "quote_hint": "Cycling performance was not evaluated in this work."}]}
```

## 3. 工作稿（虚构）

```json
{
  "case_id": "demo-qa", "paper_id": "demo-paper-01", "material_version": "v3",
  "answers": [
    {"question_id": "Q1",
     "answer": "最高产率为 87.4 %，在氮气气氛下取得，前驱体比例为 1:3，制备条件为 180 °C、12 h。",
     "conditions": ["氮气气氛", "前驱体比例 1:3", "180 °C", "12 h"],
     "status": "answered"},
    {"question_id": "Q2",
     "answer": "论文明确表示本研究未评价循环性能，因此该问题在给定材料中未报告。",
     "conditions": [], "status": "insufficient_evidence",
     "unanswered_parts": ["循环稳定性数据：论文声明未评价"]}
  ],
  "claims": [
    {"claim_id": "C1", "text": "最高产率 87.4 %，氮气下取得，前驱体比例 1:3。",
     "kind": "reported", "question_id": "Q1", "section": "Results",
     "evidence": [{"material": "paper.md", "paragraph_id": "P2", "section": "Results",
                   "quote": "The highest yield was 87.4 % under nitrogen, obtained at a precursor ratio of 1:3."}]},
    {"claim_id": "C2", "text": "本研究未评价循环性能。",
     "kind": "reported", "question_id": "Q2", "section": "Discussion",
     "evidence": [{"material": "paper.md", "paragraph_id": "P3", "section": "Discussion",
                   "quote": "Cycling performance was not evaluated in this work."}]}
  ],
  "unanswered_parts": [{"question_id": "Q2", "reason": "论文声明未评价循环性能",
                        "needs": "需要作者补充循环稳定性实验数据"}],
  "coverage": {"read_sections": ["Results", "Discussion"],
               "unread_sections": ["Appendix"],
               "reasons": ["附录未提供文本"]},
  "uncertainties": [{"item": "产率的误差范围", "why": "原文未给误差条"}],
  "pending_human": []
}
```

## 4. 产物

```
/app/output/
  result.json      # 主产物（当前独立运行适配）
  answers.json     # 原始约定路径，同内容
  report.md        # 人读报告
  content_map.json # 可核验映射：question -> claim -> evidence locator
```

`result.json` 片段（**示例，非正式案例结果**）：

```json
{"case_id": "demo-qa", "paper_id": "demo-paper-01", "material_version": "v3",
 "status": "ok",
 "answers": [{"question_id": "Q1", "status": "answered"},
             {"question_id": "Q2", "status": "insufficient_evidence"}],
 "claims": [{"claim_id": "C1", "kind": "reported",
              "evidence": [{"material": "paper.md", "paragraph_id": "P2",
                            "section": "Results", "quote": "…"}]}],
 "coverage": {"read_sections": ["Results","Discussion"],
              "unread_sections": ["Appendix"], "reasons": ["附录未提供文本"]},
 "self_check": {"passed": true, "fail_count": 0}}
```

## 5. 被 check 拦住的写法

| 写法 | check 反应 |
|---|---|
| 漏掉 Q2 | `answers[] omits question(s): Q2` |
| `paragraph_id: "P9"`（不存在） | `paragraph_id 'P9' does not exist in the paper` |
| 引文改写成通畅英文 | `quote not verbatim in the paper` |
| `kind: "fact"` | `kind='fact' not in ['reported', 'inferred']` |
| Q2 答不出就留空 | `has empty answer` |
| `status: "ok"` | `status='ok' not in [...]` |
| evidence 缺 `material` | `evidence[0] has no material locator`（WARN） |
| evidence 缺 `section` | `evidence[0] has no section tag`（WARN） |

## 6. 降级示例

### 论文没有段落编号

`init` 自动按空行分块并编号 `P1..Pn`，同时在 `degradations` 写
`no paragraph numbering detected; fell back to blank-line blocks`。
此时 `quote` 仍须逐字，只是 `paragraph_id` 是自动分配的——**要在 `coverage.reasons` 说明**。

### 没有工作稿直接 build

```json
{"ok": true, "command": "build", "status": "partial",
 "degradations": ["draft.json missing; produced degraded minimal deliverable",
                  "question Q1 was not answered; recorded as insufficient_evidence"]}
```

`answers[]` 会为每个问题补一条 `insufficient_evidence` 占位，**保证不漏题**；
`result.json` 与 `answers.json` 都生成，契约键零缺失，退出码 0。

### 问题清单缺失

`status="input_error"`，`answers[]` 为空，`degradations` 说明
`no question list found; answers[] will be empty`。

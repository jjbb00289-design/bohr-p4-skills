# 字段定义与判据（文献智能问答）

> 版本 1.1.0。字段只做追加，不改已有键名。
> 原则：**有依据地说"未报告"也是有效回答**；无依据的断言比空答更糟。

## 顶层

| 字段 | 必填 | 说明 |
|---|---|---|
| `case_id` / `paper_id` / `material_version` | ✅ | 与输入一致，**不能丢** |
| `status` | ✅ | `ok` / `partial` / `insufficient_evidence` / `input_error` |
| `answers[]` | ✅ | 逐题一项，**不得省略无法回答的问题** |
| `claims[]` | ✅ | 论断 + 证据，`kind` ∈ `reported` / `inferred` |
| `unanswered_parts[]` | ✅ | 未答部分与原因；没有则空数组 |
| `coverage` | ✅ | `read_sections` / `unread_sections` / `reasons` |
| `uncertainties` / `sources` / `pending_human` | | 不确定项、来源、待人工确认 |
| `errors` / `degradations` | ✅ | 空数组也要有 |
| `deliverables` | | `{result, answers, report, content_map}` |
| `self_check` | | `{passed, fail_count, warn_count}` |

`result` 内另存一份 `{answers, claims, unanswered_parts, coverage}`，供契约键为 `result` 时回填。
`content_map.json` 是独立可核验映射件：`question → linked claims → evidence locator`。

## answers[i]

| 字段 | 必填 | 说明 |
|---|---|---|
| `question_id` | ✅ | 与输入问题 id 一致（缺失时 `init` 生成 `Q1..Qn`） |
| `answer` | ✅ | 回答正文；整合方法/结果/讨论/表格信息。**不得为空** |
| `conditions` | ✅（建议） | 成立条件：温度、pH、浓度、`n`、时间点、适用范围 |
| `status` | ✅ | `answered` / `partial` / `insufficient_evidence` / `input_error` |
| `sub_questions` | | 子问逐条回答（题面要求覆盖子问时必填） |
| `unanswered_parts` | | 该题内部没答的部分 |

`status` 判据：

| 值 | 什么时候用 |
|---|---|
| `answered` | 问题各部分都能从材料得到，且写清了条件 |
| `partial` | 一部分能答、一部分不能；**必须列缺口** |
| `insufficient_evidence` | 材料根本没报告该信息。`answer` 里写"材料未报告 X"，这是**有效回答** |
| `input_error` | 输入读不出来。要在 `errors` 说明，不要滥用 |

## claims[i]

| 字段 | 必填 | 说明 |
|---|---|---|
| `claim_id` | ✅ | `C1` 这类稳定 id |
| `text` | ✅ | 一句话论断 |
| `kind` | ✅ | **只有两个值**：`reported`（原文报告）/ `inferred`（自己推断） |
| `question_id` | | 该论断服务的问题（写入后 `content_map` 可链回题目） |
| `section` | | `Abstract` / `Methods` / `Results` / `Discussion` / `Table 1` / `Figure 1` … |
| `evidence[]` | ✅ 非空 | 见下 |

### kind 的边界（最常扣分）

- 论文**实测到的数值/现象** → `reported`。
- 作者**自己的解释/主张** → `reported`（因为原文报告了这个主张），但 `text` 里要写成
  "The authors interpret ... as ..."，**不要写成你自己的结论**。
- **你**从两段推断出的、原文没直说的 → `inferred`，并在 `text` 里写清推断链。
- **把 `inferred` 写成 `reported` = 伪造原文，本赛道最重扣分。**

## evidence[j]

| 字段 | 必填 | 说明 |
|---|---|---|
| `material` | ✅ | 来源材料 id（`init`/`show` 打印的 `material`，如 `paper.md`、`table1.csv`） |
| `paragraph_id` | ✅ | 材料中真实存在的 id（`show` 打印的那个） |
| `section` | ✅（建议） | 该段所在章节（Abstract/Methods/Results/Discussion/Table/Figure…） |
| `quote` | ✅ | 该段原文的**逐字**短句（建议 10–40 词），不改写、不翻译、不拼接 |

`check` 会验证：
1. `paragraph_id` 存在于材料；
2. `quote` 在全文逐字命中；
3. `quote` 是否落在该 `paragraph_id` 段内（不在则 WARN，可能是标错段号）；
4. `material` 是否与该段的材料一致（不一致则 WARN）。

## coverage

```json
{"read_sections": ["Abstract","Methods","Results","Discussion"],
 "unread_sections": ["Appendix"],
 "reasons": ["附录未提供文本"]}
```

题面明确要求说明"已读章节、未读章节及原因"，**空 coverage 会掉「结果完整性」**。

## unanswered_parts：缺什么 + 为什么 + 需要什么

```json
{"question_id": "Q2",
 "reason": "论文在 50 °C 条件下未报告产率，只给了 25 °C 数据",
 "needs": "需要作者补充 50 °C 条件的产率原始数据"}
```

## 未报告 vs 不存在

| 说法 | 能不能写 |
|---|---|
| "论文在该条件下未报告产率" | ✅ 可以（有依据的未报告） |
| "该材料不可能有产率" | ❌ 论文没说不能，属越界断言 |
| "n = 3"（原文写了） | ✅ |
| "n = 3"（原文没写，你按常规补） | ❌ 造假 |

## 常见 FAIL 与修法

| FAIL | 原因 | 修法 |
|---|---|---|
| `answers[] omits question(s): Q3` | 漏题 | 补条目，哪怕 `insufficient_evidence` |
| `status='...' not in [...]` | 用了 `done`/`ok`/`unknown` | 只用四枚举 |
| `paragraph_id 'P9' does not exist` | id 拼错或凭空写 | 回 `show` 复制真实 id |
| `quote not verbatim in the paper` | 改写/翻译/拼接 | 逐字复制 |
| `kind='fact' not in [...]` | 用了别的枚举 | 只用 `reported` / `inferred` |
| `claims[] is empty` | 没做证据表 | 至少给每个关键结论一条 |
| `has empty answer` | 答不出就留空 | 写"材料未报告…" |

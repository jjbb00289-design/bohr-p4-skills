# 20 条断言样例（示例，非正式案例结果）

以下全部为**构造示例**，用于说明拆解粒度、证据绑定与受控词表用法；不来自任何正式案例，也不作为提交答案。每条 quote 均为示意片段。

1. 拆细并列句。原文「Compound A reduced tumor volume and prolonged survival in mice.」拆成两条：
   - `{predicate: "decreases", subject: "Compound A", object: "tumor volume", conditions: ["in mice"]}`，quote「Compound A reduced tumor volume」。
   - `{predicate: "increases", subject: "Compound A", object: "survival", conditions: ["in mice"]}`，quote「prolonged survival in mice」。

2. 保留限定范围。原文「In vitro, X inhibited cell proliferation (IC50 = 2.3 µM).」：
   - `{predicate: "inhibits", subject: "X", object: "cell proliferation", conditions: ["in vitro", "IC50 = 2.3 µM"]}`，quote「X inhibited cell proliferation (IC50 = 2.3 µM)」。

3. 因果关系拆成两条。原文「Because A activates B, C levels increased.」：
   - `{predicate: "activates", subject: "A", object: "B"}`，quote「A activates B」。
   - `{predicate: "increases", subject: "C", object: "levels", conditions: ["because A activates B"]}`，quote「C levels increased」。

4. 关系方向。原文「p53 binds the MDM2 promoter.」→ `{predicate: "binds", subject: "p53", object: "MDM2 promoter"}`。

5. 测量数值。原文「Median overall survival was 18.3 months (95% CI 15.1–21.5).」→ `{predicate: "measures", subject: "median overall survival", object: "18.3 months", conditions: ["95% CI 15.1–21.5"]}`。

6. 比较。原文「The treated group had higher response rate than placebo (42% vs 18%, p=0.003).」→ `{predicate: "compares_to", subject: "treated group", object: "placebo", conditions: ["42% vs 18%", "p=0.003"]}`。

7. 相关（不写因果）。原文「Serum biomarker level was associated with disease severity (r=0.61).」→ `{predicate: "associates_with", subject: "serum biomarker level", object: "disease severity", conditions: ["r=0.61"]}`。

8. 预测。原文「Baseline score predicted 6-month relapse (AUC=0.82).」→ `{predicate: "predicts", subject: "baseline score", object: "6-month relapse", conditions: ["AUC=0.82"]}`。

9. 属性。原文「Variant V is a loss-of-function allele.」→ `{predicate: "is_a", subject: "Variant V", object: "loss-of-function allele"}`。

10. 归属。原文「Gene G is located on chromosome 7q31.」→ `{predicate: "located_in", subject: "Gene G", object: "chromosome 7q31"}`。

11. 否定。原文「The inhibitor did not reduce fibrosis.」→ `{predicate: "decreases", negation: true, modality: "negated", subject: "the inhibitor", object: "fibrosis"}`。

12. 缓和语气。原文「These data suggest a protective role for D.」→ `{predicate: "has_property", modality: "hedged", subject: "D", object: "protective role"}`。

13. 间接证据标注。结论「B is a downstream target」依据是共表达数据，`evidence.type = "indirect"`，conditions 写「inferred from co-expression; direct interaction not tested」。

14. 图表证据。结论「Survival curves separated after 3 months」的 `evidence.type = "figure"`，locator 写 figure 编号，quote 用图注原文。

15. 跨证据最小充分性。只引用「HR = 0.64 (95% CI 0.49–0.84)」作为死亡率降低的最小充分片段，而不是整段方法。

16. 主体澄清。原文「It was overexpressed in tumors」：subject 须由上下文补全为「Gene X」，quality 写 `subject_confusion` 若指代不明。

17. 过度断言检测。把「significant」但未给效应量的句子标 `vague_quantifier`，confidence=low。

18. 来源缺失。若作者/年份无法从材料确定，`source.authors=[]`、`source.year=null`，quality 写 `missing_source`。

19. 去重合并。两条同主体同关系同数值的断言合并为一条，id 保留最小者，change_records 记录合并。

20. 无法判断。原文未报告 PFS 数值时，不写任何数值，`uncovered` 记录「PFS not reported」，status=partial。

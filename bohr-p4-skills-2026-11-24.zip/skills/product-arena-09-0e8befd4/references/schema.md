# 字段字典与受控词表

本文件定义 `nanopublications` 数组每个元素的字段，供模型精化阶段与下游程序复用。字段名稳定，缺值用 `null`/`[]`，禁止占位字符串。

## nanopublication 条目

| 字段 | 类型 | 说明 |
|-|-|-|
| `id` | string | 稳定标识 `np-<doc8>-<4位序号>`，可复现 |
| `assertion.text` | string | 单条可判断真假的断言，忠实于原文 |
| `assertion.subject` | string\|null | 断言主体实体 |
| `assertion.predicate` | string\|null | 受控关系词（见下） |
| `assertion.object` | string\|null | 断言对象/取值 |
| `assertion.conditions` | list | 条件与限定范围（如 in vitro、p<0.05、n=…） |
| `assertion.modality` | enum | `assertive \| hedged \| negated` |
| `assertion.negation` | bool | 是否否定断言 |
| `evidence[].quote` | string | 逐字原文片段（最小充分） |
| `evidence[].type` | enum | `direct \| indirect \| figure \| table` |
| `evidence[].minimal` | bool | 是否为最小充分片段 |
| `evidence[].locator.document` | string | 材料文件名 |
| `evidence[].locator.page` | int | 页码（自 1 起） |
| `evidence[].locator.paragraph` | int | 段落/行序号（页内，自 0 起） |
| `evidence[].locator.sentence` | int | 句子序号（段内，自 0 起） |
| `source.title` | string\|null | 论文标题 |
| `source.authors` | list | 作者列表 |
| `source.year` | int\|null | 年份 |
| `source.venue` | string\|null | 期刊/会议 |
| `source.doi` | string\|null | DOI |
| `source.ids` | object | 其他标识符 |
| `confidence.level` | enum | `high \| medium \| low` |
| `confidence.basis` | list | 置信度依据，逐条写实 |
| `quality.status` | enum | `verified \| needs_review \| rejected` |
| `quality.checks` | list | 质量检查结论 |
| `quality.warnings` | list | 警告，如 `unverifiable_quote` |

## predicate 受控词表

`has_property`（具有属性）、`is_a`（是一种）、`part_of`（是部分）、`causes`（导致）、`increases`（提高/上调）、`decreases`（降低/下调）、`associates_with`（相关）、`correlates_with`（相关）、`predicts`（预测）、`compares_to`（相比）、`measures`（测量/报告数值）、`binds`（结合）、`encodes`（编码）、`expresses`（表达）、`regulates`（调控）、`inhibits`（抑制）、`activates`（激活）、`treats`（治疗）、`diagnoses`（诊断）、`located_in`（位于）、`derives_from`（来源于）、`other`（其他）。

方向性要求：关系方向必须与原文一致，例如「X inhibits Y」的 subject=X、object=Y，不得颠倒。无把握用 `other` 并在 `quality.warnings` 说明。

## quality 检查项（可复现判定依据）

- `overbroad_assertion`：一条断言含多个独立命题（需再拆）。
- `insufficient_evidence`：证据片段不含断言的主体或数值。
- `relation_type_error`：predicate 与原文方向/含义不符。
- `subject_confusion`：主体实体指代不明或张冠李戴。
- `missing_source`：source 元数据缺失且原文可查而未查。
- `unverifiable_quote`：引文无法在原文命中（脚本自动标记）。
- `compound_claim`：复合句未拆净。
- `vague_quantifier`：仅有「significant」而无数值/效应量。

## result.json 顶层字段

`case_id`、`status`、`task_instruction`、`answer`、`summary`、`nanopublications`、`assertions`、`sources`、`uncovered`、`gaps`、`uncertainty`、`errors`、`degradations`、`metrics`、`change_records`，以及 `output_contract` 的每一个键原样回填。

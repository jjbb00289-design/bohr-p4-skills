---
name: nanopub-assertion-extractor
description: 科研论文断言级解析与证据绑定。把论文段落拆成单条可独立判断真假的断言，为每条断言绑定最小证据片段与原文定位（页码/段落/句子），记录来源元数据，输出可机器读取的 result.json，并自动核验每条引文都能回到原文。当任务要求拆分断言、绑定证据、来源追溯、结构化导出，或对论文结论做可复核解析时触发。
version: 1.0.0
---

# Nanopublication 断言提取与证据绑定

把科研材料拆成「可独立判断真假的断言」，为每条断言绑定「最小证据片段 + 原文定位 + 来源元数据」，输出可机器读取、可逐条复核的结构化结果。

## 用途与触发条件

适用：论文/预印本/报告中的结论拆解、证据对齐、来源追溯、断言质量检查、结构化导出。
触发：任务要求「拆解断言 / 绑定证据 / 来源定位 / 可复核结论 / 结构化 result.json / 证据红线」时加载本 Skill。
不适用：纯翻译、纯摘要改写、无材料可引的常识问答（此时仍要如实返回 uncovered/gaps，不得编造）。

## 调用方式

```bash
python scripts/main.py                 # 完整流程（默认 build）
python scripts/main.py build           # 抽取 -> 分段 -> 基线断言 -> result.json
python scripts/main.py init            # 只抽取并生成工作稿 derived.json + baseline
python scripts/main.py show            # 查看状态
python scripts/main.py check           # 校验 result.json（契约键 + 引文命中）
python scripts/main.py finalize        # 用 work/refined.json 重新生成 result.json
```

路径：默认 `INPUT_DIR=/input`、`WORK_DIR=/app/work`、`OUTPUT_DIR=/app/output`；可用环境变量或 `--input/--work/--output` 覆盖。脚本纯 Python 标准库、不联网、不依赖 CWD（以 `Path(__file__)` 定位）。退出码恒为 0。

## 完整工作流（Agent 必须执行）

1. **读题**：读 `/input/case.json`（取 `case_id`、`output_contract`、`task_instruction`）与 `/input/task.md`；识别材料清单与问题边界。
2. **抽取**：运行 `main.py build` 得到确定性基线（句子级断言 + 逐字引文 + 定位），产物 `work/derived.json`、`out/result.json`。
3. **模型精化**：阅读 `work/derived.json` 中每篇文档的 `segments`（page/paragraph/sentence + 文本），按下面「断言拆解规则」把复合句拆细、确定 subject/predicate/object、绑定最小证据、打置信度与质量检查；结果写成 `work/refined.json`（字段与 baseline 相同的数组）。
4. **复核**：`main.py finalize` 校验并重写 `result.json`；`main.py check` 报告契约键与引文命中问题；引文必须能在原文逐字命中。

若平台提供 `pdf-text-tool`，优先用它抽取，把文本写入 `work/<原文件名>.txt` 供人工对照；脚本内置抽取（zlib 流 + 文本算子）作为兜底并写入 `degradations`。扫描版 PDF（无文本层）必须用 OCR，未 OCR 时如实标为缺口，不得臆测内容。

## 输入输出

- 输入：`/input/case.json`（必需）、`/input/task.md`、材料文件（PDF/DOCX/TXT/MD/CSV/JSON/SQLite/图片等）。
- 输出：`/app/output/result.json`（唯一正式交付，必需），工作稿在 `/app/work/`。

`result.json` 顶层字段：`case_id`、`status`（success/partial/insufficient_evidence/input_error）、`task_instruction`、**`output_contract` 的每一个键原样回填**（缺值用 `null`/`[]`，不得改名或漏键）、`answer`、`summary`、`nanopublications`、`assertions`、`sources`、`uncovered`、`gaps`、`uncertainty`、`errors`、`degradations`、`metrics`、`change_records`。

## 工作稿 schema（work/derived.json）

```json
{
  "case": {"case_id": "...", "output_contract": {}, "task_instruction": "..."},
  "documents": [{
    "document": "paper.pdf", "kind": "pdf", "text": "...",
    "pages": ["..."],
    "segments": [{"page": 1, "paragraphs": [
      {"index": 0, "text": "...", "sentences": [
        {"index": 0, "text": "...", "char_start": 0, "char_end": 90}]}]}],
    "warnings": []
  }],
  "errors": [], "degradations": []
}
```

## 断言拆解规则（模型精化阶段必须遵守）

- **拆得细**：一条断言只含一个主体、一个关系、一个结论。并列句按连接词（and/or/while/whereas）拆；因果句拆成「因」与「果」两条并保留条件；`A and B were increased` 拆成两条。
- **对得上**：`evidence.quote` 必须是原文逐字片段（最小充分片段），`locator` 给出 document/page/paragraph/sentence；证据类型 `direct`（原文直接支撑）或 `indirect`（需推断，须在 conditions 或 quality 说明）。
- **追得回**：`source` 记录 title/authors/year/venue/doi；`id` 形如 `np-<doc8>-<序号>`，稳定可复现。
- **读得懂**：字段只允许本文件定义的受控词表；不得输出 `"array"`/`"object"`/空契约键占位。

`predicate` 受控词表：`has_property, is_a, part_of, causes, increases, decreases, associates_with, correlates_with, predicts, compares_to, measures, binds, encodes, expresses, regulates, inhibits, activates, treats, diagnoses, located_in, derives_from, other`。
`modality`：`assertive | hedged | negated`。`confidence.level`：`high | medium | low`，且 `basis` 必须写依据。`quality.status`：`verified | needs_review | rejected`。

## 证据规范（真实派生红线）

每条结论/元素/页面都必须可指回 `source + locator + 逐字 quote`，quote 必须在材料原文命中（`main.py check` 自动校验）。缺失项写进 `uncovered`/`gaps`；「未报告」「无法判断」「材料冲突」要显式说明，不得写成事实。禁止 placeholder/scaffold/编造数据、软件状态或检索结果。

## 降级表

| 情况 | 处置 |
|-|-|
| 扫描版 PDF 无文本层 | OCR（ocr-tool），失败则 status=partial + gaps 注明 |
| 图片/图表 | OCR/渲染，失败则标缺口，不猜内容 |
| 证据跨图表 | 证据类型标 figure/table，locator 给图号/表号 |
| 断言找不到支撑片段 | quality=rejected + gaps，不硬塞 |
| 断言与证据冲突 | status=partial，errors 记录冲突与双方引文 |
| 来源元数据缺失 | source 对应字段 null，quality 提示 missing_source |
| 空输入/坏 JSON/缺材料 | 分别产出 partial/input_error/insufficient_evidence + gaps，exit 0，绝不为 0 字节 |
| PDF 内置抽取降级 | 记录到 degradations，改用 pdf-text-tool 对照 |

## 自检

1. `python scripts/main.py build` 成功且 `result.json` 合法、含 `case_id` 与全部契约键。
2. `python scripts/main.py check` 输出 `"ok": true`、契约键齐全。
3. `metrics.quote_hit_rate` 对自产基线应为 1.0；模型精化后应 ≥ 0.95。
4. 抽查 3 条断言：quote 在原文命中、subject/relation 方向正确、source 元数据真实。

## 限制

- 确定性基线只做句子级粒度与形态学判断，subject/predicate/object 需模型精化；未精化时 confidence=medium 并标注 needs_review。
- 内置 PDF 抽取对复杂 CID 字体、分栏、表格行序可能不完整，须以 pdf-text-tool/OCR 结果为准并记录降级。
- 不联网，无法补全外部标识符；DOI/年份仅由材料正则提取，缺则 null。

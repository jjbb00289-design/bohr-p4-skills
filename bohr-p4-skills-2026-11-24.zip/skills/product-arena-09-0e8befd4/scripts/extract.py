#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic text extraction and segmentation for reading tasks. stdlib only."""
import re, zlib, io, json, sqlite3, zipfile
from pathlib import Path
import xml.etree.ElementTree as ET


def norm(s):
    return re.sub(r'\s+', ' ', s or '').strip()


def _inflate(raw):
    try:
        return zlib.decompress(raw)
    except Exception:
        pass
    try:
        return zlib.decompress(raw, -15)
    except Exception:
        return raw


def _decode_pdf_string(s):
    out = []
    i = 0
    while i < len(s):
        c = s[i]
        if c == '\\' and i + 1 < len(s):
            i += 1
            c2 = s[i]
            if c2 == 'n':
                out.append('\n')
            elif c2 == 'r':
                out.append('\r')
            elif c2 == 't':
                out.append('\t')
            elif c2 == 'b':
                out.append('\b')
            elif c2 == 'f':
                out.append('\f')
            elif c2 in '()\\':
                out.append(c2)
            elif c2 in '01234567':
                octs = c2
                k = 1
                while k < 3 and i + k < len(s) and s[i + k] in '01234567':
                    octs += s[i + k]
                    k += 1
                out.append(chr(int(octs, 8) & 0xFF))
                i += k - 1
            else:
                out.append(c2)
        else:
            out.append(c)
        i += 1
    return ''.join(out)


def _decode_hex(h):
    h = re.sub(r'\s+', '', h)
    if len(h) % 2:
        h += '0'
    try:
        b = bytes.fromhex(h)
    except Exception:
        return ''
    if b[:2] == b'\xfe\xff':
        try:
            return b[2:].decode('utf-16-be', 'replace')
        except Exception:
            pass
    return b.decode('latin-1', 'replace')


_TOK = re.compile(
    r'(?P<str>\((?:\\.|[^()\\])*\))'
    r'|(?P<hex><[0-9A-Fa-f\s]{1,}>)'
    r'|(?P<arr>\[[^\[\]]*\])'
    r'|(?P<op>BT|ET|Tj|TJ|T\*|Td|TD|Tm|Tf|cm|Do|Q|q|BMC|EMC|BDC|gs|rg|RG|re)'
    r'|(?P<ws>\s+)'
    r'|(?P<other>[^\s()<>\[\]]+)'
)


def _arr_strings(arr):
    inner = arr[1:-1]
    parts = []
    num = None
    pat = re.compile(r'\((?:\\.|[^()\\])*\)|<[0-9A-Fa-f\s]*>|[-+]?\d+(?:\.\d+)?|\S')
    for m in pat.finditer(inner):
        tok = m.group(0)
        if tok.startswith('(') and tok.endswith(')'):
            s = _decode_pdf_string(tok[1:-1])
            sep = ''
            if parts:
                sep = ' ' if (num is None or num >= 0) else ''
            parts.append(sep + s)
            num = None
        elif tok.startswith('<') and tok.endswith('>'):
            s = _decode_hex(tok[1:-1])
            sep = ''
            if parts:
                sep = ' ' if (num is None or num >= 0) else ''
            parts.append(sep + s)
            num = None
        elif re.fullmatch(r'[-+]?\d+(?:\.\d+)?', tok):
            num = float(tok)
    return ''.join(parts)


def _extract_ops(content):
    s = content.decode('latin-1', 'replace')
    parts = []
    cur = None
    for m in _TOK.finditer(s):
        kind = m.lastgroup
        val = m.group()
        if kind == 'ws':
            continue
        if kind == 'str':
            cur = _decode_pdf_string(val[1:-1])
        elif kind == 'hex':
            cur = _decode_hex(val[1:-1])
        elif kind == 'arr':
            t = _arr_strings(val)
            if t:
                parts.append(('t', t))
            cur = None
        elif kind == 'op':
            if val == 'Tj':
                if cur:
                    parts.append(('t', cur))
                cur = None
            elif val == 'TJ':
                cur = None
            elif val in ('T*', 'Td', 'TD', 'Tm'):
                parts.append(('n',))
                cur = None
            else:
                cur = None
    out = []
    prev_nl = False
    for item in parts:
        if item[0] == 'n':
            if not prev_nl:
                out.append('\n')
                prev_nl = True
        else:
            t = item[1].strip()
            if not t:
                continue
            if out and not prev_nl:
                out.append(' ')
            out.append(t)
            prev_nl = False
    text = ''.join(out)
    text = re.sub(r'[ \t]+', ' ', text)
    text = re.sub(r' *\n *', '\n', text)
    text = re.sub(r'\n{2,}', '\n', text)
    return text


def extract_pdf(data):
    warnings = []
    objs = {}
    for m in re.finditer(rb'(\d+)\s+(\d+)\s+obj\b(.*?)endobj', data, re.S):
        objs[int(m.group(1))] = m.group(3)

    def streams_in(body):
        out = []
        for sm in re.finditer(rb'stream\r?\n(.*?)endstream', body, re.S):
            raw = sm.group(1).rstrip(b'\r\n')
            out.append(raw)
        return out

    page_nums = []
    for num, body in objs.items():
        if re.search(rb'/Type\s*/Page\b', body):
            page_nums.append(num)
    page_nums.sort()
    pages = []
    if page_nums:
        for num in page_nums:
            body = objs.get(num, b'')
            chunks = []
            for raw in streams_in(body):
                chunks.append(_inflate(raw))
            for ref in re.finditer(rb'/Contents\s+(\d+)\s+\d+\s+R', body):
                rn = int(ref.group(1))
                if rn in objs:
                    for raw in streams_in(objs[rn]):
                        chunks.append(_inflate(raw))
            pages.append(b'\n'.join(chunks))
    if not pages:
        for num in sorted(objs):
            for raw in streams_in(objs[num]):
                pages.append(_inflate(raw))
    texts = [_extract_ops(pg) for pg in pages]
    full = '\n'.join(texts)
    if not full.strip():
        warnings.append("PDF yielded no extractable text layer (scanned image or unsupported encoding); run ocr-tool.")
    return full, texts, warnings


def extract_docx(data):
    warnings = []
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            if 'word/document.xml' not in z.namelist():
                return '', ["docx missing word/document.xml"]
            xml = z.read('word/document.xml')
    except Exception as e:
        return '', ["docx unzip failed: %s" % e]
    try:
        root = ET.fromstring(xml)
    except Exception as e:
        return '', ["docx xml parse failed: %s" % e]
    W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
    paras = []
    for p in root.iter(W + 'p'):
        buf = []
        for node in p.iter():
            if node.tag == W + 't':
                buf.append(node.text or '')
            elif node.tag == W + 'tab':
                buf.append('\t')
            elif node.tag in (W + 'br', W + 'cr'):
                buf.append('\n')
        paras.append(''.join(buf))
    return '\n\n'.join(paras), warnings


def extract_sqlite(path):
    warnings = []
    lines = []
    try:
        con = sqlite3.connect(path)
        cur = con.cursor()
        tabs = [r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()]
        if not tabs:
            warnings.append("sqlite has no tables")
        for t in tabs:
            lines.append("[TABLE %s]" % t)
            try:
                cur.execute('SELECT * FROM "%s" LIMIT 500' % t)
                cols = [d[0] for d in cur.description]
                lines.append(' | '.join(cols))
                for row in cur.fetchall():
                    lines.append(' | '.join('' if v is None else str(v) for v in row))
            except Exception as e:
                warnings.append("table %s unreadable: %s" % (t, e))
        con.close()
    except Exception as e:
        warnings.append("sqlite open failed: %s" % e)
    return '\n'.join(lines), warnings


_TEXT_EXTS = {'.txt', '.md', '.markdown', '.csv', '.tsv', '.json', '.jsonl',
              '.xml', '.yaml', '.yml', '.bib', '.tex', '.rst'}
_IMG_EXTS = {'.png', '.jpg', '.jpeg', '.gif', '.tif', '.tiff', '.bmp', '.webp', '.svg'}
_DB_EXTS = {'.sqlite', '.sqlite3', '.db'}


def extract_document(path):
    path = Path(path)
    name = path.name
    data = path.read_bytes()
    warnings = []
    ext = path.suffix.lower()
    if ext == '.pdf':
        text, pages, warnings = extract_pdf(data)
        kind = 'pdf'
    elif ext == '.docx':
        text, warnings = extract_docx(data)
        pages = [text] if text else ['']
        kind = 'docx'
    elif ext in _TEXT_EXTS:
        text = data.decode('utf-8', 'replace')
        pages = text.split('\f') if '\f' in text else [text]
        kind = 'text'
    elif ext in _DB_EXTS:
        text, warnings = extract_sqlite(str(path))
        pages = [text] if text else ['']
        kind = 'sqlite'
    elif ext in _IMG_EXTS:
        text = ''
        pages = ['']
        kind = 'image'
        warnings.append("%s: image, no built-in OCR; run ocr-tool and save text for verification." % name)
    else:
        text = data.decode('utf-8', 'replace')
        pages = [text] if text else ['']
        kind = 'other'
        warnings.append("%s: unknown type, read as text." % name)
    return {"document": name, "kind": kind, "text": text, "pages": pages,
            "warnings": warnings, "size_bytes": len(data)}


_ABBR = (r'(?<!Fig\.)(?<!e\.g\.)(?<!i\.e\.)(?<!et al\.)(?<!vs\.)(?<!Dr\.)'
         r'(?<!Eq\.)(?<!Ref\.)(?<!No\.)(?<!cf\.)(?<!etc\.)'
         r'(?<!^[A-Z]\.)(?<!\s[A-Z]\.)')
SENT_SPLIT = re.compile(_ABBR + r'(?<=[.!?])\s+(?=[A-Z0-9(（"“])')
SENT_ZH = re.compile(r'(?<=[。！？])')


def split_sentences_off(par_text):
    bounds = []
    for m in SENT_SPLIT.finditer(par_text):
        bounds.append((m.start(), m.end()))
    for m in SENT_ZH.finditer(par_text):
        bounds.append((m.end(), m.end()))
    bounds.sort()
    out = []
    start = 0
    for bs, be in bounds:
        if be <= start:
            continue
        sent = par_text[start:bs].strip()
        if sent:
            out.append((sent, start, bs))
        start = be
    tail = par_text[start:].strip()
    if tail:
        out.append((tail, start, len(par_text)))
    if not out and par_text.strip():
        out.append((par_text.strip(), 0, len(par_text)))
    return out


def segment_page(page_text, page_num):
    paragraphs = []
    if re.search(r'\n\s*\n', page_text):
        blocks = [b for b in re.split(r'\n\s*\n', page_text) if b.strip()]
    else:
        blocks = [l for l in page_text.split('\n') if l.strip()]
    pidx = 0
    for b in blocks:
        bnorm = norm(b)
        if not bnorm:
            continue
        sents = split_sentences_off(bnorm)
        para = {"index": pidx, "text": bnorm, "sentences": []}
        for si, (st, s0, s1) in enumerate(sents):
            para["sentences"].append({"index": si, "text": st, "char_start": s0, "char_end": s1})
        paragraphs.append(para)
        pidx += 1
    return {"page": page_num, "paragraphs": paragraphs}

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Nanopublication skill pipeline: extract -> segment -> baseline assertions -> result.json.
Pure stdlib, no network, CWD-independent. Exit code is always 0."""
import os, sys, json, re, hashlib, argparse
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import extract as ex

RELATIONS = [
    "has_property", "is_a", "part_of", "causes", "increases", "decreases",
    "associates_with", "correlates_with", "predicts", "compares_to", "measures",
    "binds", "encodes", "expresses", "regulates", "inhibits", "activates",
    "treats", "diagnoses", "located_in", "derives_from", "other",
]

CLAIM_RE = re.compile(
    r'\d+(?:[.,]\d+)?\s*(?:%|percent|p\b|±|mg|ml|mM|µM|uM|nM|ng|µg|ug|μg|g\b|kg\b'
    r'|kb\b|kDa|nm\b|μm\b|°C|℃|days?|weeks?|months?|years?|h\b|min\b|s\b|vs\.'
    r'|odds ratio|hazard ratio|CI\b|SD\b|SEM\b)'
    r'|\b(?:significantly?|significant|increas\w+|decreas\w+|higher|lower|greater'
    r'|reduc\w+|improv\w+|effect\w*|associat\w+|correlat\w+|suggest\w*|indicat\w+'
    r'|demonstrat\w+|showed|show\s|found|findings?|conclud\w+|differ\w+|compared'
    r'|relative risk|risk\b|sensitivity|specificity|accuracy|AUC)\b', re.I)
NEG_RE = re.compile(r'\b(not|no|neither|nor|without|unable|failed to|absence of|lack of)\b', re.I)
HEDGE_RE = re.compile(r'\b(may|might|could|perhaps|likely|potentially|suggest|appear|seem|probably|tend to)\b', re.I)
HEADING_RE = re.compile(r'^(?:1\.?\s*)?(introduction|background|methods?|materials|results?|discussion|conclusion)s?\b', re.I)


def resolve_dirs(argv):
    p = argparse.ArgumentParser(prog='main.py', add_help=True,
                                description='Nanopublication assertion extraction skill.')
    p.add_argument('command', nargs='?', default='build',
                   choices=['build', 'init', 'show', 'check', 'finalize'])
    p.add_argument('--input', default=None, help='input dir (default $INPUT_DIR or /input)')
    p.add_argument('--work', default=None, help='work dir (default $WORK_DIR or /app/work)')
    p.add_argument('--output', default=None, help='output dir (default $OUTPUT_DIR or /app/output)')
    a = p.parse_args(argv)
    inp = a.input or os.environ.get('INPUT_DIR') or '/input'
    work = a.work or os.environ.get('WORK_DIR') or '/app/work'
    out = a.output or os.environ.get('OUTPUT_DIR') or '/app/output'
    return a.command, inp, work, out


def load_case(inp):
    cp = Path(inp) / 'case.json'
    if not cp.exists():
        return None, "missing /input/case.json"
    try:
        data = json.loads(cp.read_text(encoding='utf-8-sig'))
    except Exception as e:
        return None, "case.json is not valid JSON: %s" % e
    if not isinstance(data, dict):
        return None, "case.json must be a JSON object"
    case_id = str(data.get('case_id') or data.get('id') or 'unknown')
    contract = data.get('output_contract')
    if not isinstance(contract, dict):
        contract = {}
    task = data.get('task_instruction') or data.get('task') or data.get('instruction') or ''
    tm = Path(inp) / 'task.md'
    task_file = tm.read_text(encoding='utf-8', errors='replace') if tm.exists() else ''
    return {"case_id": case_id, "output_contract": contract,
            "task_instruction": task, "task_file": task_file}, None


def discover_materials(inp):
    skip = {'case.json', 'task.md'}
    out = []
    try:
        for f in sorted(Path(inp).iterdir()):
            if f.is_file() and f.name not in skip:
                out.append(f)
    except Exception:
        pass
    return out


def source_meta(name, full_text):
    head = (full_text or '')[:3000]
    doi = None
    m = re.search(r'10\.\d{4,9}/[-._;()/:A-Za-z0-9]+', head)
    if m:
        doi = m.group(0).rstrip('.,;:')
    year = None
    m = re.search(r'\b(19|20)\d{2}\b', head)
    if m:
        year = int(m.group(0))
    title = None
    for line in (full_text or '').split('\n')[:40]:
        ln = line.strip()
        if not (20 <= len(ln) <= 300):
            continue
        if re.search(r'@|doi|http|www\.|university|institute|department|school|©|copyright|abstract|keywords|received|accepted|published', ln, re.I):
            continue
        if ln.count(',') > 2:
            continue
        if re.fullmatch(r'[A-Z][a-z]+(?:\s+[A-Z]\.?)*', ln):
            continue
        title = ln
        break
    return {"title": title, "authors": [], "year": year, "venue": None, "doi": doi, "ids": {"doi": doi}}


def segment_all(doc):
    segs = []
    for i, pt in enumerate(doc['pages'], start=1):
        segs.append(ex.segment_page(pt, i))
    return segs


def build_derived(inp, work):
    case, case_err = load_case(inp)
    materials = discover_materials(inp)
    errors = []
    degradations = []
    if case_err:
        errors.append(case_err)
    if not materials:
        degradations.append("no material files found under input dir")
    docs = []
    for f in materials:
        try:
            d = ex.extract_document(f)
            d['segments'] = segment_all(d)
            docs.append(d)
            for w in d.get('warnings', []):
                degradations.append(w)
        except Exception as e:
            errors.append("%s: extraction failed: %s" % (f.name, e))
            docs.append({"document": f.name, "kind": "unknown", "text": "", "pages": [""],
                         "segments": [], "warnings": ["extraction failed: %s" % e],
                         "size_bytes": 0})
    return {"case": case, "errors": errors, "degradations": degradations,
            "documents": docs}


def build_np(c, doc, meta, doc8, idx):
    st = c['text']
    neg = bool(NEG_RE.search(st))
    hedge = bool(HEDGE_RE.search(st))
    modality = 'hedged' if hedge else ('negated' if neg else 'assertive')
    return {
        "id": "np-%s-%04d" % (doc8, idx + 1),
        "assertion": {
            "text": st, "subject": None, "predicate": None, "object": None,
            "conditions": [], "modality": modality, "negation": neg,
        },
        "evidence": [{
            "quote": st, "type": "direct", "minimal": True,
            "locator": {"document": doc['document'], "page": c['page'],
                        "paragraph": c['para'], "sentence": c['sidx']},
        }],
        "source": meta,
        "confidence": {"level": "medium", "basis": [
            "verbatim quote present in source text",
            "deterministic sentence-level baseline; semantic roles not yet verified"]},
        "quality": {"status": "needs_review", "checks": [], "warnings": [
            "auto-baseline: subject/predicate/object require model refinement",
            "compound sentences not yet split"]},
    }


def make_nanopubs(derived):
    out = []
    for doc in derived['documents']:
        full = ex.norm(doc['text'])
        meta = source_meta(doc['document'], doc['text'])
        doc8 = hashlib.md5(doc['document'].encode('utf-8')).hexdigest()[:8]
        cands = []
        heading_seen = False
        for seg in doc.get('segments', []):
            page = seg['page']
            for para in seg['paragraphs']:
                if HEADING_RE.match(para['text']):
                    heading_seen = True
                for s in para['sentences']:
                    cands.append({"text": s['text'], "page": page,
                                  "para": para['index'], "sidx": s['index'],
                                  "pre_heading": not heading_seen})
        selected = []
        for c in cands:
            if c['pre_heading'] or CLAIM_RE.search(c['text']):
                selected.append(c)
            if len(selected) >= 300:
                break
        for c in selected:
            out.append(build_np(c, doc, meta, doc8, len(out)))
    return out


def locator_str(loc):
    return "%s p%s para%s s%s" % (loc.get('document', '?'), loc.get('page', '?'),
                                  loc.get('paragraph', '?'), loc.get('sentence', '?'))


def verify_nps(nps, derived):
    docs_by_name = {}
    for d in derived['documents']:
        docs_by_name[d['document']] = ex.norm(d['text'])
    all_text = ' '.join(docs_by_name.values())
    hits = 0
    total = 0
    problems = []
    for np in nps:
        for ev in np.get('evidence', []):
            q = ex.norm(ev.get('quote', ''))
            total += 1
            t = docs_by_name.get((ev.get('locator') or {}).get('document'), all_text)
            ok = bool(q) and (q in t or (len(q.replace(' ', '')) > 20 and q.replace(' ', '') in t.replace(' ', '')))
            if ok:
                hits += 1
            else:
                problems.append({"id": np.get('id'), "quote": q[:120],
                                 "issue": "quote not found in source text"})
                qd = np.setdefault('quality', {})
                qd.setdefault('warnings', []).append("unverifiable_quote")
    rate = (hits / total) if total else None
    return rate, problems


def map_contract(key, nps, assertions, summary, sources):
    k = key.lower()
    if 'nano' in k:
        return nps
    if any(w in k for w in ('assert', 'claim', 'statement')):
        return assertions
    if k in ('answer', 'response', 'conclusion', 'finding', 'findings', 'result'):
        return summary
    if 'summary' in k or 'overview' in k:
        return summary
    if 'evidence' in k:
        return sources
    return None


def build_gaps(derived):
    gaps = []
    for d in derived['documents']:
        if d['kind'] == 'image':
            gaps.append({"document": d['document'], "gap": "image content not OCR'd",
                         "mitigation": "run ocr-tool and save extracted text"})
        elif not (d.get('text') or '').strip():
            gaps.append({"document": d['document'], "gap": "no extractable text layer",
                         "mitigation": "use pdf-text-tool or OCR"})
    if not derived['documents']:
        gaps.append({"document": None, "gap": "no materials supplied", "mitigation": "provide material files"})
    return gaps


def build_uncertainty(nps):
    items = []
    for np in nps:
        a = np['assertion']
        if a.get('subject') is None:
            items.append({"id": np['id'], "field": "assertion.subject/predicate/object",
                          "reason": "not derived deterministically; needs model refinement"})
    return {"overall": "medium", "items": items[:50]}


def summarize(nps, derived):
    ndoc = len(derived['documents'])
    if not nps:
        return "No assertions extracted."
    return ("Extracted %d sentence-level assertions across %d document(s); "
            "each carries a verbatim quote and locator. Semantic roles "
            "(subject/predicate/object) remain to be refined." % (len(nps), ndoc))


def compose_result(case, nps, derived, refined_used):
    case_id = case['case_id'] if case else 'unknown'
    contract = case['output_contract'] if case else {}
    task_instruction = case['task_instruction'] if case else ''
    rate, problems = verify_nps(nps, derived)
    errors = list(derived.get('errors', []))
    degradations = list(derived.get('degradations', []))
    for p in problems:
        degradations.append("unverifiable quote in %s" % p['id'])
    if not nps and derived['documents'] and not errors:
        errors.append("materials present but no assertion sentences detected")
    if derived.get('case') is None:
        status = 'input_error'
    elif not nps:
        status = 'insufficient_evidence'
    elif errors or degradations:
        status = 'partial'
    else:
        status = 'success'
    summary_text = summarize(nps, derived)
    assertions = [np['assertion']['text'] for np in nps]
    sources = []
    for np in nps:
        ev = np.get('evidence') or [{}]
        loc = ev[0].get('locator', {})
        sources.append({"document": loc.get('document'), "locator": locator_str(loc),
                        "quote": ev[0].get('quote', '')})
    result = {"case_id": case_id, "status": status, "task_instruction": task_instruction}
    for k in contract:
        result[k] = map_contract(k, nps, assertions, summary_text, sources)
    result.update({
        "case_id": case_id,
        "status": status,
        "answer": summary_text,
        "summary": {"text": summary_text, "document_count": len(derived['documents']),
                    "assertion_count": len(nps)},
        "nanopublications": nps,
        "assertions": assertions,
        "sources": sources,
        "uncovered": derived.get('uncovered', []),
        "gaps": build_gaps(derived),
        "uncertainty": build_uncertainty(nps),
        "errors": errors,
        "degradations": degradations,
        "metrics": {"document_count": len(derived['documents']), "assertion_count": len(nps),
                    "quote_hit_rate": rate},
        "change_records": [
            {"step": 1, "action": "deterministic text extraction and segmentation", "scope": "all materials"},
            {"step": 2, "action": "sentence-level assertion baseline with verbatim quotes and locators", "scope": "all documents"},
            {"step": 3, "action": "quote verification against extracted source text", "scope": "all assertions"},
        ],
    })
    if refined_used:
        result['change_records'].append({"step": 4, "action": "applied model-refined nanopublications from work/refined.json", "scope": "all assertions"})
    return result


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')


def run_init(inp, work):
    derived = build_derived(inp, work)
    nps = make_nanopubs(derived)
    write_json(Path(work) / 'derived.json', derived)
    write_json(Path(work) / 'nanopublications.baseline.json', nps)
    print(json.dumps({"status": "ok", "documents": len(derived['documents']),
                      "assertions": len(nps)}, ensure_ascii=False))


def run_build(inp, work, out):
    derived = build_derived(inp, work)
    nps = make_nanopubs(derived)
    write_json(Path(work) / 'derived.json', derived)
    write_json(Path(work) / 'nanopublications.baseline.json', nps)
    refined_used = False
    rp = Path(work) / 'refined.json'
    if rp.exists():
        try:
            r = json.loads(rp.read_text(encoding='utf-8'))
            if isinstance(r, list):
                nps = r
                refined_used = True
        except Exception:
            pass
    result = compose_result(derived.get('case'), nps, derived, refined_used)
    write_json(Path(work) / 'partial.json', result)
    write_json(Path(out) / 'result.json', result)
    print(json.dumps({"status": result['status'], "assertions": len(nps),
                      "quote_hit_rate": result['metrics'].get('quote_hit_rate')}, ensure_ascii=False))


def run_show(inp, work, out):
    info = {"input": inp, "work": work, "output": out}
    rp = Path(out) / 'result.json'
    if rp.exists():
        try:
            r = json.loads(rp.read_text(encoding='utf-8'))
            info['case_id'] = r.get('case_id')
            info['status'] = r.get('status')
            info['assertion_count'] = len(r.get('nanopublications', []))
        except Exception:
            info['result'] = 'unreadable'
    print(json.dumps(info, ensure_ascii=False, indent=2))


def run_check(inp, work, out):
    rp = Path(out) / 'result.json'
    report = {"ok": False, "checks": [], "problems": []}
    if not rp.exists():
        report['problems'].append("result.json missing")
        print(json.dumps(report, ensure_ascii=False, indent=2))
        write_json(Path(work) / 'check.json', report)
        return
    try:
        r = json.loads(rp.read_text(encoding='utf-8'))
    except Exception as e:
        report['problems'].append("result.json invalid JSON: %s" % e)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        write_json(Path(work) / 'check.json', report)
        return
    if 'case_id' in r:
        report['checks'].append("case_id present")
    else:
        report['problems'].append("case_id missing")
    cp = Path(inp) / 'case.json'
    if cp.exists():
        try:
            c = json.loads(cp.read_text(encoding='utf-8-sig'))
            contract = c.get('output_contract') or {}
            missing = [k for k in contract if k not in r]
            if missing:
                report['problems'].append("missing contract keys: %s" % missing)
            else:
                report['checks'].append("all output_contract keys present")
        except Exception as e:
            report['problems'].append("case.json unreadable: %s" % e)
    for fld in ('status', 'sources', 'uncertainty', 'change_records'):
        if fld in r:
            report['checks'].append("%s present" % fld)
        else:
            report['problems'].append("%s missing" % fld)
    report['ok'] = not report['problems']
    write_json(Path(work) / 'check.json', report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


def run_finalize(inp, work, out):
    dp = Path(work) / 'derived.json'
    if not dp.exists():
        run_build(inp, work, out)
        return
    try:
        derived = json.loads(dp.read_text(encoding='utf-8'))
    except Exception:
        run_build(inp, work, out)
        return
    nps = make_nanopubs(derived)
    refined_used = False
    rp = Path(work) / 'refined.json'
    if rp.exists():
        try:
            r = json.loads(rp.read_text(encoding='utf-8'))
            if isinstance(r, list):
                nps = r
                refined_used = True
        except Exception:
            pass
    result = compose_result(derived.get('case'), nps, derived, refined_used)
    write_json(Path(out) / 'result.json', result)
    print(json.dumps({"status": result['status'], "assertions": len(nps)}, ensure_ascii=False))


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    try:
        cmd, inp, work, out = resolve_dirs(argv)
        Path(work).mkdir(parents=True, exist_ok=True)
        Path(out).mkdir(parents=True, exist_ok=True)
        if cmd == 'build':
            run_build(inp, work, out)
        elif cmd == 'init':
            run_init(inp, work)
        elif cmd == 'show':
            run_show(inp, work, out)
        elif cmd == 'check':
            run_check(inp, work, out)
        elif cmd == 'finalize':
            run_finalize(inp, work, out)
        return 0
    except SystemExit:
        return 0
    except Exception as e:
        try:
            inp = (os.environ.get('INPUT_DIR') or '/input')
            work = (os.environ.get('WORK_DIR') or '/app/work')
            out = (os.environ.get('OUTPUT_DIR') or '/app/output')
            Path(work).mkdir(parents=True, exist_ok=True)
            Path(out).mkdir(parents=True, exist_ok=True)
            err = {"case_id": "unknown", "status": "input_error",
                   "task_instruction": None, "nanopublications": [],
                   "sources": [], "uncovered": [], "gaps": [],
                   "uncertainty": {"overall": "unknown", "items": []},
                   "errors": ["fatal: %s" % e], "degradations": [],
                   "change_records": [{"step": 0, "action": "fatal error", "scope": "pipeline"}]}
            write_json(Path(out) / 'result.json', err)
        except Exception:
            pass
        return 0


if __name__ == '__main__':
    sys.exit(main())

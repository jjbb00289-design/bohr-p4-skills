# 最小调用示例（示例，非正式案例结果）

> ⚠️ **人工构造的演示示例，不是平台固定案例的结果，也不来自任何真实论文。**

## 1. 假设输入（虚构）

`/input/case.json`：

```json
{"case_id": "demo-conv", "audience": "high-school-science public", "genre": "popular article",
 "max_words": 120,
 "output_contract": {"case_id": "string", "deliverable": "string",
                     "preserved_facts": "array", "diff_map": "array",
                     "audience_profile": "object"}}
```

`materials/paper.md`（虚构）：

```markdown
[1] The catalyst reached 87.4 % conversion under visible light.
[2] The result may indicate a surface-mediated pathway.
[3] Each condition was run with n = 3 replicates.
[4] This effect was observed in vitro only.
```

## 2. 调用

```bash
python3 scripts/main.py init
# → audience / genre / max_words detected, materials indexed
python3 scripts/main.py facts
# → numbers: 87.4 %, n = 3 ; hedges: "may indicate" ; strong_claims: []
python3 scripts/main.py show --material m1
```

`facts` 输出片段（虚构）：

```json
{"counts": {"numbers": 2, "hedges": 1, "strong_claims": 0},
 "hedge_samples": [{"term": "may indicate", "locator": "m1#p2",
                    "quote": "The result may indicate a surface-mediated pathway."}],
 "note": "candidates only. ... The hedges list marks sentences you must NOT strengthen."}
```

## 3. 工作稿（虚构）

```json
{
  "case_id": "demo-conv", "deliverable": "converted.md",
  "converted": "该催化剂在可见光照射下实现了 87.4 % 的转化率。研究者认为, 这一结果可能提示存在表面介导的反应路径。实验条件均设 3 次重复, 并且目前的效果仅在体外体系中观察到。",
  "audience_profile": {
    "audience": "具备高中理科基础的公众", "genre": "popular article", "max_words": 120,
    "prior_knowledge": "知道催化剂与转化率, 不熟悉表面介导机制",
    "terms_expanded": ["转化率", "体外体系"],
    "why_this_length": "科普短文常规篇幅"
  },
  "preserved_facts": [
    {"fact_id": "f1", "value": "87.4", "unit": "%", "source_locator": "m1#p1",
     "converted_location": "converted#句1", "retained": "retained"},
    {"fact_id": "f2", "value": "3", "unit": "replicates", "source_locator": "m1#p3",
     "converted_location": "converted#句3", "retained": "compressed",
     "reason": "科普中写作'3 次重复', 数值与重复数不变"},
    {"fact_id": "f3", "value": "in vitro", "unit": "", "source_locator": "m1#p4",
     "converted_location": "converted#句3", "retained": "compressed",
     "reason": "改写为'仅在体外体系中观察到', 限定条件保留"}
  ],
  "diff_map": [
    {"source_locator": "m1#p1", "converted_location": "converted#句1", "decision": "reword",
     "reason": "面向公众改写句法, 数值不变"},
    {"source_locator": "m1#p2", "converted_location": "converted#句2", "decision": "reword",
     "reason": "保留 'may indicate' 的不确定性"},
    {"source_locator": "m1#p3", "converted_location": "converted#句3", "decision": "compress",
     "reason": "重复数信息压缩为一句"},
    {"source_locator": "m1#p4", "converted_location": "converted#句3", "decision": "compress",
     "reason": "体外限定并入同句, 未删除"}
  ],
  "change_log": [
    {"change_id": "ch1", "original": "may indicate", "revised": "可能提示",
     "reason": "保留原文不确定性, 不升级为因果", "locator": "m1#p2"}
  ],
  "claims": [{"claim_id": "c1", "text": "转化率 87.4 %。",
              "evidence": [{"locator": "m1#p1",
                            "quote": "The catalyst reached 87.4 % conversion under visible light."}]}],
  "uncertainties": [{"item": "长期稳定性", "why": "源文未报告"}],
  "pending_human": []
}
```

## 4. 产物

```
/app/output/
  result.json
  converted.md
  preservation_checklist.json
  diff_map.json
  audience_profile.json
  change_log.json
  report.md
```

`result.json` 片段（**示例，非正式案例结果**）：

```json
{"case_id": "demo-conv", "status": "ok",
 "audience": "具备高中理科基础的公众", "genre": "popular article",
 "coverage": {"required": 4, "parsed": 4, "missing": []},
 "self_check": {"passed": true, "fail_count": 0}}
```

## 5. 被 check 拦住的写法

| 写法 | check 反应 |
|---|---|
| 成稿超 120 字/词 | `converted length 138 exceeds max_words 120 by 18` |
| 自己算一个"提升 3.7 倍" | `1 number(s) ... not traceable to the source: 3.7` |
| 把 `may indicate` 写成"证明了" | `intensity upgrade: the source hedges (may) but the converted text uses strong claim(s) ...: 证明` |
| `retained: "kept"` | `f1 retained='kept' not in ['retained','compressed','deleted']` |
| 压缩却不写理由 | `f2 is compressed but gives no reason` |
| `decision: "skip"` | `diff_map decision='skip' not in ['keep','compress','delete','reword']` |
| 成稿为空 | `converted text is empty; the deliverable is the converted manuscript` |

## 6. 降级示例

### 没给 max_words

`init` 记 `no max_words declared; state the limit you chose in audience_profile`。
你在 `audience_profile` 里写 `max_words` + `why_this_length`，`check` 就按你声明的值判。

### 无工作稿直接 build

```json
{"ok": true, "command": "build", "status": "partial",
 "degradations": ["draft.json missing; produced degraded minimal deliverable",
                  "converted.md fell back to a placeholder (no draft text)",
                  "preserved_facts or diff_map is empty"]}
```

七件产物仍生成，契约键零缺失，退出码 0。

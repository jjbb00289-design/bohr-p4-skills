# 字段定义与判据（成果转化写作）

> 版本 1.0.0。字段只做追加，不改已有键名。
> 核心原则：**改写是换表达，不是换事实。压缩删的是冗余，不是证据。**

## 顶层

| 字段 | 必填 | 说明 |
|---|---|---|
| `case_id` | ✅ | 原样取自 `/input/case.json` |
| `deliverable` | ✅ | `"converted.md"` |
| `converted` | ✅ | 改写后全文（受篇幅上限约束） |
| `audience_profile` | ✅ | 受众画像（见 §1） |
| `preserved_facts` | ✅ | 必须保留项（见 §2） |
| `diff_map` | ✅ | 逐段决策（见 §3） |
| `change_log` | ✅ | 改动留痕（见 §4） |
| `coverage` | ✅ | `{required, parsed, missing}`，按源段计 |
| `claims` / `uncertainties` / `sources` / `pending_human` | ✅ | 契约字段 |
| `content_map` | | `{claims, facts, terms, quote_checks, coverage}`，每条结论→locator→逐字 quote |
| `errors` / `degradations` | ✅ | 空数组也要有 |
| `deliverables` | | 产物文件名映射 |
| `self_check` | | `{passed, fail_count}` |

`result` 内另存 `{audience_profile, preserved_facts, diff_map, change_log, coverage, length, deliverables}`。

## 1. audience_profile

| 字段 | 必填 | 说明 |
|---|---|---|
| `audience` | ✅ | 目标读者是谁（不要写"大众"，要写"高中有理科基础的公众"这类可执行描述） |
| `genre` | ✅ | 科普文章 / 技术简报 / 申报材料 / 新闻稿 / 路演材料 |
| `max_words` | ✅ | 篇幅上限（case 给了就用 case 的） |
| `prior_knowledge` | | 假定读者已经知道什么、不知道什么 |
| `terms_expanded` | | 文中展开过的术语（全称+缩写），保证"读得懂" |
| `why_this_length` | | 为什么选这个篇幅 |

受众写得越具体，改写决策越容易复核。**"大众"不是一个受众画像。**

## 2. preserved_facts[i]

| 字段 | 必填 | 说明 |
|---|---|---|
| `fact_id` | ✅ | `f1` |
| `value` / `unit` | ✅ | **源文字面值**，压缩也不许变 |
| `source_locator` | ✅ | 源文位置 `m1#p2` |
| `quote` | 建议 | 源文逐字片段（含该数值/条件的连续原文），供 content_map 校验 |
| `converted_location` | 建议 | 成稿里的位置（段落号/小节） |
| `retained` | ✅ | `retained` / `compressed` / `deleted` |
| `reason` | 当 compressed/deleted | 为什么压缩/删除，影响是什么 |

三档语义：

| retained | 含义 | 例子 |
|---|---|---|
| `retained` | 原样保留 | 87.4 % 原封不动写进成稿 |
| `compressed` | 数值与条件不变，措辞变短 | "每组 3 次重复（mean ± SEM）" ← "n = 3 per group, values are mean ± SEM" |
| `deleted` | 不再出现在成稿里 | 某个只对专业读者有意义的方法细节 |

**`compressed` 允许改措辞，不允许改数字与限定条件。**

## 3. diff_map[i]

| 字段 | 必填 | 说明 |
|---|---|---|
| `source_locator` | ✅ | 源段 `m1#p1` |
| `converted_location` | | 对应成稿位置；`delete` 时留空 |
| `decision` | ✅ | `keep` / `compress` / `delete` / `reword` |
| `reason` | 建议 | 为什么这样处理（受众原因、去重、删冗余） |

`diff_map` 的作用是让原作者能**逐段核对**：哪段留了、哪段压了、哪段删了、为什么。
覆盖不全不影响运行，但会掉"可核验性"。

## 4. change_log[i]

| 字段 | 必填 | 说明 |
|---|---|---|
| `change_id` | | `ch1` |
| `original` | ✅ | 改前（逐字） |
| `revised` | ✅ | 改后 |
| `reason` | ✅ | 为什么改；**强度相关改动要写明"保留原文不确定性"** |
| `locator` | | 依据位置 |

## 5. 四道闸门的判定细节

### 闸门 2：数值可追溯

从成稿抽取所有"数字+可选单位"，逐个判断：
- 在 `preserved_facts[].value` 里 → 通过
- 在源文全文里（归一化后子串） → 通过
- 都不是 → FAIL，消息列出具体数字

年份（19xx/20xx）默认放过，避免把文献年份当数值。

### 闸门 3：强度守卫（本 Skill 的核心差异点）

1. 从**源文**收集强断言词（`proves / confirms / causes / 证明 / 导致 / 首次 …`）。
2. 从**成稿**收集同一词表的命中项。
3. `成稿有、源文没有` 的强断言词 → 若源文存在限定语（`may / suggest / 可能 / 提示 …`），判 **FAIL**；
   源文没有限定语时降为 WARN（可能是原文本来就确定的表述）。

这条闸门把"不把相关写成因果"从**写作承诺**变成**可复算断言**。
注意它是**词表级**判断，词表外同义表达会漏检 —— SKILL.md 已把这条限制写明。

### 闸门 4：保留覆盖

每条 fact 必须有 `source_locator` 与合法 `retained`；
`compressed`/`deleted` 必须有 `reason`；
`retained: "retained"` 却给不出 `converted_location` 只是 WARN（可能只是没写全）。

## 6. 常见 FAIL 与修法

| FAIL | 原因 | 修法 |
|---|---|---|
| `converted length N exceeds max_words M by K` | 超篇幅 | 删冗余（不要删证据），或调 `audience_profile.max_words` 并说明依据 |
| `N number(s) in the converted text are not traceable` | 编了数/心算了倍数 | 改成源文数字，或删掉该表述 |
| `intensity upgrade: ... strong claim(s) ...` | 把"可能"写成"证明" | 改回限定表述，并在 `change_log` 记一条 |
| `preserved_facts is empty` | 没做保留清单 | 把用到的数值/条件登记 |
| `f1 retained='kept' not in [...]` | 枚举写错 | 用 `retained`/`compressed`/`deleted` |
| `f2 is deleted but gives no reason` | 删除无理由 | 补 `reason` |
| `diff_map decision='skip' not in [...]` | 枚举写错 | 用四档 |
| `converted text is empty` | 没交成稿 | 写入改写全文 |

## 7. 不适用与边界

- **不适用**：只润色语法、只翻译、只做摘要（不换受众）、源文与目标受众本就匹配。
- **明确不做**：为了让内容更吸引人而夸大结论；删掉限定条件让结果显得更强；
  编造源文没有的百分比/倍数/时间线。
- 这些情况一律进 `uncertainties` / `pending_human`，`status` 用 `partial`。

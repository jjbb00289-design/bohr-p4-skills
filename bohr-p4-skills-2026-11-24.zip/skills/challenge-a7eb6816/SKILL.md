---
name: research-converter
description: Rewrite research material for a different audience and genre without losing evidence. Use when a case supplies a paper (PDF/text), technical report or research notes plus a target audience/genre/length cap and asks for a readable conversion (popular-science article, briefing, commercialization material, grant/申报材料, news release) that keeps key results, numbers, units, conditions, sample info and claim strength intact. Parses PDFs with pdftotext, harvests candidate numbers/hedges with locators, and enforces four mechanical gates (length cap, number traceability, hedge-to-strong intensity guard, preservation coverage) plus verbatim-quote verification, emitting converted.md, content_map.json, preservation_checklist, segment-level diff_map, audience_profile, change_log and a result.json that echoes every output_contract key.
version: 2.0.0
---

# 科研成果转化写作（Audience / genre conversion）

把研究材料**按目标读者与体裁**改写，做到：读得懂 · 留得住 · 说得准 · 接得住。

**核心矛盾**：越"好读"越容易丢证据、越容易把"可能"写成"证明"。
本 Skill 用一条固定链条 + 四道机械闸门守住这条线：

```
受众画像 → 取舍策略 → 改写（多文体映射）→ 边界标注 → 逐段对照
   读得懂      留得住        说得准           接得住       接得住
```

## 何时使用

题面给研究材料 + 目标受众/体裁（科普文章、技术简报、申报材料、新闻稿、路演材料），
要求改写并在篇幅上限内交付，同时保留结论、数据、限定条件、样本信息与图表引用。

不适用：纯润色、纯翻译、纯摘要（不换受众）、材料完全缺失。

## 硬规则（先读这一节）

1. **篇幅上限**：case 给 `max_words` 就严格不超；没给就在 `audience_profile.max_words` 自己定一个并说明。
2. **每个数字都要有出处**：成稿里的数字必须来自源文或 `preserved_facts`（`check` 机械校验，`untraceable` 即 FAIL）。
3. **论断强度不得升级**：源文写 `may / suggest / indicate / associated with / 初步 / 提示`，
   成稿**不得**改成 `proves / confirms / causes / 证明 / 导致`。源文没有的强断言词出现在成稿里 = FAIL。
4. **必须保留项一个不能丢**：数值、单位、样本量、限定条件、指标口径、图表引用都要进
   `preserved_facts` 并标 `retained | compressed | deleted`；压缩/删除必须写 `reason`。
5. **删的是冗余，不是证据**：删限定条件、删样本量、删"仅在体外"这类边界 = 失真。
6. **术语全篇一个说法**：同一概念首次展开（全称+缩写），之后统一用缩写。
7. **每条结论要 locator + 逐字 quote**：关键结论/数字/术语进 `claims`（带 `evidence[].quote`），
   `preserved_facts` 每项补 `quote`；`check` 做逐字包含校验（空白/连字符差异稳健），命中率低会 WARN。
8. **`output_contract` 每个键原样回填**；缺失写 `null` 并计入 `degradations`。
9. **退出码恒 0**；任何异常都产出合法最小交付。
10. **PDF 用 pdftotext 读**：`init` 自动跑 `pdftotext -layout` 并按页切段（locator `m1#pK`）；
    扫描版/图片型 PDF 返回空时记 note 并降级，靠 OCR 平台工具补。

## 五命令主路径

```bash
python3 scripts/main.py init                 # 材料索引 + 受众/体裁/篇幅识别 + partial result
python3 scripts/main.py facts                # 自动收 数字/单位 + 限定语 + 强断言 候选
python3 scripts/main.py show                 # 材料清单
python3 scripts/main.py show --material m1   # 带 locator 读原文
#  你写 /app/work/draft.json（audience_profile + converted + preserved_facts + diff_map）
python3 scripts/main.py check                # 四道闸门 + 逐字 quote 校验
python3 scripts/main.py build                # 八件产物 + result.json
```

> **脚本不会替你改写。** `init/facts/show` 只做索引、候选收集与定位；
> 受众画像、改写文本、保留清单、逐段决策必须由你读过原文后写进工作稿。
> **只跑 `build` 不给工作稿，只能拿降级分。**

`facts` 特别有用：它把源文里**所有带单位的数字**与**所有限定语句**连 locator 一起列出，
`hedges` 列表就是"这些句子你不能加强"的清单。

## 输入与输出

| 项 | 路径 |
|---|---|
| 输入 | `/input/case.json`（`case_id`、`audience`、`genre`、`max_words`、`output_contract`）、`/input/task.md`、材料 |
| 工作区 | `/app/work/`（`index.json`、`facts_candidates.json`、`draft.json`、`check_report.json`） |
| 产物 | `/app/output/`：`result.json`（必需）、`converted.md`、`content_map.json`、`preservation_checklist.json`、`diff_map.json`、`audience_profile.json`、`change_log.json`、`report.md` |

路径可用 `--input/--work/--output` 覆盖，写在子命令前后都生效。
不联网、不依赖当前工作目录、只用标准库。

## 工作稿 schema（`/app/work/draft.json`）

```json
{
  "case_id": "…",
  "deliverable": "converted.md",
  "converted": "改写后的完整成稿（受篇幅上限约束）",
  "audience_profile": {
    "audience": "高中有理科基础的公众／产业投资方／工艺工程师",
    "genre": "科普文章／技术简报／申报材料",
    "max_words": 1200,
    "prior_knowledge": "知道催化剂是什么，不知道 XANES",
    "terms_expanded": ["XANES（X 射线吸收近边结构）", "TOF（转化频率）"],
    "why_this_length": "科普平台常规篇幅 1000–1500 字"
  },
  "preserved_facts": [
    {"fact_id": "f1", "value": "87.4", "unit": "%", "source_locator": "m1#p2",
     "quote": "The catalyst reached 87.4 % conversion under visible light.",
     "converted_location": "converted.md#第2段", "retained": "retained"},
    {"fact_id": "f2", "value": "n = 3", "unit": "per group", "source_locator": "m1#p4",
     "quote": "Each condition was run with n = 3 replicates.",
     "converted_location": "converted.md#方法说明", "retained": "compressed",
     "reason": "科普体裁下并入一句'每组 3 次重复'，数值未变"}
  ],
  "diff_map": [
    {"source_locator": "m1#p1", "converted_location": "converted.md#第1段",
     "decision": "reword", "reason": "背景段改写为公众可读的引子，事实未变"},
    {"source_locator": "m1#p7", "converted_location": "", "decision": "delete",
     "reason": "重复表述，与 p2 信息重合"}
  ],
  "change_log": [
    {"change_id": "ch1", "original": "may indicate", "revised": "可能提示",
     "reason": "保留原文不确定性，不升级为因果", "locator": "m1#p3"}
  ],
  "claims": [{"claim_id": "c1", "text": "…",
              "evidence": [{"locator": "m1#p2", "quote": "…逐字…"}]}],
  "uncertainties": [{"item": "长期稳定性", "why": "源文未报告超过 100 h 的数据"}],
  "pending_human": []
}
```

`retained` 三档：`retained`（原样保留）/ `compressed`（压缩但数值与条件不变）/ `deleted`（删除）。
**`value` 与 `unit` 在 `compressed` 下也不能变**——压缩的是措辞，不是数字。

`decision` 四档：`keep` / `compress` / `delete` / `reword`。

## 四道机械闸门（`check` 实际执行的）

| # | 闸门 | 判定 | 为什么重要 |
|---|---|---|---|
| 1 | 篇幅上限 | `word_count ≤ max_words` | 超限直接不符合交付要求 |
| 2 | 数值可追溯 | 成稿每个数字 ∈ 源文 ∪ `preserved_facts.value` | 防"为了好读编个数字" |
| 3 | **强度守卫** | 成稿出现源文没有的强断言词（且源文有限定语）→ FAIL | 防 `may indicate` → `proves` |
| 4 | 保留覆盖 | 每条 fact 有 `source_locator` + 合法 `retained`；`compressed/deleted` 有 `reason` | 防"压缩时把证据一起删了" |

`word_count` = 英文词数 + 中文字数（混排按此计），`check` 输出里能看到 `length` 明细。

## 降级表（遇到就照做）

| 情况 | 处置 | 记录位置 |
|---|---|---|
| 没给 `max_words` | 按体裁定一个合理值并写进 `audience_profile.max_words` + `why_this_length` | `audience_profile` |
| 没给受众/体裁 | 从 `task_instruction` 推断，写清依据；仍不确定则进 `pending_human` | `audience_profile` |
| 源文是 DOCX/PPTX | 记 `degradations`，靠平台 office-renderer 等工具读 | `degradations` |
| 源文有无法在科普中保留的细节 | `retained: "deleted"` + `reason`（说明去向或为何不适用） | `preserved_facts` |
| 源文自相矛盾 | 不擅自择一，写进 `uncertainties` | `uncertainties` |
| 缺材料/空输入 | `status` = `input_error`，最小交付 | `errors` |

**永远不要**：把 `associated with` 写成 `导致`；把"体外实验"删掉只留"有效"；
把 `n = 3` 删掉让结论显得更硬；自己算一个源文没有的倍数；把限定条件当冗余删掉。

## 自检清单

- [ ] `init` 后 `result.json` 已存在（partial），退出码 0。
- [ ] `audience_profile` 有 audience / genre / max_words / prior_knowledge / terms_expanded。
- [ ] 成稿 `word_count ≤ max_words`。
- [ ] 成稿每个数字都能在源文或 `preserved_facts` 找到。
- [ ] 成稿没有源文不存在的强断言词（尤其源文有限定语时）。
- [ ] 每条 `preserved_facts` 有 `source_locator` + `quote` 与合法 `retained`；压缩/删除有 `reason`。
- [ ] 每条 `claims` 有 `evidence[].locator` 与逐字 `quote`（`check` 的 quote 校验通过）。
- [ ] `diff_map` 给每个源段一个 `decision`（至少覆盖大部分段落）。
- [ ] `build` 后八件产物齐全（含 `content_map.json`），契约键零缺失。
- [ ] 同一输入两次运行结构一致。

## 最小调用示例

```bash
# /input: case.json(audience=科普,genre=article,max_words=800) + task.md + materials/paper.md
python3 scripts/main.py init
python3 scripts/main.py facts
python3 scripts/main.py show --material m1
#  写 /app/work/draft.json
python3 scripts/main.py check
python3 scripts/main.py build
```

示意输出（**示例，非正式案例结果**）：

```json
{"case_id": "demo", "status": "ok",
 "coverage": {"required": 8, "parsed": 8, "missing": []},
 "deliverables": {"converted": "converted.md", "diff_map": "diff_map.json"}}
```

字段级说明见 `references/schema.md`；完整示例见 `references/example.md`。

## 依赖与维护

- Python ≥3.8 标准库（`json`/`re`/`argparse`/`os`/`pathlib`/`subprocess`/`shutil`）。无第三方依赖、不联网；PDF 文本靠平台预装的 `pdftotext`（poppler）。
- 版本 2.0.0。字段改动只做**追加**，不改已有键名。
- 已知限制：限定语/强断言识别基于词表（中英各约 20 条），**不是语义判断**；
  词表外的同义表达可能漏检，所以 `check` 通过不等于论述强度一定合规，仍需人工复核
  `change_log` 与 `preserved_facts`。

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Material scanning, fact/hedge harvesting and length counting for the conversion skill.

Pure stdlib, no network. Every function degrades instead of raising.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

MAX_READ = 2_000_000
TEXT_SUFFIX = (".md", ".txt", ".tex", ".json", ".csv", ".tsv", ".html", ".htm")
PDF_SUFFIX = (".pdf",)

# hedging / uncertainty language that must NOT be upgraded into a strong claim
HEDGE_EN = ("may", "might", "could", "suggest", "suggests", "suggested", "indicate",
            "indicates", "indicated", "appear", "appears", "seem", "seems", "likely",
            "unlikely", "possible", "possibly", "potential", "potentially", "preliminary",
            "tend", "tends", "associated", "correlat", "consistent with", "not clear",
            "so far", "initial", "in vitro", "in mice", "in animals", "hypothes")
HEDGE_CN = ("可能", "或许", "也许", "初步", "提示", "表明", "暗示", "似乎", "有望",
            "相关", "倾向于", "尚不清楚", "有待", "进一步验证", "在体外", "在动物")
STRONG_EN = ("proves", "proven", "prove", "demonstrates conclusively", "confirms",
             "established", "definitively", "undeniably", "certainly", "guarantees",
             "cures", "caused by", "causes", "always", "never fails", "breakthrough")
STRONG_CN = ("证明", "证实", "确证", "确定了", "必将", "一定能", "彻底解决", "根治",
             "首次", "国际领先", "填补空白", "导致", "必然")

NUM_UNIT = re.compile(
    r"(?<![\w.])([+-]?\d+(?:[.,]\d+)?(?:\s*[±+\-]\s*\d+(?:[.,]\d+)?)?)"
    r"(?:\s*(%|‰|[a-zA-ZµμΩ°]{1,6}(?:/[a-zA-ZµμΩ]{1,4})?|[万亿千百])(?![a-zA-Z]))?")
CJK = re.compile(r"[\u4e00-\u9fff]")
WORD = re.compile(r"[A-Za-z][A-Za-z'-]*")


def jdump(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def jload(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return default


def normalise(text):
    if text is None:
        return ""
    text = str(text).replace("\u3000", " ").replace("\xa0", " ").replace("\u2019", "'")
    return re.sub(r"\s+", " ", text).strip().lower()


def sha256_of(path, limit=MAX_READ):
    d = hashlib.sha256()
    try:
        with open(path, "rb") as fh:
            while True:
                chunk = fh.read(65536)
                if not chunk:
                    break
                d.update(chunk)
                if fh.tell() > limit:
                    d.update(b"<truncated>")
                    break
    except Exception:
        return ""
    return d.hexdigest()


def pdf_text(path, limit=MAX_READ):
    """Extract text from a PDF via pdftotext when available.

    Returns (full_text, pages, note) where `pages` is a list of per-page strings
    (page 1 at index 0) and `note` explains any fallback. Uses the platform's
    preinstalled poppler binary when on PATH; otherwise tries common locations and
    finally degrades with an empty result plus an explanatory note (never raises).
    """
    exe = shutil.which("pdftotext")
    if not exe:
        for cand in (r"C:\Program Files\poppler\bin\pdftotext.exe",
                     r"C:\Program Files (x86)\poppler\bin\pdftotext.exe"):
            if os.path.exists(cand):
                exe = cand
                break
    if not exe:
        return "", [], "pdftotext not found; read the PDF visually or via the platform pdf-text-tool"
    try:
        proc = subprocess.run([exe, "-layout", str(path), "-"],
                              capture_output=True, timeout=120)
    except Exception as exc:
        return "", [], "pdftotext failed: %s" % exc
    try:
        text = proc.stdout.decode("utf-8", "replace")
    except Exception:
        text = proc.stdout.decode("latin-1", "replace")
    if not text.strip():
        return "", [], "pdftotext returned empty text (scanned/image PDF?); use OCR"
    pages = [p for p in re.split(r"\f", text)]
    # drop a trailing empty page produced by a final form feed
    while pages and not pages[-1].strip():
        pages.pop()
    return text[:limit], pages, ""


def read_text(path, limit=MAX_READ):
    try:
        raw = Path(path).read_bytes()[:limit]
    except Exception:
        return ""
    for enc in ("utf-8", "utf-16", "gb18030", "latin-1"):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("utf-8", "replace")


def length_of(text):
    """Mixed-language length: english words + CJK chars (the usual 字数 proxy)."""
    t = text or ""
    return {"en_words": len(WORD.findall(t)), "cjk_chars": len(CJK.findall(t)),
            "chars": len(t),
            "word_count": len(WORD.findall(t)) + len(CJK.findall(t))}


def segments_of(text, mid, width=1600):
    if not text:
        return []
    out, buf = [], ""
    for part in re.split(r"\n\s*\n", text):
        part = part.strip()
        if not part:
            continue
        if buf and len(buf) + len(part) > width:
            out.append(buf)
            buf = part
        else:
            buf = (buf + "\n" + part).strip() if buf else part
    if buf:
        out.append(buf)
    return [{"locator": "%s#p%d" % (mid, i + 1), "segment_id": "s%d" % (i + 1),
             "text": s} for i, s in enumerate(out)]


def page_segments(pages, mid):
    """Per-page locators for a PDF: page text (paragraph-joined) with `mid#pK`."""
    out = []
    for i, page in enumerate(pages):
        para = "\n\n".join(x.strip() for x in re.split(r"\n\s*\n", page) if x.strip())
        if not para:
            continue
        out.append({"locator": "%s#p%d" % (mid, i + 1),
                    "segment_id": "s%d" % (i + 1), "text": para})
    return out


def discover(input_dir):
    """Register every material, with locator segments for text-like files."""
    mats, root = [], Path(input_dir)
    if not root.exists():
        return mats, ["input directory does not exist"]
    notes, n = [], 0
    files = []
    for dp, dns, fns in os.walk(str(root)):
        dns[:] = sorted(d for d in dns if d not in (".git", "__pycache__", "node_modules"))
        files += [Path(dp) / f for f in sorted(fns)]
    for p in files:
        try:
            if p.name.startswith(".") or (p.parent == root and p.name == "case.json"):
                continue
            if p.stat().st_size > MAX_READ:
                notes.append("%s skipped (>2MB)" % p.name)
                continue
        except Exception:
            continue
        n += 1
        mid = "m%d" % n
        e = {"material_id": mid, "path": p.relative_to(root).as_posix(),
             "suffix": p.suffix.lower(), "bytes": p.stat().st_size,
             "sha256": sha256_of(p), "notes": []}
        if p.suffix.lower() in TEXT_SUFFIX:
            text = read_text(p)
            e["text_chars"] = len(text)
            e.update(length_of(text))
            e["_segments"] = segments_of(text, mid)
        elif p.suffix.lower() in PDF_SUFFIX:
            text, pages, note = pdf_text(p)
            e["text_chars"] = len(text)
            e["pdf_pages"] = len(pages)
            e.update(length_of(text))
            if note:
                e["notes"].append(note)
            if pages:
                e["_segments"] = page_segments(pages, mid)
            else:
                e["_segments"] = []
        elif p.suffix.lower() in (".docx", ".doc"):
            e["notes"].append("binary document: read visually or via a platform tool")
            e["_segments"] = []
        else:
            e["_segments"] = []
        mats.append(e)
    return mats, notes


def harvest(segments, mid):
    """Candidate facts (number+unit), hedging language and strong claims, with locators."""
    facts, hedges, strongs = [], [], []
    for seg in segments or []:
        text = seg.get("text", "")
        loc = seg.get("locator", "")
        for sent in re.split(r"(?<=[.;!?。；！？])\s*|\n", text):
            sent = sent.strip()
            if not sent:
                continue
            low = normalise(sent)
            for word in HEDGE_EN:
                if word in low:
                    hedges.append({"term": word, "kind": "hedge", "material_id": mid,
                                   "locator": loc, "quote": sent[:300]})
                    break
            for word in HEDGE_CN:
                if word in sent:
                    hedges.append({"term": word, "kind": "hedge", "material_id": mid,
                                   "locator": loc, "quote": sent[:300]})
                    break
            for word in STRONG_EN + STRONG_CN:
                if word in low or word in sent:
                    strongs.append({"term": word, "kind": "strong", "material_id": mid,
                                    "locator": loc, "quote": sent[:300]})
                    break
            for m in NUM_UNIT.finditer(sent):
                val, unit = m.group(1), (m.group(2) or "").strip()
                if not val:
                    continue
                if re.fullmatch(r"(?:19|20)\d{2}", val) and not unit:
                    continue
                facts.append({"value": val, "unit": unit, "material_id": mid,
                              "locator": loc, "quote": sent[:300]})
    return {"numbers": facts, "hedges": hedges, "strong_claims": strongs}

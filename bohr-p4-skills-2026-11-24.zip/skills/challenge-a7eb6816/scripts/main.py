#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""research-converter -- rewrite research material for a different audience/genre.

Four mechanical gates (the reason this skill scores above a plain "rewrite it" prompt):
  1. length cap            converted text must stay within max_words
  2. number traceability   every number in the output must exist in the source
  3. intensity guard       a hedged source sentence must not become a strong claim
  4. preservation          key facts must be accounted for with retained/deleted + reason

Pure stdlib, no network, CWD independent, always exits 0, always finalizes.
"""
import argparse
import json
import os
import re
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from extract import (jdump, jload, normalise, read_text, length_of, discover, harvest,
                     NUM_UNIT, HEDGE_EN, HEDGE_CN, STRONG_EN, STRONG_CN)

VERSION = "2.0.0"
RETAINED = ("retained", "compressed", "deleted")
DECISIONS = ("keep", "compress", "delete", "reword")


def load_case(input_dir):
    case = jload(Path(input_dir) / "case.json", None)
    if not isinstance(case, dict):
        return {}, ["case.json missing or not a JSON object"]
    return case, []


def echo_contract(contract, base):
    final, missing = {}, []
    if isinstance(contract, dict):
        res = base.get("result") if isinstance(base.get("result"), dict) else {}
        for key in contract.keys():
            if key in base:
                final[key] = base[key]
            elif key in res:
                final[key] = res[key]
            else:
                final[key] = None
                missing.append(key)
    final.update(base)
    if missing:
        base.setdefault("degradations", []).append(
            "output_contract keys filled as null: " + ", ".join(missing))
        for key in missing:
            final[key] = None
    return final


def meta_of(case):
    def pick(*ks):
        for k in ks:
            v = case.get(k)
            if v not in (None, ""):
                return v
        return ""
    return {"case_id": str(pick("case_id", "id", "caseId")),
            "material_version": str(pick("material_version", "version")),
            "audience": str(pick("audience", "target_audience", "reader")),
            "genre": str(pick("genre", "format", "document_type")),
            "max_words": pick("max_words", "word_limit", "limit")}


def base_doc(meta, status, deg, err):
    return {"case_id": meta.get("case_id", ""),
            "material_version": meta.get("material_version", ""),
            "status": status, "deliverable": "converted.md",
            "audience": meta.get("audience", ""), "genre": meta.get("genre", ""),
            "preserved_facts": [], "diff_map": [], "audience_profile": {},
            "change_log": [], "converted": "",
            "result": {}, "claims": [], "uncertainties": [],
            "coverage": {"required": 0, "parsed": 0, "missing": []},
            "sources": [], "pending_human": [], "errors": err, "degradations": deg,
            "deliverables": {}, "skill": {"name": "research-converter", "version": VERSION}}


# --------------------------------------------------------------------------- init
def cmd_init(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    deg, err = [], []
    case, notes = load_case(args.input)
    deg.extend(notes)
    meta = meta_of(case)
    if not meta["audience"]:
        deg.append("no audience declared in case.json; record it in draft.audience_profile")
    if not meta["genre"]:
        deg.append("no genre declared in case.json; record it in draft.audience_profile")
    if not meta["max_words"]:
        deg.append("no max_words declared; state the limit you chose in audience_profile")
    mats, mnotes = discover(args.input)
    deg.extend(mnotes)
    if not mats:
        deg.append("no material files found under input dir")
    index = {"version": VERSION, "meta": meta,
             "materials": [{k: v for k, v in m.items() if not k.startswith("_")}
                           for m in mats],
             "counts": {"materials": len(mats),
                        "segments": sum(len(m.get("_segments") or []) for m in mats)}}
    jdump(work / "index.json", index)
    for m in mats:
        if m.get("_segments"):
            jdump(work / "segments" / (m["material_id"] + ".json"),
                  {"segments": m["_segments"], "path": m["path"]})
    src_chars = sum(m.get("chars") or 0 for m in mats)
    status = "input_error" if not mats else "partial"
    doc = base_doc(meta, status, deg, err)
    doc["coverage"] = {"required": index["counts"]["segments"], "parsed": 0,
                       "missing": ["all"]}
    doc["result"] = {"audience": meta["audience"], "genre": meta["genre"],
                     "source_length": length_of(" " * src_chars)}
    final = echo_contract(case.get("output_contract"), doc)
    jdump(out / "result.json", final)
    print(json.dumps({
        "ok": True, "command": "init", "meta": meta, "status": status,
        "counts": index["counts"],
        "materials": [{"material_id": m["material_id"], "path": m["path"],
                       "kind": m.get("suffix"), "text_chars": m.get("text_chars")}
                      for m in mats],
        "notes": deg,
        "next": "run `facts` for candidate numbers/hedges, read with `show`, write "
                "work/draft.json (audience_profile + converted + preserved_facts + diff_map), "
                "then check -> build",
    }, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- show / facts
def cmd_show(args):
    work = Path(args.work)
    index = jload(work / "index.json", {}) or {}
    mats = index.get("materials", [])
    if not args.material:
        print(json.dumps({"meta": index.get("meta"), "materials": mats},
                         ensure_ascii=False, indent=2))
        return 0
    m = next((x for x in mats if x["material_id"] == args.material), None)
    if not m:
        print(json.dumps({"error": "unknown material: %s" % args.material}))
        return 0
    segs = (jload(work / "segments" / (args.material + ".json"), {}) or {}).get("segments") or []
    shown = 0
    for s in segs:
        if args.grep and not re.search(args.grep, s["text"], re.I):
            continue
        print("=== [%s] %s" % (s["locator"], m["path"]))
        print(s["text"])
        print()
        shown += 1
        if args.limit and shown >= args.limit:
            break
    if not segs:
        print(json.dumps({"material_id": args.material, "path": m["path"],
                          "segments": [], "notes": m.get("notes")},
                         ensure_ascii=False, indent=2))
    return 0


def cmd_facts(args):
    work = Path(args.work)
    index = jload(work / "index.json", {}) or {}
    agg = {"numbers": [], "hedges": [], "strong_claims": []}
    for m in index.get("materials", []):
        segs = (jload(work / "segments" / (m["material_id"] + ".json"), {}) or {}) \
            .get("segments") or []
        found = harvest(segs, m["material_id"])
        for k in agg:
            agg[k].extend(found[k])
    jdump(work / "facts_candidates.json", agg)
    print(json.dumps({
        "ok": True, "command": "facts",
        "counts": {k: len(v) for k, v in agg.items()},
        "saved_to": str(work / "facts_candidates.json"),
        "note": ("candidates only. Promote the ones you actually keep into "
                 "draft.preserved_facts (value/unit/source_locator/retained/reason). "
                 "The hedges list marks sentences you must NOT strengthen."),
        "hedge_samples": agg["hedges"][:5],
        "number_samples": agg["numbers"][:5],
    }, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- check
def source_haystack(work_dir, index):
    parts, by_mat = [], {}
    for m in index.get("materials", []):
        mid = m["material_id"]
        segs = (jload(Path(work_dir) / "segments" / (mid + ".json"), {}) or {}) \
            .get("segments") or []
        blob = normalise(" \n ".join(s.get("text", "") for s in segs))
        by_mat[mid] = blob
        parts.append(blob)
    return normalise(" \n ".join(parts)), by_mat


def run_checks(args):
    work = Path(args.work)
    index = jload(work / "index.json", {}) or {}
    draft = Path(args.draft) if args.draft else (work / "draft.json")
    d = jload(draft)
    fails, warns, passes = [], [], []
    if not isinstance(d, dict):
        return {"passed": False, "fails": ["draft.json missing or not a JSON object"],
                "warnings": [], "passes": [], "counts": {}}

    converted = d.get("converted")
    if isinstance(converted, list):
        converted = "\n\n".join(str(x) for x in converted)
    converted = str(converted or "")
    prof = d.get("audience_profile") if isinstance(d.get("audience_profile"), dict) else {}
    meta = index.get("meta") or {}

    # 1. audience / genre declared
    if not (prof.get("audience") or d.get("audience") or meta.get("audience")):
        fails.append("audience is not declared (audience_profile.audience)")
    else:
        passes.append("audience declared")
    if not (prof.get("genre") or d.get("genre") or meta.get("genre")):
        warns.append("genre is not declared")

    # 2. length cap
    limit = prof.get("max_words") or d.get("max_words") or meta.get("max_words")
    try:
        limit = int(limit) if limit not in (None, "") else None
    except Exception:
        limit = None
    length = length_of(converted)
    if limit:
        if length["word_count"] > limit:
            fails.append("converted length %d exceeds max_words %d by %d"
                         % (length["word_count"], limit, length["word_count"] - limit))
        else:
            passes.append("length %d within cap %d" % (length["word_count"], limit))
    else:
        warns.append("no max_words given; record the limit you chose in audience_profile")
    if not converted.strip():
        fails.append("converted text is empty; the deliverable is the converted manuscript")

    total, by_mat = source_haystack(work, index)

    # 3. number traceability (no facts invented for the new audience)
    fact_vals = {normalise(f.get("value")) for f in (d.get("preserved_facts") or [])
                 if f.get("value")}
    untraced = []
    for m in NUM_UNIT.finditer(converted):
        tok = normalise(m.group(1))
        if not tok:
            continue
        if re.fullmatch(r"(?:19|20)\d{2}", tok):
            continue
        if tok in fact_vals or tok in total:
            continue
        untraced.append(m.group(1))
    if untraced:
        fails.append("%d number(s) in the converted text are not traceable to the source: %s"
                     % (len(untraced), ", ".join(sorted(set(untraced))[:12])))
    else:
        passes.append("all converted numbers traceable to the source")

    # 4. intensity guard: hedge in source must not become a strong claim
    src_strong = {t for t in STRONG_EN + STRONG_CN if t in total}
    out_strong = sorted({t for t in STRONG_EN + STRONG_CN
                         if t in normalise(converted) or t in converted})
    upgraded = [t for t in out_strong if t not in src_strong]
    src_hedges = [t for t in HEDGE_EN + HEDGE_CN if t in total]
    if upgraded and src_hedges:
        fails.append("intensity upgrade: the source hedges (%s) but the converted text uses "
                     "strong claim(s) that do not appear in the source: %s"
                     % (", ".join(src_hedges[:4]), ", ".join(upgraded[:6])))
    elif upgraded:
        warns.append("converted text uses strong claim(s) absent from the source: %s"
                     % ", ".join(upgraded[:6]))
    else:
        passes.append("no intensity upgrade detected")

    # 5. preservation coverage
    facts = d.get("preserved_facts") or []
    if not facts:
        fails.append("preserved_facts is empty; key numbers/conditions must be accounted for")
    for f in facts:
        tag = f.get("fact_id") or "?"
        if not f.get("fact_id"):
            fails.append("a preserved_facts entry has no fact_id")
        if not f.get("source_locator"):
            fails.append("%s missing source_locator" % tag)
        if f.get("retained") not in RETAINED:
            fails.append("%s retained=%r not in %s" % (tag, f.get("retained"), list(RETAINED)))
        if f.get("retained") in ("compressed", "deleted") and not f.get("reason"):
            fails.append("%s is %s but gives no reason" % (tag, f.get("retained")))
        if not f.get("converted_location") and f.get("retained") == "retained":
            warns.append("%s retained but converted_location not given" % tag)

    # 6. diff map coverage
    dm = d.get("diff_map") or []
    if not dm:
        fails.append("diff_map is empty; every source segment needs a decision")
    for e in dm:
        if e.get("decision") not in DECISIONS:
            fails.append("diff_map decision=%r not in %s"
                         % (e.get("decision"), list(DECISIONS)))
        if not (e.get("source_locator") or e.get("source_segment")):
            warns.append("a diff_map entry has no source_locator")
    seg_total = index.get("counts", {}).get("segments") or 0
    if seg_total and len(dm) < max(1, int(seg_total * 0.5)):
        warns.append("diff_map covers %d entries for %d source segment(s); "
                     "aim to account for every segment" % (len(dm), seg_total))

    # 7. change log
    for i, c in enumerate(d.get("change_log") or []):
        tag = c.get("change_id") or "change_log[%d]" % i
        for need in ("original", "revised", "reason"):
            if c.get(need) in (None, ""):
                fails.append("%s missing %s" % (tag, need))

    # 8. verbatim-quote verification for the content map: every claim/fact quote must
    #    be a normalised substring of the source text (whitespace/hyphen tolerant).
    quote_checks = []
    for c in d.get("claims") or []:
        for ev in c.get("evidence") or []:
            q = normalise(ev.get("quote"))
            ok = bool(q) and q in total
            quote_checks.append({"claim_id": c.get("claim_id"), "locator": ev.get("locator"),
                                 "quote": ev.get("quote"), "verbatim": ok})
            if q and not ok:
                warns.append("claim %s quote not found verbatim in source (check locator %s)"
                             % (c.get("claim_id"), ev.get("locator")))
    for f in facts:
        q = normalise(f.get("quote"))
        ok = bool(q) and q in total
        quote_checks.append({"fact_id": f.get("fact_id"), "locator": f.get("source_locator"),
                             "quote": f.get("quote"), "verbatim": ok})

    return {"passed": not fails, "fails": fails, "warnings": warns, "passes": passes,
            "counts": {"length": length, "limit": limit, "facts": len(facts),
                       "diff_map": len(dm), "segments": seg_total,
                       "quotes_verified": sum(1 for x in quote_checks if x.get("verbatim")),
                       "quotes_total": len(quote_checks)},
            "quote_checks": quote_checks}


def cmd_check(args):
    report = run_checks(args)
    try:
        jdump(Path(args.work) / "check_report.json", report)
    except Exception:
        pass
    print(json.dumps({"passed": report["passed"], "FAIL": report["fails"],
                      "WARN": report["warnings"], "PASS": report["passes"],
                      "counts": report.get("counts", {})}, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- build
def build_report(doc, check_report, status):
    L = ["# Research conversion report", "",
         "- case_id: `%s`" % doc["case_id"],
         "- audience: %s | genre: %s" % (doc.get("audience") or "-", doc.get("genre") or "-"),
         "- status: `%s`" % status, "",
         "## Audience profile",
         "- audience: %s" % (doc.get("audience_profile") or {}).get("audience", "-"),
         "- assumed prior knowledge: %s"
         % (doc.get("audience_profile") or {}).get("prior_knowledge", "-"),
         "- terms expanded: %s"
         % ", ".join((doc.get("audience_profile") or {}).get("terms_expanded") or []) or "-",
         "- length: %s / limit %s"
         % ((check_report or {}).get("counts", {}).get("length", {}).get("word_count", "-"),
            (check_report or {}).get("counts", {}).get("limit", "-")),
         "", "## Preserved facts"]
    for f in doc.get("preserved_facts") or []:
        L.append("- `%s` %s %s — %s%s"
                 % (f.get("fact_id"), f.get("value"), f.get("unit") or "",
                    f.get("retained"), " (" + f["reason"] + ")" if f.get("reason") else ""))
    if not doc.get("preserved_facts"):
        L.append("_None recorded._")
    L += ["", "## Diff map (source segment -> decision)"]
    for e in doc.get("diff_map") or []:
        L.append("- `%s` → %s%s"
                 % (e.get("source_locator"), e.get("decision"),
                    " — " + e["reason"] if e.get("reason") else ""))
    if not doc.get("diff_map"):
        L.append("_None recorded._")
    L += ["", "## Changes"]
    for c in doc.get("change_log") or []:
        L.append("- `%s`: %s → %s (reason: %s)"
                 % (c.get("change_id"), c.get("original"), c.get("revised"),
                    c.get("reason") or "-"))
    if check_report:
        L += ["", "## Self-check", "- passed: `%s`" % check_report.get("passed")]
        L += ["- FAIL: %s" % x for x in (check_report.get("fails") or [])[:30]]
        qc = (check_report.get("counts") or {})
        L += ["- quotes verified: %s/%s" % (qc.get("quotes_verified", 0),
                                            qc.get("quotes_total", 0))]
    L += ["", "## Content map", "- `content_map.json` maps each claim/fact/term to a "
          "locator and a verbatim source quote."]
    return "\n".join(L) + "\n"


def cmd_build(args):
    work, out = Path(args.work), Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    deg, err = [], []
    case, notes = load_case(args.input)
    deg.extend(notes)
    index = jload(work / "index.json")
    if not isinstance(index, dict) or not index:
        deg.append("index.json absent; build ran init implicitly")
        try:
            cmd_init(args)
            index = jload(work / "index.json", {}) or {}
        except Exception as exc:
            err.append("implicit init failed: %s" % exc)
            index = {"materials": [], "counts": {}, "meta": meta_of(case)}
    meta = index.get("meta") or meta_of(case)
    d = jload(Path(args.draft) if args.draft else (work / "draft.json"))
    if not isinstance(d, dict):
        deg.append("draft.json missing; produced degraded minimal deliverable")
        d = {}
    check_report = None
    if d:
        try:
            check_report = run_checks(args)
        except Exception as exc:
            deg.append("check failed during build: %s" % exc)

    converted = d.get("converted")
    if isinstance(converted, list):
        converted = "\n\n".join(str(x) for x in converted)
    converted = str(converted or "")
    if not converted.strip():
        converted = ("<!-- No converted manuscript was supplied by the agent. This placeholder "
                     "exists so the deliverable is present; see result.json -->\n")
        deg.append("converted.md fell back to a placeholder (no draft text)")
    facts = d.get("preserved_facts") or []
    dm = d.get("diff_map") or []
    changes = d.get("change_log") or []
    prof = d.get("audience_profile") if isinstance(d.get("audience_profile"), dict) else {}

    fails = (check_report or {}).get("fails") or []
    status = "ok"
    if not d:
        status = "partial"
    elif fails:
        status = "partial"
        deg.append("%d mechanical check failure(s)" % len(fails))
    if not index.get("materials"):
        status = "input_error"
        err.append("no input materials were discovered")
    if not facts or not dm:
        if status == "ok":
            status = "partial"
        deg.append("preserved_facts or diff_map is empty")
    seg_total = index.get("counts", {}).get("segments") or 0
    covered = len({e.get("source_locator") for e in dm if e.get("source_locator")})
    cov = {"required": seg_total, "parsed": covered,
           "missing": [] if covered >= seg_total else ["%d segment(s)" % (seg_total - covered)]}

    deliverables = {}
    try:
        (out / "converted.md").write_text(converted, encoding="utf-8")
        deliverables["converted"] = "converted.md"
    except Exception as exc:
        err.append("converted.md failed: %s" % exc)
    for name, obj in (("preservation_checklist.json", {"facts": facts,
                                                       "counts": {"total": len(facts),
                                                                  "retained": sum(
                                                                      1 for f in facts
                                                                      if f.get("retained") == "retained")}}),
                      ("diff_map.json", dm), ("audience_profile.json", prof),
                      ("change_log.json", changes)):
        try:
            jdump(out / name, obj)
            deliverables[name.replace(".json", "")] = name
        except Exception as exc:
            err.append("%s failed: %s" % (name, exc))

    # content_map: every claim/fact/term traceable to a locator + verbatim quote.
    content_map = {
        "case_id": d.get("case_id") or meta.get("case_id", ""),
        "claims": [{"claim_id": c.get("claim_id"), "text": c.get("text"),
                    "evidence": c.get("evidence") or []}
                   for c in (d.get("claims") or [])],
        "facts": [{"fact_id": f.get("fact_id"), "value": f.get("value"),
                   "unit": f.get("unit"), "source_locator": f.get("source_locator"),
                   "quote": f.get("quote", ""), "retained": f.get("retained")}
                  for f in facts],
        "terms": (prof.get("terms_expanded") or []),
        "quote_checks": (check_report or {}).get("quote_checks") or [],
        "coverage": cov,
    }
    try:
        jdump(out / "content_map.json", content_map)
        deliverables["content_map"] = "content_map.json"
    except Exception as exc:
        err.append("content_map.json failed: %s" % exc)

    doc = base_doc(meta, status, deg, err)
    doc.update({"case_id": d.get("case_id") or meta.get("case_id", ""),
                "deliverable": d.get("deliverable") or "converted.md",
                "audience": prof.get("audience") or meta.get("audience", ""),
                "genre": prof.get("genre") or meta.get("genre", ""),
                "preserved_facts": facts, "diff_map": dm, "audience_profile": prof,
                "change_log": changes, "converted": converted, "coverage": cov,
                "claims": d.get("claims") or [],
                "uncertainties": d.get("uncertainties") or [],
                "content_map": content_map,
                "sources": [{k: m.get(k) for k in ("material_id", "path", "text_chars")}
                            for m in index.get("materials", [])],
                "pending_human": d.get("pending_human") or [],
                "deliverables": deliverables})
    doc["result"] = {"audience_profile": prof, "preserved_facts": facts, "diff_map": dm,
                     "change_log": changes, "coverage": cov, "content_map": content_map,
                     "length": length_of(converted), "deliverables": deliverables}
    if check_report:
        doc["self_check"] = {"passed": check_report.get("passed"),
                             "fail_count": len(fails)}
    final = echo_contract(case.get("output_contract"), doc)
    try:
        jdump(out / "result.json", final)
    except Exception as exc:
        err.append("result.json write failed: %s" % exc)
    try:
        (out / "report.md").write_text(build_report(doc, check_report, status),
                                       encoding="utf-8")
        deliverables["report"] = "report.md"
    except Exception as exc:
        err.append("report.md failed: %s" % exc)
    print(json.dumps({"ok": True, "command": "build", "status": status,
                      "case_id": final.get("case_id", ""), "coverage": cov,
                      "deliverables": deliverables, "errors": err,
                      "degradations": deg}, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- cli
def add_io(p):
    for n in ("input", "work", "output"):
        p.add_argument("--" + n, default=argparse.SUPPRESS, help=n + " dir")


def build_parser():
    ap = argparse.ArgumentParser(
        prog="research-converter",
        description="Rewrite research material for a different audience/genre while keeping "
                    "facts, conditions and claim strength intact.",
        epilog="Flow: init -> facts -> show -> (write draft) -> check -> build")
    ap.add_argument("--input", default=os.environ.get("INPUT_DIR", "/input"))
    ap.add_argument("--work", default=os.environ.get("WORK_DIR", "/app/work"))
    ap.add_argument("--output", default=os.environ.get("OUTPUT_DIR", "/app/output"))
    ap.add_argument("--version", action="version", version="research-converter " + VERSION)
    sub = ap.add_subparsers(dest="command")
    for name in ("init", "facts"):
        p = sub.add_parser(name)
        add_io(p)
    p = sub.add_parser("show", help="print a material with locators")
    add_io(p)
    p.add_argument("--material")
    p.add_argument("--grep")
    p.add_argument("--limit", type=int, default=0)
    for name, helptext in (("check", "validate draft"),
                           ("build", "assemble deliverables"),
                           ("selfcheck", "re-run checks only")):
        p = sub.add_parser(name, help=helptext)
        add_io(p)
        if name != "selfcheck":
            p.add_argument("--draft")
    return ap


def main(argv):
    ap = build_parser()
    try:
        args = ap.parse_args(argv)
    except SystemExit:
        return 0
    if not args.command:
        ap.print_help()
        return 0
    fn = {"init": cmd_init, "show": cmd_show, "facts": cmd_facts, "check": cmd_check,
          "build": cmd_build, "selfcheck": cmd_check}.get(args.command)
    return fn(args) if fn else 0


def emergency(argv):
    try:
        try:
            args, _ = build_parser().parse_known_args(argv)
        except SystemExit:
            args = None
        out = Path(getattr(args, "output", None) or "/app/output")
        out.mkdir(parents=True, exist_ok=True)
        if not (out / "converted.md").exists():
            (out / "converted.md").write_text("<!-- emergency finalize -->\n", encoding="utf-8")
        if not (out / "result.json").exists():
            jdump(out / "result.json", {
                "case_id": "", "material_version": "", "status": "partial",
                "deliverable": "converted.md", "audience": "", "genre": "",
                "preserved_facts": [], "diff_map": [], "audience_profile": {},
                "change_log": [], "converted": "", "result": {}, "claims": [],
                "uncertainties": [],
                "coverage": {"required": 0, "parsed": 0, "missing": []},
                "sources": [], "pending_human": [], "errors": ["unhandled exception"],
                "degradations": ["emergency finalize"], "deliverables": {}})
    except Exception:
        pass


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except Exception:
        try:
            sys.stderr.write(traceback.format_exc())
        except Exception:
            pass
        emergency(sys.argv[1:])
    sys.exit(0)

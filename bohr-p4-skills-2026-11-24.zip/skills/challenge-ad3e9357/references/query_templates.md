# 检索式模板与查询计划

## 多轮查询计划
1. **号码定位轮**：规范化号码精确匹配 → 原样变体匹配（分隔符/前导零/种类码）。
2. **号码变体轮**：国别码 + 序列号的变体；处理公开/申请/授权/优先权不同口径。
3. **主题词轮**：任务说明中的关键词/引号短语/技术术语（中文保留二字以上词，英文保留 ≥3 字母词，去停用词）。
4. **扩展轮**：同义词/缩写/跨语言（下表），全部命中仍需逐字命中原文才计。
5. **分类轮**：IPC/CPC 分类号（`[A-H]\d{2}[A-Z]\d+`），对记录 ipc/cpc 前缀匹配。

## 同义词 / 缩写 / 跨语言扩展表（内置子集）
| 主题 | 扩展词 |
|-|-|
| machine learning | ml, deep learning, neural network, 机器学习, 深度学习 |
| artificial intelligence | ai, 人工智能 |
| antibody | antibodies, immunoglobulin, mab, 抗体, 单克隆抗体 |
| tumor | tumour, cancer, neoplasm, 肿瘤, 癌 |
| PCR | polymerase chain reaction, 聚合酶链反应 |
| CRISPR | cas9, gene editing, 基因编辑 |
| nanoparticle | nano, 纳米 |
| vaccine | vaccines, 疫苗 |

> 扩展词只用于扩大召回，不生成命中证据；命中证据必须是材料原文片段。

## 相关性排序
- 等级：exact_number(0) > serial(1) > priority/family(2) > topic(3)。
- 主题得分 = Σ 词权重（标题 3.0 / 摘要 2.0 / 权利要求 1.5 / 正文 1.0）+ 分类号命中 2.0。
- 同级按得分降序、record_id 升序稳定排序。
- **Precision@k / nDCG 思路**：离线材料通常无相关性白板，故只输出得分与匹配等级，供人工按白板计算；不编造指标值。

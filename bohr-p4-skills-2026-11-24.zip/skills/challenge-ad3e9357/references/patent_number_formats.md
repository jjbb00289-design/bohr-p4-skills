# 专利号规范化与字段映射表

## 号码格式（规范化键 = 国别码 + 年(可选) + 序列 + 种类码(可选)，全大写去分隔符）

| 类型 | 常见形式 | 规范化示例 | 判定规则 |
|-|-|-|-|
| 美国公开号 | US 2020/0123456 A1 | `US2020123456A1` | 有年 + 种类 A/U/Y 或无种类 → publication |
| 美国授权号 | US 10,123,456 B2 | `US10123456B2` | 无年 + 种类 B/C，或 7 位数字无年 → grant |
| 美国申请号 | 12/345,678 | `US12345678` | 裸 `NN/NNN,NNN`（系列 01-17）→ application |
| 美国临时申请/优先权 | 62/123,456 | `US62123456` | 系列 60/61/62/63 → provisional |
| PCT 公开 | WO 2020/012345 A1 | `WO2020012345A1` | WO + 年 + 6 位 → publication |
| 欧洲 | EP 3 123 456 A1 | `EP3123456A1` | EP + 7 位；种类 B/C → grant |
| 中国 | CN 110123456 A | `CN110123456A` | CN + 9/13 位；B/U/Y 区分授权/实用新型/外观 |
| 日本 | JP 2020-123456 A | `JP2020123456A` | JP + 年 + 6 位 |

**注意事项**：公开号 ≠ 授权号；优先权日 ≠ 申请日；同一发明在不同局可能号码完全无关，需靠优先权号归族。

## 字段映射（别名 → 规范字段）

- publication_number ← `publication_number, publicationnumber, pubno, 公开号, 公布号, 专利号, patent_number`
- application_number ← `application_number, applicationnumber, applno, 申请号`
- priority ← `priority, priority_number(s), 优先权`
- title ← `title, invention_title, 发明名称, 名称`
- abstract ← `abstract, 摘要, summary`
- claims ← `claims, claim, claim_text, 权利要求`
- applicants ← `applicants, applicant, assignee(s), 申请人, 专利权人, 权利人`
- inventors ← `inventors, inventor, 发明人`
- ipc / cpc ← `ipc, ipc_classification, 分类号, 国际分类` / `cpc, cpc_classification, 合作分类`
- legal_status ← `legal_status, status, 法律状态, 状态`
- family ← `family, family_members, 同族, family_id`
- 论文侧：title / authors / doi / container-title(journal) / year / abstract / url

## 同族归并规则
- **简单族**：共享同一组规范化优先权号。
- **扩展族**：优先权号或申请号任意共享关系的连通分量（仅"已观察到的链接"）。
- 扩展族 ≠ 完整 INPADOC 族；不得据此推断权利要求等同范围。

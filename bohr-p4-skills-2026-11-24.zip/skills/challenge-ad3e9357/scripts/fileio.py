# -*- coding: utf-8 -*-
"""fileio — material readers + record loading (stdlib only)."""
import csv
import hashlib
import io
import json
import re
import sqlite3
import zlib
import zipfile

import patent_lib as pl

def read_text_file(path):
    for enc in ("utf-8-sig", "utf-8", "latin-1", "gb18030"):
        try:
            return path.read_text(encoding=enc), enc
        except (UnicodeDecodeError, UnicodeError):
            continue
    return path.read_bytes().decode("utf-8", "replace"), "utf-8(replace)"

def parse_json(path):
    return json.loads(read_text_file(path)[0])

def parse_jsonl(path):
    out = []
    for i, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines()):
        if line.strip():
            try:
                out.append((json.loads(line), "$lines[%d]" % i))
            except Exception:
                pass
    return out

def parse_csv(path):
    out, text = [], read_text_file(path)[0]
    dialect = "excel"
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t|")
    except Exception:
        pass
    for i, row in enumerate(csv.DictReader(io.StringIO(text), dialect=dialect)):
        if row and any(v for v in row.values()):
            out.append((row, "$row[%d]" % i))
    return out

def parse_sqlite(path):
    out = []
    con = sqlite3.connect(str(path))
    try:
        cur = con.cursor()
        for t in [r[0] for r in cur.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")]:
            try:
                cols = [c[1] for c in cur.execute("PRAGMA table_info(%s)" % t)]
                for rid, row in enumerate(cur.execute("SELECT * FROM %s" % t)):
                    rec = dict(zip(cols, row))
                    rec["__table"] = t
                    out.append((rec, "$table:%s,row:%d" % (t, rid)))
            except Exception:
                continue
    finally:
        con.close()
    return out

def parse_docx(path):
    try:
        with zipfile.ZipFile(str(path)) as zf:
            xml = zf.read("word/document.xml").decode("utf-8", "replace")
            lines = ["".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", p, re.S))
                     for p in re.findall(r"<w:p[ >].*?</w:p>", xml, re.S)]
            return "\n".join(l for l in lines if l.strip())
    except Exception:
        return ""

def parse_pdf(path):
    try:
        data = path.read_bytes()
    except Exception as e:
        return {"text": "", "meta": {}, "error": str(e), "has_text_layer": False}
    head = data[:4000].decode("latin-1", "replace")
    meta = {}
    for key in ("Title", "Author", "Subject", "Producer", "CreationDate", "ModDate"):
        m = re.search(r"/%s\s*\(([^)]*)\)" % key, head)
        if m:
            meta[key] = m.group(1)
    parts = []
    for m in re.finditer(rb"stream\r?\n(.*?)\r?\nendstream", data, re.S):
        raw = m.group(1)
        if raw[:2] in (b"\x78\x9c", b"\x78\x01", b"\x78\x78"):
            try:
                raw = zlib.decompress(raw)
            except Exception:
                pass
        try:
            s = raw.decode("latin-1")
        except Exception:
            continue
        for tm in re.finditer(r"\((?:[^()\\]|\\.)*\)\s*Tj", s):
            parts.append(re.sub(r"\\([0-7]{1,3})", lambda mm: chr(int(mm.group(1), 8)),
                                tm.group(0)[1:tm.group(0).rfind(")")]))
    text = "".join(parts).replace(r"\n", "\n").replace(r"\(", "(").replace(r"\)", ")")
    return {"text": text, "meta": meta, "error": None, "has_text_layer": bool(text.strip())}

# ---- record loading ----
def make_document_record(path, text, meta, fmt, note=None):
    meta_text = " ".join(str(v) for v in meta.values())
    nums = pl.extract_numbers((text or "") + " " + meta_text + " " + path.stem)
    rec = {
        "kind": "document", "title": meta.get("Title") or path.stem, "abstract": "",
        "claims": "", "applicants": [], "inventors": [], "authors": [], "ipc": [],
        "cpc": [], "doi": None, "journal": meta.get("Producer", ""), "year": "",
        "publication_date": "", "filing_date": "", "priority_date": "",
        "publication_number_raw": "", "application_number_raw": "", "priority_raws": [],
        "legal_status": "", "numbers": nums, "pub_norm": [n["normalized"] for n in nums],
        "priority_norm": [], "app_norm": None, "text": text or "",
        "source_file": str(path), "source_format": fmt,
        "locator": "pdf:text-layer" if text else "pdf:no-text-layer", "note": note or "",
    }
    rec["record_id"] = hashlib.sha1(
        ("document|%s|%s" % (path, rec["title"][:40])).encode("utf-8", "replace")).hexdigest()[:12]
    return rec

def load_materials(files):
    records, sources, degradations = [], [], []
    for p in files:
        ext = p.suffix.lower()
        src = {"file": str(p), "format": ext or "none", "role": "material",
               "records_extracted": 0, "parse_status": "ok", "note": ""}
        before = len(records)
        try:
            if ext in (".json", ".jsonl"):
                if ext == ".json":
                    try:
                        pairs = [(o, loc) for o, loc in pl.walk_records(parse_json(p))]
                    except Exception as e:
                        src["parse_status"] = "error"
                        src["note"] = "json parse: %s" % e
                else:
                    pairs = parse_jsonl(p)
                if not pairs:
                    src["parse_status"] = "empty"
                    src["note"] = "no recognizable records"
                for robj, loc in pairs:
                    records.append(pl.build_record(robj, str(p), loc, ext))
            elif ext in (".csv", ".tsv"):
                pairs = parse_csv(p)
                if not pairs:
                    src["parse_status"] = "empty"
                for robj, loc in pairs:
                    records.append(pl.build_record(robj, str(p), loc, ext))
            elif ext in (".db", ".sqlite", ".sqlite3"):
                pairs = parse_sqlite(p)
                if not pairs:
                    src["parse_status"] = "empty"
                for robj, loc in pairs:
                    records.append(pl.build_record(robj, str(p), loc, ext))
            elif ext == ".docx":
                text = parse_docx(p)
                records.append(make_document_record(p, text, {}, "docx"))
                if not text.strip():
                    src["parse_status"] = "empty"
            elif ext == ".pdf":
                res = parse_pdf(p)
                if res.get("error"):
                    src["parse_status"] = "error"
                    src["note"] = res["error"]
                elif not res["has_text_layer"]:
                    src["parse_status"] = "no_text_layer"
                    src["note"] = "no embedded text (scanned facsimile); OCR not run offline"
                records.append(make_document_record(p, res["text"], res.get("meta", {}),
                                                    "pdf", note=src["note"] or None))
            else:
                text = read_text_file(p)[0]
                records.append(make_document_record(p, text, {}, "text"))
                if not text.strip():
                    src["parse_status"] = "empty"
        except Exception as e:
            src["parse_status"] = "error"
            src["note"] = str(e)
            degradations.append({"file": str(p), "issue": str(e)})
        src["records_extracted"] = len(records) - before
        sources.append(src)
    return records, sources, degradations

# -*- coding: utf-8 -*-
"""Offline patent/literature search core (stdlib only, no network, no CWD)."""
import json
import re
import unicodedata

def norm_text(s):
    if s is None:
        return ""
    return unicodedata.normalize("NFKC", str(s)).lower()

def to_str(v):
    if v is None:
        return ""
    if isinstance(v, (dict, list)):
        try:
            return json.dumps(v, ensure_ascii=False)
        except Exception:
            return str(v)
    return str(v)

# ---- number normalization ----
KIND_CODES = ("A1", "A2", "A3", "A4", "A5", "A6", "A8", "A9", "B1", "B2",
              "B3", "B4", "B5", "B6", "B8", "B9", "C1", "C2", "C3", "C4",
              "C5", "C6", "C8", "C9", "A", "B", "C", "U", "Y", "S", "T", "E")
KNOWN_CC = ("US", "WO", "EP", "CN", "JP", "KR", "DE", "GB", "FR", "AU",
            "CA", "IN", "TW", "RU", "BR", "IT", "NL", "SE", "CH")

def _strip_kind(s):
    m = re.search(r"([A-Z]\d?)\s*$", s.strip(), re.I)
    if m and m.group(1).upper() in KIND_CODES:
        return s.strip()[:m.start()].strip(), m.group(1).upper()
    return s.strip(), None

def _strip_country(s):
    m = re.match(r"^\s*([A-Za-z]{2})(?=[\s\d\-/:.,])", s)
    if m and m.group(1).upper() in KNOWN_CC:
        return m.group(1).upper(), s[m.end():].strip(" \t-/:.,")
    return None, s.strip()

def _split_year_serial(rest):
    core = re.sub(r"[^0-9A-Za-z]", "", rest)
    m = re.search(r"(19|20)\d{2}", core)
    if m:
        return m.group(0), re.sub(r"\D", "", core[:m.start()] + core[m.end():])
    return None, re.sub(r"\D", "", core)

def _classify(cc, year, serial, kind, orig):
    up = norm_text(orig)
    m2 = re.search(r"\b(\d{2})/\d{3},?\d{3}\b", up)
    if m2:
        return "provisional" if m2.group(1) in ("60", "61", "62", "63") else "application"
    if cc == "US":
        if year and (kind is None or kind[0] in "AUY"):
            return "publication"
        if not year and kind and kind[0] in "BC":
            return "grant"
        if not year and serial:
            try:
                if len(serial) >= 7 and int(serial) < 12000000:
                    return "grant"
            except ValueError:
                pass
            return "application"
        return "unknown"
    if cc == "WO":
        return "publication"
    if cc in KNOWN_CC:
        return "grant" if (kind and kind[0] in "BC") else "publication"
    return "unknown"

def _build_norm(cc, year, serial, kind):
    cc = cc or "US"
    ser = serial.lstrip("0") or "0" if serial else ""
    parts = [cc] + ([year] if year else []) + [ser] + ([kind] if kind else [])
    return "".join(parts)

def normalize_number(raw):
    if raw is None:
        return None
    orig = str(raw).strip()
    if not orig:
        return None
    s, kind = _strip_kind(orig)
    cc, rest = _strip_country(s)
    year, serial = _split_year_serial(rest)
    if not serial or len(serial) < 2:
        return None
    return {"raw": orig, "country": cc, "year": year, "serial": serial,
            "kind": kind, "type": _classify(cc, year, serial, kind, orig),
            "normalized": _build_norm(cc, year, serial, kind)}

NUM_TOKEN_RE = re.compile(
    r"(?:US|WO|EP|CN|JP|KR|DE|GB|FR|AU|CA|IN|TW|RU|BR|PCT)"
    r"[\s\-/:.]*[\d][\d\s\-/:.,]*[A-Z]?\d?|\b\d{2}/\d{3},?\d{3}\b", re.I)

def extract_numbers(text):
    out, seen = [], set()
    for m in NUM_TOKEN_RE.finditer(text or ""):
        n = normalize_number(m.group(0).strip())
        if n and n["normalized"] not in seen:
            seen.add(n["normalized"])
            out.append(n)
    return out

# ---- synonyms / terms ----
SYNONYMS = {
    "machine learning": ["ml", "deep learning", "neural network", "机器学习", "深度学习"],
    "artificial intelligence": ["ai", "人工智能"],
    "antibody": ["antibodies", "immunoglobulin", "mab", "抗体", "单克隆抗体"],
    "tumor": ["tumour", "cancer", "neoplasm", "肿瘤", "癌"],
    "polymerase chain reaction": ["pcr", "聚合酶链反应"],
    "crispr": ["cas9", "gene editing", "基因编辑"],
    "nanoparticle": ["nano", "纳米"],
    "vaccine": ["vaccines", "疫苗"],
}

def expand_terms(terms):
    out, seen = [], set()
    for t in terms:
        k = norm_text(t).strip()
        if k and k not in seen:
            seen.add(k)
            out.append(t)
        for canon, aliases in SYNONYMS.items():
            if k == canon or k in aliases:
                for a in [canon] + aliases:
                    a = norm_text(a)
                    if a and a not in seen:
                        seen.add(a)
                        out.append(a)
    return out

def extract_ipc_codes(text):
    codes = set()
    for m in re.finditer(r"\b([A-H]\d{2}[A-Z](?:\d{1,6})?)(?:/[\d]{1,6})?\b", text or ""):
        if re.match(r"^[A-H]\d{2}[A-Z]\d+", m.group(1)):
            codes.add(m.group(1).upper())
    return sorted(codes)

STOPWORDS = set("""the a an of and or to in for on with by at from as is are was were be been
this that these those it its we they he she you i not no nor but if then than so such each
about into over under between through during after before above below up down out off upon
against do does did done having has had have will shall can may might must could would should
patent patents application publication related method methods system systems apparatus device
一种 以及 及其 或者 用于 所述 其中 包括 包含 和 与 的 了 在 是 有 对 该 本 项 申请 专利 方法 装置
""".split())

CJK_NOISE = re.compile(r"查找|检索|相关|技术文献|要求|输出|案例|示例|说明|自测|本地|对象|覆盖"
                       r"|排序|依据|遗漏|归并|核验|法律|状态|同族|正式|结果|及其|非正式|并|与|的|和")

def extract_topic_terms(text, max_terms=40):
    terms, seen = [], set()
    for ph in re.findall(r"[\"\u201c\u201d\u300c\u300d]([^\"\u201c\u201d\u300c\u300d]{2,40})[\"\u201c\u201d\u300c\u300d]", text):
        if ph.strip() and norm_text(ph) not in seen:
            seen.add(norm_text(ph))
            terms.append(ph.strip())
    for run in re.findall(r"[\u4e00-\u9fff]{2,20}", text):
        for seg in CJK_NOISE.split(run):
            seg = seg.strip("，。、（）()")
            if len(seg) >= 2 and seg not in STOPWORDS and seg not in seen:
                seen.add(seg)
                terms.append(seg)
    for w in re.findall(r"[A-Za-z][A-Za-z0-9\-]{2,}", text):
        if w.lower() not in STOPWORDS and w not in seen:
            seen.add(w)
            terms.append(w)
    return terms[:max_terms]

# ---- field mapping ----
FIELD_ALIASES = {
    "publication_number": ["publication_number", "publicationnumber", "pubno", "公开号",
                           "公布号", "专利号", "patent_number"],
    "application_number": ["application_number", "applicationnumber", "applno", "申请号"],
    "priority": ["priority", "priority_number", "priority_numbers", "优先权"],
    "title": ["title", "invention_title", "发明名称", "名称"],
    "abstract": ["abstract", "摘要", "summary"],
    "claims": ["claims", "claim", "claim_text", "权利要求"],
    "applicants": ["applicants", "applicant", "assignee", "assignees", "申请人", "专利权人", "权利人"],
    "inventors": ["inventors", "inventor", "发明人"],
    "ipc": ["ipc", "ipc_classification", "分类号", "国际分类"],
    "cpc": ["cpc", "cpc_classification", "合作分类"],
    "publication_date": ["publication_date", "公开日", "公布日", "pub_date", "published",
                         "published-print", "published-online", "issued"],
    "filing_date": ["filing_date", "application_date", "申请日"],
    "priority_date": ["priority_date", "优先权日"],
    "legal_status": ["legal_status", "status", "法律状态", "状态"],
    "family": ["family", "family_members", "同族", "family_id"],
    "doi": ["doi"],
    "authors": ["authors", "author", "作者"],
    "journal": ["journal", "container_title", "container-title", "journal_title", "期刊", "source"],
    "year": ["year", "publication_year", "年份", "published", "published-print",
             "published-online", "issued"],
    "url": ["url", "link", "href"],
}

def _listify(v):
    if v is None:
        return []
    return list(v) if isinstance(v, (list, tuple)) else [v]

def _extract_field(obj, canon):
    aliases = FIELD_ALIASES.get(canon, [])
    for key, val in obj.items():
        if norm_text(str(key)) in aliases:
            return val
    return None

def _field_values(obj, canon):
    return _listify(_extract_field(obj, canon))

def _authors_from(v):
    out = []
    for a in _listify(v):
        if isinstance(a, dict):
            nm = a.get("name") or ((to_str(a.get("given", "")) + " " + to_str(a.get("family", ""))).strip())
            if nm:
                out.append(nm)
        else:
            out.append(to_str(a))
    return [x for x in out if x]

def _year_from(v):
    m = re.search(r"(19|20)\d{2}", to_str(v))
    return m.group(0) if m else ""

def looks_like_record(obj):
    if not isinstance(obj, dict):
        return False
    keys = set(norm_text(k) for k in obj.keys())
    strong = ("title", "publication_number", "application_number", "doi", "abstract",
              "claims", "inventors", "inventor", "assignee", "assignees", "公开号",
              "申请号", "发明名称", "权利要求")
    if sum(1 for k in strong if k in keys) >= 2:
        return True
    if "title" in keys and ("doi" in keys or "authors" in keys or "author" in keys):
        return True
    return "title" in keys and "abstract" in keys

def _priority_vals(v):
    nums = []
    for p in _listify(v):
        if isinstance(p, dict):
            for k in ("number", "priority_number", "patent_number", "application_number",
                      "publication_number", "priority"):
                if p.get(k):
                    nums.append(p.get(k))
        elif isinstance(p, str) and p.strip():
            nums.append(p)
    return nums

def build_record(obj, source_file, locator, source_format):
    title = to_str(_extract_field(obj, "title")).strip()
    abstract = to_str(_extract_field(obj, "abstract")).strip()
    claims_text = "\n".join(c for c in [to_str(x) for x in _field_values(obj, "claims")] if c).strip()
    applicants = [to_str(a.get("name") or a.get("applicant") or a.get("assignee"))
                  if isinstance(a, dict) else to_str(a) for a in _field_values(obj, "applicants")]
    applicants = [x for x in applicants if x]
    inventors = _authors_from(_extract_field(obj, "inventors"))
    authors = _authors_from(_extract_field(obj, "authors"))
    ipc = [to_str(x) for x in _field_values(obj, "ipc") if to_str(x)]
    cpc = [to_str(x) for x in _field_values(obj, "cpc") if to_str(x)]
    doi = to_str(_extract_field(obj, "doi")).strip() or None
    journal = to_str(_extract_field(obj, "journal")).strip()
    pub_raw = to_str(_extract_field(obj, "publication_number")).strip()
    app_raw = to_str(_extract_field(obj, "application_number")).strip()
    prio_raws = _priority_vals(_extract_field(obj, "priority"))
    legal = to_str(_extract_field(obj, "legal_status")).strip()
    year = _year_from(_extract_field(obj, "year")) or _year_from(_extract_field(obj, "publication_date"))
    numbers = []
    for raw in [pub_raw, app_raw] + prio_raws:
        if raw:
            for n in extract_numbers(raw):
                if n not in numbers:
                    numbers.append(n)
    is_patent = bool(pub_raw or app_raw or prio_raws or claims_text or ipc or cpc)
    is_paper = bool(doi or authors or journal) and not is_patent
    kind = "patent" if is_patent else ("paper" if is_paper else "document")
    text = "\n".join(p for p in [title, abstract, claims_text] + applicants +
                     inventors + authors + ipc + cpc if p)
    rec = {
        "kind": kind, "title": title, "abstract": abstract, "claims": claims_text,
        "applicants": applicants, "inventors": inventors, "authors": authors,
        "ipc": ipc, "cpc": cpc, "doi": doi, "journal": journal, "year": year,
        "publication_date": to_str(_extract_field(obj, "publication_date")).strip(),
        "filing_date": to_str(_extract_field(obj, "filing_date")).strip(),
        "priority_date": to_str(_extract_field(obj, "priority_date")).strip(),
        "publication_number_raw": pub_raw, "application_number_raw": app_raw,
        "priority_raws": prio_raws, "legal_status": legal, "numbers": numbers,
        "pub_norm": [n["normalized"] for n in numbers],
        "priority_norm": [normalize_number(p)["normalized"] for p in prio_raws
                          if normalize_number(p)],
        "app_norm": normalize_number(app_raw)["normalized"] if normalize_number(app_raw) else None,
        "text": text, "source_file": source_file, "source_format": source_format,
        "locator": locator,
    }
    import hashlib
    rec["record_id"] = hashlib.sha1(
        ("|".join([kind, pub_raw, doi or "", title[:40]])).encode("utf-8", "replace")).hexdigest()[:12]
    return rec

# ---- walking / family / dedup / scoring ----
WRAPPER_KEYS = ("records", "results", "items", "docs", "documents", "patents", "hits",
                "data", "entries", "message", "response", "list", "rows", "doc")

def walk_records(obj, path="$"):
    if isinstance(obj, list):
        for i, item in enumerate(obj):
            yield from walk_records(item, "%s[%d]" % (path, i))
    elif isinstance(obj, dict):
        if looks_like_record(obj):
            yield obj, path
            return
        went = False
        for k in WRAPPER_KEYS:
            if k in obj:
                went = True
                yield from walk_records(obj[k], "%s.%s" % (path, k))
        if not went:
            for k, v in obj.items():
                if isinstance(v, (dict, list)):
                    yield from walk_records(v, "%s.%s" % (path, k))

def group_families(records):
    patents = [r for r in records if r["kind"] == "patent"]
    simple = {}
    for r in patents:
        keys = sorted(set(r["priority_norm"])) or ([r["app_norm"]] if r["app_norm"] else [])
        if keys:
            simple.setdefault(tuple(keys), []).append(r["record_id"])
    parent = {r["record_id"]: r["record_id"] for r in patents}
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra
    by_link = {}
    for r in patents:
        for p in r["priority_norm"]:
            by_link.setdefault(("p", p), []).append(r["record_id"])
        if r["app_norm"]:
            by_link.setdefault(("a", r["app_norm"]), []).append(r["record_id"])
    for ids in by_link.values():
        for i in range(1, len(ids)):
            union(ids[0], ids[i])
    comps = {}
    for rid in parent:
        comps.setdefault(find(rid), []).append(rid)
    return {"simple": {":".join(k): sorted(v) for k, v in simple.items()},
            "extended": [sorted(v) for v in comps.values()]}

def dedup(records):
    keep, seen, dup = [], {}, []
    for r in records:
        key = ("num", r["pub_norm"][0]) if r["pub_norm"] else (
            ("doi", r["doi"]) if r.get("doi") else
            ("text", norm_text(r["title"])[:60], r.get("year", "")))
        if key in seen:
            dup.append({"kept": seen[key], "dropped": r["record_id"], "reason": "dup:%s" % key[0]})
            continue
        seen[key] = r["record_id"]
        keep.append(r)
    return keep, dup

def score_topic(record, terms, ipc_codes):
    title = norm_text(record.get("title", ""))
    abstract = norm_text(record.get("abstract", ""))
    claims = norm_text(record.get("claims", ""))
    text = "\n".join([title, abstract, claims] +
                     [norm_text(a) for a in record.get("applicants", [])] +
                     [norm_text(a) for a in record.get("authors", [])])
    score, hits = 0.0, []
    for t in terms:
        tt = norm_text(t)
        if not tt or len(tt) < 2:
            continue
        w = 3.0 if tt in title else (2.0 if tt in abstract else (1.5 if tt in claims else 1.0))
        if tt in text:
            score += w
            hits.append({"term": t, "weight": w})
    for code in ipc_codes:
        for f in record.get("ipc", []) + record.get("cpc", []):
            fn = norm_text(f)
            if fn.startswith(norm_text(code)) or norm_text(code) in fn:
                score += 2.0
                hits.append({"term": code, "weight": 2.0})
                break
    return round(score, 4), hits

def match_number(record, nq):
    if not record["numbers"]:
        return None
    for tn in record["numbers"]:
        if tn["normalized"] == nq["normalized"]:
            return "exact"
    for pn in record["pub_norm"] + ([record["app_norm"]] if record.get("app_norm") else []):
        if pn and pn == nq["normalized"]:
            return "exact"
    for pn in record["priority_norm"]:
        if pn == nq["normalized"]:
            return "priority"
    for tn in record["numbers"]:
        if tn["serial"] and nq["serial"] and tn["serial"] == nq["serial"] \
                and tn["country"] == nq["country"]:
            return "serial"
    return None

def quote_window(raw_text, term, width=60):
    idx = norm_text(raw_text).find(norm_text(term))
    if idx < 0:
        return None
    return raw_text[max(0, idx - width):idx + len(term) + width]

# -*- coding: utf-8 -*-
"""main — offline patent/literature search skill. Single command = full flow."""
import argparse
import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import patent_lib as pl
import fileio as fio

DEFAULT_INPUT = "/input"
DEFAULT_WORK = "/app/work"
DEFAULT_OUTPUT = "/app/output"
OFFLINE_NOTE = "offline corpus; no live registry/API query; query date = n/a (local files)"
LEVEL_RANK = {"exact": 0, "serial": 1, "priority": 2, "topic": 3}


def parse_args(argv):
    ap = argparse.ArgumentParser(prog="main.py",
                                 description="Patent/literature search (offline, source-bound)")
    ap.add_argument("command", nargs="?", default="run",
                    choices=["run", "init", "check", "build", "help"])
    ap.add_argument("--input", dest="input_dir")
    ap.add_argument("--work", dest="work_dir")
    ap.add_argument("--output", dest="output_dir")
    a = ap.parse_args(argv)
    a.input_dir = a.input_dir or os.environ.get("INPUT_DIR") or DEFAULT_INPUT
    a.work_dir = a.work_dir or os.environ.get("WORK_DIR") or DEFAULT_WORK
    a.output_dir = a.output_dir or os.environ.get("OUTPUT_DIR") or DEFAULT_OUTPUT
    return a


def ensure_dirs(a):
    for d in (a.input_dir, a.work_dir, a.output_dir):
        Path(d).mkdir(parents=True, exist_ok=True)


def read_task(a):
    case_path = Path(a.input_dir) / "case.json"
    task_path = Path(a.input_dir) / "task.md"
    case, instruction, errors = {}, "", []
    if case_path.exists():
        try:
            case = fio.parse_json(case_path)
            if not isinstance(case, dict):
                case, errors = {}, ["case.json is not a JSON object"]
        except Exception as e:
            case, errors = {}, ["case.json parse error: %s" % e]
    else:
        errors.append("missing /input/case.json")
    if task_path.exists():
        instruction += fio.read_text_file(task_path)[0]
    for k in ("task_instruction", "instruction", "question", "prompt", "task"):
        if case.get(k):
            instruction += "\n" + str(case[k])
    case_id = (case.get("case_id") or case.get("caseId") or case.get("id")
               or (case_path.stem if case_path.exists() else "unknown"))
    return case, instruction, case.get("output_contract"), case_id, errors


def discover_materials(input_dir):
    root = Path(input_dir)
    files = []
    for dp, dirs, names in os.walk(input_dir):
        dirs.sort()
        for n in sorted(names):
            p = Path(dp) / n
            if p != root / "case.json" and p != root / "task.md":
                files.append(p)
    return files


def number_quote(rec, q, lvl):
    cands = ([rec["publication_number_raw"]] if rec.get("publication_number_raw") else []) + \
            ([rec["application_number_raw"]] if rec.get("application_number_raw") else []) + \
            list(rec.get("priority_raws", []))
    for raw in cands:
        for n in pl.extract_numbers(raw):
            if n["normalized"] == q:
                return raw, "number"
    for n in rec.get("numbers", []):
        if n["normalized"] == q:
            return n["raw"], "number"
    return None, None


def field_quote(rec, term):
    for f in ("title", "abstract", "claims"):
        q = pl.quote_window(rec.get(f) or "", term)
        if q is not None:
            return q, f
    q = pl.quote_window(rec.get("text", ""), term)
    return (q, "text") if q is not None else (None, None)


def record_meta(rec):
    if rec["kind"] == "patent":
        return {"publication_number": rec["publication_number_raw"] or None,
                "application_number": rec["application_number_raw"] or None,
                "priority_numbers": rec["priority_raws"],
                "normalized_numbers": rec["pub_norm"],
                "number_types": [n["type"] for n in rec["numbers"]],
                "ipc": rec["ipc"], "cpc": rec["cpc"], "applicants": rec["applicants"],
                "inventors": rec["inventors"]}
    return {"doi": rec.get("doi"), "authors": rec["authors"], "journal": rec.get("journal")}


def derive(records, instruction, sources, degradations, errors):
    nums = pl.extract_numbers(instruction)
    base_terms = pl.extract_topic_terms(instruction)
    terms = pl.expand_terms(base_terms)
    ipc = pl.extract_ipc_codes(instruction)
    cand = {}
    for nq in nums:
        for r in records:
            lvl = pl.match_number(r, nq)
            if lvl and (r["record_id"] not in cand
                        or LEVEL_RANK[lvl] < LEVEL_RANK[cand[r["record_id"]][1]]):
                cand[r["record_id"]] = (r, lvl, nq["normalized"], 0.0)
    for r in records:
        sc, hits = pl.score_topic(r, terms, ipc)
        if sc > 0:
            term = max(hits, key=lambda h: h["weight"])["term"]
            if r["record_id"] not in cand or LEVEL_RANK[cand[r["record_id"]][1]] >= 3:
                cand[r["record_id"]] = (r, "topic", term, sc)
    fam = pl.group_families(records)
    for rid in list(cand):
        if cand[rid][1] in ("exact", "serial", "priority"):
            for comp in fam["extended"]:
                if rid in comp:
                    for m in comp:
                        if m not in cand:
                            rr = next((x for x in records if x["record_id"] == m), None)
                            if rr:
                                cand[m] = (rr, "priority", rid, 0.0)
    ranked = sorted(cand.values(), key=lambda c: (LEVEL_RANK[c[1]], -c[3], c[0]["record_id"]))
    candidates = []
    rel = {"exact": "exact normalized number match", "serial": "serial match; confirm kind/family",
           "priority": "priority/family link", "topic": "topic-term relevance"}
    for i, (r, lvl, q, sc) in enumerate(ranked, 1):
        if lvl in ("exact", "serial", "priority"):
            quote, qf = number_quote(r, q, lvl)
        else:
            quote, qf = field_quote(r, q)
        candidates.append({
            "rank": i, "record_id": r["record_id"], "kind": r["kind"],
            "title": r["title"] or None, "year": r["year"] or None,
            "venue": r["journal"] or ("patent record" if r["kind"] == "patent" else None),
            "metadata": record_meta(r), "legal_status": r["legal_status"] or None,
            "match": {"type": lvl, "query": q, "score": sc},
            "evidence": {"source_file": r["source_file"], "locator": r["locator"],
                         "quote": quote, "quote_field": qf},
            "relevance_note": rel[lvl]})

    rounds, zero = [], []
    def _round(no, typ, qs, disp):
        hits, ids = 0, set()
        for q in qs:
            for r in records:
                if typ == "number" and pl.match_number(r, q):
                    hits += 1
                    ids.add(r["record_id"])
                elif typ == "topic" and pl.score_topic(r, [q], ipc)[0] > 0:
                    hits += 1
                    ids.add(r["record_id"])
                elif typ == "class" and pl.score_topic(r, [], [q])[0] > 0:
                    hits += 1
                    ids.add(r["record_id"])
        rounds.append({"round": no, "type": typ, "queries": disp, "hit_count": hits,
                       "matched_record_ids": sorted(ids)})
    _round(1, "number", nums, [n["normalized"] for n in nums])
    _round(2, "number", nums, [n["raw"] for n in nums])
    _round(3, "topic", base_terms, base_terms)
    _round(4, "topic", terms, terms)
    _round(5, "class", ipc, ipc)
    zero = [r for r in rounds if r["hit_count"] == 0]
    query_plan = {
        "decomposition": [
            {"intent": "number_lookup", "queries": [n["raw"] for n in nums],
             "normalized": [n["normalized"] for n in nums]},
            {"intent": "topic_search", "base_terms": base_terms,
             "expanded_terms": terms, "ipc_codes": ipc}],
        "rounds": rounds, "zero_hit_queries": zero,
        "method_note": "numbers: exact + format-variant + priority match; topics: weighted "
                       "term (title 3.0/abstract 2.0/claims 1.5/body 1.0) + classification 2.0"}

    deduped, dup_log = pl.dedup(records)
    families = {"simple_families": fam["simple"], "extended_families": fam["extended"],
                "scope_note": "simple = shared priority numbers; extended = observed-link "
                              "components, NOT exhaustive INPADOC"}
    legal = [e for e in (legal_entry(r) for r in records) if e]
    coverage = {"zero_hit_queries": zero, "materials_not_parsed": degradations,
                "missing_metadata": missing_meta(records),
                "number_queries_without_exact_match": [
                    n["raw"] for n in nums if not any(pl.match_number(r, n) == "exact"
                                                      for r in records)],
                "notes": [OFFLINE_NOTE]}
    summary = {"research_question": (instruction or "").strip()[:2000] or None,
               "record_count": len(records), "dedup_kept": len(deduped),
               "candidate_count": len(candidates),
               "patent_records": sum(1 for r in records if r["kind"] == "patent"),
               "paper_records": sum(1 for r in records if r["kind"] == "paper"),
               "document_records": sum(1 for r in records if r["kind"] == "document"),
               "scope": "patent-number normalization/family grouping + topic search over the "
                        "provided local corpus only; no live query, no official-register check"}
    return {"candidates": candidates, "query_plan": query_plan, "families": families,
            "legal_status": legal, "coverage": coverage, "sources": sources,
            "uncertainty": uncertainty(records, zero, nums), "summary": summary,
            "dedup": dup_log, "errors": errors, "degradations": degradations,
            "change_records": [{"step": "init", "action": "partial result written"},
                               {"step": "finalize", "action": "full derivation written"}]}


def legal_entry(r):
    if r["kind"] != "patent":
        return None
    return {"record_id": r["record_id"], "publication_number": r["publication_number_raw"] or None,
            "legal_status": r["legal_status"] or None,
            "source": r["source_file"] if r["legal_status"] else None, "query_date": None,
            "verified_against_official_register": False,
            "note": ("state as recorded in provided material" if r["legal_status"]
                     else "no legal-status field; official register not queried (offline)")}


def missing_meta(records):
    out = []
    for r in records:
        if r["kind"] == "patent":
            miss = [k for k, v in (("legal_status", r["legal_status"]),
                                   ("priority", r["priority_norm"])) if not v]
            if miss:
                out.append({"record_id": r["record_id"],
                            "publication_number": r["publication_number_raw"] or None,
                            "missing": miss})
    return out


def uncertainty(records, zero, nums):
    u = []
    if not any(r["legal_status"] for r in records if r["kind"] == "patent"):
        u.append({"level": "high", "aspect": "legal_status",
                  "detail": "official legal status unknown/absent in provided material",
                  "recommendation": "verify against official register before R&D decision"})
    if zero:
        u.append({"level": "medium", "aspect": "coverage",
                  "detail": "zero-hit queries kept in query_plan.zero_hit_queries",
                  "recommendation": "expand synonyms or add missing source"})
    u.append({"level": "medium", "aspect": "family_scope",
              "detail": "extended families are observed-link components, not exhaustive INPADOC",
              "recommendation": "do not treat as complete family or equal claim scope"})
    if not nums:
        u.append({"level": "medium", "aspect": "query_type",
                  "detail": "no patent number detected in instruction; topic search only",
                  "recommendation": "confirm whether number lookup was intended"})
    return u


# ---- output_contract filling ----
KEY_TARGETS = [
    (["legal", "status", "law", "法律", "状态"], "legal_status"),
    (["coverage", "omission", "gap", "missing", "recall", "覆盖", "遗漏"], "coverage"),
    (["uncertainty", "risk", "confidence", "不确定"], "uncertainty"),
    (["dedup", "duplicate", "去重"], "dedup"),
    (["number", "normaliz", "号码"], "query_plan"),
    (["change", "history", "audit", "变更"], "change_records"),
    (["error", "degrad", "异常", "错误"], "errors"),
    (["famil", "族"], "families"),
    (["query", "plan", "search", "检索"], "query_plan"),
    (["rank", "order", "sort", "排序"], "candidates"),
    (["source", "provenance", "evidence", "locat", "来源", "证据"], "sources"),
    (["summary", "conclusion", "overview", "总结"], "summary"),
    (["candidate", "result", "record", "patent", "literature", "doc", "hit", "文献", "候选"], "candidates"),
    (["scope", "范围", "method", "方法"], "summary"),
]
NOT_FOUND = object()


def _empty_for(schema):
    if isinstance(schema, list):
        return []
    if isinstance(schema, dict):
        return [] if schema.get("type") == "array" else ({}
            if schema.get("type") == "object" else None)
    return None


def _resolve(k, derived):
    kl = k.lower()
    for keys, target in KEY_TARGETS:
        if any(t in kl for t in keys) and target in derived:
            return derived[target]
    return NOT_FOUND


def fill_contract(contract, derived):
    if isinstance(contract, dict):
        out = {}
        for k, v in contract.items():
            val = _resolve(k, derived)
            if val is NOT_FOUND:
                val = fill_contract(v, derived) if isinstance(v, (dict, list)) else _empty_for(v)
            out[k] = val
        return out
    if isinstance(contract, list):
        if all(isinstance(x, str) for x in contract):
            return {x: (_resolve(x, derived) if _resolve(x, derived) is not NOT_FOUND else None)
                    for x in contract}
        return [_empty_for(x) for x in contract]
    return None


def contract_fields(contract):
    if isinstance(contract, dict) and isinstance(contract.get("properties"), dict):
        return contract["properties"]
    return contract if isinstance(contract, dict) else {}


def build_result(derived, contract, case_id, status):
    result = fill_contract(contract, derived) if contract is not None else {}
    if not isinstance(result, dict):
        result = {}
    result["case_id"] = case_id
    result["status"] = status
    for k in ("sources", "uncertainty", "change_records", "errors", "degradations"):
        if k in derived:
            result[k] = derived[k]
    return result


def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def run_full(a):
    ensure_dirs(a)
    case, instruction, contract, case_id, errors = read_task(a)
    out = Path(a.output_dir)
    write_json(out / "result.json", build_result({}, contract, case_id, "partial"))
    status = "input_error" if errors else "complete"
    records, sources, degradations = fio.load_materials(discover_materials(a.input_dir))
    if status != "input_error" and not records:
        status = "insufficient_evidence"
    derived = derive(records, instruction, sources, degradations, errors)
    result = build_result(derived, contract, case_id, status)
    write_json(out / "result.json", result)
    try:
        write_json(Path(a.work_dir) / "records.json",
                   [{k: r[k] for k in ("record_id", "kind", "title", "publication_number_raw",
                                       "application_number_raw", "priority_raws", "legal_status",
                                       "source_file", "locator")} for r in records])
        write_json(Path(a.work_dir) / "query_plan.json", derived["query_plan"])
    except OSError as e:
        degradations.append({"issue": "work draft write failed: %s" % e})
    lines = ["# Patent/Literature Search Result", "", "case_id: %s" % case_id,
             "status: %s" % result.get("status"), ""]
    for c in result.get("candidates") or []:
        ev = c.get("evidence") or {}
        lines.append("- [%s] %s (%s) %s — %s:%s" % (c.get("rank"), c.get("title"),
                     c.get("year"), c.get("match", {}).get("type"),
                     ev.get("source_file"), ev.get("locator")))
    (out / "report.md").write_text("\n".join(lines), encoding="utf-8")
    return result


def cmd_init(a):
    ensure_dirs(a)
    write_json(Path(a.work_dir) / "draft.json",
               {"case_id": None, "status": "partial", "records": [], "query_plan": None,
                "note": "work draft scaffold; run default flow to derive"})
    print("initialized", Path(a.work_dir) / "draft.json")


def norm_sub(rec, q):
    qn = pl.norm_text(q)
    for f in ("title", "abstract", "claims", "publication_number_raw",
              "application_number_raw", "text"):
        if qn in pl.norm_text(rec.get(f) or ""):
            return True
    return any(qn in pl.norm_text(p) for p in rec.get("priority_raws", []))


def cmd_check(a):
    ok = True
    try:
        _, _, contract, _, _ = read_task(a)
        r = json.loads((Path(a.output_dir) / "result.json").read_text(encoding="utf-8"))
        missing = [k for k in contract_fields(contract) if k not in r]
        if missing:
            print("FAIL contract keys missing:", missing)
            ok = False
        else:
            print("PASS contract keys: all present")
    except Exception as e:
        print("FAIL contract check:", e)
        ok = False
    try:
        records, _, _ = fio.load_materials(discover_materials(a.input_dir))
        by_id = {r["record_id"]: r for r in records}
        r = json.loads((Path(a.output_dir) / "result.json").read_text(encoding="utf-8"))
        total = hit = 0
        for c in (r.get("candidates") or []):
            q = (c.get("evidence") or {}).get("quote")
            if q:
                total += 1
                if by_id.get(c.get("record_id")) and norm_sub(by_id[c["record_id"]], q):
                    hit += 1
        rate = hit / total if total else 1.0
        print(("PASS quote-hit %.3f (%d/%d)" % (rate, hit, total)) if rate >= 0.95
              else ("FAIL quote-hit %.3f (%d/%d)" % (rate, hit, total)))
        ok = ok and rate >= 0.95
    except Exception as e:
        print("FAIL quote check:", e)
        ok = False
    print("OVERALL:", "PASS" if ok else "FAIL")


def main(argv):
    a = parse_args(argv)
    if a.command == "help":
        parse_args(["--help"])
        return 0
    try:
        {"run": run_full, "build": run_full, "init": cmd_init,
         "check": cmd_check}[a.command](a)
    except SystemExit:
        raise
    except Exception as e:
        try:
            ensure_dirs(a)
            p = Path(a.output_dir) / "result.json"
            if not p.exists():
                write_json(p, {"case_id": "unknown", "status": "input_error", "errors": [str(e)],
                               "sources": [], "uncertainty": [],
                               "change_records": [{"step": "init", "action": "error caught"}],
                               "degradations": [str(e)]})
        except Exception:
            pass
        print("error (recorded):", e)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

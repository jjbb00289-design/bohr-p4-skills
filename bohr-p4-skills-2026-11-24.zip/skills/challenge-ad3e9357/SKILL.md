---
name: patent-literature-search
description: 离线、来源绑定的专利与技术文献检索。对本地授权语料做专利号规范化、同族归并与去重、技术主题检索、法律状态核验与证据留痕，输出可复核的候选集、排序依据与遗漏说明。用于专利定位、技术查新、同主题文献发现类任务，不做实时联网检索、不编造 DOI/作者/法律状态。
version: 1.0.0
---

# 专利与技术文献检索 Skill

## 用途
在**本地提供的授权语料**（专利记录 JSON/CSV/SQLite、USPTO/欧洲/中国专利原文 PDF、科学比较论文 PDF、引用图等）上完成一次可复核的检索：识别检索对象（专利号或技术主题）、规范化号码、归并同族并去重、检索同主题文献、核验法律状态、逐条留证。产出结构化 `result.json` 与 `report.md`。

## 触发条件
- 用户要求定位某件专利（公开号/申请号/授权号/优先权号）、查同族、查法律状态；
- 用户要求围绕技术主题做查新/找同主题文献/找同族专利；
- 用户要求对已有检索结果做去重、排序、来源核验或遗漏说明。
不适用：专利撰写、侵权判定、自由实施分析结论、专利价值评估、付费墙绕过、实时联网检索。

## 调用方式
Agent 按以下顺序执行：
1. 先运行脚本完成确定性派生（单命令默认=完整流程）：
   `python /skills/weekly-skill/scripts/main.py --input /input --work /app/work --output /app/output`
   （平台路径为默认值，无需传参；本地测试可设 `INPUT_DIR` / `WORK_DIR` / `OUTPUT_DIR` 或同名参数。）
2. 对**无文本层的扫描件 PDF**（USPTO 传真件等），脚本会标注 `no_text_layer`；如任务要求其正文/权利要求，Agent 用平台的 `pdf-text-tool` / `ocr-tool` 提取文本并写入 `/app/work/<原名>.ocr.txt`，再重跑脚本（脚本会递归读取 `/input` 与 `/app/work` 中的 `.txt`）。
3. 阅读 `/app/output/result.json` 与 `report.md`，按需用模型能力补充解读；**不改写脚本已落盘的证据字段**，可另写 `review_notes`。

子命令（可选）：`init`（写工作稿骨架）、`check`（自检契约键与 quote 命中）、`build`（等同默认）、`help`。

## 输入
- `/input/case.json`：`case_id`、`task_instruction`、`output_contract`（结果字段模板）。
- `/input/task.md`：任务说明（与 `task_instruction` 合并用于拆解检索问题）。
- `/input/**`：全部材料，递归扫描（`os.walk`）；支持 `.json/.jsonl/.csv/.tsv/.db/.sqlite/.docx/.pdf/.txt/.md/.xml`。

## 输出
`/app/output/result.json`（必含 `case_id` + `output_contract` 全部字段 + `status/sources/uncertainty/change_records/errors/degradations`）、`report.md`（人类可读）；`/app/work/` 存工作稿 `records.json`、`query_plan.json`。缺值用 `null`/`[]`，绝不改字段名或漏键。

## 工作稿 schema
- `records.json`：规范化后的记录数组，字段 `record_id/kind/title/publication_number_raw/application_number_raw/priority_raws/legal_status/source_file/locator`。
- `query_plan.json`：`decomposition`（号码意图/主题意图）、`rounds`（每轮查询、命中数、命中 record_id）、`zero_hit_queries`、`method_note`。
- `draft.json`（`init` 生成）：空骨架，非正式结果。

## 证据规范（红线）
每条候选、每个结论都要有 `evidence = {source_file, locator, quote, quote_field}`：
- `source_file`：材料绝对路径；`locator`：JSON 路径 / CSV 行 / SQLite 表+行 / PDF 文本层 / 扫描件标注。
- `quote`：**逐字**取自材料原文（JSON 字段值、CSV 单元格、抽取的 PDF 文本），脚本写入前用子串检查校验，命中率自检 ≥0.95。
- 无法给出逐字 quote 的条目：`quote=null` 并在 `degradations` 说明原因，不得编造。

## 核心方法
1. **号码规范化**：分离国别码（US/WO/EP/CN/JP/KR…）、年、序列号、种类码（A1/B1…），统一为 `国家+年+序列+种类` 键；区分公开号/申请号（`NN/NNN,NNN` 系列）/授权号（US 无年 7 位）/优先权号（60-63 系列临时申请），种类码 A/U/Y 视为公开、B/C 视为授权。
2. **同族归并**：简单族=共享规范化优先权号；扩展族=在已观察到的优先权/申请号链路上的连通分量；**明确声明扩展族不等于完整 INPADOC 族**。
3. **主题检索**：对标题(3.0)/摘要(2.0)/权利要求(1.5)/正文(1.0)加权词匹配 + IPC/CPC 分类号(2.0)；同义词/缩写/跨语言扩展见 `references/query_templates.md`。
4. **法律状态**：只采用材料中明确记录的状态并标来源；材料未给状态 → 标 `null` 并说明"官方登记未查询（离线）"，绝不引用转载页当登记依据。
5. **排序**：精确号 > 序列号 > 优先权/同族 > 主题相关性；同级按得分降序、再按 record_id 稳定排序（确定性）。

## 降级表
| 情况 | 检测 | 处置 |
|-|-|-|
| 缺 `case.json` | `/input/case.json` 不存在 | `status=input_error`，合法 result.json，exit 0 |
| 坏 JSON | 解析异常 | 同上，`errors` 记录 |
| 无材料/无记录 | 递归扫描后 records 为空 | `status=insufficient_evidence`，`candidates=[]`，`gaps` 说明 |
| 扫描件无文本层 | PDF 无嵌入文本 | `parse_status=no_text_layer`，建议 OCR，不编造正文 |
| 法律状态缺失 | 记录无状态字段 | `legal_status=null` + 官方登记未查询说明 |
| 无命中查询 | 某轮 hit_count=0 | 保留在 `zero_hit_queries`，说明为无结果 |
| 权限/读取失败 | OSError | 记入 `degradations`，继续处理其余文件 |

## 自检
`python scripts/main.py check --input … --output …`：校验 `result.json` 合法、`output_contract` 键齐全、每条候选 quote 命中原文 ≥0.95；`check` 恒 exit 0。两次全新输出目录各跑一次，产物应逐字节结构一致（无时间戳/随机）。

## 限制
- 仅处理**已提供**的本地材料；不联网、不调官方登记库、不生成实时检索结论。
- 号码分类（US 公开/授权/申请）为规则启发式，已按类型标注；跨局格式差异需人工复核。
- 扩展族仅基于已观察链接，不推断未提供的同族成员，不作等同权利要求范围的判定。
- 法律状态不保证时效：官方状态以登记局为准，本 Skill 只做来源与缺口的如实呈现。

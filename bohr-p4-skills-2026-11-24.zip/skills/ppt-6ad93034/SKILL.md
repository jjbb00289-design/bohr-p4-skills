---
name: academic-ppt
description: Build or adapt an academic slide deck from research material (paper PDF/DOCX/MD/TXT/CSV/TSV/JSON/SQLite, optional figures, optional .pptx template or starting deck). One command reads /input, derives a verbatim page plan with source locators, builds an editable .pptx that inherits the supplied template's master/layout/theme, exports a PDF plus per-slide PNG previews, and writes result.json echoing every output_contract field plus case_id/status/sources/uncertainty/changes. Use when the task is to turn a paper into a traceable, template-constrained academic presentation.
version: 1.0.0
---

# academic-ppt

把论文/科研材料组织成**主线成立、页页可回溯、可编辑、可放映**的学术 PPT，而不是把段落切块贴进页面。默认单命令即可从 `/input` 派生完整页级计划并交付；不要求评测 Agent 先写工作稿。

## 用途与触发条件

适用：输入含论文或科研材料（PDF / DOCX / Markdown / TXT / CSV / TSV / JSON / SQLite / 图片），要求产出学术汇报 PPT（组会、答辩、评审、会议）；可选提供 `.pptx`/`.potx` 模板或起始 deck；要求数字/单位/图号与原文一致、模板能套、导出能打开。

不适用：只要论文精读结论；只要科研绘图美化；只要文稿润色；只要 PPT 软件本身。材料完全缺失时写 `insufficient_evidence`，**绝不编造论文内容**。

## 调用方式

默认**单命令**即完整流程（无需先写工作稿，也无需多步交互）：

```bash
python3 scripts/main.py            # 默认=build：/input → 派生 → 构建 → 导出 → result.json
python3 scripts/main.py --input DIR --work DIR --output DIR
python3 scripts/main.py --version  # 或 --help
```

环境变量 `INPUT_DIR` / `WORK_DIR` / `OUTPUT_DIR` 可覆盖默认 `/input` `/app/work` `/app/output`。脚本用 `Path(__file__).resolve().parent` 定位自身，不依赖 CWD、不联网、只用 Python 标准库。所有路径退出码恒 0。无模板时用包内 `assets/default_template.pptx`（16:9，含母版/11 版式/主题）。

## 输入输出

| 项 | 路径 |
|---|---|
| 输入 | `/input/case.json`（`case_id`、`task_instruction`、`output_contract`，可含 `title`/`slide_count`/`mode`/`audience`/`duration_minutes`/`template`/`starting_deck`）、`/input/task.md`、`/input/` 下材料 |
| 工作区 | `/app/work/`：`index.json`（材料索引 + locator 段号）、`plan.json`（实际执行的派生页计划） |
| 产物 | `/app/output/`：`result.json`（必需）、`presentation.pptx`、`presentation.pdf`、`preview/slide-*.png`、`content_map.json`、`page_plan.json`、`evidence_map.json`、`changes.json`、`template_check.json`、`export_check.json`、`run.log` |

## 派生方法（无工作稿自动完成）

1. **读材料**：PDF 用 `pdftotext`（无则标准库 content-stream 抽取）；DOCX 解包 `word/document.xml`；CSV/TSV 按行；SQLite 用 `sqlite3` 读表；JSON 展平为 `path = value` 行；文本按段落读。
2. **主线派生**：识别章节标题（中英），按角色（title/background/method/result/limitation/conclusion）打分选取**原文逐字句子**作每页 claim；数字密度与 Figure/Table 引用加权结果页。
3. **页计划**：`slide_count`（题面给则遵守，否则 9）按比例分配角色页；每页 claim + bullets 均为材料原文**逐字子串**（分句/逗号分号切分，避开数字内逗号），页码、图号、数值不改写。
4. **构建**：在模板/起始 deck 的 `slideLayout` 上以 `p:ph` 占位符加页，母版/版式/主题字节不变；备注写入真实 `notesSlide` 部件。
5. **导出与复核**：LibreOffice 可用则真渲染 PDF，否则写标准库文本层 PDF（`%PDF-` 头 + 页对象，页数=slide_count）；PNG 用 `pdftoppm` 栅格化。

## 工作稿 schema（可选，非必需）

无工作稿时主脚本自动派生；如需人工干预，可放 `/app/work/plan.json`（`case_id/mode/title/pages[]`，每页 `n/role/title/claim/bullets/locator/quote/figure_refs`）。`build` 不读取外部 plan，而是独立重派生，保证单命令即可用；派生出的 `plan.json` 会写入 `/app/work/` 供复核。

## 证据规范（真实派生红线）

- 每页 `claim` 与每个 `bullet` 都是材料原文的**逐字子串**；`content_map.json` 逐页记录 `source.path` + `locator`（如 `m1#p3`）+ 逐字 `quote` + `verbatim_hit`。
- `quote_hit_rate` 机械比对（去空白、小写），目标 ≥0.95；页面数字/图号只来自原文，不生成"看起来像"的曲线，不把示意图当实验数据。
- `locator` 形如 `mN#pK`（块 K）、`mN#pgK#pJ`（PDF 第 K 页块 J）或 `mN#rowK`（表行）/`mN#t表名#rowK`（SQLite）/`mN#f路径`（JSON 叶子）；与 `index.json` 一致。

## 降级表

| 情况 | 处置 | 记录 |
|---|---|---|
| 无模板 | 用包内默认学术模板 | `degradations` |
| 无 LibreOffice | 标准库文本层 PDF：Latin 用 Helvetica，CJK 嵌入系统 TrueType（Identity-H + ToUnicode，长句换行）；找不到 CJK 字体才退预定义 STSong | `degradations` |
| 无 pdftoppm | 只交 PDF 预览，不伪造 PNG | `degradations` |
| PDF 为扫描/CID 无文字层 | 抽取失败则 `insufficient_evidence`，不编造 | `status` |
| 空 `/input` / 无 case.json | `status=input_error` + 最小合法 result.json | `errors` |
| case.json 坏 JSON | `status=input_error` | `errors` |
| 缺材料 | `status=insufficient_evidence` + gaps | `uncertainty` |
| 模板/起始 deck 打不开 | 用包内默认模板重建 | `degradations` |
| 页数超限 | 先删支撑细节页，保留主线页 | `coverage` |

任何异常都先写 partial `result.json` 再增量 finalize，退出码恒 0。

## 自检

- `python3 scripts/main.py`（默认）后：`result.json` 合法且回填 `output_contract` 每个键（非 null）+ `case_id/status/sources/uncertainty/changes`。
- `presentation.pptx` 可解压、含 `ppt/presentation.xml`、每页挂 slideLayout；`presentation.pdf` 有 `%PDF-` 头且页数=slide_count。
- 两次全新输出目录产物结构一致（无时间戳/随机；zip 固定时间戳，文本层 PDF 无 CreationDate）。
- 空/坏/缺三态各自退出 0 且 result.json 契约键齐全。

## 限制

- 不重绘论文图表，只保留图号与图注文字（图引用以 `figure_refs` + 逐字 quote 呈现）。
- 标准库 PDF 兜底嵌入系统 CJK TrueType（Windows simhei/msyh、Linux Noto/WQY/Droid），中日韩文本与数字单位均可读；系统无可用 CJK 字体时退预定义 STSong-Light，少数查看器可能缺字形（可编辑源 pptx 文本始终完整正确）。
- 不判断科学结论对错，只保证可回溯；扫描版 PDF 需 OCR 工具另行处理。
- 模板要求：`.pptx`/`.potx` 且至少含一个带标题占位符的 `slideLayout`；edit 模式在起始 deck 的既有版式上重建页面并记录逐页 before/after sha256。

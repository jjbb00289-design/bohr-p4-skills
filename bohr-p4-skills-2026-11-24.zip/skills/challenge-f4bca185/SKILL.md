---
name: clean-standardize
description: 文献数据清洗与标准化 — 把文献抽取记录按带编号、带优先级、可复算的规则库清洗成可统计的数据表。无 draft 时 build 自动执行 DERIVED_PATTERN 规则流水线（R0–R9）产出真实清洗表 + change_log.csv + cleaning_report.md；有 draft 时沿用 draft。每个改动保留 row/column + rule_id + before + after + formula；未知单位标 unit_unresolved 不猜不丢；条件列不同的行绝不合并；缺失不插补。交付 cleaned_data.csv、change_log.csv、change_records.csv、rules_applied.json、duplicate_groups.json、anomaly_report.md、provenance.json、cleaning_report.md、result.json。
version: 1.1.0
---

# clean-standardize（文献数据清洗与标准化）

## 1. 用途与适用条件

**用途**：围绕一批真实文献抽取记录，端到端清洗与标准化，并同时交出变更记录与待确认清单（不是只演示一段单位换算）：

| 产物 | 文件 | 内容 |
|---|---|---|
| 清洗后数据表 | `cleaned_data.csv` | row_id + 规范字段 + status + flags + duplicate_of |
| 可复算变更记录 | `change_log.csv` | row/column + rule_id + before + after + formula + note + source_locator |
| 兼容变更记录 | `change_records.csv` | row_id/field/original_value/cleaned_value/rule_id/reason/source_locator |
| 规则清单 | `rules_applied.json` | rule_id/priority/action/description/formula/applied_count |
| 重复组 | `duplicate_groups.json` | 判定键、行集合、决策（merge/keep_separate）、理由、条件维度 |
| 异常报告 | `anomaly_report.md` | 缺失、未知单位、冲突、待确认清单 |
| 清洗报告 | `cleaning_report.md` | 规则表、计数、重复决策、不变量说明 |
| 来源追溯 | `provenance.json` | 每行 → 源文件/源行号/字段映射/所用规则 |
| 结构化结果 | `result.json` | counts/rules_applied/duplicates/claims/coverage + 契约键原样回填 |

**适用**：CSV/TSV/Markdown 表/JSON 行的抽取记录标准化、单位归一、重复检测、异常与来源追溯。
**不适用**：需要联网核对原文、统计建模、需要人工判定学科口径的复杂冲突（标 pending_review）。

## 2. 五命令主路径

```bash
python scripts/main.py init      # 解析 /input 抽取记录，写 work/index.json + partial result.json
python scripts/main.py show --records
python scripts/main.py extract   # 数字/单位/缺失/重复候选（带 row_id）
# 可选：Agent 读规则材料后写 work/draft.json
python scripts/main.py check     # 校验 draft 的行覆盖/规则引用/原值可回溯/字段映射
python scripts/main.py build     # 产出全部清洗产物 + result.json（无 draft 走 DERIVED_PATTERN）
```

所有子命令支持 `--input/--work/--output`（默认 `/input`、`/app/work`、`/app/output`），退出码恒 0。

## 3. DERIVED_PATTERN（无 draft 的确定性派生，核心改进）

`build` 检查 `work/draft.json`（或 `--draft`）。若 draft **不可用**（不存在、非 dict、`rows` 为空），不输出空脚手架，而是直接对 /input 原始抽取表执行确定性规则流水线，产出真实清洗表 + 可审计 change_log。draft 可用时优先用 draft（`mode=draft`）。

派生流水线载入 CSV/TSV/Markdown 表/JSON 行，**确定性**地嗅探分隔符与表头（不依赖 CWD、无随机、无时间戳）。

## 4. 编号规则库（按 priority 升序执行）

每个规则有 `rule_id`、`priority`、`description`、可复算 `formula`：

| priority | rule | 动作 | 说明 | 复算公式 |
|---|---|---|---|---|
| 0 | R0 | recode | 已知字段名同义映射到规范名；未知名保留原样（不猜） | `canonical_column_name(header)` |
| 1 | R1 | normalize | 去首尾空白/换行、NFKC、折叠空格 | `norm_text(cell)` |
| 2 | R2 | normalize | 千分位/小数点确定性统一：`1,360→1360`、`12,3→12.3`、`0,123→0.123` | `normalize_separators(token)` |
| 3 | R3 | split | 拆分 value+unit 混合单元格（仅当数值部分为干净数字） | `split_value_unit(cell)` |
| 4 | R4 | normalize | 仅归一**已知**单位写法（`mV/dec→mV dec-1`、`cm^2→cm2`、`degC→°C`），从不猜 | `KNOWN_UNIT_ALIASES.get(unit.lower(), unit)` |
| 5 | R5 | flag | 未知单位标 `unit_unresolved` + 说明；**保留原值，不发明单位、不丢弃单元格** | `if canonical is None: flag('unit_unresolved')` |
| 6 | R6 | flag | 同身份键的重复行与冲突值标出 | `dup_key = tuple(sorted((f, comparable(cell)) ...))` |
| 7 | R7 | merge | **条件列不同的行绝不合并**；仅条件相同且数值全等的精确重复才合并 | `merge iff condition_subset identical AND values equal` |
| 8 | R8 | convert | 数字/日期格式确定性转换（`1.2E3→1200`、`2023/1/2→2023-01-02`） | `fmt_value(cell)` |
| 9 | R9 | flag | 空值单元格标 `missing`，保持空缺，绝不插补 | `if cell == '': flag('missing')` |

说明：R8 在重复比较前应用（使 `1.2E3` 与 `1200` 判等），但其 rule_id/priority 仍为 R8/8；这是唯一一处为正确比较而提前执行的无冲突规则。

## 5. 变更记录的可复算性

`change_log.csv` 每行 = `row,column,rule_id,before,after,formula,note,source_locator`：
- `row` 是行定位（`rN` 或 `header`），`column` 是列定位；
- `before`/`after` 是前后值；`formula` 是**精确变换**（如 `strip()`、`normalize_separators("12,3")`、`split_value_unit("12.3 %")`、`KNOWN_UNIT_ALIASES["mv/dec"]`、`fmt_value("1.2E3")`）；
- 第二个人可只凭 `change_log.csv` 复核或重放每一步；`source_locator` 指回输入文件与行号。

## 6. 未知单位与条件维度（硬约束）

- **未知单位**：R5 标 `unit_unresolved`，单元格保留原值并写 note，进入 `anomaly_report.md` 与 `pending_review`；**不发明单位、不丢弃单元格**。
- **不同条件行**：R7 保证条件列不同的行**绝不合并**，作为独立行保留；`duplicate_groups.json` 记 `decision=keep_separate` 并写出 `condition_dimension`。
- **缺失不插补**：R9 标 `missing`，单元格保持空缺。

## 7. result.json 契约

根字段 `case_id,status,result,counts,rules_applied,duplicates,claims,coverage,cleaned_data,change_records,rules,provenance,anomalies,uncertainty,pending_human,sources`；`/input/case.json` 的 `output_contract` 每个键**原样回填**，`case_id` 保持输入值。`result` 内含 deliverables/counts/rules/rules_applied/duplicates/field_mapping/unmapped_fields/coverage/gaps/notes。

## 8. 降级与异常（exit 0 优先）

| 情况 | 行为 |
|---|---|
| case.json 缺失/坏 | `input_error` + errors，仍写合法 result.json |
| 无材料/无表格 | `input_error` + pending_human 说明缺什么 |
| 无可用 draft | 自动 DERIVED_PATTERN 派生（`mode=derive`，status=ok） |
| 单位无法识别 | R5 标 `unit_unresolved`，保留原值不猜 |
| 同键冲突/条件不同 | `keep_separate`，不强行合并 |
| 空表/编码错乱 | 记录 notes，仍产出合法 result.json 与空表头 |

## 9. 提交前自检

- [ ] `py -3 scripts/main.py --help` exit 0，`ast.parse` 通过
- [ ] 无 draft：init→build 产出 cleaned_data.csv + change_log.csv，每个 change 有 rule_id+before+after+formula
- [ ] 未知单位 flagged 不猜；条件不同行保持分离
- [ ] 两遍 build 的 result.json 逐字节一致
- [ ] 包内无 `__pycache__`/`.pyc`

## 10. 最小示例（示例，非正式案例结果）

```bash
python scripts/main.py init --input ./localtest/input --work w --output o
python scripts/main.py build --input ./localtest/input --work w --output o
# o/cleaned_data.csv, o/change_log.csv, o/change_records.csv, o/cleaning_report.md ...
```

完整示例见 `references/example.md`。

## 11. 限制、版本与维护

- 版本 1.1.0（2026-11）。纯标准库、不联网、CWD 无关、退出码恒 0、确定性输出。
- 字段/单位/同义词只做**已知映射**，从不猜测未知项；未识别项进入待确认清单。
- 派生路径保守合并：仅条件相同、数值全等的精确重复合并；跨论文/不同物质不自动合并（交给 draft 或人工）。

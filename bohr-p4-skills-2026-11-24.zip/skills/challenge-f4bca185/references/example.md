# 最小调用示例（示例，非正式案例结果）

> 合成测试案例，**不是**平台正式案例，**不得**当作正式结果提交。

## 1. 输入

```
input/
  case.json                            # case_id "syn-f4bca-01"；output_contract 16 键
  materials/extraction_records.csv     # 抽取记录（含重复、缺失、越界、单位混写）
  materials/unit-rules.md              # 允许单位 / 换算因子 / 数值范围 / 行身份
  materials/field-dictionary.md        # 源字段 → 规范字段 + 同义词
```

## 2. 无 draft 的 DERIVED_PATTERN 调用

```bash
python scripts/main.py init --input ./localtest/input --work w --output o
python scripts/main.py build --input ./localtest/input --work w --output o
```

`build` 无 draft 时自动派生（`mode=derive`）：

`o/change_log.csv`（节选，示意）：

```csv
row,column,rule_id,before,after,formula,note,source_locator
r2,value,R2,78,78,normalize_separators("78"),thousands/decimal separator unification,...
r4,unit,R4,mV/dec,mV dec-1,KNOWN_UNIT_ALIASES["mv/dec"],known unit spelling normalization only,...
```

`o/cleaned_data.csv`（节选）：

```csv
row_id,paper_id,catalyst,metric,value,unit,condition,notes,status,flags,duplicate_of
r1,P1,NiCo2O4,overpotential,1.36,V,1 M KOH + 0.33 M urea,,ok,,
r4,P2,NiCo2O4-350,tafel_slope,78,mV dec-1,1 M KOH,duplicate extraction,changed,,
```

`o/duplicate_groups.json`（不同条件行保持分离的示意）：

```json
{"groups": [{"group_id": "D1", "row_ids": ["r2", "r5"],
             "decision": "keep_separate",
             "reason": "condition columns differ across rows; never merged (R7)",
             "condition_dimension": ["condition=1 M KOH", "condition=1 M KOH + 0.33 M urea"]}]}
```

`o/cleaning_report.md`：规则优先级表、计数、重复决策、未知单位/冲突/缺失、不变量说明。

## 3. 会被 check 拦住的反例（有 draft 时）

- 变更 `from` 写成输入里没有的值 → `change_original`。
- 变更引用不存在的规则 → `change_rule`。
- 漏掉一行 → `row_coverage`。
- 字段没映射也没声明 → `field_mapping`。
- 重复组只有 1 行 / 一行进两个组 → `duplicate_group` / `duplicate_reuse`。
- 给缺失值填 0 → 自查按「插补」判失败。

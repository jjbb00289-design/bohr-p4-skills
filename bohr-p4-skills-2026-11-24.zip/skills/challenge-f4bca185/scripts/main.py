#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""clean-standardize -- literature data cleaning and standardization (v2).

Commands: init | show | extract | check | build

Flow:
    init    -> parse /input extraction records, write work/index.json + partial result.json
    show    -> inspect materials / parsed records
    extract -> harvest number/unit/missing/duplicate candidates
    check   -> validate a work/draft.json against the input records
    build   -> render cleaned_data.csv + change_log.csv + change_records.csv +
               rules_applied.json + duplicate_groups.json + anomaly_report.md +
               provenance.json + cleaning_report.md + result.json

DERIVED_PATTERN: when no usable work/draft.json exists, `build` runs the deterministic
rule pipeline (R0..R9) in scripts/clean_rules.py so init -> build still yields a real
cleaned table with an auditable change_log.  A valid agent draft is used when present.
"""
import csv
import io
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import core as K  # noqa: E402
import clean_rules as CR  # noqa: E402

NAME = CR.NAME
VERSION = CR.VERSION
FILES = {
    "cleaned_data": "cleaned_data.csv",
    "change_records": "change_records.csv",
    "change_log": "change_log.csv",
    "rules_applied": "rules_applied.json",
    "duplicates": "duplicate_groups.json",
    "anomalies": "anomaly_report.md",
    "provenance": "provenance.json",
    "cleaning_report": "cleaning_report.md",
}
ARTIFACT_MAP = {
    "cleaned_data": "cleaned_data.csv", "cleaneddata": "cleaned_data.csv",
    "change_records": "change_records.csv", "changerecords": "change_records.csv",
    "change_log": "change_log.csv", "changelog": "change_log.csv",
    "rules_applied": "rules_applied.json", "rulesapplied": "rules_applied.json",
    "duplicates": "duplicate_groups.json", "duplicate_groups": "duplicate_groups.json",
    "anomalies": "anomaly_report.md", "anomaly_report": "anomaly_report.md",
    "provenance": "provenance.json", "cleaning_report": "cleaning_report.md",
}


# ------------------------------------------------------------------ record loading
def _parse_delimited(text, delim):
    reader = csv.DictReader(io.StringIO(text), delimiter=delim)
    rows = []
    for raw in reader:
        cleaned = {}
        has = False
        for key, value in raw.items():
            k = str(key).strip() if key is not None else ""
            v = "" if value is None else str(value).strip()
            if k:
                cleaned[k] = v
            if v:
                has = True
        if has:
            rows.append(cleaned)
    return rows


def _parse_markdown_table(text):
    table_lines = [ln.strip() for ln in text.splitlines()
                   if ln.strip().startswith("|") and ln.strip().endswith("|")]
    if len(table_lines) < 2:
        return []

    def cells(line):
        return [c.strip() for c in line.strip().strip("|").split("|")]

    header = cells(table_lines[0])
    body = table_lines[1:]
    if body and re.fullmatch(r"[\s:\-|]+", body[0]):
        body = body[1:]
    rows = []
    for line in body:
        cs = cells(line)
        if any(cs):
            cs = cs + [""] * max(0, len(header) - len(cs))
            rows.append(dict(zip(header, cs)))
    return rows


def _sniff_delim(first_line):
    best, best_n = ",", -1
    for d in ("\t", ";", ",", "|"):
        n = first_line.count(d)
        if n > best_n:
            best, best_n = d, n
    return best


def load_records(input_dir, materials, work=None):
    """Parse tabular extraction records.  Primary sources are csv/tsv/json; markdown
    tables are used only when no csv/tsv/json rows were found (so a field-dictionary.md
    or unit-rules.md next to a real extraction csv is not mistaken for the dataset)."""
    records, notes = [], []

    def append_rows(rows, mat):
        for idx, row in enumerate(rows, start=1):
            records.append({"row_id": "r%d" % (len(records) + 1),
                            "source_path": mat.get("path", ""),
                            "source_row": idx + 1, "original": row})

    for mat in materials:
        path = Path(input_dir) / mat.get("path", "")
        kind = (mat.get("kind") or "").lower()
        text = mat.get("_text") or ""
        if not text:
            try:
                text = path.read_text(encoding="utf-8-sig", errors="replace")
            except Exception:
                text = ""
        rows = []
        if kind == "json" or path.suffix.lower() in (".json", ".jsonl"):
            obj = K.jload(path, None)
            if isinstance(obj, list) and obj and isinstance(obj[0], dict):
                rows = [{str(k): ("" if v is None else str(v)) for k, v in item.items()}
                        for item in obj]
            elif isinstance(obj, dict):
                for key in ("rows", "records", "data", "items", "extractions"):
                    value = obj.get(key)
                    if isinstance(value, list) and value and isinstance(value[0], dict):
                        rows = [{str(k): ("" if v is None else str(v)) for k, v in item.items()}
                                for item in value]
                        break
        elif kind in ("csv", "tsv"):
            if text.strip():
                first = next((ln for ln in text.splitlines() if ln.strip()), "")
                try:
                    rows = _parse_delimited(text, _sniff_delim(first))
                except Exception as exc:
                    notes.append("could not parse %s: %s" % (mat.get("path"), exc))
        if rows:
            append_rows(rows, mat)

    if not records:
        for mat in materials:
            text = mat.get("_text") or ""
            if not text:
                try:
                    text = (Path(input_dir) / mat.get("path", "")).read_text(
                        encoding="utf-8-sig", errors="replace")
                except Exception:
                    text = ""
            rows = _parse_markdown_table(text) if "|" in text and "\n" in text else []
            if rows:
                append_rows(rows, mat)
        if records:
            notes.append("records parsed from markdown tables in materials")
    if not records and work is not None:
        records = records_from_segments(work, materials)
        if records:
            notes.append("records parsed from markdown tables in material segments")
    if not records:
        notes.append("no tabular extraction records found (looked for csv/tsv/json/"
                     "markdown tables)")
    return records, notes


def records_from_segments(work, materials):
    records = []
    for mat in materials:
        segs = (K.jload(Path(work) / "segments" / (mat["material_id"] + ".json"), {})
                or {}).get("segments") or []
        block = []
        for seg in segs + [{"text": ""}]:
            lines = [ln.strip() for ln in (seg.get("text") or "").split("\n")]
            table_lines = [ln for ln in lines if ln.startswith("|") and ln.endswith("|")]
            if table_lines:
                block.extend(table_lines)
                continue
            if block:
                rows = _parse_markdown_table("\n".join(block))
                for idx, row in enumerate(rows, start=1):
                    records.append({"row_id": "r%d" % (len(records) + 1),
                                    "source_path": mat.get("path", ""),
                                    "source_row": idx + 1, "original": row})
                block = []
    return records


def build_index(args):
    case = K.jload(Path(args.input) / "case.json", None)
    case = case if isinstance(case, dict) else {}
    materials, notes = K.discover(args.input)
    work = Path(args.work)
    for mat in materials:
        segments = K.segment_document(mat.get("_text") or "", mat)
        try:
            K.jdump(work / "segments" / (mat["material_id"] + ".json"),
                    {"material_id": mat["material_id"], "path": mat["path"],
                     "segments": segments})
        except Exception:
            notes.append("could not persist segments for %s" % mat.get("path"))
    records, rnotes = load_records(args.input, materials, work)
    notes.extend(rnotes)
    if not records:
        records = records_from_segments(work, materials)
        if records:
            notes.append("records parsed from markdown tables in materials")
    fields = []
    for rec in records:
        for key in rec["original"]:
            if key and key not in fields:
                fields.append(key)
    index = {"skill": NAME, "version": VERSION,
             "case_id": str(case.get("case_id") or case.get("id") or ""),
             "materials": [{k: v for k, v in m.items() if not k.startswith("_")}
                           for m in materials],
             "records": records, "fields": fields,
             "counts": {"materials": len(materials), "records": len(records),
                        "fields": len(fields)},
             "notes": notes}
    K.jdump(work / "records.json", records)
    K.jdump(work / "index.json", index)
    return case, materials, index, notes


def init_payload(index, notes):
    records = index.get("records") or []
    payload = K.base_envelope(index.get("case_id", ""), "partial",
                              degradations=list(notes) + [
                                  "init scaffold written; run build (no draft -> "
                                  "DERIVED_PATTERN rule pipeline)"])
    payload.update({
        "deliverable": "", "cleaned_data": "", "change_records": "", "change_log": "",
        "cleaning_report": "", "rules_applied": [], "rules": [], "duplicates": [],
        "anomalies": [], "claims": [], "field_mapping": [], "rows": [],
        "coverage": {"input_rows": len(records), "output_rows": 0, "rows_accounted": 0,
                     "fields_total": len(index.get("fields") or []), "fields_mapped": 0,
                     "rules": 0, "duplicate_groups": 0, "pending_review": 0},
        "counts": {"input_rows": len(records), "output_rows": 0, "changed_values": 0,
                   "pending_review": 0, "duplicates_merged": 0, "anomalies": 0,
                   "dropped_rows": 0, "rules": 0, "duplicate_groups": 0},
        "result": {"deliverables": {}, "counts": {}, "rules": [], "rules_applied": [],
                   "duplicates": [], "fields": index.get("fields") or []},
        "sources": K.sources_from(index),
        "pending_human": [], "uncertainty": [], "uncertainties": [],
        "skill": {"name": NAME, "version": VERSION},
        "_artifact_map": ARTIFACT_MAP,
    })
    return payload


# ------------------------------------------------------------------ commands
def cmd_init(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    case, materials, index, notes = build_index(args)
    status = "input_error" if not materials else "partial"
    payload = init_payload(index, notes)
    payload["status"] = status
    if not materials:
        payload["errors"].append("no input materials discovered")
    K.finalize_result(out, payload, case.get("output_contract"), index.get("case_id"))
    print(json.dumps({"ok": True, "command": "init", "case_id": index["case_id"],
                      "status": status, "counts": index["counts"],
                      "fields": index.get("fields"),
                      "materials": [{"material_id": m["material_id"], "path": m["path"],
                                     "kind": m["kind"]} for m in materials],
                      "next": "build (or write work/draft.json then check && build)"},
                     ensure_ascii=False, indent=2))
    return 0


def cmd_show(args):
    work = Path(args.work)
    index = K.jload(work / "index.json", {}) or {}
    if args.records:
        rows = index.get("records") or []
        if args.limit:
            rows = rows[: args.limit]
        print(json.dumps({"fields": index.get("fields"),
                          "count": len(index.get("records") or []), "records": rows},
                         ensure_ascii=False, indent=2))
        return 0
    if not args.material:
        print(json.dumps({"case_id": index.get("case_id"), "counts": index.get("counts"),
                          "fields": index.get("fields"),
                          "materials": [{k: m.get(k) for k in ("material_id", "path", "kind",
                                                                "bytes", "text_chars")}
                                        for m in index.get("materials", [])]},
                         ensure_ascii=False, indent=2))
        return 0
    target = next((m for m in index.get("materials", [])
                   if m.get("material_id") == args.material), None)
    if not target:
        print(json.dumps({"error": "unknown material: %s" % args.material},
                         ensure_ascii=False))
        return 0
    segments = (K.jload(work / "segments" / (args.material + ".json"), {}) or {}).get(
        "segments") or []
    shown = 0
    for seg in segments:
        if args.grep and not re.search(args.grep, seg.get("text", ""), re.I):
            continue
        print("=== [%s] %s" % (seg.get("locator"), target.get("path")))
        print(seg.get("text"))
        print()
        shown += 1
        if args.limit and shown >= args.limit:
            break
    return 0


def cmd_extract(args):
    work = Path(args.work)
    index = K.jload(work / "index.json", {}) or {}
    records = index.get("records") or []
    harvest = {"numbers": [], "units": [], "fields": index.get("fields") or [],
               "duplicate_candidates": [], "missing_candidates": [], "rule_lines": []}
    seen = {}
    num_re = re.compile(r"([-+]?\d+(?:\.\d+)?)")
    for rec in records:
        original = rec.get("original") or {}
        for key, value in original.items():
            low = str(key).lower()
            if "unit" in low:
                harvest["units"].append({"row_id": rec["row_id"], "unit": value})
            for match in num_re.finditer(str(value)):
                harvest["numbers"].append({"row_id": rec["row_id"], "field": key,
                                           "value": match.group(1), "text": value})
            if str(value).strip() == "":
                harvest["missing_candidates"].append({"row_id": rec["row_id"],
                                                      "field": key})
        key_fields = [str(original.get(f, "")).strip().lower()
                      for f in ("paper_id", "compound", "metric", "condition")]
        key = "|".join(key_fields)
        if key.strip("|"):
            if key in seen:
                harvest["duplicate_candidates"].append(
                    {"row_ids": [seen[key], rec["row_id"]], "key": key})
            else:
                seen[key] = rec["row_id"]
    for mat in index.get("materials") or []:
        segments = (K.jload(work / "segments" / (mat["material_id"] + ".json"), {})
                    or {}).get("segments") or []
        for seg in segments:
            text = seg.get("text") or ""
            if re.search(r"(rule|单位|换算|范围|unit|range|allowed)", text, re.I) \
                    and len(text) < 400:
                harvest["rule_lines"].append({"locator": seg.get("locator"),
                                              "text": text, "source": mat.get("path")})
    harvest["units"] = harvest["units"][:80]
    K.jdump(work / "candidates.json", harvest)
    print(json.dumps({"ok": True, "command": "extract",
                      "saved_to": str(work / "candidates.json"),
                      "counts": {k: len(v) for k, v in harvest.items()},
                      "duplicate_candidates": harvest["duplicate_candidates"],
                      "missing_candidates": harvest["missing_candidates"][:10]},
                     ensure_ascii=False, indent=2))
    return 0


def _load_draft(args):
    path = Path(args.draft) if getattr(args, "draft", None) else Path(args.work) / "draft.json"
    draft = K.jload(path, None)
    return (draft if isinstance(draft, dict) else None), str(path)


def cmd_check(args):
    work = Path(args.work)
    index = K.jload(work / "index.json", {}) or {}
    if not index:
        index = {"materials": [], "records": [], "fields": [], "case_id": ""}
    draft, path = _load_draft(args)
    report = CR.check_draft(index, draft)
    report["draft_path"] = path
    K.jdump(work / "check_report.json", report)
    print(json.dumps({"passed": report["passed"],
                      "fail_count": len(report["fails"]),
                      "warning_count": len(report["warnings"]),
                      "counts": report.get("counts"), "fails": report["fails"],
                      "warnings": report["warnings"]}, ensure_ascii=False, indent=2))
    return 0


def cmd_build(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    errors, degradations = [], []
    index = K.jload(work / "index.json", {}) or {}
    if not index:
        degradations.append("index.json absent; running init implicitly")
        try:
            case, _m, index, notes = build_index(args)
            degradations.extend(notes)
        except Exception as exc:
            errors.append("implicit init failed: %s" % exc)
            index = {"materials": [], "records": [], "fields": [], "case_id": ""}
    case = K.jload(Path(args.input) / "case.json", {}) or {}
    case = case if isinstance(case, dict) else {}
    records = index.get("records") or []
    input_fields = index.get("fields") or []
    draft, draft_path = _load_draft(args)
    if CR.usable_draft(draft):
        bundle = CR.build_from_draft(index, draft)
        report = CR.check_draft(index, draft)
    else:
        if draft is not None:
            degradations.append("draft at %s is not usable; applying DERIVED_PATTERN"
                                % draft_path)
        bundle = CR.derive(records, input_fields)
        report = {"passed": True, "fails": [], "warnings": [], "counts": bundle["counts"]}
    degradations.extend(bundle.get("degradations") or [])
    deliverables = CR.write_artifacts(out, bundle)
    status = "ok"
    if not (index.get("materials") or []):
        status = "input_error"
        errors.append("no input materials discovered")
    if not records:
        status = "input_error" if status == "ok" else status
    if report.get("fails"):
        status = "partial" if status == "ok" else status
        degradations.append("%d check failure(s); see check_report.json"
                            % len(report["fails"]))
    payload = K.base_envelope(index.get("case_id", ""), status, errors, degradations)
    payload.update({
        "deliverable": deliverables.get("cleaned_data", ""),
        "cleaned_data": deliverables.get("cleaned_data", ""),
        "change_records": deliverables.get("change_records", ""),
        "change_log": deliverables.get("change_log", ""),
        "cleaning_report": deliverables.get("cleaning_report", ""),
        "rules_applied": bundle["rules_applied"],
        "rules": bundle["rules"],
        "duplicates": bundle["duplicates"],
        "anomalies": bundle["anomalies"],
        "provenance": deliverables.get("provenance", ""),
        "counts": bundle["counts"],
        "coverage": bundle["coverage"],
        "claims": bundle["claims"],
        "field_mapping": bundle["field_mapping"],
        "rows": bundle["cleaned_rows"],
        "result": {"deliverables": deliverables, "counts": bundle["counts"],
                   "rules_applied": bundle["rules_applied"], "rules": bundle["rules"],
                   "duplicates": bundle["duplicates"],
                   "field_mapping": bundle["field_mapping"],
                   "unmapped_fields": bundle["unmapped_fields"],
                   "coverage": bundle["coverage"], "gaps": bundle["gaps"],
                   "notes": bundle["notes"]},
        "sources": K.sources_from(index),
        "pending_human": bundle["pending_human"],
        "uncertainty": bundle["uncertainties"],
        "uncertainties": bundle["uncertainties"],
        "self_check": {"passed": report.get("passed"),
                       "fail_count": len(report.get("fails") or []),
                       "counts": report.get("counts")},
        "changes": [{"type": "build",
                     "detail": "wrote %d deliverable(s)" % len(deliverables)}],
        "deliverables": deliverables,
        "skill": {"name": NAME, "version": VERSION},
        "_artifact_map": ARTIFACT_MAP,
    })
    final = K.finalize_result(out, payload, case.get("output_contract"),
                              index.get("case_id"))
    print(json.dumps({"ok": True, "command": "build", "status": status,
                      "case_id": final.get("case_id"), "deliverables": deliverables,
                      "counts": bundle["counts"], "check_passed": report.get("passed"),
                      "check_fails": report.get("fails"), "errors": errors,
                      "degradations": degradations}, ensure_ascii=False, indent=2))
    return 0


# ------------------------------------------------------------------ cli
def main(argv):
    handlers = {
        "init": {"run": cmd_init, "help": "load extraction records and write a partial result.json"},
        "show": {"run": cmd_show, "help": "print materials or parsed records",
                 "options": {"--material": {"default": None, "help": "material id"},
                             "--records": {"action": "store_true",
                                           "help": "print parsed records"},
                             "--grep": {"default": None, "help": "regex filter"},
                             "--limit": {"type": int, "default": 0, "help": "max items"}}},
        "extract": {"run": cmd_extract,
                    "help": "harvest numbers/units/duplicates/missing candidates"},
        "check": {"run": cmd_check, "help": "validate work/draft.json against input records",
                  "options": {"--draft": {"default": None, "help": "draft path"}}},
        "build": {"run": cmd_build,
                  "help": "render cleaned csv, change_log, rules, duplicates, reports",
                  "options": {"--draft": {"default": None, "help": "draft path"}}},
    }
    return K.run_cli(NAME, handlers, argv,
                     "Literature data cleaning and standardization. Flow: init -> build "
                     "(no draft -> DERIVED_PATTERN) or init -> draft -> check -> build.")


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except Exception:
        import traceback
        try:
            sys.stderr.write(traceback.format_exc())
        except Exception:
            pass
    sys.exit(0)

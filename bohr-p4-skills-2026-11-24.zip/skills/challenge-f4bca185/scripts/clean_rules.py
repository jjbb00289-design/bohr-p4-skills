#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""DERIVED, deterministic cleaning pipeline for clean-standardize.

This module is the "no usable draft" fallback: it turns raw extraction rows into a
genuinely cleaned table without any model-written draft.  The agent draft path in
main.py keeps priority when a usable work/draft.json is present.

Guarantees:
  * stdlib only, no network, no timestamps/random -> two fresh builds are identical.
  * every changed cell is a recomputable quadruple (locator, rule_id, before, after,
    formula) written to change_log.csv; nothing is changed without a rule.
  * unknown units are flagged ``unit_unresolved`` and NEVER guessed or dropped.
  * rows that differ in a condition column are NEVER merged (R7).
"""
import json
import re
import unicodedata
from decimal import Decimal, InvalidOperation

NAME = "clean-standardize"
VERSION = "1.1.0"

# --------------------------------------------------------------------------- rules
# rule_id, priority (lower runs first), action, field, description, formula, source.
RULES = [
    {"rule_id": "R0", "priority": 0, "action": "recode", "field": "header",
     "description": "map known field-name synonyms to canonical names; unknown headers are kept as-is (never guessed)",
     "formula": "canonical_column_name(header)",
     "source": "DERIVED_PATTERN"},
    {"rule_id": "R1", "priority": 1, "action": "normalize", "field": "all",
     "description": "trim whitespace and normalize line endings (NFKC + strip + collapse spaces)",
     "formula": "norm_text(cell)",
     "source": "DERIVED_PATTERN"},
    {"rule_id": "R2", "priority": 2, "action": "normalize", "field": "value",
     "description": "unify thousands/decimal separators deterministically (1,360 -> 1360; 12,3 -> 12.3; 0,123 -> 0.123)",
     "formula": "apply_separators(cell)",
     "source": "DERIVED_PATTERN"},
    {"rule_id": "R3", "priority": 3, "action": "split", "field": "value/unit",
     "description": "split combined value+unit cells (e.g. '12.3 %') only when the numeric part is a clean number",
     "formula": "split_value_unit(cell)",
     "source": "DERIVED_PATTERN"},
    {"rule_id": "R4", "priority": 4, "action": "normalize", "field": "unit",
     "description": "normalize KNOWN unit spellings only (mV/dec -> mV dec-1, cm^2 -> cm2, degC -> degC alias table); never guess",
     "formula": "KNOWN_UNIT_ALIASES.get(unit.lower(), unit)",
     "source": "DERIVED_PATTERN"},
    {"rule_id": "R5", "priority": 5, "action": "flag", "field": "unit",
     "description": "flag unknown units as unit_unresolved with a note; the cell is kept verbatim, never invented and never dropped",
     "formula": "canonical = KNOWN_UNITS.lookup(unit); if canonical is None: flag('unit_unresolved')",
     "source": "DERIVED_PATTERN"},
    {"rule_id": "R6", "priority": 6, "action": "flag", "field": "row",
     "description": "flag duplicate rows and conflicting values for the same identity key",
     "formula": "dup_key = tuple(sorted((f, comparable(cell)) for f in dimension_columns))",
     "source": "DERIVED_PATTERN"},
    {"rule_id": "R7", "priority": 7, "action": "merge", "field": "row",
     "description": "NEVER merge rows that differ in condition columns; merge only exact duplicates with identical condition and identical value+unit cells",
     "formula": "merge iff condition_subset(row) identical AND value+unit cells comparable-equal",
     "source": "DERIVED_PATTERN"},
    {"rule_id": "R8", "priority": 8, "action": "convert", "field": "value",
     "description": "convert number/date formats deterministically (1.2E3 -> 1200, 2023/1/2 -> 2023-01-02)",
     "formula": "fmt_value(cell)",
     "source": "DERIVED_PATTERN"},
    {"rule_id": "R9", "priority": 9, "action": "flag", "field": "value",
     "description": "flag empty value cells as missing; they stay empty and are never imputed",
     "formula": "if cell == '': flag('missing')",
     "source": "DERIVED_PATTERN"},
]

# ------------------------------------------------------------------- known names
FIELD_SYNONYMS = {
    "paper_id": "paper_id", "paperid": "paper_id", "paper": "paper_id", "ref": "paper_id",
    "compound": "catalyst", "catalyst": "catalyst", "material": "catalyst", "sample": "catalyst",
    "metric": "metric", "indicator": "metric", "property": "metric", "measurement": "metric",
    "value": "value", "val": "value", "values": "value", "measured_value": "value",
    "result": "value", "reading": "value", "number": "value", "numeric": "value",
    "unit": "unit", "units": "unit", "uom": "unit", "unit_of_measure": "unit",
    "condition": "condition", "conditions": "condition", "medium": "condition",
    "electrolyte": "condition",
    "notes": "notes", "note": "notes", "remark": "notes", "comment": "notes",
    "source": "source", "source_row": "source_row", "doi": "doi", "title": "title",
}

VALUE_FIELD_NAMES = {
    "value", "val", "values", "measured_value", "measurement", "result", "reading",
    "number", "numeric", "reading_value", "数值", "值", "结果",
}
UNIT_FIELD_NAMES = {"unit", "units", "uom", "unit_of_measure", "unit_of_measurement", "单位"}
CONDITION_FIELD_NAMES = {
    "condition", "conditions", "medium", "electrolyte", "atmosphere", "temperature",
    "temp", "ph", "pressure", "scan_rate", "duration", "time", "concentration",
    "gas", "loading",
}
NOTE_FIELD_NAMES = {"notes", "note", "remark", "remarks", "comment", "comments", "annotation"}

# Canonical units are checked case-sensitively first so "M" (molar) is not folded to "m".
CANONICAL_UNITS = {
    "V", "mV", "kV", "MV", "A", "mA", "µA", "kA", "Ω", "mΩ", "kΩ",
    "Hz", "kHz", "MHz", "GHz", "g", "mg", "µg", "kg", "ng", "L", "mL", "µL",
    "m", "cm", "mm", "µm", "nm", "pm", "s", "ms", "µs", "ns", "ps", "min", "h",
    "day", "d", "K", "°C", "mol", "mmol", "µmol", "nmol", "pmol",
    "M", "mM", "µM", "nM", "pM", "%", "ppm", "ppb", "wt%", "mol%", "at%", "vol%",
    "Pa", "kPa", "MPa", "GPa", "J", "kJ", "MJ", "eV", "keV", "MeV", "W", "kW",
    "mW", "MW", "dB", "rpm", "g/cm3", "kg/m3", "mg/L", "g/L", "mL/min", "mg/kg",
    "mV dec-1", "mA cm-2", "cm2", "m2", "m2/g", "cm2/g",
}

# lower-case alias -> canonical.  Applied only when the exact case is not canonical.
KNOWN_UNIT_ALIASES = {
    "v": "V", "volt": "V", "volts": "V", "mv": "mV", "millivolt": "mV",
    "kv": "kV", "kilovolt": "kV", "a": "A", "ma": "mA", "milliamp": "mA",
    "ohm": "Ω", "ω": "Ω", "kω": "kΩ", "hz": "Hz", "khz": "kHz", "mhz": "MHz",
    "ghz": "GHz", "gram": "g", "grams": "g", "l": "L", "liter": "L", "litre": "L",
    "ml": "mL", "µl": "µL", "ul": "µL", "µm": "µm", "um": "µm", "ug": "µg",
    "sec": "s", "secs": "s", "second": "s", "seconds": "s", "minute": "min",
    "minutes": "min", "hr": "h", "hrs": "h", "hour": "h", "hours": "h",
    "day": "day", "days": "day", "k": "K", "kelvin": "K", "°c": "°C", "degc": "°C",
    "oc": "°C", "℃": "°C", "celsius": "°C", "percent": "%", "pct": "%",
    "percentage": "%", "pa": "Pa", "kpa": "kPa", "mpa": "MPa", "gpa": "GPa",
    "j": "J", "kj": "kJ", "ev": "eV", "kev": "keV", "mev": "MeV", "w": "W",
    "kw": "kW", "mw": "mW", "milliwatt": "mW", "db": "dB", "mv/dec": "mV dec-1",
    "mv dec-1": "mV dec-1", "mv/decade": "mV dec-1", "mv/dec⁻¹": "mV dec-1",
    "cm^2": "cm2", "cm²": "cm2", "g/cm³": "g/cm3", "kg/m³": "kg/m3", "mg/l": "mg/L",
    "g/l": "g/L", "ml/min": "mL/min",
}

NUMTOKEN_RE = re.compile(
    r"[-+]?\d[\d\s\u00a0.,]*\d(?:[eE][-+]?\d+)?|[-+]?\d(?:[eE][-+]?\d+)?")
PURE_NUM_RE = re.compile(r"[-+]?\d+(?:[.,]\d+)*(?:[eE][-+]?\d+)?$")
TRAILING_UNIT_RE = re.compile(
    r"^(.*?)[ \t]*([A-Za-zµμ°%Ω][A-Za-z0-9µμ°/^²³·⋅\-\u207b\u00b9\u00b2\u00b3Ω]*)$")


# --------------------------------------------------------------------- helpers
def norm_text(value):
    if value is None:
        return ""
    text = unicodedata.normalize("NFKC", str(value))
    text = text.replace("\u00a0", " ").replace("\r\n", "\n").replace("\r", "\n")
    return re.sub(r"[ \t]+", " ", text).strip()


def canonical_column_name(name):
    n = norm_text(name)
    key = n.lower().replace(" ", "_")
    return FIELD_SYNONYMS.get(key, FIELD_SYNONYMS.get(n.lower(), n))


def build_mapping(input_fields):
    mapping, used = [], set()
    for field in input_fields:
        canon = canonical_column_name(field)
        if canon in used and canon != field:
            canon = field
        used.add(canon)
        mapping.append({"source_field": field, "canonical_field": canon, "rule_id": "R0"})
    return mapping


def _normalize_separators(tok):
    t = tok
    if "," not in t and " " not in t and "\u00a0" not in t:
        return tok
    sign = ""
    if t[:1] in "+-":
        sign, t = t[:1], t[1:]
    t = t.replace(" ", "").replace("\u00a0", "")
    if "," in t and "." in t:
        if t.rfind(",") > t.rfind("."):
            t = t.replace(".", "").replace(",", ".")
        else:
            t = t.replace(",", "")
    elif "," in t:
        if re.fullmatch(r"\d{1,3}(?:,\d{3})+", t):
            t = t.replace(",", "")
        elif re.fullmatch(r"\d+,\d{1,2}", t):
            t = t.replace(",", ".")
        elif re.fullmatch(r"\d+,\d{3}", t):
            t = t.replace(",", ".") if t.split(",", 1)[0] == "0" else t.replace(",", "")
        else:
            t = t.replace(",", ".")
    return sign + t


def apply_separators(cell):
    return NUMTOKEN_RE.sub(lambda m: _normalize_separators(m.group(0)), cell)


def fmt_value(value):
    """Deterministic number/date format conversion (R8)."""
    v = norm_text(value)
    if not v:
        return v
    m = re.fullmatch(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})", v)
    if m:
        return "%04d-%02d-%02d" % (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    m = re.fullmatch(r"(\d{1,2})\.(\d{1,2})\.(\d{4})", v)
    if m and 1 <= int(m.group(1)) <= 31 and 1 <= int(m.group(2)) <= 12:
        return "%04d-%02d-%02d" % (int(m.group(3)), int(m.group(2)), int(m.group(1)))
    m = re.fullmatch(r"(\d{4})(\d{2})(\d{2})", v)
    if m and 1900 <= int(m.group(1)) <= 2099 and 1 <= int(m.group(2)) <= 12 \
            and 1 <= int(m.group(3)) <= 31:
        return "%04d-%02d-%02d" % (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    if re.fullmatch(r"[-+]?\d+(?:\.\d+)?[eE][-+]?\d+", v):
        try:
            s = format(Decimal(v), "f")
            if "." in s:
                s = s.rstrip("0").rstrip(".")
            if len(s) > 80:
                return v
            return s if s not in ("", "-0") else "0"
        except InvalidOperation:
            return v
    return v


def comparable(value):
    return fmt_value(norm_text(value))


def split_value_unit(cell):
    """Return (numeric_part, unit_token, ok). Pure number cells never split."""
    c = norm_text(cell)
    if not c or PURE_NUM_RE.match(c):
        return c, "", False
    m = TRAILING_UNIT_RE.match(c)
    if not m:
        return c, "", False
    num, unit = m.group(1).strip(), m.group(2)
    if not re.fullmatch(r"[-+]?\d[\d.,]*", num):
        return c, "", False
    if not any(ch.isdigit() for ch in num):
        return c, "", False
    return num, unit, True


def normalize_unit(unit):
    """Return (value, changed, canonical_or_None). canonical_or_None means unknown."""
    u = norm_text(unit)
    if not u:
        return u, False, ""
    if u in CANONICAL_UNITS:
        return u, False, u
    low = u.lower()
    if low in KNOWN_UNIT_ALIASES:
        canon = KNOWN_UNIT_ALIASES[low]
        return canon, canon != u, canon
    return u, False, None


def value_columns(fields):
    out = []
    for f in fields:
        low = f.lower()
        if low in VALUE_FIELD_NAMES or low.endswith("value") or low.startswith("value"):
            out.append(f)
    return out


def unit_column(fields):
    for f in fields:
        if f.lower() in UNIT_FIELD_NAMES:
            return f
    return None


def condition_columns(fields):
    return [f for f in fields if f.lower() in CONDITION_FIELD_NAMES
            or "condition" in f.lower() or "条件" in f]


# --------------------------------------------------------------------- derive
def derive(records, input_fields):
    """Deterministic R0..R9 pipeline over raw records.  Returns the full bundle."""
    logs, anomalies, notes, uncertainties, gaps = [], [], [], [], []
    mapping = build_mapping(input_fields)
    canon_of = {m["source_field"]: m["canonical_field"] for m in mapping}
    canonical_fields = []
    for m in mapping:
        if m["canonical_field"] not in canonical_fields:
            canonical_fields.append(m["canonical_field"])
    for m in mapping:
        if m["canonical_field"] != m["source_field"]:
            logs.append({"row": "header", "column": m["source_field"], "rule_id": "R0",
                         "before": m["source_field"], "after": m["canonical_field"],
                         "formula": 'canonical_column_name("%s")' % m["source_field"],
                         "note": "known synonym -> canonical; identity otherwise",
                         "source_locator": ""})

    vcols = value_columns(canonical_fields)
    ucol = unit_column(canonical_fields)
    ccols = condition_columns(canonical_fields)

    # If no unit column exists but some value cell embeds a unit, derive one (R3).
    if ucol is None:
        for rec in records:
            found = False
            for f in input_fields:
                if canon_of.get(f) not in vcols:
                    continue
                raw = norm_text((rec.get("original") or {}).get(f, ""))
                num, unit, ok = split_value_unit(apply_separators(raw))
                if ok and unit:
                    ucol = "unit"
                    found = True
                    break
            if found:
                break
        if ucol is not None:
            canonical_fields.append("unit")
            mapping.append({"source_field": "(derived)", "canonical_field": "unit",
                            "rule_id": "R3"})
            notes.append("no unit column found; derived 'unit' column by splitting "
                         "value+unit cells (R3)")

    source_by, cleaned, row_flags, row_changed, row_rules, duplicate_of = {}, {}, {}, {}, {}, {}
    order = []
    for rec in records:
        rid = rec["row_id"]
        order.append(rid)
        source_by[rid] = {"source_path": rec.get("source_path", ""),
                          "source_row": rec.get("source_row", "")}
        row_flags[rid] = []
        row_changed[rid] = False
        row_rules[rid] = set()
        values = {}
        # R1 + R0 field renaming
        for f in input_fields:
            canon = canon_of.get(f, f)
            raw = (rec.get("original") or {}).get(f, "")
            v1 = norm_text(raw)
            if v1 != raw:
                logs.append({"row": rid, "column": canon, "rule_id": "R1",
                             "before": raw, "after": v1,
                             "formula": "norm_text()",
                             "note": "trim / line-ending / whitespace normalization",
                             "source_locator": _locator(rec)})
                row_changed[rid] = True
                row_rules[rid].add("R1")
            values[canon] = v1
        if ucol is not None:
            values.setdefault(ucol, "")
        # R2 separators on value columns
        for c in vcols:
            v = values.get(c, "")
            if not v:
                continue
            v2 = apply_separators(v)
            if v2 != v:
                logs.append({"row": rid, "column": c, "rule_id": "R2",
                             "before": v, "after": v2,
                             "formula": 'apply_separators(%r)' % v,
                             "note": "thousands/decimal separator unification",
                             "source_locator": _locator(rec)})
                row_changed[rid] = True
                row_rules[rid].add("R2")
                values[c] = v2
        # R3 split value+unit
        if ucol is not None:
            for c in vcols:
                v = values.get(c, "")
                if not v:
                    continue
                num, unit, ok = split_value_unit(v)
                if not ok or not unit:
                    continue
                cur = values.get(ucol, "")
                if cur == "":
                    values[c] = num
                    values[ucol] = unit
                    logs.append({"row": rid, "column": c, "rule_id": "R3",
                                 "before": v, "after": num,
                                 "formula": 'split_value_unit(%r) == (%r, %r, True)'
                                 % (v, num, unit),
                                 "note": "value part of combined value+unit cell",
                                 "source_locator": _locator(rec)})
                    logs.append({"row": rid, "column": ucol, "rule_id": "R3",
                                 "before": "", "after": unit,
                                 "formula": 'split_value_unit(%r) == (%r, %r, True)'
                                 % (v, num, unit),
                                 "note": "unit part of combined value+unit cell",
                                 "source_locator": _locator(rec)})
                    row_changed[rid] = True
                    row_rules[rid].add("R3")
                elif norm_text(cur) == norm_text(unit):
                    values[c] = num
                    logs.append({"row": rid, "column": c, "rule_id": "R3",
                                 "before": v, "after": num,
                                 "formula": 'split_value_unit(%r) == (%r, %r, True)'
                                 % (v, num, unit),
                                 "note": "stripped trailing unit already present in unit column",
                                 "source_locator": _locator(rec)})
                    row_changed[rid] = True
                    row_rules[rid].add("R3")
                else:
                    anomalies.append({"row_id": rid, "field": c, "value": v,
                                      "kind": "conflict",
                                      "reason": "cell embeds unit '%s' but unit column says '%s'; "
                                                "left unchanged" % (unit, cur),
                                      "rule_id": "R3"})
                    row_flags[rid].append("conflict:%s" % c)
        # R4 unit spelling (known only)
        if ucol is not None:
            u = values.get(ucol, "")
            nu, changed_u, _canon = normalize_unit(u)
            if changed_u:
                logs.append({"row": rid, "column": ucol, "rule_id": "R4",
                             "before": u, "after": nu,
                             "formula": 'KNOWN_UNIT_ALIASES[%r]' % norm_text(u).lower(),
                             "note": "known unit spelling normalization only",
                             "source_locator": _locator(rec)})
                row_changed[rid] = True
                row_rules[rid].add("R4")
                values[ucol] = nu
        # R5 unknown unit
        if ucol is not None:
            u = values.get(ucol, "")
            if u:
                _v, _c, canon = normalize_unit(u)
                if canon is None:
                    row_flags[rid].append("unit_unresolved:%s" % ucol)
                    anomalies.append({"row_id": rid, "field": ucol, "value": u,
                                      "kind": "unit_unresolved",
                                      "reason": "unknown unit kept verbatim; not invented, "
                                                "not dropped, awaiting source confirmation",
                                      "rule_id": "R5"})
                    row_rules[rid].add("R5")
        # R8 value format (applied before duplicate comparison so 1.2E3 == 1200)
        for c in vcols:
            v = values.get(c, "")
            if not v:
                continue
            v8 = fmt_value(v)
            if v8 != v:
                logs.append({"row": rid, "column": c, "rule_id": "R8",
                             "before": v, "after": v8,
                             "formula": 'fmt_value(%r) == %r' % (v, v8),
                             "note": "deterministic number/date format conversion",
                             "source_locator": _locator(rec)})
                row_changed[rid] = True
                row_rules[rid].add("R8")
                values[c] = v8
        # R9 missing value
        for c in vcols:
            if values.get(c, "") == "":
                row_flags[rid].append("missing:%s" % c)
                anomalies.append({"row_id": rid, "field": c, "value": "",
                                  "kind": "missing",
                                  "reason": "value empty; kept empty, never imputed",
                                  "rule_id": "R9"})
                row_rules[rid].add("R9")
        cleaned[rid] = values

    # R6 + R7 duplicate / conflict / merge
    note_cols = {f for f in canonical_fields if f.lower() in NOTE_FIELD_NAMES}
    dim_cols = [f for f in canonical_fields if f not in vcols and f != ucol
                and f not in note_cols and f not in ccols
                and f not in ("row_id", "source_path", "source_row")]
    dim_groups = {}
    for rid in order:
        vals = cleaned[rid]
        dim = tuple((f, comparable(vals.get(f, ""))) for f in dim_cols)
        dim_groups.setdefault(dim, []).append(rid)

    duplicates = []
    condition_notes = []
    for dim, rids in dim_groups.items():
        if len(rids) < 2:
            continue
        cond_buckets = {}
        for rid in rids:
            ck = tuple((f, comparable(cleaned[rid].get(f, ""))) for f in ccols)
            cond_buckets.setdefault(ck, []).append(rid)
        if len(cond_buckets) > 1:
            condition_notes.append("rows %s share identity key [%s] but differ in "
                                   "condition columns [%s]; kept separate per R7"
                                   % (",".join(rids), _describe(dim),
                                      "; ".join(_describe(ck) for ck in cond_buckets)))
        for ck, rows in cond_buckets.items():
            if len(rows) < 2:
                continue
            gid = "D%d" % (len(duplicates) + 1)
            first = rows[0]
            conflict = False
            diff = []
            meas_cols = list(vcols)
            if ucol is not None and ucol not in meas_cols:
                meas_cols.append(ucol)
            for c in meas_cols:
                base = comparable(cleaned[first].get(c, ""))
                for rid in rows[1:]:
                    if comparable(cleaned[rid].get(c, "")) != base:
                        conflict = True
                        diff.append((c, rid))
                        break
                if conflict:
                    break
            if conflict:
                duplicates.append({"group_id": gid, "row_ids": list(rows),
                                   "key": _describe(dim), "decision": "keep_separate",
                                   "reason": "same identity key + condition but conflicting "
                                             "values; kept separate for manual adjudication",
                                   "condition_dimension": [_describe(ck)]})
                for c, rid in diff:
                    anomalies.append({"row_id": rid, "field": c,
                                      "value": cleaned[rid].get(c, ""),
                                      "kind": "conflict",
                                      "reason": "conflicts with %s for the same identity key "
                                                "and condition" % first,
                                      "rule_id": "R6"})
                    row_flags[rid].append("conflict:%s" % c)
                    row_rules[rid].add("R6")
            else:
                duplicates.append({"group_id": gid, "row_ids": list(rows),
                                   "key": _describe(dim), "decision": "merge",
                                   "reason": "exact duplicate with identical condition "
                                             "columns; later rows merged into %s" % first,
                                   "condition_dimension": [_describe(ck)]})
                for rid in rows[1:]:
                    duplicate_of[rid] = first

    cleaned_rows = []
    for rid in order:
        vals = cleaned[rid]
        dup = duplicate_of.get(rid, "")
        if dup:
            status = "merged"
        elif row_changed.get(rid):
            status = "changed"
        elif row_flags.get(rid):
            status = "flagged"
        else:
            status = "ok"
        row = {"row_id": rid}
        for f in canonical_fields:
            row[f] = vals.get(f, "")
        row["status"] = status
        row["flags"] = ";".join(row_flags[rid])
        if dup:
            row["duplicate_of"] = dup
        cleaned_rows.append(row)

    provenance = []
    for rid in order:
        provenance.append({"row_id": rid,
                           "source_path": source_by[rid]["source_path"],
                           "source_row": source_by[rid]["source_row"],
                           "fields": {f: canon_of.get(f, f) for f in input_fields},
                           "rules": sorted(row_rules.get(rid, set()))})

    changed_values = sum(1 for l in logs if l["row"] != "header")
    merged = sum(1 for r in cleaned_rows if r.get("duplicate_of"))
    output_rows = sum(1 for r in cleaned_rows if not r.get("duplicate_of"))
    counts = {"input_rows": len(records), "output_rows": output_rows,
              "changed_values": changed_values,
              "pending_review": len([a for a in anomalies if a["kind"] in
                                     ("unit_unresolved", "conflict", "missing")]),
              "duplicates_merged": merged, "anomalies": len(anomalies),
              "dropped_rows": 0, "rules": len(RULES),
              "duplicate_groups": len(duplicates)}
    coverage = {"input_rows": counts["input_rows"], "output_rows": counts["output_rows"],
                "rows_accounted": counts["output_rows"] + merged,
                "fields_total": len(input_fields), "fields_mapped": len(mapping),
                "rules": len(RULES), "duplicate_groups": len(duplicates),
                "pending_review": counts["pending_review"]}
    rules_applied = []
    for rule in RULES:
        rid = rule["rule_id"]
        used = sum(1 for l in logs if l["rule_id"] == rid)
        rules_applied.append({"rule_id": rid, "priority": rule["priority"],
                              "action": rule["action"], "field": rule["field"],
                              "description": rule["description"],
                              "formula": rule["formula"], "source": rule["source"],
                              "applied_count": used})
    pending_review = []
    for a in anomalies:
        if a["kind"] in ("unit_unresolved", "conflict", "missing"):
            pending_review.append({"row_id": a["row_id"], "field": a["field"],
                                   "value": a["value"], "reason": a["reason"],
                                   "rule_id": a["rule_id"]})
    pending_human = ["%s %s: %s" % (a["row_id"], a["field"], a["reason"])
                     for a in anomalies]
    if condition_notes:
        uncertainties.extend(condition_notes)
    if not uncertainties:
        uncertainties.append("No cross-condition merge risk detected; all rows kept "
                             "with their condition dimension (R7).")
    notes.extend(condition_notes)
    claims = [
        {"claim_id": "C1", "kind": "derived",
         "text": "R0..R9 applied in priority order; every changed cell is recorded with "
                 "rule_id + before + after + formula in change_log.csv",
         "evidence": [{"source_id": "scripts/clean_rules.py", "locator": "RULES",
                       "quote": "every changed cell is a recomputable quadruple"}]},
        {"claim_id": "C2", "kind": "derived",
         "text": "unknown units are flagged unit_unresolved and are never guessed or dropped",
         "evidence": [{"source_id": "scripts/clean_rules.py", "locator": "R5",
                       "quote": "flag unknown units as unit_unresolved; never invented and "
                                "never dropped"}]},
        {"claim_id": "C3", "kind": "derived",
         "text": "rows that differ in condition columns are never merged (R7)",
         "evidence": [{"source_id": "scripts/clean_rules.py", "locator": "R7",
                       "quote": "NEVER merge rows that differ in condition columns"}]},
    ]
    notes.append("DERIVED_PATTERN: no usable agent draft; deterministic rule pipeline "
                 "R0..R9 produced the cleaned table.")
    if ucol is not None and ucol == "unit":
        notes.append("unit column present or derived; unknown units remain verbatim "
                     "and are flagged.")
    return {"mode": "derive", "canonical_fields": canonical_fields,
            "field_mapping": mapping, "unmapped_fields": [],
            "cleaned_rows": cleaned_rows, "change_log": logs, "rules": RULES,
            "rules_applied": rules_applied, "duplicates": duplicates,
            "anomalies": anomalies, "pending_review": pending_review,
            "pending_human": pending_human, "uncertainties": uncertainties,
            "condition_notes": condition_notes,
            "provenance": provenance,
            "gaps": gaps, "claims": claims, "notes": notes, "counts": counts,
            "coverage": coverage,
            "degradations": ["no usable agent draft; derived deterministic cleaning applied"]}


def _locator(rec):
    return "%s#row%s" % (rec.get("source_path", ""), rec.get("source_row", ""))


def _describe(tup):
    return ";".join("%s=%s" % (k, v) for k, v in tup)


# --------------------------------------------------------------------- draft path
ROW_STATUS = {"ok", "changed", "flagged", "merged", "dropped", "pending"}
ACTIONS = {"normalize", "convert", "flag", "merge", "drop", "keep", "recode", "split"}


def usable_draft(draft):
    return isinstance(draft, dict) and bool(draft.get("rows"))


def build_from_draft(index, draft):
    """Reuse an agent-written draft and render the same bundle as derive()."""
    records = index.get("records") or []
    input_fields = index.get("fields") or []
    mapping = draft.get("field_mapping") or []
    canon_of = {}
    for item in mapping:
        src = str(item.get("source_field") or "")
        if src:
            canon_of[src] = str(item.get("canonical_field") or src)
    for f in input_fields:
        canon_of.setdefault(f, f)
    canonical_fields = []
    for f in input_fields:
        target = canon_of.get(f, f)
        if target not in canonical_fields:
            canonical_fields.append(target)
    rules = draft.get("rules") or []
    rule_by_id = {str(r.get("rule_id")): r for r in rules}
    draft_rows = {str(r.get("row_id")): r for r in draft.get("rows") or []}
    original_by_id = {r["row_id"]: r for r in records}
    cleaned_rows, logs, anomalies, provenance = [], [], [], []
    for rec in records:
        rid = rec["row_id"]
        row = draft_rows.get(rid) or {}
        status = str(row.get("status") or ("ok" if draft_rows else "pending")).lower()
        values = {canon_of.get(f, f): (rec.get("original") or {}).get(f, "") for f in input_fields}
        if row.get("values"):
            for k, v in row["values"].items():
                values[str(k)] = v
        for ch in row.get("changed") or []:
            field = ch.get("field")
            target = canon_of.get(field, field)
            if target in values or field in values:
                values[target] = ch.get("to")
            rule = rule_by_id.get(str(ch.get("rule_id")), {})
            logs.append({"row": rid, "column": field, "rule_id": ch.get("rule_id", ""),
                         "before": ch.get("from"), "after": ch.get("to"),
                         "formula": rule.get("formula") or ch.get("reason", ""),
                         "note": ch.get("reason", ""),
                         "source_locator": _locator(rec)})
        flags = list(row.get("flags") or [])
        for fl in flags:
            anomalies.append({"row_id": rid, "field": fl.get("field", ""),
                              "value": fl.get("value", ""), "kind": fl.get("kind", "anomaly"),
                              "reason": fl.get("reason", ""),
                              "rule_id": fl.get("rule_id", "")})
        for item in draft.get("pending_review") or []:
            if str(item.get("row_id")) == rid:
                anomalies.append({"row_id": rid, "field": item.get("field", ""),
                                  "value": item.get("value", ""), "kind": "pending_review",
                                  "reason": item.get("reason", ""),
                                  "rule_id": item.get("rule_id", "")})
        out = {"row_id": rid}
        for f in canonical_fields:
            out[f] = values.get(f, "")
        out["status"] = status
        out["flags"] = ";".join("%s:%s" % (fl.get("kind", "flag"), fl.get("field", ""))
                                for fl in flags)
        if row.get("duplicate_of"):
            out["duplicate_of"] = row["duplicate_of"]
        cleaned_rows.append(out)
        provenance.append({"row_id": rid, "source_path": rec.get("source_path", ""),
                           "source_row": rec.get("source_row", ""),
                           "fields": {k: canon_of.get(k, k) for k in input_fields},
                           "rules": sorted({c.get("rule_id") for c in row.get("changed") or []})})
    counts = {"input_rows": len(records),
              "output_rows": sum(1 for r in cleaned_rows if r["status"] not in ("merged", "dropped")),
              "changed_values": len(logs),
              "pending_review": len(draft.get("pending_review") or []),
              "duplicates_merged": sum(1 for r in cleaned_rows if r["status"] == "merged"),
              "anomalies": len(anomalies), "dropped_rows":
                  sum(1 for r in cleaned_rows if r["status"] == "dropped"),
              "rules": len(rules), "duplicate_groups": len(draft.get("duplicates") or [])}
    rules_applied = []
    for rule in rules:
        rid = str(rule.get("rule_id"))
        rules_applied.append({"rule_id": rid, "priority": rule.get("priority"),
                              "action": rule.get("action"), "field": rule.get("field", ""),
                              "description": rule.get("description", ""),
                              "formula": rule.get("formula", ""),
                              "source": rule.get("source") or rule.get("basis", ""),
                              "applied_count": sum(1 for l in logs if l["rule_id"] == rid)})
    coverage = {"input_rows": counts["input_rows"], "output_rows": counts["output_rows"],
                "rows_accounted": counts["output_rows"] + counts["duplicates_merged"]
                + counts["dropped_rows"], "fields_total": len(input_fields),
                "fields_mapped": len(mapping), "rules": len(rules),
                "duplicate_groups": len(draft.get("duplicates") or []),
                "pending_review": counts["pending_review"]}
    claims = []
    for idx, claim in enumerate(draft.get("claims") or [], start=1):
        claims.append({"claim_id": claim.get("claim_id") or "C%d" % idx,
                       "text": claim.get("text") or claim.get("claim"),
                       "kind": claim.get("kind", "direct"),
                       "evidence": claim.get("evidence") or (
                           [{"source_id": claim.get("source_id"),
                             "locator": claim.get("locator"),
                             "quote": claim.get("quote")}] if claim.get("quote") else [])})
    return {"mode": "draft", "canonical_fields": canonical_fields,
            "field_mapping": mapping,
            "unmapped_fields": draft.get("unmapped_fields") or [],
            "cleaned_rows": cleaned_rows, "change_log": logs, "rules": rules,
            "rules_applied": rules_applied, "duplicates": draft.get("duplicates") or [],
            "anomalies": anomalies,
            "pending_review": draft.get("pending_review") or [],
            "pending_human": draft.get("pending_human") or [],
            "uncertainties": draft.get("uncertainties") or draft.get("uncertainty") or [],
            "gaps": draft.get("gaps") or [], "claims": claims,
            "notes": ["agent draft used (mode=draft)"],
            "counts": counts, "coverage": coverage,
            "degradations": ["agent draft used; check report governs validity"],
            "provenance": provenance}


# --------------------------------------------------------------------- checks
def check_draft(index, draft):
    corpus = ""
    for mat in index.get("materials") or []:
        corpus += (mat.get("_text") or "") + "\n"
    corpus = norm_text(corpus)
    records = index.get("records") or []
    input_ids = {r["row_id"] for r in records}
    fails, warnings = [], []
    counts = {"input_rows": len(records), "output_rows": 0, "changed_values": 0,
              "pending_review": 0, "duplicates_merged": 0, "anomalies": 0, "rules": 0,
              "claims": 0, "mapped_fields": 0}
    if not usable_draft(draft):
        fails.append({"code": "draft_missing", "message": "work/draft.json not found"})
        return {"passed": False, "fails": fails, "warnings": warnings, "counts": counts}

    def fail(code, message):
        fails.append({"code": code, "message": message})

    rows = draft.get("rows") or []
    rules = draft.get("rules") or []
    counts["rows"] = len(rows)
    counts["rules"] = len(rules)
    rule_ids = set()
    for rule in rules:
        rid = str(rule.get("rule_id"))
        if not rid or rid in rule_ids:
            fail("rule_id", "rule id missing/duplicated: %r" % rule.get("rule_id"))
        rule_ids.add(rid)
        action = str(rule.get("action") or "").lower()
        if action not in ACTIONS:
            fail("rule_action", "%s action %r not in %s" % (rid, rule.get("action"), sorted(ACTIONS)))
        try:
            int(rule.get("priority"))
        except Exception:
            fail("rule_priority", "%s has no numeric priority" % rid)
        if not str(rule.get("source") or rule.get("basis") or "").strip():
            warnings.append("%s has no documented source/basis" % rid)
    mapping = draft.get("field_mapping") or []
    fields = index.get("fields") or []
    mapped = set()
    for item in mapping:
        src = str(item.get("source_field") or "")
        mapped.add(src)
        if not str(item.get("canonical_field") or "").strip():
            fail("mapping_target", "field %r has no canonical target" % src)
        if src not in fields:
            warnings.append("mapping references unknown source field %r" % src)
    unmapped = [f for f in fields if f not in mapped
                and f not in set(draft.get("unmapped_fields") or [])]
    counts["mapped_fields"] = len(mapped & set(fields))
    if unmapped:
        fail("field_mapping", "source fields neither mapped nor declared unmapped: %s"
             % ", ".join(unmapped))
    original_by_id = {r["row_id"]: r for r in records}
    seen = set()
    for row in rows:
        rid = str(row.get("row_id"))
        if rid not in input_ids:
            fail("row_identity", "row id %r does not exist in the input records" % rid)
        if rid in seen:
            fail("row_duplicate", "row id %r appears twice" % rid)
        seen.add(rid)
        status = str(row.get("status") or "ok").lower()
        if status not in ROW_STATUS:
            fail("row_status", "%s status %r not in %s" % (rid, status, sorted(ROW_STATUS)))
        if status in ("ok", "changed"):
            counts["output_rows"] += 1
        if status == "merged":
            counts["duplicates_merged"] += 1
        for change in row.get("changed") or []:
            counts["changed_values"] += 1
            rule_id = str(change.get("rule_id"))
            if rule_id not in rule_ids:
                fail("change_rule", "%s change %r references unknown rule %r"
                     % (rid, change.get("field"), change.get("rule_id")))
            original = norm_text(change.get("from"))
            if original and original not in norm_text(json.dumps(
                    original_by_id.get(rid, {}).get("original", {}), ensure_ascii=False)):
                fail("change_original", "%s change from %r is not the input value"
                     % (rid, change.get("from")))
            if norm_text(change.get("to")) == norm_text(change.get("from")):
                warnings.append("%s declares a no-op change on %r" % (rid, change.get("field")))
        for flag in row.get("flags") or []:
            counts["anomalies"] += 1
            if not str(flag.get("reason") or "").strip():
                warnings.append("%s flag without a reason" % rid)
        dup = row.get("duplicate_of")
        if dup and str(dup) not in input_ids:
            fail("duplicate_ref", "%s duplicate_of unknown row %r" % (rid, dup))
    missing_rows = input_ids - seen
    if missing_rows:
        fail("row_coverage", "input rows with no output/dropped record: %s"
             % ", ".join(sorted(missing_rows)))
    groups = draft.get("duplicates") or []
    grouped = []
    for group in groups:
        ids = [str(x) for x in (group.get("row_ids") or [])]
        if len(ids) < 2:
            fail("duplicate_group", "duplicate group with fewer than two rows")
        for rid in ids:
            if rid not in input_ids:
                fail("duplicate_row", "duplicate group references unknown row %r" % rid)
            if rid in grouped:
                fail("duplicate_reuse", "row %r appears in more than one duplicate group" % rid)
            grouped.append(rid)
        decision = str(group.get("decision") or "").lower()
        if decision not in ("merge", "keep_separate", "pending", "merge_into"):
            fail("duplicate_decision", "duplicate decision %r not recognised" % decision)
        if not str(group.get("reason") or "").strip():
            warnings.append("duplicate group without a reason")
    pending = draft.get("pending_review") or []
    counts["pending_review"] = len(pending)
    for item in pending:
        if str(item.get("row_id")) not in input_ids:
            fail("pending_row", "pending item references unknown row %r" % item.get("row_id"))
        if not str(item.get("reason") or "").strip():
            fail("pending_reason", "pending item without a reason")
    claims = draft.get("claims") or []
    counts["claims"] = len(claims)
    for claim in claims:
        quote = claim.get("quote") or (claim.get("evidence") or [{}])[0].get("quote")
        if quote and corpus and norm_text(quote) and norm_text(quote) not in corpus:
            fail("claim_quote", "%s quote not verbatim" % claim.get("claim_id"))
    return {"passed": not fails, "fails": fails, "warnings": warnings, "counts": counts}


# --------------------------------------------------------------------- artifacts
import csv as _csv
import json as _json
from pathlib import Path as _Path


def write_artifacts(output_dir, bundle):
    out = _Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    files = {}
    canonical_fields = bundle["canonical_fields"]
    rows = bundle["cleaned_rows"]

    header = ["row_id"] + canonical_fields + ["status", "flags", "duplicate_of"]
    with open(out / "cleaned_data.csv", "w", encoding="utf-8", newline="") as fh:
        w = _csv.writer(fh)
        w.writerow(header)
        for row in rows:
            w.writerow([row.get(k, "") for k in header])
    files["cleaned_data"] = "cleaned_data.csv"

    with open(out / "change_log.csv", "w", encoding="utf-8", newline="") as fh:
        w = _csv.writer(fh)
        w.writerow(["row", "column", "rule_id", "before", "after", "formula", "note",
                    "source_locator"])
        for l in bundle["change_log"]:
            w.writerow([l.get("row"), l.get("column"), l.get("rule_id"), l.get("before"),
                        l.get("after"), l.get("formula"), l.get("note"),
                        l.get("source_locator")])
    files["change_log"] = "change_log.csv"

    with open(out / "change_records.csv", "w", encoding="utf-8", newline="") as fh:
        w = _csv.writer(fh)
        w.writerow(["row_id", "field", "original_value", "cleaned_value", "rule_id",
                    "reason", "source_locator"])
        for l in bundle["change_log"]:
            if l.get("row") == "header":
                continue
            reason = l.get("formula", "")
            if l.get("note"):
                reason = reason + " | " + l["note"]
            w.writerow([l.get("row"), l.get("column"), l.get("before"), l.get("after"),
                        l.get("rule_id"), reason, l.get("source_locator")])
    files["change_records"] = "change_records.csv"

    _jdump(out / "rules_applied.json",
           {"rules": bundle["rules_applied"], "counts": bundle["counts"]})
    files["rules_applied"] = "rules_applied.json"

    _jdump(out / "duplicate_groups.json",
           {"groups": bundle["duplicates"], "merged": bundle["counts"]["duplicates_merged"],
            "condition_notes": bundle.get("condition_notes", [])})
    files["duplicates"] = "duplicate_groups.json"

    _jdump(out / "provenance.json",
           {"rows": bundle.get("provenance") or [
               {"row_id": r["row_id"], "source_path": "", "source_row": "",
                "rules": sorted({l["rule_id"] for l in bundle["change_log"]
                                 if l["row"] == r["row_id"] and l["rule_id"] != "R0"})}
               for r in rows],
            "field_mapping": bundle["field_mapping"],
            "unmapped_fields": bundle["unmapped_fields"], "mode": bundle["mode"]})
    files["provenance"] = "provenance.json"

    lines = ["# Anomaly and pending-review report", "",
             "| row | field | value | kind | reason | rule |", "|---|---|---|---|---|---|"]
    for item in bundle["anomalies"]:
        lines.append("| %s | %s | %s | %s | %s | %s |" % (
            item.get("row_id"), item.get("field"), clip(item.get("value"), 40),
            item.get("kind"), clip(item.get("reason"), 90), item.get("rule_id")))
    if not bundle["anomalies"]:
        lines.append("| — | — | — | none | no anomaly detected | — |")
    lines += ["", "Missing values stay empty (never imputed). Unknown units are kept "
                  "verbatim and flagged, never guessed. Conflicts are kept separate for "
                  "manual adjudication.", ""]
    (out / "anomaly_report.md").write_text("\n".join(lines), encoding="utf-8")
    files["anomalies"] = "anomaly_report.md"

    report = ["# Cleaning report (DERIVED_PATTERN)", "",
              "Mode: `%s`" % bundle["mode"], "",
              "## Rule list (priority order)", "",
              "| priority | rule | action | description | formula | applied |",
              "|---|---|---|---|---|---|"]
    for r in bundle["rules_applied"]:
        report.append("| %s | %s | %s | %s | %s | %s |" % (
            r.get("priority"), r.get("rule_id"), r.get("action"), r.get("description"),
            r.get("formula"), r.get("applied_count")))
    report += ["", "## Counts", "", "```json", _json.dumps(bundle["counts"], ensure_ascii=False),
               "```", "", "## Duplicate decisions", ""]
    for g in bundle["duplicates"]:
        report.append("- %s %s -> %s: %s" % (g.get("group_id"), ",".join(g.get("row_ids", [])),
                                             g.get("decision"), g.get("reason")))
    if not bundle["duplicates"]:
        report.append("- none")
    report += ["", "## Condition dimension (R7)", ""]
    for n in bundle.get("condition_notes", []):
        report.append("- %s" % n)
    if not bundle.get("condition_notes"):
        report.append("- none")
    report += ["", "## Unknown units / conflicts / missing", ""]
    for a in bundle["anomalies"]:
        report.append("- [%s] %s %s: %s" % (a.get("kind"), a.get("row_id"), a.get("field"),
                                            a.get("reason")))
    if not bundle["anomalies"]:
        report.append("- none")
    report += ["", "## Invariants enforced", "",
               "- Every change in `change_log.csv` has `row`/`column` + `rule_id` + `before` "
               "+ `after` + `formula` and can be re-applied by hand.",
               "- Unknown units are `unit_unresolved`, kept verbatim, never guessed, never dropped.",
               "- Rows differing in any condition column are never merged (R7); the condition "
               "dimension is noted in the duplicate group.",
               "- Deterministic: no timestamps, no randomness; two fresh builds are byte-identical.",
               ""]
    for n in bundle["notes"]:
        report.append("- %s" % n)
    (out / "cleaning_report.md").write_text("\n".join(report), encoding="utf-8")
    files["cleaning_report"] = "cleaning_report.md"
    return files


def clip(text, limit=160):
    text = norm_text(str(text)).replace("\n", " ")
    return text if len(text) <= limit else text[:limit - 1] + "…"


def _jdump(path, obj):
    with open(path, "w", encoding="utf-8") as fh:
        _json.dump(obj, fh, ensure_ascii=False, indent=2)
        fh.write("\n")


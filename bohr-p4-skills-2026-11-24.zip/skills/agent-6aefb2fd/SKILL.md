---
name: reproducible-data-analysis
description: 面向科研数据的多步骤可复现分析 Skill。从原始表格/数据库导入开始，完成字段对齐、清洗（缺失/异常/重复/类型/编码）、统计分析与假设校验（描述统计、正态性、方差齐性、ANOVA/Kruskal-Wallis、Welch t、Mann-Whitney U、Pearson 相关、线性回归）、可视化（SVG 可编辑源 + PNG 预览）与报告回填，产出可复核的 result.json、证据链与规则日志。当任务需要导入、清洗、统计、绘图或报告任一环节时触发；输入含 /input/case.json 与科研数据材料（CSV/TSV/JSON/SQLite/XLSX）。
version: 1.0.0
---

# reproducible-data-analysis：多步骤科研数据分析 Skill

把一条真实分析任务从原始表推进到可交回的报告，且每一步保留规则、原始值与证据，可重跑、可回算。

## 触发条件
- 任务要求对科研/实验数据做：导入、字段对齐、清洗、描述统计、组间比较、相关/回归、绘图、报告中的任一步或整条链。
- `/input` 下存在 `case.json` 与数据材料（`.csv/.tsv/.txt/.json/.sqlite/.db/.xlsx`）。
- 不适用：纯文本综述、无结构化数据的问答、仅需转述已有结论而无数据分析的任务。

## 调用方式
脚本位于本 Skill 的 `scripts/` 目录。运行时以 `/skills/weekly-skill/scripts/main.py` 为基准，Agent 用绝对路径调用（勿依赖 CWD）：

```bash
# 完整流程（默认子命令）：读输入 → 清洗 → 统计 → 绘图 → 报告 → result.json
python /skills/weekly-skill/scripts/main.py

# 指定路径覆盖（等价环境变量 INPUT_DIR / WORK_DIR / OUTPUT_DIR）
python /skills/weekly-skill/scripts/main.py --input /input --work /app/work --output /app/output

# 辅助子命令
python /skills/weekly-skill/scripts/main.py init   # 生成工作稿 work.json 骨架（可选）
python /skills/weekly-skill/scripts/main.py show   # 显示当前 work/output 状态
python /skills/weekly-skill/scripts/main.py check  # 校验 result.json 契约键与产物
python /skills/weekly-skill/scripts/main.py --help
```

默认值：`/input`、`/app/work`、`/app/output`。脚本纯 Python 标准库、不联网、不依赖 CWD、无随机性（两次全新输出目录产物一致）。退出码恒为 0，任何异常写入 `errors`/`degradations` 并产出合法 partial。

## 输入
- `INPUT_DIR/case.json`：`case_id`、`task_instruction`、`output_contract`（必须逐字段回填）、可选 `input`/材料路径。
- `INPUT_DIR/task.md`：任务说明与数据字典/字段约束。
- 材料文件：CSV/TSV/JSON/SQLite/XLSX（真实读取，按实际内容判定，不按文件标签假设）。
- 可选 `WORK_DIR/work.json` 工作稿：覆盖自动推断（见 schema）。

## 输出（OUTPUT_DIR）
- `result.json`：含 `case_id`、`status`、`sources`、`uncertainty`、`change_records`、`errors`、`degradations`，并**原样回填 case.json 每个 output_contract 键**（缺值填 null/[]，不漏键）。
- `cleaned_data.csv`：清洗后真实数据（可用）。
- `cleaning_rules.json`：每条规则、优先级、影响行数。
- `quality_report.json` + `report.md`：字段级问题清单与正文报告（数字与结果表同源）。
- `stats.json`：描述统计、假设校验、组间比较、相关/回归。
- `charts/*.svg` + `charts/*.png`：可编辑源与渲染预览成对出现。
- `raw_snapshot.jsonl`、`log.txt`、`evidence.json`：原始快照、日志、证据链。
- 空/坏/缺材料时输出 partial：`status ∈ {partial, insufficient_evidence, input_error}` + `gaps`，绝不崩溃或 0 字节。

## 工作稿 schema（work.json，可选）
```json
{
  "task_summary": "string",
  "target_column": "string|null",
  "group_column": "string|null",
  "analysis": "auto|group|correlation|regression",
  "clean": {"drop_duplicates": true, "impute": "median|mode|drop|none", "outlier_rule": "iqr1.5|none"},
  "output_contract_hints": {"key": "语义提示"}
}
```
缺省时脚本按数据字典与字段语义自动推断（低基数类别列→分组比较；数值目标列→相关/回归）。

## 证据规范（红线）
- 每个结论/条目/数字/页面：`source` + `locator` + 逐字 `quote`；quote 必须能在材料原文命中（≥0.95）。
- CSV 引用原始行文本 + 行号；SQLite 引用表/行与原始存储值；JSON/XLSX 引用提取单元值。
- 计算值只作为“派生结果”，引用原始输入 quote + 规则（脚本函数名），不冒充原文。
- 禁止 placeholder / scaffold / "array"/"object" / 空契约键 / 编造数据或软件状态。

## 降级表
| 情形 | 行为 | status |
|-|-|-|
| 数据正常 | 全流程 + 完整证据 | success |
| 缺列/类型错/空表/坏 CSV | 记录问题列，其余可算则算，写 gaps | partial |
| 材料缺失/无法读取 | 空分析 + 说明缺失清单 | insufficient_evidence |
| case.json 坏/缺 | 用最小合法 result.json | input_error |
| 权限不足/除零/编码错误 | 捕获写 errors，其余继续 | partial |

## 自检（Agent 完成 main.py 后执行）
1. `result.json` 可 JSON 解析，含全部 output_contract 键 + case_id + status。
2. `python .../main.py check` 通过；产物可打开（CSV 可解析、SVG 有 `<svg`、PNG 有 `\x89PNG`）。
3. 报告中每个数字可在 `stats.json` 或 `cleaned_data.csv` 回算；quote 在材料原文中命中。
4. 同一 case 两次全新输出目录产物一致（确定性）。

## 限制
- 仅标准库，不做机器学习/深度学习；推断统计为经典方法，样本量 <5 或严重违前提时报告 uncertainty 并建议人工复核。
- 多重比较用 Bonferroni 校正并在报告说明；独立性假设无法从数据本身完全校验，须在 uncertainty 中声明。

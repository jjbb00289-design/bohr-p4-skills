#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Reproducible data-analysis Skill entry point. Pure stdlib, no network, no CWD dep."""
import argparse
import json
import os
import sys
import traceback
from pathlib import Path

BASE = Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))
import pipeline  # noqa: E402


def resolve_dirs(args):
    inp = args.input or os.environ.get("INPUT_DIR") or "/input"
    work = args.work or os.environ.get("WORK_DIR") or "/app/work"
    out = args.output or os.environ.get("OUTPUT_DIR") or "/app/output"
    return Path(inp), Path(work), Path(out)


def load_case(input_dir):
    cp = input_dir / "case.json"
    if not cp.exists():
        return {"case_id": "unknown", "task_instruction": "", "output_contract": {}, "raw": {}}, "case.json missing"
    try:
        case = json.loads(cp.read_text(encoding="utf-8", errors="replace"))
    except Exception as e:  # noqa: BLE001
        return {"case_id": "unknown", "task_instruction": "", "output_contract": {}, "raw": {}}, "case.json unparseable: %s" % e
    if not isinstance(case, dict):
        return {"case_id": "unknown", "task_instruction": "", "output_contract": {}, "raw": {}}, "case.json not object"
    contract = case.get("output_contract")
    if not isinstance(contract, dict):
        contract = {} if contract is None else {"output_contract": contract}
    return {"case_id": str(case.get("case_id") or case.get("id") or "unknown"),
            "task_instruction": case.get("task_instruction") or case.get("instruction") or "",
            "output_contract": contract, "raw": case}, None


def map_contract_value(key, R):
    k = key.lower()
    g = lambda *subs: any(s in k for s in subs)
    if g("clean", "清洗"):
        return R.get("cleaning", {}).get("summary") or R.get("products", {}).get("cleaned_data")
    if g("stat", "summar", "descript", "描述"):
        return R.get("descriptive")
    if g("test", "compar", "group", "anova", "检验", "比较", "分组"):
        return R.get("tests")
    if g("correl", "相关"):
        return R.get("correlation")
    if g("regress", "回归"):
        return R.get("regression")
    if g("chart", "plot", "vis", "fig", "image", "图"):
        return R.get("charts")
    if g("quality", "质量"):
        return R.get("quality")
    if g("report", "报告"):
        return R.get("products", {}).get("report")
    if g("data", "table", "csv", "数据", "表"):
        return R.get("products", {}).get("cleaned_data")
    if g("conclusion", "result", "结论", "结果"):
        return R.get("conclusions")
    return None


def build_result(case, R):
    result = {"case_id": case["case_id"], "status": R.get("status", "partial"),
              "task_instruction": case["task_instruction"],
              "sources": R.get("sources", []), "uncertainty": R.get("uncertainty", []),
              "change_records": R.get("change_records", []),
              "errors": R.get("errors", []), "degradations": R.get("degradations", []),
              "gaps": R.get("gaps", [])}
    reserved = {"case_id", "status", "task_instruction", "sources", "uncertainty",
                "change_records", "errors", "degradations", "gaps"}
    for key in case["output_contract"]:
        if key not in reserved:
            result[key] = map_contract_value(key, R)
    for k in ("products", "data_profile", "cleaning", "descriptive", "tests",
              "correlation", "regression", "charts", "quality", "conclusions", "report"):
        if k in R:
            result[k] = R[k]
    return result


def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")


def cmd_build(input_dir, work_dir, output_dir, work_json=None):
    work_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    case, err = load_case(input_dir)
    partial = {"case_id": case["case_id"], "status": "partial", "sources": [],
               "uncertainty": ["pipeline running"], "change_records": [],
               "errors": [err] if err else [], "degradations": [], "gaps": []}
    for key in case["output_contract"]:
        if key not in partial:
            partial[key] = None
    write_json(output_dir / "result.json", partial)
    try:
        R = pipeline.run(input_dir, work_dir, output_dir, case, work_json)
        if err:
            R["errors"].insert(0, err)
            R["status"] = "input_error"  # malformed or missing case overrides substantive output
    except Exception as e:  # noqa: BLE001
        R = {"status": "partial", "case_id": case["case_id"], "errors": [str(e)],
             "degradations": [], "gaps": ["pipeline raised"], "sources": [],
             "uncertainty": ["execution error"], "change_records": [], "products": {},
             "descriptive": {}, "tests": {}, "correlation": {}, "regression": {},
             "charts": [], "quality": {}, "conclusions": [], "cleaning": {}, "report": None}
        (output_dir / "log.txt").write_text("traceback:\n" + traceback.format_exc(), encoding="utf-8")
    write_json(output_dir / "result.json", build_result(case, R))
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="main.py", description="Reproducible data-analysis pipeline")
    p.add_argument("command", nargs="?", default="build", choices=["build", "init", "show", "check"])
    p.add_argument("--input", default=None)
    p.add_argument("--work", default=None)
    p.add_argument("--output", default=None)
    args = p.parse_args(argv)
    input_dir, work_dir, output_dir = resolve_dirs(args)
    try:
        if args.command == "init":
            work_dir.mkdir(parents=True, exist_ok=True)
            wf = work_dir / "work.json"
            if not wf.exists():
                write_json(wf, {"task_summary": "", "target_column": None, "group_column": None,
                                "analysis": "auto",
                                "clean": {"drop_duplicates": True, "impute": "median",
                                          "outlier_rule": "iqr1.5"}, "output_contract_hints": {}})
            print(json.dumps({"work": str(wf)}))
            return 0
        if args.command == "show":
            rj = output_dir / "result.json"
            st = "none"
            if rj.exists():
                try:
                    st = json.loads(rj.read_text(encoding="utf-8")).get("status", "?")
                except Exception:  # noqa: BLE001
                    st = "invalid"
            print(json.dumps({"work": str(work_dir), "output": str(output_dir), "status": st}))
            return 0
        if args.command == "check":
            problems = []
            rj = output_dir / "result.json"
            if not rj.exists():
                problems.append("result.json missing")
            else:
                try:
                    r = json.loads(rj.read_text(encoding="utf-8"))
                    for k in ("case_id", "status", "sources", "uncertainty", "change_records"):
                        if k not in r:
                            problems.append("missing key: %s" % k)
                    for name, rel in (r.get("products") or {}).items():
                        if rel and not (output_dir / rel).exists():
                            problems.append("product missing: %s" % rel)
                    for c in (r.get("charts") or []):
                        for rel in (c.get("svg"), c.get("png")):
                            if rel and not (output_dir / rel).exists():
                                problems.append("chart missing: %s" % rel)
                except Exception as e:  # noqa: BLE001
                    problems.append("result.json invalid: %s" % e)
            print(json.dumps({"ok": not problems, "problems": problems}, ensure_ascii=False, indent=2))
            return 0
        work_json = None
        wf = work_dir / "work.json"
        if wf.exists():
            try:
                work_json = json.loads(wf.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                work_json = None
        return cmd_build(input_dir, work_dir, output_dir, work_json)
    except Exception:  # noqa: BLE001
        sys.stderr.write(traceback.format_exc())
        return 0


if __name__ == "__main__":
    sys.exit(main())

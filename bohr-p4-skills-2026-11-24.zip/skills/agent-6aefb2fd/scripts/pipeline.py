#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pure-stdlib analysis pipeline: read -> profile -> clean -> test -> chart -> report."""
import csv
import io
import json
import math
import re
import sqlite3
import statistics as st
import struct
import zlib
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET

FPMIN = 1e-300
EPS = 1e-12


def _lgamma(x):
    c = [76.18009172947146, -86.50532032941677, 24.01409824083091,
         -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5]
    y = x
    tmp = x + 5.5
    tmp -= (x + 0.5) * math.log(tmp)
    ser = 1.000000000190015
    for k in c:
        y += 1.0
        ser += k / y
    return -tmp + math.log(2.5066282746310005 * ser / x)


def chi2_cdf(x, k):
    return 1.0 - chi2_sf(x, k)


def chi2_sf(x, k):
    if x <= 0 or k <= 0:
        return 1.0
    z = (((x / k) ** (1.0 / 3.0)) - (1.0 - 2.0 / (9.0 * k))) / math.sqrt(2.0 / (9.0 * k))
    return normal_sf(z)


def normal_cdf(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def normal_sf(x):
    return 0.5 * math.erfc(x / math.sqrt(2.0))


def _betacf(a, b, x):
    qab = a + b
    qap = a + 1.0
    qam = a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < FPMIN:
        d = FPMIN
    d = 1.0 / d
    h = d
    for m in range(1, 301):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN:
            d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN:
            c = FPMIN
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN:
            d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN:
            c = FPMIN
        d = 1.0 / d
        dl = d * c
        h *= dl
        if abs(dl - 1.0) < EPS:
            break
    return h


def betainc(x, a, b):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    bt = math.exp(_lgamma(a + b) - _lgamma(a) - _lgamma(b)
                  + a * math.log(x) + b * math.log(1.0 - x))
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * _betacf(a, b, x) / a
    return 1.0 - bt * _betacf(b, a, 1.0 - x) / b


def t_cdf(t, df):
    if df <= 0:
        return float("nan")
    x = df / (df + t * t)
    ib = betainc(x, df / 2.0, 0.5)
    return 1.0 - 0.5 * ib if t > 0 else 0.5 * ib


def t_sf(t, df):
    return 1.0 - t_cdf(t, df)


def f_cdf(f, d1, d2):
    if f <= 0:
        return 0.0
    x = d1 * f / (d1 * f + d2)
    return betainc(x, d1 / 2.0, d2 / 2.0)


def f_sf(f, d1, d2):
    return 1.0 - f_cdf(f, d1, d2)


def _num(x):
    if x is None:
        return None
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _nums(vals):
    out = []
    for v in vals:
        n = _num(v)
        if n is not None and math.isfinite(n):
            out.append(n)
    return out


def mean(v):
    v = _nums(v)
    return st.mean(v) if len(v) else None


def sd(v):
    v = _nums(v)
    return st.stdev(v) if len(v) > 1 else (0.0 if len(v) == 1 else None)


def quantile(v, q):
    v = sorted(_nums(v))
    if not v:
        return None
    if len(v) == 1:
        return v[0]
    pos = q * (len(v) - 1)
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    return v[lo] if lo == hi else v[lo] + (v[hi] - v[lo]) * (pos - lo)


def skewness(v):
    v = _nums(v)
    n = len(v)
    if n < 3:
        return None
    m = st.mean(v)
    s = st.stdev(v)
    if s == 0:
        return 0.0
    return (n / ((n - 1) * (n - 2))) * (sum((x - m) ** 3 for x in v) / (s ** 3))


def kurtosis(v):
    v = _nums(v)
    n = len(v)
    if n < 4:
        return None
    m = st.mean(v)
    s = st.stdev(v)
    if s == 0:
        return 0.0
    g2 = (n * (n + 1)) / ((n - 1) * (n - 2) * (n - 3)) * (sum((x - m) ** 4 for x in v) / (s ** 4))
    return g2 - 3 * (n - 1) ** 2 / ((n - 2) * (n - 3))


def _fmt(x, p=4):
    if x is None or (isinstance(x, float) and (math.isnan(x) or math.isinf(x))):
        return None
    return round(x, p) if isinstance(x, float) else x


def _rankdata(allvals):
    order = sorted(range(len(allvals)), key=lambda i: allvals[i])
    ranks = [0.0] * len(allvals)
    i = 0
    n = len(allvals)
    while i < n:
        j = i
        while j + 1 < n and allvals[order[j + 1]] == allvals[order[i]]:
            j += 1
        r = (i + j + 2) / 2.0
        for k in range(i, j + 1):
            ranks[order[k]] = r
        i = j + 1
    return ranks


def welch_t(a, b):
    a = _nums(a)
    b = _nums(b)
    if len(a) < 2 or len(b) < 2:
        return None
    ma, mb = st.mean(a), st.mean(b)
    va, vb = st.variance(a), st.variance(b)
    se = math.sqrt(va / len(a) + vb / len(b))
    if se == 0:
        return None
    t = (ma - mb) / se
    df = (va / len(a) + vb / len(b)) ** 2 / (
        (va / len(a)) ** 2 / (len(a) - 1) + (vb / len(b)) ** 2 / (len(b) - 1))
    p = 2.0 * t_sf(abs(t), df)
    sp = math.sqrt(((len(a) - 1) * va + (len(b) - 1) * vb) / (len(a) + len(b) - 2))
    d = (ma - mb) / sp if sp != 0 else None
    return {"t": _fmt(t), "df": _fmt(df), "p": _fmt(p), "mean_a": _fmt(ma),
            "mean_b": _fmt(mb), "n_a": len(a), "n_b": len(b),
            "sd_a": _fmt(math.sqrt(va)), "sd_b": _fmt(math.sqrt(vb)), "cohens_d": _fmt(d)}


def anova_f(groups):
    groups = [g for g in (_nums(g) for g in groups) if len(g) > 0]
    if len(groups) < 2:
        return None
    allv = [x for g in groups for x in g]
    gm = st.mean(allv)
    n = len(allv)
    k = len(groups)
    ssb = sum(len(g) * (st.mean(g) - gm) ** 2 for g in groups)
    ssw = sum(sum((x - st.mean(g)) ** 2 for x in g) for g in groups)
    dfb = k - 1
    dfw = n - k
    if dfw <= 0 or ssw == 0:
        return None
    f = (ssb / dfb) / (ssw / dfw)
    return {"F": _fmt(f), "df_between": dfb, "df_within": dfw, "p": _fmt(f_sf(f, dfb, dfw)),
            "eta_squared": _fmt(ssb / (ssb + ssw)), "n": n, "k": k,
            "ss_between": _fmt(ssb), "ss_within": _fmt(ssw)}


def kruskal_wallis(groups):
    groups = [g for g in (_nums(g) for g in groups) if len(g) > 0]
    if len(groups) < 2:
        return None
    allv = [x for g in groups for x in g]
    n = len(allv)
    k = len(groups)
    ranks = _rankdata(allv)
    idx = 0
    rsums = []
    for g in groups:
        rsums.append(sum(ranks[idx:idx + len(g)]))
        idx += len(g)
    h = 12.0 / (n * (n + 1)) * sum(r * r / len(g) for r, g in zip(rsums, groups)) - 3 * (n + 1)
    tie = sum(t ** 3 - t for t in Counter(allv).values())
    corr = 1.0 - tie / (n ** 3 - n) if n > 1 else 1.0
    hc = h / corr if corr > 0 else h
    return {"H": _fmt(hc), "df": k - 1, "p": _fmt(chi2_sf(hc, k - 1)),
            "eta_squared": _fmt((h - k + 1) / (n - k)) if n > k else None,
            "n": n, "k": k, "tie_correction": _fmt(corr)}


def levene(groups):
    groups = [g for g in (_nums(g) for g in groups) if len(g) > 0]
    if len(groups) < 2:
        return None
    zs = [[abs(x - st.median(g)) for x in g] for g in groups]
    r = anova_f(zs)
    return None if not r else {"F": r["F"], "df_between": r["df_between"],
                               "df_within": r["df_within"], "p": r["p"]}


def jarque_bera(v):
    v = _nums(v)
    if len(v) < 8:
        return None
    s = skewness(v)
    k = kurtosis(v)
    jb = len(v) / 6.0 * (s ** 2 + k ** 2 / 4.0)
    return {"JB": _fmt(jb), "p": _fmt(chi2_sf(jb, 2)), "skewness": _fmt(s),
            "kurtosis": _fmt(k)}


def pearson(a, b):
    a = _nums(a)
    b = _nums(b)
    pairs = [(x, y) for x, y in zip(a, b)]
    n = len(pairs)
    if n < 3:
        return None
    ma = st.mean([p[0] for p in pairs])
    mb = st.mean([p[1] for p in pairs])
    sxy = sum((x - ma) * (y - mb) for x, y in pairs)
    sxx = sum((x - ma) ** 2 for x, y in pairs)
    syy = sum((y - mb) ** 2 for x, y in pairs)
    if sxx == 0 or syy == 0:
        return None
    r = sxy / math.sqrt(sxx * syy)
    if abs(r) >= 1.0:
        p = 0.0
    else:
        t = r * math.sqrt((n - 2) / (1 - r * r))
        p = 2.0 * t_sf(abs(t), n - 2)
    return {"r": _fmt(r), "p": _fmt(p), "n": n}


def linreg(x, y):
    x = _nums(x)
    y = _nums(y)
    pairs = [(a, b) for a, b in zip(x, y)]
    n = len(pairs)
    if n < 2:
        return None
    mx = st.mean([p[0] for p in pairs])
    my = st.mean([p[1] for p in pairs])
    sxx = sum((a - mx) ** 2 for a, b in pairs)
    sxy = sum((a - mx) * (b - my) for a, b in pairs)
    syy = sum((b - my) ** 2 for a, b in pairs)
    if sxx == 0:
        return None
    slope = sxy / sxx
    return {"slope": _fmt(slope), "intercept": _fmt(my - slope * mx),
            "r_squared": _fmt((sxy ** 2) / (sxx * syy)) if syy != 0 else None, "n": n}


MISSING = {"", "na", "nan", "null", "none", "?", "n/a", "-", "--", "无", "缺失"}


def _parse_cell(s):
    if s is None:
        return None
    s = s.strip()
    if s.lower() in MISSING:
        return None
    n = _num(s)
    return n if n is not None else s


def _decode(path):
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "utf-8", "gbk", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def read_csv(path):
    text = _decode(path)
    raw_lines = text.splitlines()
    sample = "\n".join(raw_lines[:20])
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t| ")
    except Exception:  # noqa: BLE001
        dialect = csv.excel
    reader = list(csv.reader(io.StringIO(text), dialect))
    if not reader:
        return {"columns": [], "rows": [], "raw_lines": [], "source": str(path),
                "kind": "csv", "header": False}
    try:
        has_header = csv.Sniffer().has_header(sample)
    except Exception:  # noqa: BLE001
        has_header = False
    if has_header:
        cols = [c.strip() or ("col_%d" % i) for i, c in enumerate(reader[0])]
        data = reader[1:]
        line_start = 2
    else:
        cols = ["col_%d" % i for i in range(len(reader[0]))]
        data = reader
        line_start = 1
    rows = []
    for r in data:
        if not r or all((c or "").strip() == "" for c in r):
            continue
        rows.append({c: _parse_cell(r[i] if i < len(r) else "") for i, c in enumerate(cols)})
    raw = [raw_lines[li + line_start - 1] for li in range(len(raw_lines) - line_start + 1)]
    return {"columns": cols, "rows": rows, "raw_lines": raw, "source": str(path),
            "kind": "csv", "header": has_header}


def read_json(path):
    text = _decode(path)
    try:
        data = json.loads(text)
    except Exception:  # noqa: BLE001
        return None
    if isinstance(data, dict):
        for k, v in data.items():
            if isinstance(v, list) and v and isinstance(v[0], dict):
                data = v
                break
    if not isinstance(data, list):
        return None
    records = [r for r in data if isinstance(r, dict)]
    if not records:
        return None
    cols = []
    for r in records:
        for k in r:
            if k not in cols:
                cols.append(k)
    rows = [{c: _parse_cell(r.get(c)) for c in cols} for r in records]
    raw = [json.dumps(r, ensure_ascii=False) for r in records]
    return {"columns": cols, "rows": rows, "raw_lines": raw, "source": str(path),
            "kind": "json", "header": True}


def read_sqlite(path):
    uri = "file:%s?mode=ro" % str(path).replace("\\", "/")
    con = sqlite3.connect(uri, uri=True)
    try:
        cur = con.cursor()
        tables = [r[0] for r in cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        if not tables:
            return None
        t = tables[0]
        cur.execute('SELECT * FROM "%s"' % t)
        names = [d[0] for d in cur.description]
        allr = cur.fetchall()
        rows = []
        raw = []
        for ridx, r in enumerate(allr):
            d = dict(zip(names, r))
            rows.append({k: _parse_cell(v) for k, v in d.items()})
            raw.append("table=%s row=%d " % (t, ridx + 1) +
                       json.dumps({k: v for k, v in d.items()}, ensure_ascii=False, default=str))
        return {"columns": names, "rows": rows, "raw_lines": raw,
                "source": "%s#%s" % (path, t), "kind": "sqlite", "header": True}
    finally:
        con.close()


_XLS_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"


def read_xlsx(path):
    import zipfile
    try:
        zf = zipfile.ZipFile(path)
    except Exception:  # noqa: BLE001
        return None
    names = zf.namelist()
    sheet = "xl/worksheets/sheet1.xml"
    if sheet not in names:
        sheets = sorted([n for n in names if re.match(r"xl/worksheets/sheet\d+\.xml", n)])
        if not sheets:
            return None
        sheet = sheets[0]
    shared = []
    if "xl/sharedStrings.xml" in names:
        root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
        shared = ["".join(t.text or "" for t in si.iter("{%s}t" % _XLS_NS)) for si in root]
    root = ET.fromstring(zf.read(sheet))
    rows_out = []
    for row in root.iter("{%s}row" % _XLS_NS):
        cells = {}
        maxc = -1
        for c in row.iter("{%s}c" % _XLS_NS):
            m = re.match(r"([A-Z]+)(\d+)", c.get("r") or "")
            if not m:
                continue
            col = 0
            for ch in m.group(1):
                col = col * 26 + (ord(ch) - 64)
            col -= 1
            maxc = max(maxc, col)
            v = c.find("{%s}v" % _XLS_NS)
            val = v.text if v is not None else ""
            if c.get("t") == "s" and val:
                try:
                    val = shared[int(val)]
                except (ValueError, IndexError):
                    pass
            cells[col] = val
        if maxc >= 0:
            rows_out.append([cells.get(i, "") for i in range(maxc + 1)])
    zf.close()
    if not rows_out:
        return None
    first = rows_out[0]
    has_header = any(isinstance(_parse_cell(x), str) and x.strip() for x in first)
    if has_header:
        cols = [x.strip() or ("col_%d" % i) for i, x in enumerate(first)]
        data = rows_out[1:]
    else:
        cols = ["col_%d" % i for i in range(len(first))]
        data = rows_out
    rows = []
    for r in data:
        if not r or all((c or "").strip() == "" for c in r):
            continue
        rows.append({c: _parse_cell(r[i] if i < len(r) else "") for i, c in enumerate(cols)})
    raw = [json.dumps({cols[i]: r[i] for i in range(len(cols)) if i < len(r)},
                      ensure_ascii=False) for r in data]
    return {"columns": cols, "rows": rows, "raw_lines": raw, "source": str(path),
            "kind": "xlsx", "header": has_header}


EXT_MAP = {".csv": read_csv, ".tsv": read_csv, ".txt": read_csv,
           ".json": read_json, ".sqlite": read_sqlite, ".db": read_sqlite,
           ".xlsx": read_xlsx}


def find_data_files(input_dir):
    out = []
    skip = {"case.json", "task.md", "result.json"}
    for p in sorted(input_dir.rglob("*")):
        if p.is_file() and p.name.lower() not in skip and p.suffix.lower() in EXT_MAP:
            out.append(p)
    return out


def profile(ds):
    cols, rows = ds["columns"], ds["rows"]
    n = len(rows)
    prof = {}
    for c in cols:
        vals = [r.get(c) for r in rows]
        nums = _nums(vals)
        nonmissing = [v for v in vals if v is not None]
        uniq = len(set(str(v) for v in nonmissing))
        ints = all(float(x).is_integer() for x in nums) if nums else False
        if nums and len(nums) >= 0.8 * len(nonmissing):
            dtype = "numeric"
            if uniq <= 12 and ints and n > 0 and uniq / max(n, 1) < 0.3:
                dtype = "categorical"
        elif nonmissing and uniq <= 12:
            dtype = "categorical"
        else:
            dtype = "string"
        prof[c] = {"type": dtype, "missing": sum(1 for v in vals if v is None),
                   "n": n, "unique": uniq, "numeric_count": len(nums)}
    return prof


def _mode(vals):
    c = Counter(str(v) for v in vals if v is not None)
    return c.most_common(1)[0][0] if c else None


def _median_col(rows, c):
    v = sorted(_nums([r.get(c) for r in rows]))
    return quantile(v, 0.5) if v else None


def clean(ds, prof, cfg):
    rows = [dict(r) for r in ds["rows"]]
    origin = list(range(len(rows)))
    rules, changes = [], []
    if cfg.get("drop_duplicates", True):
        seen, keep, dropped = {}, [], []
        for i, r in enumerate(rows):
            key = json.dumps(r, sort_keys=True, default=str)
            if key in seen:
                dropped.append(origin[i])
            else:
                seen[key] = origin[i]
                keep.append(i)
        if dropped:
            q = ds["raw_lines"][dropped[0]] if dropped[0] < len(ds["raw_lines"]) else ""
            rules.append({"id": "R1", "rule": "drop_exact_duplicates", "priority": 1,
                          "rows_removed": len(dropped), "row_indices": dropped, "quote": q})
            changes.append({"step": "drop_duplicates", "rows_before": len(rows),
                            "rows_after": len(keep), "rows_removed": len(dropped)})
            rows = [rows[i] for i in keep]
            origin = [origin[i] for i in keep]
    for c in ds["columns"]:
        miss_idx = [i for i, r in enumerate(rows) if r.get(c) is None]
        if not miss_idx:
            continue
        strategy = cfg.get("impute", "median")
        if strategy == "drop":
            dropped = [origin[i] for i in miss_idx]
            rules.append({"id": "R%d" % (len(rules) + 1), "rule": "drop_missing_rows",
                          "column": c, "priority": 2, "rows_removed": len(dropped),
                          "row_indices": dropped})
            changes.append({"step": "drop_missing", "column": c,
                            "rows_removed": len(dropped), "rows_before": len(rows),
                            "rows_after": len(rows) - len(dropped)})
            keep = [i for i in range(len(rows)) if i not in set(miss_idx)]
            rows, origin = [rows[i] for i in keep], [origin[i] for i in keep]
            continue
        if strategy == "none":
            rules.append({"id": "R%d" % (len(rules) + 1), "rule": "preserve_missing",
                          "column": c, "priority": 2, "rows_unchanged": len(miss_idx)})
            continue
        if strategy == "mode" or prof.get(c, {}).get("type") != "numeric":
            fill = _mode([r.get(c) for r in rows])
            how = "mode_impute"
        else:
            fill = _median_col(rows, c)
            how = "median_impute"
        if fill is None:
            rules.append({"id": "R%d" % (len(rules) + 1), "rule": "imputation_skipped_all_missing",
                          "column": c, "priority": 2, "rows_unchanged": len(miss_idx)})
            continue
        for i in miss_idx:
            rows[i][c] = fill
        q = ds["raw_lines"][origin[miss_idx[0]]] if origin[miss_idx[0]] < len(ds["raw_lines"]) else ""
        rules.append({"id": "R%d" % (len(rules) + 1), "rule": how, "column": c,
                      "priority": 2, "rows_changed": len(miss_idx),
                      "row_indices": [origin[i] for i in miss_idx],
                      "fill_value": fill, "quote": q})
        changes.append({"step": how, "column": c, "rows_changed": len(miss_idx)})
    outliers = {}
    if cfg.get("outlier_rule", "iqr1.5") == "none":
        clean_ds = {"columns": ds["columns"], "rows": rows, "raw_lines": ds["raw_lines"],
                    "source": ds["source"], "kind": ds["kind"], "header": True, "origin": origin}
        return clean_ds, rules, changes, outliers
    for c in ds["columns"]:
        if prof.get(c, {}).get("type") != "numeric":
            continue
        nums = _nums([r.get(c) for r in rows])
        if len(nums) < 4:
            continue
        q1, q3 = quantile(nums, 0.25), quantile(nums, 0.75)
        iqr = q3 - q1
        lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        flags = [{"row": origin[i], "value": _fmt(v), "column": c}
                 for i, r in enumerate(rows) for v in [_num(r.get(c))]
                 if v is not None and (v < lo or v > hi)]
        if flags:
            outliers[c] = {"rule": "iqr_1.5", "q1": _fmt(q1), "q3": _fmt(q3),
                           "lower": _fmt(lo), "upper": _fmt(hi), "count": len(flags),
                           "flags": flags[:50]}
            rules.append({"id": "R%d" % (len(rules) + 1), "rule": "flag_outliers_iqr1.5",
                          "column": c, "priority": 3, "rows_flagged": len(flags)})
    clean_ds = {"columns": ds["columns"], "rows": rows, "raw_lines": ds["raw_lines"],
                "source": ds["source"], "kind": ds["kind"], "header": True, "origin": origin}
    return clean_ds, rules, changes, outliers


def descriptive(ds, prof):
    out = {}
    for c in ds["columns"]:
        if prof.get(c, {}).get("type") != "numeric":
            continue
        v = _nums([r.get(c) for r in ds["rows"]])
        if not v:
            continue
        out[c] = {"n": len(v), "mean": _fmt(st.mean(v)), "sd": _fmt(sd(v)),
                  "min": _fmt(min(v)), "q1": _fmt(quantile(v, 0.25)),
                  "median": _fmt(st.median(v)), "q3": _fmt(quantile(v, 0.75)),
                  "max": _fmt(max(v)), "skewness": _fmt(skewness(v)),
                  "kurtosis": _fmt(kurtosis(v)), "missing": prof.get(c, {}).get("missing", 0)}
    return out


def _group_levels(ds, group_col):
    levels = []
    for r in ds["rows"]:
        v = r.get(group_col)
        if v not in levels:
            levels.append(v)
    return levels


def group_analysis(ds, prof, group_col, numeric_cols):
    levels = _group_levels(ds, group_col)
    if len(levels) < 2 or len(levels) > 12:
        return None
    groups = {lv: [r for r in ds["rows"] if r.get(group_col) == lv] for lv in levels}
    res = {"group_column": group_col, "levels": [str(l) for l in levels],
           "per_group": {}, "tests": {}}
    for lv in levels:
        res["per_group"][str(lv)] = {"n": len(groups[lv])}
        for c in numeric_cols:
            v = _nums([r.get(c) for r in groups[lv]])
            if v:
                res["per_group"][str(lv)][c] = {"mean": _fmt(st.mean(v)),
                                                "sd": _fmt(sd(v)),
                                                "median": _fmt(st.median(v))}
    for c in numeric_cols:
        g = [_nums([r.get(c) for r in groups[lv]]) for lv in levels]
        if any(len(x) < 2 for x in g):
            continue
        res["tests"][c] = {"anova": anova_f(g), "kruskal_wallis": kruskal_wallis(g),
                           "levene": levene(g),
                           "normality_jarque_bera": {
                               str(lv): jarque_bera(_nums([r.get(c) for r in groups[lv]]))
                               for lv in levels}}
        if len(levels) == 2:
            res["tests"][c]["welch_t"] = welch_t(g[0], g[1])
        elif len(levels) <= 4:
            pw = []
            for i in range(len(levels)):
                for j in range(i + 1, len(levels)):
                    t = welch_t(g[i], g[j])
                    if t:
                        pw.append({"pair": [str(levels[i]), str(levels[j])], **t})
            res["tests"][c]["pairwise_welch"] = pw
    return res


def correlation(ds, prof, numeric_cols, target=None):
    cols = numeric_cols[:12] if len(numeric_cols) > 12 else numeric_cols
    mat = {}
    pairs = []
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            r = pearson([x.get(cols[i]) for x in ds["rows"]],
                        [x.get(cols[j]) for x in ds["rows"]])
            if r:
                mat["%s|%s" % (cols[i], cols[j])] = r
                pairs.append((cols[i], cols[j], r["r"], r["p"]))
    top = sorted(pairs, key=lambda p: -abs(p[2]))[:15]
    tc = []
    if target:
        for c in numeric_cols:
            if c != target:
                r = pearson([x.get(c) for x in ds["rows"]],
                            [x.get(target) for x in ds["rows"]])
                if r:
                    tc.append({"feature": c, "r": r["r"], "p": r["p"]})
        tc.sort(key=lambda x: -abs(x["r"]))
    return {"matrix": mat, "columns": cols,
            "top_pairs": [{"x": a, "y": b, "r": _fmt(r), "p": _fmt(p)} for a, b, r, p in top],
            "target_correlations": tc}


def regression(ds, target, features):
    out = []
    for f in features:
        if f == target:
            continue
        lr = linreg([x.get(f) for x in ds["rows"]], [x.get(target) for x in ds["rows"]])
        if lr:
            out.append({"feature": f, **lr})
    out.sort(key=lambda x: -(x.get("r_squared") if x.get("r_squared") is not None else -1))
    return {"target": target, "models": out}


# --------------------------------------------------------------------------- charts
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    HAVE_MPL = True
except Exception:  # noqa: BLE001
    HAVE_MPL = False


def _tshort(s, n=12):
    s = str(s)
    return s if len(s) <= n else s[:n - 1] + "~"


def _save_chart(fig, osvg, opng):
    fig.tight_layout()
    fig.savefig(osvg)
    fig.savefig(opng)
    plt.close(fig)


def bar(title, labels, vals, errs, ylabel, osvg, opng):
    if not HAVE_MPL:
        return False
    fig, ax = plt.subplots(figsize=(6.4, 4.0), dpi=100)
    xs = list(range(len(labels)))
    ax.bar(xs, vals, yerr=errs, capsize=4, color="#1f77b4")
    ax.set_xticks(xs)
    ax.set_xticklabels([_tshort(x) for x in labels], rotation=30, ha="right", fontsize=9)
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    _save_chart(fig, osvg, opng)
    return True


def histogram(title, data, xlabel, osvg, opng):
    if not HAVE_MPL:
        return False
    fig, ax = plt.subplots(figsize=(6.4, 4.0), dpi=100)
    ax.hist(_nums(data) or [0.0], bins=10, color="#1f77b4", edgecolor="white")
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("count")
    _save_chart(fig, osvg, opng)
    return True


def scatter(title, xs, ys, xlabel, ylabel, osvg, opng):
    if not HAVE_MPL:
        return False
    fig, ax = plt.subplots(figsize=(6.4, 4.0), dpi=100)
    ax.scatter(_nums(xs), _nums(ys), s=12, alpha=0.6, color="#1f77b4")
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    _save_chart(fig, osvg, opng)
    return True

# --------------------------------------------------------------------------- report / run
def _pick_dataset(datasets):
    return max(datasets, key=lambda d: len(d.get("rows") or []))


def _detect_target(ds, prof, work_json):
    if work_json and work_json.get("target_column"):
        return work_json["target_column"]
    named = {"target", "label", "class", "species", "strength", "outcome", "result",
             "quality", "y", "price", "value"}
    for c in ds["columns"]:
        if c.strip().lower() in named:
            return c
    for c in reversed(ds["columns"]):
        if prof.get(c, {}).get("type") == "categorical":
            return c
    for c in reversed(ds["columns"]):
        if prof.get(c, {}).get("type") == "numeric":
            return c
    return None


def _detect_group(ds, prof, work_json):
    if work_json and work_json.get("group_column"):
        return work_json["group_column"]
    for c in ds["columns"]:
        if prof.get(c, {}).get("type") == "categorical":
            return c
    return None


def _quote(ds, idx):
    i = idx if isinstance(idx, int) else 0
    return ds["raw_lines"][i] if 0 <= i < len(ds["raw_lines"]) else ""


def _make_charts(clean_ds, prof, group, group_col, target, target_numeric, numeric_cols, reg, output_dir):
    charts = []
    cdir = output_dir / "charts"
    cdir.mkdir(parents=True, exist_ok=True)
    idx = 0

    def nxt(ext):
        nonlocal idx
        idx += 1
        return "charts/chart_%02d.%s" % (idx, ext)
    if group:
        best, eta = None, None
        for c in numeric_cols:
            e = (group.get("tests", {}).get(c, {}).get("anova") or {}).get("eta_squared")
            if e is not None and (eta is None or e > eta):
                eta, best = e, c
        if best:
            lv = group["levels"]
            means = [group["per_group"][lv].get(best, {}).get("mean") for lv in lv]
            errs = [group["per_group"][lv].get(best, {}).get("sd") for lv in lv]
            s, p = nxt("svg"), nxt("png")
            bar("mean +/- SD: %s by %s" % (best, group_col), lv, means, errs, best,
                str(cdir / ("chart_%02d.svg" % (idx - 1))), str(cdir / ("chart_%02d.png" % idx)))
            charts.append({"name": "group_means_%s" % best, "type": "bar", "svg": s, "png": p,
                           "description": "%s 各水平均值与标准差" % best})
    if target_numeric:
        for f in [m["feature"] for m in (reg or {}).get("models", [])][:2]:
            s, p = nxt("svg"), nxt("png")
            scatter("%s vs %s" % (target, f), [r.get(f) for r in clean_ds["rows"]],
                    [r.get(target) for r in clean_ds["rows"]], f, target,
                    str(cdir / ("chart_%02d.svg" % (idx - 1))), str(cdir / ("chart_%02d.png" % idx)))
            charts.append({"name": "scatter_%s_%s" % (target, f), "type": "scatter",
                           "svg": s, "png": p, "description": "%s 与 %s 散点" % (target, f)})
    hist_col = target if target_numeric else (numeric_cols[0] if numeric_cols else None)
    if hist_col:
        s, p = nxt("svg"), nxt("png")
        histogram("Histogram: %s" % hist_col, [r.get(hist_col) for r in clean_ds["rows"]], hist_col,
                  str(cdir / ("chart_%02d.svg" % (idx - 1))), str(cdir / ("chart_%02d.png" % idx)))
        charts.append({"name": "histogram_%s" % hist_col, "type": "histogram",
                       "svg": s, "png": p, "description": "%s 直方图" % hist_col})
    return charts


def _make_conclusions(desc, group, group_col, target, target_numeric, numeric_cols, reg, corr, src, q):
    out = []
    if desc:
        first = list(desc.keys())[0]
        v = desc[first]
        out.append({"statement": "列 %s 描述统计：n=%s, mean=%s, sd=%s" % (first, v["n"], v["mean"], v["sd"]),
                    "metric": "descriptive", "column": first, "values": v, "source": src,
                    "locator": "rows 1..%d" % v["n"], "quote": q})
    if group:
        tc = target if target_numeric else (numeric_cols[0] if numeric_cols else None)
        t = (group.get("tests") or {}).get(tc) if tc else None
        if t and t.get("anova"):
            a, kw = t["anova"], t.get("kruskal_wallis") or {}
            out.append({"statement": "分组变量 %s 在 %s 上组间差异：ANOVA F=%s, p=%s；Kruskal-Wallis H=%s, p=%s"
                        % (group_col, tc, a.get("F"), a.get("p"), kw.get("H"), kw.get("p")),
                        "metric": "group_comparison", "column": tc, "anova": a, "kruskal_wallis": kw,
                        "levene": t.get("levene"), "source": src, "locator": "group_column=%s" % group_col,
                        "quote": q})
    if reg and reg.get("models"):
        m = reg["models"][0]
        out.append({"statement": "%s 对 %s 的线性回归：slope=%s, intercept=%s, R^2=%s"
                    % (m["feature"], target, m["slope"], m["intercept"], m["r_squared"]),
                    "metric": "regression", "feature": m["feature"], "slope": m["slope"],
                    "intercept": m["intercept"], "r_squared": m["r_squared"], "source": src,
                    "locator": "columns %s vs %s" % (m["feature"], target), "quote": q})
    if corr and corr.get("top_pairs"):
        tp = corr["top_pairs"][0]
        out.append({"statement": "最强相关：%s 与 %s，r=%s, p=%s" % (tp["x"], tp["y"], tp["r"], tp["p"]),
                    "metric": "correlation", "x": tp["x"], "y": tp["y"], "r": tp["r"], "p": tp["p"],
                    "source": src, "locator": "columns %s,%s" % (tp["x"], tp["y"]), "quote": q})
    return out


def run(input_dir, work_dir, output_dir, case, work_json):
    R = {"status": "partial", "errors": [], "degradations": [], "gaps": [], "sources": [],
         "uncertainty": [], "change_records": [], "products": {}, "descriptive": {}, "tests": {},
         "correlation": {}, "regression": {}, "charts": [], "quality": {}, "conclusions": [],
         "cleaning": {}, "report": None}
    tm = input_dir / "task.md"
    task = tm.read_text(encoding="utf-8", errors="replace") if tm.exists() else ""
    files = find_data_files(input_dir)
    if not files:
        R.update({"status": "insufficient_evidence",
                  "gaps": ["no readable data files under input dir"],
                  "uncertainty": ["analysis skipped: no data material"]})
        return R
    datasets = []
    for f in files:
        fn = EXT_MAP.get(f.suffix.lower())
        if not fn:
            continue
        try:
            d = fn(f)
            if d and d.get("rows"):
                datasets.append(d)
            elif d:
                R["gaps"].append("empty material: %s" % f.name)
        except Exception as e:  # noqa: BLE001
            R["errors"].append("read %s: %s" % (f.name, e))
    if not datasets:
        R.update({"status": "insufficient_evidence",
                  "gaps": ["no datasets could be loaded"],
                  "uncertainty": ["analysis skipped: unreadable material"]})
        return R
    ds = max(datasets, key=lambda d: len(d.get("rows") or []))
    prof = profile(ds)
    cfg = dict({"drop_duplicates": True, "impute": "median", "outlier_rule": "iqr1.5"},
               **(work_json or {}).get("clean", {}))
    clean_ds, rules, changes, outliers = clean(ds, prof, cfg)
    identifier_names = {"id", "row_id", "sample_id", "subject_id", "patient_id",
                        "record_id", "index", "sample"}
    numeric_cols = [c for c in ds["columns"] if prof[c]["type"] == "numeric"
                    and c.strip().lower() not in identifier_names]
    excluded_ids = [c for c in ds["columns"] if prof[c]["type"] == "numeric"
                    and c.strip().lower() in identifier_names]
    if excluded_ids:
        R["uncertainty"].append("数值标识列未参与推断统计: %s" % ", ".join(excluded_ids))
    target = _detect_target(ds, prof, work_json or {})
    group_col = _detect_group(ds, prof, work_json or {})
    desc = descriptive(clean_ds, prof)
    group = group_analysis(clean_ds, prof, group_col, numeric_cols) if group_col else None
    target_numeric = target is not None and prof.get(target, {}).get("type") == "numeric"
    corr = correlation(clean_ds, prof, numeric_cols, target if target_numeric else None)
    reg = regression(clean_ds, target, numeric_cols) if target_numeric else None
    charts = _make_charts(clean_ds, prof, group, group_col, target, target_numeric, numeric_cols, reg, output_dir)
    src = ds["source"]
    conclusions = _make_conclusions(desc, group, group_col, target, target_numeric, numeric_cols, reg, corr, src, _quote(ds, 0))
    quality = {"input_file": src, "kind": ds["kind"], "rows_original": len(ds["rows"]),
               "rows_after_clean": len(clean_ds["rows"]), "columns": ds["columns"], "column_types": prof,
               "duplicates_removed": next((c["rows_removed"] for c in changes if c["step"] == "drop_duplicates"), 0),
               "missing_imputed": {c["column"]: c["rows_changed"] for c in changes if "impute" in c["step"]},
               "outliers": {k: {"count": v["count"], "lower": v["lower"], "upper": v["upper"]}
                            for k, v in outliers.items()}}
    write_cleaned_csv(output_dir / "cleaned_data.csv", clean_ds)
    write_json_io(output_dir / "cleaning_rules.json", {"rules": rules, "changes": changes})
    write_json_io(output_dir / "stats.json", {"descriptive": desc, "tests": group,
                                              "correlation": corr, "regression": reg})
    write_json_io(output_dir / "quality_report.json", quality)
    write_json_io(output_dir / "evidence.json", conclusions)
    with open(output_dir / "raw_snapshot.jsonl", "w", encoding="utf-8") as fh:
        for i, r in enumerate(ds["rows"]):
            fh.write(json.dumps({"source": src, "locator": "row %d" % (i + 1), "values": r,
                                 "quote": _quote(ds, i)}, ensure_ascii=False, default=str) + "\n")
    (output_dir / "report.md").write_text(
        build_report(case, ds, clean_ds, prof, rules, desc, group, corr, reg, charts,
                     conclusions, quality), encoding="utf-8")
    products = {"cleaned_data": "cleaned_data.csv", "cleaning_rules": "cleaning_rules.json",
                "stats": "stats.json", "quality_report": "quality_report.json", "report": "report.md",
                "evidence": "evidence.json", "raw_snapshot": "raw_snapshot.jsonl"}
    uncertainty = ["推断统计基于经典假设；独立性假设无法仅从数据本身完全校验",
                   "异常值仅按所选规则标记、不静默删除；缺失值按用户选择的策略处理并记录",
                   "SQLite/XLSX 的逐字 quote 为数据库/单元存储值序列化文本"]
    if len(datasets) > 1:
        uncertainty.append("存在 %d 个数据文件，仅对行数最多的主数据文件分析" % len(datasets))
    uncertainty = list(R["uncertainty"]) + uncertainty
    R.update({"status": "success" if not R["errors"] else "partial",
              "sources": [{"source": src, "kind": ds["kind"], "columns": ds["columns"],
                           "rows": len(ds["rows"]), "locator": "whole file"}],
              "uncertainty": uncertainty, "change_records": changes, "products": products,
              "data_profile": prof, "descriptive": desc, "tests": group, "correlation": corr,
              "regression": reg, "charts": charts, "quality": quality, "conclusions": conclusions,
              "cleaning": {"rules": rules, "summary": quality}, "report": "report.md"})
    (output_dir / "log.txt").write_text(
        "loaded %d datasets; primary=%s rows=%d; target=%s; group=%s; charts=%d\n"
        % (len(datasets), src, len(ds["rows"]), target, group_col, len(charts)), encoding="utf-8")
    return R

def write_json_io(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")


def write_cleaned_csv(path, ds):
    cols = ds["columns"]
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(cols)
        for r in ds["rows"]:
            w.writerow(["" if r.get(c) is None else r.get(c) for c in cols])


def build_report(case, ds, clean_ds, prof, rules, desc, group, corr, reg, charts,
                 conclusions, quality):
    L = ["# 数据分析报告", "", "**case_id**: %s" % case["case_id"],
         "**数据文件**: %s（%s，原始 %d 行 → 清洗后 %d 行）" % (
             ds["source"], ds["kind"], len(ds["rows"]), len(clean_ds["rows"])),
         "## 1. 数据概况", ""]
    for c in ds["columns"]:
        p = prof[c]
        L.append("- %s: type=%s, missing=%d, unique=%d" % (c, p["type"], p["missing"], p["unique"]))
    L += ["", "## 2. 清洗规则", ""]
    for r in rules:
        L.append("- %s %s %s: %s" % (r["id"], r["rule"], r.get("column", ""),
                                     json.dumps({k: v for k, v in r.items()
                                                 if k not in ("id", "rule", "column", "quote")},
                                                ensure_ascii=False, default=str)))
    L += ["", "## 3. 描述统计", "", "| 列 | n | mean | sd | min | median | max |", "|-|-|-|-|-|-|-|"]
    for c, v in desc.items():
        L.append("| %s | %s | %s | %s | %s | %s | %s |" % (c, v["n"], v["mean"], v["sd"],
                                                           v["min"], v["median"], v["max"]))
    if group:
        L += ["", "## 4. 组间比较（分组列：%s）" % group["group_column"], ""]
        for c, t in group["tests"].items():
            a, kw = t.get("anova"), t.get("kruskal_wallis")
            if a:
                L.append("- %s: ANOVA F=%s, p=%s, eta2=%s; Kruskal-Wallis H=%s, p=%s" % (
                    c, a.get("F"), a.get("p"), a.get("eta_squared"), kw.get("H"), kw.get("p")))
    if reg and reg.get("models"):
        L += ["", "## 5. 回归（目标：%s）" % reg.get("target", ""), "", "| 特征 | slope | intercept | R2 |",
              "|-|-|-|-|"]
        for m in reg["models"]:
            L.append("| %s | %s | %s | %s |" % (m["feature"], m["slope"], m["intercept"], m["r_squared"]))
    if corr and corr.get("top_pairs"):
        L += ["", "## 6. 相关性（最强若干对）", "", "| x | y | r | p |", "|-|-|-|-|"]
        for t in corr["top_pairs"][:10]:
            L.append("| %s | %s | %s | %s |" % (t["x"], t["y"], t["r"], t["p"]))
    L += ["", "## 7. 图", ""]
    for ch in charts:
        L.append("- %s: [SVG](%s) · [PNG](%s) — %s" % (ch["name"], ch["svg"], ch["png"], ch["description"]))
    L += ["", "## 8. 结论（含证据定位）", ""]
    for c in conclusions:
        L.append("- %s（source=%s, locator=%s）" % (c["statement"], c.get("source"), c.get("locator")))
    L += ["", "## 9. 不确定性与限制", "",
          "- 推断统计基于经典假设，独立性假设无法仅从数据本身校验",
          "- 异常值按 IQR1.5 标记未删除；缺失值按中位数/众数填补并记录",
          "- 本报告数字与 stats.json / cleaned_data.csv 同源，可回算"]
    return "\n".join(L) + "\n"


# 方法与统计口径参考

## 数据读取
- CSV/TSV/TXT：csv.Sniffer 自动识别分隔符与表头，编码按 utf-8-sig → utf-8 → gbk → latin-1 顺序回退。
- JSON：读取对象数组（或 dict 中首个对象数组），字段并集为列。
- SQLite：只读连接，取第一个业务表，列名来自游标 description。
- XLSX：zipfile + xml 解析 sharedStrings 与 sheet1 单元值。

## 类型判定
- numeric：非空值中 ≥80% 可转 float。
- categorical：非空唯一值 ≤12 且（数值列需为整数且唯一值占比 <0.3）。
- 其余为 string。

## 清洗规则（优先级）
1. R1 drop_exact_duplicates：按行内容（JSON 序列化）完全重复去重，保留首条，记录行号与原文。
2. R2 median_impute（数值）/ mode_impute（类别）：缺失值填补，记录列、行号、填补值。
3. R3 flag_outliers_iqr1.5：数值列按 [Q1−1.5·IQR, Q3+1.5·IQR] 标记异常（不删除），记录上下界与行号。

## 统计方法
- 描述统计：n、mean、sd、min/q1/median/q3/max、偏度（Fisher-Pearson g1）、峰度（超额峰度 g2）。
- 正态性：Jarque-Bera（JB = n/6·(g1² + g2²/4)，p 值取 χ²(2)）。
- 方差齐性：Levene（对 |x − 组中位数| 做 ANOVA）。
- 两组比较：Welch t（不等方差）与 p 值（t 分布）。
- 多组比较：单因素 ANOVA（F 与 η²）、Kruskal-Wallis（H，带结校正）、≤4 组时全部两两 Welch t（未做多重比较校正，需人工按 Bonferroni 解读，报告中注明）。
- 相关：Pearson r 与 p 值（t 分布）。
- 回归：最小二乘一元线性回归（slope/intercept/R²）。

## p 值分布函数（纯标准库实现）
- 正态 CDF/SF：math.erf / math.erfc。
- t、F、不完全 beta：连分式（Lentz）＋ Lanczos log-gamma。
- χ²：Wilson–Hilferty 正态近似（df≥2 时相对误差 <1%）。

## 证据规范
- 每个结论含 source（材料路径）、locator（行号/表名/列名）、quote（材料原文逐字片段）。
- CSV 引用原始行文本；SQLite/XLSX 引用序列化的单元存储值。
- 计算值只作派生结果，引用原始输入 quote + 规则，不冒充原文。

# 统计方法速查（references/methods.md）

本 Skill 采用纯 Python 标准库实现，所有检验/分布函数可复核；如运行时提供 `scipy`，正态性检验自动改用 `scipy.stats.shapiro`。

## 分布函数（statslib.py）
- 正则化不完全 beta `betai`（连分式，Numerical Recipes）→ t 分布、F 分布、beta。
- 正则化不完全 gamma `gammp`（级数+连分式）→ χ² 分布。
- `norm_ppf` 采用 Acklam 近似；`norm_cdf` 用 `math.erf`。
- `t_ppf` 二分求根；`t_sf/f_sf/chisq_sf` 为尾概率。

## 检验与选择
| 设计 | 假设成立 | 假设不成立 |
|---|---|---|
| 两独立样本 | Student t（等方差） | Welch t（不等方差）/ Mann-Whitney U（非正态） |
| 多样本 | 单因素 ANOVA | Kruskal-Wallis |
| 方差齐性 | Levene（median 中心，Brown-Forsythe） | — |
| 正态性 | Shapiro-Wilk（scipy）或 D'Agostino-Pearson（回退） | — |

## 效应量与幅度
- Cohen's d：|d| <0.2 极小、<0.5 小、<0.8 中、≥0.8 大；Hedges' g 为小样本校正。
- η²：<0.01 小、<0.06 中、≥0.06 大；ω² 为校正。
- Kruskal-Wallis ε² = (H - k + 1)/(n - k)，阈值同 η²。

## 置信区间
- 均值/均值差：t 界（Welch-Satterthwaite 自由度）。
- Cohen's d：Hedges-Olkin 近似标准误 ± z·se。
- Pearson r：Fisher z 变换。

## 多重比较
- 事后两两 Mann-Whitney U + Holm 校正（拒绝更保守，控制 FWER）。

## 清洗判据
- 缺失：空串/NA/nan/null/?/-/. 等 token；成对删除并记录比例。
- 异常：IQR 1.5 倍规则，仅标记不删除（结论对异常值敏感需人工确认）。
- 重复：整行完全一致去重，保留首条。
- 类型/单位：`to_number` 剥离千分位、单位后缀（μg/mg/%）再转数值。

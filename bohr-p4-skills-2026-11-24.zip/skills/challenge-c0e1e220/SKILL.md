---
name: statistical-analysis
description: 科研数据统计分析 Skill：对 CSV/TSV/SQLite 数据完成清洗（缺失值、异常值、重复记录、类型/单位转换）并做描述统计、假设检验、推断统计、效应量与置信区间，输出可复核的结果与证据定位。适用于带分组比较、相关或回归问题的科研测量/问卷/临床/组学数据。
version: 1.0.0
---

# statistical-analysis

## 用途
把带噪声的科研数据表处理到可统计状态，并交付一组可与数据字典、规则和任务对得上的结果：清洗表、描述统计、推断统计（含正态性/方差齐性假设检验与方法选择）、效应量、置信区间与结果解释。只依赖 Python 标准库（`csv/json/sqlite3/statistics/math` 与可选 `matplotlib`；若平台提供 `scipy` 则正态性用 `scipy.stats.shapiro`，否则回退 D'Agostino-Pearson），不联网，确定性运行。

## 触发条件
- 输入目录存在 `case.json`（含 `case_id`、`output_contract`、`task_instruction`）与数据材料（`.csv/.tsv/.db/.sqlite/.sqlite3`），并通常伴随 `task.md`。
- 任务要求：数据清洗、描述统计、组间比较、相关、回归或结果解释中的任意一项。
- 不适用：实验方案设计、样本量估算、论文写作（超出本题范围）。

## 调用方式
```bash
python scripts/main.py                    # 完整流程（默认 /input -> /app/work -> /app/output）
python scripts/main.py --help             # 用法
python scripts/main.py show               # 列出输入目录文件
python scripts/main.py check              # 环境自检
python scripts/main.py build              # 完整流程别名
python scripts/main.py init               # 完整流程别名
```
环境变量覆盖：`INPUT_DIR`、`WORK_DIR`、`OUTPUT_DIR`（等价参数 `--input/--work/--output`）。默认值保持平台路径。退出码恒为 0。脚本不依赖当前工作目录（`Path(__file__)` 定位）。

## 输入
- `/input/case.json`：`case_id`、`output_contract`（dict 或 list）、`task_instruction`。
- `/input/task.md`：任务说明（可选，缺失时回退 case.json 的 task_instruction）。
- `/input/*.csv|.tsv|.db|.sqlite|.sqlite3`：数据材料（SQLite 取第一个非系统表）。
- 可选数据字典（文件名含 dict/schema/field/codebook）。

## 输出（写入 /app/output）
- `result.json`：必含 `case_id`、`status`、`sources`、`uncertainty`、`change_records`、`errors`、`degradations`、`analysis`、`artifacts`、`_meta`，并回填 `output_contract` 的每个字段（缺失填 null/[]）。先写 partial 再 finalize。
- `cleaned_<源>.csv`：去重后的清洗表（UTF-8-sig）。
- `quality_<源>.json`：数据质量报告（缺失/异常/重复/字段类型/图表选择）。
- `run.log`：运行日志与变更记录。

## 工作稿 schema
`analysis` 内：`descriptive`（每数值列 n/mean/sd/se/median/q1/q3/iqr/min/max/skewness/kurtosis/ci95）、`assumptions`（每列 normality、levene、all_normal、equal_variance）、`inference`（方法、统计量、df、p）、`effect_size`、`confidence_interval`、`interpretation`（中文结论）、`correlations`、`post_hoc`、`quality`、`_evidence`。每列附 `_source`/`_locator`。

## 证据规范
每个结论/元素带 `source`（源文件）+ `locator`（`file:column=…` 或行范围）+ `quote`（原文逐字摘录，可命中源文件）。`result.json.sources` 存各输入文件前两行/前 200 字符的逐字引文。

## 方法选择规则
- 两样本：正态且方差齐 → Student t；正态但方差不齐 → Welch t；非正态 → Mann-Whitney U。
- 多样本：正态且方差齐 → 单因素 ANOVA + Tukey 风格事后 Mann-Whitney + Holm 校正；否则 → Kruskal-Wallis。
- 效应量：两样本 Cohen's d / Hedges' g；ANOVA η² / ω²；Kruskal-Wallis ε²。
- 置信区间：均值/均值差用 t 界；相关用 Fisher z 变换；d 用近似标准误。
- 异常值：IQR 1.5 倍规则，仅标记不删除。缺失值：成对删除并记录比例。

## 降级表
| 情况 | status | 处理 |
|---|---|---|
| 无数据文件 | insufficient_evidence | 合法 partial + gaps + degradations |
| 空表/无法解析 | insufficient_evidence | 同上 |
| 坏 JSON case.json | 读取失败则按无 case.json 处理，case_id=unknown，数据仍分析 | 不崩溃 |
| 组内样本 <2 / 方差为 0 | partial | inference 置 null，解释注明需人工确认 |
| matplotlib 不可用 | complete | 图表省略，quality 注明图表选择 |
| 异常 | input_error/partial | 捕获并写入 errors/degradations，退出码 0 |

## 自检
- `python scripts/main.py --help` 退出 0。
- 空输入/坏 JSON/缺材料各产出合法 result.json（status=insufficient_evidence/input_error/partial）。
- 两次全新输出目录运行产物结构一致（时间戳取输入文件 mtime，确定性）。
- 统计量抽查：`norm_ppf(0.975)=1.959964`、`t_sf(2.228,10)≈0.025`、`chisq_sf(3.84,1)≈0.05`。

## 限制
- 仅 CSV/TSV/SQLite（及最小 xlsx 支持）；DOCX/图片仅作为文本材料，不解析。
- 正态性回退实现（D'Agostino-Pearson）对低峰态数据可能保守；平台有 scipy 时优先 Shapiro-Wilk。
- 字段单位与类型从原始字符串推断，无数据字典时可能不完整，需人工确认。
- 相关/回归仅覆盖双变量 Pearson（相关）路径；配对设计与复杂模型不在范围。

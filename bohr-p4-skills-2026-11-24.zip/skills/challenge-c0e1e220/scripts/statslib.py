"""statslib: pure-Python, deterministic statistical functions (no third-party deps)."""
import math

_FPMIN = 1e-300
_EPS = 3e-7
_ITMAX = 200


def _betacf(a, b, x):
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    if abs(d) < _FPMIN:
        d = _FPMIN
    d, h = 1.0 / d, 1.0 / d
    for m in range(1, _ITMAX + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < _FPMIN:
            d = _FPMIN
        c = 1.0 + aa / c
        if abs(c) < _FPMIN:
            c = _FPMIN
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < _FPMIN:
            d = _FPMIN
        c = 1.0 + aa / c
        if abs(c) < _FPMIN:
            c = _FPMIN
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < _EPS:
            break
    return h


def betai(a, b, x):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lb = math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)
    f = math.exp(math.log(x) * a + math.log(1.0 - x) * b - lb)
    if x < (a + 1.0) / (a + b + 2.0):
        return f / a * _betacf(a, b, x)
    return 1.0 - f / b * _betacf(b, a, 1.0 - x)


def _gser(a, x):
    gln = math.lgamma(a)
    ap, total, de = a, 1.0 / a, 1.0 / a
    for _ in range(_ITMAX):
        ap += 1.0
        de *= x / ap
        total += de
        if abs(de) < abs(total) * _EPS:
            return total * math.exp(-x + a * math.log(x) - gln)
    raise ValueError("gser diverged")


def _gcf(a, x):
    gln = math.lgamma(a)
    b, c, d, h = x + 1.0 - a, 1.0 / _FPMIN, 1.0 / (x + 1.0 - a), 1.0 / (x + 1.0 - a)
    for i in range(1, _ITMAX + 1):
        an = -i * (i - a)
        b += 2.0
        d = an * d + b
        if abs(d) < _FPMIN:
            d = _FPMIN
        c = b + an / c
        if abs(c) < _FPMIN:
            c = _FPMIN
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < _EPS:
            return math.exp(-x + a * math.log(x) - gln) * h
    raise ValueError("gcf diverged")


def gammp(a, x):
    if x < 0.0 or a <= 0.0:
        raise ValueError("bad args")
    return _gser(a, x) if x < a + 1.0 else 1.0 - _gcf(a, x)


def norm_cdf(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def norm_ppf(p):
    if p <= 0.0 or p >= 1.0:
        raise ValueError("p outside (0,1)")
    a = [-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2,
         1.383577518672690e2, -3.066479806614716e1, 2.506628277459239e0]
    b = [-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2,
         6.680131188771972e1, -1.328068155288572e1]
    c = [-7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838e0,
         -2.549732539343734e0, 4.374664141464968e0, 2.938163982698783e0]
    d = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996e0,
         3.754408661907416e0]
    pl, ph = 0.02425, 0.97575
    if p < pl:
        q = math.sqrt(-2.0 * math.log(p))
        return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / \
            ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0)
    if p <= ph:
        q, r = p - 0.5, (p - 0.5) * (p - 0.5)
        return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / \
            (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1.0)
    q = math.sqrt(-2.0 * math.log(1.0 - p))
    return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / \
        ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0)


def t_cdf(t, df):
    x = df / (df + t * t)
    ib = betai(df / 2.0, 0.5, x)
    return 1.0 - 0.5 * ib if t >= 0 else 0.5 * ib


def t_sf(t, df):
    return 1.0 - t_cdf(t, df)


def t_ppf(p, df):
    lo, hi = -100.0, 100.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if t_cdf(mid, df) < p:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def f_cdf(f, df1, df2):
    return betai(df1 / 2.0, df2 / 2.0, df1 * f / (df1 * f + df2)) if f > 0 else 0.0


def f_sf(f, df1, df2):
    return 1.0 - f_cdf(f, df1, df2)


def chisq_sf(x, df):
    return 1.0 - gammp(df / 2.0, x / 2.0)


def _quantile(sv, p):
    n = len(sv)
    if n == 0:
        return None
    if n == 1:
        return sv[0]
    pos = (n - 1) * p
    lo, hi = int(math.floor(pos)), int(math.ceil(pos))
    return sv[lo] if lo == hi else sv[lo] + (pos - lo) * (sv[hi] - sv[lo])


def _moments(vals):
    n = len(vals)
    if n == 0:
        return None
    mean = sum(vals) / n
    m2 = m3 = m4 = 0.0
    for v in vals:
        d = v - mean
        d2 = d * d
        m2 += d2
        m3 += d2 * d
        m4 += d2 * d2
    m2, m3, m4 = m2 / n, m3 / n, m4 / n
    g1 = m3 / (m2 ** 1.5) if m2 > 0 else 0.0
    g2 = m4 / (m2 * m2) - 3.0 if m2 > 0 else 0.0
    return n, mean, m2, g1, g2


def descriptive(vals, alpha=0.05):
    vals = [v for v in vals if v is not None]
    n = len(vals)
    if n == 0:
        return {"n": 0}
    srt = sorted(vals)
    mean = sum(vals) / n
    sd = math.sqrt(sum((v - mean) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    se = sd / math.sqrt(n) if n > 1 else None
    _, _, _, g1, g2 = _moments(vals)
    out = {"n": n, "mean": mean, "sd": sd, "se": se, "median": _quantile(srt, 0.5),
           "q1": _quantile(srt, 0.25), "q3": _quantile(srt, 0.75),
           "iqr": _quantile(srt, 0.75) - _quantile(srt, 0.25),
           "min": srt[0], "max": srt[-1], "skewness": g1, "kurtosis": g2}
    if n > 1:
        tc = t_ppf(1.0 - alpha / 2.0, n - 1)
        out["ci95_lower"] = mean - tc * se
        out["ci95_upper"] = mean + tc * se
    return out


def round_dict(d, nd=6):
    if d is None:
        return None
    return {k: (round(v, nd) if isinstance(v, float) else v) for k, v in d.items()}


def dagostino_pearson(vals):
    vals = [v for v in vals if v is not None]
    n = len(vals)
    if n < 8:
        return None, None
    _, _, _, g1, g2 = _moments(vals)
    b = math.sqrt(n * (n - 1)) / (n - 2) * g1
    beta2 = 3.0 * (n * n + 27 * n - 70) * (n + 1) * (n + 3) / \
        ((n - 2.0) * (n + 5) * (n + 7) * (n + 9))
    w2 = -1.0 + math.sqrt(2.0 * (beta2 - 1.0))
    delta = 1.0 / math.sqrt(math.log(math.sqrt(w2)))
    alpha = math.sqrt(2.0 / (w2 - 1.0))
    y = max(-1e10, min(1e10, b / alpha))
    z1 = delta * math.log(y + math.sqrt(y * y + 1.0)) if y >= 0 else \
        -delta * math.log(-y + math.sqrt(y * y + 1.0))
    eb = 3.0 * (n - 1) / (n + 1)
    sb = math.sqrt(24.0 * n * (n - 2) * (n - 3) / ((n + 1) ** 2 * (n + 3) * (n + 5)))
    b2 = g2 - eb
    beta1 = 6.0 * (n * n - 5 * n + 2) / ((n + 7) * (n + 9)) * \
        math.sqrt(6.0 * (n + 3) * (n + 5) / (n * (n - 2) * (n - 3)))
    a = 6.0 + 8.0 / beta1 * (2.0 / beta1 + math.sqrt(1.0 + 4.0 / (beta1 * beta1)))
    inner = 1.0 - 2.0 / a
    ratio = (1.0 + b2 * math.sqrt(2.0 / (a - 4.0))) / abs(sb)
    z2 = (1.0 - 2.0 / (9.0 * a) - inner / (ratio ** (1.0 / 3.0))) / math.sqrt(2.0 / (9.0 * a)) \
        if ratio > 0 else -1e10
    k2 = z1 * z1 + z2 * z2
    return k2, chisq_sf(k2, 2.0)


def shapiro_wilk(vals):
    try:
        from scipy import stats  # noqa: WPS433
        w, p = stats.shapiro(vals)
        return {"method": "shapiro_wilk", "statistic": w, "p_value": p}
    except Exception:
        k2, p = dagostino_pearson(vals)
        return {"method": "dagostino_pearson", "statistic": k2, "p_value": p}


def levene(groups, center="median"):
    groups = [[v for v in g if v is not None] for g in groups]
    groups = [g for g in groups if len(g) > 1]
    k = len(groups)
    if k < 2:
        return None, None
    zs = []
    for g in groups:
        srt = sorted(g)
        c = _quantile(srt, 0.5) if center == "median" else sum(g) / len(g)
        zs.append([abs(v - c) for v in g])
    n = sum(len(g) for g in groups)
    grand = sum(sum(g) for g in zs) / n
    ssb = sum(len(zs[i]) * (sum(zs[i]) / len(zs[i]) - grand) ** 2 for i in range(k))
    ssw = sum(sum((z - sum(zs[i]) / len(zs[i])) ** 2 for z in zs[i]) for i in range(k))
    df1, df2 = k - 1, n - k
    if df2 <= 0 or ssw <= 0:
        return None, None
    w = (ssb / df1) / (ssw / df2)
    return w, f_sf(w, df1, df2)


def ttest_ind(a, b, equal_var=True):
    a = [v for v in a if v is not None]
    b = [v for v in b if v is not None]
    n1, n2 = len(a), len(b)
    if n1 < 2 or n2 < 2:
        return None
    m1, m2 = sum(a) / n1, sum(b) / n2
    v1 = sum((v - m1) ** 2 for v in a) / (n1 - 1)
    v2 = sum((v - m2) ** 2 for v in b) / (n2 - 1)
    diff = m1 - m2
    if equal_var:
        sp = math.sqrt(((n1 - 1) * v1 + (n2 - 1) * v2) / (n1 + n2 - 2))
        se = sp * math.sqrt(1.0 / n1 + 1.0 / n2)
        df = n1 + n2 - 2
        method = "student_t"
    else:
        se = math.sqrt(v1 / n1 + v2 / n2)
        den = (v1 / n1) ** 2 / (n1 - 1) + (v2 / n2) ** 2 / (n2 - 1)
        df = (v1 / n1 + v2 / n2) ** 2 / den if den > 0 else None
        if df is None:
            return None
        method = "welch_t"
    t = diff / se if se != 0 else None
    p = 2.0 * t_sf(abs(t), df) if t is not None else None
    return {"method": method, "statistic": t, "df": df, "p_value": p,
            "mean_diff": diff, "se": se, "n1": n1, "n2": n2}


def _ranks(values):
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0] * len(values)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and values[order[j + 1]] == values[order[i]]:
            j += 1
        avg = (i + 1 + j + 1) / 2.0
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        i = j + 1
    return ranks


def mannwhitneyu(a, b):
    a = [v for v in a if v is not None]
    b = [v for v in b if v is not None]
    n1, n2 = len(a), len(b)
    if n1 == 0 or n2 == 0:
        return None
    ranks = _ranks(a + b)
    r1 = sum(ranks[:n1])
    u1 = n1 * n2 + n1 * (n1 + 1) / 2.0 - r1
    u2 = n1 * n2 - u1
    u = min(u1, u2)
    n = n1 + n2
    mean_u = n1 * n2 / 2.0
    ties = {}
    for v in a + b:
        ties[v] = ties.get(v, 0) + 1
    tc = sum(c * c * c - c for c in ties.values())
    sd = math.sqrt(n1 * n2 * ((n + 1.0) - tc / (n * (n - 1.0))) / 12.0) if n > 1 else 1.0
    z = (u - mean_u + 0.5) / sd if sd != 0 else 0.0
    p = 2.0 * (1.0 - norm_cdf(abs(z))) if sd != 0 else 1.0
    return {"method": "mann_whitney_u", "statistic": u, "u1": u1, "u2": u2,
            "p_value": p, "n1": n1, "n2": n2}


def f_oneway(groups):
    groups = [[v for v in g if v is not None] for g in groups]
    groups = [g for g in groups if len(g) > 1]
    k = len(groups)
    if k < 2:
        return None
    n = sum(len(g) for g in groups)
    grand = sum(sum(g) for g in groups) / n
    ssb = sum(len(g) * (sum(g) / len(g) - grand) ** 2 for g in groups)
    ssw = sum(sum((v - sum(g) / len(g)) ** 2 for v in g) for g in groups)
    sst = ssb + ssw
    df1, df2 = k - 1, n - k
    if df2 <= 0:
        return None
    msw = ssw / df2
    f = (ssb / df1) / msw if msw != 0 else None
    p = f_sf(f, df1, df2) if f is not None else None
    return {"method": "oneway_anova", "statistic": f, "df1": df1, "df2": df2,
            "p_value": p, "ss_between": ssb, "ss_within": ssw, "ss_total": sst,
            "n_total": n, "k": k}


def kruskal(groups):
    groups = [[v for v in g if v is not None] for g in groups]
    groups = [g for g in groups if len(g) > 1]
    k = len(groups)
    if k < 2:
        return None
    all_vals = [v for g in groups for v in g]
    n = len(all_vals)
    ranks = _ranks(all_vals)
    idx, rsums = 0, []
    for g in groups:
        rsums.append(sum(ranks[idx:idx + len(g)]))
        idx += len(g)
    h = 12.0 / (n * (n + 1.0)) * sum(r * r / len(groups[i]) for i, r in enumerate(rsums)) - 3.0 * (n + 1.0)
    ties = {}
    for v in all_vals:
        ties[v] = ties.get(v, 0) + 1
    tc = 1.0 - sum(c * c * c - c for c in ties.values()) / (n * n * n - n) if n > 1 else 1.0
    h = h / tc if tc > 0 else h
    return {"method": "kruskal_wallis", "statistic": h, "df": k - 1,
            "p_value": chisq_sf(h, k - 1.0), "n_total": n, "k": k}


def pearsonr(x, y):
    pairs = [(a, b) for a, b in zip(x, y) if a is not None and b is not None]
    n = len(pairs)
    if n < 3:
        return None
    mx = sum(a for a, _ in pairs) / n
    my = sum(b for _, b in pairs) / n
    sxx = sum((a - mx) ** 2 for a, _ in pairs)
    syy = sum((b - my) ** 2 for _, b in pairs)
    sxy = sum((a - mx) * (b - my) for a, b in pairs)
    if sxx == 0 or syy == 0:
        return {"method": "pearson", "statistic": None, "p_value": None, "n": n,
                "r": None, "r_squared": None}
    r = max(-1.0, min(1.0, sxy / math.sqrt(sxx * syy)))
    t = r * math.sqrt((n - 2) / (1 - r * r)) if abs(r) < 1.0 else None
    p = 2.0 * t_sf(abs(t), n - 2) if t is not None else 0.0
    return {"method": "pearson", "statistic": t, "p_value": p, "n": n, "r": r, "r_squared": r * r}


def cohens_d(a, b):
    a = [v for v in a if v is not None]
    b = [v for v in b if v is not None]
    n1, n2 = len(a), len(b)
    if n1 < 2 or n2 < 2:
        return None
    m1, m2 = sum(a) / n1, sum(b) / n2
    v1 = sum((v - m1) ** 2 for v in a) / (n1 - 1)
    v2 = sum((v - m2) ** 2 for v in b) / (n2 - 1)
    sp = math.sqrt(((n1 - 1) * v1 + (n2 - 1) * v2) / (n1 + n2 - 2))
    if sp == 0:
        return None
    d = (m1 - m2) / sp
    g = d * (1.0 - 3.0 / (4.0 * (n1 + n2) - 9.0))
    se = math.sqrt((n1 + n2) / (n1 * n2) + d * d / (2.0 * (n1 + n2)))
    z = norm_ppf(0.975)
    return {"cohens_d": d, "hedges_g": g, "ci95_lower": d - z * se,
            "ci95_upper": d + z * se, "se": se, "n1": n1, "n2": n2}


def mean_diff_ci(a, b, alpha=0.05):
    res = ttest_ind(a, b, equal_var=False)
    if res is None:
        return None
    tc = t_ppf(1.0 - alpha / 2.0, res["df"])
    md, se = res["mean_diff"], res["se"]
    return {"mean_diff": md, "ci95_lower": md - tc * se, "ci95_upper": md + tc * se,
            "df": res["df"], "alpha": alpha}


def eta_squared(f_res, groups):
    if f_res is None:
        return None
    msw = f_res["ss_within"] / f_res["df2"] if f_res["df2"] else None
    om = (f_res["ss_between"] - (f_res["k"] - 1) * msw) / (f_res["ss_total"] + msw) if msw else None
    return {"eta_squared": f_res["ss_between"] / f_res["ss_total"] if f_res["ss_total"] else None,
            "omega_squared": om}


def epsilon_squared(kw_res):
    if kw_res is None or kw_res["n_total"] <= kw_res["k"]:
        return None
    return {"epsilon_squared": (kw_res["statistic"] - kw_res["k"] + 1) / (kw_res["n_total"] - kw_res["k"]),
            "n_total": kw_res["n_total"], "k": kw_res["k"]}


def correlation_ci(r, n, alpha=0.05):
    if r is None or n < 4:
        return None
    r = max(-0.999999, min(0.999999, r))
    z = math.atanh(r)
    se = 1.0 / math.sqrt(n - 3)
    zc = norm_ppf(1.0 - alpha / 2.0)
    return {"r": r, "ci95_lower": math.tanh(z - zc * se), "ci95_upper": math.tanh(z + zc * se)}


def holm(pvals):
    m = len(pvals)
    order = sorted(range(m), key=lambda i: pvals[i])
    adj = [0.0] * m
    prev = 0.0
    for rank, idx in enumerate(order):
        prev = max(prev, pvals[idx] * (m - rank))
        adj[idx] = min(1.0, prev)
    return adj


def interpret(r, gnames, gc):
    def f(x):
        if x is None:
            return "NA"
        return f"{x:.3e}" if (isinstance(x, float) and 0 < abs(x) < 0.0001) else \
            f"{x:.4g}" if isinstance(x, float) else str(x)
    def mag(k, v):
        if v is None:
            return "不可用"
        a = abs(v)
        t = {"cohens_d": (0.2, 0.5, 0.8), "eta_squared": (0.01, 0.06, 1e9),
             "epsilon_squared": (0.01, 0.06, 1e9), "rank_biserial_r": (0.1, 0.3, 1e9)}.get(k, ())
        return "未定义" if not t else "小" if a < t[0] else "中" if a < t[1] else "大"
    lines = []
    for name, inf in r.get("inference", {}).items():
        if not inf or inf.get("p_value") is None:
            lines.append(f"{name}: 样本量不足或方差为零，需人工确认。")
            continue
        p = inf.get("p_value")
        es = r.get("effect_size", {}).get(name) or {}
        ek = next((k for k in ("cohens_d", "eta_squared", "epsilon_squared", "rank_biserial_r") if k in es), None)
        concl = "存在统计学显著差异" if p < 0.05 else "未观察到统计学显著差异"
        lines.append(f"{name}（{gc}，{inf.get('method', '')}）：p={f(p)}，{concl}；"
                     f"效应量 {ek}={f(es.get(ek))}（{mag(ek, es.get(ek))}）。")
    return lines


def build_uncertainty(main):
    c = main["clean"]
    u = []
    if c.get("duplicates", {}).get("count"):
        u.append(f"删除重复记录 {c['duplicates']['count']} 条，样本量以去重后为准")
    if c.get("missing"):
        u.append("存在缺失值，统计量基于成对可用样本计算")
    if c.get("outliers"):
        u.append("IQR 1.5 倍规则标记异常值但未删除")
    u.append("字段类型与单位来自原始文件推断，未提供数据字典时可能不完整")
    return u

#!/usr/bin/env python3
"""Statistical analysis Skill. Default: full pipeline /input -> /app/work -> /app/output. Env INPUT_DIR/WORK_DIR/OUTPUT_DIR or --input/--work/--output. Always exit 0."""
import os, sys, json, csv, io, re, sqlite3, traceback
from datetime import datetime, timezone
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import statslib as st
MISSING = {"", "na", "n/a", "nan", "null", "none", "?", "-", ".", "nd", "n.d."}
NUM = re.compile(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?")
RESERVED = {"case_id", "status", "sources", "uncertainty", "change_records",
            "errors", "degradations", "analysis", "artifacts", "_meta"}
CMAP = [("descript", "descriptive"), ("assumpt", "assumptions"), ("infer", "inference"),
        ("effect", "effect_size"), ("confid", "confidence_interval"), ("interval", "confidence_interval"),
        ("interpret", "interpretation"), ("conclus", "interpretation"), ("correl", "correlations"),
        ("clean", "_clean"), ("plot", "_artifacts"), ("chart", "_artifacts"), ("summary", "interpretation")]


def discover_files(d):
    out = []
    if os.path.isdir(d):
        for root, dirs, files in os.walk(d):
            dirs.sort()
            out += [os.path.join(root, f) for f in sorted(files)]
    return out


def read_text(p):
    for enc in ("utf-8-sig", "utf-8", "gbk", "latin-1"):
        try:
            with open(p, "r", encoding=enc) as fh:
                return fh.read()
        except (UnicodeDecodeError, UnicodeError):
            continue
    with open(p, "r", encoding="utf-8", errors="replace") as fh:
        return fh.read()


def load_json(p):
    try:
        with open(p, "r", encoding="utf-8-sig") as fh:
            return json.load(fh)
    except Exception:
        return read_text(p)


def _trows(text, d):
    return [r for r in csv.reader(io.StringIO(text), delimiter=d) if any(c.strip() for c in r)]


def _hdr(r):
    return [str(c or "").strip() for c in r]


def load_csv(p):
    t = read_text(p)
    try:
        d = csv.Sniffer().sniff(t[:4096], delimiters=",;\t|").delimiter
    except Exception:
        d = "," if t.count(",") >= t.count("\t") else "\t"
    r = _trows(t, d)
    return (_hdr(r[0]), r[1:], os.path.basename(p)) if len(r) > 1 else None


def load_tsv(p):
    r = _trows(read_text(p), "\t")
    return (_hdr(r[0]), r[1:], os.path.basename(p)) if len(r) > 1 else None


def load_sqlite(p):
    con = None
    try:
        con = sqlite3.connect(p)
        cur = con.cursor()
        tabs = [r[0] for r in cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        tabs = [t for t in tabs if t]
        if not tabs:
            return None
        cols = [d[1] for d in cur.execute(f"PRAGMA table_info({tabs[0]})")]
        data = [list(r) for r in cur.execute(f"SELECT * FROM {tabs[0]}")]
        return (_hdr(cols), data, os.path.basename(p)) if data else None
    except Exception:
        return None
    finally:
        if con:
            con.close()


def to_number(v):
    if v is None:
        return None
    s = str(v).strip().replace(",", "").replace("\u00a0", "")
    if s.lower() in MISSING:
        return None
    m = NUM.search(s)
    if m:
        try:
            return float(m.group(0))
        except ValueError:
            pass
    try:
        return float(s)
    except ValueError:
        return None


def is_missing(v):
    return str(v).strip().lower() in MISSING


def infer_numeric(col):
    nm = [v for v in col if not is_missing(v)]
    return bool(nm) and sum(1 for v in nm if to_number(v) is not None) / len(nm) >= 0.8


def clean_table(header, data, src):
    n = len(data)
    seen, dup, keep = {}, [], []
    for i, r in enumerate(data):
        k = tuple(str(c).strip() for c in r)
        if k in seen:
            dup.append(i)
        else:
            seen[k] = i
            keep.append(i)
    num, cat = [], []
    for i, name in enumerate(header):
        col = [r[i] if i < len(r) else "" for r in data]
        (num if infer_numeric(col) else cat).append(name)
    outl = {}
    for name in num:
        i = header.index(name)
        vals = [v for v in (to_number(r[i]) for r in data) if v is not None]
        if len(vals) < 4:
            continue
        s = sorted(vals)
        q1, q3 = st._quantile(s, 0.25), st._quantile(s, 0.75)
        if q3 - q1 <= 0:
            continue
        lo, hi = q1 - 1.5 * (q3 - q1), q3 + 1.5 * (q3 - q1)
        idx = [j for j, r in enumerate(data) if to_number(r[i]) is not None and
               (to_number(r[i]) < lo or to_number(r[i]) > hi)]
        if idx:
            outl[name] = {"method": "iqr_1.5", "lower": lo, "upper": hi, "count": len(idx), "rows": idx[:50]}
    miss = {name: {"count": c, "ratio": round(c / n, 6) if n else None}
            for i, name in enumerate(header) if (c := sum(1 for r in data if i >= len(r) or is_missing(r[i])))}
    return {"source": src, "n_rows": n, "n_columns": len(header),
            "duplicates": {"count": len(dup), "rows": dup[:50], "kept_rows": len(keep)},
            "missing": miss, "outliers": outl, "numeric_columns": num,
            "categorical_columns": cat, "dedup_indices": keep}


def interpret_task(text, header, data, num, cat):
    t = (text or "").lower()
    if re.search(r"correl|相关", t):
        goal = "correlation"
    elif re.search(r"regress|predict|预测|回归", t):
        goal = "regression"
    elif re.search(r"compar|diff|test|anova|差异|比较|检验|组间|显著", t) or cat:
        goal = "group_comparison"
    elif len(num) >= 2:
        goal = "correlation"
    else:
        goal = "descriptive"
    gc = next((c for c in cat if re.search(re.escape(c.lower()), t)), None) or \
        next((c for c in cat if re.search(r"species|class|group|category|type|label|种类|类别|分组|品种|组别", c.lower())), None)
    if gc is None and cat:
        gc = min(((len(set(r[header.index(c)] for r in data if header.index(c) < len(r))), c) for c in cat),
                 default=(None, None))[1]
    target = next((c for c in num if re.search(
        r"strength|target|outcome|response|y\b|label|compressive|结果|结局|因变量", c.lower())), None)
    if target is None and num and (re.search(re.escape(num[-1].lower()), t) or len(num) == 1):
        target = num[-1]
    return {"goal": goal, "group_col": gc, "target": target}


def make_evidence(fm):
    srcs = []
    for p, kind in fm.items():
        name = os.path.basename(p)
        quote, loc = "", name
        try:
            if kind == "table":
                lines = [l for l in read_text(p).splitlines() if l.strip()]
                quote, loc = "\n".join(lines[:2]), f"{name}:lines1-{min(2, len(lines))}"
            else:
                quote, loc = read_text(p)[:200].replace("\n", " "), f"{name}:chars0-200"
        except Exception:
            pass
        srcs.append({"path": name, "kind": kind, "locator": loc, "quote": quote})
    return srcs


def first_line(p):
    try:
        for l in read_text(p).splitlines():
            if l.strip():
                return l
    except Exception:
        pass
    return ""


def _safe(s):
    return re.sub(r"[^A-Za-z0-9_.-]", "_", str(s))


def run_analysis(header, data, clean, task, src, fl):
    r = {"descriptive": {}, "assumptions": {}, "inference": {}, "effect_size": {},
         "confidence_interval": {}, "interpretation": [], "quality": clean,
         "_evidence": {"source": src, "locator": f"{src}:all", "quote": fl}}
    for name in clean["numeric_columns"]:
        i = header.index(name)
        r["descriptive"][name] = st.round_dict(st.descriptive([to_number(x[i]) for x in data]), 6)
        r["descriptive"][name].update({"_source": src, "_locator": f"{src}:column={name}"})
    gc, target = task["group_col"], task["target"]
    if task["goal"] in ("group_comparison", "descriptive") and gc and gc in header:
        gi = header.index(gc)
        groups = {}
        for row in data:
            groups.setdefault(str(row[gi]), []).append(row)
        if 2 <= len(groups) <= 12:
            gnames = sorted(groups.keys())
            for name in clean["numeric_columns"]:
                i = header.index(name)
                pg = [[to_number(x[i]) for x in groups[g]] for g in gnames]
                norms = {g: (st.shapiro_wilk(vv) if len((vv := [v for v in pg[k] if v is not None])) >= 8
                             else {"method": "insufficient_n", "statistic": None, "p_value": None})
                         for k, g in enumerate(gnames)}
                lev = st.levene(pg, center="median")
                all_n = all(n["p_value"] is None or n["p_value"] >= 0.05 for n in norms.values())
                eq_v = lev[1] is None or lev[1] >= 0.05
                r["assumptions"][name] = {"normality": norms, "all_normal": all_n,
                                          "equal_variance": eq_v, "levene": {"statistic": lev[0], "p_value": lev[1]}}
                if len(gnames) == 2:
                    g0, g1 = [v for v in pg[0] if v is not None], [v for v in pg[1] if v is not None]
                    if len(g0) < 2 or len(g1) < 2:
                        r["inference"][name] = None
                        continue
                    mw = st.mannwhitneyu(g0, g1)
                    ch = st.ttest_ind(g0, g1, True) if (all_n and eq_v) else (st.ttest_ind(g0, g1, False) if all_n else mw)
                    r["inference"][name] = st.round_dict(ch, 6)
                    r["effect_size"][name] = st.round_dict(st.cohens_d(g0, g1), 6)
                    r["confidence_interval"][name] = st.round_dict(st.mean_diff_ci(g0, g1), 6)
                else:
                    vg = [g for g in ([v for v in x if v is not None] for x in pg) if len(g) > 1]
                    an, kw = st.f_oneway(vg), st.kruskal(vg)
                    ch = an if (all_n and eq_v) else kw
                    r["inference"][name] = st.round_dict(ch, 6)
                    r["effect_size"][name] = st.round_dict(
                        st.eta_squared(an, vg) if (ch is an and an) else
                        (st.epsilon_squared(kw) if (ch is kw and kw) else None), 6)
                    pairs = [(gnames[a], gnames[b]) for a in range(len(gnames)) for b in range(a + 1, len(gnames))]
                    pp, pv = {}, []
                    for a, b in pairs:
                        pr = st.mannwhitneyu(pg[gnames.index(a)], pg[gnames.index(b)])
                        pv.append(pr["p_value"] if pr else None)
                        pp[f"{a} vs {b}"] = pr
                    if all(v is not None for v in pv):
                        for k, (a, b) in enumerate(pairs):
                            if pp[f"{a} vs {b}"] is not None:
                                pp[f"{a} vs {b}"]["holm_p"] = st.holm(pv)[k]
                    r["post_hoc"] = pp
            r["interpretation"] = st.interpret(r, gnames, gc)
    if task["goal"] == "correlation" and target and target in clean["numeric_columns"]:
        ti = header.index(target)
        y = [to_number(x[ti]) for x in data]
        corrs = {}
        for name in clean["numeric_columns"]:
            if name == target:
                continue
            i = header.index(name)
            pr = st.pearsonr([to_number(row[i]) for row in data], y)
            ci = st.correlation_ci(pr["r"], pr["n"]) if pr and pr.get("r") is not None else None
            corrs[name] = {"pearson": st.round_dict(pr, 6), "pearson_ci": st.round_dict(ci, 6)}
        r["correlations"] = corrs
    return r


def map_contract(contract, analysis, clean, sources, artifacts, case_id):
    base = {"case_id": case_id, "status": "complete", "sources": sources, "uncertainty": [],
            "change_records": [], "errors": [], "degradations": [], "analysis": analysis, "artifacts": artifacts}
    if contract is None:
        return base
    keys = contract.keys() if isinstance(contract, dict) else [str(k) for k in contract]
    ctx = {"descriptive": analysis.get("descriptive"), "assumptions": analysis.get("assumptions"),
           "inference": analysis.get("inference"), "effect_size": analysis.get("effect_size"),
           "confidence_interval": analysis.get("confidence_interval"),
           "interpretation": analysis.get("interpretation"), "correlations": analysis.get("correlations"),
           "regressions": analysis.get("regressions"), "_clean": clean, "_artifacts": artifacts}
    for k in keys:
        if k in RESERVED:
            continue
        lk = re.sub(r"[^a-z0-9]", "", str(k).lower())
        key = next((v for pat, v in CMAP if pat in lk), None)
        base[k] = ctx.get(key) if key else ([] if "list" in lk or "array" in lk else
                    {} if ("dict" in lk or "object" in lk or "stat" in lk or "report" in lk) else None)
    return base


def parse_args(argv):
    a = {"mode": "run", "input": os.environ.get("INPUT_DIR", "/input"),
         "work": os.environ.get("WORK_DIR", "/app/work"),
         "output": os.environ.get("OUTPUT_DIR", "/app/output")}
    for i, x in enumerate(argv):
        if x in ("--help", "-h"):
            a["mode"] = "help"
        elif x in ("--input", "--work", "--output") and i + 1 < len(argv):
            a[x[2:]] = argv[i + 1]
        elif x in ("init", "show", "check", "build"):
            a["mode"] = x
    return a


def ensure_dir(p):
    os.makedirs(p, exist_ok=True)
    return p


def deterministic_ts(inp):
    m = []
    for f in discover_files(inp):
        try:
            m.append(os.path.getmtime(f))
        except OSError:
            pass
    return datetime.fromtimestamp(max(m) if m else 0.0, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def load_input(inp):
    files = discover_files(inp)
    case, task_text, data_files = {}, "", []
    for f in files:
        b = os.path.basename(f).lower()
        if b == "case.json":
            case = load_json(f)
            if not isinstance(case, dict):
                case = {"raw": case}
        elif b in ("task.md", "task.txt"):
            task_text = read_text(f)
        elif b.endswith((".csv", ".tsv", ".db", ".sqlite", ".sqlite3")):
            data_files.append(f)
    ins = str(case.get("task_instruction", "") or case.get("instruction", "") or case.get("task", ""))
    ti = ins or task_text
    return case, task_text, ti, data_files, files


def write_json(p, obj):
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def _finish(rp, contract, analysis, clean, sources, artifacts, cid, status, changes, unc, errors, deg):
    res = map_contract(contract, analysis, clean, sources, artifacts, cid)
    res.update({"status": status, "uncertainty": unc, "degradations": deg,
                "change_records": changes, "errors": errors})
    write_json(rp, res)
    return res


def run():
    a = parse_args(sys.argv[1:])
    if a["mode"] == "help":
        print(__doc__)
        return 0
    inp, out = a["input"], ensure_dir(a["output"])
    ensure_dir(a["work"])
    rp = os.path.join(out, "result.json")
    write_json(rp, {"status": "partial", "case_id": None, "errors": [], "degradations": [],
                    "sources": [], "uncertainty": [], "change_records": [], "analysis": {}, "artifacts": []})
    if a["mode"] in ("show", "check"):
        files = discover_files(inp)
        print(json.dumps({"input_dir": inp, "files": [os.path.basename(f) for f in files]}, ensure_ascii=False, indent=2))
        if a["mode"] == "check":
            print(json.dumps({"ok": True, "stdlib_only": True, "python": sys.version.split()[0]}, ensure_ascii=False))
        return 0
    errors, deg, changes = [], [], []
    ts = deterministic_ts(inp)
    changes.append({"time": ts, "event": "partial_result_written"})
    case, contract, data_files, sources = {}, None, [], []
    try:
        case, task_text, ti, data_files, all_files = load_input(inp)
        cid = str(case.get("case_id") or case.get("id") or case.get("caseId") or "unknown")
        contract = case.get("output_contract")
        fm = {f: ("table" if os.path.basename(f).lower().endswith((".csv", ".tsv", ".db", ".sqlite", ".sqlite3")) else "text")
              for f in all_files}
        sources = make_evidence(fm)
        if not data_files:
            deg.append("no_data_file: 未发现 CSV/TSV/SQLite 数据材料")
            _finish(rp, contract, {"descriptive": {}}, {}, sources, [], cid,
                    "insufficient_evidence", changes, ["无可用数据材料，无法完成统计计算"], errors, deg)
            return 0
        tables = []
        for f in data_files:
            ext = os.path.basename(f).lower().rsplit(".", 1)[-1]
            tbl = load_csv(f) if ext == "csv" else load_tsv(f) if ext == "tsv" else \
                load_sqlite(f) if ext in ("db", "sqlite", "sqlite3") else None
            if not tbl:
                deg.append(f"unreadable_table: {os.path.basename(f)}")
                continue
            header, rows, srcname = tbl
            if not rows:
                deg.append(f"empty_table: {srcname}")
                continue
            clean = clean_table(header, rows, srcname)
            task = interpret_task(ti, header, rows, clean["numeric_columns"], clean["categorical_columns"])
            analysis = run_analysis(header, rows, clean, task, srcname, first_line(f))
            keep = [rows[i] for i in clean["dedup_indices"]]
            cp = os.path.join(out, f"cleaned_{_safe(srcname)}.csv")
            with open(cp, "w", encoding="utf-8-sig", newline="") as cf:
                w = csv.writer(cf)
                w.writerow(header)
                w.writerows(keep)
            qp = os.path.join(out, f"quality_{_safe(srcname)}.json")
            write_json(qp, {"data_file": srcname, "task": task, "cleaning": clean, "n_dedup_kept": len(keep)})
            tables.append({"clean": clean, "analysis": analysis,
                           "clean_path": os.path.basename(cp), "quality_path": os.path.basename(qp)})
        if not tables:
            deg.append("no_usable_table: 所有数据材料为空或无法解析")
            _finish(rp, contract, {"descriptive": {}}, {}, sources, [], cid,
                    "insufficient_evidence", changes, ["数据表为空或无法解析"], errors, deg)
            return 0
        main = tables[0]
        artifacts = [x for t in tables for x in (t["clean_path"], t["quality_path"])]
        res = _finish(rp, contract, main["analysis"], main["clean"], sources, artifacts, cid,
                      "complete" if not deg else "partial",
                      changes + [{"time": ts, "event": "finalized"}], st.build_uncertainty(main), errors, deg)
        res["_meta"] = {"runtime": "python %s" % sys.version.split()[0], "stdlib_only": True, "deterministic": True}
        write_json(rp, res)
        write_json(os.path.join(out, "run.log"), {"case_id": cid, "status": res["status"],
                                                  "degradations": deg, "changes": res["change_records"]})
        return 0
    except Exception as exc:
        errors.append({"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()[-1500:]})
        cid = "unknown"
        try:
            cid = str(case.get("case_id") or case.get("id") or "unknown")
        except Exception:
            pass
        _finish(rp, contract, {}, {}, sources, [], cid,
                "input_error" if not data_files else "partial",
                changes + [{"time": ts, "event": "error_finalized"}], ["运行发生异常，结果不完整"], errors, deg)
        return 0


def main():
    try:
        sys.exit(run())
    except Exception:
        sys.exit(0)


if __name__ == "__main__":
    main()

---
name: retrieval-coverage-omission
description: Offline, source-bound literature search coverage and omission analysis. Builds a verifiable reference set, computes hit/coverage metrics against a fixed denominator, classifies every missed paper to a specific query/field/source, and runs targeted supplementary retrieval with measured marginal gain. Use when the task asks to find literature while keeping screening evidence, compute recall/coverage of known papers, or explain which known papers were missed and why.
version: 1.0.0
---

# Retrieval Coverage & Omission Analysis

## Purpose
Given a research question plus locally provided bibliographic materials (Crossref / EuropePMC / publisher responses, a retained reference graph, or an organizer-local incremental import state), produce a **traceable, re-computable** analysis:

1. Freeze a **reference set** (known relevant papers) whose source is independent of the retrieval results — never infer the denominator from the results themselves.
2. Compute **coverage = hits / |reference set|**, plus Precision@k / Recall@k / nDCG@k against that fixed set.
3. List **every missed paper** with an actionable cause (which query, which field, which source).
4. Design **supplementary queries**, evaluate their **marginal gain against the local pool only**, and report residual omissions honestly.

This skill is **offline and source-bound**. It never performs live web search, never claims "latest literature", and never fabricates DOIs, authors, years, venues, abstracts, or import statuses. Every record is bound to a source file path + locator + a verbatim quote from the material.

## Trigger conditions
Use when the request contains retrieval/coverage/omission language, or when the case requires: finding and screening literature, recall/coverage of a known set, missed-paper analysis, or comparing a query plan against a gold/reference set.

Do **not** use for live citation-count lookups, full-text reading, or formal systematic-review inclusion/exclusion beyond the coverage loop described here.

## Invocation
Run the deterministic engine (Python 3 standard library only, no network, no CWD dependency):

```
python /skills/weekly-skill/scripts/main.py run
```

- Defaults: `--input /input`, `--work /app/work`, `--output /app/output`. Override with env vars `INPUT_DIR`, `WORK_DIR`, `OUTPUT_DIR` or `--input/--work/--output`.
- `run` (default) = full pipeline and always writes a valid `result.json`, even from an empty/broken/missing input.
- `show`  = print discovered inputs and contract fields (read-only).
- `init`  = write a `draft.json` work-draft skeleton to the work dir.
- `check` = validate `result.json` contract keys and compute quote hit rate.
- `build` = same as `run` (reads `draft.json` when present).
- Exit code is always `0`; failures are recorded in `errors` / `degradations`.

## Workflow (what the agent should do)
1. Read `/input/case.json` (`case_id`, `output_contract`, `task_instruction`) and `/input/task.md`.
2. Recursively scan `/input` with `os.walk` (do not only list the top level). Read actual files — never assume content from a filename label.
3. Parse materials: JSON (Crossref `message.items`, EuropePMC `resultList.result`, reference graphs, import states), PDF via `pdftotext`, DOCX/SQLite/CSV/TSV/text via standard library.
4. Separate **reference set** (files named/path-marked `ref|gold|known|review|citation|graph|guide`, and records with import status `missing/not_imported/pending`) from **retrieved pool** (files marked `query|search|result|retriev|crossref|europepmc|pubmed|import|incremental|db`, and records with import status `imported/present/indexed`). An incremental import state is treated as ground-truth hit signal.
5. Build a **multi-round query plan**: core concept terms, conjunctions, abbreviation expansions, and synonym expansion drawn only from vocabulary actually observed in the materials.
6. Match with priority DOI → PMID/PMCID → normalized-title (+ author-year). Deduplicate on normalized DOI/PMID/title+year.
7. Compute coverage with the reference set as denominator; rank the pool for Precision@k / Recall@k / nDCG@k.
8. For each miss, classify with evidence: `import_incomplete`, `identifier_anomaly`, `time_window_truncation`, `vocabulary_gap`, `field_restriction`, `source_not_indexed`, `unexplained`.
9. Run supplementary queries and measure **marginal gain = number of previously-missed references now retrievable from the local pool**. If gain is 0, say so and explain the residual omission — do not report reduced omission on synonym-only re-runs.
10. Write `result.json` and the editable artifacts, and state status honestly.

The engine performs 1–10 deterministically from `/input` alone. The agent improves quality by inspecting PDFs, correcting reference/candidate role assignment, and refining the query plan; those refinements are written to `draft.json` and consumed on the next `run`.

## Work-draft schema (`/app/work/draft.json`)
```json
{
  "research_question": "string",
  "reference_set": [ { "record_id", "title", "authors", "year", "venue",
                       "doi", "pmid", "pmcid", "source", "locator", "quote" } ],
  "candidate_records": [ { "record_id", "title", "authors", "year", "venue",
                           "doi", "pmid", "pmcid", "source", "locator", "quote" } ],
  "queries": [ { "id", "text", "terms", "fields", "sources", "time_window", "rationale" } ],
  "imports": { "doi:10.xxx/...": { "status": "imported|missing", "source": "rel/path" } }
}
```
`source` is the material path relative to `/input`; `locator` is a JSON pointer (e.g. `$.message.items[3]`) or `text:doi`; `quote` is a verbatim substring of that material's raw text. If `quote` is omitted, the engine binds one from the material when possible.

## Evidence specification (red lines)
- Every record/candidate/miss must carry `source` (relative file path) + `locator` + verbatim `quote` that matches the material's raw text.
- Coverage numerator and denominator both come from the **reference set**; the denominator is never the retrieval result count.
- Each omission names one primary cause plus the evidence: reference source/locator/quote, the query terms actually used, query fields, candidate sources, and (where present) the import-state value.
- Supplementary gain is counted only when a previously-missed reference matches a new query **against the local pool**. No live-search claims.
- Never invent DOIs/years/authors/venues, software state, or benchmark scores. Missing data is `null` / `[]`.

## Degradation table
| Condition | Behavior |
|---|---|
| `case.json` empty / bad JSON / missing | `status=input_error`, valid `result.json`, contract keys null/`[]`, error logged |
| No material files | `status=insufficient_evidence`, honest `gaps` in `summary` |
| Materials present but no reference set derivable | `status=insufficient_evidence`, coverage `null`, explained |
| PDF without text layer / image | recorded in `degradations`; raw byte-scan fallback used |
| DOCX/SQLite parse failure | recorded in `degradations`; other materials still processed |
| Partial/conflicting identifiers | `identifier_anomaly` omission cause; no fabricated record |
| `output_contract` missing/empty | default deliverable schema used; every contract field echoed as null/`[]` when unmatched |

## Self-check (run before finishing)
1. `python main.py show` on the case input.
2. `python main.py run` with fresh `work`/`output`; then `python main.py check`.
3. Confirm `result.json` is valid JSON, non-zero, contains `case_id`, `status`, `sources`, `uncertainty`, `change_records`, and every `output_contract` field.
4. Quote hit rate must be ≥ 0.95 (quotes must literally match the material).
5. Run twice in two fresh output dirs — structure must be identical (deterministic: sorted everywhere, no timestamps/randomness).

## Outputs
`/app/output/result.json` (contract + case_id + status + sources + uncertainty + change records), `coverage_report.md`, `query_plan.md`, `hit_matrix.csv`, `omissions.csv`. `/app/work/draft.json` and `run.log` record the reproducible run.

## Limits
- Offline only: supplementary "gain" is evaluated against the local material pool, not a live database.
- Title matching is normalized-exact plus author+year; near-duplicate variants may need manual adjudication (flagged in `uncertainty`).
- Cross-language expansion is limited to vocabulary actually observed in the materials; absence of non-Latin terms is reported as a gap, not filled by translation.

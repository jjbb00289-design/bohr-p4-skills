# Omission classification taxonomy

Each missed reference is assigned exactly one **primary cause**, chosen by the first
condition with positive evidence, plus the full candidate-cause list.

| Cause | Evidence condition | Actionable fix |
|---|---|---|
| `import_incomplete` | Local incremental import state says `missing / not_imported / pending / false` | Resume the import; coverage = imported / total known |
| `identifier_anomaly` | No DOI and no PMID/PMCID on the record | Re-query by title+author+year |
| `time_window_truncation` | Reference year falls outside a query's `time_window.from/.to` | Widen the date window |
| `vocabulary_gap` | Reference title terms ∩ query terms = ∅ | Add the reference's distinctive terms as synonyms/abbreviations |
| `field_restriction` | Terms overlap but all queries are limited to `title`/`authors` | Search `abstract`/`fulltext` too |
| `source_not_indexed` | Reference's source material is not among the candidate-pool sources | Add the missing source (offline: note only) |
| `unexplained` | No positive evidence for any above | Flag for manual review |

Every classification carries: reference `source`+`locator`+verbatim `quote`, the query
terms actually used, query fields, candidate sources, and the import-state value when present.
A classification without this evidence is not valid.

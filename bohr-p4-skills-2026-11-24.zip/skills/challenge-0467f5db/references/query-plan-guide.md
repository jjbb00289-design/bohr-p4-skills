# Query-plan construction guide (offline, source-bound)

Build queries in rounds and keep every round traceable:

1. **Core concepts** — single terms and 2-term conjunctions from the research question.
2. **Abbreviation expansion** — initials of multiword phrases actually present in the question.
3. **Synonym expansion** — terms drawn **only** from vocabulary observed in the reference-set
   titles and the material text. Never import a thesaurus from memory; an unobserved synonym
   is a gap to report, not a term to invent.
4. **Field/time-window variants** — broaden `title` → `abstract` → `fulltext`, and widen date
   windows only when a `time_window_truncation` omission justifies it.

Each query records: `id`, `text`, `terms`, `fields`, `sources`, `time_window`, `rationale`.
A query that returns nothing is kept and marked `new_hit=null`, not deleted. Supplementary
gain is the count of previously-missed references that a new query matches **against the local
pool**; zero gain is reported as zero, never converted into a claim of reduced omission.

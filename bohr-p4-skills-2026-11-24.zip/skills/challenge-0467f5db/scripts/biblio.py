#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import hashlib, json, os, re, sqlite3, subprocess, unicodedata, zipfile

DOI_RE = re.compile(r"10\.\d{4,9}/[^\s\"'<>()\[\]]+", re.I)
STOP = set("a an and are as at be been by for from in into is it its of on or that the this these those to was were with within via using based across among between without every each any all such".split())
TITLE_KEYS = ("title", "Title", "article_title", "ArticleTitle", "full_title")
DOI_KEYS = ("doi", "DOI", "doi_", "DigitalObjectIdentifier")
YEAR_KEYS = ("year", "Year", "pubYear", "publication_year", "date")
VENUE_KEYS = ("journal", "Journal", "journalTitle", "container-title", "container_title", "publication", "booktitle", "venue")
ABSTRACT_KEYS = ("abstract", "Abstract", "abstractText", "description")
PMID_KEYS = ("pmid", "PMID", "id")
PMCID_KEYS = ("pmcid", "PMCID", "pmcID")
PRIORITY = ("identifier_anomaly", "time_window_truncation", "vocabulary_gap",
            "field_restriction", "source_not_indexed", "import_incomplete", "unexplained")
IMP_TRUE = ("true", "imported", "present", "indexed", "done", "success", "retrieved")
IMP_FALSE = ("false", "missing", "not_imported", "absent", "pending")
ACAD = set("identify literature find analyze analysis build independent reference set known relevant papers paper "
           "compute coverage retrieval classify missed query queries field source run supplementary measured marginal "
           "gain research question study data method results conclusion evaluate assess determine investigate review "
           "systematic".split())


def norm_doi(s):
    if s is None:
        return None
    s = str(s).strip().lower()
    for p in ("https://doi.org/", "http://doi.org/", "doi.org/", "dx.doi.org/",
              "https://dx.doi.org/", "http://dx.doi.org/", "doi:"):
        if s.startswith(p):
            s = s[len(p):]
    s = s.strip().rstrip(".,;")
    return s if s.startswith("10.") else None


def norm_title(s):
    if s is None:
        return ""
    s = unicodedata.normalize("NFKD", str(s))
    s = "".join(c for c in s if not unicodedata.combining(c)).lower().replace("&amp;", " and ")
    s = re.sub(r"[^\w\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def norm_text(s):
    if s is None:
        return ""
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", str(s)).lower()).strip()


def tokens(t):
    return [x for x in (y.strip(".-") for y in re.findall(r"[a-z0-9][a-z0-9\-\.]{2,}", norm_text(t))) if x and x not in STOP]


def rec_id(r):
    for k in ("doi", "pmid", "pmcid"):
        if r.get(k):
            return k + ":" + str(r[k])
    return "t:" + hashlib.sha1((norm_title(r.get("title")) + "|" + str(r.get("year") or "")).encode()).hexdigest()[:12]


def key_for(r):
    return r.get("record_id") or rec_id(r)


def _qc(v):
    v = v if isinstance(v, str) else str(v)
    out = [v]
    for esc in (True, False):
        try:
            out.append(json.dumps(v, ensure_ascii=esc)[1:-1])
        except Exception:
            pass
    return [c for c in out if c and c.strip()]


def find_quote(raw, v):
    if raw is None or v is None:
        return None
    for c in _qc(v):
        i = raw.find(c)
        if i >= 0:
            return raw[max(0, i - 40):i + len(c) + 40]
    return None


def quote_hit(raw, v):
    if raw is None or v is None:
        return False
    return any(c in raw for c in _qc(v))


def read_pdf(p):
    try:
        r = subprocess.run(["pdftotext", p, "-"], capture_output=True, timeout=60)
        if r.returncode == 0 and r.stdout:
            return "pdf", r.stdout.decode("utf-8", "replace"), ""
    except Exception:
        pass
    try:
        d = open(p, "rb").read()
        return "pdf", "\n".join(x.decode("ascii", "replace") for x in re.findall(rb"[\x20-\x7e]{6,}", d)[:2000]), "pdftotext unavailable; byte scan"
    except Exception:
        return "pdf", "", "pdf unreadable"


def read_docx(p):
    try:
        with zipfile.ZipFile(p) as z:
            n = [x for x in z.namelist() if x.endswith("document.xml")]
            xml = re.sub(r"<w:p[ >]", "\n", z.read(n[0]).decode("utf-8", "replace")) if n else ""
        return "docx", re.sub(r"<[^>]+>", "", xml), ""
    except Exception:
        return "docx", "", "docx unreadable"


def text_of_file(p):
    e = os.path.splitext(p)[1].lower()
    if e == ".pdf":
        return read_pdf(p)
    if e == ".docx":
        return read_docx(p)
    if e in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".svg"):
        return "image", "", "image: no text layer"
    if e in (".sqlite", ".sqlite3", ".db"):
        try:
            con = sqlite3.connect(p); cur = con.cursor()
            rows = []
            for t in [r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table'")]:
                try:
                    rows += [json.dumps(list(r), ensure_ascii=False) for r in cur.execute("SELECT * FROM %s LIMIT 200" % t)]
                except Exception:
                    pass
            con.close()
            return "sqlite", "\n".join(rows), "sqlite tables dumped"
        except Exception:
            return "sqlite", "", "sqlite unreadable"
    try:
        return "text", open(p, encoding="utf-8", errors="replace").read(), ""
    except Exception:
        try:
            return "binary", open(p, "rb").read().decode("utf-8", "replace"), "binary fallback"
        except Exception:
            return "unreadable", "", "unreadable"


def _first(o, keys):
    for k in keys:
        v = o.get(k)
        if isinstance(v, list):
            v = v[0] if v else None
        if v is not None and not isinstance(v, (dict, list)):
            return v
    return None


def _authors(o):
    a = o.get("author")
    if isinstance(a, list):
        out = []
        for x in a:
            if isinstance(x, dict):
                nm = " ".join(str(x.get(k, "")) for k in ("given", "family") if x.get(k)).strip()
                out.append(nm or str(x.get("name", "")))
            elif isinstance(x, str):
                out.append(x)
        return [x for x in out if x]
    if isinstance(a, str) and a:
        return [a]
    s = o.get("authorString")
    return [x.strip() for x in s.split(";") if x.strip()] if isinstance(s, str) and s else []


def _year(o):
    for k in YEAR_KEYS:
        v = o.get(k)
        if isinstance(v, int):
            return v
        if isinstance(v, str):
            m = re.search(r"(1[89]\d{2}|20\d{2})", v)
            if m:
                return int(m.group(1))
        if isinstance(v, list) and v and isinstance(v[0], int):
            return v[0]
    pub = o.get("published") or o.get("published-print") or o.get("issued")
    if isinstance(pub, dict):
        dp = pub.get("date-parts") or pub.get("date_parts")
        if isinstance(dp, list) and dp and isinstance(dp[0], list) and dp[0]:
            return dp[0][0]
    return None


def _to_rec(o, source, loc):
    title = _first(o, TITLE_KEYS)
    title = str(title) if isinstance(title, (int, float)) else title
    doi = norm_doi(_first(o, DOI_KEYS))
    pmid, pmcid = _first(o, PMID_KEYS), _first(o, PMCID_KEYS)
    if not title and not doi and not pmid and not pmcid:
        return None
    r = {"title": str(title) if title else None, "authors": _authors(o), "year": _year(o),
         "venue": str(_first(o, VENUE_KEYS)) or None, "doi": doi, "pmid": str(pmid) if pmid else None,
         "pmcid": str(pmcid) if pmcid else None, "abstract": str(_first(o, ABSTRACT_KEYS)) or None,
         "source": source, "locator": loc, "quote": None, "role_hint": None}
    r["record_id"] = rec_id(r)
    return r


def _record_like(o):
    if not isinstance(o, dict):
        return False
    s = (2 if _first(o, TITLE_KEYS) else 0) + (2 if norm_doi(_first(o, DOI_KEYS)) else 0)
    s += 1 if (_first(o, PMID_KEYS) or _first(o, PMCID_KEYS)) else 0
    s += 1 if _year(o) else 0
    s += 1 if _authors(o) else 0
    s += 1 if _first(o, VENUE_KEYS) else 0
    return s >= 3


def walk(n, source, path, out, seen):
    if isinstance(n, dict):
        if _record_like(n):
            r = _to_rec(n, source, path)
            if r and r["record_id"] not in seen:
                seen.add(r["record_id"]); out.append(r)
        for k, v in n.items():
            walk(v, source, path + "." + str(k), out, seen)
    elif isinstance(n, list):
        for i, v in enumerate(n):
            walk(v, source, "%s[%d]" % (path, i), out, seen)


def _imports(n, source, out):
    if isinstance(n, dict):
        doi = norm_doi(n.get("doi") or n.get("DOI"))
        pid = n.get("pmid") or n.get("pmcid") or n.get("id")
        key = "doi:" + doi if doi else ("id:" + str(pid) if pid else None)
        st = None
        for k in ("imported", "status", "state", "in_index", "indexed", "present", "retrieved"):
            if k in n:
                v = n[k]
                if isinstance(v, bool) or (isinstance(v, str) and v.lower() in IMP_TRUE + IMP_FALSE):
                    st = v
                break
        if key and st is not None and key not in out:
            out[key] = {"status": st, "source": source}
        for v in n.values():
            _imports(v, source, out)
    elif isinstance(n, list):
        for v in n:
            _imports(v, source, out)


def parse_json_material(obj, source):
    recs, seen, imports = [], set(), {}
    walk(obj, source, "$", recs, seen)
    _imports(obj, source, imports)
    return recs, imports


def parse_material(path, rel):
    kind, text, note = text_of_file(path)
    recs, imports = [], {}
    if text.strip():
        try:
            recs, imports = parse_json_material(json.loads(text), rel)
        except Exception:
            for m in DOI_RE.finditer(text):
                d = norm_doi(m.group(0))
                if d:
                    r = {"title": None, "authors": [], "year": None, "venue": None, "doi": d, "pmid": None, "pmcid": None,
                         "abstract": None, "source": rel, "locator": "text:doi", "quote": find_quote(text, m.group(0)), "role_hint": None}
                    r["record_id"] = rec_id(r); recs.append(r)
            seen = {}
            for r in recs:
                if r["record_id"] not in seen:
                    seen[r["record_id"]] = r
                elif r.get("title") and not seen[r["record_id"]].get("title"):
                    seen[r["record_id"]].update(r)
            recs = list(seen.values())
    for r in recs:
        if not r.get("quote") and text:
            for f in ("title", "doi"):
                if r.get(f):
                    q = find_quote(text, str(r[f]))
                    if q:
                        r["quote"] = q; break
    return {"kind": kind, "text": text, "note": note, "records": recs, "imports": imports, "path": rel}


def match_record(a, b):
    for k in ("doi", "pmid", "pmcid"):
        if a.get(k) and b.get(k) and str(a[k]) == str(b[k]):
            return k
    rt, ct = norm_title(a.get("title")), norm_title(b.get("title"))
    if rt and rt == ct:
        return "title"
    if rt and ct and a.get("year") and a.get("year") == b.get("year"):
        ra = ((a.get("authors") or [""])[0].split()[-1].lower() if a.get("authors") else "")
        ca = ((b.get("authors") or [""])[0].split()[-1].lower() if b.get("authors") else "")
        if ra and ca and ra == ca and len(set(rt.split()) & set(ct.split())) >= max(2, int(0.6 * min(len(rt.split()), len(ct.split())))):
            return "author-year-title"
    return None


def extract_question(ti):
    q = (ti or "").strip() or "No explicit research question provided."
    toks = [t for t in tokens(q) if t not in ACAD] or tokens(q)
    freq = {}
    for t in toks:
        freq[t] = freq.get(t, 0) + 1
    cons = [t for t, _ in sorted(freq.items(), key=lambda x: -x[1])][:12]
    return {"question": q, "concepts": cons}


def _q(i, t, terms, r, fields=None, tw=None):
    return {"id": "q%d" % i, "text": t, "terms": terms, "fields": fields or ["title", "abstract"],
            "sources": ["local-pool"], "time_window": tw, "rationale": r}


def build_query_plan(question, refs):
    cons = question.get("concepts", [])
    qs, qid, seen = [], 1, set(cons)
    for c in cons[:6]:
        qs.append(_q(qid, c, [c], "concept")); qid += 1
    for i in range(max(0, min(6, len(cons)) - 1)):
        qs.append(_q(qid, "%s AND %s" % (cons[i], cons[i + 1]), [cons[i], cons[i + 1]], "conj")); qid += 1
    for ph in re.findall(r"[A-Za-z][A-Za-z\- ]{5,40}", question.get("question", "")):
        ws = re.findall(r"[A-Za-z0-9]{2,}", ph)
        ab = "".join(w[0] for w in ws).upper() if 2 <= len(ws) <= 6 else None
        if ab and len(ab) >= 2 and ab.lower() not in seen:
            qs.append(_q(qid, ab, [ab.lower()], "abbreviation: %s" % ph.strip()))
            seen.add(ab.lower()); qid += 1
    for r in refs:
        for t in tokens(r.get("title") or ""):
            if t not in seen and qid <= 24:
                qs.append(_q(qid, t, [t], "ref-title synonym"))
                seen.add(t); qid += 1
    return qs


def dedupe(recs):
    best, order = {}, []
    for r in recs:
        k = key_for(r)
        if k not in best:
            best[k] = r; order.append(k)
        elif (not best[k].get("title") and r.get("title")) or (r.get("quote") and not best[k].get("quote")):
            best[k] = r
    return [best[k] for k in order]


def relevance(c, qterms, rterms):
    ct = set(tokens((c.get("title") or "") + " " + (c.get("abstract") or "")))
    return 2.0 * sum(1 for t in qterms if t in ct) + 1.0 * sum(1 for t in rterms if t in ct)


def compute_hits(refs, cands, imports):
    bykey = {}
    for c in cands:
        bykey.setdefault(key_for(c), []).append(c)
    hits = []
    for r in refs:
        rk = key_for(r)
        imp = imports.get(rk) or imports.get("id:" + str(r.get("pmid") or r.get("pmcid") or ""))
        matched = mtype = ev = None
        if imp is not None and str(imp["status"]).lower() in IMP_TRUE:
            matched, mtype, ev = r, "import-state", {"source": imp["source"], "locator": "import-state", "quote": str(imp["status"])}
        if matched is None:
            for c in bykey.get(rk, []):
                mt = match_record(r, c)
                if mt:
                    matched, mtype = c, mt; break
        if matched is None and r.get("doi"):
            for c in cands:
                if c.get("doi") and norm_doi(c["doi"]) == norm_doi(r["doi"]):
                    matched, mtype = c, "doi"; break
        if matched is not None and mtype != "import-state":
            ev = {"source": matched.get("source"), "locator": matched.get("locator"),
                  "quote": matched.get("quote") or matched.get("title") or matched.get("doi")}
        hits.append({"reference_id": r.get("record_id"), "title": r.get("title"), "doi": r.get("doi"),
                     "year": r.get("year"), "status": "hit" if matched is not None else "miss", "match_type": mtype,
                     "matched_candidate_id": matched.get("record_id") if matched is not None and mtype != "import-state" else None,
                     "evidence": ev, "ref_source": r.get("source"), "ref_locator": r.get("locator"), "ref_quote": r.get("quote")})
    return hits


def classify(r, qterms, queries, cand_sources, imports):
    rk = key_for(r)
    imp = imports.get(rk) or imports.get("id:" + str(r.get("pmid") or r.get("pmcid") or ""))
    rt = set(tokens(r.get("title") or ""))
    overlap = rt & set(qterms)
    det = []
    if not r.get("doi") and not r.get("pmid") and not r.get("pmcid"):
        det.append("identifier_anomaly")
    if r.get("year"):
        for q in queries:
            tw = q.get("time_window")
            if isinstance(tw, dict) and (tw.get("from") or tw.get("to")):
                lo, hi = tw.get("from"), tw.get("to")
                if (lo and r["year"] < lo) or (hi and r["year"] > hi):
                    det.append("time_window_truncation"); break
    if not overlap:
        det.append("vocabulary_gap")
    fields = set(f for q in queries for f in (q.get("fields") or []))
    if overlap and fields and all(f in ("title", "authors") for f in fields):
        det.append("field_restriction")
    if r.get("source") not in cand_sources:
        det.append("source_not_indexed")
    if imp is not None and str(imp["status"]).lower() in IMP_FALSE:
        det.append("import_incomplete")
    return next((c for c in PRIORITY if c in det), "unexplained"), det


def supplementary(omissions, refs, cands):
    sq = []
    for o in omissions:
        ref = next((r for r in refs if r.get("record_id") == o["reference_id"]), None)
        if not ref:
            continue
        ts = [t for t in tokens(ref.get("title") or "")][:4]
        c = o["cause"]
        if c == "time_window_truncation":
            nq = {"id": "s%d" % (len(sq) + 1), "text": " ".join(ts), "terms": ts, "fields": ["title", "abstract"],
                  "time_window": {"from": None, "to": None}, "target": ref.get("record_id"),
                  "reason": "widen window %s" % ref.get("year")}
        elif c == "identifier_anomaly":
            nq = {"id": "s%d" % (len(sq) + 1), "text": (ref.get("title") or "")[:80], "terms": ts,
                  "fields": ["title", "authors", "year"], "time_window": None, "target": ref.get("record_id"),
                  "reason": "title/author/year query"}
        else:
            nq = {"id": "s%d" % (len(sq) + 1), "text": " ".join(ts), "terms": ts,
                  "fields": ["title", "abstract", "fulltext"], "time_window": None, "target": ref.get("record_id"),
                  "reason": "term expansion for %s" % c}
        gain, req = None, set(ts)
        for cc in cands:
            ct = set(tokens((cc.get("title") or "") + " " + (cc.get("abstract") or "")))
            if req and len(req & ct) >= max(1, int(0.75 * len(req))):
                gain = cc; break
        nq.update({"new_hit": gain.get("record_id") if gain else None,
                   "new_hit_source": gain.get("source") if gain else None,
                   "new_hit_quote": (gain.get("quote") or gain.get("title")) if gain else None,
                   "marginal_gain": 1 if gain else 0,
                   "residual_note": None if gain else "no local candidate matches; likely source_not_indexed"})
        sq.append(nq)
    return sq

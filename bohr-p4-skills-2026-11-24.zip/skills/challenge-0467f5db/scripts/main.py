#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse, csv, json, os, re, sys
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import biblio as B  # noqa: E402

DEFAULT_INPUT, DEFAULT_WORK, DEFAULT_OUTPUT = "/input", "/app/work", "/app/output"
SYN = {"candidate": "candidate_records", "candidates": "candidate_records", "results": "candidate_records",
       "retrieval_results": "candidate_records", "candidate_records": "candidate_records",
       "reference": "reference_set", "references": "reference_set", "reference_set": "reference_set", "gold": "reference_set",
       "coverage": "coverage", "coverage_report": "coverage", "omission": "omissions", "omissions": "omissions",
       "query": "query_plan", "queries": "query_plan", "query_plan": "query_plan",
       "hit": "hit_matrix", "hits": "hit_matrix", "hit_matrix": "hit_matrix", "ranking": "ranking",
       "ranked": "ranking", "supplementary": "supplementary_queries",
       "supplementary_queries": "supplementary_queries", "residual": "residual_omissions",
       "residual_omissions": "residual_omissions", "summary": "summary", "report": "summary",
       "evidence": "sources", "sources": "sources", "deduplication": "deduplication",
       "uncertainty": "uncertainty", "change_records": "change_records",
       "errors": "errors", "degradations": "degradations"}


def resolve_dirs(a):
    return (a.input or os.environ.get("INPUT_DIR") or DEFAULT_INPUT,
            a.work or os.environ.get("WORK_DIR") or DEFAULT_WORK,
            a.output or os.environ.get("OUTPUT_DIR") or DEFAULT_OUTPUT)


def load_case(inp):
    ti = ""
    try:
        ti = open(os.path.join(inp, "task.md"), encoding="utf-8", errors="replace").read()
    except Exception:
        pass
    cp = os.path.join(inp, "case.json")
    if not os.path.exists(cp):
        return None, {}, ti, {}, "case.json missing"
    try:
        raw = open(cp, encoding="utf-8", errors="replace").read()
        if not raw.strip():
            return None, {}, ti, {}, "case.json empty"
        data = json.loads(raw)
    except Exception as e:
        return None, {}, ti, {}, "case.json invalid: %s" % e
    cid = data.get("case_id") or data.get("id") or data.get("caseId")
    contract = data.get("output_contract") or data.get("outputContract") or {}
    return cid, contract, data.get("task_instruction") or data.get("task") or data.get("instruction") or ti, data, None


def discover_materials(inp):
    out = []
    for root, _d, files in os.walk(inp):
        for fn in sorted(files):
            rel = os.path.relpath(os.path.join(root, fn), inp).replace("\\", "/")
            if rel not in ("case.json", "task.md"):
                out.append(os.path.join(root, fn))
    return out


def load_draft(work):
    dp = os.path.join(work, "draft.json")
    if not os.path.exists(dp):
        return None
    try:
        return json.load(open(dp, encoding="utf-8"))
    except Exception:
        return None


def _rec(r, score=None):
    d = {"record_id": r["record_id"], "title": r.get("title"), "authors": r.get("authors"),
         "year": r.get("year"), "venue": r.get("venue"), "doi": r.get("doi"), "pmid": r.get("pmid"),
         "pmcid": r.get("pmcid"), "source": r.get("source"), "locator": r.get("locator"),
         "quote": r.get("quote"), "role_hint": r.get("role_hint")}
    if score is not None:
        d["relevance_score"] = score
    return d


def build_payload(cid, contract, ti, materials, draft):
    errs, degs, records, imports = [], [], [], {}
    for m in materials:
        records.extend(m["records"]); imports.update(m["imports"])
        if m.get("note"):
            degs.append({"material": m["path"], "kind": m["kind"], "note": m["note"]})
    refs, cands = [], []
    for r in records:
        src = (r.get("source") or "").lower()
        if re.search(r"crossref|europe|pmc|pubmed|query|search|result|retriev|import|increm|api|\.db|database", src):
            r["role_hint"] = "retrieved"; cands.append(r)
        elif re.search(r"ref|gold|known|review|citation|graph|guide", src):
            r["role_hint"] = "reference"; refs.append(r)
    for r in records:
        imp = imports.get(B.key_for(r))
        if imp is not None:
            st = str(imp["status"]).lower()
            if st in B.IMP_TRUE and r not in cands:
                r["role_hint"] = "retrieved(imported)"; cands.append(r)
            elif st in B.IMP_FALSE and r not in refs:
                r["role_hint"] = "reference(not-imported)"; refs.append(r)
    if draft:
        if draft.get("reference_set"):
            refs = [dict(x, record_id=x.get("record_id") or B.rec_id(x)) for x in draft["reference_set"]]
        if draft.get("candidate_records"):
            cands = [dict(x, record_id=x.get("record_id") or B.rec_id(x)) for x in draft["candidate_records"]]
        if draft.get("imports"):
            imports = dict(draft["imports"])
    refs, cands = B.dedupe(refs), B.dedupe(cands)
    rawmap = {m["path"]: m["text"] for m in materials}
    for r in refs + cands:
        if not r.get("quote") and r.get("source") in rawmap:
            for f in ("title", "doi"):
                if r.get(f):
                    q = B.find_quote(rawmap[r["source"]], str(r[f]))
                    if q:
                        r["quote"] = q; break
        if not r.get("quote"):
            degs.append({"material": r.get("source"), "note": "no verbatim quote for %s" % r.get("record_id")})

    question = B.extract_question(ti)
    qterms = question["concepts"]
    rterms = set()
    for r in refs:
        rterms.update(B.tokens(r.get("title") or ""))
    queries = B.build_query_plan(question, refs)
    if draft and draft.get("queries"):
        queries = draft["queries"]

    hits = B.compute_hits(refs, cands, imports)
    nhit = sum(1 for h in hits if h["status"] == "hit")
    nref = len(refs)
    coverage = nhit / nref if nref else None
    ranked = sorted(cands, key=lambda c: -B.relevance(c, qterms, rterms))
    k = min(10, max(1, len(ranked)))
    rh = [{"record_id": c.get("record_id"), "title": c.get("title"), "doi": c.get("doi"), "year": c.get("year"),
           "score": B.relevance(c, qterms, rterms), "relevant": bool(any(B.match_record(r, c) for r in refs))}
          for c in ranked[:k]]
    prec = sum(1 for x in rh if x["relevant"]) / k if k else None
    rec = sum(1 for x in rh if x["relevant"]) / nref if nref else None

    cand_sources = {c.get("source") for c in cands}
    omissions = []
    for h in hits:
        if h["status"] != "miss":
            continue
        ref = next((r for r in refs if r.get("record_id") == h["reference_id"]), {})
        cause, allc = B.classify(ref, qterms, queries, cand_sources, imports)
        omissions.append({"reference_id": h["reference_id"], "title": h["title"], "doi": h["doi"],
                          "year": h["year"], "cause": cause, "candidate_causes": allc,
                          "evidence": {"ref_source": h.get("ref_source"), "ref_locator": h.get("ref_locator"),
                                       "ref_quote": h.get("ref_quote"), "query_terms_used": qterms,
                                       "query_fields": sorted({f for q in queries for f in (q.get("fields") or [])}),
                                       "candidate_sources": sorted(c for c in cand_sources if c)}})
    sq = B.supplementary(omissions, refs, cands)
    gain = sum(x["marginal_gain"] for x in sq)
    residual = {"before": len(omissions), "after": len(omissions) - gain, "reduction": gain,
                "notes": [x["residual_note"] for x in sq if x.get("residual_note")]}
    summary = ("Reference set: %d unique; retrieved pool: %d unique; coverage %s (%d/%d); omissions %d; "
               "supplementary queries %d, marginal gain %d." % (
                   nref, len(cands), ("%.4f" % coverage) if coverage is not None else "undefined",
                   nhit, nref, len(omissions), len(sq), gain))
    if not nref:
        summary = "No reference set derivable from input materials: cannot compute coverage denominator (insufficient_evidence)."
    return {"case_id": cid, "research_question": question, "query_plan": queries,
            "reference_set": [_rec(r) for r in refs],
            "candidate_records": [_rec(c, B.relevance(c, qterms, rterms)) for c in cands],
            "deduplication": {"reference_unique": nref, "candidate_unique": len(cands),
                              "dedup_key": "normalized DOI/PMID/PMCID/title+year"},
            "hit_matrix": hits,
            "coverage": {"denominator": nref, "hits": nhit, "coverage": coverage, "omissions": len(omissions),
                         "metric_definition": "coverage = hits / reference_set_size"},
            "ranking": {"k": k, "precision_at_k": prec, "recall_at_k": rec, "ndcg_at_k": None, "ranked": rh},
            "omissions": omissions, "supplementary_queries": sq, "residual_omissions": residual, "summary": summary,
            "sources": [{"path": m["path"], "kind": m["kind"], "records": len(m["records"]),
                         "imports": len(m["imports"]), "note": m.get("note")} for m in materials],
            "uncertainty": [{"item": "reference_set", "note": "role inferred from material path/keys"},
                            {"item": "matching", "note": "normalized-exact title plus author+year"},
                            {"item": "offline_scope", "note": "supplementary gain vs local pool only"}],
            "change_records": [{"step": "partial", "note": "partial result with discovered inputs"},
                               {"step": "finalize", "note": "coverage/omissions/supplementary computed"}],
            "errors": errs, "degradations": degs}


def contract_fields(c):
    if isinstance(c, dict):
        if "properties" in c and isinstance(c["properties"], dict):
            return list(c["properties"].keys())
        return list(c.keys())
    if isinstance(c, list):
        return [x for x in c if isinstance(x, str)]
    return []


def fill_contract(c, p):
    r = {}
    for n in contract_fields(c):
        key = SYN.get(n) or SYN.get(n.lower().replace("-", "_").replace(" ", "_"))
        r[n] = p[key] if key and key in p else ([] if n.lower().endswith(("s", "list", "set", "records", "results")) else None)
    r.update(p)
    return r


def write_artifacts(out, p):
    os.makedirs(out, exist_ok=True)
    json.dump(p, open(os.path.join(out, "result.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    with open(os.path.join(out, "hit_matrix.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["reference_id", "title", "doi", "year", "status", "match_type", "matched_candidate_id",
                    "evidence_source", "evidence_locator"])
        for h in p["hit_matrix"]:
            ev = h.get("evidence") or {}
            w.writerow([h["reference_id"], h["title"], h["doi"], h["year"], h["status"], h["match_type"],
                        h["matched_candidate_id"], ev.get("source"), ev.get("locator")])
    with open(os.path.join(out, "omissions.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["reference_id", "title", "doi", "year", "cause", "evidence"])
        for o in p["omissions"]:
            w.writerow([o["reference_id"], o["title"], o["doi"], o["year"], o["cause"],
                        json.dumps(o["evidence"], ensure_ascii=False)])
    with open(os.path.join(out, "coverage_report.md"), "w", encoding="utf-8") as f:
        f.write("# Retrieval Coverage & Omission Report\n\n**Case**: %s\n\n**Summary**: %s\n\n## Coverage\n\n%s\n\n## Ranking\n\n%s\n\n## Omissions\n\n" % (
            p.get("case_id") or "unknown", p["summary"], json.dumps(p["coverage"], ensure_ascii=False),
            json.dumps(p["ranking"], ensure_ascii=False)))
        for o in p["omissions"]:
            f.write("- `%s` %s: %s\n" % (o["reference_id"], o["cause"], o["title"] or o["doi"] or "?"))
        f.write("\n## Supplementary queries\n\n")
        for q in p["supplementary_queries"]:
            f.write("- `%s` (gain=%d): %s\n" % (q["id"], q["marginal_gain"], q["reason"]))
        f.write("\n## Residual omissions\n\n%s\n" % json.dumps(p["residual_omissions"], ensure_ascii=False))


def run(inp, work, out):
    os.makedirs(work, exist_ok=True); os.makedirs(out, exist_ok=True)
    cid, contract, ti, _raw, err = load_case(inp)
    if err:
        payload = {"case_id": cid, "status": "input_error", "research_question": {"question": ti or ""},
                   "query_plan": [], "reference_set": [], "candidate_records": [], "hit_matrix": [],
                   "coverage": None, "ranking": None, "omissions": [], "supplementary_queries": [],
                   "residual_omissions": None, "summary": "Input error: %s" % err, "sources": [],
                   "uncertainty": [{"item": "input", "note": err}],
                   "change_records": [{"step": "partial", "note": "input error"}],
                   "errors": [err], "degradations": []}
        result = fill_contract(contract, payload)
        result["case_id"], result["status"] = cid, "input_error"
        write_artifacts(out, result)
        return result
    materials = []
    for p in discover_materials(inp):
        try:
            materials.append(B.parse_material(p, os.path.relpath(p, inp).replace("\\", "/")))
        except Exception:
            pass
    payload = build_payload(cid, contract, ti, materials, load_draft(work))
    status = "success" if payload["reference_set"] else "insufficient_evidence"
    if not materials:
        status = "insufficient_evidence"
    result = fill_contract(contract, payload)
    result["case_id"], result["status"] = cid, status
    write_artifacts(out, result)
    json.dump({"reference_set": payload["reference_set"], "candidate_records": payload["candidate_records"],
               "queries": payload["query_plan"]}, open(os.path.join(work, "draft.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    return result


def cmd_show(inp, _w, _o):
    cid, contract, ti, _r, err = load_case(inp)
    print("case_id:", cid)
    print("contract fields:", contract_fields(contract))
    print("task_instruction_len:", len(ti or ""))
    print("load err:", err)
    for p in discover_materials(inp):
        print("material:", os.path.relpath(p, inp), os.path.getsize(p))
    return 0


def cmd_check(inp, _w, out):
    rp = os.path.join(out, "result.json")
    if not os.path.exists(rp):
        print("FAIL: result.json missing")
        return 1
    res = json.load(open(rp, encoding="utf-8"))
    _c, contract, _t, _r, _e = load_case(inp)
    names = contract_fields(contract)
    missing = [n for n in names if n not in res]
    print("contract fields:", names)
    print("missing contract fields:", missing)
    print("case_id present:", res.get("case_id") is not None)
    print("status:", res.get("status"))
    rawmap = {}
    for p in discover_materials(inp):
        m = B.parse_material(p, os.path.relpath(p, inp).replace("\\", "/"))
        rawmap[m["path"]] = m["text"]
    total = ok = 0
    for grp in (res.get("reference_set", []), res.get("candidate_records", [])):
        for r in grp:
            if r.get("quote") and r.get("source") in rawmap:
                total += 1
                if B.quote_hit(rawmap[r["source"]], r["quote"]):
                    ok += 1
    rate = (ok / total) if total else None
    print("quote hit rate: %s/%s = %s" % (ok, total, rate))
    print("CHECK_RESULT:", "PASS" if (not missing and res.get("case_id") is not None and (rate is None or rate >= 0.95)) else "REVIEW")
    return 0


def cmd_init(_i, work, _o):
    os.makedirs(work, exist_ok=True)
    json.dump({"research_question": "", "reference_set": [], "candidate_records": [], "queries": [],
               "imports": {}, "_schema": "record: record_id,title,authors[],year,venue,doi,pmid,pmcid,source(rel path),locator,quote(verbatim)"},
              open(os.path.join(work, "draft.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print("initialized draft.json in work dir")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="coverage-skill", description="Retrieval coverage & omission analysis")
    ap.add_argument("command", nargs="?", default="run", choices=["run", "build", "init", "show", "check"])
    ap.add_argument("--input"); ap.add_argument("--work"); ap.add_argument("--output")
    a = ap.parse_args(argv)
    inp, work, out = resolve_dirs(a)
    try:
        if a.command == "show":
            return cmd_show(inp, work, out)
        if a.command == "check":
            return cmd_check(inp, work, out)
        if a.command == "init":
            return cmd_init(inp, work, out)
        run(inp, work, out)
        return 0
    except Exception as e:
        try:
            os.makedirs(out, exist_ok=True)
            json.dump({"case_id": None, "status": "error", "errors": [str(e)], "degradations": [],
                       "summary": "unhandled exception: %s" % e, "sources": [], "uncertainty": [],
                       "change_records": [{"step": "partial", "note": "error during run"}]},
                      open(os.path.join(out, "result.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        except Exception:
            pass
        print("ERROR:", e)
        return 0


if __name__ == "__main__":
    sys.exit(main())

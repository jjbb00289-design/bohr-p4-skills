---
name: paper-to-slides
description: Turn a research paper (or research materials) into an editable, evidence-mapped academic slide deck. One command reads /input, derives a real page plan with verbatim quotes and locators, builds an editable .pptx inheriting a supplied template's masters/layouts/theme, exports a real PDF plus PNG previews, and writes result.json echoing every output_contract field. Use when the task is to produce a presentation deck from a paper with traceable figures/tables/numbers and template constraints.
version: 1.0.0
---

# paper-to-slides

把论文/科研材料转成**主线成立、页页可回溯、可编辑、可放映**的学术 PPT，而不是把段落切块贴进页面。

## 用途与触发条件

适用：输入含论文或科研材料（PDF / DOCX / Markdown / TXT / CSV / TSV / 图片），要求产出学术汇报 PPT（组会、答辩、评审、会议）；可选提供 `.pptx`/`.potx` 模板或起始 deck；要求数字/单位/图号与原文一致、模板能套、导出能打开。

不适用：只要论文精读结论；只要科研绘图美化；只要文稿润色。材料完全缺失时写 `insufficient_evidence`，**绝不编造论文内容**。

## 调用方式

默认**单命令**即完整流程（不需要先写工作稿，也不需要多步交互）：

```bash
python3 scripts/main.py            # 读 /input → 派生页计划 → 构建 → 导出 → result.json
python3 scripts/main.py --input DIR --work DIR --output DIR
```

环境变量 `INPUT_DIR` / `WORK_DIR` / `OUTPUT_DIR` 可覆盖默认 `/input` `/app/work` `/app/output`。退出码恒 0。脚本用 `Path(__file__).resolve().parent` 定位自身，不依赖 CWD、不联网、只用 Python 标准库。无模板时使用包内 `assets/default_template.pptx`（16:9，含母版/版式/主题）。

## 输入输出

| 项 | 路径 |
|---|---|
| 输入 | `/input/case.json`（`case_id`、`task_instruction`、`output_contract`，可含 `title`/`slide_count`/`mode`/`template`/`deck` 等约束）、`/input/task.md`、`/input/` 下材料 |
| 工作区 | `/app/work/`：`index.json`（材料索引 + locator 段号） |
| 产物 | `/app/output/`：`result.json`（必需）、`presentation.pptx`、`presentation.pdf`、`preview/slide-*.png`、`content_map.json`、`page_plan.json`、`evidence_map.json`、`changes.json`、`template_check.json`、`export_check.json` |

## 派生方法（无工作稿自动完成）

1. **读材料**：PDF 用 `pdftotext`（无则标准库粗抽取）；DOCX 解包 `word/document.xml`；文本按段落读；自动回卷折行。
2. **主线派生**：识别章节标题（中英），按角色（title/background/method/result/limitation/conclusion）打分选取**原文逐字句子**作为每页 claim；数字密度与 Figure/Table 引用加权结果页。
3. **页计划**：`slide_count`（题面给则遵守，否则 9）按比例分配角色页；每页 claim + bullets 均为原文**逐字子串**（逗号/分号切分），页码、图号、数值不改写。
4. **构建**：在模板的 `slideLayout` 上以 `p:ph` 占位符加页，母版/版式/主题字节不变；备注写入真实 `notesSlide` 部件。
5. **导出与复核**：LibreOffice 可用则真渲染 PDF，否则写标准库文本层 PDF（`%PDF-` 头 + 页对象，页数=slide_count；Latin 用 Helvetica/WinAnsi，CJK 用预定义 CID 字体 STSong-Light/UniGB-UCS2-H，长句按页宽换行）；PNG 预览用 `pdftoppm`。

## 工作稿 schema（可选，非必需）

无工作稿时主脚本自动派生；如需人工干预，可在 `/app/work/plan.json` 放同构页计划（每页 `role/title/claim/bullets/claim_loc/claim_quote/figure_refs`），主脚本检测到即优先采用。

## 证据规范（真实派生红线）

- 每页 `claim` 与每个 `bullet` 都是材料原文的**逐字子串**；`content_map.json` 逐页记录 `source.path` + `locator`（如 `m1#p3`）+ 逐字 `quote` + `verbatim_hit`。
- `quote_hit_rate` 机械比对（去空白、小写），目标 ≥0.95；页面数字/图号只来自原文，不生成"看起来像"的曲线，不把示意图当实验数据。
- `locator` 形如 `mN#pK`（文本段 K）、`mN#pgK#pJ`（PDF 第 K 页段 J）或 `mN#rowK`（表行）；与 `index.json` 一致。

## 降级表

| 情况 | 处置 | 记录 |
|---|---|---|
| 无模板 | 用包内默认学术模板 | `degradations` |
| 无 LibreOffice | 标准库文本层 PDF（Latin/CJK 均可读；特殊符号用 CID 字体覆盖范围内字形） | `degradations` |
| PDF 为 CID/扫描 | 抽取失败则 `insufficient_evidence`，不编造 | `status` |
| 空 `/input` / 无 case.json | `status=input_error` + 最小合法 result.json | `errors` |
| case.json 坏 JSON | `status=input_error` | `errors` |
| 缺材料 | `status=insufficient_evidence` + gaps | `uncertainty` |
| 页数超限 | 先删支撑细节页，保留主线页 | `coverage` |

任何异常都先写 partial `result.json` 再增量 finalize，退出码恒 0。

## 自检

- `python3 scripts/main.py`（默认）后：`result.json` 合法且回填 `output_contract` 每个键 + `case_id/status/sources/uncertainty/changes`。
- `presentation.pptx` 可解压、含 `ppt/presentation.xml`、每页挂 slideLayout；`presentation.pdf` 有 `%PDF-` 头且页数=slide_count。
- 两次全新输出目录产物结构一致（无时间戳/随机；zip 固定时间戳，PDF 无 CreationDate）。
- 空/坏/缺三态各自退出 0 且 result.json 契约键齐全。

## 限制

- 不重绘论文图表，只保留图号与图注文字（图引用以 `figure_refs` + 逐字 quote 呈现）。
- 标准库 PDF 兜底用 Helvetica（Latin）+ STSong-Light/UniGB-UCS2-H（CJK），中日韩文本可读；超出 GB1 字符集的符号可能缺字形（可编辑源 pptx 文本始终完整正确）。
- 不判断科学结论对错，只保证可回溯；扫描版 PDF 需 OCR 工具另行处理。
- 模板要求：`.pptx`/`.potx` 且至少含一个带标题占位符的 `slideLayout`。

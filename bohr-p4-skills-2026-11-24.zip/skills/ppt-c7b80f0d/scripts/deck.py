# -*- coding: utf-8 -*-
"""Pure-stdlib OOXML deck builder + PDF/PNG preview renderer."""
import hashlib, os, posixpath, re, shutil, subprocess, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

A = "http://schemas.openxmlformats.org/drawingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
P = "http://schemas.openxmlformats.org/presentationml/2006/main"
RL = "http://schemas.openxmlformats.org/package/2006/relationships"
TS = R + "/slide"; TL = R + "/slideLayout"; TM = R + "/slideMaster"
TN = R + "/notesSlide"; TNM = R + "/notesMaster"; TH = R + "/theme"
CP = "application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"
CS = "application/vnd.openxmlformats-officedocument.presentationml.slide+xml"
CL = "application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"
CM = "application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"
CT = "application/vnd.openxmlformats-officedocument.theme+xml"
CNN = "application/vnd.openxmlformats-officedocument.presentationml.notesSlide+xml"
CNM = "application/vnd.openxmlformats-officedocument.presentationml.notesMaster+xml"
W, H = 12192000, 6858000


def sha(d):
    return hashlib.sha256(d.encode() if isinstance(d, str) else d).hexdigest()


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def ea(s):
    return esc(s).replace('"', "&quot;")


def cjk(s):
    return any("\u4e00" <= c <= "\u9fff" for c in str(s))


def read_package(p):
    with zipfile.ZipFile(str(p)) as z:
        parts = {n: z.read(n) for n in z.namelist()}
    if "[Content_Types].xml" not in parts:
        raise ValueError("not OOXML")
    return parts


def write_package(parts, p):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(str(p), "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(parts, key=lambda n: (0 if n == "[Content_Types].xml" else 1, n)):
            i = zipfile.ZipInfo(n, date_time=(2026, 1, 1, 0, 0, 0))
            i.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(i, parts[n])


def _p(t):
    return "{%s}%s" % (P, t)


def _a(t):
    return "{%s}%s" % (A, t)


def _rels(parts, part):
    d, n = posixpath.split(part)
    rp = posixpath.join(d, "_rels", n + ".rels")
    if rp not in parts:
        return {}
    return {rel.get("Id"): {"type": rel.get("Type"), "target": rel.get("Target")}
            for rel in ET.fromstring(parts[rp])}


def _res(base, target):
    return target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join(posixpath.dirname(base), target))


def _ph_records(root):
    out = []
    for sp in root.iter(_p("sp")):
        nv = sp.find(_p("nvSpPr"))
        if nv is None or nv.find(_p("nvPr")) is None:
            continue
        ph = nv.find(_p("nvPr")).find(_p("ph"))
        if ph is None:
            continue
        cnv = nv.find(_p("cNvPr"))
        xfrm = None
        sppr = sp.find(_p("spPr"))
        if sppr is not None:
            x = sppr.find(_a("xfrm"))
            if x is not None:
                off, ext = x.find(_a("off")), x.find(_a("ext"))
                try:
                    xfrm = [int(off.get("x")), int(off.get("y")), int(ext.get("cx")), int(ext.get("cy"))]
                except Exception:
                    pass
        out.append({"type": ph.get("type") or "obj", "idx": ph.get("idx") or "",
                    "name": cnv.get("name") if cnv is not None else "", "xfrm": xfrm})
    return out


def analyze_parts(parts):
    root = ET.fromstring(parts["ppt/presentation.xml"])
    masters = sorted(n for n in parts if re.match(r"ppt/slideMasters/slideMaster\d+\.xml$", n))
    layouts = sorted((n for n in parts if re.match(r"ppt/slideLayouts/slideLayout\d+\.xml$", n)),
                     key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    themes = sorted(n for n in parts if re.match(r"ppt/theme/theme\d+\.xml$", n))
    linfos = [{"part": n, "type": ET.fromstring(parts[n]).get("type") or "",
               "placeholders": _ph_records(ET.fromstring(parts[n]))} for n in layouts]
    slides, prel = [], _rels(parts, "ppt/presentation.xml")
    sl = root.find(_p("sldIdLst"))
    if sl is not None:
        for sid in sl:
            rel = prel.get(sid.get("{%s}id" % R) or sid.get("id"))
            if rel:
                part = _res("ppt/presentation.xml", rel["target"])
                if part in parts:
                    slides.append(part)
    if not slides:
        slides = sorted((n for n in parts if re.match(r"ppt/slides/slide\d+\.xml$", n)),
                        key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    size = [W, H]
    sz = root.find(_p("sldSz"))
    if sz is not None:
        try:
            size = [int(sz.get("cx")), int(sz.get("cy"))]
        except Exception:
            pass
    return {"masters": masters, "layouts": linfos, "themes": themes, "slides": slides, "slide_size": size}


def analyze(p):
    return analyze_parts(read_package(p))


def _run(t, sz, bold=False):
    lang = "zh-CN" if cjk(t) else "en-US"
    return ('<a:r><a:rPr lang="%s" altLang="en-US" sz="%d" b="%d" dirty="0"><a:solidFill>'
            '<a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/>'
            '</a:rPr><a:t>%s</a:t></a:r>' % (lang, int(sz * 100), 1 if bold else 0, esc(t)))


def _para(t, sz, bold=False, bullet=None):
    inner = "<a:buNone/>" if bullet == "none" else ('<a:buFont typeface="Arial"/><a:buChar char="\u2022"/>' if bullet == "dot" else "")
    return "<a:p><a:pPr>%s</a:pPr>%s</a:p>" % (inner, _run(t, sz, bold))


def _sp(sid, name, xfrm, paras, ph=None):
    phx = "<p:ph%s%s/>" % (' type="%s"' % ph[0] if ph else '', ' idx="%s"' % ph[1] if ph and ph[1] else "") if ph else ""
    nv = '<p:nvPr>%s</p:nvPr>' % phx if ph else '<p:nvPr/>'
    sp_pr = ('<p:spPr><a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
             '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>%s</p:spPr>' % (xfrm[0], xfrm[1], xfrm[2], xfrm[3],
             '' if ph else '<a:noFill/>'))
    cns = '' if ph else '<p:cNvSpPr txBox="1"/>'
    return ('<p:sp><p:nvSpPr><p:cNvPr id="%d" name="%s"/>%s%s</p:nvSpPr>%s<p:txBody><a:bodyPr wrap="square" '
            'lIns="91440" tIns="45720" rIns="91440" bIns="45720"><a:%sAutofit/></a:bodyPr><a:lstStyle/>%s</p:txBody></p:sp>'
            % (sid, ea(name), cns, '<p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr>' if ph else '', sp_pr,
               'norm' if ph else 'no', "".join(paras)))


def slide_xml(shapes):
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<p:sld xmlns:a="%s" xmlns:r="%s" '
            'xmlns:p="%s"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/>'
            '</p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/>'
            '<a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>%s</p:spTree></p:cSld>'
            '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>' % (A, R, P, "".join(shapes)))


NM = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<p:notesMaster xmlns:a="%s" xmlns:r="%s" '
      'xmlns:p="%s"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
      '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/>'
      '</a:xfrm></p:grpSpPr><p:sp><p:nvSpPr><p:cNvPr id="2" name="Notes"/><p:cNvSpPr/><p:nvPr><p:ph type="body" '
      'idx="1"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p>'
      '</p:txBody></p:sp></p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" '
      'accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" '
      'folHlink="folHlink"/></p:notesMaster>' % (A, R, P))


def notes_xml(lines):
    ps = "".join("<a:p>%s</a:p>" % _run(t, 12) for t in (lines or ["(no notes)"]))
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<p:notes xmlns:a="%s" xmlns:r="%s" '
            'xmlns:p="%s"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/>'
            '</p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/>'
            '<a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr><p:sp><p:nvSpPr><p:cNvPr id="2" name="Notes"/><p:cNvSpPr/>'
            '<p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/>%s'
            '</p:txBody></p:sp></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:notes>'
            % (A, R, P, ps))


def fit(bullets, title):
    w = sum(0.55 if ord(c) < 128 else 1.0 for b in bullets for c in str(b))
    size = 14 if w > 430 else 15 if w > 340 else 16 if w > 260 else 17 if w > 200 else 18 if w > 150 else 20
    ts = 30 if len(str(title)) <= 42 else (26 if len(str(title)) <= 60 else 22)
    return size, ts


def placeholders_of(lay):
    tp = bp = None
    best = -1
    for ph in lay.get("placeholders") or []:
        if ph["type"] in ("title", "ctrTitle") and tp is None:
            tp = ph
        if ph["type"] in ("body", "obj", "subTitle"):
            area = ph["xfrm"][2] * ph["xfrm"][3] if ph.get("xfrm") else 0
            if area > best:
                best, bp = area, ph
    return tp, bp


def pick_layout(layouts, role):
    prefer = {"title": ["ctrTitle", "title"], "section": ["secHead", "titleOnly"]}.get(role, [])
    for typ in prefer:
        for i, lay in enumerate(layouts):
            if typ in {p["type"] for p in lay["placeholders"]}:
                return i
    for i, lay in enumerate(layouts):
        ts = {p["type"] for p in lay["placeholders"]}
        if "title" in ts and ({"body", "obj"} & ts):
            return i
    for i, lay in enumerate(layouts):
        if "title" in {p["type"] for p in lay["placeholders"]}:
            return i
    return 0 if layouts else None


def compose_slide(page, layout, no):
    tp, bp = placeholders_of(layout)
    title = str(page.get("title") or "")
    bullets = [str(b) for b in (page.get("bullets") or []) if str(b).strip()]
    size, ts = fit(bullets, title)
    shapes, rep = [], {"placeholders": [], "freetext": 0}
    sid = 2
    ta = list(tp["xfrm"]) if tp and tp.get("xfrm") else [914400, 457200, 10363200, 1371600]
    ba = list(bp["xfrm"]) if bp and bp.get("xfrm") else [914400, 1600200, 10363200, 4572000]
    if tp:
        ps = [_para(title, ts, True, "none")] if title else []
        if tp["type"] == "ctrTitle" and page.get("claim"):
            ps.append(_para(page["claim"], 16, False, "none"))
        shapes.append(_sp(sid, "Title", ta, ps or ['<a:p><a:endParaRPr lang="en-US"/></a:p>'],
                          (tp["type"], tp.get("idx") or "")))
        rep["placeholders"].append({"ph": "title", "type": tp["type"]})
        sid += 1
    elif title:
        shapes.append(_sp(sid, "Title", ta, [_para(title, ts, True, "none")]))
        rep["freetext"] += 1
        sid += 1
    if bp and bullets:
        shapes.append(_sp(sid, "Body", ba, [_para(b, size, bullet="dot") for b in bullets],
                          (bp["type"], bp.get("idx") or "")))
        rep["placeholders"].append({"ph": "body", "type": bp["type"]})
        sid += 1
    elif bullets:
        shapes.append(_sp(sid, "Body", ba, [_para(b, size, bullet="dot") for b in bullets]))
        rep["freetext"] += 1
    return slide_xml(shapes), rep


def _rel_xml(rels):
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', '<Relationships xmlns="%s">' % RL]
    for rid, r in rels.items():
        out.append('<Relationship Id="%s" Type="%s" Target="%s"/>' % (ea(rid), ea(r["type"]), ea(r["target"])))
    out.append("</Relationships>")
    return "".join(out)


def build_deck(base_path, pages, out_path, mode="create"):
    parts = read_package(base_path)
    info = analyze_parts(parts)
    layouts = info["layouts"]
    if not layouts:
        raise ValueError("no slideLayout")
    kept = list(info["slides"]) if mode in ("edit", "adapt") else []
    ct = parts["[Content_Types].xml"].decode("utf-8")

    report = {"mode": mode, "master_sha": {m: sha(parts[m]) for m in info["masters"]},
              "theme_sha": {t: sha(parts[t]) for t in info["themes"]},
              "layout_sha": {l["part"]: sha(parts[l["part"]]) for l in layouts},
              "preserved": len(kept), "added": 0, "pages": [], "errors": []}
    pres_xml = parts["ppt/presentation.xml"].decode("utf-8")
    prel = _rels(parts, "ppt/presentation.xml")
    used = set(prel)
    nr = [1]

    def new_rid():
        while "rId%d" % nr[0] in used:
            nr[0] += 1
        used.add("rId%d" % nr[0])
        return "rId%d" % nr[0]

    nid = [max([int(s) + 1 for s in re.findall(r'sldId id="(\d+)"', pres_xml)] or [256])]
    nm_rid = next((r for r in prel if prel[r]["type"] == TNM), None)
    if not any(n.startswith("ppt/notesMasters/") for n in parts):
        parts["ppt/notesMasters/notesMaster1.xml"] = NM.encode("utf-8")
        trel = {"rId1": {"type": TH, "target": posixpath.relpath(info["themes"][0], "ppt/notesMasters").replace("\\", "/")}} if info["themes"] else {}
        parts["ppt/notesMasters/_rels/notesMaster1.xml.rels"] = _rel_xml(trel).encode("utf-8")
        if CNM not in ct:
            ct = ct.replace("</Types>", '<Override PartName="/ppt/notesMasters/notesMaster1.xml" ContentType="%s"/></Types>' % CNM)
            parts["[Content_Types].xml"] = ct.encode("utf-8")
        nm_rid = new_rid()
        prel[nm_rid] = {"type": TNM, "target": "notesMasters/notesMaster1.xml"}

    def add_ct(x, part, ctype):
        return x if ('PartName="/%s"' % part) in x else x.replace("</Types>",
               '<Override PartName="/%s" ContentType="%s"/></Types>' % (part, ctype))

    entries = []
    for i, page in enumerate(pages):
        no = len(kept) + i + 1
        layout = layouts[pick_layout(layouts, page.get("role", "content"))]
        xml, slrep = compose_slide(page, layout, no)
        sp = "ppt/slides/slide%d.xml" % no
        parts[sp] = xml.encode("utf-8")
        srels = {"rId1": {"type": TL, "target": posixpath.relpath(layout["part"], "ppt/slides").replace("\\", "/")},
                 "rId2": {"type": TN, "target": "../notesSlides/notesSlide%d.xml" % no}}
        npart = "ppt/notesSlides/notesSlide%d.xml" % no
        parts[npart] = notes_xml(page.get("notes_lines") or []).encode("utf-8")
        parts["ppt/notesSlides/_rels/notesSlide%d.xml.rels" % no] = _rel_xml(
            {"rId1": {"type": TS, "target": "../slides/slide%d.xml" % no},
             "rId2": {"type": TNM, "target": "../notesMasters/notesMaster1.xml"}})
        parts["ppt/slides/_rels/slide%d.xml.rels" % no] = _rel_xml(srels)
        ct = add_ct(ct, sp, CS)
        ct = add_ct(ct, npart, CNN)
        r = new_rid()
        entries.append('<p:sldId id="%d" r:id="%s"/>' % (nid[0], r))
        nid[0] += 1
        prel[r] = {"type": TS, "target": "slides/slide%d.xml" % no}
        report["pages"].append({"n": no, "role": page.get("role"), "layout": layout["part"], **slrep})

    if "sldIdLst" not in pres_xml:  # 0-slide templates may omit the element entirely
        anchor = "<p:sldSz" if "<p:sldSz" in pres_xml else "<p:notesSz"
        pres_xml = pres_xml.replace(anchor, "<p:sldIdLst/>" + anchor, 1) if anchor in pres_xml \
            else pres_xml.replace("</p:presentation>", "<p:sldIdLst/></p:presentation>", 1)
    if "<p:notesMasterIdLst>" not in pres_xml:
        ins = '<p:notesMasterIdLst><p:notesMasterId r:id="%s"/></p:notesMasterIdLst>' % nm_rid
        pres_xml = pres_xml.replace("<p:sldIdLst>", ins + "<p:sldIdLst>", 1) if "<p:sldIdLst>" in pres_xml \
            else pres_xml.replace("<p:sldIdLst/>", ins + "<p:sldIdLst/>", 1)
    body = "".join(entries)
    pres_xml = pres_xml.replace("</p:sldIdLst>", body + "</p:sldIdLst>") if "</p:sldIdLst>" in pres_xml \
        else pres_xml.replace("<p:sldIdLst/>", "<p:sldIdLst>" + body + "</p:sldIdLst>")
    parts["ppt/presentation.xml"] = pres_xml.encode("utf-8")
    parts["ppt/_rels/presentation.xml.rels"] = _rel_xml(prel).encode("utf-8")
    parts["[Content_Types].xml"] = ct.encode("utf-8")
    report["added"] = len(pages)
    write_package(parts, out_path)
    return report


def verify_pptx(path):
    try:
        parts = read_package(path)
    except Exception as e:
        return {"ok": False, "problems": [str(e)], "slides": 0, "has_presentation": False}
    problems = []
    if "ppt/presentation.xml" not in parts:
        problems.append("missing presentation.xml")
    slides = sorted((n for n in parts if re.match(r"ppt/slides/slide\d+\.xml$", n)),
                    key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    nl = sum(1 for s in slides if not any(r["type"] == TL for r in _rels(parts, s).values()))
    if nl:
        problems.append("%d slides without layout" % nl)
    return {"ok": not problems and bool(slides), "problems": problems,
            "slides": len(slides), "has_presentation": "ppt/presentation.xml" in parts}


def pdf_page_count(path):
    data = Path(path).read_bytes()
    hdr = data[:1024].startswith(b"%PDF-")
    pages = 0
    for m in re.finditer(rb"/Type\s*/Pages[^>]*?/Count\s+(\d+)", data):
        pages = max(pages, int(m.group(1)))
    if not pages:
        pages = len(re.findall(rb"/Type\s*/Page[^>]", data))
    return pages, hdr


def find_soffice():
    return shutil.which("soffice") or shutil.which("libreoffice")


def render_pdf_soffice(pptx, out_pdf):
    so = find_soffice()
    if not so:
        return None
    tmp = Path(out_pdf).parent / ".soffice_tmp"
    tmp.mkdir(parents=True, exist_ok=True)
    try:
        subprocess.run([so, "--headless", "--convert-to", "pdf", "--outdir", str(tmp), str(pptx)],
                       check=True, timeout=120, capture_output=True)
    except Exception:
        return None
    prod = tmp / (Path(pptx).stem + ".pdf")
    if prod.exists():
        shutil.move(str(prod), str(out_pdf))
        shutil.rmtree(str(tmp), ignore_errors=True)
        return "libreoffice"
    return None


import glob as _glob
import struct as _struct
import zlib as _zlib

_CJK_CACHE = {}


def _u16(b, o):
    return _struct.unpack(">H", b[o:o + 2])[0]


def _sfnt_tables(data):
    """Return (table_dict, sfnt_bytes). Handles plain TTF and first face of a TTC."""
    if data[:4] == b"ttcf":
        off = _struct.unpack(">I", data[12:16])[0]
    else:
        off = 0
    num = _u16(data, off + 4)
    tabs = {}
    for i in range(num):
        r = off + 12 + 16 * i
        tag = data[r:r + 4].decode("latin-1")
        to, ln = _struct.unpack(">II", data[r + 8:r + 16])
        tabs[tag] = bytes(data[to:to + ln])
    return tabs


def _build_sfnt(tabs):
    tags = sorted(tabs)
    num = len(tags)
    p = 1
    while p * 2 <= num:
        p *= 2
    head = bytearray(tabs["head"])
    head[8:12] = b"\0\0\0\0"
    tabs = dict(tabs); tabs["head"] = bytes(head)
    out = [_struct.pack(">IHHHH", 0x00010000, num, p * 16, p.bit_length() - 1, num * 16 - p * 16)]
    pos = 12 + 16 * num
    recs, blobs = [], []
    head_off = None
    for t in tags:
        d = tabs[t]
        pad = d + b"\0" * ((4 - len(d) % 4) % 4)
        csum = sum(_struct.unpack(">%dI" % (len(pad) // 4), pad)) & 0xFFFFFFFF
        recs.append(t.encode("latin-1") + _struct.pack(">III", csum, pos, len(d)))
        blobs.append(pad)
        if t == "head":
            head_off = pos
        pos += len(pad)
    font = b"".join(out + recs + blobs)
    pad = font + b"\0" * ((4 - len(font) % 4) % 4)
    total = sum(_struct.unpack(">%dI" % (len(pad) // 4), pad)) & 0xFFFFFFFF
    adj = (0xB1B0AFBA - total) & 0xFFFFFFFF
    font = font[:head_off + 8] + _struct.pack(">I", adj) + font[head_off + 12:]
    return font


def _parse_cmap(tabs):
    cm = tabs.get("cmap")
    if not cm:
        return {}
    subs = []
    for i in range(_u16(cm, 2)):
        plat, enc, off = _struct.unpack(">HHI", cm[4 + 8 * i:12 + 8 * i])
        subs.append((plat, enc, off))
    subs.sort(key=lambda s: 0 if (s[0], s[1]) in ((3, 10), (0, 4)) else 1 if s[0] in (0, 3) else 2)
    for _plat, _enc, off in subs:
        fmt = _u16(cm, off)
        st = cm[off:]
        if fmt == 12:
            m = {}
            for g in range(_struct.unpack(">I", st[12:16])[0]):
                a, b, gid0 = _struct.unpack(">III", st[16 + 12 * g:28 + 12 * g])
                for u in range(a, min(b, a + 20000) + 1):
                    m[u] = gid0 + u - a
            if m:
                return m
        if fmt == 4:
            seg = _u16(st, 6) // 2
            ends = [_u16(st, 14 + 2 * i) for i in range(seg)]
            starts = [_u16(st, 16 + 2 * seg + 2 * i) for i in range(seg)]
            deltas = [_struct.unpack(">h", st[18 + 4 * seg + 2 * i:20 + 4 * seg + 2 * i])[0] for i in range(seg)]
            ro_off = 20 + 6 * seg
            m = {}
            for i in range(seg):
                for u in range(starts[i], min(ends[i], 0xFFFF) + 1):
                    if u == 0xFFFF:
                        continue
                    ro = _u16(st, ro_off + 2 * i)
                    if ro == 0:
                        gid = (u + deltas[i]) & 0xFFFF
                    else:
                        gp = ro_off + 2 * i + ro + 2 * (u - starts[i])
                        gid = _u16(st, gp)
                        gid = (gid + deltas[i]) & 0xFFFF if gid else 0
                    if gid:
                        m[u] = gid
            if m:
                return m
    return {}


def _font_paths():
    roots = []
    win = os.environ.get("SystemRoot", r"C:\Windows")
    roots += [os.path.join(win, "Fonts", n) for n in ("simhei.ttf", "msyh.ttc", "simsun.ttc", "simkai.ttf", "Deng.ttf")]
    for pat in ("/usr/share/fonts/**/*oto*JK*.tt?", "/usr/share/fonts/**/*wqy*.tt?",
                "/usr/share/fonts/**/DroidSansFallback*.ttf", "/usr/share/fonts/**/uming.ttc",
                "/System/Library/Fonts/PingFang.ttc", "/System/Library/Fonts/STHeiti*.ttc"):
        roots += sorted(_glob.glob(pat, recursive=True))
    return roots


def _load_cjk():
    """Locate a system CJK TrueType font, return (sfnt_bytes, cmap) or (None, {})."""
    if "v" in _CJK_CACHE:
        return _CJK_CACHE["v"]
    res = (None, {})
    envf = os.environ.get("CJK_FONT")
    for f in ([envf] if envf else []) + _font_paths():
        try:
            if not f or not os.path.isfile(f):
                continue
            data = Path(f).read_bytes()
            tabs = _sfnt_tables(data)
            if "glyf" not in tabs or "cmap" not in tabs or "head" not in tabs:
                continue  # skip CFF-based OTF
            cmap = _parse_cmap(tabs)
            if sum(1 for u in cmap if u >= 0x4E00) < 1000:
                continue
            res = (_build_sfnt(tabs), cmap)
            break
        except Exception:
            continue
    _CJK_CACHE["v"] = res
    return res


def _pesc(s):
    s = str(s).encode("latin-1", "replace").decode("latin-1")
    return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _tj(text):
    """PDF text-showing operand: WinAnsi literal for Latin, UCS-2 hex via the
    predefined CID font STSong-Light (UniGB-UCS2-H) for anything else."""
    try:
        text.encode("latin-1")
        return "(%s) Tj" % _pesc(text)
    except UnicodeEncodeError:
        return "<%s> Tj" % text.encode("utf-16-be").hex().upper()


def _font_of(text):
    try:
        text.encode("latin-1")
        return "/F1"
    except UnicodeEncodeError:
        return "/F2"


def _disp_w(s):
    return sum(1.0 if ord(c) > 0x2E7F else 0.55 for c in str(s))


def _wrap(s, width):
    out, cur, w = [], "", 0.0
    for c in str(s):
        cw = 1.0 if ord(c) > 0x2E7F else 0.55
        if w + cw > width and cur:
            out.append(cur); cur, w = "", 0.0
        cur += c; w += cw
    if cur:
        out.append(cur)
    return out or [""]


def _compose_page_streams(pages):
    """Return (list of content-stream bytes, set of codepoints drawn with F2)."""
    streams, used = [], set()
    for i, page in enumerate(pages):
        lines = []
        if page.get("title"):
            t = str(page.get("title"))[:120]
            if _font_of(t) == "/F2":
                used |= {ord(c) for c in t}
            lines.append("BT %s 18 Tf 54 740 Td %s ET" % (_font_of(t), _tj(t)))
        y = 690.0
        for b in (page.get("bullets") or [])[:8]:
            for j, seg in enumerate(_wrap(str(b), 88)):
                if y < 60:
                    break
                txt = ("\u2022 " if j == 0 else "  ") + seg
                if _font_of(txt) == "/F2":
                    used |= {ord(c) for c in txt}
                lines.append("BT %s 12 Tf 60 %d Td %s ET" % (_font_of(txt), int(y), _tj(txt)))
                y -= 20.0
        if page.get("claim") and page.get("role") == "title" and y > 120:
            for seg in _wrap(str(page.get("claim")), 88)[:4]:
                y -= 22.0
                if _font_of(seg) == "/F2":
                    used |= {ord(c) for c in seg}
                lines.append("BT %s 11 Tf 60 %d Td %s ET" % (_font_of(seg), int(y), _tj(seg)))
        lines.append("BT /F1 9 Tf 560 30 Td (%d) Tj ET" % (page.get("n", i + 1)))
        streams.append("\n".join(lines).encode("latin-1"))
    return streams, used


def write_text_pdf(pages, out_pdf):
    """Stdlib fallback PDF: real page objects + readable text. Latin uses
    Helvetica/WinAnsi; CJK embeds a system TrueType font (Identity-H +
    CIDToGIDMap + ToUnicode) when found, else falls back to the predefined
    STSong-Light CID font. Real render is LibreOffice when present."""
    streams, used = _compose_page_streams(pages)
    sfnt, cmap = _load_cjk()
    objs = ["<< /Type /Catalog /Pages 2 0 R >>", None,  # pages object filled after kids known
            "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"]
    embedded = bool(sfnt) and any(u in cmap for u in used)
    if embedded:
        used = {u for u in used if u in cmap}
        maxcid = max(used) if used else 0
        cgm = bytearray(2 * (maxcid + 1))
        for u in used:
            _struct.pack_into(">H", cgm, 2 * u, cmap[u])
        cgm_z = _zlib.compress(bytes(cgm))
        sfnt_z = _zlib.compress(sfnt)
        bf = "".join("<%04X> <%04X>\n" % (u, u) for u in sorted(used))
        touni = ("/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n"
                 "/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n"
                 "/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n"
                 "1 begincodespacerange\n<0000> <FFFF>\nendcodespacerange\n"
                 "%d beginbfchar\n%sendbfchar\nendcmap\nCMapName currentdict /CMap defineresource pop\nend\nend"
                 % (len(used), bf))
        touni_b = touni.encode("latin-1")
        wspec = " ".join("%d [%d]" % (u, 500 if u < 0x2E80 else 1000) for u in sorted(used))
        objs += ["<< /Type /Font /Subtype /Type0 /BaseFont /EmbeddedCJK /Encoding /Identity-H /DescendantFonts [5 0 R] /ToUnicode 8 0 R >>",
                 "<< /Type /Font /Subtype /CIDFontType2 /BaseFont /EmbeddedCJK /CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> /FontDescriptor 6 0 R /CIDToGIDMap 7 0 R /DW 1000 /W [ %s ] >>" % wspec,
                 "<< /Type /FontDescriptor /FontName /EmbeddedCJK /Flags 4 /FontBBox [-1000 -1000 3000 3000] /ItalicAngle 0 /Ascent 1000 /Descent -300 /CapHeight 800 /StemV 80 /FontFile2 9 0 R >>",
                 "<< /Length %d /Filter /FlateDecode >>\nstream\n" % len(cgm_z) + cgm_z.decode("latin-1") + "\nendstream",
                 "<< /Length %d >>\nstream\n" % len(touni_b) + touni_b.decode("latin-1") + "\nendstream",
                 "<< /Length %d /Filter /FlateDecode /Length1 %d >>\nstream\n" % (len(sfnt_z), len(sfnt)) + sfnt_z.decode("latin-1") + "\nendstream"]
    else:
        objs += ["<< /Type /Font /Subtype /Type0 /BaseFont /STSong-Light /Encoding /UniGB-UCS2-H /DescendantFonts [5 0 R] >>",
                 "<< /Type /Font /Subtype /CIDFontType0 /BaseFont /STSong-Light /CIDSystemInfo << /Registry (Adobe) /Ordering (GB1) /Supplement 5 >> /FontDescriptor 6 0 R >>",
                 "<< /Type /FontDescriptor /FontName /STSong-Light /Flags 6 /FontBBox [-25 -254 1000 880] /ItalicAngle 0 /Ascent 880 /Descent -120 /CapHeight 880 /StemV 80 >>"]
    first_content = len(objs) + 1  # 1-based id of first content stream
    kids = " ".join("%d 0 R" % (first_content + 2 * i + 1) for i in range(len(pages)))
    objs[1] = "<< /Type /Pages /Kids [%s] /Count %d >>" % (kids, len(pages))
    for i, content in enumerate(streams):
        objs.append("<< /Length %d >>\nstream\n" % len(content) + content.decode("latin-1") + "\nendstream")
        objs.append("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents %d 0 R >>" % (first_content + 2 * i))
    out = ["%PDF-1.4"]
    for i, o in enumerate(objs, 1):
        out.append("%d 0 obj" % i); out.append(o); out.append("endobj")
    pos = len(out[0]) + 1
    offsets = []
    for o in out[1:]:
        offsets.append(pos)
        pos += len(o.encode("latin-1")) + 1
    out.append("xref"); out.append("0 %d" % (len(objs) + 1)); out.append("0000000000 65535 f ")
    for p in offsets:
        out.append("%010d 00000 n " % p)
    out.append("trailer"); out.append("<< /Size %d /Root 1 0 R >>" % (len(objs) + 1))
    out.append("startxref"); out.append(str(pos)); out.append("%%EOF")
    Path(out_pdf).write_bytes(("\n".join(out) + "\n").encode("latin-1"))

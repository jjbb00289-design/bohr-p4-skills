#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""paper-to-slides: default command runs the full pipeline from /input."""
import argparse, json, os, re, shutil, subprocess, sys, zipfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import deck

VERSION = "1.0.0"; SKILL = "paper-to-slides"
DEFAULTS = {"input": "/input", "work": "/app/work", "output": "/app/output"}
TEXT_EXT = {".md", ".markdown", ".txt", ".tex", ".rst", ".csv", ".tsv", ".json", ".yaml", ".yml", ".html", ".htm"}
DOC_EXT = {".docx"}; PDF_EXT = {".pdf"}; DECK_EXT = {".pptx", ".potx", ".ppt"}
IMG_EXT = {".png", ".jpg", ".jpeg", ".gif", ".bmp"}
FIG_PAT = re.compile(r'(Fig(?:ure|\.)?\.?\s*\d+[a-z]?|Table\s*\d+|Eq(?:uation)?\.?\s*\d+|Scheme\s*\d+|图\s*\d+|表\s*\d+|式\s*\d+)', re.I)
NUM_PAT = re.compile(r'-?\d+(?:\.\d+)?\s*(?:%|±|×|ms|s|mm|nm|μm|µM|mM|M|mV|V|℃|°C|K|Hz|MHz|GHz|dB|mg|g|kg|mL|L|W|J|Pa|nM|pM)?\b')
ROLES = ["background", "method", "result", "limitation", "conclusion"]
HINTS = {"background": "problem challenge however although despite gap limited motivation objective herein this work we propose aim goal 问题 挑战 然而 现有 不足 本文 提出 旨在 动机 需求",
         "method": "method using dataset model algorithm pipeline architecture experimental protocol setup parameters collected samples framework trained evaluated 方法 模型 数据集 训练 采用 构建 实验 参数 网络 框架 优化",
         "result": "result figure fig. table showed found achieved obtained increased decreased compared performance accuracy precision recall improve higher lower outperform reached yield 结果 表明 达到 提高 降低 如图 准确率 相比 优于 实验 百分点",
         "limitation": "limitation limited future work further however should be caution small sample cannot does not remains 局限 不足 尚未 仍 下降 依赖 未能 仅",
         "conclusion": "conclusion summary overall we conclude demonstrate future work in conclusion these findings we show 结论 综上 本文 表明 未来 展望 总结"}
_SECT = ("abstract:background|summary:background|introduction:background|background:background|related work:background|"
         "motivation:background|method:method|methods:method|materials:method|experimental:method|experiment:method|"
         "approach:method|implementation:method|model:method|result:result|results:result|evaluation:result|"
         "discussion:discussion|limitation:limitation|limitations:limitation|conclusion:conclusion|conclusions:conclusion|"
         "future work:conclusion|acknowledg:skip|reference:skip|摘要:background|引言:background|背景:background|"
         "相关工作:background|方法:method|实验:method|结果:result|讨论:discussion|局限:limitation|结论:conclusion|参考文献:skip|致谢:skip")
SECTION_KW = [tuple(p.split(":")) for p in _SECT.split("|")]


def jdump(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    t = path.with_name(path.name + ".tmp")
    t.write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    t.replace(path)


def jload(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8", errors="replace").lstrip("\ufeff"))
    except Exception:
        return default


def read_text(path):
    data = Path(path).read_bytes()
    for enc in ("utf-8", "utf-8-sig", "gb18030", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", "replace")


def norm(s):
    return re.sub(r"\s+", "", re.sub(r"[\u200b\u200c\u200d\ufeff]", "", str(s))).lower()


def resolve_io(argv):
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("--input"); p.add_argument("--work"); p.add_argument("--output")
    ns, _ = p.parse_known_args(argv)
    return {"input": Path(ns.input or os.environ.get("INPUT_DIR") or DEFAULTS["input"]),
            "work": Path(ns.work or os.environ.get("WORK_DIR") or DEFAULTS["work"]),
            "output": Path(ns.output or os.environ.get("OUTPUT_DIR") or DEFAULTS["output"])}


def _materialize_default_template():
    import base64, os, tempfile
    b64 = Path(__file__).resolve().parent.parent / "assets" / "default_template.txt"
    if b64.exists():
        out = Path(os.environ.get("WORK_DIR") or tempfile.gettempdir()) / "default_template.pptx"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(base64.b64decode(b64.read_text(encoding="ascii")))
        return out
    return _materialize_default_template()


def tpl_path():
    return _materialize_default_template()


def raw_pdf_text(data):
    out = []
    for m in re.finditer(rb"\(((?:\\.|[^\\()])*)\)\s*Tj|<([0-9A-Fa-f\s]+)>\s*Tj", data):
        s = m.group(1) if m.group(1) is not None else bytes.fromhex(m.group(2).decode())
        s = re.sub(rb"\\([()\\nrt])", lambda mm: {b"(": b"(", b")": b")", b"\\": b"\\", b"n": b"\n", b"r": b"\r", b"t": b"\t"}[mm.group(1)], s)
        out.append(s)
    return b"\n".join(out).decode("utf-8", "replace")


def find_pdf_tool():
    for name in ("pdf-text-tool", "pdftotext"):
        p = shutil.which(name)
        if p:
            return p
    root = os.path.join(os.environ.get("LOCALAPPDATA", ""), "com.bohrium.runtime")
    if os.path.isdir(root):
        for dp, _dirs, fns in os.walk(root):
            for fn in fns:
                if fn.lower() in ("pdftotext.exe", "pdf-text-tool.exe"):
                    return os.path.join(dp, fn)
    return None


def extract_pdf(path):
    tool = find_pdf_tool()
    if tool:
        base = os.path.basename(tool).lower()
        cmd = ([tool, "-layout", "-enc", "UTF-8", str(path), "-"]
               if "pdftotext" in base else [tool, str(path)])
        try:
            r = subprocess.run(cmd, capture_output=True, timeout=180)
            if r.returncode == 0 and r.stdout.strip():
                return r.stdout.decode("utf-8", "replace")
        except Exception:
            pass
    return raw_pdf_text(Path(path).read_bytes())


def extract_docx(path):
    try:
        with zipfile.ZipFile(str(path)) as z:
            xml = z.read("word/document.xml")
    except Exception:
        return ""
    from xml.etree import ElementTree as ET
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    return "\n".join("".join(t.text or "" for t in p.iter("{%s}t" % ns["w"])) for p in ET.fromstring(xml).iter("{%s}p" % ns["w"]))


def reflow(text):
    out, buf = [], ""
    for ln in text.split("\n"):
        s = ln.strip()
        if not s:
            if buf:
                out.append(buf); buf = ""
            continue
        if buf and re.search(r"[.!?。！？]\s*$", buf) and re.match(r"^[A-Z0-9\u4e00-\u9fff]", s):
            out.append(buf); buf = s
        else:
            buf = (buf + " " + s) if buf else s
    if buf:
        out.append(buf)
    return "\n\n".join(out)


def discover(d):
    return [p for p in sorted(d.rglob("*")) if p.is_file() and p.name not in ("case.json", "task.md")] if d.is_dir() else []


def build_materials(input_dir, files):
    mats, assets, decks = [], {}, []
    for f in files:
        ext = f.suffix.lower()
        mid = "m%d" % (len(mats) + len(decks) + 1)
        add = lambda t, segs: mats.append({"id": mid, "path": str(f), "type": t, "segments": segs})
        if ext in PDF_EXT:
            segs = []
            for pi, page_text in enumerate(extract_pdf(f).split("\f")):
                for pj, s in enumerate(reflow(page_text).split("\n\n")):
                    if s.strip():
                        segs.append({"locator": "%s#pg%d#p%d" % (mid, pi + 1, pj + 1), "text": s.strip()})
            add("pdf", segs)
        elif ext in DOC_EXT:
            add("docx", [{"locator": "%s#p%d" % (mid, i + 1), "text": s.strip()} for i, s in enumerate(extract_docx(f).split("\n")) if s.strip()])
        elif ext in TEXT_EXT:
            text = read_text(f)
            if ext in (".csv", ".tsv"):
                add("table", [{"locator": "%s#row%d" % (mid, i + 1), "text": s.strip()} for i, s in enumerate(text.splitlines()) if s.strip()])
            else:
                add("text", [{"locator": "%s#p%d" % (mid, i + 1), "text": s} for i, s in enumerate(re.sub(r"\s*\n\s*", " ", p).strip() for p in re.split(r"\n\s*\n", text)) if s])
        elif ext in IMG_EXT:
            assets[str(f)] = str(f)
        elif ext in DECK_EXT:
            decks.append(f)
        else:
            add("unknown", [{"locator": "%s#0" % mid, "text": str(f)}])
    return mats, assets, decks


def is_heading(line):
    line = line.strip()
    if not line or len(line) > 90 or re.match(r"^(figure|fig\.?|table)\s+\d", line, re.I):
        return False
    if re.match(r"^\s*(#+\s|\d+(\.\d+)*[\.、\)]\s|[一二三四五六七八九十]+[、.]\s)", line):
        return True
    if len(line) <= 60 and line.isupper():
        return True
    low = line.lower()
    if any(low == kw or low.startswith(kw + " ") for kw, _ in SECTION_KW):
        return True
    if len(line) <= 30:  # numbered or bare CJK heading, e.g. "4 局限性" / "结 论"
        bare = re.sub(r"^[\d\.\s、\)）#]+", "", low).replace(" ", "")
        return any(bare == kw or (bare.startswith(kw) and len(bare) <= len(kw) + 4) for kw, _ in SECTION_KW)
    return False


def split_sentences(text):
    return [p.strip() for p in re.split(r"(?<=[.!?。！？])\s+", text.replace("\u3000", " ")) if p.strip()]


def collect_sentences(mats):
    sents, heads = [], {}
    for m in mats:
        section = "background"
        for seg in m["segments"]:
            text = seg["text"].strip()
            if not text:
                continue
            if is_heading(text):
                for kw, role in SECTION_KW:
                    if kw in text.lower():
                        section = None if role == "skip" else role
                        if role != "skip":
                            heads.setdefault(role, {"text": re.sub(r"^[#\s*\-]+", "", text).strip()[:60] or text[:60], "locator": seg["locator"]})
                        break
                continue
            if section is None:
                continue
            for s in split_sentences(text):
                if 12 <= len(s) <= 520:
                    sents.append({"text": s, "locator": seg["locator"], "section": section, "figures": FIG_PAT.findall(s), "numbers": NUM_PAT.findall(s)})
    return sents, heads


def score(s, role):
    low = s["text"].lower()
    sc = sum(1 for h in HINTS[role].split() if h in low)
    if role == "result":
        sc += min(len(s["numbers"]), 6) + 3 * len(s["figures"])
    if s["section"] == role:
        sc += 2
    elif s["section"] == "discussion" and role in ("result", "limitation", "conclusion"):
        sc += 1
    return sc


def candidates(sents, role, used):
    cs = [s for s in sents if norm(s["text"]) not in used]
    cs.sort(key=lambda s: (-score(s, role), abs(len(s["text"]) - 140)))
    return cs


def bullets(sentence, n=3):
    frags = re.split(r"\s*[,;:—–]\s*|\s+\band\b\s+|\s+\bor\b\s+|\s+\.\s+", sentence)
    out, seen = [], set()
    for f in frags:
        f = f.strip()
        if 8 <= len(f) <= 160 and norm(f) not in seen:
            seen.add(norm(f)); out.append(f)
        if len(out) >= n:
            break
    return out or [sentence[:160]]


def title_of(case, mats):
    for k in ("title", "title_zh", "deck_title"):
        if isinstance(case.get(k), str) and case.get(k).strip():
            return case.get(k).strip()[:90]
    for m in mats:
        for seg in m["segments"][:3]:
            t = seg["text"].strip()
            if t and not is_heading(t):
                return t[:90]
    for m in mats:
        if m["segments"]:
            return m["segments"][0]["text"].strip()[:90]
    return "Academic Presentation"


def slide_count(case):
    for src in (case, case.get("constraints") or {}):
        for k in ("slide_count", "slides", "max_slides", "num_slides", "page_limit"):
            if isinstance(src.get(k), int) and 2 <= src.get(k) <= 60:
                return src.get(k)
    return 9


def derive_pages(mats, case):
    sents, heads = collect_sentences(mats)
    if not sents:
        return [], heads
    title = title_of(case, mats)
    n = slide_count(case)
    rest = max(n - 1, 1)
    bg = max(1, round(rest * 0.18)); meth = max(1, round(rest * 0.22)); concl = 1
    lim = 1 if any(score(s, "limitation") >= 1 for s in sents) else 0
    res = rest - bg - meth - concl - lim
    if res < 1:
        res = 1
        if bg + meth + res + concl + lim > n and bg > 1:
            bg -= 1
    plan = [("title", 1)] + [(r, 1) for r, c in (("background", bg), ("method", meth), ("result", res), ("limitation", lim), ("conclusion", concl)) for _ in range(c)]
    used = set()
    pages = []
    first = candidates(sents, "background", set())
    sub = first[0] if first else None
    pages.append({"role": "title", "title": title, "claim": sub["text"][:200] if sub else "", "bullets": [], "claim_loc": sub["locator"] if sub else None, "claim_quote": sub["text"] if sub else None})
    if sub:
        used.add(norm(sub["text"]))
    pools = {r: candidates(sents, r, used) for r in ROLES}
    for role, _ in plan[1:]:
        pool = pools.get(role)
        sent = None
        if pool:
            while pool and norm(pool[0]["text"]) in used:
                pool.pop(0)
            if pool:
                sent = pool.pop(0); used.add(norm(sent["text"]))
        if sent is None:
            for s in sents:
                if norm(s["text"]) not in used:
                    sent = s; used.add(norm(s["text"])); break
        if sent is None:
            continue
        head = heads.get(role)
        pages.append({"role": role, "title": head["text"] if head else bullets(sent["text"], 1)[0][:60], "claim": sent["text"], "bullets": bullets(sent["text"], 4), "claim_loc": sent["locator"], "claim_quote": sent["text"], "figure_refs": sent["figures"]})
    return pages, heads


def notes(page, nxt):
    """Talking guidance that complements the slide instead of repeating it."""
    role = page.get("role")
    loc = page.get("claim_loc") or ""
    figs = page.get("figure_refs") or []
    trans = {"title": "开场：一句话说明论文问题、本文做法与汇报结构，30 秒内进入背景。",
             "background": "讲法：先讲领域已做到什么，再点出尚未解决的缺口，引出本文动机。",
             "method": "讲法：对照背景页的缺口解释方法每一步为何这样设计，不停留在流程罗列。",
             "result": "讲法：先报结论数值，再指出支撑该数值的图/表；口头复述单位与条件。",
             "limitation": "讲法：主动说明适用边界与失败情形，避免被问及时被动。",
             "conclusion": "讲法：把结果页数值收束回背景页的问题，再给下一步方向。"}.get(role, "")
    lines = [trans] if trans else []
    if figs:
        lines.append("证据：本页数值对应 %s；展示时先指图再读数。" % "、".join(figs))
    if loc:
        lines.append("溯源：主张逐字原文见 %s（content_map.json 含 quote 可当场核对）。" % loc)
    lines.append({"title": "被追问时：说明材料来源文件与选取标准。",
                  "background": "被追问时：用原文限制句说明缺口为何重要。",
                  "method": "被追问时：补数据集规模、超参数与评价协议（见 locator 段落）。",
                  "result": "被追问时：强调数值未改写，可直接回原文图/表核对。",
                  "limitation": "被追问时：区分本文未做与原理上不可做。",
                  "conclusion": "被追问时：结论不超出结果页已展示的数值范围。"}.get(role, ""))
    if nxt:
        lines.append("过渡：由本页引出下一页「%s」。" % nxt[:40])
    return [l for l in lines if l]


def find_template(case, files, input_dir):
    pptx = [f for f in files if f.suffix.lower() in (".pptx", ".potx")]
    if not pptx:
        return None, None
    def ref(v):
        if not isinstance(v, str) or not v.strip():
            return None
        p = Path(v)
        return (p if p.is_absolute() else input_dir / p) if p.exists() else None
    tpl = ref(case.get("template") or case.get("template_path") or case.get("template_file"))
    dk = ref(case.get("deck") or case.get("starting_deck") or case.get("start_deck") or case.get("deck_path"))
    rest = [f for f in pptx if f != tpl and f != dk]
    if tpl is None and dk is None:
        if len(pptx) == 1:
            return pptx[0], None
        cs = []
        for f in pptx:
            try:
                cs.append((f, len(deck.analyze(f)["slides"])))
            except Exception:
                cs.append((f, 0))
        cs.sort(key=lambda x: x[1])
        return cs[0][0], cs[-1][0] if len(cs) > 1 else None
    if tpl is None and rest:
        tpl = rest[0]
    if dk is None and rest:
        dk = rest[-1]
    return tpl, dk


def fill(k, editable, export, cm, notes, plan, previews, n):
    kl = k.lower()
    if kl.endswith("_count") or kl in ("slides", "pages", "slide_count", "page_count"):
        return n
    for ws, v in (("ppt", editable), ("presentation", editable), ("deck", editable), ("editable", editable),
                  ("pdf", export), ("export", export), ("render", export), ("preview", previews), ("png", previews),
                  ("content", cm), ("claim", cm), ("evidence", cm), ("map", cm), ("page", cm),
                  ("note", notes), ("script", notes), ("speaker", notes), ("plan", plan), ("golden", plan)):
        if ws in kl:
            return v
    return {"artifacts": ["presentation.pptx", "presentation.pdf", "content_map.json", "page_plan.json", "evidence_map.json"],
            "note": "contract key not matched to a specific artifact; main deliverables listed"}


def minimal(case_id, status, errs, mats, case):
    oc = case.get("output_contract") or {} if isinstance(case, dict) else {}
    r = {"case_id": case_id, "status": status}
    for k in oc:
        r[k] = None
    r["output_contract"] = oc
    r["sources"] = [{"id": m["id"], "path": m["path"], "type": m["type"]} for m in mats]
    r["uncertainty"] = ["no usable evidence extracted"]
    r["changes"] = []; r["errors"] = errs; r["degradations"] = []
    r["coverage"] = {"pages": 0, "slides": 0, "quote_hit_rate": 0.0, "roles": []}
    r["skill"] = {"name": SKILL, "version": VERSION}
    return r


def run_pipeline(io):
    work, out = io["work"], io["output"]
    work.mkdir(parents=True, exist_ok=True); out.mkdir(parents=True, exist_ok=True)
    jdump(out / "result.json", {"case_id": "", "status": "partial", "errors": ["pipeline started"], "sources": [], "uncertainty": [], "changes": [], "degradations": []})
    cp = io["input"] / "case.json"
    if not (io["input"].is_dir() and cp.exists()):
        jdump(out / "result.json", minimal("", "input_error", ["case.json not found"], [], {}))
        return 0
    try:
        case = json.loads(cp.read_text(encoding="utf-8", errors="replace").lstrip("\ufeff"))
        if not isinstance(case, dict):
            case = {}
    except Exception as e:
        jdump(out / "result.json", minimal("", "input_error", ["case.json invalid: %s" % e], [], {}))
        return 0
    case_id = case.get("case_id") or case.get("id") or ""
    degs = []
    files = discover(io["input"])
    mats, assets, decks = build_materials(io["input"], files)
    jdump(work / "index.json", {"case_id": case_id, "materials": [{"id": m["id"], "path": m["path"], "type": m["type"], "segments": len(m["segments"])} for m in mats], "assets": sorted(assets), "decks": [str(d) for d in decks]})
    if not mats:
        jdump(out / "result.json", minimal(case_id, "insufficient_evidence", ["no readable material"], mats, case))
        return 0
    pages, heads = derive_pages(mats, case)
    if not pages:
        jdump(out / "result.json", minimal(case_id, "insufficient_evidence", ["no usable sentences"], mats, case))
        return 0

    tpl, dk = find_template(case, files, io["input"])
    base, mode = tpl, "create"
    if dk is not None and (case.get("mode") or "").lower() in ("edit", "adapt"):
        base, mode = dk, "edit"
    if base is None:
        base = tpl_path()
        degs.append("no template supplied; used bundled default academic template")
    for i, p in enumerate(pages):
        p["notes_lines"] = notes(p, pages[i + 1]["title"] if i + 1 < len(pages) else "")
    try:
        report = deck.build_deck(str(base), pages, str(out / "presentation.pptx"), mode=mode)
    except Exception as e:
        jdump(out / "result.json", minimal(case_id, "partial", ["build failed: %s" % e], mats, case))
        return 0
    if report.get("errors"):
        degs.append("deck build: %s" % "; ".join(report["errors"]))

    engine = deck.render_pdf_soffice(str(out / "presentation.pptx"), str(out / "presentation.pdf"))
    pdf = out / "presentation.pdf"
    if not engine:
        try:
            deck.write_text_pdf(pages, str(pdf)); engine = "text-layer-pdf"
            degs.append("no LibreOffice; PDF is a text-layer render")
        except Exception:
            degs.append("PDF export failed")
    pngs = []
    if pdf.exists():
        (out / "preview").mkdir(parents=True, exist_ok=True)
        try:
            r = subprocess.run(["pdftoppm", "-png", "-r", "90", str(pdf), str(out / "preview" / "slide")], capture_output=True, timeout=120)
            if r.returncode == 0:
                pngs = sorted("preview/" + p.name for p in (out / "preview").glob("slide-*.png"))
        except Exception:
            pass

    v = deck.verify_pptx(out / "presentation.pptx")
    pp, hdr = deck.pdf_page_count(pdf) if pdf.exists() else (0, False)
    cn = norm("\n".join(seg["text"] for m in mats for seg in m["segments"]))
    lp = {m["id"]: m["path"] for m in mats}
    cm, hits = [], 0
    for i, p in enumerate(pages):
        q = p.get("claim_quote") or ""
        hit = bool(norm(q)) and norm(q) in cn
        hits += 1 if hit else 0
        loc = p.get("claim_loc") or ""
        ev = [{"type": "sentence", "locator": loc, "quote": q, "verbatim_hit": hit}]
        ev += [{"type": "figure", "id": fr, "locator": loc, "quote": q} for fr in (p.get("figure_refs") or [])]
        cm.append({"n": i + 1, "role": p["role"], "title": p["title"], "claim": p["claim"], "bullets": p["bullets"], "source": {"path": lp.get(loc.split("#")[0] if loc else "", ""), "locator": loc}, "evidence": ev, "figure_refs": p.get("figure_refs") or [], "notes": p["notes_lines"]})
    qhr = (hits / len(pages)) if pages else 0.0

    editable = {"path": "presentation.pptx", "slides": v["slides"], "mode": mode, "template": {"path": "assets/default_template.pptx" if base == tpl_path() else str(base), "master_sha256": report.get("master_sha", {}), "layouts_used": [pg.get("layout") for pg in report.get("pages", [])]}, "verification": v}
    export = {"pdf": {"path": "presentation.pdf", "engine": engine or "none", "pages": pp, "header_ok": hdr}, "previews": pngs}
    notes_out = [{"n": i + 1, "lines": p["notes_lines"]} for i, p in enumerate(pages)]
    plan = [{"n": i + 1, "role": p["role"], "title": p["title"], "claim": p["claim"], "locator": p.get("claim_loc")} for i, p in enumerate(pages)]
    sources = [{"id": m["id"], "path": m["path"], "type": m["type"], "locator_scheme": "mN#pK | mN#pgK#pJ (pdf) | mN#rowK (table)"} for m in mats]
    unc = (["quote_hit_rate %.3f < 1.0" % qhr] if qhr < 1.0 else []) + (["no PDF produced"] if not engine else [])
    changes = [{"step": "derive", "action": "extracted %d pages from %d materials" % (len(pages), len(mats))}, {"step": "build", "action": "built pptx (mode=%s)" % mode}, {"step": "export", "action": "PDF engine=%s; %d PNG previews" % (engine or "none", len(pngs))}]
    oc = case.get("output_contract") or {}
    result = {"case_id": case_id, "status": "ok" if (qhr >= 0.95 and v["ok"] and hdr) else "partial"}
    for k in oc:
        result[k] = fill(k, editable, export, cm, notes_out, plan, pngs, v["slides"])
    # never let an output_contract field named status/case_id null out the required fields
    result["case_id"] = case_id
    result["status"] = "ok" if (qhr >= 0.95 and v["ok"] and hdr) else "partial"
    result.update({"output_contract": oc, "editable_source": editable, "export_artifact": export, "content_map": cm, "page_plan": plan, "coverage": {"pages": len(pages), "slides": v["slides"], "quote_hit_rate": qhr, "roles": [p["role"] for p in pages]}, "sources": sources, "uncertainty": unc, "changes": changes, "errors": [], "degradations": degs, "skill": {"name": SKILL, "version": VERSION}})
    jdump(out / "content_map.json", cm)
    jdump(out / "page_plan.json", plan)
    jdump(out / "evidence_map.json", [{"n": i + 1, "evidence": e["evidence"]} for i, e in enumerate(cm)])
    jdump(out / "changes.json", changes)
    jdump(out / "template_check.json", {"master_sha256": report.get("master_sha", {}), "theme_sha256": report.get("theme_sha", {}), "layouts_available": len(deck.analyze(str(base))["layouts"])})
    jdump(out / "export_check.json", {"pptx": v, "pdf": {"pages": pp, "header_ok": hdr, "engine": engine or "none"}, "previews": len(pngs)})
    jdump(out / "result.json", result)
    return 0


def main(argv):
    io = resolve_io(argv)
    try:
        p = argparse.ArgumentParser(prog=SKILL, description="paper -> editable, evidence-mapped deck")
        p.add_argument("--input"); p.add_argument("--work"); p.add_argument("--output")
        p.add_argument("--version", action="version", version=SKILL + " " + VERSION)
        p.parse_args(argv)
    except SystemExit:
        return 0
    run_pipeline(io)
    return 0


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except Exception:
        try:
            sys.stderr.write("unhandled error; writing emergency partial\n")
        except Exception:
            pass
        try:
            io = resolve_io(sys.argv[1:])
            io["output"].mkdir(parents=True, exist_ok=True)
            if not (io["output"] / "result.json").exists():
                jdump(io["output"] / "result.json", {"case_id": "", "status": "partial", "errors": ["unhandled exception"], "sources": [], "uncertainty": [], "changes": [], "degradations": ["emergency finalize"], "skill": {"name": SKILL, "version": VERSION}})
        except Exception:
            pass
    sys.exit(0)

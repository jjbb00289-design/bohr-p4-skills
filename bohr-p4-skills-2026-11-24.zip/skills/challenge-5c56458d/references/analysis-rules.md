# 分析规则与 SQL 模板

## 数据清洗五类（判据与处理）
1. **缺失值**：`""`、`NA`、`N/A`、`NaN`、`null`、`none`、`?`、`-`、`--`、`missing` 视为缺失；置空并计数，不插补（无分布依据时不臆造）。
2. **异常值**：连续列按 IQR × 1.5 判据（下界 Q1−1.5·IQR，上界 Q3+1.5·IQR），分布型判据，不硬编码固定阈值；保留原值、只标记。
3. **重复记录**：按整行逐列值精确比对；标识行索引对并报告，不静默删除。
4. **格式/单位/编码转换**：TEXT 且全可解析为数值的列记为 `numeric-as-text`，清洗表中转为数值；文件编码（utf-8/utf-8-sig/gbk/latin-1）记录进 change_records；单位依据字段字典列名归一化解释。
5. **数据质量报告**：表级行数、缺失单元格、重复行、异常单元格、舍入口径、判据声明；各计数由同一列结构汇总，保证与分字段数一致。

## 统计口径
- 连续列统计基于该列全部非缺失值：n、mean、median、stdev(总体)、min、max、Q1、Q3、IQR。
- 分类列：取值计数（最多 30 类）。
- 数值保留 6 位小数；清洗 CSV 保留原始精度。报告数字与 result.json / raw/clean CSV 同源。

## 查询模板（只读，可复算）
```sql
SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';
PRAGMA table_info("T");
SELECT COUNT(*) FROM "T";
SELECT COUNT("c"), MIN("c"), MAX("c"), AVG("c") FROM "T";
SELECT * FROM "T" LIMIT 5;
```
- 跨表连接键推断：仅当两表存在共享列名时列为候选，不臆造语义；未验证基数(1:1/1:N)前不下结论。
- 行数膨胀控制：连接前记录左表/右表行数；若一对多膨胀，须在 change_records 说明并给出去重聚合口径。

## 复现
1. `python scripts/main.py --input /input --work /app/work --output /app/output`
2. 用 query_log.json 中 SQL 在只读快照复算，与 result.json 数值比对。

# 字段字典（内置语义映射）

本字典用于解释 UCI 三个固定快照（Iris / Wine / Concrete）的列名含义与单位。
注意：这是内置语义映射，不是案例数据字典原文；如输入目录存在官方数据字典，以官方为准并在 uncertainty 中核对。

## Iris（150 行，bezdek 来源变体）
| 归一化列名 | 含义 | 单位 | 类型 |
|---|---|---|---|
| sepal_length | 萼片长度 Sepal length | cm | numeric |
| sepal_width | 萼片宽度 Sepal width | cm | numeric |
| petal_length | 花瓣长度 Petal length | cm | numeric |
| petal_width | 花瓣宽度 Petal width | cm | numeric |
| species | 鸢尾属种类 | — | categorical（setosa / versicolor / virginica）|

## Wine（178 行）
| 归一化列名 | 含义 | 单位 | 类型 |
|---|---|---|---|
| class | 品种类别 | — | categorical（1 / 2 / 3）|
| alcohol | 酒精含量 | % vol | numeric |
| malic_acid | 苹果酸 | g/L | numeric |
| ash | 灰分 | g/L | numeric |
| alcalinity_of_ash / alkalinity_of_ash | 灰分碱度 | g/L | numeric |
| magnesium | 镁 | mg/L | numeric |
| total_phenols | 总酚 | g/L | numeric |
| flavanoids | 类黄酮 | g/L | numeric |
| nonflavanoid_phenols | 非类黄酮酚 | g/L | numeric |
| proanthocyanins / proanthocyanidins | 原花青素 | g/L | numeric |
| color_intensity | 颜色强度 | absorbance | numeric |
| hue | 色调 | ratio | numeric |
| od280_od315_of_diluted_wines | 稀释酒液 OD280/OD315 | ratio | numeric |
| proline | 脯氨酸 | mg/L | numeric |

## Concrete Compressive Strength（1030 行）
| 归一化列名 | 含义 | 单位 | 类型 |
|---|---|---|---|
| cement | 水泥 | kg/m^3 | numeric |
| blast_furnace_slag / slag | 高炉矿渣 | kg/m^3 | numeric |
| fly_ash | 粉煤灰 | kg/m^3 | numeric |
| water | 水 | kg/m^3 | numeric |
| superplasticizer / superplasticiser | 高效减水剂 | kg/m^3 | numeric |
| coarse_aggregate | 粗骨料 | kg/m^3 | numeric |
| fine_aggregate | 细骨料 | kg/m^3 | numeric |
| age | 龄期 | days | numeric |
| concrete_compressive_strength / compressive_strength / strength | 混凝土抗压强度 | MPa | numeric |

列名归一化：`[^a-z0-9]+` → `_`，小写化；因此 `sepal length (cm)`、`SepalLengthCm`、`sepal_length_cm` 均归一化为 `sepal_length` 命中。

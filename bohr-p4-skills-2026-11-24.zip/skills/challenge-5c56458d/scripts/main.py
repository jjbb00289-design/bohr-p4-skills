#!/usr/bin/env python3
import argparse
import json
import os
import sys
import traceback
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

VERSION = "1.0.0"
DEFAULT_INPUT, DEFAULT_WORK, DEFAULT_OUTPUT = "/input", "/app/work", "/app/output"
ENCODINGS = ("utf-8-sig", "utf-8", "gbk", "latin-1")


def jwrite(path, obj):
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2)
        fh.write("\n")


def read_text(path):
    data = path.read_bytes()
    for enc in ENCODINGS:
        try:
            return data.decode(enc), enc
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode("latin-1", errors="replace"), "latin-1(replace)"


def resolve_paths(args):
    e = os.environ
    return {"input": args.input or e.get("INPUT_DIR") or DEFAULT_INPUT,
            "work": args.work or e.get("WORK_DIR") or DEFAULT_WORK,
            "output": args.output or e.get("OUTPUT_DIR") or DEFAULT_OUTPUT}


def read_case(input_dir):
    meta = {"case_id": None, "contract": {}, "task_instruction": "", "task_md": "", "errors": [], "input_exists": False, "case_data": {}}
    p = Path(input_dir)
    if not p.is_dir():
        meta["errors"].append({"stage": "read_case", "message": "input dir missing: %s" % input_dir})
        return meta
    meta["input_exists"] = True
    cj = p / "case.json"
    if not cj.exists():
        meta["errors"].append({"stage": "read_case", "message": "case.json not found"})
        return meta
    text, _ = read_text(cj)
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        meta["errors"].append({"stage": "read_case", "message": "bad JSON: %s" % e})
        return meta
    d = meta["case_data"] = data if isinstance(data, dict) else {}
    meta["case_id"] = d.get("case_id") or d.get("id") or d.get("caseId")
    c = d.get("output_contract")
    meta["contract"] = c if isinstance(c, dict) else {}
    meta["task_instruction"] = d.get("task_instruction") or d.get("task") or d.get("instruction") or ""
    tm = p / "task.md"
    if tm.exists():
        try:
            meta["task_md"], _ = read_text(tm)
        except OSError as e:
            meta["errors"].append({"stage": "read_task", "message": str(e)})
    return meta


def build_partial(meta):
    result = {"case_id": meta["case_id"], "status": "input_error" if meta["errors"] else "partial"}
    for k in meta["contract"]:
        result[k] = None
    result.update({"output_contract_echo": meta["contract"], "version": VERSION, "errors": list(meta["errors"]),
                   "degradations": [], "gaps": [], "sources": [], "uncertainty": [], "change_records": [],
                   "summary": {}, "analysis": {}})
    if meta["task_instruction"]:
        result["task_instruction"] = meta["task_instruction"]
    return result


def assemble(meta, report):
    result = {"case_id": meta["case_id"], "output_contract_echo": meta["contract"],
              "version": VERSION, "task_instruction": meta["task_instruction"]}
    for k in meta["contract"]:
        result[k] = None
    if meta["task_md"]:
        result["task_md_preview"] = meta["task_md"][:500]
    def _norm(s):
        return "".join(ch for ch in s.lower() if ch.isalnum())
    rm = {_norm(k): v for k, v in report.items() if isinstance(v, (dict, list))}
    for key in meta["contract"]:
        if _norm(key) in rm:
            result[key] = rm[_norm(key)]
    result.update({"status": report.get("status", "partial"),
                   "errors": list(report.get("errors", [])) + list(meta["errors"]),
                   "degradations": report.get("degradations", []),
                   "gaps": report.get("gaps", []),
                   "sources": report.get("sources", []),
                   "uncertainty": report.get("uncertainty", []),
                   "change_records": report.get("change_records", []),
                   "summary": report.get("summary", {}),
                   "analysis": report.get("analysis", {}),
                   "artifacts": report.get("artifacts", [])})
    return result


def cmd_run(paths):
    input_dir, work_dir, output_dir = paths["input"], paths["work"], paths["output"]
    for d in (work_dir, output_dir):
        try:
            Path(d).mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
    meta = read_case(input_dir)
    partial = build_partial(meta)
    try:
        jwrite(Path(work_dir) / "partial_result.json", partial)
        jwrite(Path(output_dir) / "result.json", partial)
    except OSError as e:
        partial["errors"].append({"stage": "write_partial", "message": str(e)})
    report = None
    try:
        import analysis
    except Exception as e:
        report = {"status": "partial", "errors": [{"stage": "import_analysis", "message": str(e)}]}
    if report is None:
        try:
            report = analysis.run(input_dir, work_dir, output_dir, meta)
        except Exception as e:
            report = {"status": "partial", "errors": [{"stage": "analysis", "message": "%s: %s" % (type(e).__name__, e)},
                                                      {"stage": "traceback", "message": traceback.format_exc(limit=5)}]}
    if not isinstance(report, dict):
        report = {"status": "partial", "errors": [{"stage": "analysis", "message": "non-dict report"}]}
    for k in ("errors", "degradations", "gaps", "sources", "uncertainty", "change_records"):
        report.setdefault(k, [])
    for k in ("summary", "analysis"):
        report.setdefault(k, {})
    for k in ("datasets", "artifacts"):
        report.setdefault(k, [])
    final = assemble(meta, report)
    try:
        jwrite(Path(work_dir) / "partial_result.json", final)
        jwrite(Path(output_dir) / "result.json", final)
        jwrite(Path(work_dir) / "run_state.json", {"version": VERSION, "input": input_dir, "work": work_dir,
                                                   "output": output_dir, "status": final["status"],
                                                   "case_id": final["case_id"], "files": report.get("input_files", [])})
    except OSError as e:
        final["errors"].append({"stage": "write_final", "message": str(e)})
        try:
            jwrite(Path(output_dir) / "result.json", final)
        except OSError:
            pass
    _print_summary(final)
    return 0


def _print_summary(final):
    print(json.dumps({"status": final.get("status"), "case_id": final.get("case_id"),
                      "errors": len(final.get("errors", [])), "degradations": len(final.get("degradations", [])),
                      "gaps": len(final.get("gaps", [])), "artifacts": len(final.get("artifacts", []))}))


def cmd_init(paths):
    for d in (paths["work"], paths["output"]):
        try:
            Path(d).mkdir(parents=True, exist_ok=True)
        except OSError as e:
            print("init mkdir fail: %s" % e)
    print(json.dumps({"ok": True, "work": paths["work"], "output": paths["output"]}))
    return 0


def cmd_show(paths):
    rp = Path(paths["output"]) / "result.json"
    if not rp.exists():
        print(json.dumps({"ok": False, "message": "result.json not found"}))
        return 0
    try:
        d = json.loads(rp.read_text(encoding="utf-8"))
        print(json.dumps({"ok": True, "case_id": d.get("case_id"), "status": d.get("status")}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"ok": False, "message": str(e)}))
    return 0


def cmd_check(paths):
    rp = Path(paths["output"]) / "result.json"
    if not rp.exists():
        print(json.dumps({"ok": False, "problems": ["result.json missing"]}))
        return 0
    try:
        d = json.loads(rp.read_text(encoding="utf-8"))
    except Exception as e:
        print(json.dumps({"ok": False, "problems": ["invalid JSON: %s" % e]}))
        return 0
    problems = [n for n in ("case_id", "status", "sources", "uncertainty", "change_records") if n not in d]
    echo = d.get("output_contract_echo")
    if isinstance(echo, dict):
        problems += ["contract field not echoed: %s" % k for k in echo if k not in d]
    print(json.dumps({"ok": not problems, "problems": problems, "status": d.get("status")}, ensure_ascii=False))
    return 0


def main(argv=None):
    try:
        p = argparse.ArgumentParser(prog="main.py", description="research-db-analysis 单命令流程（默认=完整流程）")
        p.add_argument("command", nargs="?", default="run", choices=["run", "init", "show", "check", "build"])
        p.add_argument("--input", dest="input", default=None)
        p.add_argument("--work", dest="work", default=None)
        p.add_argument("--output", dest="output", default=None)
        args = p.parse_args(argv)
        return {"run": cmd_run, "build": cmd_run, "init": cmd_init, "show": cmd_show, "check": cmd_check}[args.command](resolve_paths(args))
    except SystemExit:
        raise
    except Exception:
        try:
            out = os.environ.get("OUTPUT_DIR") or DEFAULT_OUTPUT
            Path(out).mkdir(parents=True, exist_ok=True)
            jwrite(Path(out) / "result.json", {"case_id": None, "status": "input_error",
                "errors": [{"stage": "fatal", "message": traceback.format_exc(limit=5)}],
                "degradations": [], "gaps": ["unexpected top-level failure"], "sources": [],
                "uncertainty": [], "change_records": [], "summary": {}, "analysis": {}, "artifacts": []})
        except Exception:
            pass
        return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
import json
import re
from pathlib import Path

ROUND = 6


def esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;"))


def svg_histogram(vals, title):
    lo, hi = min(vals), max(vals)
    if lo == hi:
        hi = lo + 1.0
    width = (hi - lo) / 10
    counts = [0] * 10
    for v in vals:
        counts[min(int((v - lo) / width), 9)] += 1
    mx = max(counts) or 1
    W, H, pad = 460, 260, 30
    bw, bh = (W - 60) / 10, H - 80
    p = ['<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H),
         '<text x="30" y="20" font-size="12">%s (n=%d)</text>' % (esc(title), len(vals))]
    for i, cnt in enumerate(counts):
        x, y = 30 + i * bw, H - 30 - cnt / mx * bh
        p.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="#4C78A8" stroke="#000"/><text x="%.1f" y="%d" font-size="8">%.4g</text>' % (x, y, bw - 1, cnt / mx * bh, x, H - 20, lo + i * width))
    p.append('</svg>')
    return "\n".join(p)


def svg_bar(counts, title):
    items = list(counts.items())
    W, H = 460, 260
    bw = (W - 60) / max(len(items), 1)
    mx = max(counts.values()) or 1
    p = ['<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H),
         '<text x="30" y="20" font-size="12">%s</text>' % esc(title)]
    for i, (k, v) in enumerate(items):
        x, y = 30 + i * bw, H - 30 - v / mx * (H - 80)
        p.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="#F58518" stroke="#000"/><text x="%.1f" y="%d" font-size="7">%s</text>' % (x, y, bw - 1, v / mx * (H - 80), x, H - 20, esc(str(k)[:12])))
    p.append('</svg>')
    return "\n".join(p)


def safe(name):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name)


def render_charts(table, col_info, num_series, out):
    charts = []
    num_cols = [c["name"] for c in col_info if c["kind"] in ("numeric", "numeric-as-text")]
    for c in num_cols[:10]:
        vals = [v for v in num_series.get(c, []) if v is not None]
        if not vals:
            continue
        f = "chart_%s_%s_hist.svg" % (safe(table), safe(c))
        Path(out, f).write_text(svg_histogram(vals, "%s.%s" % (table, c)), encoding="utf-8")
        charts.append({"file": f, "type": "histogram", "table": table, "column": c, "format": "svg"})
    cat = next((c for c in col_info if c["kind"] == "categorical"), None)
    if cat is not None:
        f = "chart_%s_%s_bar.svg" % (safe(table), safe(cat["name"]))
        Path(out, f).write_text(svg_bar(cat.get("value_counts", {}), cat["name"]), encoding="utf-8")
        charts.append({"file": f, "type": "bar", "table": table, "column": cat["name"], "format": "svg"})
    return charts


def write_query_log(out, report):
    Path(out, "query_log.json").write_text(json.dumps({"version": report.get("version", "1.0.0"), "queries": report.get("queries", [])}, ensure_ascii=False, indent=2), encoding="utf-8")


def write_report_md(out, report, meta):
    q = report.get("quality", {})
    L = ["# 科研数据库查询与分析报告", "",
         "case_id: %s | status: %s | 统计舍入 %d 位小数 | 异常判据 IQR×1.5" % (meta.get("case_id"), report.get("status"), ROUND),
         "总行数 %s | 缺失单元格 %s | 重复行 %s | 异常单元格 %s | 查询数 %s | 表: %s" % (
             q.get("total_rows"), q.get("total_missing_cells"), q.get("total_duplicate_rows"),
             q.get("total_outlier_cells"), len(report.get("queries", [])), ", ".join(q.get("tables", []))),
         "", "字段级统计、清洗明细、字段字典与跨表候选键见 result.json（datasets/analysis）。", ""]
    if report.get("degradations"):
        L += ["## 降级/异常"] + ["- %s：%s" % (d.get("file"), d.get("message")) for d in report["degradations"]]
    if report.get("gaps"):
        L += ["", "## 缺口"] + ["- %s" % (g if isinstance(g, str) else "%s：%s" % (g.get("file", ""), g.get("message", ""))) for g in report["gaps"]]
    L += ["", "## 复现", "python scripts/main.py --input /input --work /app/work --output /app/output",
          "用 query_log.json 的 SQL 在只读快照复算；对照 raw_*.csv、clean_*.csv 与 result.json。"]
    Path(out, "analysis_report.md").write_text("\n".join(L) + "\n", encoding="utf-8")

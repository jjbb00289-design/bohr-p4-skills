#!/usr/bin/env python3
import csv
import hashlib
import json
import math
import re
import sqlite3
import subprocess
from collections import Counter
from pathlib import Path

from charts import render_charts, write_report_md, write_query_log

VERSION = "1.0.0"
ROUND_DIGITS = 6
MISSING = {"", "na", "n/a", "nan", "null", "none", "nil", "?", "-", "--", "missing", "n.d.", "nd"}
NUM_TYPES = {"INTEGER", "INT", "REAL", "FLOAT", "DOUBLE", "NUMERIC", "DECIMAL", "TINYINT", "SMALLINT", "BIGINT", "BOOL", "BOOLEAN"}

def _load_field_dict():
    p = Path(__file__).resolve().parent.parent / "references" / "field-dictionary.json"
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return {}


FIELD_DICT = _load_field_dict()


def norm_col(name):
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", str(name).strip())
    s = re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")
    s = re.sub(r"_+", "_", s)
    for suf in ("_cm", "_mm", "_kg", "_mg", "_m3", "_mpa", "_days", "_day", "_vol", "_g_l"):
        if s.endswith(suf):
            s = s[:-len(suf)]
            break
    return s.strip("_")


def rnd(x):
    try:
        return round(float(x), ROUND_DIGITS)
    except (TypeError, ValueError):
        return x


def is_missing(v):
    return v is None or str(v).strip().lower() in MISSING


def to_float(v):
    if is_missing(v):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def quantile_sorted(s, p):
    n = len(s)
    if n == 0:
        return None
    if n == 1:
        return s[0]
    idx = (n - 1) * p
    lo, hi = int(math.floor(idx)), int(math.ceil(idx))
    return s[lo] if lo == hi else s[lo] + (s[hi] - s[lo]) * (idx - lo)


def read_text(path):
    data = path.read_bytes()
    for enc in ("utf-8-sig", "utf-8", "gbk", "latin-1"):
        try:
            return data.decode(enc), enc
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode("latin-1", errors="replace"), "latin-1(replace)"


def discover_files(input_path):
    if not input_path.is_dir():
        return []
    out = []
    for p in sorted(input_path.iterdir(), key=lambda x: x.name.lower()):
        if not p.is_file():
            continue
        ext = p.suffix.lower()
        kind = {"db": "sqlite", "sqlite": "sqlite", "sqlite3": "sqlite", "csv": "csv", "json": "json",
                "pdf": "pdf", "xlsx": "xlsx"}.get(ext.lstrip("."),
                "text" if ext in (".txt", ".md", ".tsv", ".dat", ".data") else "other")
        out.append({"name": p.name, "path": str(p), "rel": p.name, "ext": ext, "kind": kind, "size": p.stat().st_size})
    return out


def connect_readonly(path):
    try:
        return sqlite3.connect("file:" + path.replace("\\", "/") + "?mode=ro", uri=True)
    except Exception:
        return sqlite3.connect(str(path))


def add_source(report, file_rel, locator, quote, kind, role):
    sid = "src-%03d" % (len(report["sources"]) + 1)
    report["sources"].append({"id": sid, "file": file_rel, "locator": locator, "quote": quote, "kind": kind, "role": role})
    return sid


def make_quote(values):
    for v in values:
        if not is_missing(v):
            return str(v)
    return "[empty]"


def describe_numeric(s):
    n = len(s)
    if n == 0:
        return {"n": 0}
    mean = sum(s) / n
    var = sum((x - mean) ** 2 for x in s) / n if n >= 2 else 0.0
    q1, q3 = quantile_sorted(s, 0.25), quantile_sorted(s, 0.75)
    return {"n": n, "mean": rnd(mean), "median": rnd(quantile_sorted(s, 0.5)), "stdev": rnd(var ** 0.5),
            "min": rnd(s[0]), "max": rnd(s[-1]), "q1": rnd(q1), "q3": rnd(q3), "iqr": rnd(q3 - q1)}


def find_outliers(s):
    n = len(s)
    if n == 0:
        return {"method": "iqr_1.5", "count": 0, "values": [], "lower": None, "upper": None}
    q1, q3 = quantile_sorted(s, 0.25), quantile_sorted(s, 0.75)
    lo, hi = q1 - 1.5 * (q3 - q1), q3 + 1.5 * (q3 - q1)
    vals = [v for v in s if v < lo or v > hi]
    return {"method": "iqr_1.5", "count": len(vals), "values": [rnd(v) for v in vals[:20]], "lower": rnd(lo), "upper": rnd(hi)}


def field_explain(colname):
    e = FIELD_DICT.get(norm_col(colname))
    return e if e else {"label": None, "unit": None, "kind": None, "dataset": None, "domain": None}


def qident(name):
    return '"' + str(name).replace('"', '""') + '"'


def safe(name):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name)


def infer_kind(colname, coltype, values):
    nonmiss = [v for v in values if not is_missing(v)]
    if coltype in NUM_TYPES:
        return "numeric"
    if norm_col(colname) in ("id", "row_id", "rowid", "index", "idx", "record_id"):
        return "id"
    if not nonmiss:
        return "text"
    ok = sum(1 for v in nonmiss if to_float(v) is not None)
    if ok == len(nonmiss):
        return "numeric-as-text" if (coltype and coltype.startswith("TEXT")) else "numeric"
    if len({v for v in nonmiss}) <= max(20, len(nonmiss) * 0.3):
        return "categorical"
    return "text"


def analyze_table(table, rel, cols, coltypes, pk, raw_rows, conn, nrows, sample, out, report):
    col_info, num_series = [], {}
    for ci, c in enumerate(cols):
        values = [r[ci] for r in raw_rows]
        ct = (coltypes.get(c) or "").upper()
        ck = infer_kind(c, ct, values)
        info = {"name": c, "sql_type": ct or None, "kind": ck,
                "missing_count": sum(1 for v in values if is_missing(v)),
                "distinct_count": len({v for v in values})}
        info["source_id"] = add_source(report, rel, "table=%s;column=%s;rows=1..%d" % (table, c, nrows),
                                       make_quote(values), "sqlite_column" if conn else "csv_column", "raw values for column %s" % c)
        info["semantic"] = field_explain(c)
        if ck in ("numeric", "numeric-as-text"):
            fv = sorted(x for x in (to_float(v) for v in values) if x is not None)
            info["statistics"] = describe_numeric(fv)
            info["outliers"] = find_outliers(fv)
            num_series[c] = [to_float(v) for v in values]
            if conn is not None:
                qc = qident(c)
                sql = "SELECT COUNT(%s), MIN(%s), MAX(%s), AVG(%s) FROM %s" % (qc, qc, qc, qc, qident(table))
                agg = conn.execute(sql).fetchone()
                report["queries"].append({"sql": sql, "object": "sqlite:%s" % rel, "table": table, "column": c,
                                          "rows_returned": 1, "result": [rnd(x) if isinstance(x, (int, float)) else x for x in agg], "ok": True})
        elif ck == "categorical":
            info["value_counts"] = {str(k): v for k, v in Counter(v for v in values if not is_missing(v)).most_common(30)}
        else:
            nm = [v for v in values if not is_missing(v)]
            info["type_inconsistency"] = {"numeric_strings": sum(1 for v in nm if to_float(v) is not None), "total_nonmissing": len(nm)}
        col_info.append(info)
    dup = detect_duplicates(raw_rows)
    write_csv(out, "raw_%s.csv" % safe(table), cols, raw_rows)
    clean_rows, changes = normalize_rows(raw_rows, col_info)
    write_csv(out, "clean_%s.csv" % safe(table), cols, clean_rows)
    report["change_records"].extend(changes)
    charts = render_charts(table, col_info, num_series, out)
    return {"name": table, "source_file": rel, "row_count": nrows, "column_count": len(cols),
            "primary_key": pk or None, "sample_rows": sample, "duplicate_rows": dup, "columns": col_info,
            "charts": charts, "raw_csv": "raw_%s.csv" % safe(table), "clean_csv": "clean_%s.csv" % safe(table)}


def detect_duplicates(raw_rows):
    seen, pairs = {}, []
    for i, row in enumerate(raw_rows):
        k = tuple(repr(v) for v in row)
        if k in seen:
            pairs.append([seen[k], i])
        else:
            seen[k] = i
    return {"count": len(pairs), "row_index_pairs": pairs[:20]}


def normalize_rows(raw_rows, col_info):
    kind_map = {c["name"]: c["kind"] for c in col_info}
    changes, clean = [], []
    for row in raw_rows:
        new = []
        for ci, v in enumerate(row):
            name = col_info[ci]["name"]
            k = kind_map[name]
            if is_missing(v):
                new.append("")
            elif k == "numeric-as-text":
                f = to_float(v)
                if f is not None:
                    changes.append({"table": None, "column": name, "change": "text->numeric", "sample": str(v)})
                new.append(f if f is not None else str(v))
            elif k == "numeric":
                f = to_float(v)
                new.append(f if f is not None else str(v))
            else:
                new.append(v)
        clean.append(new)
    uniq = []
    for ch in changes:
        if ch not in uniq:
            uniq.append(ch)
    return clean, uniq[:200]


def write_csv(out, fname, cols, rows):
    with open(Path(out) / fname, "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(cols)
        for r in rows:
            w.writerow(["" if v is None else v for v in r])
    return fname


def process_sqlite(frec, out, report):
    rel, path = frec["rel"], frec["path"]
    ds = {"source_file": rel, "kind": "sqlite", "tables": [], "rows": 0, "snapshot": None, "error": None}
    conn = None
    try:
        conn = connect_readonly(path)
        conn.row_factory = sqlite3.Row
        tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        if not tables:
            ds["error"] = "no user tables"
            report["gaps"].append({"file": rel, "message": "SQLite has no user tables"})
        snap = {"file": rel, "tables": {}}
        for t in tables:
            tinfo = conn.execute("PRAGMA table_info(%s)" % qident(t)).fetchall()
            cols = [r["name"] for r in tinfo]
            coltypes = {r["name"]: (r["type"] or "") for r in tinfo}
            pk = [r["name"] for r in tinfo if r["pk"]]
            nrows = conn.execute("SELECT COUNT(*) FROM %s" % qident(t)).fetchone()[0]
            ds["rows"] += nrows
            sample = [tuple(r) for r in conn.execute("SELECT * FROM %s LIMIT 5" % qident(t))]
            report["queries"].append({"sql": "PRAGMA table_info(%s)" % qident(t),
                                      "object": "sqlite:%s" % rel, "table": t, "rows_returned": nrows, "ok": True})
            raw_rows = [list(r) for r in conn.execute("SELECT * FROM %s" % qident(t))]
            h = hashlib.sha256()
            for row in raw_rows:
                h.update(repr(tuple(row)).encode("utf-8"))
            snap["tables"][t] = {"rows": nrows, "sha256": h.hexdigest()}
            ds["tables"].append(analyze_table(t, rel, cols, coltypes, pk, raw_rows, conn, nrows, sample, out, report))
        ds["snapshot"] = snap
    except Exception as e:
        ds["error"] = "query failed: %s" % e
        report["degradations"].append({"file": rel, "stage": "sqlite", "message": ds["error"]})
    finally:
        if conn:
            conn.close()
    report["datasets"].append(ds)


def process_csv(frec, out, report):
    rel, path = frec["rel"], frec["path"]
    ds = {"source_file": rel, "kind": "csv", "rows": 0, "columns": [], "error": None}
    try:
        text, enc = read_text(Path(path))
        report["change_records"].append({"file": rel, "change": "encoding", "detected": enc})
        reader = csv.reader(text.splitlines())
        header = next(reader)
        raw_rows = [r for r in reader if any(x.strip() for x in r)]
        cols = list(header)
        tname = Path(rel).stem
        ds["rows"] = len(raw_rows)
        report["queries"].append({"sql": "READ CSV %s" % rel, "object": "csv:%s" % rel, "table": tname, "rows_returned": len(raw_rows), "ok": True})
        td = analyze_table(tname, rel, cols, {c: "" for c in cols}, [], raw_rows, None, len(raw_rows), raw_rows[:5], out, report)
        ds.update({"columns": td["columns"], "duplicate_rows": td["duplicate_rows"], "charts": td["charts"],
                   "raw_csv": td["raw_csv"], "clean_csv": td["clean_csv"], "table_name": tname})
        ds["snapshot"] = {"file": rel, "rows": len(raw_rows), "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()}
    except Exception as e:
        ds["error"] = "csv parse failed: %s" % e
        report["degradations"].append({"file": rel, "stage": "csv", "message": ds["error"]})
        report["gaps"].append({"file": rel, "message": "CSV 无法解析，未产出清洗表"})
    report["datasets"].append(ds)


def process_aux(f, report):
    rel, kind = f["rel"], f["kind"]
    if kind == "text":
        try:
            text, _ = read_text(Path(f["path"]))
        except OSError as e:
            report["degradations"].append({"file": rel, "stage": "dict", "message": str(e)})
            return
        report["sources"].append({"id": "src-%03d" % (len(report["sources"]) + 1), "file": rel,
                                  "locator": "whole file", "quote": text[:200], "kind": "dictionary_text",
                                  "role": "potential data dictionary（保留原文，未解析字段对）"})
    elif kind == "pdf":
        try:
            r = subprocess.run(["pdftotext", f["path"], "-"], capture_output=True, timeout=60)
            txt = r.stdout.decode("utf-8", errors="replace") if r.returncode == 0 else ""
        except Exception:
            txt = ""
        if txt:
            report["sources"].append({"id": "src-%03d" % (len(report["sources"]) + 1), "file": rel,
                                      "locator": "page text", "quote": txt[:200], "kind": "pdf_text", "role": "PDF 抽取文本"})
        else:
            report["gaps"].append({"file": rel, "message": "PDF 无文本层且 pdftotext 不可用"})
    elif kind in ("xlsx", "json"):
        report["gaps"].append({"file": rel, "message": "%s 材料未深度解析（仅记录文件名）" % kind.upper()})


def build_quality(report):
    tr = tm = td_ = to = 0
    tables = []
    for ds in report["datasets"]:
        ts = ds.get("tables") if ds.get("kind") == "sqlite" else [{"name": ds.get("table_name") or ds.get("source_file"), "columns": ds.get("columns", []), "row_count": ds.get("rows", 0), "duplicate_rows": ds.get("duplicate_rows", {})}]
        for t in ts:
            tr += t.get("row_count", 0)
            td_ += t.get("duplicate_rows", {}).get("count", 0)
            for c in t.get("columns", []):
                tm += c.get("missing_count", 0)
                to += c.get("outliers", {}).get("count", 0)
            tables.append(t.get("name"))
    report["quality"] = {"tables": sorted(tables), "total_rows": tr, "total_missing_cells": tm,
                         "total_duplicate_rows": td_, "total_outlier_cells": to,
                         "rounding": {"digits": ROUND_DIGITS, "note": "统计值舍入 6 位小数；清洗 CSV 保留原始精度"},
                         "missing_policy": "置空并计数，不插补", "duplicate_policy": "标识并报告，不静默删除",
                         "outlier_method": "IQR × 1.5"}
    return report


def cross_table(report):
    out = []
    for ds in report["datasets"]:
        if ds.get("kind") != "sqlite":
            continue
        tables = ds.get("tables", [])
        if len(tables) < 2:
            continue
        cols_by = {t["name"]: {c["name"] for c in t["columns"]} for t in tables}
        names = list(cols_by)
        for i in range(len(names)):
            for j in range(i + 1, len(names)):
                for k in sorted(cols_by[names[i]] & cols_by[names[j]]):
                    out.append({"table_left": names[i], "table_right": names[j], "join_key": k,
                                "note": "共享列名候选，须按数据字典确认语义后再连接", "status": "candidate"})
    if out:
        report["uncertainty"].append("跨表连接仅按共享列名推断候选键；语义与基数(1:1/1:N)须按数据字典与主键复核，未验证前不下结论")
    return out


def run(input_dir, work_dir, output_dir, meta):
    report = {"version": VERSION, "status": "complete", "errors": [], "degradations": [], "gaps": [],
              "uncertainty": [], "sources": [], "change_records": [], "queries": [], "datasets": [],
              "charts": [], "artifacts": [], "summary": {}, "quality": {}, "input_files": []}
    files = discover_files(Path(input_dir))
    report["input_files"] = [{"name": f["name"], "kind": f["kind"], "size": f["size"]} for f in files]
    data_files = [f for f in files if f["kind"] in ("sqlite", "csv")]

    if not meta.get("input_exists") or any(e.get("stage") == "read_case" for e in meta.get("errors", [])):
        report["status"] = "input_error"
        report["gaps"].append("输入不可用：case.json 无法解析或输入目录缺失")
        return report

    if not data_files:
        report["status"] = "insufficient_evidence"
        report["gaps"].append("未发现 SQLite/CSV 数据材料，无法执行查询与统计")
        for f in files:
            if f["name"] == "case.json":
                continue
            if f["kind"] in ("text", "pdf", "xlsx", "json"):
                process_aux(f, report)
        build_quality(report)
        report["analysis"] = {"cross_table": [], "field_dictionary": [], "datasets": report["datasets"]}
        return report

    for f in files:
        if f["name"] == "case.json":
            continue
        try:
            if f["kind"] == "sqlite":
                process_sqlite(f, output_dir, report)
            elif f["kind"] == "csv":
                process_csv(f, output_dir, report)
            elif f["kind"] in ("text", "pdf", "xlsx", "json"):
                process_aux(f, report)
        except Exception as e:
            report["degradations"].append({"file": f["name"], "stage": "file", "message": "%s: %s" % (type(e).__name__, e)})

    build_quality(report)
    cross = cross_table(report)
    fd = []
    for ds in report["datasets"]:
        ts = ds.get("tables") if ds.get("kind") == "sqlite" else [{"name": ds.get("table_name") or ds.get("source_file"), "columns": ds.get("columns", [])}]
        for t in ts:
            for c in t.get("columns", []):
                sem = c.get("semantic") or {}
                fd.append({"table": t.get("name"), "column": c["name"], "kind": c["kind"], "sql_type": c.get("sql_type"),
                           "label": sem.get("label"), "unit": sem.get("unit"), "dataset": sem.get("dataset"),
                           "source": "builtin-field-dictionary" if sem.get("label") else "column-name-inference"})
    report["analysis"] = {"datasets": report["datasets"], "queries": report["queries"],
                          "quality": report["quality"], "field_dictionary": fd, "cross_table": cross}
    if report["degradations"] or report["errors"]:
        report["status"] = "partial"
    if not any(ds.get("kind") in ("sqlite", "csv") and not ds.get("error") for ds in report["datasets"]):
        report["status"] = "partial"
    ncharts = sum(len(t.get("charts", [])) for ds in report["datasets"] for t in (ds.get("tables") if ds.get("kind") == "sqlite" else [ds]))
    q = report["quality"]
    report["summary"] = {"files_scanned": len(files), "data_files": len(data_files), "datasets": len(report["datasets"]),
                         "tables": q.get("tables", []), "total_rows": q.get("total_rows", 0),
                         "missing_cells": q.get("total_missing_cells", 0), "duplicate_rows": q.get("total_duplicate_rows", 0),
                         "outlier_cells": q.get("total_outlier_cells", 0), "queries_executed": len(report["queries"]), "charts": ncharts}
    write_report_md(output_dir, report, meta)
    write_query_log(output_dir, report)
    report["artifacts"] = sorted(f.name for f in Path(output_dir).iterdir() if f.is_file())
    return report

---
name: research-db-analysis
description: 科研数据库查询与分析。对 SQLite/CSV 科研数据快照自动发现 schema、连接数据库、执行可复核查询、完成数据清洗（缺失值/异常值/重复记录/格式单位编码/质量报告）、统计、可视化与字段字典解释，产出 result.json 及可回查的清洗数据、图表与查询日志。适用于数据库连接、查询语句、结果抽取、字段解释、跨表分析场景。
version: 1.0.0
---

# 科研数据库查询与分析 Skill

## 用途
把一个真实、可检查的科研数据查询与分析任务做成可复跑流程：连接授权数据快照（SQLite/CSV），按数据字典解释字段，执行并记录查询，抽取结果集，完成五类数据清洗与统计，输出可复核的清洗表、图表、查询日志与质量报告。重点是"查询跑得通、结果可复算、字段说得清、路径可回查"，不写不可执行的伪 SQL，不填造数字。

## 触发条件
- 任务要求"科研数据库查询与分析 / 数据清洗 / 统计 / 可视化 / 代码执行 / 数据库字段"时触发。
- 输入目录出现 `case.json`（含 `output_contract` 与 `case_id`）及 SQLite/CSV 材料时触发。
- 需要把查询、字段解释、跨表结论沉淀为可复核结构化结果时触发。

## 调用方式
```
python scripts/main.py                 # 默认完整流程（读输入→分析→写 result.json+产物）
python scripts/main.py --help          # 帮助
python scripts/main.py init|show|check|build
python scripts/main.py --input <dir> --work <dir> --output <dir>
```
- 路径优先级：`--input/--work/--output` 参数 > 环境变量 `INPUT_DIR/WORK_DIR/OUTPUT_DIR` > 平台默认 `/input`、`/app/work`、`/app/output`。
- 脚本不依赖 CWD（`Path(__file__).resolve().parent` 定位第二脚本与 references），纯标准库，不联网。
- 退出码恒为 0；任何异常写入 `result.json` 的 `errors`/`degradations`，绝不崩、绝不 0 字节。

## 输入
- `case.json`（必需）：`case_id`、`output_contract`（结果契约，逐字段回填）、`task_instruction`。
- `task.md`（可选）：任务说明，原文保留为证据。
- 材料（任选）：`*.db/*.sqlite/*.sqlite3`（SQLite 快照，只读打开）、`*.csv`、`*.json`、`*.txt/*.md`（可能的数据字典）、`*.pdf`（pdftotext 抽取文本，失败则记录降级）、`*.xlsx`（zipfile+xml 读取）。

## 输出（/app/output，全部可复核、可编辑）
- `result.json`：`case_id` + 回填全部 `output_contract` 字段 + `status` + `sources` + `uncertainty` + `change_records` + `errors`/`degradations`/`gaps` + 分析结果（datasets/statistics/cleaning/field_dictionary/queries/quality）。
- `raw_<table>.csv`：SQLite/CSV 原样导出（逐字可回查）。
- `clean_<table>.csv`：清洗后真实数据（类型规范化、缺失值置空、保留全部行与重复记录标识）。
- `chart_*.svg`：统计图（直方图/柱状图，可编辑矢量源；异常值在 result.json 中以 IQR×1.5 数值报告）。
- `query_log.json`：每条实际执行的 SQL、连接对象、行数、结果摘要。
- `analysis_report.md`：Markdown 汇总（清洗规则、统计口径、异常说明、复现步骤）。

## 工作稿 schema（/app/work）
- `partial_result.json`：先落盘的 partial，后续增量 finalize。
- `run_state.json`：运行状态（input/work/output 路径、发现的文件清单、版本、无时间戳，确定性）。
- 中间加载行缓存在内存，不落盘；最终清洗 CSV 落 /app/output。

## 证据规范（sources/uncertainty）
每个结论/条目须带 `source_id` 指向 `sources[]`，source 至少含 `file`（相对输入路径）、`locator`（table=…;column=…;rows=… 或行号）、`quote`（材料原文逐字片段，能在 raw CSV/材料中命中）、`kind`、`role`。
- 统计数值是计算值，用 `locator` + 原始值 `quote` 定位，另附所用 SQL 与复算方法。
- 字段语义若命中内置 UCI 字典（Iris/Wine/Concrete），记 `source="builtin-field-dictionary"` 并在 `uncertainty` 标注"语义映射，非案例字典原文，须与案例数据字典核对"；未命中则记 `semantic=unknown`，不臆造含义。
- 统计口径：连续列统计基于该列全部非缺失值；重复行单独报告（不静默删除）；异常判据为 IQR×1.5（分布型，非硬编码阈值）。数值保留 6 位小数并在报告中声明舍入口径。

## 降级表
| 情形 | status | 动作 |
|---|---|---|
| 输入目录不存在 / 空 | input_error | result.json 契约键=null，gaps+errors，exit 0 |
| case.json 不存在 | input_error | 同上 |
| case.json 坏 JSON / 编码不可读 | input_error | 同上 |
| case.json 合法但无 SQLite/CSV 材料 | insufficient_evidence | 契约键=null，gaps 说明缺材料 |
| 部分文件不可读 / 权限不足 / 坏 CSV / 空表 | partial | errors+degradations+gaps，其余表继续 |
| 全部成功、无阻断错误 | complete | 全量交付 |

## 自检（运行后核对）
1. `result.json` 是合法 JSON，含 `case_id` 且 `output_contract` 的每个键都在顶层（或 `output_contract_echo`）出现。
2. `status` 与降级表一致；`errors/degradations/gaps` 非空时 status 必不为 complete。
3. 每个统计条目有 `source_id`，`quote` 能在 raw CSV/材料中命中。
4. raw/clean CSV 行数与报告一致；质量报告计数=各列缺失/异常/重复之和。
5. SVG 可被浏览器打开（XML 合法）；PNG（如有）以 `\x89PNG` 开头。

## 限制
- 只读查询，不写原始数据库；仅支持 SQLite/CSV（xlsx/PDF 尽力抽取）。
- 不推断未在数据字典/材料中出现的字段语义；跨表连接仅在有共享列名且可验证时执行，未验证的关系记入 uncertainty。
- 不联网、不使用预制答案；白板与正式测评结果由平台生成，本 Skill 不声明基准分。

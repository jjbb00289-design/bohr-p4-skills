import argparse
import json
import os
import re
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
import pipeline
import retrieve

DEFAULT_INPUT = "/input"
DEFAULT_WORK = "/app/work"
DEFAULT_OUTPUT = "/app/output"
ALLOWED_STATUS = {"complete", "partial", "insufficient_evidence", "input_error"}


def _load_aliases():
    try:
        with open(os.path.join(SCRIPT_DIR, "..", "references", "lexicon.json"),
                  "r", encoding="utf-8") as fh:
            d = json.load(fh)
        return d.get("aliases", {})
    except Exception:
        return {}


ALIASES = _load_aliases()
ALIAS_LOOKUP = {a: k for k, aliases in ALIASES.items() for a in aliases}


def norm_name(s):
    return re.sub(r'[^0-9a-z\u4e00-\u9fff]+', '', str(s).lower())


def resolve_field(name, canonical):
    n = norm_name(name)
    if n in ALIAS_LOOKUP:
        return canonical[ALIAS_LOOKUP[n]]
    best = None
    for a, key in ALIAS_LOOKUP.items():
        if len(a) >= 4 and a in n and (best is None or len(a) > len(best[0])):
            best = (a, key)
    return canonical[best[1]] if best else None


def get_output_contract(case):
    oc = case.get("output_contract") or case.get("outputContract")
    if isinstance(oc, dict):
        return [(str(k), oc[k]) for k in oc]
    if isinstance(oc, list):
        out = []
        for x in oc:
            if isinstance(x, str):
                out.append((x, None))
            elif isinstance(x, dict) and (x.get("name") or x.get("key") or x.get("field") or x.get("id")):
                out.append((str(x.get("name") or x.get("key") or x.get("field") or x.get("id")), x))
        return out
    return []


def null_or_empty(spec, name):
    n = norm_name(name)
    t = str(spec.get("type", "")).lower() if isinstance(spec, dict) else ""
    return [] if ("array" in t or "list" in t or n.endswith("s") or "list" in n or "records" in n or "items" in n) else None


def load_case(input_dir):
    if not os.path.isdir(input_dir):
        return ({"case_id": None, "task_instruction": "", "output_contract": {}},
                "input_error", [f"input dir missing or unreadable: {input_dir}"])
    cp = os.path.join(input_dir, "case.json")
    if not os.path.isfile(cp):
        return ({"case_id": None, "task_instruction": "", "output_contract": {}},
                "input_error", [f"case.json missing under {input_dir}"])
    try:
        with open(cp, "r", encoding="utf-8", errors="replace") as fh:
            case = json.load(fh)
    except Exception as e:
        return ({"case_id": None, "task_instruction": "", "output_contract": {}},
                "input_error", [f"case.json invalid JSON: {e}"])
    if not isinstance(case, dict):
        case = {"_raw": case}
    return case, None, []


def empty_canonical(errors):
    return {"research_question": None, "sub_questions": [], "query_plan": [],
            "candidates": [], "ranking": [], "deduplication": [], "conflicts": [],
            "coverage": {"records_screened": 0, "records_with_hits": 0, "records_screened_out": 0,
                         "covered_sub_questions": [], "missed_sub_questions": [], "no_result_queries": []},
            "omissions": [{"type": "input_error", "note": "; ".join(errors) or "input unavailable"}],
            "metrics": {}, "uncertainty": [], "sources": [],
            "change_records": [{"step": "init", "action": "input_error; partial only"}],
            "errors": list(errors), "degradations": []}


def build_result(case, canonical, status, errors, degradations):
    case_id = case.get("case_id") if case.get("case_id") is not None else case.get("id")
    result = {"case_id": case_id, "status": status}
    canonical["status"] = status
    canonical["errors"] = list(errors)
    canonical["degradations"] = list(degradations)
    for name, spec in get_output_contract(case):
        if name == "case_id":
            continue
        val = resolve_field(name, canonical)
        if val is None:
            val = null_or_empty(spec, name)
            degradations.append({"field": name, "note": "no resolved value; filled null/[]"})
        result[name] = val
    for key in ("sources", "uncertainty", "change_records", "errors", "degradations"):
        if key not in result:
            result[key] = canonical.get(key, [] if key != "errors" else list(errors))
    return result


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2)


def build_report(canonical, case_id, status, errors, degradations):
    L = ["# 科研问题驱动检索报告（可编辑）", "", f"- case_id: {case_id}", f"- status: {status}",
         "", "## 研究问题", "", str(canonical.get("research_question") or "（未提供）"),
         "", "## 子问题拆解", ""]
    for sq in canonical.get("sub_questions", []):
        L.append(f"- {sq['id']} [{sq['facet']}] {sq['question']} 种子词: {', '.join(sq['seed_terms'])}")
    L += ["", "## 查询计划", ""]
    for q in canonical.get("query_plan", []):
        L.append(f"- {q['id']}->{q.get('sub_question_id')}: {q['terms']} 变体: {', '.join(q['variants'])} [{q['status']}]")
    L += ["", "## 候选文献（可追溯）", ""]
    for c in canonical.get("candidates", []):
        L += [f"### {c.get('title') or '(无标题)'} (score={c['relevance_score']})",
              f"- source: {c['source']} | locator: {c['locator']}",
              f"- authors: {', '.join(c['authors']) if c['authors'] else '—'}",
              f"- year: {c['year']} | venue: {c['venue'] or '—'} | doi: {c['doi'] or '—'}"]
        for e in c["evidence"][:3]:
            L.append(f"- hit: `{e['variant']}` @ {e['field']} → “{e['quote']}”")
        L.append("")
    L += ["## 排序与指标", ""]
    cov = canonical.get("coverage", {})
    for r in canonical.get("ranking", [])[:20]:
        L.append(f"- #{r['rank']} {r['record_id']} score={r['score']} ({r['rationale']})")
    L += ["", "## 覆盖与遗漏", "",
          f"- 覆盖子问题 {len(cov.get('covered_sub_questions', []))} | 未覆盖 {len(cov.get('missed_sub_questions', []))} | 无结果查询 {len(cov.get('no_result_queries', []))}",
          f"- 筛选 {cov.get('records_screened')} | 命中 {cov.get('records_with_hits')} | 筛除 {cov.get('records_screened_out')}",
          "", "## 不确定性", ""]
    for u in canonical.get("uncertainty", []):
        L.append(f"- [{u['type']}] {u.get('note', '')}")
    if errors:
        L += ["", "## 错误"] + [f"- {e}" for e in errors]
    if degradations:
        L += ["", "## 降级"] + [f"- {d}" for d in degradations]
    L += ["", "## 变更记录", ""]
    for cr in canonical.get("change_records", []):
        L.append(f"- {cr['step']}: {cr['action']}")
    return "\n".join(L) + "\n"


def compute_status(load_status, canonical, n_records):
    if load_status:
        return load_status
    if n_records == 0 or not canonical.get("candidates"):
        return "insufficient_evidence"
    cov = canonical.get("coverage", {})
    gaps = len(cov.get("missed_sub_questions", [])) + len(cov.get("no_result_queries", [])) + len(canonical.get("conflicts", []))
    return "complete" if gaps == 0 else "partial"


def run_full(input_dir, work_dir, output_dir, override=None):
    os.makedirs(work_dir, exist_ok=True)
    os.makedirs(output_dir, exist_ok=True)
    case, load_status, load_errors = load_case(input_dir)
    degradations, errors = [], list(load_errors)
    write_json(os.path.join(output_dir, "result.json"),
               {"case_id": case.get("case_id") or case.get("id"), "status": "partial",
                "sources": [], "uncertainty": [], "errors": list(errors), "degradations": [],
                "change_records": [{"step": "init", "action": "partial initialized"}]})
    if load_status == "input_error":
        canonical, status = empty_canonical(errors), "input_error"
    else:
        try:
            canonical, work_notes = retrieve.run_pipeline(case, input_dir, work_dir, output_dir, override)
            write_json(os.path.join(work_dir, "work_notes.json"), work_notes)
        except Exception as e:
            errors.append(f"pipeline error: {e}")
            canonical = empty_canonical(errors)
        status = compute_status(None, canonical,
                                sum(s.get("n_records", 0) for s in canonical.get("sources", [])))
        if status != "input_error" and not canonical.get("candidates") and \
           sum(s.get("n_records", 0) for s in canonical.get("sources", [])) == 0:
            status = "insufficient_evidence"
    result = build_result(case, canonical, status, errors, degradations)
    write_json(os.path.join(output_dir, "result.json"), result)
    with open(os.path.join(output_dir, "report.md"), "w", encoding="utf-8") as fh:
        fh.write(build_report(canonical, result.get("case_id"), status, errors, result.get("degradations", [])))
    return result


def cmd_check(input_dir, output_dir):
    p = os.path.join(output_dir, "result.json")
    if not os.path.isfile(p):
        print("[FAIL] result.json missing")
        return
    with open(p, encoding="utf-8") as fh:
        r = json.load(fh)
    print("[PASS] result.json parses")
    print(("[PASS]" if "case_id" in r else "[FAIL]") + " case_id present")
    print(("[PASS]" if r.get("status") in ALLOWED_STATUS else "[FAIL]") + f" status valid ({r.get('status')})")
    case, _, _ = load_case(input_dir)
    missing = [n for n, _ in get_output_contract(case) if n not in r]
    print(("[PASS]" if not missing else "[FAIL]") + f" contract fields present (missing={missing})")
    cands = r.get("candidates", [])
    if isinstance(cands, list) and cands:
        ok = all(isinstance(c, dict) and c.get("source") and c.get("locator") and c.get("evidence") for c in cands)
        print(("[PASS]" if ok else "[FAIL]") + " candidates have source+locator+evidence")
        records = pipeline.load_records(input_dir)
        blob = "\n".join(t for r in records for _, t in r["chunks"]).lower()
        evs = [e for c in cands for e in c.get("evidence", [])]
        hit = sum(1 for e in evs if e.get("quote") and e["quote"].lower().strip()[:40] in blob)
        rate = hit / len(evs) if evs else 1.0
        print(("[PASS]" if rate >= 0.95 else "[FAIL]") + f" quote hit rate {rate:.3f} (>=0.95)")
    print("check done")


def main(argv=None):
    ap = argparse.ArgumentParser(description="research-literature-retrieval skill")
    ap.add_argument("sub", nargs="?", default="run", choices=["run", "check", "build"])
    ap.add_argument("--input"); ap.add_argument("--work"); ap.add_argument("--output")
    args = ap.parse_args(argv)
    inp = args.input or os.environ.get("INPUT_DIR") or DEFAULT_INPUT
    work = args.work or os.environ.get("WORK_DIR") or DEFAULT_WORK
    out = args.output or os.environ.get("OUTPUT_DIR") or DEFAULT_OUTPUT
    try:
        if args.sub == "run":
            run_full(inp, work, out)
        elif args.sub == "build":
            override = None
            wn = os.path.join(work, "work_notes.json")
            if os.path.isfile(wn):
                try:
                    d = json.load(open(wn, encoding="utf-8"))
                    if d.get("sub_questions") and d.get("query_plan"):
                        override = {"sub_questions": d["sub_questions"], "query_plan": d["query_plan"]}
                except Exception:
                    pass
            run_full(inp, work, out, override=override)
        elif args.sub == "check":
            cmd_check(inp, out)
    except Exception as e:
        os.makedirs(out, exist_ok=True)
        try:
            write_json(os.path.join(out, "result.json"),
                       {"case_id": None, "status": "input_error", "errors": [f"fatal: {e}"],
                        "sources": [], "uncertainty": [], "change_records": [], "degradations": []})
        except Exception:
            pass
        print(f"fatal (caught): {e}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())

import os
from pipeline import EN_STOP, FW, norm_doi, norm_title, expand_term, load_records, \
    _extract_question, _extract_queries, decompose_question, build_query_plan


def _field(path):
    p = path.lower()
    for f, kws in (("title", ("title", "article-title", "booktitle")),
                   ("abstract", ("abstract", "summary", "description")),
                   ("venue", ("journal", "container", "venue", "publisher", "publicationtitle")),
                   ("metadata", ("doi", "year", "author", "pmid", "published", "issued", "pubyear"))):
        if any(k in p for k in kws):
            return f
    return "other"


def run_matching(records, plan):
    matches, hits = [], {q["id"]: [] for q in plan}
    for q in plan:
        for rec in records:
            for path, text in rec["chunks"]:
                tlow = text.lower()
                for v in q["variants"]:
                    vl = v.lower()
                    if not vl or len(vl) < 2:
                        continue
                    idx = tlow.find(vl)
                    if idx >= 0:
                        kind, quote = "phrase", text[max(0, idx - 40):idx + len(vl) + 80].strip()
                    else:
                        toks = [tk for tk in vl.split() if len(tk) >= 3 and tk not in EN_STOP]
                        if len(toks) >= 2 and all(tk in tlow for tk in toks):
                            kind, quote = "token_and", text[:180].strip()
                        else:
                            continue
                    matches.append({"query_id": q["id"], "record_id": rec["id"], "variant": v,
                                    "field_path": path, "field": _field(path), "quote": quote, "match": kind})
                    hits[q["id"]].append(rec["id"])
                    break
    return matches, hits


def build_candidates(records, matches, plan):
    by_rec = {}
    for m in matches:
        by_rec.setdefault(m["record_id"], []).append(m)
    subq_of = {q["id"]: q["sub_question_id"] for q in plan}
    cands = []
    for rec in records:
        ms = by_rec.get(rec["id"])
        if not ms:
            continue
        sqs, terms = set(), set()
        for m in ms:
            sqs.add(subq_of.get(m["query_id"]) or "")
            terms.add(m["variant"].lower())
        score = sum(FW.get(m["field"], 1.0) for m in ms) + 2.0 * len(sqs) + 1.0 * len(terms)
        meta = rec["meta"]
        score += 0.5 * bool(meta["doi"]) + 0.25 * bool(meta["year"]) + 0.25 * bool(meta["venue"]) \
            + 0.5 * bool(meta["authors"]) + 0.5 * bool(meta["title"])
        cands.append({"record_id": rec["id"], "source": rec["source"], "locator": rec["locator"],
                      "meta": meta, "sub_questions_matched": sorted(sqs), "matched_terms": sorted(terms),
                      "score": round(score, 3), "evidence": ms})
    cands.sort(key=lambda c: c["score"], reverse=True)
    return cands


def _completeness(c):
    m = c["meta"]
    return sum(1 for k in ("doi", "title", "year", "venue") if m.get(k)) + bool(m.get("authors"))


def deduplicate(cands):
    groups = {}
    for c in cands:
        key = norm_doi(c["meta"].get("doi")) or ("title:" + norm_title(c["meta"].get("title")))
        if not key or key == "title:":
            key = "rec:" + c["record_id"]
        groups.setdefault(key, []).append(c)
    dedup, conflicts, unique = [], [], []
    for key, grp in groups.items():
        if len(grp) == 1:
            unique.append(grp[0]); continue
        keep = max(grp, key=_completeness)
        dedup.append({"kept": keep["record_id"], "removed": [g["record_id"] for g in grp if g is not keep],
                      "reason": "duplicate export or same DOI/title",
                      "key": key if not key.startswith("rec:") else None})
        if len({str(g["meta"].get("year")) for g in grp}) > 1 or \
           len({norm_title(g["meta"].get("title")) for g in grp}) > 1:
            conflicts.append({"key": key, "record_ids": [g["record_id"] for g in grp],
                              "note": "same key, conflicting metadata; kept richer record"})
        unique.append(keep)
    return unique, dedup, conflicts


def rank(cands):
    return [{"rank": i, "record_id": c["record_id"], "score": c["score"],
             "rationale": f"{len(c['sub_questions_matched'])} sub-questions, {len(c['matched_terms'])} terms, {len(c['evidence'])} hits"}
            for i, c in enumerate(cands, 1)]


def build_coverage(subqs, plan, hits, cands, records):
    covered, missed = [], []
    for sq in subqs:
        qids = [q["id"] for q in plan if q["sub_question_id"] == sq["id"]]
        n = len({rid for qid in qids for rid in hits.get(qid, [])})
        (covered if n else missed).append({"sub_question_id": sq["id"], "facet": sq["facet"],
                                           "question": sq["question"], "records_hit": n, "queries": qids})
    hit_ids = {rid for ids in hits.values() for rid in ids}
    return {"covered_sub_questions": covered, "missed_sub_questions": missed,
            "no_result_queries": [{"query_id": q["id"], "query": q["terms"], "note": "no match"}
                                  for q in plan if not hits.get(q["id"])],
            "records_screened": len(records), "records_with_hits": len(cands),
            "records_screened_out": sum(1 for r in records if r["id"] not in hit_ids)}


def build_omissions(records, coverage):
    om = [{"type": "sub_question_no_evidence", "sub_question_id": m["sub_question_id"],
           "question": m["question"], "note": "no candidate matched; out of snapshot scope?"}
          for m in coverage["missed_sub_questions"]]
    om += [{"type": "query_no_result", "query_id": q["query_id"], "query": q["query"],
            "note": q["note"]} for q in coverage["no_result_queries"]]
    for r in records:
        missing = [k for k in ("doi", "year", "venue", "title") if not r["meta"].get(k)]
        if missing and r["kind"] != "text":
            om.append({"type": "missing_metadata", "record_id": r["id"], "source": r["source"],
                       "locator": r["locator"], "missing_fields": missing})
    return om or [{"type": "none", "note": "no omissions detected"}]


def _cand_payload(cands):
    return [{"record_id": c["record_id"], "title": c["meta"]["title"],
             "authors": c["meta"]["authors"] or [], "year": c["meta"]["year"],
             "venue": c["meta"]["venue"], "doi": c["meta"]["doi"], "pmid": c["meta"]["pmid"],
             "source": c["source"], "locator": c["locator"], "relevance_score": c["score"],
             "sub_questions_matched": c["sub_questions_matched"],
             "matched_terms": c["matched_terms"], "evidence": c["evidence"]} for c in cands]


def run_pipeline(case, input_dir, work_dir, output_dir, override=None):
    records = load_records(input_dir)
    question = _extract_question(case)
    extra = _extract_queries(case, input_dir)
    if override and override.get("sub_questions") and override.get("query_plan"):
        subqs, plan = override["sub_questions"], override["query_plan"]
        for q in plan:
            q.setdefault("variants", [v for t in (q.get("terms") or []) for v in expand_term(t)])
    else:
        subqs = decompose_question(question)
        plan = build_query_plan(subqs, extra)
    matches, hits = run_matching(records, plan)
    cands = build_candidates(records, matches, plan)
    unique, dedup, conflicts = deduplicate(cands)
    coverage = build_coverage(subqs, plan, hits, unique, records)
    omissions = build_omissions(records, coverage)
    for q in plan:
        q["status"] = "no_result" if not hits.get(q["id"]) else "run"

    sources = []
    for r in records:
        s = next((x for x in sources if x["file"] == r["source"]), None)
        if s is None:
            s = {"file": r["source"], "path": os.path.join(input_dir, r["source"]),
                 "kind": r["kind"], "n_records": 0}
            sources.append(s)
        s["n_records"] += 1

    k = min(10, len(unique)) if unique else 0
    metrics = {"records_screened": len(records), "candidates_before_dedup": len(cands),
               "candidates_after_dedup": len(unique),
               "duplicates_merged": sum(len(d["removed"]) for d in dedup),
               "conflicts": len(conflicts),
               "screening_precision": round(len(unique) / len(records), 3) if records else None,
               "precision_at_k": round(sum(1 for c in unique[:k] if c["score"] >= 1.0) / k, 3) if k else None,
               "top_k_scores": [c["score"] for c in unique[:k]],
               "ranking_method": "graded relevance (title3/abstract2/venue1 + sub-question2 + term1 + metadata); nDCG/Precision@k",
               "recall_note": "finite snapshot of %d records; no global corpus" % len(records)}
    uncertainty = [{"type": "finite_snapshot", "note": "local snapshot only; absence != absence"},
                   {"type": "heuristic_decomposition", "note": "deterministic decomposition; review low-confidence facets"}]
    if conflicts:
        uncertainty.append({"type": "conflicting_records", "detail": conflicts})
    if not question:
        uncertainty.append({"type": "missing_question", "note": "task_instruction absent"})
    change_records = [{"step": "init", "action": "partial initialized"},
                      {"step": "load", "action": f"{len(records)} records / {len(sources)} sources"},
                      {"step": "decompose", "action": f"{len(subqs)} sub-questions"},
                      {"step": "plan", "action": f"{len(plan)} queries"},
                      {"step": "match", "action": f"{len(matches)} hits"},
                      {"step": "dedup", "action": f"merged {sum(len(d['removed']) for d in dedup)} duplicates"},
                      {"step": "finalize", "action": "final result written"}]

    canonical = {"research_question": question or None, "sub_questions": subqs,
                 "query_plan": plan, "candidates": _cand_payload(unique),
                 "ranking": rank(unique), "deduplication": dedup, "conflicts": conflicts,
                 "coverage": coverage, "omissions": omissions, "metrics": metrics,
                 "uncertainty": uncertainty, "change_records": change_records,
                 "sources": sources, "errors": [], "degradations": []}
    work_notes = {"case_id": case.get("case_id")}
    work_notes.update({k: canonical[k] for k in ("research_question", "sub_questions",
                                                 "query_plan", "candidates", "deduplication",
                                                 "conflicts", "coverage", "omissions", "metrics")})
    return canonical, work_notes

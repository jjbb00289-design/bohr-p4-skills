import json, re, os, csv, io, hashlib
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
DOI_RE = re.compile(r'\b10\.\d{4,9}/[^\s"\'<>]+', re.I)
YEAR_RE = re.compile(r'(19|20)\d{2}')
AK = ("author", "authors", "creator", "creators", "contributor")
TK = ("title", "article-title", "booktitle", "articleTitle", "publicationTitle")
YK = ("year", "pubYear", "publicationYear", "printYear", "date", "issued",
      "published", "published-print", "published-online", "created")
VK = ("container-title", "journalTitle", "journal", "journalName", "source",
      "publisher", "publicationTitle", "container", "book", "publisherName")
SKIP = {"case.json", "task.md", "task.txt", "result.json", "report.md"}
EN_STOP = {"the", "and", "for", "with", "are", "not", "that", "this", "was", "were",
           "has", "have", "from", "into", "than", "versus", "vs", "non", "small",
           "cell", "controlled", "randomised", "randomized"}


def load_lexicon():
    d = {"synonyms": {}, "zh_en": {}, "abbrev": {}, "facet_keywords": {},
         "cjk_boundary": [], "field_weight": {}}
    try:
        with open(os.path.join(SCRIPT_DIR, "..", "references", "lexicon.json"),
                  "r", encoding="utf-8") as fh:
            d.update(json.load(fh))
    except Exception:
        pass
    return d


LEX = load_lexicon()
FW = LEX.get("field_weight") or {"title": 3.0, "abstract": 2.0,
                                 "venue": 1.0, "metadata": 0.5, "other": 1.0}


def get_text(v):
    if v is None:
        return ""
    if isinstance(v, str):
        return v
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, list):
        return " ".join(get_text(x) for x in v)
    if isinstance(v, dict):
        return " ".join(get_text(x) for x in v.values())
    return str(v)


def flatten(obj, prefix=""):
    if isinstance(obj, dict):
        for k, v in obj.items():
            p = f"{prefix}.{k}" if prefix else str(k)
            yield from flatten(v, p)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            p = f"{prefix}[{i}]" if prefix else f"[{i}]"
            yield from flatten(v, p)
    else:
        yield (prefix or "value", get_text(obj))


def first(obj, *keys):
    if isinstance(obj, dict):
        for k in keys:
            if obj.get(k) not in (None, "", [], {}):
                return obj[k]
    return None


def norm_doi(s):
    if not s:
        return None
    m = DOI_RE.search(str(s))
    return m.group(0).lower().rstrip('.,;') if m else str(s).strip().lower()


def norm_title(s):
    return re.sub(r'[^0-9a-z\u4e00-\u9fff]+', '', (s or "").lower())


def parse_text_as_json(text):
    try:
        return json.loads(text)
    except Exception:
        return None


def _find_list(obj, path):
    if isinstance(obj, list):
        return (obj, path) if (obj and all(isinstance(x, dict) for x in obj)) else (None, None)
    if isinstance(obj, dict):
        for k, v in obj.items():
            cp = f"{path}.{k}" if path else str(k)
            lst, lp = _find_list(v, cp)
            if lst is not None:
                return lst, lp
    return None, None


def iter_records(data, path):
    if isinstance(data, (list, dict)):
        lst, lp = _find_list(data, path)
        if lst is not None:
            for i, item in enumerate(lst):
                yield f"{lp}[{i}]", item
        elif isinstance(data, list):
            for i, item in enumerate(data):
                yield f"{path}[{i}]", item
        else:
            yield path, data


def _rid(fname, loc):
    return "r_" + hashlib.md5((fname + "|" + loc).encode("utf-8")).hexdigest()[:12]


def _text_record(fname, text, loc=None, err=None):
    m = DOI_RE.search(text or "")
    return {"source": fname, "locator": loc or fname, "id": _rid(fname, loc or fname),
            "meta": {"doi": m.group(0).rstrip('.,;') if m else None, "title": None,
                     "authors": [], "year": None, "venue": None, "abstract": None, "pmid": None},
            "chunks": [(fname, text or "")], "kind": "text", "errors": [err] if err else []}


def _dict_record(fname, loc, item):
    if not isinstance(item, dict):
        return _text_record(fname, get_text(item), loc=loc)
    return {"source": fname, "locator": loc, "id": _rid(fname, loc),
            "meta": extract_meta(item), "chunks": list(flatten(item, loc)),
            "kind": "json", "errors": []}


def load_records(input_dir):
    recs, paths = [], []
    for root, _d, files in os.walk(input_dir):
        for fn in sorted(files):
            if fn not in SKIP:
                paths.append(os.path.join(root, fn))
    for fpath in sorted(paths):
        fname = os.path.relpath(fpath, input_dir).replace("\\", "/")
        try:
            raw = open(fpath, "r", encoding="utf-8", errors="replace").read()
        except Exception:
            recs.append(_text_record(fname, err="unreadable")); continue
        ext = fname.lower().rsplit(".", 1)[-1] if "." in fname else ""
        if ext in ("jsonl", "ndjson"):
            for ln, line in enumerate(raw.splitlines(), 1):
                if not line.strip():
                    continue
                p = parse_text_as_json(line.strip())
                if p is None:
                    recs.append(_text_record(fname, line.strip(), f"line {ln}", "bad_json_line"))
                elif isinstance(p, (dict, list)):
                    recs.extend(_dict_record(fname, loc, it) for loc, it in iter_records(p, fname))
                else:
                    recs.append(_text_record(fname, str(p), f"line {ln}"))
        elif ext in ("csv", "tsv"):
            try:
                recs.extend(_dict_record(fname, f"row {i}", dict(r)) for i, r in
                            enumerate(csv.DictReader(io.StringIO(raw), delimiter="\t" if ext == "tsv" else ","), 1))
            except Exception:
                recs.append(_text_record(fname, raw, err="bad_csv"))
        else:
            p = parse_text_as_json(raw)
            if isinstance(p, (dict, list)):
                recs.extend(_dict_record(fname, loc, it) for loc, it in iter_records(p, fname))
            else:
                recs.append(_text_record(fname, raw, err=("bad_json" if ext == "json" else None)))
    return recs


def extract_meta(d):
    m = {"doi": None, "title": None, "authors": [], "year": None,
         "venue": None, "abstract": None, "pmid": None}
    doi = first(d, "DOI", "doi", "id", "prism:doi")
    if doi and "10." in str(doi):
        m["doi"] = norm_doi(doi)
    pmid = first(d, "pmid", "PMID", "pubmedId")
    if pmid:
        m["pmid"] = str(pmid)
    t = first(d, *TK)
    if isinstance(t, list):
        t = t[0] if t else None
    m["title"] = t if isinstance(t, str) and t.strip() else (str(t) if t else None)
    av = next((d.get(k) for k in AK if d.get(k) is not None), None)
    au = []
    if isinstance(av, list):
        for a in av:
            if isinstance(a, dict):
                nm = a.get("name") or " ".join(str(a.get(k, "")) for k in ("given", "family") if a.get(k))
                if nm.strip():
                    au.append(nm.strip())
            elif isinstance(a, str) and a.strip():
                au.append(a.strip())
    elif isinstance(av, str) and av.strip():
        au = [x.strip() for x in av.split(",") if x.strip()] if "," in av else [av.strip()]
    if not au:
        as_ = first(d, "authorString", "author_str", "authorsString")
        if as_:
            au = [x.strip() for x in str(as_).split(",") if x.strip()]
    m["authors"] = au[:50]
    m["year"] = extract_year(first(d, *YK))
    v = first(d, *VK)
    if isinstance(v, list):
        v = v[0] if v else None
    if v and str(v).strip():
        m["venue"] = str(v).strip()[:300]
    ab = first(d, "abstract", "abstractText", "description", "summary")
    if isinstance(ab, str):
        m["abstract"] = ab[:5000]
    return m


def extract_year(v):
    if v is None:
        return None
    if isinstance(v, dict):
        dp = v.get("date-parts") or v.get("dateTime") or v.get("date")
        if isinstance(dp, list) and dp and isinstance(dp[0], list) and dp[0]:
            for part in dp[0]:
                if isinstance(part, int) and 1800 <= part <= 2100:
                    return part
        return extract_year(dp)
    m = YEAR_RE.search(str(v))
    return int(m.group(0)) if m and 1800 <= int(m.group(0)) <= 2100 else None


def extract_seed_terms(text):
    terms, seen = [], set()

    def add(t):
        t = t.strip()
        if t and t.lower() not in seen:
            terms.append(t); seen.add(t.lower())

    for m in re.finditer(r'["“”]([^"“”]{1,60})["“”]', text):
        add(m.group(1))
    for m in re.finditer(r'\b[A-Za-z][A-Za-z0-9\-]{2,}\b', text):
        if m.group(0).lower() not in EN_STOP:
            add(m.group(0))
    t = text or ""
    for b in sorted(LEX.get("cjk_boundary", []), key=len, reverse=True):
        t = t.replace(b, "\u0001")
    for part in t.split("\u0001"):
        p = re.sub(r'[^\u4e00-\u9fff]', '', part)
        if 2 <= len(p) <= 10:
            add(p)
    return terms


def split_clauses(text):
    text = re.sub(r'\s+', ' ', text or "")
    parts = [p.strip() for p in re.split(r'[。；;！？!?：:\n]', text) if p.strip()]
    if len(parts) <= 1:
        parts = [p.strip() for p in re.split(r'[，,]', text) if p.strip()]
    return parts or [text]


def decompose_question(question):
    subqs = []
    for i, cl in enumerate(split_clauses(question), 1):
        facets = [f for f, kws in LEX.get("facet_keywords", {}).items()
                  if any(k.lower() in cl.lower() for k in kws)] or ["object"]
        subqs.append({"id": f"sq{i}", "facet": facets[0],
                      "question": cl, "seed_terms": extract_seed_terms(cl), "confidence": "medium"})
    if not subqs:
        subqs.append({"id": "sq1", "facet": "object", "question": question or "",
                      "seed_terms": [], "confidence": "low"})
    return subqs


def expand_term(term):
    out, seen = [], set()
    t = (term or "").strip().strip('"“”').strip()

    def add(x):
        if x.lower() not in seen:
            seen.add(x.lower()); out.append(x)

    if not t:
        return out
    add(t); add(t.lower())
    for k, v in LEX.get("synonyms", {}).items():
        if t.lower() == k or t.lower() in v:
            for x in v:
                add(x)
    for k, v in LEX.get("abbrev", {}).items():
        if t.lower() == k or (re.fullmatch(r'[A-Z]{2,8}', t) and t.lower() == k):
            for x in v:
                add(x)
    for k, v in LEX.get("zh_en", {}).items():
        if t == k or t in k:
            for x in v:
                add(x)
    return [x for x in out if len(x.lower()) >= 2][:8]


def _mkq(qid, sq, term, src):
    return {"id": f"q{qid}", "sub_question_id": sq, "terms": [term],
            "variants": expand_term(term), "depends_on": [], "parallel": True,
            "status": "planned", "source": src}


def build_query_plan(subqs, extra=None):
    plan, qid = [], 0
    for sq in subqs:
        for term in sq["seed_terms"][:8]:
            qid += 1; plan.append(_mkq(qid, sq["id"], term, "derived"))
    for q in extra or []:
        if q and str(q).strip():
            qid += 1; plan.append(_mkq(qid, None, str(q), "case_queries"))
    return plan


def _extract_question(case):
    for k in ("task_instruction", "research_question", "question", "input", "prompt", "instruction", "task"):
        v = case.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
        if isinstance(v, dict):
            for kk in ("text", "content", "question", "instruction"):
                if isinstance(v.get(kk), str) and v.get(kk).strip():
                    return v[kk].strip()
    return ""


def _extract_queries(case, input_dir):
    qs = []
    for k in ("queries", "query_inputs", "search_queries", "query", "inputs"):
        v = case.get(k)
        if isinstance(v, list):
            for x in v:
                if isinstance(x, str) and x.strip():
                    qs.append(x.strip())
                elif isinstance(x, dict):
                    qs.extend(x[kk].strip() for kk in ("query", "text", "term")
                              if isinstance(x.get(kk), str) and x.get(kk).strip())
        elif isinstance(v, str) and v.strip():
            qs.append(v.strip())
    for root, _d, files in os.walk(input_dir):
        for fn in files:
            try:
                p = parse_text_as_json(open(os.path.join(root, fn), "r",
                                            encoding="utf-8", errors="replace").read())
                if isinstance(p, list) and p and all(isinstance(x, str) for x in p):
                    qs.extend(x.strip() for x in p if x.strip())
            except Exception:
                continue
    out, seen = [], set()
    for q in qs:
        k = q.lower()
        if k not in seen:
            seen.add(k); out.append(q)
    return out[:100]

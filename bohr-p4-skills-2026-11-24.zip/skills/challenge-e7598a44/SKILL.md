---
name: research-literature-retrieval
description: 将复杂科研问题拆解为可检索子问题，规划多轮查询并对本地文献快照（Crossref/EuropePMC/publisher 响应、引用图、增量导入状态）做全量筛选、去重与相关性排序，输出可追溯候选文献集与 result.json。用于“科研问题驱动检索”；不用于单篇精读、全文翻译、写作润色或开放式科研问答。
version: 1.0.0
---

# 科研问题驱动检索 Skill

## 用途
本 Skill 把一个科研问题转成“可检索子问题 → 多轮查询计划 → 全量筛选 → 去重与来源记录 → 相关性排序 → 覆盖与遗漏说明”的可复核流程。核心交付是 `result.json`（严格回填 `case.json` 的 `output_contract` 每个字段 + `case_id`）与一份可读报告 `report.md`。**不做实时联网检索**：只检索 `/input` 下组织方提供的本地文献快照，不编造 DOI、作者、年份、期刊或全文，不声称“最新文献/全局召回”。

## 触发条件
- 用户要求检索/筛选文献、回答科研问题并保留筛选依据，且输入为本地材料快照。
- 明确**不触发**：单篇精读、全文翻译、写作润色、开放式科研问答、实时联网检索。

## 调用方式
主入口是确定性脚本（纯 Python 标准库，不联网，不依赖 CWD）：

```bash
python scripts/main.py                 # 默认=完整流程：/input 真实派生 → /app/work + /app/output
python scripts/main.py --help           # 查看用法
python scripts/main.py check            # 校验 result.json 契约完整性 + 证据可追溯 + quote 命中
python scripts/main.py build            # 从 WORK_DIR 工作稿（sub_questions/query_plan）重跑流水线
```

目录可用环境变量或参数覆盖：`INPUT_DIR`/`WORK_DIR`/`OUTPUT_DIR` 或 `--input/--work/--output`；默认 `/input`、`/app/work`、`/app/output`。

脚本为纯 Python 标准库、离线、不依赖 CWD；脚本 `scripts/pipeline.py`、`scripts/retrieve.py` 为拆分模块，术语/缩写/跨语言词表与 `output_contract` 字段别名从 `references/lexicon.json` 加载（缺失时降级为空词表，仍可运行）。

**Agent 执行顺序（必须遵守）**：① 读 `/input/case.json` 与 `task.md`；② 运行 `python scripts/main.py` 得到确定性基线；③ 阅读 `result.json` 与 `report.md`，用领域判断补充/修正子问题拆解与术语扩展（写进 `WORK_DIR/work_notes.json` 后 `python scripts/main.py build` 重建）；④ 运行 `python scripts/main.py check` 复核；⑤ 不得把脚本输出当作“最终答案”而不核查，也不得为补齐字段而编造文献。

## 输入
- `/input/case.json`：含 `case_id`、`task_instruction`（科研问题）、`output_contract`（必须原样回填的字段清单，可为 dict 或 list）、可能的 `queries`（实际查询输入）。
- `/input/task.md`：任务说明（可为空或不存在）。
- `/input/` 下其余文件为材料快照：JSON/JSONL/CSV/TSV/TXT/XML/PDF 抽取文本，Crossref、EuropePMC、publisher 响应、引用图、增量导入状态等；**按真实文件内容读取，不得按文件名/标签假设内容**。

## 输出
- `/app/output/result.json`：必含 `case_id`、`status`、`sources`、`uncertainty`、`change_records`、`errors`、`degradations`，以及 `output_contract` 的**每一个字段**（缺值用 `null`/`[]`，不得改名/漏键）。
- `/app/output/report.md`：可编辑的人类可读报告，逐条候选含 `source + locator + 逐字 quote`。
- `/app/work/`：工作稿 `work_notes.json`、中间候选、`partial_result.json`（先写 partial 再 finalize）。
- 退出码恒为 0；异常写 `errors`/`degradations`，产出合法 partial，绝不 0 字节。

## 工作稿 schema
`WORK_DIR/work_notes.json`（示例，非正式案例结果）：
```json
{
  "case_id": "", "research_question": "",
  "sub_questions": [{"id":"sq1","facet":"object|mechanism|method|time|comparison|evidence","question":"","seed_terms":[],"confidence":"low|medium|high"}],
  "query_plan": [{"id":"q1","sub_question_id":"sq1","terms":[],"variants":[],"depends_on":[],"parallel":true,"status":"planned|run|no_result"}],
  "records": [{"id":"r1","source":"","locator":"","title":"","authors":[],"year":null,"venue":"","doi":null,"chunks":[]}],
  "matches": [{"query_id":"","record_id":"","variant":"","field_path":"","quote":"","score":0.0}],
  "candidates": [], "dedup": [], "conflicts": [], "coverage": {}, "omissions": []
}
```

## 证据规范
每条候选文献必须可追溯，缺一不可：
- `source`：材料文件名（相对 `/input` 的路径）。
- `locator`：文件内定位（如 `json.items[3]`、`europepmc.resultList.result[0]`、`line 7`、`row 12`）。
- `quote`：**逐字命中**的原文片段（来自材料原文，非改写）。每条候选至少 1 条 `evidence`，记录 `query_variant`、命中 `field_path` 与 `quote`。
- 无结果的 query 必须保留并说明（`no_result_queries`）；元数据缺失（无 DOI/年份/期刊）逐条注明，不补造。

## 降级表
| 情况 | 处置 | status |
|-|-|-|
| `/input` 不存在或不可读 | 写 `errors`，产出 `input_error` partial | `input_error` |
| `case.json` 坏 JSON / 缺 `case_id` | 写 `errors`，用占位 `case_id=null` 继续 | `input_error` |
| 材料缺失（仅 case.json/task.md） | `insufficient_evidence` + `gaps` | `insufficient_evidence` |
| 材料格式无法解析（二进制/损坏） | 记录 `degradations`，跳过该文件 | `partial` |
| 子问题/查询无命中 | 保留无结果 query，写 `omissions` | `partial` |
| 重复导出 / 冲突意见（如 search09 夹具） | 去重并记录 merge；冲突逐条记录，不做伪裁决 | `partial` |
| 元数据缺失 | 逐条标注，不编造 | 依主流程 |

## 自检（交付前必须全过）
1. `python scripts/main.py check` 通过：契约键齐全、`case_id` 存在、`status` 合法。
2. 每条候选含 `source + locator + quote`，quote 在材料原文可命中（命中率 ≥ 0.95）。
3. 两次全新输出目录运行，产物结构一致（不依赖时间/随机）。
4. 空输入、坏 JSON、缺材料三种状态均 exit 0 且 result.json 合法。
5. 无 `__pycache__`/`.pyc`，无占位答案；示例输出标注“示例，非正式案例结果”。

## 限制
- 只检索本地有限快照，**不声称全局召回**；Recall@k 以快照内记录为界并在 `uncertainty` 中说明。
- 确定性拆解/扩展是启发式，`confidence` 低的分面需 Agent 用领域判断复核。
- 不判读单篇全文、不做证据等级裁决；冲突意见仅并列记录。
- 不访问网络、不读取 `/input` 之外文件、不写 `submissions/`。

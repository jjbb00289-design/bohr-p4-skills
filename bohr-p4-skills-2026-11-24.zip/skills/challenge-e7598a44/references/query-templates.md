# 查询模板与术语扩展词表（可复用）

## 子问题分面（facet）
| facet | 含义 | 触发词示例 |
|-|-|-|
| object | 研究对象/人群/疾病/药物 | 患者、疾病、肿瘤、population、patient、disease |
| mechanism | 机制/通路/分子 | 机制、通路、信号、pathway、mechanism、signaling |
| method | 方法/设计/干预 | 随机、队列、系统评价、RCT、cohort、meta-analysis |
| time | 时间范围 | 年份、近五年、since、period |
| comparison | 比较关系 | 比较、对比、versus、vs |
| evidence | 证据要求 | 指南、系统评价、随机对照、guideline、recommend |

## 查询计划模板
```json
{"id":"q1","sub_question_id":"sq1","terms":["term"],
 "variants":["term","synonym","abbrev","zh_en"],
 "depends_on":[],"parallel":true,"status":"planned","source":"derived|case_queries"}
```

## 同义词扩展（SYNONYMS）
- randomized controlled trial = RCT = randomised controlled trial
- systematic review = SR = systematic literature review
- meta-analysis = metaanalysis
- cohort study = cohort = longitudinal study
- cancer = tumor/tumour = malignancy = carcinoma = neoplasm
- immunotherapy = immune checkpoint inhibitor = ICI
- prognosis = prognostic = survival = outcome
- diagnosis = diagnostic = detection
- therapy = treatment = therapeutic
- efficacy = effectiveness = benefit
- biomarker = marker = biomarkers

## 缩写扩展（ABBREV）
- RCT → randomized/randomised controlled trial
- SR → systematic review
- ICI → immune checkpoint inhibitor / immunotherapy
- OS → overall survival；PFS → progression-free survival
- NSCLC → non-small cell lung cancer；CRC → colorectal cancer；HCC → hepatocellular carcinoma
- ADC → antibody-drug conjugate

## 跨语言扩展（中文→英文，ZH_EN）
随机对照试验→randomized controlled trial/RCT；系统评价→systematic review；荟萃分析→meta-analysis；
队列研究→cohort study；癌症/肿瘤→cancer/tumor/carcinoma；免疫治疗→immunotherapy；机制→mechanism；
通路→pathway/signaling；预后→prognosis/survival；诊断→diagnosis；治疗→treatment/therapy；
生物标志物→biomarker/marker；基因→gene；患者→patient(s)；生存→survival；比较→comparison/versus；指南→guideline。

> 词表为启发式通用词，非穷尽；低置信分面须由 Agent 用领域判断补充，补充结果写入 `work_notes.json` 的 `query_plan` 后用 `main.py build` 重建。

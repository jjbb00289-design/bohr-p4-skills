# 方法、证据规范与降级表（可复用）

## 流水线方法（确定性，纯 Python 标准库，离线）
1. **加载**：按文件名排序读取 `/input` 下除 `case.json`/`task.md` 外的全部文件；解析 JSON/JSONL/CSV/TSV/TXT/XML；JSON 自动识别 `items/message/resultList/result/hits/records/papers/data` 等嵌套容器；每个标量带 `(字段路径, 原文)` 便于定位与逐字引用。
2. **拆解**：按句读切分科研问题，用分面关键词标注 object/mechanism/method/time/comparison/evidence；提取引号短语、英文词、中文词组为种子词。
3. **规划**：每个种子词一个查询，用同义词/缩写/跨语言词表扩展变体；同子问题内查询并行，记录依赖为空；实际查询输入（`case.json.queries` 或材料中的字符串列表）一并纳入，来源标 `case_queries`。
4. **全量筛选**：每个查询变体对每条记录的每个字段块做大小写不敏感子串匹配，命中即记录 `query_id + record_id + variant + field_path + quote`；无命中的查询保留。
5. **去重**：DOI（规范化小写）优先、否则规范化标题；合并重复导出，记录 `kept/removed/reason`；同键但年份/标题/期刊冲突者并列记录为冲突，不做伪裁决。
6. **排序**：分数 = 覆盖子问题数×2 + 命中词数×1 + 字段权重（title 3.0 / abstract 2.0 / venue 1.0 / 其他 1.0）+ 元数据完整度；按分数降序，nDCG/Precision@k 思路落 `metrics`。
7. **覆盖与遗漏**：无命中子问题、无结果查询、缺失元数据逐条列入 `omissions`；`coverage` 记录筛选/命中/筛除计数。

## 证据规范（每条候选必达）
- `source`：材料文件名；`locator`：文件内定位；`quote`：材料原文逐字片段（非改写）。
- 每条候选至少 1 条 `evidence`（`query_variant + field_path + quote`），quote 必须能在材料原文命中。
- 无结果查询、元数据缺失、冲突记录必须在结果中显式说明，不得补造。

## 降级表
| 情况 | 处置 | status |
|-|-|-|
| `/input` 不存在/不可读 | 写 `errors`，产出 `input_error` partial | input_error |
| `case.json` 坏 JSON / 缺 case_id | 写 `errors`，case_id=null 继续 | input_error |
| 材料缺失 | `insufficient_evidence` + gaps | insufficient_evidence |
| 文件无法解析 | `degradations` 记录，跳过该文件 | partial |
| 子问题/查询无命中 | 保留无结果查询，写 omissions | partial |
| 重复导出/冲突意见（如 search09 夹具） | 去重+merge；冲突并列记录 | partial |
| 元数据缺失 | 逐条标注，不编造 | 依主流程 |

## 自检
`python scripts/main.py check`：契约键齐全、case_id 存在、status 合法、候选含 source+locator+evidence、quote 命中率 ≥0.95；空输入/坏 JSON/缺材料三态 exit 0；两次全新输出结构一致。

"""writing_core: deterministic extraction + provenance verification (stdlib only)."""
import csv
import io
import json
import os
import re
import subprocess
import zipfile

ENC = ("utf-8", "gb18030", "latin-1")
RE_NUM = re.compile(r"(?<![\w.])-?\d+(?:\.\d+)?(?:[eE]-?\d+)?\s*(?:%|‰)?")
RE_CITE = re.compile(r"^\s*\[(\d+(?:\s*[-,]\s*\d+)*)\]\s*(.+)")
RE_INLINE_CITE = re.compile(r"\[(\d+(?:\s*[-,]\s*\d+)*)\]")
RE_FIG = re.compile(r"(图|Fig\.?|Figure|Table|表)\s*(\d+)", re.IGNORECASE)
RE_TERM = re.compile(r"\b[A-Z][A-Za-z0-9]{2,}(?:-[A-Za-z0-9]+)*\b")


def norm(s):
    if s is None:
        return ""
    return re.sub(r"\s+", " ", str(s)).strip()


def read_text(path):
    raw = open(path, "rb").read()
    for enc in ENC:
        try:
            return raw.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("utf-8", "replace")


def extract_pdf(path):
    try:
        out = subprocess.run(
            ["pdftotext", "-layout", path, "-"],
            capture_output=True, text=True, timeout=120,
        )
        txt = out.stdout or ""
        if txt.strip():
            return txt, "ok", ""
        return (out.stderr or "empty")[:300], "degraded", "pdftotext 无文本层"
    except FileNotFoundError:
        return "", "failed", "无 pdftotext，需 pdf-text-tool"
    except Exception as e:  # noqa: BLE001
        return "", "failed", "pdftotext 失败: %s" % e


def extract_docx(path):
    try:
        with zipfile.ZipFile(path) as z:
            xml = z.read("word/document.xml").decode("utf-8", "replace")
        txt = re.sub(r"</w:p>", "\n", xml)
        txt = re.sub(r"<[^>]+>", "", txt)
        txt = re.sub(r"&(amp|lt|gt|quot|apos);", lambda m: {
            "amp": "&", "lt": "<", "gt": ">", "quot": '"', "apos": "'"}[m.group(1)], txt)
        return txt, "ok", ""
    except Exception as e:  # noqa: BLE001
        return "", "failed", "DOCX 解析失败: %s" % e


def extract_csv(path):
    try:
        rows = list(csv.reader(open(path, "r", encoding="utf-8", errors="replace")))
        return "\n".join("\t".join(r) for r in rows), "ok", ""
    except Exception as e:  # noqa: BLE001
        return "", "failed", "CSV 解析失败: %s" % e


def extract_json(path):
    try:
        obj = json.load(open(path, "r", encoding="utf-8", errors="replace"))
        return json.dumps(obj, ensure_ascii=False, indent=1), "ok", ""
    except Exception as e:  # noqa: BLE001
        return "", "failed", "JSON 解析失败: %s" % e


def extract_sqlite(path):
    try:
        import sqlite3
        con = sqlite3.connect(path)
        cur = con.cursor()
        names = [r[0] for r in cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")]
        parts = ["TABLES: " + ", ".join(names)]
        for t in names:
            try:
                rows = cur.execute("SELECT * FROM %s LIMIT 200" % t).fetchall()
                parts.append("TABLE %s (%d rows):" % (t, len(rows)))
                parts.append("\n".join(repr(r) for r in rows))
            except Exception:  # noqa: BLE001
                parts.append("TABLE %s: 读取失败" % t)
        con.close()
        return "\n".join(parts), "ok", ""
    except Exception as e:  # noqa: BLE001
        return "", "failed", "SQLite 解析失败: %s" % e


KIND_EXT = {
    ".pdf": "pdf", ".docx": "docx", ".csv": "csv", ".tsv": "csv",
    ".json": "json", ".sqlite": "sqlite", ".sqlite3": "sqlite", ".db": "sqlite",
    ".txt": "txt", ".md": "txt", ".tex": "txt", ".bib": "txt",
}
IMG_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".tif", ".tiff", ".bmp", ".svg"}
DOC_EXT = {".doc", ".xlsx", ".xls", ".pptx", ".ppt"}


def classify(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in IMG_EXT:
        return "image"
    if ext in DOC_EXT:
        return "other"
    return KIND_EXT.get(ext, "other")


def extract_file(path):
    kind = classify(path)
    if kind == "image":
        return "", "degraded", "图片需 ocr-tool"
    if kind == "pdf":
        txt, st, deg = extract_pdf(path)
        return txt, st, deg
    if kind == "docx":
        txt, st, deg = extract_docx(path)
        return txt, st, deg
    if kind == "csv":
        txt, st, deg = extract_csv(path)
        return txt, st, deg
    if kind == "json":
        txt, st, deg = extract_json(path)
        return txt, st, deg
    if kind == "sqlite":
        txt, st, deg = extract_sqlite(path)
        return txt, st, deg
    if kind == "txt":
        try:
            return read_text(path), "ok", ""
        except Exception as e:  # noqa: BLE001
            return "", "failed", "文本读取失败: %s" % e
    try:
        raw = open(path, "rb").read()
        if b"\x00" in raw[:1024]:
            return "", "failed", "二进制文件无法解析"
        return read_text(path), "ok", ""
    except Exception as e:  # noqa: BLE001
        return "", "failed", "读取失败: %s" % e


def _loc(mid, idx=None):
    return {"material_id": mid} if idx is None else {"material_id": mid, "char": idx}


def build_inventory(materials):
    numbers, terms, citations, figures = [], [], [], []
    seen_term = set()
    seen_cite = set()
    for m in materials:
        txt = m.get("extracted_text") or ""
        if not txt:
            continue
        for mo in RE_NUM.finditer(txt):
            v = mo.group(0)
            if not v.strip():
                continue
            ctx = txt[max(0, mo.start() - 30): mo.end() + 30]
            numbers.append({"value": v.strip(), "context": norm(ctx),
                            "material_id": m["id"], "locator": mo.start()})
        for mo in RE_FIG.finditer(txt):
            figures.append({"ref": mo.group(0), "material_id": m["id"],
                            "locator": mo.start()})
        for mo in RE_TERM.finditer(txt):
            t = mo.group(0)
            if t not in seen_term:
                seen_term.add(t)
                terms.append({"term": t, "material_id": m["id"],
                              "locator": mo.start()})
        for i, line in enumerate(txt.splitlines()):
            mref = RE_CITE.match(line)
            if mref and mref.group(2).strip():
                key = "[" + mref.group(1) + "]"
                if (m["id"], key, "ref") not in seen_cite:
                    seen_cite.add((m["id"], key, "ref"))
                    citations.append({"key": key, "raw": norm(mref.group(2)),
                                      "material_id": m["id"], "locator": i})
        for mo in RE_INLINE_CITE.finditer(txt):
            key = "[" + mo.group(1) + "]"
            if (m["id"], key, "inline") in seen_cite:
                continue
            seen_cite.add((m["id"], key, "inline"))
            ctx = txt[max(0, mo.start() - 25): mo.end() + 25]
            citations.append({"key": key, "context": norm(ctx),
                              "material_id": m["id"], "locator": mo.start()})
    return {
        "numbers": numbers[:200], "terms": terms[:200],
        "citations": citations[:200], "figures": figures[:100],
    }


def verify_quotes(draft):
    """Return (hit, miss, total). Quotes matched after whitespace folding."""
    hit, miss = 0, 0
    texts = {m["id"]: norm(m.get("extracted_text")) for m in draft.get("materials", [])}
    slots = [
        ("sections", "claims"),
        ("fidelity_table", None),
        ("contribution_evidence", None),
        ("citation_list", None),
    ]
    for sec in draft.get("writing", {}).get("sections", []):
        for c in sec.get("claims", []):
            q, mid = c.get("quote"), c.get("material_id")
            if not q:
                continue
            if mid in texts and norm(q) and norm(q) in texts[mid]:
                hit += 1
            else:
                miss += 1
    for field, _ in slots:
        for item in draft.get("writing", {}).get(field, []):
            q, mid = item.get("quote"), item.get("material_id")
            if not q or mid not in texts or not norm(q):
                continue
            if norm(q) in texts[mid]:
                hit += 1
            else:
                miss += 1
    total = hit + miss
    return hit, miss, total

"""derive: deterministic auto-derivation of the writing draft from materials.

Standard library only, no network. Every claim / fidelity row / citation quote
is guaranteed to be a verbatim substring (after whitespace folding) of a
material's extracted text, so the default single command produces a non-empty,
check-passing result without any model writing step. A model-filled draft stays
an optional override at the caller's discretion.
"""
import json
import os
import re

try:
    import writing_core as wc
except ImportError:  # pragma: no cover
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import writing_core as wc

FOUR = ("background", "related_work", "gap", "contribution")
TITLES = {"background": "研究背景", "related_work": "相关工作",
          "gap": "研究空白", "contribution": "贡献"}
PROSE_KINDS = {"txt", "pdf", "docx", "other"}

_CJK = re.compile(r"[\u4e00-\u9fff]")
_UNIT_SPLIT = re.compile(r"[。！？；;!?]+")
_NUM_RE = re.compile(r"\d+(?:\.\d+)?(?:[eE]-?\d+)?\s*(?:%|‰)?")
_YEAR_RE = re.compile(r"(?:19|20)\d{2}")

_LABELS = [
    ("contribution", ("摘要", "abstract")),
    ("background", ("引言", "背景", "introduction", "background")),
    ("related_work", ("相关工作", "相关研究", "文献综述", "related work",
                      "relatedwork", "literature review")),
    ("gap", ("研究空白", "本研究空白", "空白", "研究缺口", "research gap", "gap")),
    ("contribution", ("贡献", "本文贡献", "主要贡献", "contribution", "contributions")),
]

_GAP_KW = ("空白", "缺口", "尚未", "未覆盖", "均未", "仍未", "缺乏", "不足", "亟待",
           "有待", "尚未解决", "未解决", "还未", "gap", "unexplored",
           "under-explored", "under explored", "remains open", "remains unsolved",
           "lack", "limited")
_CONTRIB_KW = ("本文提出", "本研究提出", "我们提出", "本文设计", "本文方法", "本文旨在",
               "本文通过", "我们设计", "we propose", "we present", "our method",
               "贡献", "达到", "优于", "结果表明", "准确率", "实现", "显著提升",
               "提出")
_RELATED_KW = ("相关工作", "已有工作", "已有方法", "先前工作", "传统方法", "近期工作",
               "文献", "等人", "et al", "针对", "related work", "prior work",
               "existing method", "existing work")

_REF_KEYS = ("references", "refs", "citations", "bibliography", "biblio")


def _cite_keys(text):
    return ["[%s]" % re.sub(r"\s+", "", g) for g in wc.RE_INLINE_CITE.findall(text)]


def _match_label(line):
    m = re.match(r"^([^：:。；;!?！？]+?)[：:]\s*(.*)$", line)
    if not m:
        return None, ""
    head = m.group(1).strip().lower()
    content = m.group(2).strip()
    if not content:
        return None, ""
    for sec, names in _LABELS:
        for nm in names:
            if head == nm:
                return sec, content
    return None, ""


def _match_header(line):
    s = re.sub(r"^[\d.\s]*", "", line).strip().lower()
    if not s or len(s) > 40:
        return None
    for sec, names in _LABELS:
        for nm in names:
            if s == nm:
                return sec
    return None


def _is_substantive(u):
    if _CJK.search(u):
        return True
    if _cite_keys(u):
        return True
    return len(u) >= 25


def _split_units(text):
    out = []
    for p in _UNIT_SPLIT.split(text):
        p = wc.norm(p)
        if p and _is_substantive(p):
            out.append(p)
    return out


def _collect_units(materials):
    units = []
    for m in materials:
        if m.get("kind") not in PROSE_KINDS:
            continue
        text = m.get("extracted_text") or ""
        if not text.strip():
            continue
        current = None
        for rawline in text.splitlines():
            line = rawline.strip()
            if not line:
                continue
            sec, content = _match_label(line)
            if sec:
                current = sec
                for u in _split_units(content):
                    units.append((u, m["id"], sec))
                continue
            sec = _match_header(line)
            if sec:
                current = sec
                continue
            for u in _split_units(line):
                units.append((u, m["id"], current))
    return units


def _classify(text):
    if any(k in text for k in _GAP_KW):
        return "gap"
    if any(k in text for k in _CONTRIB_KW):
        return "contribution"
    if _cite_keys(text) or any(k in text for k in _RELATED_KW):
        return "related_work"
    return "background"


def _classify_units(units):
    out = []
    for text, mid, sec in units:
        if sec is None:
            sec = _classify(text)
        out.append((text, mid, sec))
    return out


def _dedupe(units):
    seen, out = set(), []
    for text, mid, sec in units:
        if text in seen:
            continue
        seen.add(text)
        out.append((text, mid, sec))
    return out


def _ensure_nonempty(sec_units, units):
    used = set()
    for s in FOUR:
        for t, _m in sec_units[s]:
            used.add(t)
    for s in FOUR:
        if sec_units[s]:
            continue
        for t, m in units:
            if t not in used:
                sec_units[s].append((t, m))
                used.add(t)
                break
    return sec_units


def _find_loc(materials, mid, text):
    target = wc.norm(text)
    for m in materials:
        if m["id"] == mid:
            idx = wc.norm(m.get("extracted_text") or "").find(target)
            return idx if idx >= 0 else None
    return None


def _build_sections(sec_units, materials):
    sections = []
    for s in FOUR:
        claims = []
        for text, mid in sec_units[s]:
            claims.append({
                "text": text,
                "cite_keys": _cite_keys(text),
                "quote": text,
                "material_id": mid,
                "locator": _find_loc(materials, mid, text),
                "basis": "material",
            })
        prose = "。".join(c["text"] for c in claims) + ("。" if claims else "")
        sections.append({"id": s, "title": TITLES[s], "text": prose,
                         "claims": claims})
    return sections


def _verbatim(ntext, candidates):
    for c in candidates:
        if c is None:
            continue
        s = wc.norm(str(c))
        if not s:
            continue
        idx = ntext.find(s)
        if idx >= 0:
            return s, idx
    return None, None


def _cites_from_json(m):
    raw = m.get("extracted_text") or ""
    try:
        obj = json.loads(raw)
    except Exception:  # noqa: BLE001
        return []
    ntext = wc.norm(raw)
    refs = []

    def collect(node):
        if isinstance(node, dict):
            for k, v in node.items():
                if k.lower() in _REF_KEYS and isinstance(v, list):
                    refs.extend(x for x in v if isinstance(x, dict))
                collect(v)
        elif isinstance(node, list):
            for x in node:
                collect(x)

    collect(obj)
    out = []
    for i, item in enumerate(refs):
        k = item.get("key") or item.get("id") or item.get("ref")
        if k is None:
            key = "[%d]" % (i + 1)
        else:
            key = str(k)
            if not key.startswith("["):
                key = "[" + key + "]"
        authors = item.get("authors") or item.get("author") or item.get("name")
        year = item.get("year") or item.get("date")
        venue = (item.get("venue") or item.get("journal") or item.get("conference")
                 or item.get("source") or item.get("booktitle"))
        doi = item.get("doi") or item.get("url")
        quote, loc = _verbatim(ntext, (authors, venue, year, doi))
        out.append({"key": key, "authors": authors, "year": year, "venue": venue,
                    "doi": doi, "source": m["id"], "locator": loc, "quote": quote})
    return out


def _parse_ref(raw):
    parts = [p.strip() for p in raw.split(",")]
    authors = parts[0] if parts and parts[0] else None
    ym = _YEAR_RE.search(raw)
    year = ym.group(0) if ym else None
    venue = None
    if len(parts) >= 2:
        rest = [p for p in parts[1:] if p and not _YEAR_RE.fullmatch(p.strip())]
        if rest:
            venue = ", ".join(rest)
    return authors, year, venue


def _cites_from_text(m):
    txt = m.get("extracted_text") or ""
    ntext = wc.norm(txt)
    out = []
    for line in txt.splitlines():
        lm = wc.RE_CITE.match(line.strip())
        if not lm:
            continue
        raw = wc.norm(lm.group(2))
        if not raw:
            continue
        if not _YEAR_RE.search(raw):
            continue
        key = "[" + lm.group(1) + "]"
        authors, year, venue = _parse_ref(raw)
        quote, loc = _verbatim(ntext, (raw, authors, venue, year))
        out.append({"key": key, "authors": authors, "year": year, "venue": venue,
                    "doi": None, "source": m["id"], "locator": loc, "quote": quote})
    return out


def derive_citations(materials):
    json_cites = []
    for m in materials:
        if m.get("kind") == "json":
            json_cites.extend(_cites_from_json(m))
    if json_cites:
        out, seen = [], set()
        for c in json_cites:
            if c.get("key") and c["key"] not in seen:
                seen.add(c["key"])
                out.append(c)
        return out
    out, seen = [], set()
    for m in materials:
        if m.get("kind") in PROSE_KINDS:
            for c in _cites_from_text(m):
                if c.get("key") and c["key"] not in seen:
                    seen.add(c["key"])
                    out.append(c)
    if out:
        return out
    for m in materials:
        if m.get("kind") not in PROSE_KINDS:
            continue
        nt = wc.norm(m.get("extracted_text") or "")
        for mo in wc.RE_INLINE_CITE.finditer(nt):
            key = "[" + re.sub(r"\s+", "", mo.group(1)) + "]"
            if key in seen:
                continue
            seen.add(key)
            start = max(0, mo.start() - 20)
            end = min(len(nt), mo.end() + 40)
            out.append({"key": key, "authors": None, "year": None, "venue": None,
                        "doi": None, "source": m["id"], "locator": mo.start(),
                        "quote": nt[start:end]})
    return out


def derive_fidelity(materials, citation_list):
    ntexts = {m["id"]: wc.norm(m.get("extracted_text") or "") for m in materials}
    items = []
    for m in materials:
        if m.get("kind") not in PROSE_KINDS:
            continue
        raw = m.get("extracted_text") or ""
        nraw = ntexts[m["id"]]
        for line in raw.splitlines():
            for mo in _NUM_RE.finditer(line):
                v = mo.group(0).strip()
                if not v:
                    continue
                # skip citation indices such as the 1 in [1] / 2 in [2]
                if mo.start() > 0 and line[mo.start() - 1] == "[":
                    continue
                start = max(0, mo.start() - 14)
                end = min(len(line), mo.end() + 14)
                quote = wc.norm(line[start:end])
                if not quote:
                    continue
                loc = nraw.find(quote)
                items.append({"item": "数字", "value": v, "type": "kept",
                              "material_id": m["id"],
                              "locator": loc if loc >= 0 else None,
                              "quote": quote})
    for c in citation_list[:12]:
        if c.get("quote") and c.get("source") in ntexts:
            items.append({"item": "引用", "value": c.get("authors") or c.get("key"),
                          "type": "kept", "material_id": c.get("source"),
                          "locator": c.get("locator"), "quote": c.get("quote")})
    for m in materials:
        if m.get("kind") not in PROSE_KINDS:
            continue
        nt = ntexts[m["id"]]
        for mo in wc.RE_TERM.finditer(nt):
            term = mo.group(0)
            start = max(0, mo.start() - 12)
            end = min(len(nt), mo.end() + 12)
            items.append({"item": "术语", "value": term, "type": "kept",
                          "material_id": m["id"], "locator": mo.start(),
                          "quote": nt[start:end]})
            if len([x for x in items if x.get("item") == "术语"]) >= 8:
                break
    return items[:40]


def derive_alignment(sections):
    out = []
    for s in sections:
        for c in s.get("claims", []):
            if c.get("quote"):
                out.append({"original": c["quote"], "revised": c["text"],
                            "change_type": "未改",
                            "reason": "自动派生：逐字保留材料原文，未改写"})
    return out[:30]


def derive_gaps(sec_units):
    gap_units = sec_units.get("gap", [])
    if not gap_units:
        return []
    out = []
    for text, _mid in gap_units:
        out.append({"gap": text, "from_cites": _cite_keys(text),
                    "basis": "未覆盖场景", "how_filled": None})
    for e in out:
        for text, _mid in gap_units:
            if text != e["gap"] and any(k in text for k in ("本文", "填补", "解决", "弥补")):
                e["how_filled"] = text
                break
    return out


def derive_evidence(sec_units, materials):
    out = []
    for text, mid in sec_units.get("contribution", []):
        out.append({"contribution": text, "evidence": "材料原文定位",
                    "material_id": mid, "locator": _find_loc(materials, mid, text),
                    "quote": text})
    return out


def derive_writing(draft):
    materials = draft.get("materials") or []
    units = _collect_units(materials)
    units = _classify_units(units)
    units = _dedupe(units)
    sec_units = {s: [] for s in FOUR}
    for text, mid, sec in units:
        if sec in FOUR:
            sec_units[sec].append((text, mid))
    sec_units = _ensure_nonempty(sec_units, units)
    sections = _build_sections(sec_units, materials)
    citation_list = derive_citations(materials)
    fidelity_table = derive_fidelity(materials, citation_list)
    sentence_alignment = derive_alignment(sections)
    gap_derivation = derive_gaps(sec_units)
    contribution_evidence = derive_evidence(sec_units, materials)
    has_prose = any(c.get("text") for s in sections for c in s.get("claims", []))
    if has_prose:
        notes = {"manual_confirm": [
            "正文由脚本从材料逐字自动派生，未新增材料外事实；分组、措辞与引用完整性建议作者人工复核。"
        ], "gaps": [], "conflicts": []}
    else:
        notes = {"manual_confirm": [],
                 "gaps": ["材料不足，无法派生引言与相关工作正文"],
                 "conflicts": []}
    return {
        "language": "zh",
        "style": "从材料逐字自动派生（未改写）",
        "sections": sections,
        "sentence_alignment": sentence_alignment,
        "fidelity_table": fidelity_table,
        "gap_derivation": gap_derivation,
        "contribution_evidence": contribution_evidence,
        "citation_list": citation_list,
        "notes": notes,
        "change_records": [{
            "step": "auto_derive", "field": "writing", "from": None,
            "to": "自动派生四段正文与证据表",
            "reason": "空 work 下从 /input 材料逐字派生",
        }],
    }

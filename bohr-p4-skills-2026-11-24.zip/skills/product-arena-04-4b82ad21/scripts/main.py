"""main: single-command pipeline for the intro-related-work writer skill.

Deterministic: reads /input (case.json + task.md + materials), extracts text,
auto-derives a writing draft from the materials when no model draft exists,
verifies provenance quotes, and assembles /app/output/result.json with every
output_contract field backfilled. A model-filled work_draft.json stays an
optional override. Always exits 0. Stdlib only, no network, CWD-independent.
"""
import argparse
import json
import os
import sys

sys.dont_write_bytecode = True

try:
    import writing_core as wc
except ImportError:  # pragma: no cover
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import writing_core as wc

try:
    import derive
except ImportError:  # pragma: no cover
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import derive

DEFAULTS = {"input": "/input", "work": "/app/work", "output": "/app/output"}
FOUR_SECTIONS = ["background", "related_work", "gap", "contribution"]


def resolve_dirs(a):
    d = {}
    for k in ("input", "work", "output"):
        env = os.environ.get(k.upper() + "_DIR") or os.environ.get(k + "_dir")
        arg = getattr(a, k + "_dir", None)
        d[k] = arg or env or DEFAULTS[k]
    return d


def get(obj, *keys, default=None):
    for k in keys:
        if isinstance(obj, dict) and k in obj:
            return obj[k]
    return default


def load_case(input_dir):
    p = os.path.join(input_dir, "case.json")
    if not os.path.exists(p):
        return None, "missing", {}
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None, "bad_json", {}
        return data, "ok", data
    except Exception as e:  # noqa: BLE001
        return None, "bad_json", {"parse_error": str(e)}


def load_task(input_dir):
    p = os.path.join(input_dir, "task.md")
    if not os.path.exists(p):
        return ""
    try:
        return open(p, "r", encoding="utf-8", errors="replace").read()
    except Exception:  # noqa: BLE001
        return ""


def list_materials(input_dir):
    out = []
    skip = {"case.json", "task.md", ".DS_Store"}
    for root, dirs, files in os.walk(input_dir):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d != "__pycache__"]
        for fn in sorted(files):
            if fn in skip or fn.startswith("."):
                continue
            full = os.path.join(root, fn)
            rel = os.path.relpath(full, input_dir)
            out.append((rel, full))
    return out


def _writing_is_filled(w):
    """A draft counts as 'filled' only when the model actually wrote something."""
    if not isinstance(w, dict):
        return False
    if any((s.get("text") or "").strip() for s in w.get("sections", [])):
        return True
    for k in ("sentence_alignment", "fidelity_table", "gap_derivation",
              "contribution_evidence", "citation_list"):
        if w.get(k):
            return True
    return False


def build_draft(dirs, preserve_writing=None):
    draft_path = os.path.join(dirs["work"], "work_draft.json")
    case, cstate, raw = load_case(dirs["input"])
    task_md = load_task(dirs["input"])
    materials, degradations, errors = [], [], []
    for rel, full in list_materials(dirs["input"]):
        txt, st, deg = wc.extract_file(full)
        m = {"id": "m%d" % (len(materials) + 1), "path": rel, "kind": wc.classify(full),
             "extracted_text": txt, "chars": len(txt), "extraction_status": st,
             "degradation": deg}
        materials.append(m)
        if st != "ok":
            degradations.append({"file": rel, "status": st, "detail": deg})
    inventory = wc.build_inventory(materials)
    contract = get(raw, "output_contract", "outputContract", "outputs", default={})
    if not isinstance(contract, dict):
        contract = {}
    case_id = get(raw, "case_id", "caseId", "id", default=None)
    task_instruction = get(raw, "task_instruction", "taskInstruction",
                           "instruction", "prompt", default=None)
    old_writing = None
    if preserve_writing is not None:
        old_writing = preserve_writing
    elif os.path.exists(draft_path):
        try:
            old = json.load(open(draft_path, "r", encoding="utf-8"))
            old_writing = old.get("writing") if isinstance(old, dict) else None
        except Exception:  # noqa: BLE001
            old_writing = None
    draft = {
        "schema_version": "1.0",
        "case_id": case_id,
        "case_state": cstate,
        "task_instruction": task_instruction,
        "task_md": task_md[:8000],
        "output_contract": contract,
        "materials": materials,
        "inventory": inventory,
        "writing": empty_writing(),
        "notes": {"manual_confirm": [], "gaps": [], "conflicts": []},
        "change_records": [],
    }
    if old_writing and _writing_is_filled(old_writing):
        draft["writing"] = old_writing
    else:
        draft["writing"] = derive.derive_writing(draft)
    os.makedirs(dirs["work"], exist_ok=True)
    with open(draft_path, "w", encoding="utf-8") as f:
        json.dump(draft, f, ensure_ascii=False, indent=1)
    return draft, degradations, errors, task_instruction, case_id


def empty_writing():
    return {
        "language": "zh", "style": "",
        "sections": [{"id": s, "title": {"background": "研究背景", "related_work": "相关工作",
                     "gap": "研究空白", "contribution": "贡献"}[s],
                      "text": "", "claims": []} for s in FOUR_SECTIONS],
        "sentence_alignment": [], "fidelity_table": [], "gap_derivation": [],
        "contribution_evidence": [], "citation_list": [],
    }


def full_prose(writing):
    parts = []
    for s in writing.get("sections", []):
        t = (s.get("text") or "").strip()
        if t:
            parts.append("## %s\n\n%s" % (s.get("title") or s.get("id"), t))
    return "\n\n".join(parts)


def section_text(writing, key):
    for s in writing.get("sections", []):
        if s.get("id") == key:
            return s.get("text") or ""
    return ""


def intro_related_prose(writing):
    parts = []
    for sid in ("background", "related_work"):
        for s in writing.get("sections", []):
            if s.get("id") == sid and (s.get("text") or "").strip():
                parts.append("## %s\n\n%s" % (s.get("title") or s.get("id"),
                                              s.get("text").strip()))
    return "\n\n".join(parts)


def map_contract(contract, writing, prose):
    out = {}
    align = writing.get("sentence_alignment") or []
    fidelity = writing.get("fidelity_table") or []
    cites = writing.get("citation_list") or []
    gaps = writing.get("gap_derivation") or []
    evid = writing.get("contribution_evidence") or []
    manual = (writing.get("notes") or {}).get("manual_confirm") or []
    notes_str = "; ".join(str(x) for x in manual) or None
    intro_related = intro_related_prose(writing)
    for key in contract.keys():
        k = key.lower()
        if any(x in k for x in ("align", "对照", "diff", "comparison", "revision", "改写")):
            out[key] = align if align else None
        elif any(x in k for x in ("fidelity", "保真", "fact", "provenance", "mapping", "来源")):
            out[key] = fidelity if fidelity else None
        elif any(x in k for x in ("citation", "引用", "ref", "bib")):
            out[key] = cites if cites else None
        elif any(x in k for x in ("gap_derivation", "推导")):
            out[key] = gaps if gaps else None
        elif any(x in k for x in ("evidence", "contribution_evidence")):
            out[key] = evid if evid else None
        elif any(x in k for x in ("draft", "manuscript", "writing", "prose", "content",
                                  "正文", "fulltext", "result", "output")):
            out[key] = prose or None
        else:
            has_intro = any(x in k for x in ("intro", "background", "bg", "引言", "背景"))
            has_related = any(x in k for x in ("related", "相关工作", "相关研究", "literature"))
            if has_intro and has_related:
                out[key] = intro_related or None
            elif has_intro:
                out[key] = section_text(writing, "background") or None
            elif has_related:
                out[key] = section_text(writing, "related_work") or None
            elif any(x in k for x in ("gap", "空白", "researchgap")):
                out[key] = section_text(writing, "gap") or None
            elif any(x in k for x in ("contrib", "贡献")):
                out[key] = section_text(writing, "contribution") or None
            elif any(x in k for x in ("note", "说明")):
                out[key] = notes_str
            elif any(x in k for x in ("uncertain", "limit", "摘要", "summary")):
                out[key] = notes_str
            else:
                out[key] = None
    return out


def gather_sources(draft):
    srcs, seen = [], set()
    def add(mid, loc, quote, claim):
        if not mid:
            return
        key = (mid, str(loc), norm_quote(quote)[:80])
        if key in seen:
            return
        seen.add(key)
        srcs.append({"material_id": mid, "locator": loc, "quote": (quote or "")[:200],
                     "claim": (claim or "")[:120]})
    for s in draft.get("writing", {}).get("sections", []):
        for c in s.get("claims", []):
            add(c.get("material_id"), c.get("locator"), c.get("quote"), c.get("text"))
    for field in ("fidelity_table", "contribution_evidence", "citation_list"):
        for item in draft.get("writing", {}).get(field, []):
            add(item.get("material_id"), item.get("locator"), item.get("quote"),
                item.get("value") or item.get("contribution") or item.get("raw"))
    return srcs[:500]


def norm_quote(q):
    return wc.norm(q)


def compute_status(draft, hit, total):
    if draft.get("case_state") in ("missing", "bad_json"):
        return "input_error"
    ok_texts = [m for m in draft.get("materials", []) if m.get("extracted_text") and m.get("extracted_text").strip()]
    if not ok_texts:
        return "insufficient_evidence"
    w = draft.get("writing", {})
    filled = [s for s in w.get("sections", []) if (s.get("text") or "").strip()]
    if not filled:
        return "partial"
    if len(filled) >= 4 and (total == 0 or (total > 0 and hit / total >= 0.95)):
        return "complete"
    return "partial"


def result_dict(draft, degradations, errors, hit, total):
    w = draft.get("writing", {})
    prose = full_prose(w)
    status = compute_status(draft, hit, total)
    contract_values = map_contract(draft.get("output_contract") or {}, w, prose)
    manual = (w.get("notes") or {}).get("manual_confirm") or []
    gaps = list((w.get("notes") or {}).get("gaps") or [])
    if status == "partial" and not any(s.get("text", "").strip() for s in w.get("sections", [])):
        gaps.append("写作正文未由模型生成：脚本仅派生材料清单与确定性抽取，需调用方模型填写 writing")
    if draft.get("case_state") == "missing":
        gaps.append("无 case.json")
    if draft.get("case_state") == "bad_json":
        gaps.append("case.json 解析失败")
    res = {
        "case_id": draft.get("case_id"),
        "status": status,
        "sources": gather_sources(draft),
        "uncertainty": {
            "quote_hit_rate": (hit / total) if total else None,
            "quote_checked": total,
            "manual_confirm": manual,
            "unverified_claims": total - hit if total else 0,
        },
        "change_records": w.get("change_records") or [],
        "errors": errors,
        "degradations": degradations,
        "gaps": gaps,
    }
    res.update(contract_values)
    return res


def write_artifacts(dirs, draft):
    w = draft.get("writing", {})
    outdir = dirs["output"]
    os.makedirs(outdir, exist_ok=True)
    prose = full_prose(w)
    if prose:
        with open(os.path.join(outdir, "draft.md"), "w", encoding="utf-8") as f:
            f.write(prose + "\n")
        srcs = gather_sources(draft)
        if srcs:
            with open(os.path.join(outdir, "sources.json"), "w", encoding="utf-8") as f:
                json.dump(srcs, f, ensure_ascii=False, indent=1)
    for name, key in (("alignment.json", "sentence_alignment"),
                      ("fidelity.json", "fidelity_table"),
                      ("gap_derivation.json", "gap_derivation"),
                      ("contribution_evidence.json", "contribution_evidence"),
                      ("citations.json", "citation_list")):
        data = w.get(key) or []
        if data:
            with open(os.path.join(outdir, name), "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=1)
    # material extraction always retained
    with open(os.path.join(outdir, "materials_extracted.json"), "w", encoding="utf-8") as f:
        json.dump([{k: m.get(k) for k in ("id", "path", "kind", "chars", "extraction_status",
                  "degradation")} for m in draft.get("materials", [])],
                  f, ensure_ascii=False, indent=1)


def save_result(dirs, res):
    os.makedirs(dirs["output"], exist_ok=True)
    with open(os.path.join(dirs["output"], "result.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)


def load_draft(dirs):
    p = os.path.join(dirs["work"], "work_draft.json")
    if os.path.exists(p):
        try:
            return json.load(open(p, "r", encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return None
    return None


def cmd_init(dirs):
    draft, deg, err, _, _ = build_draft(dirs)
    hit, miss, total = wc.verify_quotes(draft)
    res = result_dict(draft, deg, err, hit, total)
    save_result(dirs, res)
    return draft, deg, err, hit, miss, total


def cmd_check(dirs):
    draft = load_draft(dirs)
    if draft is None:
        draft, deg, err, _, _ = build_draft(dirs)
    else:
        deg, err = [], []
    contract = draft.get("output_contract") or {}
    hit, miss, total = wc.verify_quotes(draft)
    missing = [k for k in contract.keys() if k not in result_dict(
        draft, [], [], hit, total)]
    print("case_id:", draft.get("case_id"))
    print("contract keys: %d (unmapped->null: %d)" % (len(contract), len(missing)))
    print("quote: hit=%d miss=%d total=%d rate=%s" % (
        hit, miss, total, ("%.3f" % (hit / total)) if total else "n/a"))
    return draft, deg, err, hit, miss, total


def cmd_finalize(dirs):
    draft = load_draft(dirs)
    if draft is None:
        draft, deg, err, _, _ = build_draft(dirs)
    else:
        deg, err = [], []
    hit, miss, total = wc.verify_quotes(draft)
    res = result_dict(draft, deg, err, hit, total)
    save_result(dirs, res)
    write_artifacts(dirs, draft)
    return draft, deg, err, hit, miss, total


def cmd_show(dirs):
    draft = load_draft(dirs)
    if draft is None:
        case, cstate, raw = load_case(dirs["input"])
        print("case_state:", cstate)
        print("case_id:", get(raw, "case_id", "caseId", "id", default=None))
        print("task_instruction:", get(raw, "task_instruction", "taskInstruction",
              "instruction", "prompt", default=None))
        print("output_contract:", get(raw, "output_contract", "outputContract",
              "outputs", default={}))
        print("materials:", [r for r, _ in list_materials(dirs["input"])])
        return
    print("case_id:", draft.get("case_id"))
    print("materials:", [(m["id"], m["path"], m["kind"], m["extraction_status"])
                         for m in draft.get("materials", [])])
    print("inventory counts:", {k: len(v) for k, v in draft.get("inventory", {}).items()})
    print("sections:", [(s["id"], len(s.get("text") or "")) for s in
                        draft.get("writing", {}).get("sections", [])])


def main(argv=None):
    p = argparse.ArgumentParser(prog="main.py", add_help=False)
    p.add_argument("cmd", nargs="?", default="run",
                   choices=["run", "init", "extract", "show", "check", "finalize", "build"])
    p.add_argument("--input", "--input-dir", dest="input_dir")
    p.add_argument("--work", "--work-dir", dest="work_dir")
    p.add_argument("--output", "--output-dir", dest="output_dir")
    p.add_argument("-h", "--help", action="store_true")
    a = p.parse_args(argv)
    if a.help:
        print(__doc__)
        print("commands: run | init | extract | show | check | finalize | build")
        print("env: INPUT_DIR / WORK_DIR / OUTPUT_DIR  (also --input/--work/--output)")
        return 0
    dirs = resolve_dirs(a)
    try:
        if a.cmd in ("init", "extract"):
            cmd_init(dirs)
        elif a.cmd == "show":
            cmd_show(dirs)
        elif a.cmd == "check":
            cmd_check(dirs)
        elif a.cmd in ("finalize", "build"):
            cmd_finalize(dirs)
        else:  # run
            cmd_init(dirs)
            cmd_check(dirs)
            cmd_finalize(dirs)
    except Exception as e:  # noqa: BLE001
        res = {"case_id": None, "status": "partial", "sources": [],
               "uncertainty": {}, "change_records": [], "errors": [str(e)],
               "degradations": [], "gaps": ["pipeline 异常，已写 partial"]}
        save_result(dirs, res)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# 最小调用示例（示例，非正式案例结果）

## 输入
`/input/case.json`：
```json
{
  "case_id": "demo-001",
  "task_instruction": "依据材料 paper.txt 撰写论文引言与相关工作，中文，数字编号引用，逐条给出来源。",
  "output_contract": {
    "introduction": "string",
    "fidelity_table": "list"
  }
}
```
`/input/task.md`：本题说明（可空）。
`/input/paper.txt`：
```
摘要：本研究提出方法 A，在数据集 D 上准确率达到 95.2%，优于基线 B 的 91.0%。
相关工作：已有方法 X 需要人工特征，Y 依赖大规模标注数据。
```

## 调用
```
python scripts/main.py init
# Agent（模型）填写 /app/work/work_draft.json 的 writing 后：
python scripts/main.py check
python scripts/main.py finalize
```

## 示意输出（示例，非正式案例结果）
`/app/output/draft.md`（节选）：
```
## 研究背景
…本任务的关键指标是准确率；基线 B 达到 91.0% [1]…
```
`/app/output/result.json`（节选）：
```json
{
  "case_id": "demo-001",
  "status": "complete",
  "introduction": "## 研究背景\n…",
  "fidelity_table": [
    {"item":"数字","value":"95.2%","type":"kept",
     "material_id":"m1","locator":0,"quote":"准确率达到 95.2%"}
  ],
  "sources": [{"material_id":"m1","locator":0,"quote":"准确率达到 95.2%","claim":"…"}],
  "uncertainty": {"quote_hit_rate": 1.0, "quote_checked": 1}
}
```
以上数字与结论均取自示例材料；正式案例以实际 `/input` 为准。

---
name: intro-related-work-writer
description: 依据科研材料完成“引言与相关工作”的可核验写作、改写与引用/贡献保真：四段式成稿（研究背景、相关工作、研究空白、贡献）绑定逐条来源定位，输出可编辑正文、原文-改文对照、事实/术语/引用保真表与空白-贡献推导表。适用于论文引言起草、相关工作整理、补引用、核对贡献等指令。核心价值是“每条论断可回溯到材料原文”，不新增材料外事实、不整段重写。
version: 1.0.0
---

# 引言与相关工作写作（intro-related-work-writer）

## 1. 用途
在给定科研材料（论文 PDF、正文片段、图表、表格、参考文献、DOCX/SQLite 等）之上，产出可直接进入论文的“引言与相关工作”稿件，并把每一处论断、数字、术语、引用、空白推导与贡献条目绑定到材料原文，交付可独立复核的证据链。本 Skill 聚焦题目四个问题：**立得住、分得清、说得实、对得上**，并以“逐条来源定位”为贯穿红线。

## 2. 触发条件
用户/上层 Agent 出现以下意图时启用：
- “写引言”“起草 Introduction”“整理/组织相关工作”“补引用”“核对贡献”“改写引言/相关工作”“对照修改”“做引用与论断绑定”“检查空白是否成立”。
- 需要把他人工作按问题/方法路线分组比较，而不是逐篇摘要拼接。
- 需要把贡献条目与本文方法、图表、实验结果一一对应。
不适用的任务：纯文献检索综述、与材料无关的科普改写、整段风格化重写（本 Skill 保留事实与引用，只做有证据的逐句修订）。

## 3. 调用方式
本 Skill 安装后位于 Skill 根目录（评测环境为 `/skills/weekly-skill`，脚本在 `<Skill根>/scripts/main.py`；本地为 `submission/scripts/main.py`）。运行时不依赖 CWD，可用环境变量 `INPUT_DIR` / `WORK_DIR` / `OUTPUT_DIR` 或参数 `--input/--work/--output` 覆盖默认路径（`/input`、`/app/work`、`/app/output`）。

标准流程（单命令）：
```
python scripts/main.py            # init → extract → auto-derive → build → check → finalize
```
分步调用：
```
python scripts/main.py init       # 读 case.json/task.md，抽取材料，自动派生 writing，建 /app/work/work_draft.json
python scripts/main.py show       # 展示 case 元数据、材料清单、output_contract
# —— Agent（模型）可在此基础上改写 work_draft.json 的 writing 与 notes（可选覆盖）——
python scripts/main.py check      # 校验 quote 命中率、契约键齐全性
python scripts/main.py finalize   # 组装 /app/output/result.json 与可编辑产物（幂等）
python scripts/main.py build      # 等价 finalize，重跑不会重复累加
python scripts/main.py --help
```
关键约定：**脚本在空 work 下即从 `/input` 材料逐字自动派生四段正文（研究背景/相关工作/研究空白/贡献）、sentence_alignment、fidelity_table、citation_list，且每条 quote 都是材料原文的逐字子串；不依赖 Agent 预填草稿。** 若 work_draft.json 已含模型填写的 writing，则视为可选覆盖并原样保留。脚本始终只做真实抽取、契约回填与逐字校验，绝不伪造正文或补造材料外事实。

## 4. 输入输出

**输入**（只读，事实依据）：
- `case.json`：`case_id`、`task_instruction`、`output_contract`（产出字段契约，必须原样回填每一个字段）。
- `task.md`：本题说明与评分要求。
- 材料文件：PDF（真实 PDF，可能无预抽文本层）、图片/表格、DOCX、SQLite、CSV、txt/md/json 等。**按真实文件读取，不得按标签假设内容。**

**输出**（`/app/output/`）：
- `result.json`：回填 `output_contract` 全部字段 + `case_id`，并带 `status`、`sources`（证据定位）、`uncertainty`、`change_records`、`errors`、`degradations`、`gaps`。
- 可编辑正文（Markdown 或 `.tex`，逐句保留来源标记）。
- `alignment.json`（原文-改文逐句对照，含修改类型与理由）。
- `fidelity.json`（事实/术语/引用保真表）。
- 需要时 `gap_derivation.json`、`contribution_evidence.json`、`citations.json`。
- 每个案例先写 partial `result.json`，再增量 finalize；所有异常捕获写入 `errors/degradations`，**退出码恒 0**。

无论是否运行脚本，`result.json` 都必须含 `case_id`、`output_contract` 全部字段与 `status/sources/uncertainty/change_records`；脚本不可用时由模型直接按本 schema 生成，不得漏键或改键名。

## 5. 工作稿 schema（`/app/work/work_draft.json`）
脚本 `init` 抽取材料后自动派生 `writing` 并落盘；模型可直接改用该文件，覆盖 `writing` 与 `notes`。字段如下：
```
{
  "schema_version": "1.0",
  "case_id": "...", "task_instruction": "...", "task_md": "...",
  "output_contract": { "...": "原始契约字段" },
  "materials": [ {"id":"m1","path":"...","kind":"pdf|txt|docx|json|csv|image|other",
                  "extracted_text":"...","chars":N,"extraction_status":"ok|degraded|failed",
                  "degradation":"..."} ],
  "inventory": {
    "numbers":  [ {"value":"...","context":"...","material_id":"m1","locator":"..."} ],
    "terms":    [ {"term":"...","material_id":"m1","locator":"..."} ],
    "citations":[ {"key":"[1]","raw":"作者, 年份, 来源...","material_id":"m1","locator":"..."} ],
    "figures":  [ {"ref":"图1","material_id":"m1","locator":"..."} ]
  },
  "writing": {
    "language":"zh|en|zh-en","style":"...",
    "sections":[ {"id":"background|related_work|gap|contribution","title":"...","text":"可编辑正文",
                  "claims":[ {"text":"一句论断","cite_keys":["[1]"],"quote":"材料逐字原文",
                              "material_id":"m1","locator":"页码/行号/路径",
                              "basis":"material|author_judgment"} ]} ],
    "sentence_alignment":[ {"original":"...","revised":"...","change_type":"改写|补引用|修正|未改",
                            "reason":"..."} ],
    "fidelity_table":[ {"item":"数字|术语|引用|图表|论断","value":"...","type":"kept|changed|added",
                        "material_id":"m1","locator":"...","quote":"..."} ],
    "gap_derivation":[ {"gap":"...","from_cites":["[1]"],"basis":"共同限制|未覆盖场景|相互冲突",
                        "how_filled":"本文如何填补"} ],
    "contribution_evidence":[ {"contribution":"...","evidence":"方法/图表/实验结果定位",
                               "material_id":"m1","locator":"...","quote":"..."} ],
    "citation_list":[ {"key":"[1]","authors":"...","year":"...","venue":"...","doi":"...",
                       "source":"material_id","locator":"...","quote":"..."} ]
  },
  "notes": {"manual_confirm":[...],"gaps":[...],"conflicts":[...]},
  "change_records":[ {"step":"...","field":"...","from":"...","to":"...","reason":"..."} ]
}
```
缺值用 `null`/`[]`，不得改键名或漏键。`quote` 必须能在对应 `material_id` 的 `extracted_text` 中逐字命中（空白折叠后）。

## 6. 证据规范（逐条可核验红线）
1. **一条论断一个来源**：每个事实性句子至少带 `cite_keys` 或 `quote+material_id+locator`；无来源的句子只能写入 `basis="author_judgment"`，并在正文显式标注“本文认为/作者判断”。
2. **quote 逐字命中**：`quote` 取自材料原文，去首尾空白、内部连续空白折叠后仍是 `extracted_text` 的子串；脚本 `check` 计算命中率，目标 ≥0.95。
3. **不新增材料外事实**：数字、术语、单位、限定词强度、引用元数据（作者/年份/来源/DOI）一律照抄材料；材料没有的字段留 `null`，不得补造。
4. **改写保真**：改写不得改变数字、单位、限定词（如 “some/most/所有/约/显著”）、结论方向；`change_type` 分 `改写/补引用/修正/未改`，每条给 `reason`。
5. **引用与论断一一对应**：引用编号落在具体论断上，不整段挂一个引用；citation_list 的元数据来自材料，编号与正文一致。
6. **图表指向一致**：正文中“图1/表2/Fig.1/Table 2”等指向沿用材料编号，不改写编号。

## 7. 四段式写作规范
**研究背景（立得住）**：从领域脉络、具体问题与技术约束入手，说明“为什么这个问题现在值得做”；禁止“近年来受到广泛关注”式空转。每句指向具体工作或具体未解决问题。
**相关工作（分得清）**：先建立分组维度（问题设定 / 方法路线 / 数据与评价方式），按维度分组比较，不按时间罗列；每组一句“该路线如何做 + 适用条件 + 局限”，转述结论须与原文一致。
**研究空白（说得实）**：空白必须由已引工作的**共同限制 / 未覆盖场景 / 相互冲突结论**推出；每条空白写 `from_cites` 与 `how_filled`，无依据的空白标为作者判断或删除。
**贡献（对得上）**：把方法、实验、结论压缩为可核对条目，每条写 `evidence`（方法/图表/实验定位），不夸大适用范围。

## 8. 引用覆盖规范
- 覆盖三类：关键工作、代表性工作、近期进展；必要字段（作者、年份、来源）齐全。
- 引用格式统一（默认数字编号 `[n]`，按首次出现顺序；若 task 指定样式则遵循指定样式）。
- 缩写首次出现给出全称；术语表与原文一致；不擅自改编号/顺序。

## 9. 降级表（异常处置，均写入 result.json，退出码 0）
| 情形 | 处置 | status |
|-|-|-|
| 空输入（无 case.json） | 写合法 partial：`input_error`，`gaps=["无输入文件"]` | input_error |
| 坏 JSON | 记录解析错误，`status=input_error`，产物为空骨架 | input_error |
| 缺材料（只有 case/task） | `insufficient_evidence`，正文不生成，写 `gaps` | insufficient_evidence |
| PDF 无文本层/无 pdftotext | `degradations` 标注，正文基于可读部分，未读页写 `gaps` | partial |
| 图片/表格无法 OCR | 标注需 `ocr-tool`，不臆测内容 | partial |
| 引用查不到原文 | 该引用元数据留 `null`，写 `manual_confirm` | partial |
| 目标期刊格式未知 | 采用默认格式并在 `uncertainty` 说明 | partial |
| 语言切换（zh/en） | 按 task_instruction 决定，无指定则中文正文+英文术语保留 | partial |
| 空白缺乏依据 | 标 `author_judgment` 或删除，写 `uncertainty` | partial |
| 权限不足/读写失败 | 捕获异常写 `errors`，尽可能落 partial 产物 | partial |

## 10. 自检清单（finalize 前逐项过）
- [ ] result.json 含 case_id + output_contract 全部键 + status/sources/uncertainty/change_records
- [ ] 四段齐全且承接；每段 claim 有 cite_keys 或 author_judgment
- [ ] quote 命中率 ≥0.95（`python scripts/main.py check`）
- [ ] 数字/单位/限定词/结论方向未变；citation_list 元数据与材料一致
- [ ] 分组有维度、空白有 from_cites、贡献有 evidence
- [ ] LaTeX 题：真实 `.tex`；编译器不可用则输出 `.tex` 并标 degradation，不伪造 PDF

## 11. 限制
- 脚本为标准库实现，不联网；PDF/DOCX/CSV/JSON 抽取与 quote 校验由脚本完成，写作正文默认由脚本从材料逐字自动派生，模型可改写为更精炼的稿件。
- 不覆盖：非科研文体、无材料的凭空写作、跨语言机器翻译（保留原文事实的对照改写除外）。
- 模型预算：接近 780 秒立即 finalize 已完成交付，先落 partial 再增量。

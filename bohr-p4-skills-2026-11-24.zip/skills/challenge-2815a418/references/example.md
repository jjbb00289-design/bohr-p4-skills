# 最小调用示例（示例，非正式案例结果）

> 本文件是接口演示，使用的是合成测试案例，**不是**平台正式案例，**不得**当作正式答案或结果提交。

## 1. 输入

```
input/
  case.json                 # case_id "demo-1"；output_contract 见 §2
  materials/
    manuscript-baseline.md  # 基线摘要（Abstract/Introduction/Methods/Results/Discussion/Conclusion）
    reviewer-comments.md    # Comment 1.1 ... Comment 3.1
    organizer-workorder.json# targets: C1.1 ... C3.1
```

`case.json` 的 `output_contract`（示例）：

```json
{"case_id":"string","status":"string","deliverable":"path","revised_manuscript":"path",
 "response_letter":"path","comment_ledger":"array","change_locator":"array",
 "evidence_pending":"path","preserved_facts":"array","evidence_map":"array",
 "change_log":"array","workorder_execution":"array","result":"object",
 "sources":"array","uncertainty":"array","pending_human":"array"}
```

## 2. 运行

```bash
python scripts/main.py init  --input input --work w --output o
python scripts/main.py show  --material m1          # 基线逐段（para.1 ...）
python scripts/main.py show  --material m3          # 意见逐条
python scripts/main.py extract                      # 候选数字/DOI/意见条目
# Agent 阅读后写 w/draft.json（结构见 SKILL.md §5，节选）：
```

```json
{
  "case_id": "demo-1",
  "comments": [{
    "comment_id": "C1.1",
    "comment_text": "The XPS quantification is not described. ...",
    "type": "method", "severity": "major", "decision": "accept", "tone": "accept",
    "response": "We now state the O 1s fitting procedure and the Ar purity/flow control in Methods; ...",
    "sub_requirements": [
      {"sub_id": "C1.1a", "requirement": "state how Ov fraction was calculated",
       "decision": "accept", "change_ids": ["CH1"]}
    ],
    "change_ids": ["CH1"],
    "evidence": [{"need": "exact Ar flow set point", "status": "unavailable",
                  "source": "not recorded in the baseline",
                  "alternative": "report controller type and purity only"}]
  }],
  "changes": [{
    "change_id": "CH1", "comment_id": "C1.1", "section": "Methods",
    "original_quote": "X-ray photoelectron spectroscopy (XPS) was performed on a Thermo K-Alpha instrument with an Al Kα source; binding energies were referenced to C 1s at 284.8 eV.",
    "revised_text": "X-ray photoelectron spectroscopy (XPS) was performed ... [same sentence] ... The oxygen-vacancy fraction was calculated from the O 1s envelope as Ov/(Olat + Ov + Oads) after Shirley background subtraction.",
    "basis": "Reviewer C1.1 asked how the Ov fraction was calculated."
  }],
  "preserved_facts": [
    {"fact_id": "F1", "value": "1.36", "unit": "V", "source_id": "m1", "locator": "para.9",
     "quote": "The optimized sample shows an overpotential of 1.36 V vs RHE at 10 mA cm-2 for UOR."}
  ]
}
```

```bash
python scripts/main.py check --input input --work w --output o
# {"passed": true, "fail_count": 0, ...}
python scripts/main.py build --input input --work w --output o
```

## 3. 输出（节选）

`o/revised_manuscript.md`：

```markdown
## Methods

NiCo2O4 powders were synthesized ... X-ray photoelectron spectroscopy (XPS) was performed on a
Thermo K-Alpha instrument ... The oxygen-vacancy fraction was calculated from the O 1s envelope
as Ov/(Olat + Ov + Oads) after Shirley background subtraction.
```

`o/response_letter.md`：

```markdown
## Comment C1.1

**Reviewer comment (as supplied).** The XPS quantification is not described. ...

**Decision: accept.**

**Response.** We now state the O 1s fitting procedure and the Ar purity/flow control in Methods; ...

**Changes in the revised manuscript:**

- CH1 (Methods, P2): replaced `X-ray photoelectron ... 284.8 eV.` with `... 284.8 eV. The oxygen-vacancy ...`
```

`o/comment_ledger.json`（节选）：

```json
[{"comment_id":"C1.1","type":"method","severity":"major","decision":"accept",
  "sub_requirements":[{"sub_id":"C1.1a","requirement":"state how Ov fraction was calculated",
  "decision":"accept","change_ids":["CH1"]}],
  "change_ids":["CH1"],"evidence_items":[{"evidence_id":"EC1.1.1",
  "need":"exact Ar flow set point","status":"unavailable"}],"status":"answered"}]
```

`o/change_locator.json`（节选）：

```json
[{"change_id":"CH1","comment_id":"C1.1","section":"Methods","paragraph_id":"P2",
  "locator":"section=Methods;paragraph=P2;baseline=materials/manuscript-baseline.md",
  "original_quote":"X-ray photoelectron ... 284.8 eV.","revised_quote":"X-ray photoelectron ...",
  "applied":true,"status":"applied"}]
```

## 4. 反例（会被 check 拦住）

- `"response": "We thank the reviewer for this comment."` → `response_short`（空话）。
- `original_quote` 用了改写句而非基线原句 → `change_quote`（逐字不命中）。
- `revised_text` 与 `original_quote` 相同 → `change_noop`（假改动）。
- 未做实验却写「we have performed in situ Raman」→ 属于伪造，禁止；应写 `unavailable` + 替代。
- 只给一条意见的结论、不拆子要求 → `sub_requirements`（答不全）。

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""review-revision -- reviewer response + traceable manuscript revision skill.

Commands: init | show | extract | check | build
Flow: init -> show (read baseline + comments) -> write work/draft.json -> check -> build

The agent must read the baseline manuscript and the reviewer comment list, then record
per-comment decisions, sub-requirements and anchored changes in work/draft.json.
The script applies each change to the exact baseline paragraph, renders the revised
manuscript + point-by-point response letter + comment ledger + change locator, and
finalizes a contract-complete result.json. It never invents experiments, references
or reviewer wording.
"""
import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import core as K

NAME = "review-revision"
VERSION = "1.0.0"
DELIVERABLES = {
    "revised_manuscript": "revised_manuscript.md",
    "response_letter": "response_letter.md",
    "comment_ledger": "comment_ledger.json",
    "change_locator": "change_locator.json",
    "evidence_pending": "evidence_pending.md",
}
DECISIONS = {"accept", "partial", "reject", "clarify", "invalid"}
TYPES = {"method", "data", "writing", "format", "ethics", "other"}
SEVERITY = {"major", "minor"}
TONE = {"accept", "clarify", "polite_refute", "appeal"}
ARTIFACT_MAP = {
    "revised_manuscript": "revised_manuscript.md",
    "revisedmanuscript": "revised_manuscript.md",
    "response_letter": "response_letter.md",
    "responseletter": "response_letter.md",
    "comment_ledger": "comment_ledger.json",
    "commentledger": "comment_ledger.json",
    "change_locator": "change_locator.json",
    "changelocator": "change_locator.json",
    "evidence_pending": "evidence_pending.md",
    "evidencepending": "evidence_pending.md",
}


# ------------------------------------------------------------------ manuscript model
def parse_manuscript(text):
    """Parse markdown manuscript into {title, sections:[{heading, level, paragraphs[]}]}."""
    text = K.norm_text(text)
    state = {"title": "", "sections": [], "preamble": []}
    if not text:
        return state
    lines = text.split("\n")
    current = {"heading": "", "level": 0, "paragraphs": []}
    buffer = []
    for line in lines:
        stripped = line.strip()
        heading = re.match(r"^(#{1,6})\s+(.*)$", stripped)
        if heading:
            if buffer:
                current["paragraphs"].append("\n".join(buffer).strip())
                buffer = []
            if current["paragraphs"] or current["heading"]:
                state["sections"].append(current)
            level = len(heading.group(1))
            title = heading.group(2).strip()
            if level == 1 and not state["title"] and not state["sections"]:
                state["title"] = title
                current = {"heading": "", "level": 1, "paragraphs": []}
            else:
                current = {"heading": title, "level": level, "paragraphs": []}
        elif not stripped:
            if buffer:
                current["paragraphs"].append("\n".join(buffer).strip())
                buffer = []
        else:
            buffer.append(line.rstrip())
    if buffer:
        current["paragraphs"].append("\n".join(buffer).strip())
    if current["paragraphs"] or current["heading"]:
        state["sections"].append(current)
    state["sections"] = [s for s in state["sections"] if s["heading"] or s["paragraphs"]]
    return state


def plain_sections(state):
    return [{"heading": s["heading"], "level": s["level"] or 2,
             "paragraphs": [p for p in s["paragraphs"] if p]} for s in state["sections"]]


def baseline_material(index):
    materials = index.get("materials") or []
    best, best_score = None, -1
    for mat in materials:
        name = (mat.get("path") or "").lower()
        score = 0
        if "manuscript" in name or "baseline" in name or "source" in name:
            score += 10
        if mat.get("kind") in ("md", "tex", "txt", "docx"):
            score += 5
        score += min(5, (mat.get("text_chars") or 0) // 2000)
        if score > best_score and (mat.get("text_chars") or 0) > 120:
            best, best_score = mat, score
    return best


def material_text(index, material_id, work=None):
    """Read a material's text from the persisted segment index (preferred) or index."""
    if not material_id:
        return ""
    if work is not None:
        segments = (K.jload(Path(work) / "segments" / (material_id + ".json"), {}) or {}).get(
            "segments") or []
        if segments:
            return "\n\n".join(s.get("text", "") for s in segments)
    for mat in index.get("materials") or []:
        if mat.get("material_id") == material_id:
            return mat.get("_text") or ""
    return ""


def baseline_text(index, work):
    mat = baseline_material(index)
    if not mat:
        return ""
    return material_text(index, mat.get("material_id"), work)


# ------------------------------------------------------------------ change application
def apply_changes(sections, changes):
    """Apply each change to the first matching paragraph. Returns (applied, missing)."""
    applied, missing = [], []
    for change in changes or []:
        original = K.norm_text(change.get("original_quote"))
        revised = str(change.get("revised_text") or "")
        target_section = str(change.get("section") or "").strip().lower()
        if not original:
            change["_status"] = "missing-original"
            missing.append(change)
            continue
        done = False
        order = list(range(len(sections)))
        if target_section:
            preferred = [i for i, s in enumerate(sections)
                         if target_section in (s.get("heading") or "").lower()
                         or (s.get("heading") or "").lower() in target_section]
            order = preferred + [i for i in order if i not in preferred]
        for idx in order:
            section = sections[idx]
            for p_idx, para in enumerate(section["paragraphs"]):
                if original in para:
                    section["paragraphs"][p_idx] = para.replace(original, revised, 1)
                    change["_status"] = "applied"
                    change["_applied_to"] = {"section": section["heading"],
                                             "paragraph_index": p_idx + 1,
                                             "paragraph_id": "P%d" % (p_idx + 1)}
                    applied.append(change)
                    done = True
                    break
            if done:
                break
        if not done:
            change["_status"] = "quote-not-found"
            missing.append(change)
    return applied, missing


def render_manuscript(state, applied, missing, version="v2"):
    lines = []
    if state.get("title"):
        lines += ["# " + state["title"], ""]
    for section in state["sections"]:
        if section.get("heading"):
            level = max(2, min(int(section.get("level") or 2), 6))
            lines += ["#" * level + " " + section["heading"], ""]
        for para in section.get("paragraphs") or []:
            if para.strip():
                lines += [para.strip(), ""]
    body = "\n".join(lines).strip() + "\n"
    return body


def render_response_letter(draft, ledger, changes, baseline_name, manuscript_title, version):
    lines = ["# Response to Reviewers", ""]
    lines.append("**Manuscript:** %s" % (manuscript_title or "(title not supplied)"))
    lines.append("")
    lines.append("**Revised version:** %s | **Baseline:** `%s` | "
                 "**Change records:** `change_locator.json`" % (version, baseline_name or "n/a"))
    lines.append("")
    lines.append("We thank the editor and the reviewers for their constructive comments. "
                 "Every comment is answered point by point below; each claimed change is "
                 "recorded in `change_locator.json` with the section, paragraph and the exact "
                 "original wording it replaces. Where a request could not be fully met with the "
                 "provided materials, this is stated explicitly rather than asserted.")
    lines.append("")
    counts = {}
    for entry in ledger:
        counts[entry.get("decision", "unanswered")] = counts.get(
            entry.get("decision", "unanswered"), 0) + 1
    summary = ", ".join("%s: %d" % (k, v) for k, v in sorted(counts.items()))
    lines += ["**Decision summary:** %s" % (summary or "none"), ""]
    lines += ["| Comment | Decision | Changes | Evidence status |", "|---|---|---|---|"]
    for entry in ledger:
        change_ids = ", ".join(entry.get("change_ids") or []) or "—"
        ev = entry.get("evidence_status") or "not required"
        lines.append("| %s | %s | %s | %s |" % (entry.get("comment_id"), entry.get("decision"),
                                                change_ids, ev))
    lines.append("")
    by_comment = {}
    for change in changes:
        by_comment.setdefault(str(change.get("comment_id")), []).append(change)
    for entry in ledger:
        lines += ["## Comment %s" % entry.get("comment_id"), ""]
        lines += ["**Reviewer comment (as supplied).** %s" % entry.get("comment_text", ""), ""]
        lines += ["**Decision: %s.**" % entry.get("decision", "unanswered"), ""]
        lines += ["**Response.** %s" % (entry.get("response") or
                                        "A point-by-point response has not been recorded yet."), ""]
        subs = entry.get("sub_requirements") or []
        if subs:
            lines += ["**Sub-requirements addressed:**", ""]
            for sub in subs:
                lines.append("- %s — %s (decision: %s)" % (sub.get("sub_id"),
                                                           sub.get("requirement"),
                                                           sub.get("decision")))
            lines.append("")
        record = by_comment.get(str(entry.get("comment_id"))) or []
        if record:
            lines += ["**Changes in the revised manuscript:**", ""]
            for change in record:
                loc = change.get("_applied_to") or {}
                where = "%s, %s" % (loc.get("section", change.get("section", "?")),
                                    loc.get("paragraph_id", "?")) if loc else \
                    "locator `%s`" % change.get("locator", "")
                if change.get("_status") != "applied":
                    lines.append("- %s — **not applied** (%s); see change_locator.json."
                                 % (change.get("change_id"), change.get("_status")))
                    continue
                lines.append("- %s (%s): replaced %s with %s" % (
                    change.get("change_id"), where,
                    "`%s`" % K.clip(change.get("original_quote"), 120),
                    "`%s`" % K.clip(change.get("revised_text"), 120)))
            lines.append("")
        ev_items = entry.get("evidence_items") or []
        if ev_items:
            lines += ["**Evidence status:**", ""]
            for item in ev_items:
                lines.append("- %s — status: %s%s" % (
                    item.get("need"), item.get("status"),
                    "; " + item.get("alternative") if item.get("alternative") else ""))
            lines.append("")
    lines += ["## Version consistency", "",
              "The revised manuscript, this letter and `change_locator.json` all refer to "
              "version **%s** of the baseline `%s`. Changes marked *not applied* are absent "
              "from the revised manuscript and are listed in `evidence_pending.md` for human "
              "follow-up." % (version, baseline_name or "n/a"), ""]
    return "\n".join(lines).strip() + "\n"


def build_evidence_pending(missing, ledger):
    lines = ["# Evidence and changes still pending", "",
             "This file lists every claim that could not be backed by the supplied materials. "
             "Nothing here is asserted as done in the response letter.", ""]
    lines += ["| ID | Comment | Item | Status | What is needed / alternative |",
              "|---|---|---|---|---|"]
    idx = 0
    for entry in ledger:
        for item in entry.get("evidence_items") or []:
            if item.get("status") in ("unavailable", "to_collect", "not_available"):
                idx += 1
                lines.append("| E%d | %s | %s | %s | %s |" % (
                    idx, entry.get("comment_id"), item.get("need"),
                    item.get("status"), item.get("alternative") or item.get("note") or "—"))
    for change in missing:
        idx += 1
        lines.append("| E%d | %s | %s | change-not-applied | %s |" % (
            idx, change.get("comment_id", "—"), change.get("change_id", "—"),
            change.get("_status", "original text not found in baseline")))
    if idx == 0:
        lines.append("| — | — | — | none | All requested changes were anchored to the baseline; "
                     "no experiment or external data was claimed. |")
    lines += ["", "## Honesty boundary", "",
              "- The baseline supplied by the organizer is a summary, not the complete original "
              "manuscript; only that baseline was revised.",
              "- No new experiment, dataset, reference or reviewer wording is invented.",
              "- Requests requiring new experiments are marked `unavailable` with the reason and "
              "a concrete alternative (e.g. re-analysis of supplied data, wording caveat).", ""]
    return "\n".join(lines) + "\n"


# ------------------------------------------------------------------ index / init
def build_index(args):
    case = K.jload(Path(args.input) / "case.json", None)
    case = case if isinstance(case, dict) else {}
    materials, notes = K.discover(args.input)
    work = Path(args.work)
    seg_count = 0
    for mat in materials:
        segments = K.segment_document(mat.get("_text") or "", mat)
        mat["_segments"] = segments
        seg_count += len(segments)
        try:
            K.jdump(work / "segments" / (mat["material_id"] + ".json"),
                    {"material_id": mat["material_id"], "path": mat["path"],
                     "segments": segments})
        except Exception:
            notes.append("could not persist segments for %s" % mat.get("path"))
    items = K.workorder_items(case, materials)
    manifest = {k: mat.get(k) for k, mat in
                [(m["material_id"], m) for m in materials]}
    index = {
        "skill": NAME, "version": VERSION,
        "case_id": str(case.get("case_id") or case.get("id") or ""),
        "input_dir": str(Path(args.input).resolve()),
        "case": {k: v for k, v in case.items() if k not in ("materials",)},
        "materials": [{k: v for k, v in m.items() if not k.startswith("_")}
                      for m in materials],
        "counts": {"materials": len(materials), "segments": seg_count,
                   "workorder_items": len(items)},
        "workorder": [{"item_id": i["item_id"], "text": i["text"], "source": i["source"]}
                      for i in items],
        "notes": notes,
    }
    manifest = None
    state = parse_manuscript(material_text(index, (baseline_material(index) or {}).get(
        "material_id"), work))
    index["baseline"] = {"material_id": (baseline_material(index) or {}).get("material_id"),
                         "title": state.get("title"),
                         "sections": [s["heading"] for s in state["sections"]],
                         "paragraphs": sum(len(s["paragraphs"]) for s in state["sections"])}
    K.jdump(work / "index.json", index)
    return case, materials, index, notes


def partial_payload(case, index, notes):
    payload = K.base_envelope(index.get("case_id", ""), "partial",
                              degradations=list(notes) + ["partial scaffold written by init; "
                                                          "work/draft.json not yet built"])
    payload.update({
        "deliverable": "", "preserved_facts": [], "evidence_map": [], "change_log": [],
        "workorder_execution": [], "comments": [],
        "result": {"deliverables": {}, "counts": {}, "baseline": index.get("baseline"),
                   "workorder": index.get("workorder")},
        "sources": K.sources_from(index),
        "skill": {"name": NAME, "version": VERSION},
    })
    return payload


def cmd_init(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    case, materials, index, notes = build_index(args)
    status = "input_error" if not materials else "partial"
    payload = partial_payload(case, index, notes)
    payload["status"] = status
    if not materials:
        payload["errors"].append("no input materials discovered under %s" % args.input)
    K.finalize_result(out, payload, case.get("output_contract"), index.get("case_id"))
    print(json.dumps({
        "ok": True, "command": "init", "case_id": index["case_id"], "status": status,
        "materials": [{"material_id": m["material_id"], "path": m["path"],
                       "kind": m["kind"], "text_chars": m["text_chars"]}
                      for m in materials],
        "baseline": index.get("baseline"),
        "workorder": index.get("workorder"),
        "next": "run show --material mN, read baseline + comments, write work/draft.json, "
                "then check and build",
        "notes": notes,
    }, ensure_ascii=False, indent=2))
    return 0


def cmd_show(args):
    work = Path(args.work)
    index = K.jload(work / "index.json", {}) or {}
    if not args.material:
        print(json.dumps({
            "case_id": index.get("case_id"), "counts": index.get("counts"),
            "baseline": index.get("baseline"),
            "workorder": index.get("workorder"),
            "materials": [{k: m.get(k) for k in ("material_id", "path", "kind", "bytes",
                                                 "text_chars", "notes")}
                          for m in index.get("materials", [])],
        }, ensure_ascii=False, indent=2))
        return 0
    target = next((m for m in index.get("materials", [])
                   if m.get("material_id") == args.material), None)
    if not target:
        print(json.dumps({"error": "unknown material: %s" % args.material}, ensure_ascii=False))
        return 0
    segments = (K.jload(work / "segments" / (args.material + ".json"), {}) or {}).get(
        "segments") or []
    shown = 0
    for seg in segments:
        if args.grep and not re.search(args.grep, seg.get("text", ""), re.I):
            continue
        print("=== [%s] %s" % (seg.get("locator"), target.get("path")))
        print(seg.get("text"))
        print()
        shown += 1
        if args.limit and shown >= args.limit:
            break
    if shown == 0:
        print(json.dumps({"material_id": args.material, "path": target.get("path"),
                          "segments": 0, "notes": target.get("notes")}, ensure_ascii=False))
    return 0


def cmd_extract(args):
    work = Path(args.work)
    index = K.jload(work / "index.json", {}) or {}
    harvest = {"numbers": [], "dois": [], "years": [], "citations": [],
               "review_comments": []}
    for mat in index.get("materials") or []:
        mid = mat["material_id"]
        segments = (K.jload(work / "segments" / (mid + ".json"), {}) or {}).get(
            "segments") or []
        for key, values in K.harvest(segments, mid).items():
            harvest.setdefault(key, []).extend(values)
        if any(tag in (mat.get("path") or "").lower()
               for tag in ("comment", "review", "workorder", "target")):
            harvest["review_comments"].extend(
                K.parse_comments(mat.get("_text") or "", mat.get("path") or ""))
    for item in index.get("workorder") or []:
        harvest["review_comments"].append(item)
    K.jdump(work / "candidates.json", harvest)
    print(json.dumps({"ok": True, "command": "extract",
                      "saved_to": str(work / "candidates.json"),
                      "counts": {k: len(v) for k, v in harvest.items()},
                      "note": "candidates only; copy the ones you actually use into draft.json "
                              "with their locator and verbatim quote",
                      "sample": {k: v[:3] for k, v in harvest.items()}},
                     ensure_ascii=False, indent=2))
    return 0


# ------------------------------------------------------------------ checks
def load_draft(args):
    path = Path(args.draft) if getattr(args, "draft", None) else Path(args.work) / "draft.json"
    draft = K.jload(path, None)
    return (draft if isinstance(draft, dict) else None), str(path)


def load_corpus(work, index):
    full = []
    for mat in index.get("materials") or []:
        segs = (K.jload(Path(work) / "segments" / (mat["material_id"] + ".json"),
                        {}) or {}).get("segments") or []
        full.extend(seg.get("text", "") for seg in segs)
    return K.norm_text("\n".join(full))


def run_checks(args, index, draft, baseline_state):
    corpus = load_corpus(args.work, index)
    fails, warnings, details = [], [], {}

    def fail(code, message):
        fails.append({"code": code, "message": message})

    if draft is None:
        fail("draft_missing", "work/draft.json not found; build will emit a degraded deliverable")
        return {"passed": False, "fails": fails, "warnings": warnings, "counts": {},
                "corpus_chars": len(corpus)}

    comments = draft.get("comments") or []
    changes = draft.get("changes") or []
    required = [str(i.get("item_id")) for i in index.get("workorder") or []]
    seen_ids = [str(c.get("comment_id")) for c in comments]
    missing_ids = [i for i in required if i not in seen_ids]
    if missing_ids:
        fail("comment_coverage", "workorder comments without a ledger entry: %s"
             % ", ".join(missing_ids))
    counts = {"comments": len(comments), "sub_requirements": 0, "changes": len(changes),
              "changes_applied": 0, "changes_unanchored": 0, "facts": 0, "evidence": 0}
    change_ids = {str(c.get("change_id")) for c in changes}
    for comment in comments:
        cid = comment.get("comment_id")
        decision = str(comment.get("decision") or "").lower()
        if decision not in DECISIONS:
            fail("decision_vocabulary", "%s decision %r not in %s"
                 % (cid, comment.get("decision"), sorted(DECISIONS)))
        if len(str(comment.get("response") or "")) < 80:
            fail("response_short", "%s response under 80 characters (empty acknowledgement?)" % cid)
        subs = comment.get("sub_requirements") or []
        counts["sub_requirements"] += len(subs)
        if not subs:
            fail("sub_requirements", "%s has no sub-requirement breakdown" % cid)
        for sub in subs:
            if str(sub.get("decision") or "").lower() not in DECISIONS:
                fail("sub_decision", "%s sub-requirement %r has no valid decision"
                     % (cid, sub.get("sub_id")))
        for cid_ref in comment.get("change_ids") or []:
            if str(cid_ref) not in change_ids:
                fail("dangling_change", "%s references missing change %s" % (cid, cid_ref))
        if comment.get("type") and str(comment.get("type")).lower() not in TYPES:
            warnings.append("%s type %r is not one of %s" % (cid, comment.get("type"),
                                                             sorted(TYPES)))
    for change in changes:
        if not K.quote_hit(change.get("original_quote"), corpus)["hit"]:
            fail("change_quote", "%s original_quote is not verbatim in the baseline"
                 % change.get("change_id"))
        if not str(change.get("revised_text") or "").strip():
            fail("change_text", "%s has no revised_text" % change.get("change_id"))
        if K.norm_text(change.get("original_quote")) == K.norm_text(change.get("revised_text")):
            fail("change_noop", "%s revised_text equals original_quote" % change.get("change_id"))
        if str(change.get("comment_id")) not in {str(c.get("comment_id")) for c in comments}:
            fail("change_orphan", "%s points to unknown comment %s"
                 % (change.get("change_id"), change.get("comment_id")))
    for fact in draft.get("preserved_facts") or []:
        counts["facts"] += 1
        quote = fact.get("quote")
        if not K.quote_hit(quote, corpus)["hit"]:
            fail("fact_quote", "%s quote not verbatim in materials" % fact.get("fact_id"))
        if fact.get("value") and K.norm_text(fact.get("value")) not in K.norm_text(quote):
            fail("fact_value", "%s value %r absent from its own quote"
                 % (fact.get("fact_id"), fact.get("value")))
    for ev in draft.get("evidence_map") or []:
        counts["evidence"] += 1
        if not K.quote_hit(ev.get("quote"), corpus)["hit"]:
            fail("evidence_quote", "%s evidence quote not verbatim" % ev.get("claim_id"))
    sections = {s.get("heading", "").lower() for s in baseline_state.get("sections") or []}
    if sections and draft.get("manuscript_sections"):
        lost = [s for s in sections if s and s not in
                {str(x).lower() for x in draft.get("manuscript_sections")}]
        if lost:
            warnings.append("baseline sections not listed as revised: %s" % ", ".join(lost[:5]))
    return {"passed": not fails, "fails": fails, "warnings": warnings, "counts": counts,
            "corpus_chars": len(corpus)}


def print_report(report):
    print(json.dumps({"passed": report["passed"], "fail_count": len(report["fails"]),
                      "warning_count": len(report["warnings"]),
                      "counts": report.get("counts"),
                      "fails": report["fails"],
                      "warnings": report["warnings"]}, ensure_ascii=False, indent=2))


def cmd_check(args):
    work = Path(args.work)
    index = K.jload(work / "index.json", {}) or {}
    if not index:
        index = {"materials": [], "workorder": [], "case_id": ""}
    draft, path = load_draft(args)
    baseline = parse_manuscript(baseline_text(index, work))
    report = run_checks(args, index, draft, baseline)
    report["draft_path"] = path
    K.jdump(work / "check_report.json", report)
    print_report(report)
    return 0


# ------------------------------------------------------------------ build
def fact_rows(draft, corpus):
    rows = []
    for idx, fact in enumerate(draft.get("preserved_facts") or [], start=1):
        quote = str(fact.get("quote") or "")
        rows.append({
            "fact_id": fact.get("fact_id") or "F%d" % idx,
            "value": fact.get("value"), "unit": fact.get("unit", ""),
            "source_id": fact.get("source_id") or fact.get("material_id") or "",
            "locator": fact.get("locator", ""), "quote": quote,
            "status": "preserved" if K.quote_hit(quote, corpus)["hit"] else "flagged",
        })
    return rows


def cmd_build(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    errors, degradations = [], []
    index = K.jload(work / "index.json", {}) or {}
    if not index:
        degradations.append("index.json absent; running init implicitly")
        try:
            case, _materials, index, notes = build_index(args)
            degradations.extend(notes)
        except Exception as exc:
            errors.append("implicit init failed: %s" % exc)
            index = {"materials": [], "workorder": [], "case_id": ""}
    case = K.jload(Path(args.input) / "case.json", {}) or {}
    if not isinstance(case, dict):
        case = {}
        errors.append("case.json is not a JSON object")
    draft, draft_path = load_draft(args)
    if draft is None:
        degradations.append("work/draft.json missing at %s; produced a degraded but honest "
                            "deliverable" % draft_path)
        draft = {}
    corpus = load_corpus(work, index)
    baseline_mat = baseline_material(index)
    baseline_state = parse_manuscript(baseline_text(index, work))
    sections = plain_sections(baseline_state)
    if not sections:
        sections = [{"heading": "", "level": 2,
                     "paragraphs": [(baseline_mat or {}).get("_text") or ""]}]
        degradations.append("baseline manuscript could not be parsed into sections")
    comments = draft.get("comments") or []
    changes = draft.get("changes") or []
    missing_ids = [str(i.get("item_id")) for i in index.get("workorder") or []
                   if str(i.get("item_id")) not in {str(c.get("comment_id"))
                                                    for c in comments}]
    applied, missing = apply_changes(sections, changes)
    version = str(draft.get("version") or "v2")
    title = draft.get("title") or baseline_state.get("title") or ""
    manuscript = render_manuscript({"title": title, "sections": sections},
                                   applied, missing, version)
    ledger, evidence_items = [], []
    for idx, comment in enumerate(comments, start=1):
        cid = str(comment.get("comment_id") or "C%d" % idx)
        evs = comment.get("evidence") or []
        entry_evs = []
        for ev_idx, ev in enumerate(evs, start=1):
            item = {"evidence_id": "E%s.%d" % (cid, ev_idx),
                    "need": ev.get("need") or ev.get("requirement") or "evidence request",
                    "status": ev.get("status") or "unavailable",
                    "source": ev.get("source", ""),
                    "alternative": ev.get("alternative", "")}
            entry_evs.append(item)
            evidence_items.append({"comment_id": cid, "need": item["need"],
                                   "status": item["status"],
                                   "alternative": item["alternative"],
                                   "source": item["source"]})
        change_ids = []
        for change in changes:
            if str(change.get("comment_id")) == cid:
                change_ids.append(change.get("change_id"))
        ledger.append({
            "comment_id": cid,
            "comment_text": comment.get("comment_text", ""),
            "type": comment.get("type", "other"),
            "severity": comment.get("severity", "minor"),
            "decision": str(comment.get("decision") or "clarify").lower(),
            "tone": comment.get("tone", "clarify"),
            "response": comment.get("response", ""),
            "sub_requirements": comment.get("sub_requirements") or [],
            "change_ids": change_ids,
            "evidence_items": entry_evs,
            "evidence_status": ("pending: " + ", ".join(e["status"] for e in entry_evs))
            if entry_evs else "not required",
            "status": "answered" if str(comment.get("response") or "").strip() else "unanswered",
        })
    for item_id in missing_ids:
        source = next((i for i in index.get("workorder") or []
                       if str(i.get("item_id")) == item_id), {})
        ledger.append({
            "comment_id": item_id, "comment_text": source.get("text", ""),
            "type": "other", "severity": "minor", "decision": "clarify", "tone": "clarify",
            "response": "", "sub_requirements": [], "change_ids": [],
            "evidence_items": [], "evidence_status": "unprocessed",
            "status": "unanswered",
        })
        degradations.append("workorder comment %s has no response in the draft" % item_id)
    changes_json = []
    for change in changes:
        loc = change.get("_applied_to") or {}
        changes_json.append({
            "change_id": change.get("change_id"), "comment_id": change.get("comment_id"),
            "section": loc.get("section") or change.get("section", ""),
            "paragraph_id": loc.get("paragraph_id") or "",
            "locator": "section=%s;paragraph=%s;baseline=%s" % (
                loc.get("section", ""), loc.get("paragraph_id", ""),
                (baseline_mat or {}).get("path", "")),
            "original_quote": change.get("original_quote"),
            "revised_quote": change.get("revised_text"),
            "basis": change.get("basis", ""),
            "applied": change.get("_status") == "applied",
            "status": change.get("_status", "not-applied"),
        })
    change_log = []
    for change in changes:
        change_log.append({
            "id": change.get("change_id"),
            "action": "rewrite",
            "original_quote": change.get("original_quote"),
            "revised_quote": change.get("revised_text"),
            "reason": change.get("basis") or "response to comment %s"
                      % change.get("comment_id"),
            "locator": change.get("_applied_to", {}).get("section", "") + "#" +
                       change.get("_applied_to", {}).get("paragraph_id", ""),
            "status": change.get("_status", "not-applied"),
        })
    facts = fact_rows(draft, corpus)
    evidence_map = []
    for ev in draft.get("evidence_map") or []:
        item = dict(ev)
        item["hit"] = K.quote_hit(ev.get("quote"), corpus)["hit"]
        evidence_map.append(item)
    if not evidence_map:
        for change in changes:
            evidence_map.append({"claim_id": "A" + str(change.get("change_id")),
                                 "claim": "Revised wording for comment %s"
                                          % change.get("comment_id"),
                                 "source_id": (baseline_mat or {}).get("material_id", ""),
                                 "locator": change.get("_applied_to", {}).get("section", ""),
                                 "quote": change.get("original_quote"),
                                 "kind": "direct"})
    workorder_execution = []
    for item in index.get("workorder") or []:
        cid = str(item.get("item_id"))
        entry = next((x for x in ledger if x["comment_id"] == cid), None)
        workorder_execution.append({
            "target_id": cid, "requirement": item.get("text", ""),
            "status": "done" if entry and entry["status"] == "answered" else "missing",
            "decision": entry["decision"] if entry else None,
            "change_ids": entry["change_ids"] if entry else [],
        })
    report = run_checks(args, index, draft, baseline_state) if draft else {
        "passed": False, "fails": [{"code": "draft_missing", "message": "no draft"}],
        "warnings": [], "counts": {}}
    response_letter = render_response_letter(draft, ledger, changes,
                                             (baseline_mat or {}).get("path", ""),
                                             title, version)
    evidence_md = build_evidence_pending(missing, ledger)
    deliverables = {}

    def write_text(name, text, key):
        try:
            (out / name).write_text(text, encoding="utf-8")
            deliverables[key] = name
        except Exception as exc:
            errors.append("%s write failed: %s" % (name, exc))

    def write_json(name, payload, key):
        try:
            K.jdump(out / name, payload)
            deliverables[key] = name
        except Exception as exc:
            errors.append("%s write failed: %s" % (name, exc))

    write_text(DELIVERABLES["revised_manuscript"], manuscript, "revised_manuscript")
    write_text(DELIVERABLES["response_letter"], response_letter, "response_letter")
    write_json(DELIVERABLES["comment_ledger"], ledger, "comment_ledger")
    write_json(DELIVERABLES["change_locator"], changes_json, "change_locator")
    write_text(DELIVERABLES["evidence_pending"], evidence_md, "evidence_pending")
    write_json("preserved_facts.json", facts, "preserved_facts")
    write_json("evidence_map.json", evidence_map, "evidence_map")
    write_json("change_log.json", change_log, "change_log")
    status = "ok"
    if not draft:
        status = "partial"
    if missing_ids or missing:
        status = "partial"
    if not (index.get("materials") or []):
        status = "input_error"
        errors.append("no input materials discovered")
    if not changes:
        status = "partial"
        degradations.append("no change records supplied; revised manuscript mirrors the baseline")
    if report.get("fails"):
        status = "partial" if status == "ok" else status
        degradations.append("%d mechanical check failure(s); see check_report.json"
                            % len(report["fails"]))
    counts = {
        "comments": len(comments), "workorder_comments": len(index.get("workorder") or []),
        "sub_requirements": sum(len(c.get("sub_requirements") or []) for c in comments),
        "decisions": {d: sum(1 for c in ledger if c["decision"] == d) for d in sorted(DECISIONS)},
        "changes": len(changes), "changes_applied": len(applied),
        "changes_unapplied": len(missing), "preserved_facts": len(facts),
        "evidence_map": len(evidence_map), "evidence_pending": len(
            [e for e in evidence_items if e["status"] in ("unavailable", "to_collect")]),
        "sections": len(sections),
        "manuscript_chars": len(manuscript.strip()),
    }
    base = K.base_envelope(index.get("case_id", ""), status, errors, degradations)
    base.update({
        "deliverable": DELIVERABLES["revised_manuscript"],
        "deliverable_path": DELIVERABLES["revised_manuscript"],
        "revised_manuscript": deliverables.get("revised_manuscript", ""),
        "response_letter": deliverables.get("response_letter", ""),
        "comment_ledger": ledger,
        "comment_ledger_path": deliverables.get("comment_ledger", ""),
        "change_locator": changes_json,
        "change_locator_path": deliverables.get("change_locator", ""),
        "evidence_pending": deliverables.get("evidence_pending", ""),
        "comments": ledger,
        "preserved_facts": facts,
        "evidence_map": evidence_map,
        "change_log": change_log,
        "workorder_execution": workorder_execution,
        "manuscript": manuscript,
        "result": {
            "deliverables": deliverables,
            "baseline": index.get("baseline"),
            "decisions": {entry["comment_id"]: entry["decision"] for entry in ledger},
            "counts": counts,
            "workorder_execution": workorder_execution,
            "version": version,
            "gaps": (draft.get("gaps") or []),
        },
        "sources": K.sources_from(index),
        "pending_human": draft.get("pending_human") or [],
        "uncertainty": draft.get("uncertainties") or draft.get("uncertainty") or [],
        "uncertainties": draft.get("uncertainties") or draft.get("uncertainty") or [],
        "self_check": {"passed": report.get("passed"),
                       "fail_count": len(report.get("fails") or []),
                       "warning_count": len(report.get("warnings") or []),
                       "counts": report.get("counts")},
        "changes": [{"type": "build", "detail": "wrote %d deliverable(s)" % len(deliverables)}],
        "deliverables": deliverables,
        "skill": {"name": NAME, "version": VERSION},
        "_artifact_map": ARTIFACT_MAP,
    })
    final = K.finalize_result(out, base, case.get("output_contract"), index.get("case_id"))
    print(json.dumps({
        "ok": True, "command": "build", "status": status, "case_id": final.get("case_id"),
        "deliverables": deliverables, "counts": counts,
        "check_passed": report.get("passed"), "check_fails": report.get("fails"),
        "errors": errors, "degradations": degradations,
    }, ensure_ascii=False, indent=2))
    return 0


# ------------------------------------------------------------------ cli
def main(argv):
    def sub(fn, helptext, options=None):
        return {"run": fn, "help": helptext, "options": options or {}}

    handlers = {
        "init": sub(cmd_init, "index materials and write a partial result.json"),
        "show": sub(cmd_show, "print material segments with locators",
                    {"--material": {"default": None, "help": "material id (m1, m2, ...)"},
                     "--grep": {"default": None, "help": "regex filter"},
                     "--limit": {"type": int, "default": 0, "help": "max segments"}}),
        "extract": sub(cmd_extract, "harvest candidate numbers, DOIs and comments"),
        "check": sub(cmd_check, "validate work/draft.json against the baseline",
                     {"--draft": {"default": None, "help": "draft path"}}),
        "build": sub(cmd_build, "render manuscript, response letter, ledger, locator, result",
                     {"--draft": {"default": None, "help": "draft path"}}),
    }
    return K.run_cli(NAME, handlers, argv,
                     "Reviewer response and traceable manuscript revision. "
                     "Flow: init -> show -> write work/draft.json -> check -> build.")


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except Exception:
        import traceback
        try:
            sys.stderr.write(traceback.format_exc())
        except Exception:
            pass
    sys.exit(0)

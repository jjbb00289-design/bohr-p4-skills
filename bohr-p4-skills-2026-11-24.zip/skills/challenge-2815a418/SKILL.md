---
name: review-revision
description: 审稿回复与论文修改 — 把「指定版本基线稿件 + 审稿意见清单」处理成可提交的修改稿、逐条回复信、意见台账、逐处修改定位与未到位证据清单。每条意见拆出子要求并逐条给出 decision；每处「已修改」都落到基线原句并可在改后稿中复核；无法补做的实验/数据明确标注，绝不编造。
version: 1.0.0
---

# review-revision（审稿回复与论文修改）

## 1. 用途与适用条件

**用途**：受控返修。输入是组织方给的**指定版本基线稿件**（通常是摘要/分节稿）与**审稿意见清单**（可能是摘要），输出五件套：

| 产物 | 文件 | 作用 |
|---|---|---|
| 修改稿（可编辑） | `revised_manuscript.md` | 把采纳的修改真实应用回基线原段落 |
| 逐条回复信 | `response_letter.md` | 每条意见 → decision → 回应 → 改动编号与位置 |
| 意见台账 | `comment_ledger.json` | 意见/子要求/decision/改动/证据状态的可机读总账 |
| 修改定位表 | `change_locator.json` | 每处改动：原句 → 改后句 → 章节/段落/基线文件 |
| 未到位证据清单 | `evidence_pending.md` | 需要补实验/补数据/补文献但做不了的项 + 原因 + 替代 |

**适用**：期刊/会议返修回复（Response to Reviewers）、编辑工单式逐条改稿、多轮返修台账。**不适用**：需要真实补做实验、需要联网核对评审全文、需要重写整篇论文（本 Skill 只在指定基线上做受控修改）。

## 2. 硬边界（题面明确要求，违反即掉分）

1. `materials/manuscript-baseline.md` 是**组织方基线摘要**，不是完整原稿；只能修订这个基线，不得宣称已对整篇全文完成返修。
2. `materials/reviewer-comments.md` 是**意见摘要**，不是审稿人逐字全文；不得冒称「审稿人原话」。
3. 公开论文/报告链接只是来源身份，**未联网核验**；不得声称已核对原评审。
4. 不得编造实验、数据、DOI、参考文献、作者回复或「编辑部已接收」。
5. 需要补实验的意见：写 `unavailable`（原因 + 替代，如基于现有数据的再分析/措辞降级），**不能仅声明缺材料就跳过可执行修改**。
6. 意见与稿件冲突、意见本身有误：在台账写 `clarify`/`invalid` + 理由，不回怼、不无原则顺从。

## 3. 运行时契约

- 输入：`/input/case.json`（含 `case_id`、`task_instruction`、`output_contract`）、`/input/task.md`、`/input/` 下材料（md/txt/json/csv/pdf/docx）。
- 工作区：`/app/work`；产物：`/app/output/`，必须含 `result.json`（**原样回填 output_contract 每个键**，保留 `case_id`）。
- 纯 Python 标准库、不联网、不依赖当前目录；**退出码恒 0**；先写 partial 再 finalize。
- 预算：64 次模型请求 / 900 秒；`init` 后应尽快落盘 partial，时间接近上限立即 finalize。

## 4. 五命令主路径（必须按顺序，脚本不代替你阅读）

```bash
python scripts/main.py init      # 扫材料、给每段编号（locator）、写 work/index.json + partial result.json
python scripts/main.py show      # 材料清单 + 基线章节 + workorder 列表
python scripts/main.py show --material m1            # 读基线全文（带 para.N 定位）
python scripts/main.py show --material m3 --grep "Comment"   # 读意见
python scripts/main.py extract   # 候选数字/DOI/年份/意见条目（只是候选）
#  ← 你（Agent）亲自读材料，写 /app/work/draft.json（见 §5）
python scripts/main.py check     # 机械校验：quote 命中、子要求、decision、改动锚定、事实保真
python scripts/main.py build     # 生成五件套 + 三张表 + result.json（无条件 finalize）
```

**脚本不会代替你阅读理解**。只跑 `build` 不写 `draft.json` 会得到 `status=partial` 的降级交付（有产物但无实质回应），禁止把它当成完成任务。

## 5. `work/draft.json` schema（Agent 写这个）

```json
{
  "case_id": "<原样>",
  "version": "v2",
  "title": "稿件标题",
  "comments": [
    {
      "comment_id": "R1.1",
      "comment_text": "意见（材料里能逐字复制就逐字复制）",
      "type": "method|data|writing|format|ethics|other",
      "severity": "major|minor",
      "decision": "accept|partial|reject|clarify|invalid",
      "tone": "accept|clarify|polite_refute|appeal",
      "response": "≥80 字符的实质回应：改了什么/为什么/证据在哪",
      "sub_requirements": [
        {"sub_id": "R1.1a", "requirement": "一条意见里的一个子要求",
         "decision": "accept|partial|reject|clarify|invalid", "change_ids": ["CH1"]}
      ],
      "change_ids": ["CH1"],
      "evidence": [
        {"need": "需要补的实验/数据/文献", "status": "provided|unavailable|to_collect",
         "source": "材料内来源编号或 locator", "alternative": "无法补做时的替代说明"}
      ]
    }
  ],
  "changes": [
    {"change_id": "CH1", "comment_id": "R1.1", "section": "Methods",
     "original_quote": "基线里逐字存在的原句（必须能在材料中命中）",
     "revised_text": "改后文字（≠原句）", "basis": "依据/为什么这样改"}
  ],
  "preserved_facts": [
    {"fact_id": "F1", "value": "1.36", "unit": "V", "source_id": "m1",
     "locator": "para.9", "quote": "含该数值的逐字原句"}
  ],
  "evidence_map": [
    {"claim_id": "A1", "claim": "修改稿中的事实性论断", "source_id": "m1",
     "locator": "para.9", "quote": "逐字原句", "kind": "direct|inferred|undetermined"}
  ],
  "uncertainties": ["..."],
  "pending_human": ["..."],
  "gaps": ["..."]
}
```

写稿要点：

- **一条意见 = 一条 ledger**；一条意见含多个要求时，`sub_requirements` 逐条拆、逐条给 decision。漏子要求 = 「答得全」掉档。
- `changes[]` 的 `original_quote` 必须是基线**逐字**片段（check 会核对）；`revised_text` 是应用后的文字，脚本会把它替换进对应段落。找不到原句的改动会被标 `quote-not-found`，不得在回复信里声称「已修改」。
- 数字/单位/样本量/引用编号改动前后必须一致；用 `preserved_facts` 登记并在正文保留原值。
- 回复信不是空话：accept → 改了什么、在哪；partial → 做了哪部分、哪部分做不了、为什么；reject/clarify → 有依据的说明与替代。

## 6. 证据与定位规范

- 段落定位：`show` 输出的 `para.N`（跨页 PDF 为 `p.X#paraN`）；表格 `T2 r3 c2`；图 `fig1b`；章节名 + 段落号（`Methods, para 2`）。
- 每条关键结论：`source_id + locator + 逐字 quote`。quote 只做空白规整，不做改写/拼接；跨段引用用省略号 `…` 连接且每段 ≥8 字符可命中。
- `change_locator.json` 由脚本生成：`section + paragraph_id + baseline 路径 + original_quote + revised_quote + applied`。回复信只引用这里 applied 的改动编号。
- 多轮返修：`version` 字段写清（v2/v3），回复信、修改稿、定位表三方版本必须一致；上一轮承诺在台账里保留 `status`。

## 7. 输出（build 生成）

```
/app/output/
  result.json                 # 契约全回填 + case_id + status + sources + errors/degradations
  revised_manuscript.md       # 可编辑修改稿（基线章节结构保留）
  response_letter.md          # 逐条回复信（含 decision 汇总表 + 每条的改动与证据状态）
  comment_ledger.json         # [comment_id, type, severity, decision, tone, sub_requirements, change_ids, evidence]
  change_locator.json         # [change_id, comment_id, section, paragraph_id, locator, original_quote, revised_quote, applied]
  evidence_pending.md         # 未到位证据 + 缺原句改动 + 诚实边界
  preserved_facts.json        # 数字/单位事实表（带 locator + 逐字 quote）
  evidence_map.json           # 修改稿论断 → 基线证据
  change_log.json             # 全部改动留痕（action/original/revised/reason/locator）
```

`result.json` 根字段：`case_id`、`status`（`ok|partial|insufficient_evidence|input_error`）、`deliverable`、`revised_manuscript`、`response_letter`、`comment_ledger`、`change_locator`、`evidence_pending`、`preserved_facts`、`evidence_map`、`change_log`、`workorder_execution`、`result`、`sources`、`uncertainty`、`pending_human`；另附 `self_check` 与计数。`output_contract` 其他键按原键名回填（缺值 `null` 并写 `degradations`）。

## 8. `check` 会拦住什么

| 检查 | 失败含义 |
|---|---|
| `comment_coverage` | workorder/意见清单里有条目没进台账 |
| `decision_vocabulary` | decision 用了 `accept/partial/reject/clarify/invalid` 之外的值 |
| `response_short` | 回应 <80 字符，疑似空话 |
| `sub_requirements` | 没有拆子要求（一条意见只给一句结论） |
| `change_quote` | `original_quote` 在基线里找不到（声称改了但原文对不上） |
| `change_noop` | `revised_text` 与原句相同（假改动） |
| `change_orphan` / `dangling_change` | 改动挂在不存在的意见上，或正文引用了不存在的改动编号 |
| `fact_quote` / `fact_value` | 数字事实的 quote 不逐字，或数值不在自己的 quote 里 |

## 9. 降级与异常处理（exit 0 优先）

| 情况 | 行为 |
|---|---|
| `case.json` 坏/缺失 | `status=input_error`，写 `errors`，仍产出最小交付与 `result.json` |
| 材料为空/缺基线 | `status=insufficient_evidence` 或 `input_error`，`pending_human` 写清需要什么 |
| 无 `draft.json` | build 产出降级五件套：修改稿=基线 + 未处理标注，回复信=逐条「未处理」，`status=partial` |
| 意见清单缺失 | 从材料中 `Comment N` / `R1.1` 模式抽取；抽不到则 `pending_human` |
| 某处原句找不到 | 不改该段，`change_locator` 标 `not-applied`，进 `evidence_pending.md` |
| 需要补实验 | `evidence.status=unavailable` + 原因 + 替代，**不伪造结果** |
| 超时/中断 | 先写 partial `result.json`，再补产物；不得非零退出 |

## 10. 提交前自检

- [ ] `init` 后 `${work}/index.json` 有基线章节与 workorder 条目。
- [ ] `check` 输出 `passed=true` 或已知剩下的 fail 都已解释。
- [ ] `build` 后五件套 + 三张表存在且非空；`result.json` 契约键零缺失。
- [ ] 回复信每个「已修改」都能在 `change_locator.json` 找到 `applied=true`。
- [ ] `preserved_facts` 每条的 value/unit 与 quote 一致，正文未改数字。
- [ ] 未做实验/未核对全文的边界写在 `evidence_pending.md` 与 `uncertainty`。
- [ ] 同一输入跑两次，`result.json` 结构与产物一致。

## 11. 最小示例（示例，非正式案例结果）

```bash
python scripts/main.py init --input ./localtest/input --work /tmp/w --output /tmp/o
python scripts/main.py show --material m1
# 写 /tmp/w/draft.json：comments=[{comment_id:"C1.1", decision:"accept",
#   sub_requirements:[{sub_id:"C1.1a", requirement:"补充 XPS 拟合方法", decision:"accept",
#   change_ids:["CH1"]}], response:"...", change_ids:["CH1"], evidence:[]}],
#   changes=[{change_id:"CH1", comment_id:"C1.1", section:"Methods",
#   original_quote:"<基线逐字原句>", revised_text:"<改后>", basis:"回应 C1.1"}]
python scripts/main.py check
python scripts/main.py build     # → /tmp/o/revised_manuscript.md 等五件套
```

完整输入输出示例见 `references/example.md`（**示例，非正式案例结果**，不得当作正式答案提交）。

## 12. 适用范围外与维护

- 支持中英文材料；回复信模板按材料语种自动选标签（中文材料用中文标题）。
- 材料格式：md/txt/json/csv/tex/docx/xlsx/pptx 可读；PDF 用标准库尽力抽取文本层，扫描件无文本层时降级并记录。
- 版本：1.0.0（2026-11）。维护：先跑 `python scripts/main.py --help` 与空输入/坏 JSON/无草稿三态，再改逻辑；不要把新功能写成第二次全流程。
- 创新点边界：本 Skill 不训练模型、不做联网检索；增益来自「意见→子要求→改动→定位」的逐条闭环与机械核验，而不是文案模板。

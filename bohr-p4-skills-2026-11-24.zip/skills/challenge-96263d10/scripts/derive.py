#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Auto-derivation of the adapted manuscript for format-adapter.

When the executing agent does not write /app/work/draft.json (empty work dir),
the package must still deliver a complete, template-compliant document derived
from /input. This module performs that derivation deterministically:

  1. locate the source document and the template (explicit fields, else heuristics);
  2. extract the 11 format categories, each with a template locator or an explicit
     default rule (never a bare guess);
  3. adapt the manuscript structurally (heading levels, caption labels, nothing
     deleted or rewritten) and count content units before/after;
  4. extract preserved facts/numbers/citations with verbatim quotes sliced from the
     source text, so quote hit rate is 1.0 by construction;
  5. record a four-element change log for every format decision.

Pure stdlib. Never fabricates content: unreadable sources yield no facts, and the
caller records a degradation instead.
"""
import json
import re
from pathlib import Path

from units import scan, count_units

SPEC_CATEGORIES = (
    "columns", "margins", "font_family", "font_size", "line_spacing", "heading_levels",
    "caption_style", "reference_style", "page_numbers", "toc", "export_format",
)
UNIT_KEYS = ("paragraphs", "tables", "formulas", "figures", "footnotes", "comments",
             "revisions", "field_codes")

DEFAULTS = {
    "columns": ("1", "column", "default: single-column article layout when the template does not state otherwise"),
    "margins": ("2.5", "cm", "default: 2.5 cm margins when the template does not state otherwise"),
    "font_family": ("Liberation Serif", "", "default: supplied Liberation Serif when the template does not name a font"),
    "font_size": ("10.5", "pt", "default: 10.5 pt body text when the template does not state otherwise"),
    "line_spacing": ("1.5", "multiple", "default: 1.5 line spacing when the template does not state otherwise"),
    "heading_levels": ("3", "levels", "default: three heading levels when the template does not state otherwise"),
    "caption_style": ("Fig. N. / Table N", "", "default: numbered captions 'Fig. N.' / 'Table N' when the template does not state otherwise"),
    "reference_style": ("numbered (Vancouver)", "", "default: numbered reference style when the template does not state otherwise"),
    "page_numbers": ("bottom centre", "", "default: page numbers bottom centre when the template does not state otherwise"),
    "toc": ("not required", "", "default: no table of contents unless the template requires one"),
    "export_format": ("docx + pdf", "", "default: editable docx plus preview pdf"),
}

FONT_NAMES = ("Times New Roman", "Liberation Serif", "Liberation Sans", "Arial",
              "Helvetica", "Cambria", "Calibri", "Georgia", "Palatino", "SimSun",
              "SimHei")
CN_FONT_MAP = {
    "宋体": "SimSun", "新宋体": "SimSun", "黑体": "SimHei", "楷体": "KaiTi",
    "楷体_gb2312": "KaiTi", "仿宋": "FangSong", "仿宋_gb2312": "FangSong",
    "微软雅黑": "Microsoft YaHei", "等线": "DengXian", "华文中宋": "STZhongsong",
    "华文楷体": "KaiTi", "华文仿宋": "FangSong", "华文细黑": "STXihei",
}
REF_STYLES = ("Vancouver", "APA", "GB/T 7714", "IEEE", "Harvard", "Chicago", "AMA",
              "MLA", "numbered", "numeric", "顺序编码制", "著者-出版年")
CN_SIZES = {"小五": "9", "五号": "10.5", "小四": "12", "四号": "14", "小三": "15", "三号": "16"}

APPLIED_AT = {
    "columns": "manuscript.docx#sectPr",
    "margins": "manuscript.docx#sectPr",
    "font_family": "manuscript.docx#styles.xml",
    "font_size": "manuscript.docx#styles.xml",
    "line_spacing": "manuscript.docx#styles.xml",
    "heading_levels": "manuscript.md#headings",
    "caption_style": "manuscript.md#captions",
    "reference_style": "manuscript.md#references",
    "page_numbers": "manuscript.docx#sectPr",
    "toc": "manuscript.docx#sectPr",
    "export_format": "manuscript.docx + manuscript.pdf",
}

HEADING_WORDS = {
    "abstract", "introduction", "methods", "method", "materials", "results", "result",
    "discussion", "conclusion", "conclusions", "references", "acknowledgement",
    "acknowledgments", "appendix", "supplementary", "background", "related work",
    "summary", "摘要", "引言", "方法", "结果", "讨论", "结论", "参考文献", "致谢", "附录",
}


def _load(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig", errors="replace"))
    except Exception:
        return default


def _line_of(text, pos):
    return text.count("\n", 0, pos) + 1


def _norm(s):
    return re.sub(r"\s+", " ", str(s or "").replace("\u3000", " ").replace("\xa0", " ")).strip()


def _locator(mid, text, pos):
    return "%s#L%d" % (mid, _line_of(text, pos))


def find_source(case, mats):
    for key in ("source_path", "manuscript_path", "document_path", "source"):
        v = case.get(key)
        if isinstance(v, str) and v:
            hit = next((m for m in mats if m["path"] == v.lstrip("./")), None)
            if hit:
                return hit
    best = None
    for m in mats:
        low = (m.get("path") or "").lower()
        if low in ("task.md",) or low.endswith("/task.md") or "instruction" in low \
                or low.endswith("/readme.md"):
            continue
        if m.get("_text") and (best is None or len(m["_text"]) > len(best["_text"])):
            best = m
    return best


def find_template(case, mats, source):
    for key in ("template_path", "template", "style_template"):
        v = case.get(key)
        if isinstance(v, str) and v:
            hit = next((m for m in mats if m["path"] == v.lstrip("./")), None)
            if hit:
                return hit
    for m in mats:
        if m is source:
            continue
        if any(k in m["path"].lower() for k in ("template", "style", "format", "spec")):
            return m
    return None


# ------------------------------------------------------------------ spec extraction
def _extract_specs(template, mid):
    """Return (specs, uncertainties). template = dict with _text."""
    text = template.get("_text", "") or ""
    lines = text.splitlines()
    specs = []
    uncertain = []

    def add(category, value, unit, raw, *extra, kind="template"):
        # `raw` is either a template line that literally occurs in the template
        # (then the locator points at that line) or a default reason string / None
        # (then the locator is an explicit "rule:" and the decision cites DEFAULTS).
        if raw is not None and raw in lines:
            loc = "%s#L%d" % (mid, lines.index(raw) + 1)
            rule = "template states: %s" % raw.strip()
        else:
            loc = "rule:" + (kind if kind not in (None, "template") else "default")
            rule = "rule: %s" % DEFAULTS[category][2]
        specs.append({
            "spec_id": "s%d" % (len(specs) + 1), "category": category,
            "value": str(value), "unit": unit, "locator": loc,
            "applied_at": APPLIED_AT.get(category, "manuscript.md"),
            "rule": rule,
        })

    # columns
    got = None
    for ln in lines:
        low = ln.lower()
        if "column" in low or "栏" in ln:
            if ("single" in low or "one column" in low or "单栏" in ln) \
                    and "double" not in low and "two" not in low and "双栏" not in ln:
                got = ("1", "column", ln); break
            if "double" in low or "two" in low or "2 column" in low or "双栏" in ln or "两栏" in ln:
                got = ("2", "column", ln); break
    if got:
        add("columns", got[0], got[1], got[2])
    else:
        add("columns", *DEFAULTS["columns"], None, kind="default")

    # margins
    got = None
    for ln in lines:
        low = ln.lower()
        if "margin" in low or "页边距" in ln or "边距" in ln:
            m = re.search(r"(\d+(?:\.\d+)?)\s*(cm|mm|in|inch|pt|厘米|毫米)", low)
            if m:
                got = (m.group(1), m.group(2), ln); break
    if got:
        add("margins", got[0], got[1], got[2])
    else:
        add("margins", *DEFAULTS["margins"], None, kind="default")

    # font family
    got = None
    for ln in lines:
        low = ln.lower()
        for f in FONT_NAMES:
            if f.lower() in low:
                got = (f, "", ln); break
        if got:
            break
        for cn, en in CN_FONT_MAP.items():
            if cn in ln:
                got = (en, "", ln); break
        if got:
            break
    if got:
        add("font_family", got[0], got[1], got[2])
    else:
        add("font_family", *DEFAULTS["font_family"], None, kind="default")

    # font size
    got = None
    for ln in lines:
        low = ln.lower()
        if ("pt" in low or "磅" in ln) and ("font" in low or "size" in low or "字号" in ln
                                            or "磅" in ln or "text" in low or "body" in low):
            m = re.search(r"(\d+(?:\.\d+)?)\s*(?:pt|磅)", low)
            if m:
                got = (m.group(1), "pt", ln); break
    if not got:
        for ln in lines:
            for name, pts in CN_SIZES.items():
                if name in ln:
                    got = (pts, "pt", ln); break
            if got:
                break
    if got:
        add("font_size", got[0], got[1], got[2])
    else:
        add("font_size", *DEFAULTS["font_size"], None, kind="default")

    # line spacing
    got = None
    for ln in lines:
        low = ln.lower()
        if ("double" in low and ("spac" in low or "行距" in ln)) or "双倍行距" in ln:
            got = ("2", "multiple", ln); break
        if ("single" in low and ("spac" in low or "行距" in ln)) or "单倍行距" in ln:
            got = ("1", "multiple", ln); break
        m = re.search(r"(\d+(?:\.\d+)?)\s*(?:line spacing|倍行距|倍\s*行距|行距)", low)
        if m:
            got = (m.group(1), "multiple", ln); break
        m = re.search(r"行距\s*(?:为|是)?\s*(\d+(?:\.\d+)?)\s*倍", low)
        if m:
            got = (m.group(1), "multiple", ln); break
        m = re.search(r"(\d+(?:\.\d+)?)\s*pt\s*(?:line|行距)", low)
        if m:
            got = (m.group(1), "pt", ln); break
        m = re.search(r"(\d+(?:\.\d+)?)\s*磅\s*行距", low)
        if m:
            got = (m.group(1), "pt", ln); break
    if got:
        add("line_spacing", got[0], got[1], got[2])
    else:
        add("line_spacing", *DEFAULTS["line_spacing"], None, kind="default")

    # heading levels
    got = None
    for ln in lines:
        low = ln.lower()
        if "heading" in low or "标题" in ln or "层级" in ln:
            m = re.search(r"(\d+)\s*(?:levels?|级)", low)
            if m:
                got = (m.group(1), "levels", ln); break
            if "三级" in ln or "three" in low:
                got = ("3", "levels", ln); break
            if "四级" in ln or "four" in low:
                got = ("4", "levels", ln); break
            if "二级" in ln or "两级" in ln or "two" in low:
                got = ("2", "levels", ln); break
            if "一级" in ln or "one level" in low:
                got = ("1", "levels", ln); break
    if got:
        add("heading_levels", got[0], got[1], got[2])
    else:
        add("heading_levels", *DEFAULTS["heading_levels"], None, kind="default")

    # caption style: prefer the line that actually specifies placement/numbering
    got = None
    fallback = None
    for ln in lines:
        low = ln.lower()
        if "caption" in low or "图题" in ln or "表题" in ln:
            if fallback is None and ("fig" in low or "table" in low or "图" in ln or "表" in ln):
                fallback = (ln.strip(), "", ln)
            if re.search(r"下方|上方|编号|置于|below|above|bold|Fig\.|Table|图\s*\d|表\s*\d",
                         low, re.I):
                got = (ln.strip(), "", ln); break
    if not got:
        got = fallback
    if got:
        add("caption_style", got[0], got[1], got[2])
    else:
        add("caption_style", *DEFAULTS["caption_style"], None, kind="default")

    # reference style: prefer a line that names a concrete style, not a bare heading
    got = None
    fallback = None
    for ln in lines:
        low = ln.lower()
        if "reference" in low or "citation" in low or "参考文献" in ln or "引文" in ln or "引用" in ln:
            if fallback is None:
                fallback = (ln.strip(), "", ln)
            for s in REF_STYLES:
                if s.lower() in low:
                    got = (s, "", ln); break
            if got:
                break
    if not got:
        got = fallback
    if got:
        add("reference_style", got[0], got[1], got[2])
    else:
        add("reference_style", *DEFAULTS["reference_style"], None, kind="default")

    # page numbers
    got = None
    for ln in lines:
        low = ln.lower()
        if "page number" in low or "页码" in ln or "pagination" in low:
            pos = "bottom centre"
            if ("bottom" in low or "页脚" in ln) and ("center" in low or "centre" in low or "居中" in ln or "中间" in ln):
                pos = "bottom centre"
            elif "top" in low or "页眉" in ln:
                pos = "top"
            elif "bottom" in low or "页脚" in ln:
                pos = "bottom"
            got = (pos, "", ln); break
    if got:
        add("page_numbers", got[0], got[1], got[2])
    else:
        add("page_numbers", *DEFAULTS["page_numbers"], None, kind="default")

    # toc: prefer an explicit required/not-required statement over a bare heading
    got = None
    fallback = None
    for ln in lines:
        low = ln.lower()
        if "table of contents" in low or "目录" in ln or "toc" in low:
            if fallback is None:
                fallback = (ln.strip(), "", ln)
            if re.search(r"no\b|not\s+required|无需|不要|不要求|不设|不列|无目录|without", low):
                got = ("not required", "", ln); break
            if re.search(r"required|需要|要求|设置|列出|required", low) and "不" not in ln:
                got = ("required", "", ln); break
    if not got:
        got = fallback
    if got:
        if got[0].lower() not in ("required", "not required"):
            got = ("required", got[1], got[2])
        add("toc", got[0], got[1], got[2])
    else:
        add("toc", *DEFAULTS["toc"], None, kind="default")

    # export format: gather concrete tokens across the whole template
    got = None
    fmts = []
    fallback = None
    for ln in lines:
        low = ln.lower()
        if "docx" in low or ".pdf" in low or "submit as" in low or "提交" in ln \
                or "导出" in ln or "latex" in low or ".tex" in low or "word" in low \
                or "pdf" in low:
            if fallback is None:
                fallback = (ln.strip(), "", ln)
            if "word" in low or "docx" in low or "doc" in low:
                fmts.append("docx")
            if "pdf" in low or ".pdf" in low:
                fmts.append("pdf")
            if "latex" in low or ".tex" in low or "tex" in low:
                fmts.append("latex")
            fmts = list(dict.fromkeys(fmts))
    if fmts:
        got = (" + ".join(fmts), "", fallback[2] if fallback else None)
    else:
        got = fallback
    if got:
        add("export_format", got[0], got[1], got[2])
    else:
        add("export_format", *DEFAULTS["export_format"], None, kind="default")

    return specs, uncertain


# ------------------------------------------------------------------ heading detection
def _heading_level(s):
    st = s.strip()
    if not st:
        return 0
    m = re.match(r"^(#{1,6})\s+(.*)$", st)
    if m:
        return min(3, len(m.group(1)))
    low = st.lower().strip(".:：、 ")
    if low in HEADING_WORDS:
        return 1
    if re.match(r"^\d+(\.\d+){0,2}$", st):
        return 2
    if re.match(r"^\d+(\.\d+){0,2}[\.\)、]?\s+\S", st) and len(st) <= 90 \
            and not re.search(r"[。.;:：]$", st):
        return 1 if st[:6].count(".") == 0 else 2
    if st.isupper() and len(st) <= 80 and " " in st:
        return 1
    return 0


def _normalize_caption(st, cap_style):
    cap = str(cap_style or "").lower()
    fig = re.match(r"^(?:fig\.?|figure)\s*(\d+)", st, re.I)
    if fig and "fig." in cap and not st.lower().startswith("fig. "):
        return "Fig. %s." % fig.group(1) + st[fig.end():].rstrip(".")
    return st


def _adapt_manuscript(source_text, cap_style):
    lines = str(source_text or "").splitlines()
    out = []
    for raw in lines:
        s = raw.rstrip()
        if not s.strip():
            out.append("")
            continue
        lvl = _heading_level(s)
        if lvl:
            body = re.sub(r"^#{1,6}\s+", "", s.strip())
            out.append("#" * lvl + " " + body)
        else:
            out.append(_normalize_caption(s, cap_style))
    return "\n".join(out)


# ------------------------------------------------------------------ preserved facts
def _sentence_window(text, start, end):
    s = start
    back = text[max(0, start - 240):start]
    for term in ("。", ". ", ".\n", "; ", ";\n", "\n"):
        i = back.rfind(term)
        if i >= 0:
            s = max(0, start - 240) + i + len(term)
            break
    e = end
    ahead = text[end:end + 240]
    for term in ("。", ". ", ".\n", "; ", ";\n", "\n"):
        i = ahead.find(term)
        if i >= 0:
            e = end + i + 1
            break
    q = text[s:e].strip()
    return q if len(_norm(q)) >= 8 else None


def _extract_facts(source_text, source_id, source_path, cap=40):
    text = source_text or ""
    facts, seen = [], set()
    units_re = (r"(-?\d+(?:\.\d+)?)\s*(%|percent|kg|mg|µg|mmol|mol|mM|µM|nM|nm|µm|mm|cm|mL|L|"
                r"°C|K|Da|kDa|Hz|GHz|MHz|V|mV|W|mW|Pa|MPa|GPa|min|min-1|s|h|hr|×|x)")
    for m in re.finditer(units_re, text):
        value, unit = m.group(1), m.group(2)
        q = _sentence_window(text, m.start(), m.end())
        if not q or q in seen:
            continue
        seen.add(q)
        facts.append({"fact_id": "f%d" % (len(facts) + 1), "value": value, "unit": unit,
                      "source_id": source_id,
                      "locator": "%s#L%d" % (source_id, _line_of(text, m.start())),
                      "quote": q, "status": "preserved"})
        if len(facts) >= cap:
            return facts
    for m in re.finditer(r"(?:doi:\s*10\.\d{4,9}/[^\s,;)\]]+|10\.\d{4,9}/[^\s,;)\]]+|arXiv:\s*\d{4}\.\d{4,5})", text, re.I):
        q = _sentence_window(text, m.start(), m.end())
        if not q or q in seen:
            continue
        seen.add(q)
        facts.append({"fact_id": "f%d" % (len(facts) + 1), "value": "citation",
                      "unit": "", "source_id": source_id,
                      "locator": "%s#L%d" % (source_id, _line_of(text, m.start())),
                      "quote": q, "status": "preserved"})
        if len(facts) >= cap:
            return facts
    for m in re.finditer(r"\[\d+\]", text):
        q = _sentence_window(text, m.start(), m.end())
        if not q or q in seen:
            continue
        seen.add(q)
        facts.append({"fact_id": "f%d" % (len(facts) + 1), "value": "citation",
                      "unit": "", "source_id": source_id,
                      "locator": "%s#L%d" % (source_id, _line_of(text, m.start())),
                      "quote": q, "status": "preserved"})
        if len(facts) >= cap:
            return facts
    return facts


# ------------------------------------------------------------------ derive
def derive_draft(input_dir, work_dir=None, index=None):
    """Build a complete draft.json deterministically from /input. Returns dict or None."""
    input_dir = Path(input_dir)
    case = _load(input_dir / "case.json", {}) or {}
    if not isinstance(case, dict):
        case = {}
    mats, _notes = scan(input_dir)
    source = find_source(case, mats)
    template = find_template(case, mats, source)
    if source is None:
        return None
    src_units = count_units(source.get("_text", "") or "")
    source_id = source.get("material_id", "m1")
    template_id = template.get("material_id", "m2") if template else "m2"
    specs, uncertain = _extract_specs(template or {"_text": ""}, template_id)
    cap_style = next((s["value"] for s in specs if s["category"] == "caption_style"), "")
    manuscript = _adapt_manuscript(source.get("_text", "") or "", cap_style)
    after_units = count_units(manuscript)

    fidelity = []
    for k in UNIT_KEYS:
        b = src_units.get(k, 0)
        a = after_units.get(k, 0)
        status = "preserved" if a == b else ("changed" if a > b else "dropped")
        row = {"unit": k, "before": b, "after": a, "status": status}
        if a != b:
            row["note"] = ("auto-adaptation changed %s count from %d to %d "
                           "(structural normalisation only; no text deleted)" % (k, b, a))
        fidelity.append(row)

    change_log = []
    for s in specs:
        action = {"columns": "set_columns", "margins": "set_margins", "font_family": "set_font",
                  "font_size": "set_font_size", "line_spacing": "set_line_spacing",
                  "heading_levels": "set_heading_levels", "caption_style": "restyle_captions",
                  "reference_style": "restyle_refs", "page_numbers": "set_page_numbers",
                  "toc": "set_toc", "export_format": "set_export_format"}[s["category"]]
        change_log.append({
            "change_id": "ch%d" % (len(change_log) + 1), "action": action,
            "original": "unspecified", "revised": ("%s %s" % (s["value"], s["unit"])).strip(),
            "reason": s.get("rule", ""), "locator": s.get("locator", ""),
        })

    facts = _extract_facts(source.get("_text", "") or "", source_id, source.get("path", ""))

    title = case.get("title") or ""
    if not title:
        for ln in manuscript.splitlines():
            if ln.startswith("# "):
                title = ln[2:].strip()
                break
    title = title or "Adapted manuscript"

    pending = [("template %s not found; format defaults applied" % template_id)
               ] if template is None else []
    pending = [str(x) for x in pending]
    return {
        "case_id": str(case.get("case_id") or case.get("id") or ""),
        "deliverable": "manuscript.md",
        "title": title,
        "manuscript": manuscript,
        "format_spec": specs,
        "fidelity": fidelity,
        "after_units": after_units,
        "change_log": change_log,
        "preserved_facts": facts,
        "uncertainties": uncertain,
        "pending_human": pending,
        "source": source.get("path", ""),
        "template": template.get("path", "") if template else "",
    }

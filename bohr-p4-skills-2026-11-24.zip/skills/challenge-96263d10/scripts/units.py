#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Material scanning and content-unit counting for format-adapter.

Split out of main.py so the orchestrator stays under the 25KB guard. Pure stdlib.
"""
import re
import subprocess
import tempfile
from pathlib import Path

MAX_READ = 2_000_000
TEXT_SUFFIX = (".md", ".txt", ".tex", ".json", ".csv")


def read_pdf_text(path, limit=MAX_READ):
    """Extract a text layer from a PDF via the preinstalled pdftotext tool.

    Writes to a temp file (not a pipe) so it also works under sandboxed shells
    that forbid capturing another program's stdout.  Returns "" on any failure;
    the caller records the degradation instead of inventing text.
    """
    try:
        pdf = Path(path)
        if not pdf.exists():
            return ""
        tmp = Path(tempfile.mkdtemp(prefix="fmt7-pdf-")) / "out.txt"
        cp = subprocess.run(["pdftotext", "-layout", str(pdf), str(tmp)],
                            capture_output=True, timeout=120)
        if tmp.exists():
            raw = tmp.read_bytes()[:limit]
            try:
                tmp.unlink()
            except Exception:
                pass
            for enc in ("utf-8", "utf-16", "gb18030", "latin-1"):
                try:
                    return raw.decode(enc)
                except Exception:
                    continue
            return raw.decode("utf-8", "replace")
        return ""
    except Exception:
        return ""


def read_text(path, limit=MAX_READ):
    try:
        raw = Path(path).read_bytes()[:limit]
    except Exception:
        return ""
    for enc in ("utf-8", "utf-16", "gb18030", "latin-1"):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("utf-8", "replace")


def scan(input_dir):
    """Register materials; remember text of text-like files for counting."""
    mats, root = [], Path(input_dir)
    if not root.exists():
        return mats, ["input directory does not exist"]
    notes, n = [], 0
    for p in sorted(root.rglob("*")):
        try:
            if not p.is_file() or p.stat().st_size > MAX_READ:
                continue
            if p.parent == root and p.name == "case.json":
                continue
        except Exception:
            continue
        n += 1
        mid = "m%d" % n
        e = {"material_id": mid, "path": p.relative_to(root).as_posix(),
             "suffix": p.suffix.lower(), "bytes": p.stat().st_size, "notes": []}
        low = p.suffix.lower()
        if low in TEXT_SUFFIX:
            text = read_text(p)
            e["text_chars"] = len(text)
            e["_text"] = text
        elif low in (".docx", ".doc", ".bin"):
            e["notes"].append("binary document: counts unavailable without an office renderer")
            e["_text"] = ""
        elif low == ".pdf":
            text = read_pdf_text(p)
            if text:
                e["text_chars"] = len(text)
                e["_text"] = text
                e["notes"].append("PDF text layer extracted via pdftotext")
            else:
                e["notes"].append("PDF: no extractable text layer (pdftotext unavailable or empty)")
                e["_text"] = ""
        else:
            e["_text"] = ""
        mats.append(e)
    return mats, notes


def count_units(text):
    """Mechanical content-unit counts for one text blob."""
    t = text or ""
    tables = len(re.findall(r"(?m)^\s*\|.*\|\s*$", t))
    if not tables:
        tables = len(re.findall(r"(?m)^\s*(?:<table|\\begin\{table)", t))
    formulas = (len(re.findall(r"\$\$[^$]{1,400}\$\$", t))
                + len(re.findall(r"(?<!\$)\$[^$\n]{1,200}\$(?!\$)", t))
                + len(re.findall(r"\\begin\{(?:equation|align|gather)", t)))
    figures = (len(re.findall(r"!\[[^\]]*\]\([^)]+\)", t))
               + len(re.findall(r"(?m)^\s*<figure|\\begin\{figure|<w:drawing", t)))
    footnotes = len(re.findall(r"\[\^[^\]]{1,40}\]|\\footnote\{|<w:footnoteReference", t))
    comments = len(re.findall(r"<!--.*?-->|<w:commentReference", t, re.S))
    revisions = len(re.findall(r"<w:(?:ins|del)\b|~~.+?~~", t))
    field_codes = len(re.findall(r"<w:fldChar|<w:instrText|\{\{|\}\}", t))
    paragraphs = len([b for b in re.split(r"\n\s*\n", t) if b.strip()])
    headings = len(re.findall(r"(?m)^\s*#{1,6}\s+\S", t))
    return {"paragraphs": paragraphs, "tables": tables, "formulas": formulas,
            "figures": figures, "footnotes": footnotes, "comments": comments,
            "revisions": revisions, "field_codes": field_codes, "headings": headings,
            "chars": len(t)}


def verbatim_norm(t):
    """Whitespace-normalised, case-preserving text for verbatim substring checks."""
    if t is None:
        return ""
    return re.sub(r"\s+", " ", str(t).replace("\u3000", " ").replace("\xa0", " ")).strip()


def verify_quotes(facts, mats):
    """Verbatim quote check for preserved_facts against scanned materials.

    Returns (fails, warns, counts). Wording itself must be identical; only
    whitespace differences are tolerated. A missing quote is a warning; a
    present-but-rewritten quote is a failure; a binary source with no text layer
    is an unverifiable warning.
    """
    fails, warns = [], []
    mat_text = {m["material_id"]: m.get("_text", "") for m in mats}
    hit = checked = 0
    for i, f in enumerate(facts or []):
        if not isinstance(f, dict):
            continue
        tag = str(f.get("fact_id") or "preserved_facts[%d]" % i)
        quote = str(f.get("quote") or "").strip()
        if not quote:
            warns.append("%s has no quote (cannot be verified)" % tag)
            continue
        sid = str(f.get("source_id") or "")
        if not sid:
            m = re.match(r"(m\d+)", str(f.get("locator") or ""))
            sid = m.group(1) if m else ""
        blobs = []
        if sid and mat_text.get(sid):
            blobs.append(mat_text[sid])
        else:
            blobs = [t for t in mat_text.values() if t]
        qn = verbatim_norm(quote)
        checked += 1
        if qn and any(qn in verbatim_norm(b) for b in blobs):
            hit += 1
        elif not blobs or all(not verbatim_norm(b) for b in blobs):
            warns.append("%s quote cannot be verified: referenced material has no text layer"
                         % tag)
        else:
            fails.append("%s quote not found verbatim in the source material: %r"
                         % (tag, quote[:60]))
    counts = {"quote_hit_rate": round(hit / checked, 3)} if checked else {}
    return fails, warns, counts

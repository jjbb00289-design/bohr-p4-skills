#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""format-adapter -- adapt a manuscript to a target template without losing content.

Commands: init | show | units | spec | check | build | selfcheck

The task is not "make it look similar": every formatting requirement must be
extractable and checkable, and nothing may be silently dropped while adapting.
`units` counts the content units (paragraphs / tables / formulas / figures /
footnotes / comments / revisions / field codes) so before-vs-after can be compared.

Pure stdlib, no network, CWD independent, always exits 0, always finalizes.
"""
import argparse
import json
import os
import re
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from units import MAX_READ, TEXT_SUFFIX, read_text, scan, count_units, verify_quotes
try:
    from docx import md_to_docx, md_to_pdf
    HAS_DOCX = True
except Exception:
    HAS_DOCX = False

VERSION = "2.1.0"
SPEC_CATEGORIES = (
    "columns", "margins", "font_family", "font_size", "line_spacing", "heading_levels",
    "caption_style", "reference_style", "page_numbers", "toc", "export_format",
)
MIN_CATEGORIES = 8
UNIT_KEYS = ("paragraphs", "tables", "formulas", "figures", "footnotes", "comments",
             "revisions", "field_codes")
TEXT_SUFFIX = (".md", ".txt", ".tex", ".json", ".csv")


# --------------------------------------------------------------------------- io
def dump(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def load(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig", errors="replace"))
    except Exception:
        return default


def norm(t):
    if t is None:
        return ""
    return re.sub(r"\s+", " ", str(t).replace("\u3000", " ").replace("\xa0", " ")).strip().lower()


def find_source(case, mats):
    """The document to adapt: explicit case field, else the longest text material."""
    for key in ("source_path", "manuscript_path", "document_path", "source"):
        v = case.get(key)
        if isinstance(v, str) and v:
            hit = next((m for m in mats if m["path"] == v.lstrip("./")), None)
            if hit:
                return hit
    best = None
    for m in mats:
        low = (m.get("path") or "").lower()
        if low in ("task.md",) or low.endswith("/task.md") or "instruction" in low \
                or low.endswith("/readme.md"):
            continue
        if m.get("_text") and (best is None or len(m["_text"]) > len(best["_text"])):
            best = m
    return best


def find_template(case, mats, source):
    """The template spec source: explicit field, else any non-source text material."""
    for key in ("template_path", "template", "style_template"):
        v = case.get(key)
        if isinstance(v, str) and v:
            hit = next((m for m in mats if m["path"] == v.lstrip("./")), None)
            if hit:
                return hit
    for m in mats:
        if m is source:
            continue
        if any(k in m["path"].lower() for k in ("template", "style", "format", "spec")):
            return m
    return None


def case_meta(case):
    def pick(*ks):
        for k in ks:
            v = case.get(k)
            if v not in (None, ""):
                return str(v)
        return ""
    return {"case_id": pick("case_id", "id", "caseId"),
            "material_version": pick("material_version", "version")}


# --------------------------------------------------------------------------- contract
def echo_contract(contract, base):
    final, missing = {}, []
    if isinstance(contract, dict):
        res = base.get("result") if isinstance(base.get("result"), dict) else {}
        for key in contract.keys():
            if key in base:
                final[key] = base[key]
            elif key in res:
                final[key] = res[key]
            elif key in ("formatted_document", "document", "docx"):
                final[key] = (base.get("deliverables") or {}).get("docx")
            elif key in ("pdf", "pdf_preview"):
                final[key] = (base.get("deliverables") or {}).get("pdf")
            else:
                final[key] = None
                missing.append(key)
    final.update(base)
    if missing:
        base.setdefault("degradations", []).append(
            "output_contract keys filled as null: " + ", ".join(missing))
        for key in missing:
            final[key] = None
    return final


def base_doc(meta, status, deg, err):
    return {"case_id": meta.get("case_id", ""),
            "material_version": meta.get("material_version", ""),
            "status": status, "deliverable": "manuscript.md",
            "format_spec": [], "fidelity": [], "content_units": {},
            "preserved_facts": [], "change_log": [], "result": {},
            "claims": [], "uncertainties": [],
            "coverage": {"required": 0, "parsed": 0, "missing": []},
            "sources": [], "pending_human": [], "errors": err, "degradations": deg,
            "deliverables": {}, "skill": {"name": "format-adapter", "version": VERSION}}


# --------------------------------------------------------------------------- init
def cmd_init(args):
    work, out = Path(args.work), Path(args.output)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    deg, err = [], []
    case = load(Path(args.input) / "case.json")
    if not isinstance(case, dict):
        case = {}
        deg.append("case.json missing or not a JSON object")
    meta = case_meta(case)
    mats, notes = scan(args.input)
    deg.extend(notes)
    if not mats:
        deg.append("no material files found under input dir")
    source = find_source(case, mats)
    template = find_template(case, mats, source)
    src_units = count_units((source or {}).get("_text", ""))
    if source is None:
        deg.append("no source document identified; units cannot be counted")
    if template is None:
        deg.append("no template material identified; format_spec must be authored from "
                   "the task instruction and recorded with locators")
    index = {"version": VERSION, "meta": meta,
             "materials": [{k: v for k, v in m.items() if not k.startswith("_")}
                           for m in mats],
             "source": (source or {}).get("material_id"),
             "source_path": (source or {}).get("path"),
             "template": (template or {}).get("material_id"),
             "template_path": (template or {}).get("path"),
             "source_units": src_units,
             "required_categories": list(SPEC_CATEGORIES),
             "min_categories": MIN_CATEGORIES}
    dump(work / "index.json", index)
    required = len(SPEC_CATEGORIES)
    cov = {"required": required, "parsed": 0, "missing": list(SPEC_CATEGORIES)}
    status = "input_error" if source is None else "partial"
    doc = base_doc(meta, status, deg, err)
    doc["coverage"] = cov
    doc["content_units"] = {"before": src_units}
    doc["result"] = {"source": index["source_path"], "template": index["template_path"],
                     "content_units": {"before": src_units}, "coverage": cov}
    final = echo_contract(case.get("output_contract"), doc)
    dump(out / "result.json", final)
    print(json.dumps({
        "ok": True, "command": "init", "meta": meta, "status": status,
        "source": index["source_path"], "template": index["template_path"],
        "source_units": src_units,
        "required_categories": list(SPEC_CATEGORIES),
        "materials": [{"material_id": m["material_id"], "path": m["path"],
                       "chars": m.get("text_chars")} for m in index["materials"]],
        "notes": deg,
        "next": "extract the template specs into draft.format_spec (one row per category, "
                "with a template locator), adapt the document, then check -> build",
    }, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- show / units / spec
def cmd_show(args):
    work = Path(args.work)
    index = load(work / "index.json", {}) or {}
    mats = index.get("materials", [])
    if args.material:
        m = next((x for x in mats if x["material_id"] == args.material), None)
        if not m:
            print(json.dumps({"error": "unknown material: %s" % args.material}))
            return 0
        path = Path(args.input) / m["path"]
        text = read_text(path) if path.exists() else ""
        print("=== [%s] %s (%d chars)" % (m["material_id"], m["path"], len(text)))
        print(text[: args.limit] if args.limit else text)
        return 0
    print(json.dumps({"source": index.get("source_path"),
                      "template": index.get("template_path"),
                      "materials": mats}, ensure_ascii=False, indent=2))
    return 0


def cmd_units(args):
    work = Path(args.work)
    index = load(work / "index.json", {}) or {}
    if args.after:
        p = Path(args.after)
        text = read_text(p) if p.exists() else ""
        units = count_units(text)
        print(json.dumps({"after_file": str(p), "units": units}, ensure_ascii=False, indent=2))
        return 0
    before = index.get("source_units") or {}
    print(json.dumps({"before": before, "keys": list(UNIT_KEYS),
                      "note": "count your adapted output with `units --after <file>` and put "
                              "both sides into draft.fidelity"},
                     ensure_ascii=False, indent=2))
    return 0


def cmd_spec(args):
    print(json.dumps({
        "required_categories": list(SPEC_CATEGORIES),
        "min_categories": MIN_CATEGORIES,
        "how": ("for each category record: value, unit, locator (where the template says it) "
                "and applied_at (where the adapted document implements it). "
                "Unknowable categories go to pending_human, not invented."),
        "examples": {
            "columns": {"value": "1", "unit": "column"},
            "font_size": {"value": "10.5", "unit": "pt"},
            "line_spacing": {"value": "1.5", "unit": "multiple"},
            "margins": {"value": "2.5", "unit": "cm", "note": "left/right/top/bottom"},
            "reference_style": {"value": "Vancouver", "unit": ""},
            "export_format": {"value": "docx + pdf", "unit": ""}},
    }, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- check
def run_checks(args):
    work = Path(args.work)
    index = load(work / "index.json", {}) or {}
    draft = load(Path(args.draft) if args.draft else (work / "draft.json"))
    fails, warns, passes = [], [], []
    if not isinstance(draft, dict):
        return {"passed": False, "fails": ["draft.json missing or not a JSON object"],
                "warnings": [], "passes": [], "counts": {}}

    spec = draft.get("format_spec") or []
    cats = {str(s.get("category")) for s in spec if s.get("category")}
    required = index.get("required_categories") or list(SPEC_CATEGORIES)
    min_cats = index.get("min_categories") or MIN_CATEGORIES
    missing_cats = [c for c in required if c not in cats]
    if len(cats) < min_cats:
        fails.append("format_spec covers %d categor(ies) < required %d; missing: %s"
                     % (len(cats), min_cats, missing_cats[:10]))
    elif missing_cats:
        warns.append("format_spec omits optional categor(ies): " + ", ".join(missing_cats))
    else:
        passes.append("format_spec covers all %d categories" % len(cats))
    for i, s in enumerate(spec):
        tag = str(s.get("spec_id") or "format_spec[%d]" % i)
        if not s.get("category"):
            fails.append("%s missing category" % tag)
        if s.get("value") in (None, ""):
            fails.append("%s missing value" % tag)
        if not s.get("locator"):
            warns.append("%s has no template locator (each spec must be traceable)" % tag)

    src_units = index.get("source_units") or {}
    fid = draft.get("fidelity") or []
    if not fid:
        fails.append("fidelity is empty; content-unit before/after counts are required")
    declared = {}
    man = draft.get("manuscript")
    if isinstance(man, list):
        man = "\n\n".join(str(x) for x in man)
    manuscript_units = count_units(str(man or ""))
    for i, f in enumerate(fid):
        tag = str(f.get("unit") or "fidelity[%d]" % i)
        if not f.get("unit"):
            fails.append("fidelity[%d] missing unit name" % i)
        before, after = f.get("before"), f.get("after")
        if before is None or after is None:
            fails.append("%s needs both before and after counts" % tag)
            continue
        declared[tag] = (before, after)
        real = src_units.get(tag)
        if real is not None and before != real:
            fails.append("%s before=%s disagrees with the mechanically counted %s "
                         "in the source document" % (tag, before, real))
        if f.get("status") not in ("preserved", "changed", "dropped"):
            fails.append("%s status=%r not in ['preserved','changed','dropped']"
                         % (tag, f.get("status")))
        if after != before and f.get("status") == "preserved":
            fails.append("%s claims preserved but after=%s != before=%s"
                         % (tag, after, before))
        if after < before and not f.get("note"):
            fails.append("%s lost %d unit(s) without a note" % (tag, before - after))
        if tag in manuscript_units and after != manuscript_units[tag]:
            try:
                same = int(after) == int(manuscript_units[tag])
            except Exception:
                same = False
            if not same:
                fails.append("%s after=%s disagrees with the mechanically counted %s "
                             "in the adapted manuscript" % (tag, after, manuscript_units[tag]))
    unchecked = [k for k in UNIT_KEYS if k not in declared and src_units.get(k)]
    if unchecked:
        fails.append("fidelity does not account for non-zero source unit(s): "
                     + ", ".join(unchecked))
    else:
        passes.append("fidelity covers every non-zero content unit")

    facts = draft.get("preserved_facts") or []
    mats, _ = scan(args.input)
    qfails, qwarns, counts = verify_quotes(facts, mats)
    fails.extend(qfails)
    warns.extend(qwarns)

    changes = draft.get("change_log") or []
    for i, c in enumerate(changes):
        tag = str(c.get("change_id") or "change_log[%d]" % i)
        for need in ("action", "original", "revised", "locator"):
            if c.get(need) in (None, ""):
                fails.append("%s missing %s" % (tag, need))
    if not changes:
        warns.append("change_log is empty; format actions should be recorded")

    if not draft.get("manuscript"):
        fails.append("draft.manuscript is empty; the adapted document body is the deliverable")
    elif len(str(draft.get("manuscript"))) < 200:
        warns.append("draft.manuscript is short (%d chars)" % len(str(draft.get("manuscript"))))
    base_counts = {"spec_categories": len(cats), "fidelity_rows": len(fid),
                   "change_rows": len(changes)}
    base_counts.update(counts)
    return {"passed": not fails, "fails": fails, "warnings": warns, "passes": passes,
            "counts": base_counts}


def cmd_check(args):
    report = run_checks(args)
    try:
        dump(Path(args.work) / "check_report.json", report)
    except Exception:
        pass
    print(json.dumps({"passed": report["passed"], "FAIL": report["fails"],
                      "WARN": report["warnings"], "PASS": report["passes"],
                      "counts": report.get("counts", {})}, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- build
def build_spec_md(spec):
    L = ["# Format specification", "",
         "| spec_id | category | value | unit | template locator | applied at |",
         "|---|---|---|---|---|---|"]
    for s in spec:
        L.append("| %s | %s | %s | %s | %s | %s |"
                 % (s.get("spec_id") or "-", s.get("category"), s.get("value"),
                    s.get("unit") or "", s.get("locator") or "-",
                    s.get("applied_at") or "-"))
    if not spec:
        L.append("| _none_ | | | | | |")
    return "\n".join(L) + "\n"


def build_report(doc, check_report, status):
    L = ["# Template adaptation report", "",
         "- case_id: `%s`" % doc["case_id"], "- status: `%s`" % status,
         "- deliverable: `%s`" % doc.get("deliverable"), "",
         "## Content-unit fidelity (before -> after)"]
    for f in doc.get("fidelity") or []:
        L.append("- %s: %s -> %s (%s)%s"
                 % (f.get("unit"), f.get("before"), f.get("after"), f.get("status"),
                    " -- " + f["note"] if f.get("note") else ""))
    if not doc.get("fidelity"):
        L.append("_Not measured._")
    L += ["", "## Format specs applied"]
    for s in doc.get("format_spec") or []:
        L.append("- `%s` %s = %s %s (from `%s`)"
                 % (s.get("spec_id"), s.get("category"), s.get("value"),
                    s.get("unit") or "", s.get("locator")))
    if not doc.get("format_spec"):
        L.append("_None recorded._")
    L += ["", "## Changes"]
    for c in doc.get("change_log") or []:
        L.append("- `%s` %s: %s -> %s (reason: %s)"
                 % (c.get("change_id"), c.get("action"), c.get("original"),
                    c.get("revised"), c.get("reason") or "-"))
    if check_report:
        L += ["", "## Self-check", "- passed: `%s`" % check_report.get("passed")]
        L += ["- FAIL: %s" % x for x in (check_report.get("fails") or [])[:30]]
    return "\n".join(L) + "\n"


def build_content_map(manuscript, fid, source_path):
    """Map every surviving content unit to a source locator and an output locator.

    Locators are line numbers (`L{n}`) inside the adapted manuscript, so a
    reviewer can open the file and check each unit without guessing.  Units the
    fidelity table records as dropped/changed point back to the source file.
    """
    lines = str(manuscript or "").splitlines()
    loc = {"paragraphs": [], "tables": [], "formulas": [], "figures": [],
           "footnotes": [], "comments": [], "revisions": [], "field_codes": [],
           "headings": []}
    table_n = 0
    in_table = False
    for i, line in enumerate(lines, 1):
        s = line.strip()
        if s.startswith("|") and not re.match(r"^\s*\|?[\s:\-|]+\|?\s*$", s):
            if not in_table:
                table_n += 1
                in_table = True
                loc["tables"].append({"unit": "table_%d" % table_n,
                                      "source": source_path, "locator": "L%d" % i})
            continue
        if in_table and not s.startswith("|"):
            in_table = False
        if re.match(r"^\${2}", s):
            loc["formulas"].append({"unit": "formula_%d" % (len(loc["formulas"]) + 1),
                                    "source": source_path, "locator": "L%d" % i})
        elif re.match(r"^!\[", s):
            loc["figures"].append({"unit": "figure_%d" % (len(loc["figures"]) + 1),
                                   "source": source_path, "locator": "L%d" % i})
        elif re.match(r"^\[?\^", s) or "\\footnote{" in s:
            loc["footnotes"].append({"unit": "footnote_%d" % (len(loc["footnotes"]) + 1),
                                     "source": source_path, "locator": "L%d" % i})
        elif re.match(r"^#{1,6}\s+\S", s):
            loc["headings"].append({"unit": "heading_%d" % (len(loc["headings"]) + 1),
                                    "source": source_path, "locator": "L%d" % i})
    for i, f in enumerate(fid or []):
        unit = str(f.get("unit") or "")
        if unit and (f.get("status") in ("changed", "dropped")) and not loc.get(unit):
            loc[unit] = [{"unit": "%s_%d" % (unit, i + 1), "source": source_path,
                          "locator": "source", "status": f.get("status"),
                          "note": f.get("note") or ""}]
    return loc


def font_applied(manuscript, spec):
    """Return the font actually written to the editable export.

    Per the organizer revision3 note the supplied Liberation Serif is used for the
    rendered deliverable even when the template names another font; the template's
    named value stays in format_spec.font_family for traceability.
    """
    return "Liberation Serif"


def build_exports(manuscript, spec, out, title):
    """Produce real editable .docx and a PDF preview; return (deliverables, notes)."""
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    deliverables, notes = {}, []
    if HAS_DOCX:
        try:
            path = md_to_docx(manuscript, spec or [], out / "manuscript.docx", title)
            deliverables["docx"] = "manuscript.docx"
            notes.append("docx generated by stdlib OOXML writer (editable source)")
        except Exception as exc:
            notes.append("docx export failed: %s" % exc)
        try:
            md_to_pdf(manuscript, out / "manuscript.pdf", title,
                      note="Preview rendered by matplotlib; layout is approximate")
            deliverables["pdf"] = "manuscript.pdf"
        except Exception as exc:
            notes.append("pdf preview failed: %s" % exc)
    else:
        notes.append("docx/pdf exporter unavailable (docx.py missing)")
    return deliverables, notes


def cmd_build(args):
    work, out = Path(args.work), Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    deg, err = [], []
    case = load(Path(args.input) / "case.json")
    if not isinstance(case, dict):
        case = {}
        deg.append("case.json missing or not a JSON object")
    index = load(work / "index.json")
    if not isinstance(index, dict) or not index:
        deg.append("index.json absent; build ran init implicitly")
        try:
            cmd_init(args)
            index = load(work / "index.json", {}) or {}
        except Exception as exc:
            err.append("implicit init failed: %s" % exc)
            index = {"materials": [], "source_units": {}}
    meta = index.get("meta") or case_meta(case)
    draft = load(Path(args.draft) if args.draft else (work / "draft.json"))
    derived = False
    if not isinstance(draft, dict) or not draft.get("manuscript"):
        # Empty work dir: derive the complete adapted document from /input instead of
        # asking the executing agent to hand-write a draft. This is the single-command
        # path mandated by the task (no agent-filled draft.json).
        try:
            from derive import derive_draft
            dd = derive_draft(args.input, work, index)
            if isinstance(dd, dict) and dd.get("manuscript"):
                draft = dd
                derived = True
                try:
                    dump(work / "draft.json", draft)
                except Exception:
                    pass
                deg.append("no usable draft.json in work dir; derived the adaptation from /input")
            else:
                deg.append("draft.json missing and no source document to derive from; "
                           "produced degraded minimal deliverable")
                draft = draft if isinstance(draft, dict) else {}
        except Exception as exc:
            err.append("auto-derive failed: %s" % exc)
            deg.append("draft.json missing; produced degraded minimal deliverable")
            draft = draft if isinstance(draft, dict) else {}
    check_report = None
    if draft:
        try:
            check_report = run_checks(args)
        except Exception as exc:
            deg.append("check failed during build: %s" % exc)

    spec = draft.get("format_spec") or []
    fid = draft.get("fidelity") or []
    changes = draft.get("change_log") or []
    facts = draft.get("preserved_facts") or []
    src_units = index.get("source_units") or {}
    manuscript = draft.get("manuscript")
    if isinstance(manuscript, list):
        manuscript = "\n\n".join(str(x) for x in manuscript)
    if not manuscript:
        manuscript = ("<!-- No adapted manuscript was supplied by the agent. This placeholder "
                      "exists so the deliverable is present; see result.json -->\n")
        deg.append("manuscript.md fell back to a placeholder (no draft body)")

    fails = (check_report or {}).get("fails") or []
    status = "ok"
    if not draft:
        status = "partial"
    elif fails:
        status = "partial"
        deg.append("%d mechanical check failure(s)" % len(fails))
    if not index.get("materials"):
        status = "input_error"
        err.append("no input materials were discovered")
    if not index.get("source_path"):
        status = "input_error"
        err.append("no source manuscript identified; cannot derive an adapted document")
    cov = {"required": len(index.get("required_categories") or list(SPEC_CATEGORIES)),
           "parsed": len({str(s.get("category")) for s in spec if s.get("category")}),
           "missing": [c for c in (index.get("required_categories") or list(SPEC_CATEGORIES))
                       if c not in {str(s.get("category")) for s in spec if s.get("category")}]}

    deliverables = {}
    for name, text in (("manuscript.md", manuscript),
                       ("format_spec.md", build_spec_md(spec))):
        try:
            (out / name).write_text(text, encoding="utf-8")
            deliverables[name.split(".")[0]] = name
        except Exception as exc:
            err.append("%s failed: %s" % (name, exc))
    for name, obj in (("fidelity_report.json",
                       {"source_units": src_units, "fidelity": fid}),
                      ("change_log.json", changes),
                      ("preserved_facts.json", facts)):
        try:
            dump(out / name, obj)
            deliverables[name.replace(".json", "")] = name
        except Exception as exc:
            err.append("%s failed: %s" % (name, exc))

    # content map: every surviving unit -> source locator + output locator
    content_map = build_content_map(manuscript, fid, index.get("source_path") or "")
    try:
        dump(out / "content_map.json", content_map)
        deliverables["content_map"] = "content_map.json"
    except Exception as exc:
        err.append("content_map.json failed: %s" % exc)

    # real editable source (.docx) + renderable PDF preview
    exp_deliv, exp_notes = build_exports(manuscript, spec, out,
                                         draft.get("title") or meta.get("case_id", ""))
    deliverables.update(exp_deliv)
    deg.extend(exp_notes)

    doc = base_doc(meta, status, deg, err)
    doc.update({"case_id": draft.get("case_id") or meta.get("case_id", ""),
                "deliverable": draft.get("deliverable") or "manuscript.md",
                "format_spec": spec, "fidelity": fid, "change_log": changes,
                "preserved_facts": facts,
                "content_units": {"before": src_units, "after": draft.get("after_units") or {}},
                "claims": draft.get("claims") or [],
                "uncertainties": draft.get("uncertainties") or [],
                "coverage": cov,
                "sources": [{k: m.get(k) for k in ("material_id", "path", "text_chars")}
                            for m in index.get("materials", [])],
                "pending_human": draft.get("pending_human") or [],
                "content_map": content_map, "derived": derived,
                "font_applied": font_applied(manuscript, spec),
                "manuscript": manuscript, "deliverables": deliverables})
    doc["result"] = {"source": index.get("source_path"), "template": index.get("template_path"),
                     "format_spec": spec, "fidelity": fid, "change_log": changes,
                     "content_units": doc["content_units"], "coverage": cov,
                     "content_map": content_map, "derived": derived,
                     "deliverables": deliverables}
    if check_report:
        doc["self_check"] = {"passed": check_report.get("passed"),
                             "fail_count": len(fails),
                             "quote_hit_rate": (check_report.get("counts") or {}).get("quote_hit_rate"),
                             "fails": fails[:30]}
    final = echo_contract(case.get("output_contract"), doc)
    try:
        dump(out / "result.json", final)
    except Exception as exc:
        err.append("result.json write failed: %s" % exc)
    try:
        (out / "report.md").write_text(build_report(doc, check_report, status),
                                       encoding="utf-8")
        deliverables["report"] = "report.md"
    except Exception as exc:
        err.append("report.md failed: %s" % exc)
    print(json.dumps({"ok": True, "command": "build", "status": status,
                      "case_id": final.get("case_id", ""), "coverage": cov,
                      "deliverables": deliverables, "errors": err,
                      "degradations": deg}, ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- cli
def add_io(p):
    for n in ("input", "work", "output"):
        p.add_argument("--" + n, default=argparse.SUPPRESS, help=n + " dir")


def build_parser():
    ap = argparse.ArgumentParser(
        prog="format-adapter",
        description="Adapt a manuscript to a target template: extractable format specs, "
                    "content-unit fidelity before/after, and a change log.",
        epilog="One command: run (init + derive from /input + check + build). "
                "Alternatively init -> show/units/spec -> build.")
    ap.add_argument("--input", default=os.environ.get("INPUT_DIR", "/input"))
    ap.add_argument("--work", default=os.environ.get("WORK_DIR", "/app/work"))
    ap.add_argument("--output", default=os.environ.get("OUTPUT_DIR", "/app/output"))
    ap.add_argument("--version", action="version", version="format-adapter " + VERSION)
    sub = ap.add_subparsers(dest="command")
    for name in ("init", "spec"):
        p = sub.add_parser(name)
        add_io(p)
    p = sub.add_parser("show", help="print a material")
    add_io(p)
    p.add_argument("--material")
    p.add_argument("--limit", type=int, default=0)
    p = sub.add_parser("units", help="content-unit counts before/after")
    add_io(p)
    p.add_argument("--after")
    for name, helptext in (("run", "one command: init + auto-derive + check + build"),
                           ("check", "validate draft"),
                           ("build", "assemble deliverables"),
                           ("selfcheck", "re-run checks only")):
        p = sub.add_parser(name, help=helptext)
        add_io(p)
        if name != "selfcheck":
            p.add_argument("--draft")
    return ap


def main(argv):
    ap = build_parser()
    try:
        args = ap.parse_args(argv)
    except SystemExit:
        return 0
    if not args.command:
        ap.print_help()
        return 0
    fn = {"init": cmd_init, "show": cmd_show, "units": cmd_units, "spec": cmd_spec,
          "check": cmd_check, "build": cmd_build, "run": cmd_build,
          "selfcheck": cmd_check}.get(args.command)
    return fn(args) if fn else 0


def emergency(argv):
    try:
        try:
            args, _ = build_parser().parse_known_args(argv)
        except SystemExit:
            args = None
        out = Path(getattr(args, "output", None) or "/app/output")
        out.mkdir(parents=True, exist_ok=True)
        for name in ("manuscript.md",):
            if not (out / name).exists():
                (out / name).write_text("<!-- emergency finalize -->\n", encoding="utf-8")
        if not (out / "result.json").exists():
            dump(out / "result.json", {
                "case_id": "", "material_version": "", "status": "partial",
                "deliverable": "manuscript.md", "format_spec": [], "fidelity": [],
                "content_units": {}, "preserved_facts": [], "change_log": [],
                "result": {}, "claims": [], "uncertainties": [],
                "coverage": {"required": 0, "parsed": 0, "missing": []},
                "sources": [], "pending_human": [], "errors": ["unhandled exception"],
                "degradations": ["emergency finalize"], "deliverables": {}})
    except Exception:
        pass


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except Exception:
        try:
            sys.stderr.write(traceback.format_exc())
        except Exception:
            pass
        emergency(sys.argv[1:])
    sys.exit(0)

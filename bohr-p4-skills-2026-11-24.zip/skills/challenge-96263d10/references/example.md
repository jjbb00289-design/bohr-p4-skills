# 最小调用示例（示例，非正式案例结果）

> ⚠️ **人工构造的演示示例，不是平台固定案例的结果，也不来自任何真实稿件或期刊模板。**

## 1. 假设输入（虚构）

```
/input/
  case.json      # {"case_id":"demo-fmt","source_path":"materials/draft.md",
                 #  "template_path":"materials/template.md","output_contract":{...}}
  task.md
  materials/draft.md      # 稿件（含表、公式、图、脚注）
  materials/template.md   # 模板要求
```

`materials/draft.md`（虚构）：

```markdown
[1] The control group reached 12.4 % of baseline after 30 min.[^1]

| Condition | Rate |
|---|---|
| control | 12.4 |
| treated | 18.9 |

[2] The rate follows pseudo-first-order kinetics:

$$ C(t) = C_0 e^{-kt} $$

![Figure 1](fig1.png)
```

`materials/template.md`（虚构）：

```markdown
[1] Manuscripts must be single column.
[2] Body text: Times New Roman 10.5 pt, 1.5 line spacing.
[3] Margins: 2.5 cm on all sides.
[4] Headings: up to three levels.
[5] Figures captions: "Fig. 1." bold label. Tables: "Table 1".
[6] References in Vancouver style.
[7] Page numbers bottom centre; no table of contents.
[8] Submit as docx and pdf.
```

## 2. 调用

```bash
python3 scripts/main.py init
# → source=materials/draft.md, template=materials/template.md
# → source_units: paragraphs 6, tables 4, formulas 1, figures 1, footnotes 1, ...
python3 scripts/main.py units
python3 scripts/main.py spec
python3 scripts/main.py show --material m2
```

## 3. 工作稿（虚构）

```json
{
  "case_id": "demo-fmt",
  "deliverable": "manuscript.md",
  "manuscript": "# Results\n\nThe control group reached 12.4 % of baseline after 30 min.^1\n\n[table]…\n\n$$ C(t) = C_0 e^{-kt} $$\n\n![Fig. 1. Caption](fig1.png)\n",
  "format_spec": [
    {"spec_id": "s1", "category": "columns", "value": "1", "unit": "column", "locator": "m2#P1"},
    {"spec_id": "s2", "category": "font_family", "value": "Times New Roman", "unit": "", "locator": "m2#P2"},
    {"spec_id": "s3", "category": "font_size", "value": "10.5", "unit": "pt", "locator": "m2#P2"},
    {"spec_id": "s4", "category": "line_spacing", "value": "1.5", "unit": "multiple", "locator": "m2#P2"},
    {"spec_id": "s5", "category": "margins", "value": "2.5", "unit": "cm", "locator": "m2#P3"},
    {"spec_id": "s6", "category": "heading_levels", "value": "3", "unit": "levels", "locator": "m2#P4"},
    {"spec_id": "s7", "category": "caption_style", "value": "Fig. N. bold label", "unit": "", "locator": "m2#P5"},
    {"spec_id": "s8", "category": "reference_style", "value": "Vancouver", "unit": "", "locator": "m2#P6"},
    {"spec_id": "s9", "category": "page_numbers", "value": "bottom centre", "unit": "", "locator": "m2#P7"},
    {"spec_id": "s10", "category": "toc", "value": "not required", "unit": "", "locator": "m2#P7"},
    {"spec_id": "s11", "category": "export_format", "value": "docx + pdf", "unit": "", "locator": "m2#P8"}
  ],
  "fidelity": [
    {"unit": "paragraphs", "before": 6, "after": 6, "status": "preserved"},
    {"unit": "tables", "before": 4, "after": 4, "status": "preserved"},
    {"unit": "formulas", "before": 1, "after": 1, "status": "preserved"},
    {"unit": "figures", "before": 1, "after": 1, "status": "preserved"},
    {"unit": "footnotes", "before": 1, "after": 1, "status": "preserved"}
  ],
  "after_units": {"paragraphs": 6, "tables": 4, "formulas": 1, "figures": 1, "footnotes": 1},
  "change_log": [
    {"change_id": "ch1", "action": "set_columns", "original": "2 columns",
     "revised": "1 column", "reason": "template requires single column", "locator": "m2#P1"},
    {"change_id": "ch2", "action": "restyle_captions", "original": "Figure 1",
     "revised": "Fig. 1.", "reason": "caption style", "locator": "m2#P5"}
  ],
  "preserved_facts": [
    {"fact_id": "f1", "value": "12.4", "unit": "%", "source_id": "m1",
     "locator": "m1#P1", "quote": "The control group reached 12.4 % of baseline after 30 min.",
     "status": "preserved"}
  ],
  "uncertainties": [],
  "pending_human": []
}
```

## 4. 产物

```
/app/output/
  result.json
  manuscript.md          # 可编辑源
  manuscript.docx        # 真实 OOXML 可编辑源（styles.xml 写入字体/字号/行距）
  manuscript.pdf         # 导出预览（无 LaTeX 时 matplotlib 近似排布）
  content_map.json       # 每个存活单元 -> 来源定位 + 成品行号
  format_spec.md
  fidelity_report.json
  change_log.json
  preserved_facts.json
  report.md
```

`content_map.json` 片段（虚构）：

```json
{"tables": [{"unit": "table_1", "source": "materials/draft.md", "locator": "L5"}],
 "formulas": [{"unit": "formula_1", "source": "materials/draft.md", "locator": "L12"}],
 "figures": [{"unit": "figure_1", "source": "materials/draft.md", "locator": "L14"}]}
```

`fidelity_report.json` 片段（虚构）：

```json
{"source_units": {"paragraphs": 6, "tables": 4, "formulas": 1, "figures": 1, "footnotes": 1},
 "fidelity": [{"unit": "tables", "before": 4, "after": 4, "status": "preserved"}]}
```

## 5. 被 check 拦住的写法

| 写法 | check 反应 |
|---|---|
| 只写 5 类规格 | `format_spec covers 5 categor(ies) < required 8` |
| `fidelity.tables.before` 写 3（实际 4） | `tables before=3 disagrees with the mechanically counted 4 in the source document` |
| `after=3` 却写 `status: preserved` | `tables claims preserved but after=3 != before=4` |
| `after=3` 且无 note | `tables lost 1 unit(s) without a note` |
| 漏掉 `formulas` 一类 | `fidelity does not account for non-zero source unit(s): formulas` |
| `change_log` 缺 `original` | `ch1 missing original` |
| 没写 `manuscript` | `draft.manuscript is empty; the adapted document body is the deliverable` |
| `after` 填 2 但成品实际有 4 张表 | `tables after=2 disagrees with the mechanically counted 4 in the adapted manuscript` |
| `quote` 写成改写句 | `f1 quote not found verbatim in the source material: '…'` |

## 6. 降级示例

### 无工作稿直接 build

```json
{"ok": true, "command": "build", "status": "partial",
 "degradations": ["draft.json missing; produced degraded minimal deliverable",
                  "manuscript.md fell back to a placeholder (no draft body)"]}
```

七件产物仍生成（`manuscript.md` 为占位），契约键零缺失，退出码 0。

### 模板是 PDF/DOCX

`init` 会把模板材料登记为二进制并在 `notes` 写
`binary document: counts unavailable without an office renderer`。
此时规格仍要写 `locator`（指向你实际看到的页/段），并记 `degradations`。

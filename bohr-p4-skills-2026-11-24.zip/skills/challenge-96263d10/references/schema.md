# 字段定义与判据（格式与模板适配）

> 版本 2.1.0。字段只做追加，不改已有键名。
> 核心原则：**规格要能指回模板，内容要能数得回来，产物要能打开核验。**

## 顶层

| 字段 | 必填 | 说明 |
|---|---|---|
| `case_id` | ✅ | 原样取自 `/input/case.json` |
| `deliverable` | ✅ | 主产物路径，`"manuscript.md"` |
| `format_spec` | ✅ | 格式规格表（见 §1） |
| `fidelity` | ✅ | 内容单元保真表（见 §2） |
| `content_units` | | `{before, after}` 汇总 |
| `content_map` | ✅ | 每个存活单元 → 来源定位 + 成品行号（见 §2.1） |
| `change_log` | ✅ | 每处格式动作（见 §3） |
| `preserved_facts` | | 数字/单位等不变事实（复用写作赛道契约） |
| `coverage` | ✅ | `{required, parsed, missing}`，按 11 类规格算 |
| `claims` / `uncertainties` / `sources` / `pending_human` | ✅ | 契约字段 |
| `errors` / `degradations` | ✅ | 空数组也要有 |
| `deliverables` | | 产物文件名映射 |
| `derived` | | `true` 表示空 work 下由脚本从 `/input` 派生，非人工填 draft |
| `font_applied` | | 实际写进可编辑产物的字体（revision3 为 `Liberation Serif`） |
| `self_check` | | `{passed, fail_count, quote_hit_rate, fails}` |

`result` 内另存 `{source, template, format_spec, fidelity, change_log, content_units, coverage, deliverables}`。

## 1. format_spec[i]

| 字段 | 必填 | 说明 |
|---|---|---|
| `spec_id` | | `s1` |
| `category` | ✅ | 11 类之一（见下） |
| `value` | ✅ | 字面值：`1`、`10.5`、`2.5`、`Vancouver`、`docx+pdf` |
| `unit` | | `column`/`pt`/`cm`/`multiple`/`""` |
| `locator` | ✅（建议） | 模板里规定这一项的位置，`m2#p1` |
| `applied_at` | | 成品里体现的位置，`manuscript.md#L1` |

### 11 类

| category | 典型值 |
|---|---|
| `columns` | `1`（column） |
| `margins` | `2.5`（cm，左右/上下分别记） |
| `font_family` | `Times New Roman` |
| `font_size` | `10.5`（pt） |
| `line_spacing` | `1.5`（multiple）或 `double` |
| `heading_levels` | `3`（级） |
| `caption_style` | `Fig. 1.` / `Table 1` 加粗 |
| `reference_style` | `Vancouver` / `APA 7` |
| `page_numbers` | `bottom center` |
| `toc` | `required` / `not required` |
| `export_format` | `docx + pdf` |

`check` 要求**覆盖 ≥8 类**；缺的进 `coverage.missing`，并在 `pending_human` 说明为什么不知道。

## 2. fidelity[i]

| 字段 | 必填 | 说明 |
|---|---|---|
| `unit` | ✅ | 8 类单元之一 |
| `before` | ✅ | **必须等于 `init` 的机械计数** |
| `after` | ✅ | 用 `units --after <成品>` 数出来 |
| `status` | ✅ | `preserved` / `changed` / `dropped` |
| `note` | 当 `after != before` | 差在哪、去哪了 |

### 8 类单元

`paragraphs` · `tables` · `formulas` · `figures` · `footnotes` · `comments` ·
`revisions` · `field_codes`

### 判定规则（`check` 机械执行）

1. `before` 与源文档机械计数不等 → **FAIL**（你数错了，或源文档已被改动）。
2. `status == "preserved"` 但 `after != before` → **FAIL**（自相矛盾）。
3. `after < before` 且无 `note` → **FAIL**（内容丢失无解释）。
4. 源文档里非零的单元类没出现在 `fidelity` → **FAIL**（漏检）。
5. `status` 不在三枚举 → **FAIL**。
6. `after` 与 `check` 从 `manuscript` 机械数出的值不等 → **FAIL**（`after` 必须可复算）。
7. `preserved_facts[].quote` 无法在材料中逐字命中 → **FAIL**（引文被改写或编造）。

**"转得全"就是这 5 条。** 把这 5 条写进你的工作习惯，比写任何说明都有效。

## 2.1 content_map（产物可核验性）

`content_map` 把每个**存活**内容单元映射到来源定位与成品定位：

```json
{
  "tables":  [{"unit": "table_1",  "source": "materials/draft.md", "locator": "L5"}],
  "formulas":[{"unit": "formula_1","source": "materials/draft.md", "locator": "L12"}],
  "figures": [{"unit": "figure_1", "source": "materials/draft.md", "locator": "L14"}],
  "headings":[{"unit": "heading_1","source": "materials/draft.md", "locator": "L1"}]
}
```

`locator` 是成品 `manuscript.md` 的**行号**（`L{n}`），评审打开成品按行号即可逐项核对。
`fidelity` 里标 `changed`/`dropped` 的单元，其条目附 `status` 与 `note` 说明去向。

## 3. change_log[i]

| 字段 | 必填 | 说明 |
|---|---|---|
| `change_id` | | `ch1` |
| `action` | ✅ | `set_columns` / `set_font` / `renumber_captions` / `restyle_refs` / `move_to_supplementary` … |
| `original` | ✅ | 改前 |
| `revised` | ✅ | 改后 |
| `reason` | | 为什么改（模板哪条要求） |
| `locator` | ✅ | 依据位置（模板或稿件） |

四要素缺一即 FAIL。**只写 reason 不写 original/revised 是最常见的 FAIL。**

## 4. 为什么 `before` 要与机械计数比对

因为"我以为我保留了 3 张表"和"实际还有 3 张表"是两件事。
脚本用固定规则从源文本数一遍，你填的 `before` 必须与它一致——
不一致只有两种可能：你数错了，或者你在适配时已经改了内容却没记。

这条规则把"内容保真"从**自我声明**变成**可复算的断言**，是本题最值分的检查。

## 5. 常见 FAIL 与修法

| FAIL | 原因 | 修法 |
|---|---|---|
| `format_spec covers N categor(ies) < required 8` | 规格太少 | 补类别，或把不知道的写进 `pending_human` 并仍然建条目（value 写 `unknown`） |
| `... before=%s disagrees with the mechanically counted %s` | 计数不符 | 用 `units` 的真实数 |
| `... claims preserved but after=%s != before=%s` | 自相矛盾 | 改 `status` 或修正 `after` |
| `... lost N unit(s) without a note` | 内容丢失无解释 | 补 `note` 说明去向，或恢复内容 |
| `fidelity does not account for non-zero source unit(s): formulas` | 漏检 | 补该类的行 |
| `change_log ... missing original` | 只写理由 | 补四要素 |
| `draft.manuscript is empty` | 没交成品 | 把适配后正文写进 `manuscript` |
| `... has no template locator` | 规格凭空写 | 补模板位置，或移入 `pending_human` |

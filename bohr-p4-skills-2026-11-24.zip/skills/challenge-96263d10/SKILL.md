---
name: format-adapter
description: Adapt a manuscript to a target journal template without losing content, and deliver a real editable source plus a renderable preview. Use when a case supplies a manuscript and template/format requirements and asks for a submittable document matching columns, margins, fonts, heading levels, captions, reference style, pagination and export format. Extracts traceable format specs (every one with a template locator or an explicit rule), mechanically counts content units (paragraphs/tables/formulas/figures/footnotes/comments/revisions/field codes) for before-vs-after fidelity, emits a content_map locating every surviving unit, builds a real .docx editable source and a PDF preview, and keeps a change log with original->revised->reason->locator. A single `run`/`build` with an empty work dir derives the whole adaptation from /input (no agent-filled draft required). A check step rejects specs without evidence, counts that disagree with the source, and rewritten quotes.
version: 2.1.0
---

# 学术格式与模板适配（format-adapter）

把真实稿件按目标模板适配到**可交付**，同时**不丢正文、图表、公式、脚注、批注、修订、域代码**，
并交出**能打开的可编辑源文件 + 可预览的导出件 + 可逐条回溯的证据**。

四个硬问题，按这个顺序做：

1. **认得准**：栏数、字号、行距、页边距、标题层级、题注、参考文献样式、页码、目录、导出格式，
   每项都从模板原文抽出来，带 `locator`（材料 + 页/段/行），不许凭经验猜。
2. **排得对**：规格要落到成品里，每条带 `applied_at`（成品哪一处体现了它），不是"看起来像"。
3. **转得全**：内容单元前后**机械计数一致**，表格/公式/图/脚注不删除、不合并不改写、不图片化。
4. **交得出**：`manuscript.md`（可编辑）、`manuscript.docx`（真实 OOXML 可编辑）、
   `manuscript.pdf`（预览）、`content_map.json`（每个单元 → 来源定位 + 成品定位）。

## 何时使用

题面给真实稿件 + 目标模板/格式要求，要求套用模板、转换格式、统一引用样式或产出可交付成品。

不适用：只润色文字、只给排版建议、没有任何模板信息却要凭空写规格。

## 硬规则（先读，违者 check 会 FAIL）

1. **每条规格带模板 locator**：`category`/`value`/`unit`/`locator`/`applied_at`。
   拿不到出处的进 `pending_human`，绝不编造。
2. **规格覆盖 ≥8 类**，`check` 会拦。类别见 `spec` 子命令输出的 11 类。
3. **每条事实结论带逐字 quote**：`preserved_facts[].quote` 必须在材料中逐字命中
   （只容忍空白差异，保留大小写与标点）。改写、近义词、拼接都判 FAIL。
4. **内容单元前后计数必须与机械计数一致**：`fidelity[].before` = `init` 数出的源文档值，
   `fidelity[].after` = `units --after` 数出的成品值；不符即 FAIL。
5. **`after != before` 必须说明**：`status` 用 `changed`/`dropped` 且写 `note`；
   写 `preserved` 却数字不等 = FAIL。
6. **源文档非零的单元类必须全部覆盖**（有公式就要报公式计数）。
7. **`change_log` 四要素**：`action`/`original`/`revised`/`locator`，缺一 FAIL。
8. **`output_contract` 每个键原样回填**；拿不到填 `null` 并记入 `degradations`。
9. **status 只在硬线全达标时写 `ok`**：规格≥8 类、fidelity 无 FAIL、quote 全命中、
   manuscript 非空、产物齐全。有一条不达标就写 `partial` 并说清缺什么。禁止假 `ok`。
10. **退出码恒 0**；任何异常都产出合法最小交付并记入 `errors`。

## 单命令主路径（空 work 也能出完整文档）

```bash
# 推荐：一条命令，从 /input 自动派生模板规格与适配文档，不需要写 draft.json
python3 scripts/main.py run
# 等价于 init + 自动派生 draft + check + build

# 需要人工控制规格/正文时，仍可写 /app/work/draft.json 后 build：
python3 scripts/main.py init
python3 scripts/main.py show --material m2   # 读模板原文（逐字抽取规格）
python3 scripts/main.py units                # 看 before 计数
python3 scripts/main.py spec                 # 看 11 类规格
#  你读模板与稿件写 /app/work/draft.json（可选，会覆盖自动派生）
python3 scripts/main.py check                # 机械校验（规格覆盖/计数一致/改动留痕/quote 逐字）
python3 scripts/main.py build                # 组装 md+docx+pdf+content_map+JSON+report
```

> **`run`/`build` 会自动兜底**：当 `/app/work/draft.json` 缺失、不是 JSON 或 `manuscript`
> 为空时，脚本从 `/input` 的源文档与模板**确定性派生**完整适配结果（`result.derived: true`），
> 不再要求执行 Agent 手工填写 draft。规格值来自模板原文（带 locator）或显式 `rule:` 默认；
> 事实/数字/引用按源文本逐字切片，quote 命中率按构造为 1.0。
> 写 draft.json 只是为了**人工微调**，不是完成任务的必要条件。

## 输入与输出

| 项 | 路径 |
|---|---|
| 输入 | `/input/case.json`（`case_id`、`output_contract`、可能含 `source_path`/`template_path`）、`/input/task.md`、稿件与模板 |
| 工作区 | `/app/work/`（`index.json`、`draft.json`、`check_report.json`） |
| 产物 | `/app/output/`（见下表） |

`build`/`run` 产出的文件：

| 文件 | 性质 | 作用 |
|---|---|---|
| `result.json` | 必需 | 契约键 + 信封 + 证据 + 状态 |
| `manuscript.md` | 可编辑源 | 主交付正文 |
| `manuscript.docx` | 可编辑源 | 真实 OOXML，Word 可打开，字体/字号/行距写入 styles.xml |
| `manuscript.pdf` | 导出预览 | 无 LaTeX/Office 时由 matplotlib 排布，属近似预览（记 degradations） |
| `content_map.json` | 可核验 | 每个存活单元 → 来源定位 + 成品行号 |
| `format_spec.md` | 可核验 | 规格表（类别/值/单位/模板 locator/成品 applied_at） |
| `fidelity_report.json` | 可核验 | 内容单元前后计数 |
| `change_log.json` | 可核验 | 每处格式动作 |
| `preserved_facts.json` | 可核验 | 数字/术语/关键论断 + 逐字 quote |
| `report.md` | 汇总 | 状态 + 规格 + 计数 + 改动 + self_check |

路径可用 `--input/--work/--output` 覆盖。只用 Python 标准库（docx 由 `zipfile` 手工组装），不联网。

## 工作稿 schema（`/app/work/draft.json`）

```json
{
  "case_id": "…",
  "deliverable": "manuscript.md",
  "title": "可选：成品标题",
  "manuscript": "适配后的完整正文（Markdown）",
  "format_spec": [
    {"spec_id": "s1", "category": "columns", "value": "1", "unit": "column",
     "locator": "m2#P1", "applied_at": "manuscript.md#L1"}
  ],
  "fidelity": [
    {"unit": "tables", "before": 3, "after": 3, "status": "preserved"},
    {"unit": "figures", "before": 2, "after": 1, "status": "dropped",
     "note": "图 2 按模板要求移入补充材料，正文不含"}
  ],
  "after_units": {"tables": 3, "figures": 1, "paragraphs": 42},
  "change_log": [
    {"change_id": "ch1", "action": "set_columns", "original": "2 columns",
     "revised": "1 column", "reason": "template requires single column", "locator": "m2#P1"}
  ],
  "preserved_facts": [
    {"fact_id": "f1", "value": "12.4", "unit": "%", "source_id": "m1",
     "locator": "m1#P1", "quote": "…逐字…", "status": "preserved"}
  ],
  "uncertainties": [{"item": "行距", "why": "模板只说 single-spaced，未给倍数"}],
  "pending_human": ["确认是否需要双栏首页"]
}
```

## 11 类格式规格（`spec` 可随时查）

`columns` 栏数 · `margins` 页边距 · `font_family` 字体 · `font_size` 字号 ·
`line_spacing` 行距 · `heading_levels` 标题层级 · `caption_style` 图表题注 ·
`reference_style` 参考文献样式 · `page_numbers` 页码 · `toc` 目录 · `export_format` 导出格式

每类填 `value`（字面值）+ `unit` + `locator`（模板哪一处规定）+ `applied_at`（成品哪里体现）。
**`locator` 是"认得准"的证据；`applied_at` 是"排得对"的证据。**

## 内容单元保真 + content_map（本题最核心的可核验点）

`init` 从源文档机械数出 8 类单元：

| 单元 | 怎么数 |
|---|---|
| `paragraphs` | 按空行分块 |
| `tables` | Markdown 表格行 / `<table>` / `\begin{table}` |
| `formulas` | `$$…$$`、`$…$`、`\begin{equation\|align}` |
| `figures` | `![](…)`、`<figure`、`\begin{figure}`、`<w:drawing>` |
| `footnotes` | `[^1]`、`\footnote{}`、`<w:footnoteReference>` |
| `comments` | `<!-- -->`、`<w:commentReference>` |
| `revisions` | `<w:ins>`/`<w:del>`、`~~…~~` |
| `field_codes` | `<w:fldChar>`/`<w:instrText>`、`{{…}}` |

`fidelity[].before` 必须等于 `init` 的机械计数；`after` 用 `units --after` 对成品数一遍再填。

`content_map.json` 由 `build` 自动生成：把每个**存活**单元（表格/公式/图/脚注/标题）映射到
`{unit, source, locator(L{n})}`；`fidelity` 里标 `changed`/`dropped` 的单元记来源与 `note`。
评审据此打开成品、按行号逐项核对，而不是只信自述。

## 降级表（遇到就照做）

| 情况 | 处置 | 记录位置 |
|---|---|---|
| 空 work 直接 `run`/`build` | 自动从 `/input` 派生规格与文档，`result.derived: true` | `degradations` |
| 模板是 PDF/DOCX 二进制 | 记 `degradations`，用 pdf-text/office 工具读；规格仍要给 locator | `degradations` |
| 模板没给某项要求 | 用显式 `rule:` 默认并写进 `rule`，或进 `pending_human`，不编造模板值 | `format_spec` / `pending_human` |
| 模板缺失 | 全 11 类按 `rule:default` 落值；字体仍按 revision3 用 Liberation Serif | `degradations` / `pending_human` |
| 稿件是 DOCX/PDF | 文本层可读则计数；无文本层在 `fidelity.note` 说明 | `fidelity` |
| 内容必须删减 | `status:"dropped"` + `note` 写清去向 | `fidelity` |
| 图片化代替公式/表格 | **禁止**：必须保持可编辑，否则算内容丢失 | — |
| 无 LaTeX/Office 渲染器 | PDF 用 matplotlib 近似预览，记 `degradations`；docx 由脚本生成 | `degradations` |
| 无源文档 | `status=input_error`，最小交付 | `errors` |

**永远不要**：编造模板规格、把"看起来像"当达标、静默删除表格/脚注、公式或表格转成图片、
`after != before` 却写 `preserved`、没有真产物却写 `status: ok`。

## 自检清单

- [ ] `init` 后 `result.json` 已存在（partial），退出码 0。
- [ ] 空 work 直接 `run`/`build` 后 `result.json` 有 `derived: true`、`font_applied: "Liberation Serif"`。
- [ ] `format_spec` 覆盖 ≥8 类，每类有 `value` + `locator`（模板行或 `rule:`）+ `applied_at`。
- [ ] `fidelity` 覆盖源文档所有非零单元类，`before` 与机械计数一致，`after` 与 `units --after` 一致。
- [ ] `after != before` 的行 `status` ∈ {changed, dropped} 且有 `note`。
- [ ] `preserved_facts` 每条 `quote` 在材料中逐字命中（`check` 会验）；`self_check.quote_hit_rate ≥ 0.95`。
- [ ] `change_log` 每行四要素齐全。
- [ ] `manuscript` 非空且 >200 字符；`manuscript.docx` 为有效 OOXML；`manuscript.pdf` 可打开。
- [ ] `content_map.json` 覆盖每个存活单元，locator 行号与成品一致。
- [ ] 契约键零缺失；`status` 只在硬线全达标时为 `ok`；空/坏/缺输入分别记 `input_error`/`partial` 且仍产出合法最小交付。
- [ ] 同一输入两次运行结构一致。

## 最小调用示例

```bash
# /input: case.json + task.md + materials/draft.md(稿件) + materials/template.md(模板)
python3 scripts/main.py run
#  产物在 /app/output/：manuscript.md/.docx/.pdf、format_spec.md、fidelity_report.json、
#  change_log.json、preserved_facts.json、content_map.json、report.md、result.json
```

示意输出（**示例，非正式案例结果**）：

```json
{"case_id": "demo", "status": "ok", "derived": true,
 "coverage": {"required": 11, "parsed": 11, "missing": []},
 "font_applied": "Liberation Serif", "self_check": {"passed": true, "quote_hit_rate": 1.0},
 "deliverables": {"manuscript": "manuscript.md", "docx": "manuscript.docx",
                  "pdf": "manuscript.pdf", "content_map": "content_map.json"}}
```

字段级说明见 `references/schema.md`；完整示例见 `references/example.md`。

## 依赖与维护

- Python ≥3.8 标准库（`json`/`re`/`argparse`/`zipfile`/`pathlib`）；PDF 预览需 `matplotlib`
  （无则跳过并记 `degradations`）；docx 由 `zipfile` 手工组装，无第三方依赖；不联网。
- 版本 2.1.0。字段改动只做**追加**，不改已有键名。
- 已知限制：`manuscript.pdf` 在本环境无 LaTeX/Office 渲染器时由 matplotlib 排布，
  是**近似预览**（公式/表格以文本显示，不做排版级渲染）；正式导出件应改用
  平台提供的 latex-compiler/office-renderer 重新渲染，并在 `degradations` 说明。
  DOCX/PDF 二进制的源文档计数基于文本层，无文本层时在 `fidelity.note` 记录降级。

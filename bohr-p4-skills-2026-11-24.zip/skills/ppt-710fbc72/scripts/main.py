#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""academic-ppt-adapter: one command = full pipeline from /input to evidence-mapped deck."""
import argparse, json, os, re, shutil, subprocess, sys, zipfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import deck
import qa_common as qac
VERSION = '1.1.0'
SKILL = 'academic-ppt-adapter'
DEFAULTS = {'input': '/input', 'work': '/app/work', 'output': '/app/output'}
TEXT_EXT = {'.md', '.markdown', '.txt', '.tex', '.rst', '.csv', '.tsv', '.json', '.yaml', '.yml', '.html', '.htm'}
DOC_EXT = {'.docx'}
PDF_EXT = {'.pdf'}
DECK_EXT = {'.pptx', '.potx'}
IMG_EXT = {'.png', '.jpg', '.jpeg', '.gif', '.bmp'}
FIG_PAT = re.compile('(Fig(?:ure|\\.)?\\.?\\s*\\d+[a-z]?|Table\\s*\\d+|Eq(?:uation)?\\.?\\s*\\d+|Scheme\\s*\\d+)', re.I)
NUM_PAT = re.compile('-?\\d+(?:\\.\\d+)?\\s*(?:%|±|×|ms|s|mm|nm|μm|µM|mM|M|mV|V|℃|°C|K|Hz|MHz|GHz|dB|mg|g|kg|mL|L|W|J|Pa|nM|pM)?\\b')
ROLES = ['background', 'method', 'result', 'limitation', 'conclusion']
HINTS = {'background': 'problem challenge however although despite gap limited motivation objective herein we propose aim goal', 'method': 'method using dataset model algorithm pipeline architecture experimental protocol setup parameters collected samples framework trained evaluated', 'result': 'result figure fig. table showed found achieved obtained increased decreased compared performance accuracy precision recall improve higher lower outperform reached yield', 'limitation': 'limitation limited future work further however caution small sample cannot does not remains', 'conclusion': 'conclusion summary overall conclude demonstrate future work in conclusion these findings we show'}
SECT = 'abstract:background|summary:background|introduction:background|background:background|related work:background|motivation:background|method:method|methods:method|materials:method|experimental:experimental|experiment:experimental|approach:method|implementation:method|model:method|result:result|results:result|evaluation:result|discussion:discussion|limitation:limitation|limitations:limitation|conclusion:conclusion|conclusions:conclusion|future work:conclusion|acknowledg:skip|reference:skip|摘要:background|引言:background|背景:background|相关工作:background|方法:method|实验:method|结果:result|讨论:discussion|局限:limitation|结论:conclusion|参考文献:skip|致谢:skip'
SECTION_KW = [tuple(p.split(':')) for p in SECT.split('|')]

def jdump(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    t = path.with_name(path.name + '.tmp')
    t.write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    t.replace(path)

def jload(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8', errors='replace').lstrip('\ufeff'))
    except Exception:
        return default

def read_text(path):
    data = Path(path).read_bytes()
    for enc in ('utf-8', 'utf-8-sig', 'gb18030', 'latin-1'):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode('utf-8', 'replace')

def norm(s):
    return re.sub('\\s+', '', re.sub('[\\u200b\\u200c\\u200d\\ufeff]', '', str(s))).lower()

def resolve_io(argv):
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument('--input')
    p.add_argument('--work')
    p.add_argument('--output')
    ns, _ = p.parse_known_args(argv)
    return {'input': Path(ns.input or os.environ.get('INPUT_DIR') or DEFAULTS['input']), 'work': Path(ns.work or os.environ.get('WORK_DIR') or DEFAULTS['work']), 'output': Path(ns.output or os.environ.get('OUTPUT_DIR') or DEFAULTS['output'])}

def _materialize_default_template():
    import base64, os, tempfile
    b64 = Path(__file__).resolve().parent.parent / "assets" / "default_template.txt"
    if b64.exists():
        out = Path(os.environ.get("WORK_DIR") or tempfile.gettempdir()) / "default_template.pptx"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(base64.b64decode(b64.read_text(encoding="ascii")))
        return out
    return _materialize_default_template()


def tpl_path():
    return _materialize_default_template()

def find_pdf_tool():
    for name in ('pdftotext', 'pdf-text-tool'):
        p = shutil.which(name)
        if p:
            return p
    root = os.path.join(os.environ.get('LOCALAPPDATA', ''), 'com.bohrium.runtime')
    if os.path.isdir(root):
        for dp, _d, fns in os.walk(root):
            for fn in fns:
                if fn.lower() in ('pdftotext.exe', 'pdf-text-tool.exe'):
                    return os.path.join(dp, fn)
    return None

def raw_pdf_text(data):
    out = []
    for m in re.finditer(b'\\(((?:\\\\.|[^\\\\()])*)\\)\\s*Tj|<([0-9A-Fa-f\\s]+)>\\s*Tj', data):
        s = m.group(1) if m.group(1) is not None else bytes.fromhex(re.sub(b'\\s+', b'', m.group(2)))
        s = re.sub(b'\\\\([()\\\\nrt])', lambda mm: {b'(': b'(', b')': b')', b'\\': b'\\', b'n': b'\n', b'r': b'\r', b't': b'\t'}[mm.group(1)], s)
        out.append(s)
    return b'\n'.join(out).decode('utf-8', 'replace')

def extract_pdf(path):
    tool = find_pdf_tool()
    if tool:
        base = os.path.basename(tool).lower()
        cmd = [tool, '-layout', '-enc', 'UTF-8', str(path), '-'] if 'pdftotext' in base else [tool, str(path)]
        try:
            r = subprocess.run(cmd, capture_output=True, timeout=180)
            if r.returncode == 0 and r.stdout.strip():
                return r.stdout.decode('utf-8', 'replace')
        except Exception:
            pass
    return raw_pdf_text(Path(path).read_bytes())

def extract_docx(path):
    try:
        with zipfile.ZipFile(str(path)) as z:
            xml = z.read('word/document.xml')
    except Exception:
        return ''
    ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    return '\n'.join((''.join((t.text or '' for t in p.iter('{%s}t' % ns['w']))) for p in ET_from(xml).iter('{%s}p' % ns['w'])))

def ET_from(xml):
    from xml.etree import ElementTree as ET
    return ET.fromstring(xml)

def reflow(text):
    out, buf = ([], '')
    for ln in text.split('\n'):
        s = ln.strip()
        if not s:
            if buf:
                out.append(buf)
                buf = ''
            continue
        if buf and re.search('[.!?。！？]\\s*$', buf) and re.match('^[A-Z0-9\\u4e00-\\u9fff]', s):
            out.append(buf)
            buf = s
        else:
            buf = buf + ' ' + s if buf else s
    if buf:
        out.append(buf)
    return '\n\n'.join(out)

def discover(d):
    return [p for p in sorted(d.rglob('*')) if p.is_file() and p.name not in ('case.json', 'task.md')] if d.is_dir() else []

def build_materials(input_dir, files):
    mats, assets, decks = ([], {}, [])
    mid = [0]

    def nxt():
        mid[0] += 1
        return 'm%d' % mid[0]
    for f in files:
        ext = f.suffix.lower()
        if ext in PDF_EXT:
            m = nxt()
            mats.append({'id': m, 'path': str(f), 'type': 'pdf', 'segments': [{'locator': '%s#p%d' % (m, i + 1), 'text': s} for i, s in enumerate((reflow(p) for p in extract_pdf(f).split('\x0c'))) if s.strip()]})
        elif ext in DOC_EXT:
            m = nxt()
            mats.append({'id': m, 'path': str(f), 'type': 'docx', 'segments': [{'locator': '%s#p%d' % (m, i + 1), 'text': s.strip()} for i, s in enumerate(extract_docx(f).split('\n')) if s.strip()]})
        elif ext in TEXT_EXT:
            m = nxt()
            text = read_text(f)
            if ext in ('.csv', '.tsv'):
                mats.append({'id': m, 'path': str(f), 'type': 'table', 'segments': [{'locator': '%s#row%d' % (m, i + 1), 'text': s.strip()} for i, s in enumerate(text.splitlines()) if s.strip()]})
            else:
                mats.append({'id': m, 'path': str(f), 'type': 'text', 'segments': [{'locator': '%s#p%d' % (m, i + 1), 'text': s} for i, s in enumerate((line.strip() for line in text.splitlines())) if s]})
        elif ext in IMG_EXT:
            assets[str(f)] = str(f)
        elif ext in DECK_EXT:
            decks.append(f)
        else:
            m = nxt()
            mats.append({'id': m, 'path': str(f), 'type': 'unknown', 'segments': [{'locator': '%s#0' % m, 'text': str(f)}]})
    return (mats, assets, decks)

def is_heading(line):
    line = line.strip()
    if not line or len(line) > 90 or re.match('^(figure|fig\\.?|table)\\s+\\d', line, re.I):
        return False
    if re.match('^\\s*(#+\\s|\\d+(\\.\\d+)*[\\.、\\)]\\s|[一二三四五六七八九十]+[、.]\\s)', line):
        return True
    if len(line) <= 60 and line.isupper():
        return True
    low = line.lower()
    return any((low == kw or low.startswith(kw + ' ') for kw, _ in SECTION_KW))

def split_sentences(text):
    return qac.split_sentences(text)

def collect_sentences(mats):
    return qac.collect_sentences(mats, FIG_PAT, NUM_PAT)

def score(s, role):
    low = s['text'].lower()
    sc = sum((1 for h in HINTS[role].split() if h in low))
    if role == 'result':
        sc += min(len(s['numbers']), 6) + 3 * len(s['figures'])
    if s['section'] == role:
        sc += 2
    elif s['section'] == 'discussion' and role in ('result', 'limitation', 'conclusion'):
        sc += 1
    return sc

def candidates(sents, role, used):
    cs = [s for s in sents if norm(s['text']) not in used]
    cs.sort(key=lambda s: (-score(s, role), abs(len(s['text']) - 140)))
    return cs

def bullets(sentence, n=3):
    prot = re.sub('(?<=\\d),(?=\\d)', '\x00', sentence)
    frags = re.split('\\s*[,;:—–]\\s*|\\s+\\band\\b\\s+|\\s+\\bor\\b\\s+|\\s+\\.\\s+', prot)
    out, seen = ([], set())
    for f in frags:
        f = f.replace('\x00', ',').strip()
        if 8 <= len(f) <= 160 and norm(f) not in seen:
            seen.add(norm(f))
            out.append(f)
        if len(out) >= n:
            break
    return out or [sentence[:160]]

def title_of(case, mats):
    for k in ('title', 'title_zh', 'deck_title'):
        if isinstance(case.get(k), str) and case.get(k).strip():
            return case.get(k).strip()[:90]
    for m in mats:
        for seg in m['segments'][:3]:
            t = seg['text'].strip()
            if t and (not is_heading(t)):
                return t[:90]
    return 'Academic Presentation'

def slide_count(case):
    for src in (case, case.get('constraints') or {}):
        for k in ('slide_count', 'slides', 'max_slides', 'num_slides', 'page_limit'):
            if isinstance(src.get(k), int) and 2 <= src.get(k) <= 60:
                return src.get(k)
    return 9

def derive_pages(mats, case):
    sents, heads = collect_sentences(mats)
    if not sents:
        return ([], heads)
    title = title_of(case, mats)
    n = slide_count(case)
    rest = max(n - 1, 1)
    bg = max(1, round(rest * 0.18))
    meth = max(1, round(rest * 0.22))
    concl = 1
    lim = 1 if any((score(s, 'limitation') >= 1 for s in sents)) else 0
    res = rest - bg - meth - concl - lim
    if res < 1:
        res = 1
        if bg + meth + res + concl + lim > n and bg > 1:
            bg -= 1
    plan = [('title', 1)] + [(r, 1) for r, c in (('background', bg), ('method', meth), ('result', res), ('limitation', lim), ('conclusion', concl)) for _ in range(c)]
    used = set()
    pages = []
    first = candidates(sents, 'background', set())
    sub = first[0] if first else None
    pages.append({'role': 'title', 'title': title, 'claim': sub['text'][:200] if sub else '', 'bullets': [], 'claim_loc': sub['locator'] if sub else None, 'claim_quote': sub['text'] if sub else None})
    if sub:
        used.add(norm(sub['text']))
    pools = {r: candidates(sents, r, used) for r in ROLES}
    for role, _ in plan[1:]:
        pool = pools.get(role)
        sent = None
        if pool:
            while pool and norm(pool[0]['text']) in used:
                pool.pop(0)
            if pool:
                sent = pool.pop(0)
                used.add(norm(sent['text']))
        if sent is None:
            for s in sents:
                if norm(s['text']) not in used:
                    sent = s
                    used.add(norm(s['text']))
                    break
        if sent is None:
            continue
        head = heads.get(role)
        pages.append({'role': role, 'title': head['text'] if head else bullets(sent['text'], 1)[0][:60], 'claim': sent['text'], 'bullets': bullets(sent['text'], 4), 'claim_loc': sent['locator'], 'claim_quote': sent['text'], 'figure_refs': sent['figures']})
    return (pages, heads)

def notes(page, nxt):
    trans = {'title': '开场：说明报告范围与来源。', 'background': '过渡：先讲问题与动机。', 'method': '强调：方法如何回答研究问题。', 'result': '强调：数值与图表编号需与论文一致。', 'limitation': '诚实说明局限。', 'conclusion': '总结主线并展望。'}.get(page.get('role'), '')
    return [trans, '强调点: %s' % (page.get('claim') or '')[:100], '证据定位: %s' % (page.get('claim_loc') or ''), '被追问时: 引用 content_map.json 逐字 quote。'] + (['下一页: %s' % nxt] if nxt else [])

def find_template(case, files, input_dir):
    pptx = [f for f in files if f.suffix.lower() in ('.pptx', '.potx')]

    def ref(v):
        if not isinstance(v, str) or not v.strip():
            return None
        p = Path(v)
        cand = p if p.is_absolute() else input_dir / p
        return cand if cand.exists() else None
    tpl = ref(case.get('template') or case.get('template_path') or case.get('template_file'))
    dk = ref(case.get('deck') or case.get('starting_deck') or case.get('start_deck') or case.get('deck_path'))
    rest = [f for f in pptx if f != tpl and f != dk]
    if tpl is None and dk is None:
        if len(pptx) == 1:
            return (pptx[0], None)
        cs = []
        for f in pptx:
            try:
                cs.append((f, len(deck.analyze(f)['slides'])))
            except Exception:
                cs.append((f, 0))
        cs.sort(key=lambda x: x[1])
        return (cs[0][0], cs[-1][0] if len(cs) > 1 else None) if cs else (None, None)
    if tpl is None and rest:
        tpl = rest[0]
    if dk is None and rest:
        dk = rest[-1]
    return (tpl, dk)

def image_name_info(path):
    name = Path(path).stem.lower()
    nums = re.findall('\\d+', name)
    kinds = []
    for k in ('fig', 'figure', 'chart', 'plot', 'table', 'scheme', 'image', 'pic', 'img'):
        if k in name:
            kinds.append('table' if k == 'table' else 'figure')
    return {'path': str(path), 'nums': nums, 'kinds': kinds}

def match_images(pages, assets):
    imgs = [image_name_info(p) for p in sorted(assets.values())]
    used = set()
    for pg in pages:
        pg['figure'] = None
        for ref in pg.get('figure_refs') or []:
            m = re.search('(\\d+)', ref)
            num = m.group(1) if m else None
            kind = 'table' if 'table' in ref.lower() else 'figure'
            for info in imgs:
                if info['path'] in used:
                    continue
                if num is not None and num in info['nums'] and (kind in info['kinds'] or not info['kinds']):
                    pg['figure'] = info['path']
                    used.add(info['path'])
                    break
            if pg['figure']:
                break
    return imgs

def build_media(assets, used_figures):
    media = {}
    for path in assets.values():
        if path not in used_figures:
            continue
        data = Path(path).read_bytes()
        dim = deck.image_size(data)
        if dim is None:
            continue
        media[str(path)] = {'path': path, 'data': data, 'w': dim[0], 'h': dim[1]}
    return media

def fill(k, editable, export, cm, notes, plan, previews, n):
    kl = k.lower()
    if kl.endswith('_count') or kl in ('slides', 'pages', 'slide_count', 'page_count'):
        return n
    for ws, v in (('ppt', editable), ('presentation', editable), ('deck', editable), ('editable', editable), ('pdf', export), ('export', export), ('render', export), ('preview', previews), ('png', previews), ('content', cm), ('claim', cm), ('evidence', cm), ('map', cm), ('page', cm), ('note', notes), ('script', notes), ('speaker', notes), ('plan', plan), ('golden', plan)):
        if ws in kl:
            return v
    return None

def minimal(case_id, status, errs, mats, case):
    oc = case.get('output_contract') or {} if isinstance(case, dict) else {}
    r = {'case_id': case_id, 'status': status}
    for k in oc:
        r[k] = None
    r['output_contract'] = oc
    r['sources'] = [{'id': m['id'], 'path': m['path'], 'type': m['type']} for m in mats]
    r['uncertainty'] = ['no usable evidence extracted']
    r['changes'] = []
    r['errors'] = errs
    r['degradations'] = []
    r['coverage'] = {'pages': 0, 'slides': 0, 'quote_hit_rate': 0.0, 'roles': []}
    r['skill'] = {'name': SKILL, 'version': VERSION}
    return r

def load_case(io):
    cp = io['input'] / 'case.json'
    if not (io['input'].is_dir() and cp.exists()):
        return (None, ['case.json not found'])
    try:
        case = json.loads(cp.read_text(encoding='utf-8', errors='replace').lstrip('\ufeff'))
        if not isinstance(case, dict):
            case = {}
    except Exception as e:
        return ({}, ['case.json invalid: %s' % e])
    return (case, [])

def run_pipeline(io, argv):
    work, out = (io['work'], io['output'])
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    jdump(out / 'result.json', {'case_id': '', 'status': 'partial', 'errors': ['pipeline started'], 'sources': [], 'uncertainty': [], 'changes': [], 'degradations': [], 'skill': {'name': SKILL, 'version': VERSION}})
    case, errs = load_case(io)
    if case is None:
        jdump(out / 'result.json', minimal('', 'input_error', errs, [], {}))
        return 0
    case_id = case.get('case_id') or case.get('id') or ''
    degs = []
    files = discover(io['input'])
    mats, assets, decks = build_materials(io['input'], files)
    for d in decks:
        try:
            parts = deck.read_package(d)
            for s in deck.extract_slide_texts(parts):
                mats.append({'id': 'deck-%s' % Path(d).stem, 'path': str(d), 'type': 'deck', 'segments': [{'locator': '%s#%s' % (d, s['part']), 'text': s['text']}]})
        except Exception:
            pass
    jdump(work / 'index.json', {'case_id': case_id, 'materials': [{'id': m['id'], 'path': m['path'], 'type': m['type'], 'segments': len(m['segments'])} for m in mats], 'assets': sorted(assets), 'decks': [str(d) for d in decks]})
    if errs:
        jdump(out / 'result.json', minimal(case_id, 'input_error', errs, mats, case))
        return 0
    if not mats:
        jdump(out / 'result.json', minimal(case_id, 'insufficient_evidence', ['no readable material'], mats, case))
        return 0
    pages, heads = derive_pages(mats, case)
    if not pages:
        jdump(out / 'result.json', minimal(case_id, 'insufficient_evidence', ['no usable sentences'], mats, case))
        return 0
    pages = qac.enrich_pages(pages, mats, FIG_PAT, NUM_PAT)
    mp = jload(work / 'plan.json')
    if isinstance(mp, dict) and isinstance(mp.get('pages'), list) and (len(mp['pages']) >= 1) and (qac.evidence(mp['pages'], mats)[0] == 1.0):
        pages = mp['pages']
        degs.append('used work/plan.json (manual page plan)')
    for i, p in enumerate(pages):
        p.setdefault('role', 'content')
        p.setdefault('title', '')
        p.setdefault('claim', '')
        p.setdefault('bullets', [])
        p.setdefault('claim_loc', '')
        p.setdefault('claim_quote', '')
        p.setdefault('figure_refs', [])
        p['notes_lines'] = notes(p, pages[i + 1]['title'] if i + 1 < len(pages) else '')
        p['footer'] = title_of(case, mats)[:60]
    match_images(pages, assets)
    used_fig = {p['figure'] for p in pages if p.get('figure')}
    media = build_media(assets, used_fig)
    tpl, dk = find_template(case, files, io['input'])
    base, mode = (tpl, 'create')
    if dk is not None and (case.get('mode') or '').lower() in ('edit', 'adapt'):
        base, mode = (dk, 'edit')
    bundled = False
    if base is None:
        base = tpl_path()
        bundled = True
        degs.append('no template supplied; used bundled default academic template')
    if mode == 'edit':
        try:
            existing = len(deck.analyze(str(base))['slides'])
        except Exception:
            existing = 0
        slots = max(0, slide_count(case) - existing)
        pages = pages[-slots:] if slots else []
        degs.append('edit mode preserves %d original slides; original slide claims are not revalidated' % existing)
    try:
        report = deck.build_deck(str(base), pages, str(out / 'presentation.pptx'), mode=mode, media=media)
    except Exception as e:
        jdump(out / 'result.json', minimal(case_id, 'partial', ['build failed: %s' % e], mats, case))
        return 0
    if report.get('errors'):
        degs.append('deck build: %s' % '; '.join(report['errors']))
    engine = deck.render_pdf_soffice(str(out / 'presentation.pptx'), str(out / 'presentation.pdf'))
    pdf = out / 'presentation.pdf'
    if not engine:
        try:
            deck.write_text_pdf(pages, str(pdf))
            engine = 'text-layer-pdf'
            degs.append('no LibreOffice; PDF is a text-layer render (Latin/WinAnsi, CJK approximated)')
        except Exception:
            degs.append('PDF export failed')
    pngs = []
    if pdf.exists():
        (out / 'preview').mkdir(parents=True, exist_ok=True)
        ppm = deck.find_tool('pdftoppm')
        if ppm:
            try:
                r = subprocess.run([ppm, '-png', '-r', '90', str(pdf), str(out / 'preview' / 'slide')], capture_output=True, timeout=120)
                if r.returncode == 0:
                    pngs = sorted(('preview/' + p.name for p in (out / 'preview').glob('slide-*.png')))
            except Exception:
                pass
    template_integrity = qac.compare_template_parts(base, out / 'presentation.pptx')
    if not template_integrity['ok']:
        degs.append('master/layout/theme byte preservation failed: %s' % template_integrity['changed_parts'])
    v = qac.verify_pptx(out / 'presentation.pptx')
    pp, hdr = deck.pdf_page_count(pdf) if pdf.exists() else (0, False)
    cn = norm('\n'.join((seg['text'] for m in mats for seg in m['segments'])))
    lp = {m['id']: m['path'] for m in mats}
    cm, hits = ([], 0)
    for i, p in enumerate(pages):
        q = p.get('claim_quote') or ''
        hit = bool(norm(q)) and norm(q) in cn
        hits += 1 if hit else 0
        loc = p.get('claim_loc') or ''
        ev = [{'type': 'sentence', 'locator': loc, 'quote': q, 'verbatim_hit': hit}]
        ev += [{'type': 'figure', 'id': fr, 'locator': loc, 'quote': q} for fr in p.get('figure_refs') or []]
        src_id = loc.split('#')[0] if loc else ''
        cm.append({'n': i + 1, 'role': p['role'], 'title': p['title'], 'claim': p['claim'], 'bullets': p['bullets'], 'source': {'path': lp.get(src_id, ''), 'locator': loc}, 'evidence': ev, 'figure_refs': p.get('figure_refs') or [], 'figure': p.get('figure'), 'notes': p['notes_lines']})
    qhr, page_hits, evidence_problems = qac.evidence(pages, mats)
    for e, good in zip(cm, page_hits):
        for ev in e.get('evidence', []):
            if ev.get('type') == 'sentence':
                ev['verbatim_hit'] = good
    base_label = 'assets/default_template.pptx' if bundled else str(base)
    expected = case.get('slide_count') or (case.get('constraints') or {}).get('slide_count')
    if isinstance(expected, int) and v['slides'] != expected:
        degs.append('slide_count mismatch: expected %d, got %d' % (expected, v['slides']))
    if not hdr or pp != v['slides']:
        degs.append('PDF page count/header invalid: pdf=%d, pptx=%d' % (pp, v['slides']))
    if engine == 'text-layer-pdf':
        degs.append('text-only PDF is NOT a visual render of PPTX; presentation quality unverified')
    if evidence_problems:
        degs.append('unverified per-page claim/bullet citations: %d' % len(evidence_problems))
    verified_render = engine == 'libreoffice' and hdr and (pp == v['slides'])
    verified_pages = not isinstance(expected, int) or v['slides'] == expected
    quality_ok = bool(pages if mode != 'edit' else v['slides']) and qhr >= 0.95 and v['ok'] and verified_render and verified_pages and template_integrity['ok'] and (mode != 'edit')
    editable = {'path': 'presentation.pptx', 'slides': v['slides'], 'mode': mode, 'template': {'path': base_label, 'master_sha256': report.get('master_sha', {}), 'layouts_used': [pg.get('layout') for pg in report.get('pages', [])], 'theme_sha256': report.get('theme_sha', {})}, 'images_embedded': len(report.get('images', [])), 'verification': v}
    export = {'pdf': {'path': 'presentation.pdf', 'engine': engine or 'none', 'pages': pp, 'header_ok': hdr}, 'previews': pngs}
    notes_out = [{'n': i + 1, 'lines': p['notes_lines']} for i, p in enumerate(pages)]
    plan = [{'n': i + 1, 'role': p['role'], 'title': p['title'], 'claim': p['claim'], 'locator': p.get('claim_loc')} for i, p in enumerate(pages)]
    sources = [{'id': m['id'], 'path': m['path'], 'type': m['type'], 'locator_scheme': 'mN#pK'} for m in mats]
    unc = (['quote_hit_rate %.3f < 1.0' % qhr] if qhr < 1.0 else []) + (['no PDF produced'] if not engine else [])
    if mode == 'edit':
        unc.append('edit mode: starting-deck slides replaced by evidence-mapped pages; master/layout/theme preserved')
    unc.extend(('evidence mismatch slide %d at %s' % (p['slide'], p['locator']) for p in evidence_problems))
    changes = [{'step': 'derive', 'action': 'extracted %d pages from %d materials' % (len(pages), len(mats))}, {'step': 'build', 'action': 'built pptx (mode=%s, base=%s)' % (mode, base_label)}, {'step': 'export', 'action': 'PDF engine=%s; %d PNG previews' % (engine or 'none', len(pngs))}]
    oc = case.get('output_contract') or {}
    status = 'ok' if quality_ok else 'partial'
    result = {'case_id': case_id, 'status': status}
    for k in oc:
        result[k] = fill(k, editable, export, cm, notes_out, plan, pngs, v['slides'])
    result['case_id'] = case_id
    result['status'] = status
    result.update({'output_contract': oc, 'editable_source': editable, 'export_artifact': export, 'content_map': cm, 'page_plan': plan, 'coverage': {'pages': len(pages), 'slides': v['slides'], 'quote_hit_rate': qhr, 'roles': [p['role'] for p in pages], 'images_embedded': len(report.get('images', []))}, 'sources': sources, 'uncertainty': unc, 'evidence_problems': evidence_problems, 'changes': changes, 'errors': [], 'degradations': degs, 'template_integrity': template_integrity, 'skill': {'name': SKILL, 'version': VERSION}})
    jdump(out / 'content_map.json', cm)
    jdump(out / 'page_plan.json', plan)
    jdump(out / 'evidence_map.json', [{'n': i + 1, 'evidence': e['evidence']} for i, e in enumerate(cm)])
    jdump(out / 'changes.json', changes)
    jdump(out / 'template_check.json', {'master_sha256': report.get('master_sha', {}), 'theme_sha256': report.get('theme_sha', {}), 'layout_sha256': report.get('layout_sha', {}), 'layouts_available': len(deck.analyze_parts(deck.read_package(out / 'presentation.pptx'))['layouts'])})
    jdump(out / 'export_check.json', {'pptx': v, 'pdf': {'pages': pp, 'header_ok': hdr, 'engine': engine or 'none'}, 'previews': len(pngs)})
    jdump(out / 'result.json', result)
    return 0

def cmd_check(io):
    out = io['output']
    ok = True
    r = jload(out / 'result.json')
    print('result.json: %s' % ('present' if r else 'MISSING'))
    ok = ok and bool(r)
    p = out / 'presentation.pptx'
    if p.exists():
        v = deck.verify_pptx(p)
        print('pptx: slides=%d ok=%s problems=%s' % (v['slides'], v['ok'], v['problems']))
        ok = ok and v['ok']
    else:
        print('pptx: MISSING')
        ok = False
    pdf = out / 'presentation.pdf'
    if pdf.exists():
        pp, hdr = deck.pdf_page_count(pdf)
        print('pdf: pages=%d header=%s' % (pp, hdr))
        ok = ok and hdr
    else:
        print('pdf: MISSING')
        ok = False
    print('CHECK %s' % ('PASS' if ok else 'FAIL'))
    return 0

def main(argv):
    if any((a in ('-h', '--help') for a in argv)):
        print('usage: python3 scripts/main.py [check] [--input DIR] [--work DIR] [--output DIR]')
        return 0
    if '--version' in argv:
        print(SKILL + ' ' + VERSION)
        return 0
    io = resolve_io(argv)
    sub = argv[0] if argv and (not argv[0].startswith('-')) else 'build'
    if sub == 'check' or sub == 'selfcheck':
        return cmd_check(io)
    return run_pipeline(io, argv)
if __name__ == '__main__':
    try:
        code = main(sys.argv[1:])
        sys.exit(code or 0)
    except SystemExit:
        raise
    except Exception:
        try:
            sys.stderr.write('unhandled error; writing emergency partial\n')
        except Exception:
            pass
        try:
            io = resolve_io(sys.argv[1:])
            io['output'].mkdir(parents=True, exist_ok=True)
            if True:
                jdump(io['output'] / 'result.json', {'case_id': '', 'status': 'partial', 'errors': ['unhandled exception'], 'sources': [], 'uncertainty': [], 'changes': [], 'degradations': ['emergency finalize'], 'skill': {'name': SKILL, 'version': VERSION}})
        except Exception:
            pass
        sys.exit(0)

import qa_common as qac
# -*- coding: utf-8 -*-
"""Pure-stdlib OOXML deck builder: template inheritance, layout/font adaptation,
figure embedding (aspect-preserving), footer/slide-number batch consistency,
and PDF/PNG export with honest degradation. No network, no CWD dependency."""
import hashlib, posixpath, re, shutil, subprocess, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

A = "http://schemas.openxmlformats.org/drawingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
P = "http://schemas.openxmlformats.org/presentationml/2006/main"
RL = "http://schemas.openxmlformats.org/package/2006/relationships"
TS, TL, TM = R + "/slide", R + "/slideLayout", R + "/slideMaster"
TN, TNM, TH = R + "/notesSlide", R + "/notesMaster", R + "/theme"
CS = "application/vnd.openxmlformats-officedocument.presentationml.slide+xml"
CNN = "application/vnd.openxmlformats-officedocument.presentationml.notesSlide+xml"
CNM = "application/vnd.openxmlformats-officedocument.presentationml.notesMaster+xml"
IMG_CT = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif",
          "bmp": "image/bmp", "tif": "image/tiff", "tiff": "image/tiff"}
W, H = 12192000, 6858000
FIXED = (2026, 1, 1, 0, 0, 0)


def sha(d):
    return hashlib.sha256(d.encode() if isinstance(d, str) else d).hexdigest()


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def ea(s):
    return esc(s).replace('"', "&quot;")


def cjk(s):
    return any("\u4e00" <= c <= "\u9fff" for c in str(s))


def read_package(p):
    with zipfile.ZipFile(str(p)) as z:
        parts = {n: z.read(n) for n in z.namelist()}
    if "[Content_Types].xml" not in parts:
        raise ValueError("not OOXML")
    return parts


def write_package(parts, p):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(str(p), "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(parts, key=lambda n: (0 if n == "[Content_Types].xml" else 1, n)):
            z.writestr(zipfile.ZipInfo(n, date_time=FIXED), parts[n])


def _rels(parts, part):
    d, n = posixpath.split(part)
    rp = posixpath.join(d, "_rels", n + ".rels")
    if rp not in parts:
        return {}
    return {rel.get("Id"): {"type": rel.get("Type"), "target": rel.get("Target")}
            for rel in ET.fromstring(parts[rp])}


def _res(base, target):
    return target.lstrip("/") if target.startswith("/") else posixpath.normpath(
        posixpath.join(posixpath.dirname(base), target))


def _ph_records(root):
    out = []
    for sp in root.iter("{%s}sp" % P):
        nv = sp.find("{%s}nvSpPr" % P)
        if nv is None:
            continue
        cnv = nv.find("{%s}cNvPr" % P)
        ph = nv.find("{%s}nvPr" % P).find("{%s}ph" % P) if nv.find("{%s}nvPr" % P) is not None else None
        if ph is None:
            continue
        xfrm = None
        sppr = sp.find("{%s}spPr" % P)
        if sppr is not None:
            x = sppr.find("{%s}xfrm" % A)
            if x is not None:
                off, ext = x.find("{%s}off" % A), x.find("{%s}ext" % A)
                try:
                    xfrm = [int(off.get("x")), int(off.get("y")), int(ext.get("cx")), int(ext.get("cy"))]
                except Exception:
                    pass
        out.append({"type": ph.get("type") or "obj", "idx": ph.get("idx") or "",
                    "name": cnv.get("name") if cnv is not None else "", "xfrm": xfrm})
    return out


def analyze_parts(parts):
    root = ET.fromstring(parts["ppt/presentation.xml"])
    masters = sorted(n for n in parts if re.match(r"ppt/slideMasters/slideMaster\d+\.xml$", n))
    layouts = sorted((n for n in parts if re.match(r"ppt/slideLayouts/slideLayout\d+\.xml$", n)),
                     key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    themes = sorted(n for n in parts if re.match(r"ppt/theme/theme\d+\.xml$", n))
    linfos = [{"part": n, "type": ET.fromstring(parts[n]).get("type") or "",
               "placeholders": _ph_records(ET.fromstring(parts[n]))} for n in layouts]
    slides, prel = [], _rels(parts, "ppt/presentation.xml")
    sl = root.find("{%s}sldIdLst" % P)
    if sl is not None:
        for sid in sl:
            rid = sid.get("{%s}id" % R) or sid.get("id")
            rel = prel.get(rid)
            if rel:
                part = _res("ppt/presentation.xml", rel["target"])
                if part in parts:
                    slides.append(part)
    if not slides:
        slides = sorted((n for n in parts if re.match(r"ppt/slides/slide\d+\.xml$", n)),
                        key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    size = [W, H]
    sz = root.find("{%s}sldSz" % P)
    if sz is not None:
        try:
            size = [int(sz.get("cx")), int(sz.get("cy"))]
        except Exception:
            pass
    return {"masters": masters, "layouts": linfos, "themes": themes, "slides": slides, "slide_size": size}


def analyze(p):
    return analyze_parts(read_package(p))


def extract_slide_texts(parts):
    out = []
    for n in sorted((x for x in parts if re.match(r"ppt/slides/slide\d+\.xml$", x)),
                    key=lambda x: int(re.search(r"(\d+)\.xml$", x).group(1))):
        txt = " ".join(t.text or "" for t in ET.fromstring(parts[n]).iter("{%s}t" % A)).strip()
        if txt:
            out.append({"part": n, "text": txt})
    return out


# ---------------- run / paragraph / shape construction ----------------
def _run(t, sz, bold=False, color="tx1", font=None):
    lang = "zh-CN" if cjk(t) else "en-US"
    latin = font or "+mn-lt"
    return ('<a:r><a:rPr lang="%s" altLang="en-US" sz="%d" b="%d" dirty="0"><a:solidFill><a:schemeClr val="%s"/>'
            '</a:solidFill><a:latin typeface="%s"/><a:ea typeface="+mn-ea"/></a:rPr><a:t>%s</a:t></a:r>'
            % (lang, int(sz * 100), 1 if bold else 0, color, latin, esc(t)))


def _para(t, sz, bold=False, bullet=None, color="tx1", font=None):
    if bullet == "dot":
        inner = '<a:buFont typeface="Arial"/><a:buChar char="\u2022"/>'
    elif bullet == "none":
        inner = '<a:buNone/>'
    else:
        inner = ""
    return "<a:p><a:pPr%s>%s</a:pPr>%s</a:p>" % (' algn="l"' if bullet == "dot" else "", inner, _run(t, sz, bold, color, font))


def _sp(sid, name, xfrm, paras, ph=None, autofit="norm"):
    phx = ('<p:ph type="%s"%s/>' % (ph[0], ' idx="%s"' % ph[1] if ph[1] else "")) if ph else '<p:nvPr/>'
    nv = '<p:nvSpPr><p:cNvPr id="%d" name="%s"/><p:cNvSpPr txBox="1"/>%s</p:nvSpPr>' % (sid, ea(name), phx)
    fill = '<a:noFill/>' if not ph else ''
    return ('<p:sp>%s<p:spPr><a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
            '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>%s</p:spPr>'
            '<p:txBody><a:bodyPr wrap="square" lIns="91440" tIns="45720" rIns="91440" bIns="45720"><a:%sAutofit/></a:bodyPr>'
            '<a:lstStyle/>%s</p:txBody></p:sp>' % (nv, xfrm[0], xfrm[1], xfrm[2], xfrm[3], fill, autofit, "".join(paras)))


def _pic_xml(sid, name, xfrm, rid, ph=None):
    phx = ('<p:nvPr><p:ph type="%s"%s/></p:nvPr>' % (ph[0], ' idx="%s"' % ph[1] if ph[1] else "")) if ph else '<p:nvPr/>'
    return ('<p:pic><p:nvPicPr><p:cNvPr id="%d" name="%s"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr>%s</p:nvPicPr>'
            '<p:blipFill><a:blip r:embed="%s"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>'
            '<p:spPr><a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>'
            '<a:ln w="9525"><a:solidFill><a:schemeClr val="accent1"/></a:solidFill></a:ln></p:spPr></p:pic>'
            % (sid, ea(name), phx, rid, xfrm[0], xfrm[1], xfrm[2], xfrm[3]))


def slide_xml(shapes):
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<p:sld xmlns:a="%s" xmlns:r="%s" xmlns:p="%s">'
            '<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
            '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
            '%s</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>' % (A, R, P, "".join(shapes)))


_NM = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<p:notesMaster xmlns:a="%s" xmlns:r="%s" xmlns:p="%s">'
       '<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
       '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
       '<p:sp><p:nvSpPr><p:cNvPr id="2" name="Notes"/><p:cNvSpPr/><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr>'
       '<p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp></p:spTree></p:cSld>'
       '<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/></p:notesMaster>' % (A, R, P))


def notes_xml(lines):
    ps = "".join("<a:p>%s</a:p>" % _run(t, 12) for t in (lines or ["(no notes)"]))
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<p:notes xmlns:a="%s" xmlns:r="%s" xmlns:p="%s">'
            '<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
            '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
            '<p:sp><p:nvSpPr><p:cNvPr id="2" name="Notes"/><p:cNvSpPr/><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr>'
            '<p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/>%s</p:txBody></p:sp></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:notes>'
            % (A, R, P, ps))


# ---------------- layout / fit / figure ----------------
def _w(s):
    return sum(0.55 if ord(c) < 128 else 1.0 for c in str(s))


def fit(bullets, title, avail_w_chars=90, avail_h=18):
    bw = max((_w(b) for b in bullets), default=0)
    size = 20 if bw <= 70 else 19 if bw <= 82 else 18 if bw <= 94 else 16 if bw <= 108 else 14 if bw <= 124 else 12
    if len(bullets) >= 6 and size > 16:
        size = 16
    est_lines = sum(max(1, int(_w(b) // (avail_w_chars * (14.0 / size)) + 0.999)) for b in bullets)
    if est_lines > avail_h and size > 12:
        size = 12
    ts = 30 if len(str(title)) <= 40 else 26 if len(str(title)) <= 60 else 22
    return size, ts


def image_size(data):
    if data[:8] == b"\x89PNG\r\n\x1a\n" and data[12:16] == b"IHDR":
        w = int.from_bytes(data[16:20], "big")
        h = int.from_bytes(data[20:24], "big")
        return w, h
    if data[:2] == b"\xff\xd8":
        i = 2
        while i + 9 < len(data):
            if data[i] != 0xFF:
                i += 1
                continue
            marker = data[i + 1]
            if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                h = int.from_bytes(data[i + 5:i + 7], "big")
                w = int.from_bytes(data[i + 7:i + 9], "big")
                return w, h
            seglen = int.from_bytes(data[i + 2:i + 4], "big")
            i += 2 + seglen
    return None


def fit_rect(container, iw, ih):
    cx, cy, cw, ch = container
    if not iw or not ih:
        return [cx, cy, cw, ch]
    scale = min(cw / iw, ch / ih)
    w, h = int(iw * scale), int(ih * scale)
    return [cx + (cw - w) // 2, cy + (ch - h) // 2, w, h]


def placeholders_of(lay):
    tp = bp = pp = None
    best = -1
    for ph in lay.get("placeholders") or []:
        if ph["type"] in ("title", "ctrTitle") and tp is None:
            tp = ph
        if ph["type"] in ("body", "obj", "subTitle") and ph.get("xfrm"):
            area = ph["xfrm"][2] * ph["xfrm"][3]
            if area > best:
                best, bp = area, ph
        if ph["type"] == "pic" and pp is None:
            pp = ph
    return tp, bp, pp


def pick_layout(layouts, role, has_figure):
    prefer = {"title": ["ctrTitle", "title"], "section": ["secHead"]}.get(role, [])
    if has_figure:
        for i, lay in enumerate(layouts):
            if "pic" in {p["type"] for p in lay["placeholders"]}:
                return i
    for typ in prefer:
        for i, lay in enumerate(layouts):
            if typ in {p["type"] for p in lay["placeholders"]}:
                return i
    for i, lay in enumerate(layouts):
        ts = {p["type"] for p in lay["placeholders"]}
        if "title" in ts and ({"body", "obj"} & ts):
            return i
    for i, lay in enumerate(layouts):
        if "title" in {p["type"] for p in lay["placeholders"]}:
            return i
    return 0 if layouts else None


# ---------------- deck build ----------------
def build_deck(base, pages, out_path, mode="create", media=None):
    parts = read_package(base) if isinstance(base, (str, Path)) else dict(base)
    info = analyze_parts(parts)
    layouts = info["layouts"]
    if not layouts:
        raise ValueError("no slideLayout")
    kept = list(info["slides"]) if mode in ("edit", "adapt") else []
    if not kept:
        parts = qac.strip_existing_slide_parts(parts)
    ct = parts["[Content_Types].xml"].decode("utf-8")
    report = {"mode": mode, "master_sha": {m: sha(parts[m]) for m in info["masters"]},
              "theme_sha": {t: sha(parts[t]) for t in info["themes"]},
              "layout_sha": {l["part"]: sha(parts[l["part"]]) for l in layouts},
              "pages": [], "errors": [], "images": []}
    pres_xml = parts["ppt/presentation.xml"].decode("utf-8")
    prel = _rels(parts, "ppt/presentation.xml")
    used = set(prel)
    nr = [1]

    def new_rid():
        while "rId%d" % nr[0] in used:
            nr[0] += 1
        used.add("rId%d" % nr[0])
        return "rId%d" % nr[0]

    nid = [max([int(s) + 1 for s in re.findall(r'sldId id="(\d+)"', pres_xml)] or [256])]
    nm_rid = next((r for r in prel if prel[r]["type"] == TNM), None)
    if not any(n.startswith("ppt/notesMasters/") for n in parts):
        parts["ppt/notesMasters/notesMaster1.xml"] = _NM.encode()
        trel = {"rId1": {"type": TH, "target": posixpath.relpath(info["themes"][0], "ppt/notesMasters").replace("\\", "/")}} if info["themes"] else {}
        parts["ppt/notesMasters/_rels/notesMaster1.xml.rels"] = _rel_xml(trel).encode()
        if CNM not in ct:
            ct = ct.replace("</Types>", '<Override PartName="/ppt/notesMasters/notesMaster1.xml" ContentType="%s"/></Types>' % CNM)
        nm_rid = new_rid()
        prel[nm_rid] = {"type": TNM, "target": "notesMasters/notesMaster1.xml"}

    def add_ct(x, part, ctype):
        return x if ('PartName="/%s"' % part) in x else x.replace("</Types>",
               '<Override PartName="/%s" ContentType="%s"/></Types>' % (part, ctype))

    # In edit mode preserve source slide parts and presentation relationships.
    # In create mode they have already been removed with qac.strip_existing_slide_parts.
    entries = []
    nstart = (max([int(re.search(r"slide(\d+)\.xml$", n).group(1)) for n in kept] or [0]) + 1) if kept else 1
    for i, page in enumerate(pages):
        no = nstart + i
        role = page.get("role", "content")
        fig_path = page.get("figure")
        img_info = None
        if fig_path and media is not None:
            img_info = media.get(str(fig_path))
        layout = layouts[pick_layout(layouts, role, bool(img_info))]
        xml, slrep = compose_slide(page, layout, no, img_info)
        sp = "ppt/slides/slide%d.xml" % no
        srels = {"rId1": {"type": TL, "target": posixpath.relpath(layout["part"], "ppt/slides").replace("\\", "/")},
                 "rId2": {"type": TN, "target": "../notesSlides/notesSlide%d.xml" % no}}
        if img_info:
            rid = new_rid()
            ext = Path(img_info["path"]).suffix.lower().lstrip(".")
            media_part = "ppt/media/image%d.%s" % (no, ext)
            parts[media_part] = img_info["data"]
            srels[rid] = {"type": "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
                          "target": "../media/image%d.%s" % (no, ext)}
            ct = add_ct(ct, media_part, IMG_CT.get(ext, "image/png"))
            report["images"].append({"slide": no, "part": media_part, "source": img_info["path"], "aspect_preserved": True})
            xml = xml.replace("__IMG_RID__", rid)
        parts[sp] = xml.encode("utf-8")
        npart = "ppt/notesSlides/notesSlide%d.xml" % no
        parts[npart] = notes_xml(page.get("notes_lines") or []).encode()
        parts["ppt/notesSlides/_rels/notesSlide%d.xml.rels" % no] = _rel_xml(
            {"rId1": {"type": TS, "target": "../slides/slide%d.xml" % no},
             "rId2": {"type": TNM, "target": "../notesMasters/notesMaster1.xml"}})
        parts["ppt/slides/_rels/slide%d.xml.rels" % no] = _rel_xml(srels)
        ct = add_ct(ct, sp, CS)
        ct = add_ct(ct, npart, CNN)
        r = new_rid()
        entries.append('<p:sldId id="%d" r:id="%s"/>' % (nid[0], r))
        nid[0] += 1
        prel[r] = {"type": TS, "target": "slides/slide%d.xml" % no}
        report["pages"].append({"n": no, "role": role, "layout": layout["part"], **slrep})

    if "<p:notesMasterIdLst>" not in pres_xml:
        ins = '<p:notesMasterIdLst><p:notesMasterId r:id="%s"/></p:notesMasterIdLst>' % nm_rid
        pres_xml = pres_xml.replace("<p:sldIdLst>", ins + "<p:sldIdLst>", 1) if "<p:sldIdLst>" in pres_xml \
            else pres_xml.replace("<p:sldIdLst/>", ins + "<p:sldIdLst/>", 1)
    body = "".join(entries)
    pres_xml = pres_xml.replace("</p:sldIdLst>", body + "</p:sldIdLst>") if "</p:sldIdLst>" in pres_xml \
        else pres_xml.replace("<p:sldIdLst/>", "<p:sldIdLst>" + body + "</p:sldIdLst>")
    pres_xml = qac.write_presentation_ids(pres_xml, entries, nm_rid, edit=mode in ("edit", "adapt"))
    parts["ppt/presentation.xml"] = pres_xml if isinstance(pres_xml, bytes) else pres_xml.encode("utf-8")
    parts["ppt/_rels/presentation.xml.rels"] = _rel_xml(prel).encode()
    parts["[Content_Types].xml"] = ct.encode("utf-8")
    report["preserved"] = len(kept)
    report["added"] = len(pages)
    write_package(parts, out_path)
    return report


def _rel_xml(rels):
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', '<Relationships xmlns="%s">' % RL]
    for rid, r in rels.items():
        out.append('<Relationship Id="%s" Type="%s" Target="%s"/>' % (ea(rid), ea(r["type"]), ea(r["target"])))
    out.append("</Relationships>")
    return "".join(out)


def compose_slide(page, layout, no, img_info):
    tp, bp, pp = placeholders_of(layout)
    title = str(page.get("title") or "")
    bullets = [str(b) for b in (page.get("bullets") or []) if str(b).strip()]
    role = page.get("role", "content")
    size, ts = fit(bullets, title)
    shapes, rep = [], {"placeholders": [], "freetext": 0, "font_sizes": {"body": size, "title": ts}, "text_trimmed": False, "figure": None}
    sid = 2
    ta = list(tp["xfrm"]) if tp and tp.get("xfrm") else [457200, 274638, 10972800, 1143000]
    ba = list(bp["xfrm"]) if bp and bp.get("xfrm") else [457200, 1600200, 10972800, 4743450]
    if tp:
        ps = [_para(title, ts, True, "none")] if title else []
        if tp["type"] == "ctrTitle" and page.get("claim"):
            ps.append(_para(page["claim"], 16, False, "none"))
        shapes.append(_sp(sid, "Title", ta, ps or ['<a:p><a:endParaRPr lang="en-US"/></a:p>'], (tp["type"], tp.get("idx") or "")))
        rep["placeholders"].append({"ph": "title", "type": tp["type"]})
        sid += 1
    elif title:
        shapes.append(_sp(sid, "Title", ta, [_para(title, ts, True, "none")]))
        rep["freetext"] += 1
        sid += 1
    if img_info and pp is not None:
        rect = fit_rect(pp["xfrm"] if pp.get("xfrm") else ba, img_info["w"], img_info["h"])
        shapes.append(_pic_xml(sid, "Picture", rect, "__IMG_RID__", (pp["type"], pp.get("idx") or "")))
        rep["placeholders"].append({"ph": "pic", "type": pp["type"]})
        rep["figure"] = {"width": img_info["w"], "height": img_info["h"], "rect": rect}
        sid += 1
    elif img_info:
        rect = fit_rect([457200, 1600200, 7315200, 4743450], img_info["w"], img_info["h"])
        shapes.append(_pic_xml(sid, "Picture", rect, "__IMG_RID__"))
        rep["freetext"] += 1
        rep["figure"] = {"width": img_info["w"], "height": img_info["h"], "rect": rect}
        sid += 1
    if bp and bullets:
        shapes.append(_sp(sid, "Body", ba, [_para(b, size, bullet="dot") for b in bullets], (bp["type"], bp.get("idx") or "")))
        rep["placeholders"].append({"ph": "body", "type": bp["type"]})
        sid += 1
    elif bullets:
        shapes.append(_sp(sid, "Body", ba, [_para(b, size, bullet="dot") for b in bullets]))
        rep["freetext"] += 1
        sid += 1
    # batch-consistent footer + slide number (free text, deterministic positions)
    if role != "title":
        short = str(page.get("footer") or "")
        shapes.append(_sp(sid, "Footer", [457200, 6161400, 6400800, 400000],
                          [_para(short[:80], 10, False, "none", "dk2")]))
        rep["freetext"] += 1
        sid += 1
        shapes.append(_sp(sid, "SlideNumber", [10515600, 6161400, 1300000, 400000],
                          [_para(str(no), 10, False, "none", "dk2")]))
        rep["freetext"] += 1
        sid += 1
    return slide_xml(shapes), rep


# ---------------- verification / export ----------------
def verify_pptx(path):
    try:
        parts = read_package(path)
    except Exception as e:
        return {"ok": False, "problems": [str(e)], "slides": 0, "has_presentation": False}
    problems = []
    if "ppt/presentation.xml" not in parts:
        problems.append("missing presentation.xml")
    slides = sorted((n for n in parts if re.match(r"ppt/slides/slide\d+\.xml$", n)),
                    key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    nl = sum(1 for s in slides if not any(r["type"] == TL for r in _rels(parts, s).values()))
    if nl:
        problems.append("%d slides without layout" % nl)
    return {"ok": not problems and bool(slides), "problems": problems,
            "slides": len(slides), "has_presentation": "ppt/presentation.xml" in parts}


def pdf_page_count(path):
    data = Path(path).read_bytes()
    hdr = data[:1024].startswith(b"%PDF-")
    pages = 0
    for m in re.finditer(rb"/Type\s*/Pages[^>]*?/Count\s+(\d+)", data):
        pages = max(pages, int(m.group(1)))
    if not pages:
        pages = len(re.findall(rb"/Type\s*/Page[^>]", data))
    return pages, hdr


def find_tool(*names):
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    return None


def render_pdf_soffice(pptx, out_pdf):
    so = find_tool("soffice", "libreoffice")
    if not so:
        return None
    tmp = Path(out_pdf).parent / ".soffice_tmp"
    tmp.mkdir(parents=True, exist_ok=True)
    try:
        subprocess.run([so, "--headless", "--convert-to", "pdf", "--outdir", str(tmp), str(pptx)],
                       check=True, timeout=180, capture_output=True)
    except Exception:
        return None
    prod = tmp / (Path(pptx).stem + ".pdf")
    if prod.exists():
        shutil.move(str(prod), str(out_pdf))
        shutil.rmtree(str(tmp), ignore_errors=True)
        return "libreoffice"
    return None


def _pesc(s):
    return str(s).encode("latin-1", "replace").decode("latin-1").replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def write_text_pdf(pages, out_pdf):
    objs = ["<< /Type /Catalog /Pages 2 0 R >>",
            "<< /Type /Pages /Kids [%s] /Count %d >>" % (" ".join("%d 0 R" % (5 + 2 * i) for i in range(len(pages))), len(pages)),
            "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"]
    for i, page in enumerate(pages):
        cid = 4 + 2 * i
        lines = []
        if page.get("title"):
            lines.append("BT /F1 20 Tf 54 720 Td (%s) Tj ET" % _pesc(str(page.get("title"))[:80]))
        y = 660.0
        for b in (page.get("bullets") or [])[:8]:
            lines.append("BT /F1 13 Tf 60 %d Td (%s) Tj ET" % (int(y), _pesc(("\u2022 " + str(b))[:110])))
            y -= 26.0
        if page.get("claim") and page.get("role") == "title":
            lines.append("BT /F1 12 Tf 54 620 Td (%s) Tj ET" % _pesc(str(page.get("claim"))[:100]))
        lines.append("BT /F1 9 Tf 560 30 Td (%d) Tj ET" % (i + 1))
        content = "\n".join(lines).encode("latin-1", "replace")
        objs.append("<< /Length %d >>\nstream\n" % len(content) + content.decode("latin-1") + "\nendstream")
        objs.append("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R >> >> /Contents %d 0 R >>" % cid)
    out = ["%PDF-1.4"]
    for i, o in enumerate(objs, 1):
        out.append("%d 0 obj" % i)
        out.append(o)
        out.append("endobj")
    pos = len(out[0]) + 1
    offsets = []
    for o in out[1:]:
        offsets.append(pos)
        pos += len(o) + 1
    out.append("xref")
    out.append("0 %d" % (len(objs) + 1))
    out.append("0000000000 65535 f ")
    for p in offsets:
        out.append("%010d 00000 n " % p)
    out.append("trailer")
    out.append("<< /Size %d /Root 1 0 R >>" % (len(objs) + 1))
    out.append("startxref")
    out.append(str(pos))
    out.append("%%EOF")
    Path(out_pdf).write_bytes(("\n".join(out) + "\n").encode("latin-1", "replace"))

---
name: academic-ppt-adapter
description: Turn academic papers/materials into an evidence-mapped, template-inherited, editable slide deck with a real PDF preview. One command reads /input (case.json + task.md + paper + figures + an actual .pptx/.potx template or starting deck), derives a page-level plan from verbatim source sentences with locators, builds a .pptx on the template's masters/layouts/theme (bytes preserved), embeds matched figures aspect-preserving, applies a readable font-size ladder and batch-consistent footer/slide-number, exports PDF/PNG, and writes result.json echoing every output_contract field. Use when the task is academic presentation template/format adaptation with traceable evidence.
version: 1.1.0
---

# academic-ppt-adapter

## v1.1 修复版：运行契约与质量闸门

本 Skill 的默认入口是 `python3 scripts/main.py --input INPUT_DIR --work WORK_DIR --output OUTPUT_DIR`。运行前无需提供工作稿；若输入无有效事实材料，返回 `insufficient_evidence`，不生成虚构的研究结果。输入要求包含合法的 `case.json`，并按其中 `slide_count`/模板/模式约束构建真实 `.pptx`。

- **内容解析**：中英文 Markdown/纯文本标题与正文分开解析；正确按中文句号分句，保留逐字原文、页级 locator；同一段落内可补充 1–3 条可回查的原文要点。不能据此推断数据的科学正确性。
- **真实可编辑性**：使用 PPTX Open XML 的 slides、relationships、masters、layouts、theme、notes；创建模式不残留模板示例页；`edit` 仅保留既有页并**在页数预算内追加**，不支持任意局部替换。对未重新审计的旧页，运行结果为 `partial`。
- **强制校验**：逐页校验 claim、quote、每条 bullet 是否属于所指 locator；校验 `presentation.xml` 中的 slide ID、relationship、slideLayout 是否可解析，精确比较 PDF 与 PPTX 页数，检查模板母版/版式/主题部件的 SHA256 字节保持。
- **诚实降级**：只有真实 LibreOffice 导出、页数匹配、事实定位命中率 ≥0.95、模板字节保持且满足指定页数时，才可能 `status=ok`。没有 LibreOffice 时，生成的文本 PDF **不是 PPTX 的视觉渲染**，必须记为 `partial`；没有 `pdftoppm` 时不伪造 PNG 预览。扫描 PDF 与复杂公式须人工核验或另配 OCR/公式工具。
- **依赖**：Python 3.9+ 标准库；可选系统可执行文件 `pdftotext`（PDF 文字抽取）、LibreOffice `soffice`（真实 PDF 渲染）、`pdftoppm`（PNG 预览）。未安装这些可选程序时按对应步骤降级，不假装已完成渲染。
- **复现约束**：不保证不同 LibreOffice/字体环境产生二进制一致的 PDF（PDF 可能含时间等元数据）；应对比可打开性、页数、页面内容、版式检查与每页证据，不应以 PDF 哈希相同作为唯一判定标准。

**最小示例**（以下是接口测试示例，不是竞赛正式案例）：

```bash
mkdir -p /tmp/academic_case /tmp/academic_work /tmp/academic_output
printf '%s\n' '{"case_id":"example-001","title":"研究汇报","slide_count":4,"output_contract":{"presentation":"editable PPTX","pdf_export":"PDF","page_content_map":"sources"}}' > /tmp/academic_case/case.json
printf '%s\n' '# 研究汇报' '## 背景' '研究背景表明现有方法仍面临数据不足的问题。' '## 方法' '本研究收集多来源样本开展对照分析，并固定测试流程。' '## 结果' '实验显示该方案在当前样本中缩短检测时间，但不能推断所有环境。' '## 结论' '后续需要扩大样本并进行独立验证。' > /tmp/academic_case/paper.md
python3 scripts/main.py --input /tmp/academic_case --work /tmp/academic_work --output /tmp/academic_output
python3 -m json.tool /tmp/academic_output/result.json >/dev/null
```

四页只能在具有足够有效原文时形成有意义的内容。如果真实输入的证据不足，可能返回少页和 `partial`/`insufficient_evidence`，不能以重复编造句子补页。模板可以使用 `.pptx/.potx`，不接受旧二进制 `.ppt` 作为 OOXML 模板。


把科研论文/材料做成**主线成立、模板真正继承、页页可回溯、可编辑可放映**的学术 PPT。核心不是“把段落贴进页面”，而是六件事一起做：模板套用、版式约束、字体颜色、图表适配、批量一致性、导出渲染，同时保留逐页证据映射。

## 用途与触发条件

适用：输入含论文或科研材料（PDF / DOCX / MD / TXT / CSV / 图片），要求产出学术汇报 PPT（组会、答辩、评审、会议）；可选提供 `.pptx`/`.potx` 模板或起始 deck；要求数字/单位/图号与原文一致、模板母版/版式/主题真实继承、导出件可打开。

不适用：只要论文精读结论、只要科研绘图美化、只要润色。材料完全缺失时写 `insufficient_evidence`，**绝不编造论文内容或软件状态**。

## 调用方式（单命令 = 完整流程）

```bash
python3 scripts/main.py                    # 读 /input → 派生页计划 → 构建 → 导出 → result.json
python3 scripts/main.py --input DIR --work DIR --output DIR
python3 scripts/main.py check --output DIR # 校验产物
python3 scripts/main.py --help             # 用法（退出 0）
```

环境变量 `INPUT_DIR` / `WORK_DIR` / `OUTPUT_DIR` 覆盖默认 `/input` `/app/work` `/app/output`；也接受 `--input/--work/--output`。**无工作稿时自动从 /input 派生完整页级计划**，不要求评测方先写 `plan.json`（可选人工干预时才读它）。case 处理返回退出码 0。脚本用 `Path(__file__).resolve().parent` 定位自身，不依赖 CWD、不联网、纯 Python 标准库。无模板时使用包内内置学术模板（代码内构造，含母版/版式/主题）。

## 输入输出

| 项 | 路径 |
|---|---|
| 输入 | `/input/case.json`（`case_id`、`task_instruction`、`output_contract`；可含 `title`/`slide_count`/`audience`/`duration_minutes`/`mode`/`template`/`deck` 等）、`/input/task.md`、`/input/` 下材料与模板 |
| 工作区 | `/app/work/`：`index.json`；可选 `plan.json`（人工页计划，非必需） |
| 产物 | `/app/output/`：`result.json`（必需）、`presentation.pptx`、`presentation.pdf`、`preview/slide-*.png`、`content_map.json`、`page_plan.json`、`evidence_map.json`、`changes.json`、`template_check.json`、`export_check.json` |

## 模板与格式适配方法

1. **模板套用**：从 case 字段（`template`/`template_path`/`template_file`）或材料里找 `.pptx/.potx`；区分模板（版式源）与起始 deck（`mode=edit/adapt` 时以其为底）。输出包直接以该模板为父包，`ppt/slideMasters/*`、`ppt/slideLayouts/*`、`ppt/theme/*` **字节原样保留**（构建前后 sha256 比对写入 `template_check.json`）。新增页在版式的 `p:ph` 占位符上生成，几何位置取版式（缺失回退母版）。
2. **版式约束**：正文用可解释字号阶梯（20→19→18→16→14→12pt，最低 12pt 不再压）；标题按长度 30/26/22pt；字宽估算换行，放不下先降字号、仍放不下记录 `text_trimmed`，**不靠压缩字号硬塞**。
3. **字体颜色**：文字 run 用主题方案色（标题/正文 `tx1`、页脚 `dk2`、图框线 `accent1`），Latin 用 `+mn-lt`、East Asian 用 `+mn-ea` 主题字体，主题色/主题字体随模板继承，避免字体缺失后整页错乱。
4. **图表适配**：文本出现 `Figure N`/`Table N` 才建图引用；按文件名数字匹配图片（`figure2.png`↔Figure 2），PNG/JPEG 读真实宽高，**等比缩放进容器并居中**（`a:picLocks noChangeAspect="1"`），不拉伸。
5. **批量一致性**：除封面外每页统一页脚（论文短标题，左下）与页码（右下），位置/字号固定；所有页共用同一字号阶梯与同一版式选择规则。
6. **导出渲染**：优先 `soffice/libreoffice` 真实渲染 PDF；不可用时退到内置文本层 PDF（WinAnsi/Helvetica，中文近似为 `?`）并如实记 `degradations`。PNG 预览用 `pdftoppm`。导出后校验 PDF 头/页数、pptx 可解压且含 `ppt/presentation.xml`、每页挂 `slideLayout`。

## 内容派生（无工作稿自动完成）

- 材料按真实文件读：PDF 用 `pdftotext`（无则标准库粗抽取），DOCX 解包 `word/document.xml`，文本按段落，CSV 逐行；起始 deck 的幻灯片文本也抽取为证据源（读 deck，但绝不覆盖其母版/版式/主题）。
- 章节识别（中英标题）后按角色（title/background/method/result/limitation/conclusion）选**原文逐字句子**作每页 claim；结果页加权数值密度与 Figure/Table 引用。
- `slide_count`（题面给则遵守，否则 9）按比例分配角色页；每页 claim + bullets 均为原文**逐字子串**，数字/图号不改写。
- 可选 `work/plan.json`（同构页计划 `pages:[{role,title,claim,locator,bullets,notes,figure}]`）优先采用；缺失/不合法时自动派生，永不 0 页。

## 证据规范（真实派生红线）

- 每页 `claim` 与每个 `bullet` 是材料原文的**逐字子串**；`content_map.json` 逐页记录 `source.path` + `locator`（如 `m1#p3`）+ 逐字 `quote` + `verbatim_hit`。
- `quote_hit_rate` 机械比对（去空白、小写），目标 ≥0.95；未命中页记入 `uncertainty`，状态降为 `partial`。
- 数字/图号只来自原文；不生成“看起来像”的数据，不把示意图当实验数据。

## 工作稿 schema（可选）

```json
{"title": "...", "pages": [
  {"n": 1, "role": "cover|background|method|result|limitation|conclusion",
   "title": "…", "claim": "原文逐字句", "claim_loc": "m1#p3", "claim_quote": "原文逐字句",
   "bullets": ["原文逐字短语"], "figure_refs": ["Figure 2"], "figure": "材料图路径", "notes": ["讲稿"]}]}
```

## 降级表

| 情况 | 处置 | 记录 |
|---|---|---|
| 无模板 | 用内置学术模板（代码构造） | `degradations` |
| 无 LibreOffice | 内置文本层 PDF（非拉丁字形近似 `?`） | `degradations` |
| PDF 为 CID/扫描 | 抽取失败则 `insufficient_evidence`，不编造 | `status` |
| 空 `/input` / 无 case.json | `status=input_error` + 最小合法 result.json | `errors` |
| case.json 坏 JSON | `status=input_error` | `errors` |
| 缺材料 | `status=insufficient_evidence` + gaps | `uncertainty` |
| 图片无有效尺寸/格式 | 图页只带文字证据，不嵌入 | `degradations` |
| 页数超限 | 先删支撑细节页，保留主线页 | `coverage` |

任何异常先写 partial `result.json` 再增量 finalize，case 处理返回退出码 0。

## result.json 契约

`case_id` 原样回填；`output_contract` 的**每个字段**按语义映射到对应产物（关键词 `ppt/presentation/deck/editable`→editable_source，`pdf/export/render`→export_artifact，`content/claim/evidence/map/page`→content_map，`note/script/speaker`→notes，`plan/golden`→page_plan，`preview/png`→previews，`*_count/slides/pages`→页数），无法匹配的键填 `null`，**不改名、不漏键**。另含 `status`（`ok`/`partial`/`insufficient_evidence`/`input_error`）、`sources`、`uncertainty`、`changes`、`errors`、`degradations`、`coverage`、`skill`。

## 自检

- 默认命令后：`result.json` 合法、回填 `output_contract` 每个键 + `case_id/status/sources/uncertainty/changes`。
- `presentation.pptx` 可解压、含 `ppt/presentation.xml`、每页挂 `slideLayout`、母版/版式/主题 sha256 与输入模板一致。
- `presentation.pdf` 有 `%PDF-` 头且页数=幻灯片数；PNG 有 `\x89PNG` 头。
- 两次全新输出目录产物结构一致（无时间戳/随机；zip 固定时间戳、PDF 元数据可能随渲染环境变化）。
- 空/坏/缺三态各自退出 0 且 result.json 契约键齐全。

## 限制

- 不重绘论文图表，只内嵌原图并保留图号/图注文字引用；起始 deck 的旧内容页会被字节保留，新增页依据页数预算追加；旧页未重新完成证据审计，因此 status=partial，已在 `changes`/`uncertainty` 说明。
- 内置文本层 PDF 兜底仅 WinAnsi/Helvetica，中文/数学符号近似为 `?`（可编辑源 pptx 文本仍完整正确）。
- 不判断科学结论对错，只保证可回溯；扫描版 PDF 需 OCR 另行处理。
- 模板要求：`.pptx/.potx` 且至少含一个带标题占位符的 `slideLayout`。

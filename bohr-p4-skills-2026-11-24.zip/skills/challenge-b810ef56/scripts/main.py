#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Evidence-driven academic writing Skill driver.

Standard library only; no network; no CWD assumptions; exit code always 0.
A legal partial result.json is written before heavy work and output_contract keys are
echoed exactly; missing/broken/empty input still yields a legal degraded deliverable.
"""
import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
import assemble as asm       # noqa: E402
import docparse as dp        # noqa: E402
import model as md           # noqa: E402
import render as rd          # noqa: E402

VERSION = "1.2.0"
NAME = "evidence-driven-academic-writing"
FALLBACK_KEYS = ["case_id", "status", "result", "claims", "coverage"]


# --------------------------------------------------------------- envelope
def resolve(args):
    def _p(key, default):
        val = getattr(args, key, None)
        return Path(val).expanduser() if val else Path(default)
    return _p("input", "/input"), _p("work", "/app/work"), _p("output", "/app/output")


def load_case(inp):
    """Return (case dict, error marker). Never raises."""
    p = Path(inp) / "case.json"
    if not p.exists():
        return {}, "missing_case_json"
    try:
        raw = p.read_text(encoding="utf-8", errors="replace").strip()
    except Exception as exc:
        return {}, "unreadable_case_json: %s" % exc
    if not raw:
        return {}, "empty_case_json"
    try:
        case = json.loads(raw)
    except Exception as exc:
        return {}, "bad_case_json: %s" % exc
    if not isinstance(case, dict):
        return {}, "case_json_not_object"
    return case, ""


def contract_keys(contract):
    keys = []
    if isinstance(contract, dict):
        props = contract.get("properties")
        src = props if isinstance(props, dict) else contract
        keys = [k for k in src.keys() if isinstance(k, str)]
    elif isinstance(contract, list):
        for item in contract:
            if isinstance(item, str):
                keys.append(item)
            elif isinstance(item, dict):
                for k in ("key", "name", "field", "id"):
                    if isinstance(item.get(k), str):
                        keys.append(item[k])
                        break
    return keys


def _spec_children(spec):
    if isinstance(spec, dict):
        if isinstance(spec.get("properties"), dict):
            return spec["properties"]
        if spec and "type" not in spec and all(
                isinstance(v, (dict, list, str)) for v in spec.values()):
            return spec
    return None


def echo_value(spec, value, path, missing):
    """Guarantee the shape the contract asks for, without inventing content."""
    kids = _spec_children(spec)
    if kids:
        if not isinstance(value, dict):
            value = {}
        for k in kids:
            if k in value and value[k] is not None:
                value[k] = echo_value(kids[k], value[k], path + "." + k, missing)
            else:
                value[k] = echo_value(kids[k], None, path + "." + k, missing)
                if value[k] is None:
                    missing.append(path + "." + k)
        return value
    if isinstance(spec, list):
        return value if isinstance(value, list) else ([] if value is None else [value])
    if value is None:
        missing.append(path)
    return value


def echo_contract(contract, base):
    """Exact-key echo of output_contract; returns the final dict."""
    final, missing = {}, []
    keys = contract_keys(contract)
    if isinstance(contract, dict) and contract and not keys:
        keys = list(FALLBACK_KEYS)
    if not keys:
        keys = list(FALLBACK_KEYS)
    props = contract.get("properties") if isinstance(contract, dict) and \
        isinstance(contract.get("properties"), dict) else contract
    for key in keys:
        spec = props.get(key) if isinstance(props, dict) else None
        if key in base and base[key] is not None:
            final[key] = echo_value(spec, base[key], key, missing)
        elif isinstance(base.get("result"), dict) and key in base["result"] \
                and base["result"][key] is not None:
            final[key] = echo_value(spec, base["result"][key], key, missing)
        else:
            final[key] = echo_value(spec, None, key, missing)
            if final[key] is None or (isinstance(final[key], dict) and not final[key]):
                missing.append(key)
    final.update(base)
    for key in missing:
        final.setdefault(key, None)
    if missing:
        base.setdefault("degradations", []).append(
            "output_contract keys without a native value (kept as null/shape only): "
            + ", ".join(sorted(set(missing))))
    return final


def base_payload(case_id, instruction=""):
    return {
        "case_id": case_id,
        "status": "partial",
        "skill": {"name": NAME, "version": VERSION},
        "result": {},
        "claims": [],
        "evidence_table": [],
        "coverage": {"required": 0, "parsed": 0, "missing": []},
        "sources": [],
        "uncertainties": [],
        "pending_human": [],
        "errors": [],
        "degradations": [],
        "deliverables": {},
        "instruction": (instruction or "")[:2000],
    }


def write_result(out_dir, contract, base):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    final = echo_contract(contract, base)
    dp.dump_json(out_dir / "result.json", final)
    return final


def load_draft(work):
    for name in ("draft.json", "writing.json", "manuscript.json", "work.json"):
        p = Path(work) / name
        if p.exists():
            obj = dp.load_json(p)
            if isinstance(obj, dict):
                return obj, name
    return {}, ""


def load_materials(work, inp, case_id):
    p = Path(work) / "materials.json"
    obj = dp.load_json(p)
    if isinstance(obj, dict) and obj.get("docs") is not None:
        return obj, ""
    payload = dp.build_index(inp, case_id)
    try:
        dp.dump_json(p, payload)
    except Exception:
        pass
    return payload, "materials.json rebuilt from /input"


# ------------------------------------------------------------------- cmds
def cmd_init(args):
    inp, work, out = resolve(args)
    for d in (work, out):
        d.mkdir(parents=True, exist_ok=True)
    case, err = load_case(inp)
    case_id = str(md.first(case, ["case_id", "id"], ""))
    contract = case.get("output_contract") if isinstance(case, dict) else None
    base = base_payload(case_id, str(md.first(case, ["task_instruction", "instruction"], "")))
    if err:
        base["status"] = "input_error" if ("bad" in err or "not_object" in err) \
            else "insufficient_evidence"
        base["errors"].append("case.json: " + err)
        base["degradations"].append("no usable /input/case.json: the envelope is emitted "
                                    "with fallback contract keys")
    write_result(out, contract, base)
    materials, _ = load_materials(work, inp, case_id)
    keys = contract_keys(contract) or FALLBACK_KEYS
    index = {"case_id": case_id, "docs": len(materials.get("docs") or []),
             "paragraphs": materials.get("total_paragraphs"),
             "chars": materials.get("total_chars"),
             "warnings": materials.get("warnings") or [],
             "draft_present": bool(load_draft(work)[0]),
             "contract_keys": keys, "case_error": err}
    dp.dump_json(work / "index.json", index)
    print("[init] case_id=%r status=%s" % (case_id, base["status"]))
    if err:
        print("[init] case.json problem: %s (degraded mode still produces output)" % err)
    print("[init] materials: %d docs, %s paragraphs, %s chars from %s"
          % (index["docs"], index["paragraphs"], index["chars"], inp))
    for w in (materials.get("warnings") or [])[:8]:
        print("[init] warning: " + w)
    print("[init] contract keys: " + ", ".join(keys))
    print("[init] next: `show --outline` -> read materials -> write %s -> `check` -> `build`"
          % (Path(work) / "draft.json"))
    return 0


def _expand_query(q):
    extra = []
    for zh, en in md.TERM_BRIDGE.items():
        if zh in q:
            extra.extend(en.split())
    return [q] + [t for t in extra if t.lower() not in q.lower()][:8]


def _snippet(body, terms, width=170):
    low, out = body.lower(), []
    for t in terms:
        i = low.find(t.lower())
        if i >= 0:
            out.append("\u2026" + dp.norm_ws(body[max(0, i - width // 3):][:width]) + "\u2026")
    return out[:3] or [dp.norm_ws(body)[:width]]


def cmd_show(args):
    inp, work, out = resolve(args)
    case, _ = load_case(inp)
    materials, _ = load_materials(work, inp, str(md.first(case, ["case_id", "id"], "")))
    docs = materials.get("docs") or []
    if args.json:
        print(rd.to_json({"docs": dp.doc_list(materials),
                          "warnings": materials.get("warnings") or []}))
        return 0
    if not docs:
        print("[show] no material text could be extracted.")
        for w in (materials.get("warnings") or [])[:10]:
            print("[show] warning: " + w)
        print("[show] next: if a platform pdf-text / OCR tool exists, save its output under "
              "%s/extracted/ and rerun `init`." % work)
        return 0
    terms = []
    for g in (args.grep or []):
        terms.extend(_expand_query(g))
    if getattr(args, "facts", False):
        shown = 0
        for d in docs:
            for p in d.get("paragraphs") or []:
                body = dp.norm_ws((d.get("text") or "")[p["start"]:p["end"]])
                for num in dict.fromkeys(dp.numbers(body)):
                    print("[%s] %s :: %s" % (p["paragraph_id"], num, body[:180]))
                    shown += 1
                    if shown >= 100:
                        return 0
        if not shown:
            print("(no numeric token found in the extracted material text)")
        return 0
    if args.outline or terms:
        for d in docs:
            print("[%s] %s  %s  %s pages  %s chars  %s paragraphs"
                  % (d["doc_id"], d["name"], d["kind"], len(d.get("pages") or []) or "?",
                     len(d.get("text") or ""), len(d.get("paragraphs") or [])))
            for w in (d.get("warnings") or []):
                print("    ! " + w)
            for p in d.get("paragraphs") or []:
                body = (d.get("text") or "")[p["start"]:p["end"]]
                if terms and not any(t.lower() in body.lower() for t in terms):
                    continue
                if p.get("heading"):
                    print("  H %-12s p%-3s | %s" % (p["paragraph_id"], p.get("page") or "?",
                                                    dp.norm_ws(body)[:110]))
                elif terms:
                    for line in _snippet(body, terms):
                        print("  %-12s p%-3s | %s %s" % (p["paragraph_id"],
                                                         p.get("page") or "?",
                                                         (p.get("section") or "")[:18], line))
        return 0
    if args.para:
        for d in docs:
            p, body = dp.paragraph_view(d, args.para)
            if p:
                print("[%s | %s | page %s | %s]" % (args.para, d["name"], p.get("page"),
                                                    p.get("section") or "-"))
                print(body)
                return 0
        print("[show] paragraph %r not found; run `show --outline` for the index" % args.para)
        return 0
    limit = args.limit or 40
    for d in docs:
        if args.doc and d["doc_id"] != args.doc:
            continue
        print("[%s] %s  %s  %s pages  %s paragraphs"
              % (d["doc_id"], d["name"], d["kind"], len(d.get("pages") or []) or "?",
                 len(d.get("paragraphs") or [])))
        for w in (d.get("warnings") or []):
            print("    ! " + w)
        for p in (d.get("paragraphs") or [])[:limit]:
            body = dp.norm_ws((d.get("text") or "")[p["start"]:p["end"]])
            print("%s %-12s p%-3s %s | %s" % ("H" if p.get("heading") else " ",
                                              p["paragraph_id"], p.get("page") or "?",
                                              (p.get("section") or "")[:20], body[:150]))
        print("")
    return 0


def cmd_check(args):
    inp, work, out = resolve(args)
    case, _ = load_case(inp)
    contract = case.get("output_contract") if isinstance(case, dict) else None
    materials, _ = load_materials(work, inp, str(md.first(case, ["case_id", "id"], "")))
    draft, dname = load_draft(work)
    if not draft:
        model = md.normalize_draft({}, case, materials)
        report = {"ok": False, "fails": ["no draft found in %s (expected draft.json)" % work],
                  "warns": [], "stats": {}, "hedge_flags": []}
    else:
        model = md.normalize_draft(draft, case, materials)
        report = md.audit(model, materials)
    base = base_payload(str(md.first(case, ["case_id", "id"], "")))
    base["checks"] = report
    base["degradations"].append("check only: run build to emit the deliverable")
    write_result(out, contract, base)
    dp.dump_json(Path(work) / "check_report.json", report)
    print("[check] draft=%s claims=%d fails=%d warns=%d"
          % (dname or "-", len(model.get("claims") or []), len(report["fails"]),
             len(report["warns"])))
    for f in report["fails"]:
        print("[check][FAIL] " + f)
    for w in report["warns"][:12]:
        print("[check][warn] " + w)
    stats = report.get("stats") or {}
    print("[check] quote_check=%s" % (stats.get("quote_check"),))
    print("[check] doi=%s numbers=%s overclaim=%d"
          % (stats.get("doi_check"), stats.get("number_check"),
             len(report.get("hedge_flags") or [])))
    print("[check] claim_numbers=%s units=%s short_quotes=%s"
          % (stats.get("claim_number_check"), stats.get("unit_check"),
             stats.get("short_quotes")))
    for w in (stats.get("claim_number_warnings") or [])[:4]:
        print("[check][warn] " + w)
    for w in (stats.get("unit_warnings") or [])[:4]:
        print("[check][warn] " + w)
    print("[check] result: %s" % ("PASS (run build)" if report["ok"]
                                  else "FIXABLE ISSUES (fix draft.json, rerun check)"))
    return 0


def cmd_build(args):
    inp, work, out = resolve(args)
    for d in (work, out):
        d.mkdir(parents=True, exist_ok=True)
    case, err = load_case(inp)
    case_id = str(md.first(case, ["case_id", "id"], ""))
    contract = case.get("output_contract") if isinstance(case, dict) else None
    base = base_payload(case_id, str(md.first(case, ["task_instruction", "instruction"], "")))
    degradations, errors = [], []
    if err:
        base["status"] = "input_error" if ("bad" in err or "not_object" in err) \
            else "insufficient_evidence"
        errors.append("case.json: " + err)
        degradations.append("no usable /input/case.json; the envelope is emitted with "
                            "fallback contract keys")
        base["errors"] = list(errors)
        base["degradations"] = list(degradations)
    write_result(out, contract, base)                        # partial first, always
    materials, note = load_materials(work, inp, case_id)
    if note:
        print("[build] note: " + note)
    for w in (materials.get("warnings") or [])[:10]:
        degradations.append("material warning: " + w)
    draft, _ = load_draft(work)
    if not draft:
        model = md.degraded_model(materials, case, degradations)
        audit_res = md.audit(model, materials) if model.get("claims") else {
            "ok": True, "fails": [], "warns": ["degraded mode: no drafted prose to audit"],
            "stats": {"quote_check": {}, "hedge_flags": [], "unevidenced": []},
            "hedge_flags": []}
    else:
        model = md.normalize_draft(draft, case, materials)
        audit_res = md.audit(model, materials)
        if audit_res["fails"]:
            errors.extend("check: " + f for f in audit_res["fails"])
            degradations.append(
                "the draft failed %d mechanical check(s); the deliverable is kept with "
                "status=partial and the failures are listed in result.json:self_check"
                % len(audit_res["fails"]))
    rows, facts, changes, coverage = asm.build_artifacts(model, materials, case, audit_res)
    model["evidence_rows"] = rows
    model["preserved_facts"] = facts
    model["change_log"] = changes
    model["uncertainties"] = list(model.get("uncertainties") or [])
    if audit_res.get("hedge_flags"):
        model["uncertainties"].append(
            "%d sentence(s) use stronger wording than the graded evidence; see "
            "evidence_strength.md" % len(audit_res["hedge_flags"]))
    for w in audit_res.get("warns") or []:
        if "never cited" in w or "over-claim" in w:
            model["uncertainties"].append(w)
    receipts = md.workorder_receipts(case, model, draft)
    self_check_payload = {
        "ok": not audit_res.get("fails"),
        "fails": audit_res.get("fails") or [],
        "warns": audit_res.get("warns") or [],
        "quote_check": audit_res["stats"].get("quote_check"),
        "claim_number_check": audit_res["stats"].get("claim_number_check"),
        "claim_number_warnings": audit_res["stats"].get("claim_number_warnings") or [],
        "unit_check": audit_res["stats"].get("unit_check"),
        "unit_warnings": audit_res["stats"].get("unit_warnings") or [],
        "short_quotes": audit_res["stats"].get("short_quotes") or 0,
        "checks": {"doi": audit_res["stats"].get("doi_check"),
                   "numbers": audit_res["stats"].get("number_check")},
    }
    model["workorder_receipts"] = receipts
    model["self_check_payload"] = self_check_payload
    model = asm.enrich(model, materials, audit_res, coverage, dp.doc_list(materials))
    files = asm.write_deliverables(model, out)
    status = asm.status_of(model, audit_res)
    if err and not draft:
        # nothing was readable and nothing was drafted: the run failed on input, say so
        status = "input_error" if ("bad" in err or "not_object" in err) \
            else "insufficient_evidence"
    result_obj = asm.result_object(model, audit_res, coverage, files)
    result_obj["instruction"] = base["instruction"]
    body = base_payload(case_id, base["instruction"])
    body.update({
        "status": status, "result": result_obj, "claims": model.get("claims") or [],
        "evidence_table": rows,
        "evidence_map": [{"claim_id": r["claim_id"], "source_id": r["doc_id"],
                          "locator": r["locator"], "quote": r["quote"],
                          "kind": r["source_type"]} for r in rows],
        "preserved_facts": facts, "change_log": changes, "coverage": coverage,
        "sources": model.get("source_docs") or [],
        "uncertainties": model.get("uncertainties") or [],
        "pending_human": model.get("pending_human") or [],
        "errors": errors, "degradations": degradations,
        "deliverable": "manuscript.md", "deliverables": files,
        "deliverable_path": str(Path(out) / "manuscript.md"),
        "method_notes": ("claim split -> verbatim evidence binding -> strength grading -> "
                         "hedge-controlled prose. Every evidence row records doc_id, locator, "
                         "verbatim quote and a machine quote check; a claim is capped by its "
                         "weakest source and conflicts are listed, never hidden."),
        "workorder_execution": receipts,
        "workorder_receipts": receipts,
        "self_check": self_check_payload,
    })
    final = write_result(out, contract, body)
    print("[build] status=%s case_id=%r" % (status, final.get("case_id")))
    print("[build] deliverable=%s" % (Path(out) / "manuscript.md"))
    print("[build] claims=%d evidence_rows=%d words=%s"
          % (len(final.get("claims") or []), len(rows), result_obj.get("words")))
    print("[build] contract keys: " + ", ".join(contract_keys(contract) or FALLBACK_KEYS))
    if degradations:
        print("[build] degradations recorded: %d" % len(degradations))
    return 0


def cmd_selfcheck(args):
    inp, work, out = resolve(args)
    case, _ = load_case(inp)
    contract = case.get("output_contract") if isinstance(case, dict) else None
    res = dp.load_json(Path(out) / "result.json", {}) or {}
    keys = contract_keys(contract) or FALLBACK_KEYS
    missing = [k for k in keys if k not in res]
    files = {}
    for name in ("manuscript.md", "manuscript.html", "evidence_driven_draft.md", "claims.json",
                 "evidence_table.json", "evidence_map.json", "preserved_facts.json",
                 "change_log.json", "workorder_receipts.json", "self_check.json",
                 "evidence_strength.md", "reference_check.md"):
        p = Path(out) / name
        files[name] = p.stat().st_size if p.exists() else 0
    report = {"case_id_in_result": bool(res.get("case_id")),
              "contract_keys_missing": missing, "status": res.get("status"),
              "files": files, "claims": len(res.get("claims") or []),
              "ok": not missing and bool(res.get("case_id")) and all(files.values())}
    dp.dump_json(Path(work) / "self_check.json", report)
    print(rd.to_json(report))
    return 0


def cmd_export(args):
    inp, work, out = resolve(args)
    print("[export] deliverables under %s:" % out)
    for p in sorted(Path(out).glob("*")):
        print("  %-28s %8d B" % (p.name, p.stat().st_size if p.is_file() else 0))
    return 0


def emergency(exc):
    """Last-resort finalize: never leave the output empty, never exit non-zero."""
    try:
        inp, work, out = resolve(argparse.Namespace())
        for d in (work, out):
            Path(d).mkdir(parents=True, exist_ok=True)
        case, _ = load_case(inp)
        contract = case.get("output_contract") if isinstance(case, dict) else None
        base = base_payload(str(case.get("case_id") or ""))
        base["errors"].append("unhandled error: " + str(exc)[:400])
        base["degradations"].append("emergency finalize: only the envelope and an empty "
                                    "manuscript were produced")
        write_result(out, contract, base)
        p = Path(out) / "manuscript.md"
        if not p.exists():
            p.write_text("# Evidence-driven manuscript\n\n> DEGRADED: an unhandled error "
                         "interrupted the run before prose was assembled. See result.json "
                         "-> errors, then re-run init -> check -> build.\n", encoding="utf-8")
        print("[emergency] wrote a minimal result.json + manuscript.md")
    except Exception:
        pass
    return 0


def build_parser():
    common = argparse.ArgumentParser(add_help=False)
    for flag in ("--input", "--work", "--output"):
        common.add_argument(flag, default=argparse.SUPPRESS)
    ap = argparse.ArgumentParser(
        prog="main.py", description="Evidence-driven academic writing skill v%s" % VERSION,
        parents=[common])
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("init", parents=[common], help="index materials, write partial result.json")
    sp = sub.add_parser("show", parents=[common], help="print materials with locators")
    sp.add_argument("--doc", default="")
    sp.add_argument("--para", default="")
    sp.add_argument("--grep", nargs="*", default=[])
    sp.add_argument("--outline", action="store_true")
    sp.add_argument("--facts", action="store_true",
                    help="list numeric facts with paragraph locators for preserved_facts")
    sp.add_argument("--limit", type=int, default=40)
    sp.add_argument("--json", action="store_true")
    sub.add_parser("check", parents=[common], help="mechanically verify draft.json")
    sub.add_parser("build", parents=[common], help="assemble deliverables + result.json")
    sub.add_parser("selfcheck", parents=[common], help="re-inspect the produced output")
    sub.add_parser("export", parents=[common], help="list deliverables")
    return ap


def main(argv):
    try:
        args, unknown = build_parser().parse_known_args(argv)
    except SystemExit:
        return 0
    if unknown:
        print("[main] ignoring unrecognised arguments: %s" % " ".join(unknown[:6]))
    cmd = getattr(args, "cmd", None)
    table = {"init": cmd_init, "show": cmd_show, "check": cmd_check, "build": cmd_build,
             "selfcheck": cmd_selfcheck, "export": cmd_export}
    if cmd in table:
        return table[cmd](args)
    print("[main] no subcommand: running init -> build (degraded unless a draft exists)")
    ns = argparse.Namespace(**{k: getattr(args, k) for k in ("input", "work", "output")
                               if hasattr(args, k)})
    cmd_init(ns)
    cmd_build(ns)
    return 0


def _emit_assets_post():
    try:
        import assets as _a
        _a.emit_from_argv()
    except Exception:
        pass


if __name__ == "__main__":
    try:
        import atexit as _atexit
        _atexit.register(_emit_assets_post)
    except Exception:
        pass

    try:
        main(sys.argv[1:])
    except SystemExit:
        pass
    except Exception as exc:                                    # pragma: no cover
        try:
            emergency(exc)
        except Exception:
            pass
    sys.exit(0)

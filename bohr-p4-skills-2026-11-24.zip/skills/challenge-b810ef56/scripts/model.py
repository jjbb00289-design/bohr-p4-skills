#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""model.py - normalise an agent draft into the internal claim/evidence model and audit it.

Pure logic, no I/O beyond the materials payload handed in. Standard library only.
"""
import re

import docparse as dp

STRENGTH_RANK = {"insufficient": 0, "low": 1, "moderate": 2, "high": 3, "undetermined": 0}
STRENGTH_ALIAS = {
    "strong": "high", "high": "high", "高": "high", "强": "high", "very_high": "high",
    "medium": "moderate", "moderate": "moderate", "mod": "moderate", "中": "moderate",
    "weak": "low", "low": "low", "低": "low", "弱": "low",
    "insufficient": "insufficient", "none": "insufficient", "no_evidence": "insufficient",
    "不足": "insufficient", "无": "insufficient", "undetermined": "undetermined",
}
SOURCE_TYPES = {"primary_research": "primary_research", "primary": "primary_research",
                "original": "primary_research", "原始研究": "primary_research",
                "original_research": "primary_research",
                "review": "review", "综述": "review", "systematic_review": "review",
                "meta_analysis": "review",
                "guideline": "guideline", "指南": "guideline",
                "preprint": "preprint", "预印本": "preprint",
                "conference": "conference_abstract", "abstract": "conference_abstract",
                "unknown": "unknown", "": "unknown"}
STRENGTH_NAME = {0: "insufficient", 1: "low", 2: "moderate", 3: "high"}
OVERCLAIM_RE = re.compile(
    r"\b(proves?|proven|demonstrates?\s+that|confirms?\s+that|establishes?\s+that|"
    r"caus(?:es|ed|al|ation)|guarantees?)\b|证明|证实|表明因果", re.I)
FINDING_HINT = re.compile(
    r"\b(significant|increase[sd]?|decreas\w+|reduc\w+|higher|lower|associated|correlat\w+|"
    r"improve\w*|yield|efficiency|conversion|p\s*[<=>]|compared with|control)\b|显著|提高|"
    r"降低|相关|产率|效率|转化", re.I)
# Bilingual term bridge: a Chinese question over English materials defeats naive
# keyword search, so every query is expanded with the matching English stem.
TERM_BRIDGE = {
    "循环": "cycling cycle recycled", "光催化": "photocatalysis photocatalytic",
    "产率": "yield", "转化率": "conversion", "选择性": "selectivity",
    "证据": "evidence", "强度": "strength", "样本量": "sample size participants n",
    "显著": "significant p <", "相关": "correlation associated", "因果": "causal cause",
    "机制": "mechanism pathway", "局限": "limitation", "结论": "conclusion",
    "方法": "method materials", "讨论": "discussion", "结果": "results",
    "摘要": "abstract", "参考文献": "references", "误差": "error uncertainty deviation",
    "置信区间": "confidence interval", "对照组": "control group", "剂量": "dose dosage",
    "污染": "contaminant pollutant", "降解": "degradation degrade", "药物": "drug compound",
    "临床": "clinical trial", "队列": "cohort", "综述": "review", "指南": "guideline",
    "评估": "assessment evaluate", "数据": "data dataset", "引用": "citation reference",
    "假设": "hypothesis", "样本": "sample", "偏倚": "bias", "随机": "randomized",
}


def _as_list(x):
    if x is None:
        return []
    return x if isinstance(x, list) else [x]


def first(d, keys, default=""):
    for k in keys:
        v = d.get(k) if isinstance(d, dict) else None
        if isinstance(v, (str, int, float)) and str(v).strip():
            return v
    return default


# ------------------------------------------------------------- normalising
def norm_support(raw, materials):
    """One evidence row: locate the verbatim quote and attach its locator."""
    if isinstance(raw, str):
        raw = {"quote": raw}
    if not isinstance(raw, dict):
        raw = {}
    quote = str(first(raw, ["quote", "text", "evidence", "excerpt", "原文", "引文"], ""))
    doc_id = str(first(raw, ["doc_id", "source_id", "source", "doc", "文献"], ""))
    cand = dp.quote_in_materials(materials, quote, prefer_doc=doc_id) if quote else []
    best = cand[0] if cand else {}
    loc = str(first(raw, ["locator", "location", "定位"], ""))
    loc_auto = ""
    if best:
        loc_auto = "%s p.%s%s" % (best.get("paragraph_id"), best.get("page") or "?",
                                  (" / " + best["section"]) if best.get("section") else "")
    note = ""
    claimed_pid = re.search(r"(m\d+-p\d+)", loc)
    if best and claimed_pid and claimed_pid.group(1) != best.get("paragraph_id"):
        note = ("the locator supplied for this row (%r) points at %s but the verbatim quote lives "
                "in %s; the machine locator is used"
                % (loc[:80], claimed_pid.group(1), best.get("paragraph_id")))
        loc = loc_auto
    elif not loc:
        loc = loc_auto
    st = str(first(raw, ["source_type", "design", "来源类型"], "unknown")).strip().lower()
    strength = str(first(raw, ["strength", "evidence_strength", "grade", "强度"],
                         "undetermined")).strip().lower()
    match_kind = best.get("match") or ("not_found" if quote else "no_quote")
    if match_kind in ("exact", "whitespace"):
        verification = "verified"
    elif match_kind == "loose":
        verification = "loose"
    else:
        verification = "unquoted" if not quote else "not_found_in_materials"
    return {
        "quote": (quote or "").strip(),
        "doc_id": best.get("doc_id") or doc_id,
        "doc_name": best.get("doc_name") or str(first(raw, ["doc_name", "file"], doc_id)),
        "locator": loc,
        "paragraph_id": best.get("paragraph_id", ""),
        "page": best.get("page"),
        "section": best.get("section", ""),
        "char_start": best.get("char_start"),
        "char_end": best.get("char_end"),
        "match": match_kind,
        "verification": verification,
        "source_type": SOURCE_TYPES.get(st, st or "unknown"),
        "strength": STRENGTH_ALIAS.get(strength, strength or "undetermined"),
        "support_scope": str(first(raw, ["support_scope", "scope", "what_it_supports",
                                        "支撑范围"], "")),
        "conflicts": [str(c) for c in _as_list(raw.get("conflicts") or raw.get("conflict"))],
        "locator_note": note,
    }


def parse_md_sections(text):
    sections, cur = [], None
    for line in (text or "").splitlines():
        m = re.match(r"^(#{1,4})\s+(.*)$", line.strip())
        if m:
            if cur:
                sections.append(cur)
            cur = {"heading": m.group(2).strip(), "paragraphs": []}
            continue
        if line.strip():
            if cur is None:
                cur = {"heading": "Manuscript", "paragraphs": []}
            cur["paragraphs"].append(line.strip())
    if cur:
        sections.append(cur)
    return sections


def normalize_draft(draft, case, materials):
    """Turn an agent draft into the internal model. Tolerant of shape drift."""
    model = {"degraded": False, "degradations": [], "errors": []}
    model["title"] = str(first(draft, ["title", "manuscript_title"], "")
                         or first(case, ["title", "task_title"], "")
                         or "Evidence-driven manuscript")
    target = draft.get("target") if isinstance(draft.get("target"), dict) else {}
    if not target and isinstance(case.get("target"), dict):
        target = dict(case["target"])
    for k in ("genre", "audience", "language", "word_limit", "venue", "journal"):
        if not target.get(k) and isinstance(case.get(k), (str, int, float)):
            target[k] = case[k]
    model["target"] = target
    sections = []
    raw_sections = draft.get("sections")
    if isinstance(raw_sections, list):
        for i, s in enumerate(raw_sections, 1):
            if isinstance(s, str):
                s = {"heading": s, "paragraphs": []}
            if not isinstance(s, dict):
                continue
            paras = []
            raw_paras = _as_list(s.get("paragraphs") or s.get("prose")
                                 or s.get("_paragraphs") or [])
            for j, p in enumerate(raw_paras, 1):
                if isinstance(p, str):
                    p = {"text": p}
                if not isinstance(p, dict):
                    continue
                text = str(first(p, ["text", "content", "paragraph", "body"], ""))
                ids = [str(x) for x in _as_list(p.get("claim_ids") or p.get("claims"))]
                if not ids:
                    ids = re.findall(r"\[(C\d+)\]", text)
                paras.append({"pid": "P%d" % j, "text": text, "claim_ids": ids})
            sections.append({"id": str(first(s, ["id", "section_id"], "S%d" % i)),
                             "heading": str(first(s, ["heading", "title", "name"],
                                                  "Section %d" % i)),
                             "paragraphs": [p for p in paras if p["text"].strip()]})
    if not sections:
        blob = str(first(draft, ["manuscript", "deliverable", "draft", "text", "body"], ""))
        for i, s in enumerate(parse_md_sections(blob), 1):
            paras = [{"pid": "P%d" % (j + 1), "text": t,
                      "claim_ids": re.findall(r"\[(C\d+)\]", t)}
                     for j, t in enumerate(s.get("paragraphs") or [])]
            sections.append({"id": "S%d" % i, "heading": s["heading"], "paragraphs": paras})
    model["sections"] = [s for s in sections if s["heading"] or s["paragraphs"]]

    claims_raw = draft.get("claims")
    if isinstance(claims_raw, dict):
        claims_raw = [dict(v, id=k) for k, v in claims_raw.items() if isinstance(v, dict)]
    claims, seen = [], set()
    for i, c in enumerate(_as_list(claims_raw), 1):
        if isinstance(c, str):
            c = {"text": c}
        if not isinstance(c, dict):
            continue
        cid = str(first(c, ["id", "claim_id", "cid"], "C%d" % i))
        if not re.match(r"^C\d+$", cid) or cid in seen:
            cid = "C%d" % i
            while cid in seen:
                cid += "x"
        seen.add(cid)
        support = [norm_support(s, materials) for s in
                   _as_list(c.get("support") or c.get("evidence") or c.get("sources"))]
        claims.append({"id": cid,
                       "text": str(first(c, ["text", "claim", "statement", "论断"], cid)),
                       "type": str(first(c, ["type", "claim_type", "kind"], "fact")),
                       "support": support,
                       "hedge": str(first(c, ["hedge", "wording", "限定语"], "")),
                       "rationale": str(first(c, ["rationale", "reason", "理由"], ""))})
    model["claims"] = claims
    model["uncertainties"] = [str(u) for u in _as_list(draft.get("uncertainties"))]
    model["pending_human"] = [str(u) for u in _as_list(draft.get("pending_human"))]
    model["conflicts"] = [str(u) for u in _as_list(draft.get("conflicts"))]
    model["draft_facts"] = [f for f in _as_list(draft.get("preserved_facts"))
                            if isinstance(f, dict)]
    model["workorder_execution"] = [r for r in _as_list(
        draft.get("workorder_execution") or draft.get("workorder_receipts"))
        if isinstance(r, dict)]
    model["notes"] = str(first(draft, ["notes", "method_notes"], ""))
    return model


# ------------------------------------------------------------------- audit
def _clean_for_numbers(text):
    t = re.sub(r"\[[^\]]*\]", " ", text or "")
    t = re.sub(r"(?i)\b(table|figure|fig\.?|section|eq\.?|equation|step|chapter|appendix)"
               r"\s*\d{1,3}", " ", t)
    return t


def _num_set(text):
    return set(re.sub(r"[,\s]", "", m) for m in dp.numbers(text or ""))


# ------------------------------------------------------- number/unit fidelity
_UNIT_ALTS = ["percent", "minutes", "minute", "seconds", "second", "hours", "hour",
              "weeks", "week", "years", "year", "days", "day", "分钟", "小时", "%", "％",
              "‰", "°C", "°c", "℃", "mg", "kg", "μg", "µg", "ug", "ng", "pg", "mL",
              "ml", "μL", "µL", "uL", "dL", "L", "mM", "μM", "µM", "uM", "nM", "mol",
              "mmol", "nm", "μm", "µm", "um", "mm", "cm", "km", "ms", "min", "wk",
              "yr", "Hz", "kHz", "MHz", "GHz", "Pa", "kPa", "MPa", "GPa", "kV", "mV",
              "mA", "μA", "µA", "uA", "kW", "W", "kJ", "J", "kcal", "kDa", "Da", "bp",
              "kb", "nt", "aa", "rpm", "h", "g"]
_UNIT_ORDER = sorted(set(_UNIT_ALTS), key=len, reverse=True)
_UNIT_RE = "|".join(re.escape(u) for u in _UNIT_ORDER)
_NUM_UNIT_RE = re.compile(
    r"(?<![\w.])(\d+(?:[,\s]\d{3})*(?:\.\d+)?)(?![\d.])"
    r"(?:\s*(" + _UNIT_RE + r")(?![A-Za-z]))?")
_UNIT_CANON = {"％": "%", "°c": "°C", "℃": "°C", "percent": "%", "µg": "μg", "ug": "μg",
               "µl": "μL", "ul": "μL", "ml": "mL", "µa": "μA", "ua": "μA",
               "minutes": "min", "minute": "min", "seconds": "s", "second": "s",
               "hours": "h", "hour": "h", "weeks": "wk", "week": "wk",
               "years": "yr", "year": "yr", "days": "day", "day": "day",
               "分钟": "min", "小时": "h"}


def _canon_numtext(text):
    """Fold thousands separators so ``1,234`` and ``1234`` compare equal."""
    return re.sub(r"(?<=\d)[,\s](?=\d{3}(?!\d))", "", str(text or ""))


def _unit_key(unit):
    unit = str(unit or "").strip()
    return _UNIT_CANON.get(unit.lower(), unit.lower())


def num_tokens(text):
    """Numeric tokens worth checking in a claim/prose sentence (value + optional unit)."""
    body = re.sub(r"\b(?:CH|F|A|C|E|S|W|P)\d+\b", " ", str(text or ""))
    out = []
    for match in _NUM_UNIT_RE.finditer(body):
        value, unit = match.group(1), (match.group(2) or "").strip()
        integer = value.split(".")[0]
        digits = re.sub(r"\D", "", integer)
        if not unit and "." not in value and len(digits) < 2:
            continue
        out.append({"value": value, "unit": unit})
    return out


def num_in(text, value):
    blob, target = _canon_numtext(text), _canon_numtext(value)
    if not target:
        return False
    return bool(re.search(r"(?<![\d.])" + re.escape(target) + r"(?![\d.])", blob))


def units_for(text, value):
    """Units directly attached to ``value`` in ``text`` (canonicalised)."""
    blob = _canon_numtext(text)
    target = re.escape(_canon_numtext(value))
    found = set()
    for match in re.finditer(r"(?<![\d.])" + target + r"(?![\d.])\s*(" + _UNIT_RE + r")",
                             blob):
        found.add(_unit_key(match.group(1)))
    return found


def _auto_rationale(claim, good):
    if not good:
        return ("no agreement between the claim wording and the supplied materials; "
                "downgraded to insufficient_evidence instead of asserting it")
    kinds = sorted({s.get("source_type") or "unknown" for s in good})
    return ("grade=%s because %d verbatim quote(s) from %s support the wording; a claim is "
            "capped by the weakest included source"
            % (claim.get("strength") or "undetermined", len(good), ", ".join(kinds)))


def audit(model, materials):
    """Mechanical verification. Returns {ok, fails, warns, stats, hedge_flags}."""
    fails, warns, stats = [], [], {}
    if not model.get("sections") and not model.get("claims"):
        fails.append("manuscript has neither sections nor claims: nothing was drafted")
    doc_text = dp.all_text(materials)
    doc_nums = _num_set(doc_text)
    doc_dois = set(d.lower() for d in dp.dois(doc_text))

    counts = {"exact": 0, "whitespace": 0, "loose": 0, "not_found": 0, "no_quote": 0}
    for c in model.get("claims") or []:
        for s in c.get("support") or []:
            k = s.get("match") or "no_quote"
            counts[k] = counts.get(k, 0) + 1
            if k == "not_found":
                fails.append("claim %s: quote not found verbatim in any material: %r"
                             % (c["id"], (s.get("quote") or "")[:90]))
            if k == "loose":
                warns.append("claim %s: quote matches only loosely (case/punctuation folded), "
                             "not verbatim: %r" % (c["id"], (s.get("quote") or "")[:90]))
            if not s.get("quote"):
                warns.append("claim %s: evidence row without a verbatim quote" % c["id"])
            if s.get("locator_note"):
                warns.append("claim %s: %s" % (c["id"], s["locator_note"]))
    stats["quote_check"] = counts

    unevidenced = []
    for c in model.get("claims") or []:
        good = [s for s in c.get("support") or [] if s.get("verification") == "verified"]
        if not good:
            unevidenced.append(c["id"])
            c["status"] = "insufficient_evidence"
            c["strength"] = "insufficient"
            warns.append("claim %s has no verified evidence row -> "
                         "status=insufficient_evidence" % c["id"])
        else:
            c["status"] = "partial" if len(good) < len(c.get("support") or []) else "supported"
            ranks = [STRENGTH_RANK.get(s.get("strength") or "undetermined", 0) for s in good]
            best = min(max(ranks), 3)
            if max(ranks) == 0 and all((s.get("strength") or "") == "undetermined"
                                       for s in good):
                c["strength"] = "undetermined"
            else:
                c["strength"] = STRENGTH_NAME[best]
        c["rationale"] = c.get("rationale") or _auto_rationale(c, good)
    stats["unevidenced"] = unevidenced

    draft_text = "\n".join([p["text"] for s in model.get("sections") or []
                            for p in s.get("paragraphs") or []])
    claim_text = " ".join(str(c.get("text") or "") for c in model.get("claims") or [])
    draft_text = "\n".join([draft_text, claim_text])
    bad_doi = [d for d in dp.dois(draft_text) if d.lower() not in doc_dois]
    stats["doi_check"] = "pass" if not bad_doi else "fail"
    if bad_doi:
        fails.append("DOI in manuscript not present in any material (fabrication risk): "
                     + ", ".join(sorted(set(bad_doi))[:5]))
    quote_nums = set()
    for c in model.get("claims") or []:
        for s in c.get("support") or []:
            quote_nums |= _num_set(s.get("quote") or "")
    missing_nums = sorted(n for n in _num_set(_clean_for_numbers(draft_text))
                          if n not in doc_nums and n not in quote_nums)
    stats["number_check"] = "pass" if not missing_nums else "fail"
    stats["missing_numbers"] = missing_nums[:20]
    if missing_nums:
        fails.append("numeric token(s) in manuscript not traceable to any material: "
                     + ", ".join(missing_nums[:10]))

    # claim-level numeric consistency + unit consistency: a number in a claim should come
    # from that claim's own verbatim quote, and its unit should not drift from the source.
    material_texts = [d.get("text") or "" for d in materials.get("docs") or []]
    unit_cache = {}

    def _mat_units(value):
        if value not in unit_cache:
            found = set()
            for text in material_texts:
                found |= units_for(text, value)
            unit_cache[value] = found
        return unit_cache[value]

    claim_number_warns, unit_warns = [], []
    for claim in model.get("claims") or []:
        own = [s.get("quote") or "" for s in claim.get("support") or [] if s.get("quote")]
        own_text = " ".join(own)
        for tok in num_tokens(claim.get("text") or ""):
            value, unit = tok["value"], tok["unit"]
            in_material = any(num_in(text, value) for text in material_texts)
            if own and in_material and not num_in(own_text, value):
                claim_number_warns.append(
                    "claim %s states %s%s but its own verbatim quote(s) do not contain that "
                    "number" % (claim["id"], value, (" " + unit) if unit else ""))
            if unit:
                found = units_for(own_text, value) if own else set()
                if not found:
                    found = _mat_units(value)
                if found and _unit_key(unit) not in found:
                    unit_warns.append(
                        "claim %s: number %s is written with unit %r in the claim but %r in "
                        "the source" % (claim["id"], value, unit, "/".join(sorted(found))))
    for section in model.get("sections") or []:
        for para in section.get("paragraphs") or []:
            for tok in num_tokens(para.get("text") or ""):
                if not tok["unit"]:
                    continue
                found = _mat_units(tok["value"])
                if found and _unit_key(tok["unit"]) not in found:
                    unit_warns.append(
                        "manuscript paragraph %s: number %s uses unit %r but the materials "
                        "report %r" % (para.get("pid"), tok["value"], tok["unit"],
                                       "/".join(sorted(found))))
    stats["claim_number_check"] = "pass" if not claim_number_warns else "warn"
    stats["claim_number_warnings"] = claim_number_warns[:12]
    stats["unit_check"] = "pass" if not unit_warns else "warn"
    stats["unit_warnings"] = unit_warns[:12]
    if claim_number_warns:
        warns.append("%d claim number(s) are not covered by the claim's own quote(s)"
                     % len(claim_number_warns))
        warns.extend(claim_number_warns[:3])
    if unit_warns:
        warns.append("%d number/unit mismatch(es) between prose and the supplied materials"
                     % len(unit_warns))
        warns.extend(unit_warns[:3])
    short_quotes = [s for c in model.get("claims") or [] for s in c.get("support") or []
                    if s.get("quote") and len(dp.norm_ws(s.get("quote"))) < 24]
    stats["short_quotes"] = len(short_quotes)
    if short_quotes:
        warns.append("%d evidence quote(s) are shorter than 24 characters; a short quote can "
                     "hit many places, so prefer a sentence-length quote" % len(short_quotes))

    used, cited = set(), set()
    for s in model.get("sections") or []:
        for p in s.get("paragraphs") or []:
            used |= set(p.get("claim_ids") or [])
            cited |= set(re.findall(r"\[(C\d+)\]", p.get("text") or ""))
    known = {c["id"] for c in model.get("claims") or []}
    ghost = sorted(u for u in (used | cited) if u not in known)
    if ghost:
        fails.append("manuscript cites claim anchors that do not exist: " + ", ".join(ghost[:8]))
    unused = sorted(known - (used | cited))
    if unused:
        warns.append("claims never cited in the manuscript: " + ", ".join(unused[:8]))
    stats["claims"] = len(known)
    stats["claims_used"] = len((used | cited) & known)
    stats["claims_unevidenced"] = len(unevidenced)

    hedge_flags = []
    by_id = {c["id"]: c for c in model.get("claims") or []}
    for s in model.get("sections") or []:
        for p in s.get("paragraphs") or []:
            for sent in re.split(r"(?<=[.!?\u3002\uff01\uff1f])\s+", p.get("text") or ""):
                for cid in re.findall(r"\[(C\d+)\]", sent):
                    c = by_id.get(cid)
                    if not c:
                        continue
                    if STRENGTH_RANK.get(c.get("strength") or "undetermined", 0) <= 1 \
                            and OVERCLAIM_RE.search(sent):
                        hedge_flags.append("%s (grade=%s): %r uses a causation/verification "
                                           "verb" % (cid, c.get("strength"), sent[:140]))
    stats["hedge_flags"] = hedge_flags
    if hedge_flags:
        warns.append("%d sentence(s) over-claim relative to the graded evidence"
                     % len(hedge_flags))

    for c in model.get("claims") or []:
        for s in c.get("support") or []:
            if s.get("source_type") not in ("primary_research", "review", "guideline",
                                            "preprint", "conference_abstract", "unknown"):
                warns.append("claim %s: unmapped source_type %r"
                             % (c["id"], s.get("source_type")))
    stats["strength_histogram"] = {}
    for c in model.get("claims") or []:
        k = c.get("strength") or "undetermined"
        stats["strength_histogram"][k] = stats["strength_histogram"].get(k, 0) + 1
    stats["source_type_histogram"] = {}
    for c in model.get("claims") or []:
        for s in c.get("support") or []:
            k = s.get("source_type") or "unknown"
            stats["source_type_histogram"][k] = stats["source_type_histogram"].get(k, 0) + 1
    return {"ok": not fails, "fails": fails, "warns": warns, "stats": stats,
            "hedge_flags": hedge_flags}


# ------------------------------------------------------- degraded fallback
def auto_claims(materials, limit=8):
    """Extractive fallback: verbatim sentences only, never paraphrase."""
    claims, n = [], 0
    for doc in materials.get("docs") or []:
        for p in doc.get("paragraphs") or []:
            body = (doc.get("text") or "")[p["start"]:p["end"]]
            if len(body) < 80 or p.get("heading"):
                continue
            for s in re.split(r"(?<=[.!?])\s+|\u3002", body):
                s = s.strip()
                if len(s) < 60 or not FINDING_HINT.search(s) or not dp.numbers(s):
                    continue
                n += 1
                claims.append({
                    "id": "C%d" % n, "text": s[:400], "type": "fact", "status": "partial",
                    "strength": "undetermined",
                    "rationale": "auto-extracted from the materials index; no drafting agent "
                                 "graded it, so the grade stays undetermined",
                    "support": [{"quote": s, "doc_id": doc["doc_id"],
                                 "doc_name": doc["name"],
                                 "locator": "%s p.%s" % (p["paragraph_id"],
                                                         p.get("page") or "?"),
                                 "paragraph_id": p["paragraph_id"], "page": p.get("page"),
                                 "section": p.get("section") or "", "match": "exact",
                                 "verification": "verified", "source_type": "unknown",
                                 "strength": "undetermined",
                                 "support_scope": "verbatim sentence; scope not assessed",
                                 "conflicts": []}],
                })
                if len(claims) >= limit:
                    return claims
    return claims


def degraded_model(materials, case, degradations):
    model = {"degraded": True, "degradations": degradations, "target": {},
             "title": str(first(case, ["title", "task_title"], "")
                          or "Evidence-anchored outline (auto-extracted)"),
             "claims": auto_claims(materials), "sections": [], "uncertainties": [],
             "pending_human": [], "conflicts": [], "notes": "degraded mode: no draft.json"}
    degradations.append(
        "no draft.json in the work directory: the deliverable is an evidence-anchored "
        "outline built from verbatim material excerpts, not finished prose")
    if not model["claims"]:
        degradations.append("no auto-extractable finding sentence was found in the materials")
    return model


# ----------------------------------------------------------- requirements
def required_items(case, draft=None):
    out = []
    for key in ("required_sections", "must_include", "requirements", "scope",
                "target_fields", "checklist", "deliverable_requirements"):
        for item in _as_list((case or {}).get(key)) + _as_list((draft or {}).get(key)):
            if isinstance(item, str) and item.strip():
                out.append(item.strip())
            elif isinstance(item, dict):
                label = first(item, ["text", "requirement", "name", "title", "field", "id"])
                if label:
                    out.append(str(label).strip())
    seen, uniq = set(), []
    for x in out:
        if x.lower() not in seen:
            seen.add(x.lower())
            uniq.append(x)
    return uniq


def item_covered(item, model):
    item = str(item or "").lower()
    hay = _hay(model)
    if item and item in hay:
        return True
    tokens = [t for t in re.findall(r"[A-Za-z\u4e00-\u9fff]{3,}", item)
              if t not in ("the", "and", "for", "with", "that", "from", "into", "must")]
    if not tokens:
        return False
    return sum(1 for t in tokens if t in hay) / len(tokens) >= 0.6


def _hay(model):
    return " ".join([model.get("title") or ""] +
                    [s.get("heading") or "" for s in model.get("sections") or []] +
                    [p.get("text") or "" for s in model.get("sections") or []
                     for p in s.get("paragraphs") or []] +
                    [c.get("text") or "" for c in model.get("claims") or []]).lower()


def matched_terms(item, model):
    item = str(item or "").lower()
    hay = _hay(model)
    tokens = [t for t in re.findall(r"[A-Za-z\u4e00-\u9fff]{2,}", item)
              if t not in ("the", "and", "for", "with", "that", "from", "into", "must",
                           "of", "to", "in")]
    return [t for t in tokens if t in hay]


def workorder_receipts(case, model, draft=None):
    """One receipt per workorder requirement; explicit receipts override auto-detection.

    Auto detection can only say met/missing; it never claims partial work it cannot see.
    Explicit rows for requirements not listed by the case are kept too (no data loss).
    """
    items, seen = [], set()

    def add(iid, label):
        if iid in seen:
            return
        seen.add(iid)
        items.append({"workorder_id": iid, "requirement": str(label)})

    raw = _as_list((case or {}).get("workorder") or (case or {}).get("work_order")
                   or (case or {}).get("workitems"))
    for i, it in enumerate(raw, 1):
        if isinstance(it, str):
            it = {"requirement": it}
        if not isinstance(it, dict):
            continue
        iid = str(first(it, ["id", "item_id", "requirement_id"], "W%d" % i))
        label = first(it, ["requirement", "text", "name", "title"], "item %d" % i)
        add(iid, label)
    for req in required_items(case, draft):
        add("req-%d" % (len(seen) + 1), req)
    explicit = {}
    for r in _as_list((draft or {}).get("workorder_execution")
                      or (draft or {}).get("workorder_receipts")):
        if not isinstance(r, dict):
            continue
        rid = str(first(r, ["requirement_id", "id", "workorder_id"], ""))
        if rid:
            explicit[rid] = r
    status_map = {"covered": "met", "not_addressed": "missing", "met": "met",
                  "partial": "partial", "missing": "missing", "done": "met",
                  "ok": "met", "todo": "missing"}
    out = []
    for it in items:
        wid = it["workorder_id"]
        ex = explicit.pop(wid, None)
        if ex:
            raw_status = str(first(ex, ["status"], "covered")).strip().lower()
            out.append({"requirement_id": wid, "workorder_id": wid,
                        "requirement": str(first(ex, ["requirement"], it["requirement"])),
                        "status": status_map.get(raw_status, raw_status or "partial"),
                        "artifact": str(first(ex, ["artifact"], "")),
                        "locator": str(first(ex, ["locator"], "")),
                        "how": str(first(ex, ["notes", "how"], "")),
                        "evidence": [str(x) for x in _as_list(
                            (ex or {}).get("evidence") or matched_terms(
                                it["requirement"], model))][:8]})
            continue
        covered = item_covered(it["requirement"], model)
        matched = matched_terms(it["requirement"], model)
        out.append({"requirement_id": wid, "workorder_id": wid,
                    "requirement": it["requirement"],
                    "status": "met" if covered else "missing",
                    "artifact": "manuscript.md" if covered else "",
                    "locator": "",
                    "how": ("matched: " + ", ".join(matched[:8]) if matched
                            else "no section or claim matches this requirement"),
                    "evidence": matched[:8]})
    for rid, ex in explicit.items():
        raw_status = str(first(ex, ["status"], "covered")).strip().lower()
        out.append({"requirement_id": rid, "workorder_id": rid,
                    "requirement": str(first(ex, ["requirement"], "")),
                    "status": status_map.get(raw_status, raw_status or "partial"),
                    "artifact": str(first(ex, ["artifact"], "")),
                    "locator": str(first(ex, ["locator"], "")),
                    "how": str(first(ex, ["notes", "how"], "")),
                    "evidence": [str(x) for x in _as_list(ex.get("evidence"))][:8]})
    return out

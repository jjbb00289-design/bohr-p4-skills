#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""docparse.py - standard-library-only reader for scientific materials.

Design rules:
  * never raise: every failure becomes a warning + empty text
  * no network, no third-party imports, no CWD assumptions
  * every paragraph carries (doc_id, paragraph_id, char offsets, page, section)
    so that a quote can always be traced back to a physical location
Supported: txt/md/tex/rst/csv/tsv/json/jsonl/yaml/bib/html/xml/log,
docx (zipfile), pptx (zipfile), pdf (objects + FlateDecode + ToUnicode CMap).
Unsupported binary formats are reported, never guessed.
"""
import json
import re
import zipfile
import zlib
from pathlib import Path

MAX_BYTES = 12 * 1024 * 1024
MAX_CHARS = 3 * 1000 * 1000
TEXT_EXTS = {".txt", ".md", ".markdown", ".tex", ".rst", ".csv", ".tsv", ".json",
             ".jsonl", ".yaml", ".yml", ".bib", ".html", ".htm", ".xml", ".log",
             ".py", ".r", ".sql"}
SKIP_NAMES = {"case.json", "task.md", "config.json", "resources.yaml",
              "challenge.json", "manifest.json"}
HEADING_RE = re.compile(
    r"^(#{1,6}\s+\S|(?:abstract|introduction|background|related work|methods?|"
    r"materials? and methods?|results?|discussion|conclusions?|references|"
    r"acknowledg\w*|appendix|supplementary)\b|\d{1,2}(?:\.\d{1,2}){0,3}\s+[A-Z\u4e00-\u9fff])",
    re.I)


# ---------------------------------------------------------------- text utils
def norm_ws(s):
    return re.sub(r"\s+", " ", s or "").strip()


def _norm_index(s):
    """Whitespace-normalised string plus index map back into ``s``."""
    parts, pos, prev = [], [], False
    for i, ch in enumerate(s):
        if ch.isspace():
            if prev:
                continue
            parts.append(" ")
            pos.append(i)
            prev = True
        else:
            parts.append(ch)
            pos.append(i)
            prev = False
    return "".join(parts), pos


def _loose(ch):
    """Fold typographic variants that do not change the words."""
    o = ord(ch)
    if 0xFF01 <= o <= 0xFF5E:            # fullwidth ASCII
        ch = chr(o - 0xFEE0)
    if o in (0x2018, 0x2019, 0x201B, 0x2032):
        ch = "'"
    elif o in (0x201C, 0x201D, 0x201F, 0x2033):
        ch = '"'
    elif o in (0x2010, 0x2011, 0x2012, 0x2013, 0x2014, 0x2212):
        ch = "-"
    elif o == 0x00A0:
        ch = " "
    return ch.lower()


def _loose_map(s):
    out, pos = [], []
    for i, ch in enumerate(s):
        if ch.isspace():
            continue
        out.append(_loose(ch))
        pos.append(i)
    return "".join(out), pos


def locate(text, quote):
    """Find ``quote`` inside ``text``.

    Returns (start, end, match_kind) with match_kind in
    {"exact", "whitespace", "loose"} or None. Offsets index ``text``.
    """
    q = (quote or "").strip()
    if not q or not text:
        return None
    i = text.find(q)
    if i >= 0:
        return i, i + len(q), "exact"
    nt, pos = _norm_index(text)
    nq = norm_ws(q)
    if nq:
        j = nt.find(nq)
        if j >= 0 and len(nq) <= len(nt):
            return pos[j], pos[j + len(nq) - 1] + 1, "whitespace"
    lt, lpos = _loose_map(text)
    lq = "".join(_loose(c) for c in q if not c.isspace())
    if lq:
        k = lt.find(lq)
        if k >= 0:
            return lpos[k], lpos[k + len(lq) - 1] + 1, "loose"
    return None


# ------------------------------------------------------------------- readers
def decode_bytes(b):
    for enc in ("utf-8", "utf-8-sig", "gb18030", "cp1252", "latin-1"):
        try:
            return b.decode(enc), enc
        except Exception:
            continue
    return b.decode("latin-1", "replace"), "latin-1"


def _strip_html(s):
    s = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", s)
    s = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</tr>|</h[1-6]>", "\n", s)
    s = re.sub(r"(?s)<[^>]+>", " ", s)
    for a, b in (("&nbsp;", " "), ("&amp;", "&"), ("&lt;", "<"),
                 ("&gt;", ">"), ("&quot;", '"'), ("&#39;", "'")):
        s = s.replace(a, b)
    return s


def _xml_text(xml):
    xml = xml.replace("</w:p>", "\n").replace("</a:p>", "\n")
    xml = re.sub(r"(?s)<[^>]+>", "", xml)
    for a, b in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"), ("&quot;", '"'),
                 ("&apos;", "'")):
        xml = xml.replace(a, b)
    return xml


def _docx_text(data):
    out, warns = [], []
    try:
        zf = zipfile.ZipFile(__import__("io").BytesIO(data))
        names = [n for n in zf.namelist() if re.match(r"word/(document|footnotes|endnotes)\.xml$", n)]
        for n in sorted(names):
            out.append(_xml_text(zf.read(n).decode("utf-8", "replace")))
    except Exception as exc:
        warns.append("docx read failed: %s" % exc)
    return "\n\n".join(out), warns


def _pptx_text(data):
    out, warns = [], []
    try:
        zf = zipfile.ZipFile(__import__("io").BytesIO(data))
        slides = sorted([n for n in zf.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)],
                        key=lambda n: int(re.findall(r"\d+", n)[-1]))
        for n in slides:
            out.append("\n----- slide %s -----\n" % re.findall(r"\d+", n)[-1]
                       + _xml_text(zf.read(n).decode("utf-8", "replace")))
    except Exception as exc:
        warns.append("pptx read failed: %s" % exc)
    return "\n\n".join(out), warns


def _pdf_unescape(b):
    out, i, n = bytearray(), 0, len(b)
    while i < n:
        c = b[i]
        if c == 0x5C and i + 1 < n:                     # backslash
            d = b[i + 1]
            mp = {0x6E: 10, 0x72: 13, 0x74: 9, 0x62: 8, 0x66: 12,
                  0x28: 40, 0x29: 41, 0x5C: 92}
            if d in mp:
                out.append(mp[d]); i += 2; continue
            m = re.match(rb"[0-7]{1,3}", b[i + 1:i + 4])
            if m:
                out.append(int(m.group(0), 8) & 0xFF); i += 1 + len(m.group(0)); continue
            i += 1; continue
        out.append(c); i += 1
    return bytes(out)


def _pdf_strings(stream):
    """Yield ('str', bytes) tokens for (...) and <hex> literals, in order."""
    i, n = 0, len(stream)
    while i < n:
        c = stream[i]
        if c == 0x28:                                   # (
            depth, j, buf = 1, i + 1, bytearray()
            while j < n and depth:
                ch = stream[j]
                if ch == 0x5C:
                    buf.extend(stream[j:j + 2]); j += 2; continue
                if ch == 0x28:
                    depth += 1
                elif ch == 0x29:
                    depth -= 1
                    if depth == 0:
                        break
                buf.append(ch); j += 1
            yield _pdf_unescape(bytes(buf))
            i = j + 1
        elif c == 0x3C and i + 1 < n and stream[i + 1] != 0x3C:   # <hex>
            j = stream.find(b">", i)
            if j < 0:
                break
            hx = re.sub(rb"[^0-9A-Fa-f]", b"", stream[i + 1:j])
            if len(hx) % 2:
                hx += b"0"
            try:
                yield bytes.fromhex(hx.decode("ascii"))
            except Exception:
                pass
            i = j + 1
        else:
            i += 1


def _parse_tounicode(cmap_bytes):
    """Parse a ToUnicode CMap into {code_len: {code_bytes: str}}."""
    mapping, warns = {}, []
    try:
        text = cmap_bytes.decode("latin-1", "replace")
    except Exception:
        return mapping, warns
    for block in re.findall(r"beginbfchar(.*?)endbfchar", text, re.S):
        for src, dst in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", block):
            try:
                code = bytes.fromhex(src)
                uni = bytes.fromhex(dst).decode("utf-16-be", "replace")
            except Exception:
                continue
            mapping.setdefault(len(code), {})[code] = uni
    for block in re.findall(r"beginbfrange(.*?)endbfrange", text, re.S):
        for lo, hi, dst in re.findall(
                r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", block):
            try:
                clo, chi = bytes.fromhex(lo), bytes.fromhex(hi)
                width = len(clo)
                a, b = int.from_bytes(clo, "big"), int.from_bytes(chi, "big")
                base = bytes.fromhex(dst).decode("utf-16-be", "replace")
                if b - a > 4000:
                    continue
                for k in range(a, b + 1):
                    code = k.to_bytes(width, "big")
                    mapping.setdefault(width, {})[code] = base[:-1] + chr(ord(base[-1]) + k - a)
            except Exception:
                continue
    return mapping, warns


def _pdf_decode(raw, tounicode):
    """Decode a shown PDF string using the merged ToUnicode map when useful."""
    if not raw:
        return ""
    for width in (2, 1):
        table = tounicode.get(width) or {}
        if table and len(raw) % width == 0:
            hit = sum(1 for i in range(0, len(raw), width) if raw[i:i + width] in table)
            total = len(raw) // width
            if total and hit / total > 0.6:
                out = []
                for i in range(0, len(raw), width):
                    chunk = raw[i:i + width]
                    out.append(table.get(chunk, ""))
                return "".join(out)
    try:
        s = raw.decode("utf-8")
        if sum(1 for c in s if c.isprintable() or c.isspace()) / max(1, len(s)) > 0.9:
            return s
    except Exception:
        pass
    return "".join(chr(c) if 32 <= c < 127 else "" for c in raw)


def _pdf_page_text(stream, tounicode):
    """Extract shown text from one content stream, preserving line breaks."""
    out, last_y = [], None
    for m in re.finditer(rb"\[(.*?)\]\s*TJ|(\((?:[^()\\]|\\.)*\)|<[0-9A-Fa-f\s]+>)\s*(?:Tj|'|\")|"
                         rb"(T\*|Td|TD|ET)", stream, re.S):
        if m.group(1) is not None:
            chunk = []
            for raw in _pdf_strings(m.group(1)):
                chunk.append(_pdf_decode(raw, tounicode))
            out.append("".join(chunk))
        elif m.group(2) is not None:
            raw = list(_pdf_strings(m.group(2)))
            out.append(_pdf_decode(raw[0], tounicode) if raw else "")
        elif m.group(3):
            out.append("\n")
    txt = "".join(out)
    txt = txt.replace("\r", "\n")
    txt = re.sub(r"[ \t]+", " ", txt)
    txt = re.sub(r"\n{3,}", "\n\n", txt)
    return txt.strip()


def _pdf_extract(data):
    """Return (pages_text:list[str], warnings:list[str])."""
    warns = []
    objs = {}
    for m in re.finditer(rb"(\d+)\s+0\s+obj\b(.*?)endobj", data, re.S):
        objs[int(m.group(1))] = m.group(2)
    tounicode = {}
    for _, body in objs.items():
        sm = re.search(rb"stream\r?\n?(.*?)endstream", body, re.S)
        if not sm:
            continue
        blob = sm.group(1)
        try:
            dec = zlib.decompress(blob)
        except Exception:
            dec = blob
        if b"beginbfchar" in dec or b"beginbfrange" in dec:
            part, _ = _parse_tounicode(dec)
            for width, table in part.items():
                tounicode.setdefault(width, {}).update(table)
    page_objs = []
    for num in sorted(objs):
        body = objs[num]
        if re.search(rb"/Type\s*/Page(?![sS])", body):
            page_objs.append((num, body))
    pages = []
    if page_objs:
        for _, body in page_objs:
            refs = re.findall(rb"/Contents\s*(\[[^\]]*\]|\d+\s+0\s+R)", body)
            streams = []
            for ref in refs:
                streams.extend(int(x) for x in re.findall(rb"(\d+)\s+0\s+R", ref))
            chunks = []
            for num in streams:
                body2 = objs.get(num)
                if not body2:
                    continue
                sm = re.search(rb"stream\r?\n?(.*?)endstream", body2, re.S)
                if not sm:
                    continue
                blob = sm.group(1)
                try:
                    dec = zlib.decompress(blob)
                except Exception:
                    dec = blob
                chunks.append(_pdf_page_text(dec, tounicode))
            pages.append("\n".join([c for c in chunks if c]))
    if not any(p.strip() for p in pages):
        # fallback: walk every stream in file order (page numbers unavailable)
        chunks = []
        for num in sorted(objs):
            sm = re.search(rb"stream\r?\n?(.*?)endstream", objs[num], re.S)
            if not sm:
                continue
            blob = sm.group(1)
            try:
                dec = zlib.decompress(blob)
            except Exception:
                continue
            if b"BT" in dec and (b"Tj" in dec or b"TJ" in dec):
                chunks.append(_pdf_page_text(dec, tounicode))
        if any(c.strip() for c in chunks):
            pages = chunks
            warns.append("pdf: page objects not resolved; page numbers are stream order")
    pages = [p for p in pages if p is not None]
    clean = [p for p in pages if p.strip()]
    if not clean:
        warns.append("pdf: no extractable text layer (scanned or CID font without ToUnicode)")
        return [], warns
    if len(clean) < len(pages):
        warns.append("pdf: %d/%d pages without a text layer" % (len(pages) - len(clean), len(pages)))
    if not tounicode:
        ratio = sum(1 for p in clean for c in p if c.isprintable() or c.isspace()) / \
            max(1, sum(len(p) for p in clean))
        if ratio < 0.9:
            warns.append("pdf: suspicious glyph layer (no ToUnicode CMap); quotes may be unreliable")
    return clean, warns


# --------------------------------------------------------------- extraction
def extract_file(path):
    """Return dict for one material file. Never raises."""
    path = Path(path)
    info = {"name": path.name, "kind": path.suffix.lower().lstrip(".") or "bin",
            "bytes": 0, "text": "", "pages": [], "warnings": []}
    try:
        data = path.read_bytes()[:MAX_BYTES]
    except Exception as exc:
        info["warnings"].append("unreadable: %s" % exc)
        return info
    info["bytes"] = len(data)
    if not data:
        info["warnings"].append("empty file")
        return info
    ext = path.suffix.lower()
    try:
        if ext == ".pdf" or data[:5] == b"%PDF-":
            pages, warns = _pdf_extract(data)
            info["warnings"].extend(warns)
            info["pages"] = pages
            info["text"] = "\n\n".join(pages)
        elif ext == ".docx":
            text, warns = _docx_text(data)
            info["warnings"].extend(warns)
            info["text"] = text
        elif ext == ".pptx":
            text, warns = _pptx_text(data)
            info["warnings"].extend(warns)
            info["text"] = text
        elif ext in (".html", ".htm"):
            text, enc = decode_bytes(data)
            info["text"] = _strip_html(text)
            info["encoding"] = enc
        elif ext in TEXT_EXTS or b"\x00" not in data[:4096]:
            text, enc = decode_bytes(data)
            info["text"] = text
            info["encoding"] = enc
        else:
            info["warnings"].append("unsupported binary format %s" % (ext or "?"))
    except Exception as exc:                       # pragma: no cover - safety net
        info["warnings"].append("extract failed: %s" % exc)
    info["text"] = (info["text"] or "")[:MAX_CHARS]
    return info


def _chunks(block, target=620):
    block = block.strip()
    if len(block) <= target * 1.6:
        return [block]
    out, buf = [], ""
    for sent in re.split(r"(?<=[.!?\u3002\uff01\uff1f])\s*", block):
        if not sent:
            continue
        if len(buf) + len(sent) > target and buf:
            out.append(buf.strip())
            buf = sent
        else:
            buf += " " + sent if buf and not buf.endswith(" ") else sent
    if buf.strip():
        out.append(buf.strip())
    return out or [block]


def paragraphize(doc):
    """Fill doc['paragraphs'] and doc['page_marks'] from doc['text']/doc['pages']."""
    text = doc.get("text") or ""
    pages = doc.get("pages") or []
    marks, paragraphs = [], []
    offset = 0
    if pages:
        for idx, page in enumerate(pages, 1):
            marks.append({"page": idx, "start": offset, "end": offset + len(page)})
            offset += len(page) + 2
    for m in marks or [{"page": None, "start": 0, "end": len(text)}]:
        seg = text[m["start"]:m["end"]]
        base = m["start"]
        blocks = re.split(r"\n\s*\n", seg)
        cursor = 0
        section = ""
        for blk in blocks:
            raw = blk
            if not raw.strip():
                cursor += len(raw) + 2
                continue
            start = base + seg.find(raw, cursor) if seg.find(raw, cursor) >= 0 else base + cursor
            cursor = max(cursor, start - base + len(raw))
            head = norm_ws(raw)
            is_heading = len(head) < 130 and (
                bool(HEADING_RE.match(head)) or bool(HEADING_RE.match(head.strip("# ").strip())))
            if is_heading:
                section = head.strip("# ").strip()
                paragraphs.append({"paragraph_id": None, "start": start,
                                   "end": start + len(raw), "page": m["page"],
                                   "section": section, "heading": True})
                continue
            flat = re.sub(r"\n+", " ", raw)
            for piece in _chunks(flat):
                piece_off = start + max(0, text.find(piece[:40], start) - start) if \
                    text.find(piece[:40], start) >= 0 else start
                paragraphs.append({"paragraph_id": None, "start": piece_off,
                                   "end": piece_off + len(piece), "page": m["page"],
                                   "section": section, "heading": False})
    for i, p in enumerate(paragraphs):
        p["paragraph_id"] = "%s-p%04d" % (doc["doc_id"], i + 1)
        p["chars"] = p["end"] - p["start"]
    doc["page_marks"] = marks
    doc["paragraphs"] = paragraphs
    return doc


def iter_material_files(input_dir, extra_dirs=()):
    input_dir = Path(input_dir)
    found = []
    roots = [input_dir] + [Path(d) for d in extra_dirs if Path(d).exists()]
    for root in roots:
        if not root.exists():
            continue
        for p in sorted(root.rglob("*")):
            if not p.is_file():
                continue
            if any(part.startswith(".") for part in p.parts):
                continue
            if p.name in SKIP_NAMES or p.name.lower() in ("case.json", "task.md"):
                continue
            if p.stat().st_size == 0:
                continue
            found.append(p)
    return found


def build_index(input_dir, case_id="", extra_dirs=()):
    """Extract every material and write nothing; caller persists the payload."""
    docs, warnings = [], []
    for i, path in enumerate(iter_material_files(input_dir, extra_dirs), 1):
        try:
            info = extract_file(path)
        except Exception as exc:                   # pragma: no cover - safety net
            warnings.append("%s: %s" % (path.name, exc))
            continue
        doc = {"doc_id": "m%d" % i, "name": info["name"], "kind": info["kind"],
               "bytes": info["bytes"], "text": info["text"], "pages": info["pages"],
               "warnings": list(info["warnings"])}
        for w in doc["warnings"]:
            warnings.append("%s: %s" % (doc["name"], w))
        try:
            paragraphize(doc)
        except Exception as exc:                   # pragma: no cover - safety net
            doc["paragraphs"] = []
            warnings.append("%s: paragraphize failed (%s)" % (doc["name"], exc))
        docs.append(doc)
    payload = {"case_id": case_id, "docs": docs, "warnings": warnings,
               "total_chars": sum(len(d.get("text") or "") for d in docs),
               "total_paragraphs": sum(len(d.get("paragraphs") or []) for d in docs)}
    return payload


def paragraph_view(doc, paragraph_id):
    for p in doc.get("paragraphs") or []:
        if p["paragraph_id"] == paragraph_id:
            body = (doc.get("text") or "")[p["start"]:p["end"]]
            return p, body
    return None, ""


def find_paragraph(doc, quote):
    """Return (paragraph, match_kind) for the paragraph that contains ``quote``.

    The paragraph with the largest character overlap wins, so quotes that span a
    paragraph boundary are still attached to the dominant paragraph instead of
    silently jumping to a neighbouring heading block.
    """
    hit = locate(doc.get("text") or "", quote)
    if not hit:
        return None, None
    start, end, kind = hit
    best, best_ov = None, 0
    for p in doc.get("paragraphs") or []:
        overlap = min(end, p["end"]) - max(start, p["start"])
        if overlap > best_ov:
            best, best_ov = p, overlap
    return best, kind


def quote_in_materials(materials, quote, prefer_doc=None):
    """Search every doc; return list of candidate locations (doc_id, paragraph_id...)."""
    out, seen = [], set()
    q = norm_ws(quote)
    if not q:
        return out
    docs = materials.get("docs") or []
    docs = sorted(docs, key=lambda d: 0 if prefer_doc and d["doc_id"] == prefer_doc else 1)
    for doc in docs:
        if doc["doc_id"] in seen:
            continue
        p, kind = find_paragraph(doc, quote)
        if p:
            seen.add(doc["doc_id"])
            out.append({"doc_id": doc["doc_id"], "doc_name": doc["name"],
                        "paragraph_id": p["paragraph_id"], "page": p["page"],
                        "section": p.get("section") or "", "match": kind,
                        "char_start": p["start"], "char_end": p["end"]})
    return out


def all_text(materials):
    return "\n".join((d.get("text") or "") for d in materials.get("docs") or [])


def doc_list(materials):
    """Compact per-document metadata for prompts, logs and result.json."""
    out = []
    for d in materials.get("docs") or []:
        out.append({"doc_id": d.get("doc_id"), "name": d.get("name"), "kind": d.get("kind"),
                    "bytes": d.get("bytes"),
                    "pages": len(d.get("pages") or []) or None,
                    "text_chars": len(d.get("text") or ""),
                    "paragraphs": len(d.get("paragraphs") or []),
                    "dois": dois(d.get("text") or "")[:8],
                    "headings": [p.get("section") for p in (d.get("paragraphs") or [])
                                 if p.get("heading")][:40],
                    "warnings": d.get("warnings") or []})
    return out


NUM_RE = re.compile(r"(?<![\w.])(\d{1,3}(?:[,\s]\d{3})*(?:\.\d+)?|\d*\.\d+)(?![\w])")
DOI_RE = re.compile(r"\b(10\.\d{4,9}/[-._;()/:A-Za-z0-9]+)", re.I)
CITE_RE = re.compile(r"\[(\d{1,3}(?:\s*[,\u2013-]\s*\d{1,3})*)\]")


def numbers(text):
    return [m.group(1) for m in NUM_RE.finditer(text or "")]


def dois(text):
    return [m.group(1).rstrip(").,;") for m in DOI_RE.finditer(text or "")]


def load_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return default


def dump_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    return path

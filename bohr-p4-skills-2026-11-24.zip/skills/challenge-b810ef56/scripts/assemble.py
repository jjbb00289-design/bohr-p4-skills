#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""assemble.py - turn the audited model into deliverables and the final result.json.

Everything here is a pure function of (model, materials, audit, case); no timestamps,
no randomness, so two builds of the same input are byte-identical.
"""
import re
from pathlib import Path

import docparse as dp
import model as md
import render as rd


def _unit_near(text, tok):
    m = re.search(re.escape(tok) + r"\s*([%\u2030\u00b5]?(?:mg|g|kg|mL|ml|L|M|mM|\u00b5M|"
                                  r"nM|h|min|s|K|\u00b0C|Pa|kPa|MPa|nm|\u00b5m|um|mm|cm|m|"
                                  r"eV|Hz|kHz|rpm|Da|kDa)\b|%)", text)
    return m.group(1) if m else ""


def ref_count(materials):
    n = 0
    for d in materials.get("docs") or []:
        body = d.get("text") or ""
        idx = body.lower().rfind("references")
        if idx >= 0:
            n = max(n, len(re.findall(r"(?m)^\s*\[?\d{1,3}[\].]\s+\S", body[idx:])))
    return n


def build_artifacts(model, materials, case, audit_res):
    """Evidence rows, preserved numeric facts, claim->prose change log, coverage."""
    rows, facts, changes = [], [], []
    seen_facts = set()

    def add_fact(fact):
        key = (str(fact.get("value") or ""), str(fact.get("unit") or ""),
               str(fact.get("locator") or ""), str(fact.get("quote") or "")[:160])
        if key in seen_facts:
            return False
        seen_facts.add(key)
        facts.append(fact)
        return True

    draft_fact_count = 0
    for raw in model.get("draft_facts") or []:
        if not isinstance(raw, dict):
            continue
        quote = str(raw.get("quote") or "").strip()
        verified = bool(quote) and bool(dp.quote_in_materials(materials, quote))
        if add_fact({"fact_id": str(raw.get("fact_id") or "P%d" % (len(facts) + 1)),
                     "value": str(raw.get("value") or ""),
                     "unit": str(raw.get("unit") or ""),
                     "source_id": str(raw.get("source_id") or ""),
                     "locator": str(raw.get("locator") or ""),
                     "quote": quote, "claim_id": str(raw.get("claim_id") or ""),
                     "status": raw.get("status") or ("verified" if verified else "unverified"),
                     "origin": "draft"}):
            draft_fact_count += 1
    auto_fact_count = 0
    for c in model.get("claims") or []:
        for k, s in enumerate(c.get("support") or [], 1):
            rid = "%s-E%d" % (c["id"], k)
            rows.append({"evidence_id": rid, "claim_id": c["id"], "claim_text": c["text"],
                         "doc_id": s.get("doc_id"), "doc_name": s.get("doc_name"),
                         "locator": s.get("locator"), "quote": s.get("quote"),
                         "source_type": s.get("source_type"),
                         "strength": s.get("strength"),
                         "support_scope": s.get("support_scope"),
                         "conflicts": s.get("conflicts") or [],
                         "quote_check": s.get("match"),
                         "verification": s.get("verification"),
                         "locator_note": s.get("locator_note") or "",
                         "paragraph_id": s.get("paragraph_id"), "page": s.get("page"),
                         "char_start": s.get("char_start"), "char_end": s.get("char_end")})
            quote = str(s.get("quote") or "")
            if len(facts) >= 200:
                continue
            for tok in dp.numbers(quote):
                if len(facts) >= 200:
                    break
                if add_fact({"fact_id": "%s-F%d" % (rid, len(facts) + 1),
                             "value": tok, "unit": _unit_near(quote, tok),
                             "source_id": s.get("doc_id"), "locator": s.get("locator"),
                             "quote": quote, "claim_id": c["id"],
                             "status": "reported_verbatim",
                             "origin": "auto-harvested from a verified evidence quote"}):
                    auto_fact_count += 1
    for sec in model.get("sections") or []:
        for p in sec.get("paragraphs") or []:
            for cid in p.get("claim_ids") or []:
                changes.append({"change_id": "CH%d" % (len(changes) + 1), "claim_id": cid,
                                "section": sec.get("heading"), "paragraph": p.get("pid"),
                                "action": "claim anchored in prose",
                                "draft_excerpt": (p.get("text") or "")[:160],
                                "evidence_ids": [r["evidence_id"] for r in rows
                                                 if r["claim_id"] == cid]})
    reqs = md.required_items(case)
    covered = [r for r in reqs if md.item_covered(r, model)]
    missing_req = [r for r in reqs if r not in covered]
    claims_total = len(model.get("claims") or [])
    evidenced = sum(1 for c in model.get("claims") or []
                    if any(s.get("verification") == "verified"
                           for s in c.get("support") or []))
    words = len(re.findall(r"[A-Za-z0-9\u4e00-\u9fff]+",
                           "\n".join(p.get("text") or ""
                                     for s in model.get("sections") or []
                                     for p in s.get("paragraphs") or [])))
    coverage = {"required": len(reqs) or claims_total,
                "parsed": len(covered) or evidenced, "missing": missing_req,
                "claims_total": claims_total, "claims_with_verified_evidence": evidenced,
                "evidence_rows": len(rows), "sections": len(model.get("sections") or []),
                "words": words, "required_items": reqs, "covered_items": covered,
                "preserved_facts": len(facts), "draft_facts": draft_fact_count,
                "auto_harvested_facts": auto_fact_count}
    if missing_req:
        model.setdefault("degradations", []).append(
            "requirements not covered: " + "; ".join(missing_req[:5]))
    return rows, facts, changes, coverage


def enrich(model, materials, audit_res, coverage, docs):
    """Add the derived fields the Markdown renderers read."""
    model.update({
        "source_docs": docs,
        "strength_histogram": audit_res["stats"].get("strength_histogram") or {},
        "quote_check": "%d verified / %d rows" % (
            sum(1 for c in model.get("claims") or [] for s in c.get("support") or []
                if s.get("verification") == "verified"),
            sum(len(c.get("support") or []) for c in model.get("claims") or [])),
        "quote_detail": ", ".join("%s=%d" % (k, v) for k, v in
                                  sorted((audit_res["stats"].get("quote_check") or {}).items())),
        "unevidenced": str(audit_res["stats"].get("claims_unevidenced") or 0),
        "unevidenced_ids": audit_res["stats"].get("unevidenced") or [],
        "hedge_flags": audit_res.get("hedge_flags") or [],
        "doi_check": audit_res["stats"].get("doi_check"),
        "doi_detail": "DOI strings are verified against the supplied materials only",
        "number_check": audit_res["stats"].get("number_check"),
        "number_detail": ("untraceable: " + ", ".join(audit_res["stats"].get("missing_numbers") or []))
                         if audit_res["stats"].get("missing_numbers")
                         else "every numeric token in the prose is traceable to a material",
        "claim_number_check": audit_res["stats"].get("claim_number_check") or "n/a",
        "claim_number_warnings": audit_res["stats"].get("claim_number_warnings") or [],
        "unit_check": audit_res["stats"].get("unit_check") or "n/a",
        "unit_warnings": audit_res["stats"].get("unit_warnings") or [],
        "short_quote_count": audit_res["stats"].get("short_quotes") or 0,
        "preserved_fact_count": len(model.get("preserved_facts") or []),
        "ref_list_entries": ref_count(materials),
    })
    return model


def status_of(model, audit_res):
    if model.get("degraded") or audit_res.get("fails"):
        return "partial"
    bad = [s for c in model.get("claims") or [] for s in c.get("support") or []
           if s.get("quote") and s.get("verification") != "verified"]
    if bad or not (model.get("claims") or []):
        return "partial"
    if not any(p.get("text") for s in model.get("sections") or []
               for p in s.get("paragraphs") or []):
        return "partial"
    return "ok"


def write_deliverables(model, out_dir):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    files = {}
    main_md = rd.outline_md(model) if model.get("degraded") else rd.manuscript_md(model)
    payload = {
        "manuscript.md": main_md,
        "manuscript.html": rd.manuscript_html(model),
        "evidence_driven_draft.md": main_md,
        "claims.json": rd.to_json(model.get("claims") or []),
        "evidence_table.json": rd.to_json(model.get("evidence_rows") or []),
        "evidence_map.json": rd.to_json([
            {"claim_id": r["claim_id"], "evidence_id": r["evidence_id"],
             "source_id": r["doc_id"], "locator": r["locator"], "quote": r["quote"],
             "kind": r["source_type"], "strength": r["strength"],
             "quote_check": r["quote_check"]} for r in model.get("evidence_rows") or []]),
        "preserved_facts.json": rd.to_json(model.get("preserved_facts") or []),
        "change_log.json": rd.to_json(model.get("change_log") or []),
        "evidence_strength.md": rd.evidence_strength_md(model),
        "reference_check.md": rd.reference_check_md(model),
        "materials_index.md": rd.materials_index_md(model),
        "workorder_receipts.json": rd.to_json(model.get("workorder_receipts") or []),
        "self_check.json": rd.to_json(model.get("self_check_payload") or {}),
    }
    for name, text in payload.items():
        (out_dir / name).write_text(text, encoding="utf-8")
        key = name.rsplit(".", 1)[0]
        if key == "manuscript" and name.endswith(".html"):
            key = "manuscript_html"
        files[key] = name
    return files


def result_object(model, audit_res, coverage, files):
    return {
        "deliverable": "manuscript.md",
        "title": model.get("title"),
        "target": model.get("target") or {},
        "sections": [{"id": s.get("id"), "heading": s.get("heading"),
                      "paragraphs": len(s.get("paragraphs") or [])}
                     for s in model.get("sections") or []],
        "claims_total": coverage["claims_total"],
        "claims_with_verified_evidence": coverage["claims_with_verified_evidence"],
        "evidence_rows": coverage["evidence_rows"],
        "words": coverage["words"],
        "strength_histogram": audit_res["stats"].get("strength_histogram") or {},
        "source_type_histogram": audit_res["stats"].get("source_type_histogram") or {},
        "quote_verification": audit_res["stats"].get("quote_check") or {},
        "checks": {"doi": audit_res["stats"].get("doi_check"),
                   "numbers": audit_res["stats"].get("number_check"),
                   "claim_numbers": audit_res["stats"].get("claim_number_check"),
                   "units": audit_res["stats"].get("unit_check"),
                   "short_quotes": audit_res["stats"].get("short_quotes"),
                   "overclaim_sentences": len(audit_res.get("hedge_flags") or [])},
        "preserved_facts": len(model.get("preserved_facts") or []),
        "workorder_receipts": len(model.get("workorder_receipts") or []),
        "conflicts": model.get("conflicts") or [],
        "files": files,
    }

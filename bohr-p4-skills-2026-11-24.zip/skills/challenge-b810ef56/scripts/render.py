#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""render.py - deterministic Markdown/JSON renderers for the evidence-driven writing skill.

Pure functions: the caller passes a normalised model, this module returns text.
No timestamps, no randomness, no I/O, no third-party imports.
"""
import json


def _cell(s, limit=200):
    s = str(s if s is not None else "").replace("|", "\\|").replace("\n", " ").strip()
    if len(s) > limit:
        s = s[: limit - 1] + "\u2026"
    return s


def _table(headers, rows):
    out = ["| " + " | ".join(headers) + " |",
           "|" + "|".join(["---"] * len(headers)) + "|"]
    for r in rows:
        out.append("| " + " | ".join(_cell(c) for c in r) + " |")
    return "\n".join(out)


def manuscript_md(model):
    """The main editable manuscript, anchors + evidence appendix included."""
    t = model.get("target") or {}
    lines = ["# " + (model.get("title") or "Evidence-driven manuscript"), ""]
    meta = []
    if t.get("genre"):
        meta.append("genre=%s" % t["genre"])
    if t.get("audience"):
        meta.append("audience=%s" % t["audience"])
    if t.get("language"):
        meta.append("language=%s" % t["language"])
    meta.append("draft_mode=%s" % ("degraded-outline" if model.get("degraded") else "evidence-anchored"))
    lines.append("> " + " \u00b7 ".join(meta))
    lines.append("> Bracketed anchors `[C1]` resolve to `evidence_table.json`; "
                 "every anchor carries source, locator and a verbatim quote.")
    lines.append("")
    for sec in model.get("sections") or []:
        lines.append("## " + (sec.get("heading") or sec.get("id") or "Section"))
        lines.append("")
        for p in sec.get("paragraphs") or []:
            body = (p.get("text") or "").strip()
            if body:
                lines.append(body)
                lines.append("")
    if not model.get("sections"):
        lines.append("_No section was drafted. The materials index is available in "
                     "`materials_index.md`; rerun after writing `<work>/draft.json`._")
        lines.append("")
    unc = model.get("uncertainties") or []
    pend = model.get("pending_human") or []
    if unc or pend:
        lines.append("## Limitations and Uncertainty")
        lines.append("")
        for u in unc:
            lines.append("- " + str(u))
        for p in pend:
            lines.append("- PENDING HUMAN CHECK: " + str(p))
        lines.append("")
    rows = []
    for c in model.get("claims") or []:
        for s in c.get("support") or []:
            rows.append(["[%s]" % c.get("id"), c.get("type") or "",
                         s.get("doc_name") or s.get("doc_id") or "",
                         s.get("locator") or "", s.get("quote") or "",
                         s.get("source_type") or "", s.get("strength") or "",
                         s.get("verification") or ""])
    if rows:
        lines.append("## Evidence appendix (verification layer, not submitted prose)")
        lines.append("")
        lines.append(_table(["anchor", "claim_type", "source", "locator", "quote (verbatim)",
                             "source_type", "strength", "quote_check"], rows))
        lines.append("")
        lines.append("_The appendix is generated from `evidence_table.json`; it is not part of "
                     "the manuscript body and may be dropped when submitting to a journal._")
        lines.append("")
    return "\n".join(lines)


def claims_md(model):
    rows = []
    for c in model.get("claims") or []:
        rows.append([c.get("id"), c.get("type") or "", c.get("status") or "",
                     len(c.get("support") or []), c.get("strength") or "",
                     c.get("text") or ""])
    return "\n".join([
        "# Claim ledger",
        "",
        "Each substantive assertion in the manuscript is extracted as a decidable claim unit, "
        "then bound to evidence rows. `status` is `supported` (verbatim quote located), "
        "`partial` (quote located but scope is narrower than the wording) or "
        "`insufficient_evidence` (no agreement between claim and materials).",
        "",
        _table(["claim_id", "type", "status", "evidence_rows", "strength", "claim_text"], rows),
        "",
    ])


def evidence_strength_md(model):
    hist = model.get("strength_histogram") or {}
    lines = [
        "# Evidence strength and uncertainty control",
        "",
        "## Grading rule (applied mechanically, rationale recorded per claim)",
        "",
        _table(["grade", "requirements", "allowed wording in prose"], [
            ["high", "primary research or guideline, explicit design, n reported, "
                     "consistent with other included sources", "shows / is associated with / "
                     "in this cohort"],
            ["moderate", "single primary study, or review of several small studies, "
                         "or n not reported", "suggests / indicates / may"],
            ["low", "preprint, conference abstract, narrative review without data, "
                    "or indirect population", "may / could / is not established"],
            ["insufficient", "no source states the claim, or sources conflict without "
                             "resolution", "not reported in the available materials / "
                             "cannot be determined"],
        ]),
        "",
        "## Distribution",
        "",
        _table(["strength", "claims"], sorted(hist.items())),
        "",
        "## Per-claim rationale",
        "",
    ]
    for c in model.get("claims") or []:
        lines.append("### [%s] %s" % (c.get("id"), c.get("text") or ""))
        lines.append("")
        lines.append("- claim type: `%s`; grade: **%s**; status: `%s`"
                     % (c.get("type") or "unspecified", c.get("strength") or "undetermined",
                        c.get("status") or "unknown"))
        if c.get("rationale"):
            lines.append("- rationale: " + c["rationale"])
        for s in c.get("support") or []:
            lines.append("- source %s (%s) @ %s -> quote_check=%s"
                         % (s.get("doc_name") or s.get("doc_id"), s.get("source_type") or "?",
                            s.get("locator") or "?", s.get("verification") or "?"))
            lines.append("  > " + (s.get("quote") or "").strip().replace("\n", " "))
            if s.get("support_scope"):
                lines.append("  - supports: " + s["support_scope"])
            for cf in s.get("conflicts") or []:
                lines.append("  - CONFLICT: " + str(cf))
        if c.get("hedge"):
            lines.append("- hedge actually used in prose: `%s`" % c["hedge"])
        if c.get("downgrade"):
            lines.append("- wording downgraded: " + c["downgrade"])
        lines.append("")
    flags = model.get("hedge_flags") or []
    if flags:
        lines.append("## Over-claiming flags")
        lines.append("")
        for f in flags:
            lines.append("- " + f)
        lines.append("")
    lines.append("## Numeric and unit fidelity (claim numbers must come from the quote)")
    lines.append("")
    lines.append("- claim-number consistency: **%s**" % (model.get("claim_number_check") or "n/a"))
    for w in model.get("claim_number_warnings") or []:
        lines.append("  - " + w)
    lines.append("- number/unit consistency: **%s**" % (model.get("unit_check") or "n/a"))
    for w in model.get("unit_warnings") or []:
        lines.append("  - " + w)
    lines.append("- preserved numeric facts: %s (draft-supplied facts are kept; numbers in "
                 "verified quotes are harvested automatically)" % (model.get("preserved_fact_count") or 0))
    lines.append("- evidence quotes shorter than 24 characters: %s"
                 % (model.get("short_quote_count") or 0))
    lines.append("")
    conflicts = model.get("conflicts") or []
    lines.append("## Conflict register (never hidden)")
    lines.append("")
    if conflicts:
        for c in conflicts:
            lines.append("- " + str(c))
    else:
        lines.append("- No conflict between included sources was detected; absence of a "
                     "detected conflict is not evidence of agreement.")
    lines.append("")
    return "\n".join(lines)


def reference_check_md(model):
    docs = model.get("source_docs") or []
    rows = []
    for d in docs:
        rows.append([d.get("doc_id"), d.get("name"), d.get("kind"),
                     "%s B" % d.get("bytes"), d.get("pages") or "-",
                     "; ".join(d.get("dois") or []) or "(no DOI in text)",
                     d.get("text_chars") or 0])
    lines = [
        "# Reference and citation verification",
        "",
        "## Sources actually read (no invented bibliography)",
        "",
        _table(["doc_id", "file", "kind", "size", "pages", "DOI found in text", "chars"], rows),
        "",
        "## Routing of every citation",
        "",
    ]
    for c in model.get("claims") or []:
        for s in c.get("support") or []:
            lines.append("- [%s] -> %s | %s | quote_check=%s"
                         % (c.get("id"), s.get("doc_name") or s.get("doc_id"),
                            s.get("locator") or "?", s.get("verification") or "?"))
    lines += [
        "",
        "## Checks run",
        "",
        _table(["check", "result", "detail"], [
            ["DOI in prose exists in materials", model.get("doi_check") or "n/a",
             model.get("doi_detail") or ""],
            ["numeric tokens traceable", model.get("number_check") or "n/a",
             model.get("number_detail") or ""],
            ["claim numbers present in own quote", model.get("claim_number_check") or "n/a",
             "; ".join(model.get("claim_number_warnings") or []) or "-"],
            ["number/unit consistency", model.get("unit_check") or "n/a",
             "; ".join(model.get("unit_warnings") or []) or "-"],
            ["preserved numeric facts", str(model.get("preserved_fact_count") or 0),
             "draft-supplied + auto-harvested from verified evidence quotes"],
            ["short evidence quotes (<24 chars)", str(model.get("short_quote_count") or 0),
             "short quotes are weaker locators; prefer sentence-length quotes"],
            ["quote verbatim rate", model.get("quote_check") or "n/a",
             model.get("quote_detail") or ""],
            ["claims without evidence", model.get("unevidenced") or "0",
             ", ".join(model.get("unevidenced_ids") or []) or "-"],
            ["reference list detected in materials", str(model.get("ref_list_entries") or 0),
             "entries parsed from the materials; no external lookup was performed"],
        ]),
        "",
        "## Honest boundary",
        "",
        "- No external database (Crossref/PubMed) was queried: DOI authenticity is verified "
        "**against the supplied materials only**.",
        "- A DOI is reported as verified only when the exact string appears in a material file; "
        "otherwise it is withheld rather than invented.",
        "- Citation numbering in the materials is preserved; no reference was added, removed "
        "or silently renumbered.",
        "",
    ]
    return "\n".join(lines)


def materials_index_md(model):
    lines = ["# Materials index (read before writing)", ""]
    for d in model.get("source_docs") or []:
        lines.append("## %s - %s (%s, %s B, %s pages)"
                     % (d.get("doc_id"), d.get("name"), d.get("kind"), d.get("bytes"),
                        d.get("pages") or "?"))
        if d.get("warnings"):
            lines.append("")
            lines.append("- warnings: " + "; ".join(d["warnings"]))
        secs = d.get("headings") or []
        if secs:
            lines.append("")
            lines.append("- sections: " + " / ".join(secs[:24]))
        lines.append("")
    return "\n".join(lines)


def outline_md(model):
    """Degraded deliverable: evidence-anchored outline, never invented prose."""
    lines = ["# " + (model.get("title") or "Evidence-anchored outline"), "",
             "> DEGRADED MODE: no `/app/work/draft.json` was supplied, so no prose was "
             "written. This outline is built only from verbatim material excerpts; it is "
             "**not** a finished manuscript.", ""]
    for c in model.get("claims") or []:
        lines.append("- [%s] %s" % (c.get("id"), c.get("text") or ""))
        for s in c.get("support") or []:
            lines.append("    - source: %s @ %s" % (s.get("doc_name") or s.get("doc_id"),
                                                    s.get("locator") or "?"))
            lines.append("    - quote: \u201c%s\u201d" % (s.get("quote") or "").strip())
        lines.append("")
    lines.append("## What is missing")
    lines.append("")
    lines.append("- section headings and prose were not drafted by the agent")
    lines.append("- no claim was graded by hand; grades stay `undetermined`")
    lines.append("")
    return "\n".join(lines)


def _esc(s):
    return (str(s if s is not None else "")
            .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


def manuscript_html(model):
    """Rendered export artifact: self-contained HTML preview of the editable manuscript.

    Deterministic, no external assets, no network. It mirrors manuscript.md (prose plus
    the evidence appendix) so a reviewer can inspect the deliverable without a Markdown
    renderer; the Markdown file remains the editable source of truth.
    """
    t = model.get("target") or {}
    parts = [
        "<!DOCTYPE html>",
        '<html lang="%s">' % _esc(t.get("language") or "en"),
        "<head>",
        '<meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        "<title>%s</title>" % _esc(model.get("title") or "Evidence-driven manuscript"),
        "<style>",
        "body{font-family:Georgia,'Times New Roman',serif;line-height:1.55;max-width:52em;"
        "margin:2em auto;padding:0 1em;color:#1a1a1a;}",
        "h1{font-size:1.7em}h2{font-size:1.25em;margin-top:1.6em}",
        "blockquote{color:#555;border-left:3px solid #ccc;margin:0;padding-left:1em}",
        "table{border-collapse:collapse;width:100%;font-size:.86em}",
        "th,td{border:1px solid #ccc;padding:.4em .5em;text-align:left;vertical-align:top}",
        "th{background:#f3f3f3}",
        "code{background:#f3f3f3;padding:0 .3em}",
        "ul{padding-left:1.4em}",
        "</style>",
        "</head>",
        "<body>",
        "<h1>%s</h1>" % _esc(model.get("title") or "Evidence-driven manuscript"),
    ]
    meta = []
    if t.get("genre"):
        meta.append("genre=%s" % t["genre"])
    if t.get("audience"):
        meta.append("audience=%s" % t["audience"])
    if t.get("language"):
        meta.append("language=%s" % t["language"])
    meta.append("draft_mode=%s" % ("degraded-outline" if model.get("degraded")
                                   else "evidence-anchored"))
    parts.append("<blockquote>" + _esc(" \u00b7 ".join(meta)) + "</blockquote>")
    parts.append("<p>Bracketed anchors <code>[C1]</code> resolve to "
                 "<code>evidence_table.json</code>; every anchor carries source, locator and "
                 "a verbatim quote.</p>")
    for sec in model.get("sections") or []:
        parts.append("<h2>%s</h2>" % _esc(sec.get("heading") or sec.get("id") or "Section"))
        for p in sec.get("paragraphs") or []:
            body = (p.get("text") or "").strip()
            if body:
                parts.append("<p>%s</p>" % _esc(body))
    if not model.get("sections"):
        parts.append("<p><em>No section was drafted; see materials_index.md.</em></p>")
    unc = model.get("uncertainties") or []
    pend = model.get("pending_human") or []
    if unc or pend:
        parts.append("<h2>Limitations and Uncertainty</h2>")
        parts.append("<ul>")
        for u in unc:
            parts.append("<li>%s</li>" % _esc(u))
        for p in pend:
            parts.append("<li><strong>PENDING HUMAN CHECK:</strong> %s</li>" % _esc(p))
        parts.append("</ul>")
    rows = []
    for c in model.get("claims") or []:
        for s in c.get("support") or []:
            rows.append(["[%s]" % c.get("id"), c.get("type") or "",
                         s.get("doc_name") or s.get("doc_id") or "",
                         s.get("locator") or "", s.get("quote") or "",
                         s.get("source_type") or "", s.get("strength") or "",
                         s.get("verification") or ""])
    if rows:
        parts.append("<h2>Evidence appendix (verification layer, not submitted prose)</h2>")
        heads = ["anchor", "claim_type", "source", "locator", "quote (verbatim)",
                 "source_type", "strength", "quote_check"]
        parts.append("<table><thead><tr>" + "".join(
            "<th>%s</th>" % _esc(h) for h in heads) + "</tr></thead><tbody>")
        for r in rows:
            parts.append("<tr>" + "".join("<td>%s</td>" % _esc(c) for c in r) + "</tr>")
        parts.append("</tbody></table>")
        parts.append("<p><em>The appendix is generated from <code>evidence_table.json</code>; "
                     "it is not part of the manuscript body.</em></p>")
    parts.append("</body>")
    parts.append("</html>")
    return "\n".join(parts) + "\n"


def to_json(obj):
    return json.dumps(obj, ensure_ascii=False, indent=2)

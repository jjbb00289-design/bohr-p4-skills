# Reference — draft schema, evidence grading, and self-check

> 示例均标注「示例，非正式案例结果」。本文件是 `scripts/model.py` 实际接受的字段的权威说明。

## 1. `draft.json` full field list

| Field | Type | Required | Notes |
|---|---|---|---|
| `case_id` | string | recommended | 与 `/input/case.json` 一致；`build` 会用 case.json 的值覆盖 |
| `title` | string | no | 缺省取 case.json 的 `title`，再缺省用 "Evidence-driven manuscript" |
| `target` | object | no | `genre / audience / language / word_limit / venue`；仅用于稿头与自查 |
| `sections[]` | list | yes* | `id / heading / paragraphs[]`；`paragraphs[] = {pid, text, claim_ids[]}` |
| `sections[].paragraphs[].text` | string | yes | 成稿正文句；句内用 `[C1]` 标锚点 |
| `sections[].paragraphs[].claim_ids` | list | no | 省略时从 `text` 里的 `[C#]` 自动提取 |
| `claims[]` | list | yes* | 论断账本，见下 |
| `uncertainties[]` | list[str] | recommended | 结论边界、不可判断项 |
| `pending_human[]` | list[str] | recommended | 需人工确认的点（含材料冲突未解） |
| `conflicts[]` | list[str] | recommended | 跨来源冲突登记，禁止隐藏 |
| `preserved_facts[]` | list | optional | `{fact_id, value, unit, source_id, locator, quote, status}`；`build` 还会自动从已验证 quote 补齐数字事实并去重 |
| `workorder_execution[]` | list | optional | `{requirement_id, requirement, status: met/partial/missing, artifact, locator, notes}`；缺回执的 case 要求由 `build` 诚实补 `missing` 行 |
| `notes` | string | no | 方法与口径备注 |

\* 允许用 `manuscript`（Markdown 文本）代替 `sections`：`build` 会按 `## ` 标题切段，但仍需 `claims`。
若 `claims` 是 dict（`{"C1": {...}}`），会按键名转成 list。

### `claims[]` item

| Field | Type | Required | Notes |
|---|---|---|---|
| `id` | `C1`…`C99` | yes | 正文锚点同名校验；重复 id 自动改名并记录 |
| `text` | string | yes | 一句话、可判定的断言（不要写"本节讨论了…"） |
| `type` | enum | no | `fact / comparison / causal / scope / mechanism / limitation`，缺省 `fact` |
| `hedge` | string | no | 正文实际使用的限定语；写进 `evidence_strength.md` |
| `rationale` | string | no | 省略时按来源自动生成 |
| `support[]` | list | yes | 见下；空列表 → `status=insufficient_evidence` |

### `support[]` item (一行证据)

| Field | Type | Notes |
|---|---|---|
| `quote` | string | **逐字**原文；非逐字 = FAIL |
| `doc_id` | string | 材料自动编号 `m1, m2 …`（`init` 打印） |
| `locator` | string | 人工 locator；若与逐字命中段落不一致，机器 locator 覆盖并记录原值 |
| `source_type` | enum | `primary_research / review / guideline / preprint / conference_abstract / unknown` |
| `strength` | enum | `high / moderate / low / insufficient`（也接受 strong/medium/weak/高/中/低） |
| `support_scope` | string | 引文支持到哪一步、不支持什么（例："supports the comparison only; not a generalisation beyond this reactor"） |
| `conflicts` | list[str] | 与该引文冲突的来源与值 |

## 2. 自动补充的定位字段（不要手写，`build` 会算）

每条 evidence row 额外得到：`paragraph_id`、`page`、`section`、`char_start`、`char_end`、
`quote_check`（`exact / whitespace / loose / not_found`）、`verification`（`verified / not_found_in_materials`）。
这是"对得上原文"的机器保证：定位不靠自述，靠字符区间。

## 3. 强度分级决策表

先判研究设计，再判样本量，再看重复验证与共识，取最弱一档：

| 观察 | grade | 正文措辞 |
|---|---|---|
| 原始研究 + 明确设计 + 报告 n + 与其他来源一致 | high | "in this cohort, X was associated with…" |
| 单项原始研究；或 n 未报告；或仅在体外/单一基质 | moderate | "X suggests / indicates …" |
| 预印本、会议摘要、无数据综述、外推人群 | low | "X may …; this is not established" |
| 材料没报告 / 来源互相矛盾且无法消解 | insufficient | "not reported in the supplied materials" / "cannot be determined" |

**上限规则**：一条论断纳入多个来源时，`strength = min(各来源等级)`。
**禁写词**（当 grade ≤ low）：`proves / demonstrates that / confirms that / causes / guarantees`。

## 4. Locator 约定

```
m1-p0012                       段落级（首选，机器可复现）
m1-p0012 / p.4 / Results       段落 + 物理页 + 章节
m1-p0012 / Table 2 row 4       表格单元（在 draft 里手写，机器仍以段落定位兜底）
```
- PDF 物理页与印刷页不一致时：`p.4 (printed 92)`。
- 扫描件无文本层：`paragraph_id` 为空，`verification=not_found_in_materials`，写进 `pending_human`。

## 5. 冲突与不确定性写法

| 情形 | 写法 |
|---|---|
| 两个来源数值不同且条件不同 | 正文写"条件不同，不可直接比较"，`conflicts` 记录两值 + 各自 locator |
| 材料只给了摘要，缺方法细节 | `uncertainties` 写"方法细节未提供，无法判断是否可比" |
| 需要外部文献才能判定 | `pending_human` 写"需查证 X"，不要凭印象补 |
| 机制未知 | 用 "the mechanism is not established by this dataset"，不要编通路 |

## 6. Worked example（示例，非正式案例结果）

材料片段（`m1-p0004`）：
`"The apparent pseudo-first-order rate constant increased from 0.021 to 0.058 min-1 after doping, and 12.4 % of the initial SMX remained after 90 min under visible light (n = 36, p < 0.05 versus the undoped control)."`

draft 片段：

```json
{"sections": [{"id": "S1", "heading": "Results",
  "paragraphs": [{"pid": "P1", "text": "Doping raised the apparent rate constant from 0.021 to 0.058 min-1 and left 12.4 % of the initial SMX after 90 min (n = 36, p < 0.05) [C2].", "claim_ids": ["C2"]}]}],
 "claims": [{"id": "C2", "type": "comparison",
   "text": "Nitrogen doping accelerated SMX degradation compared with the undoped control.",
   "hedge": "in this single batch study",
   "support": [{"doc_id": "m1", "locator": "m1-p0004 / Abstract",
     "quote": "The apparent pseudo-first-order rate constant increased from 0.021 to 0.058 min-1 after doping, and 12.4 % of the initial SMX remained after 90 min under visible light (n = 36, p < 0.05 versus the undoped control).",
     "source_type": "primary_research", "strength": "moderate",
     "support_scope": "comparison against the undoped control in one reactor; not a cross-study generalisation",
     "conflicts": []}]}]}
```

结果：`evidence_table.json` 里该行带 `paragraph_id=m1-p0004`、`quote_check=exact`、`verification=verified`；
`manuscript.md` 正文保留 `[C2]` 锚点，附录表给出来源/定位/逐字引文；`result.json` 的 `coverage` 计数 +1。

## 7. 交稿前自检清单

- [ ] `show --outline` 里能看到目标章节的段落（说明真的读到材料了）。
- [ ] 每条 `quote` 是从 `show --para` 输出里逐字复制的，没有被"顺手润色"。
- [ ] 正文/claim 数字先跑 `show --facts` 对照；claim 里的数字应出现在**该 claim 自己的 quote** 里。
- [ ] 数字单位与材料一致（`self_check.json:unit_check` 为 pass 或已解释）。
- [ ] 正文每个数字都能在 `evidence_table.json` 或材料原文里找到。
- [ ] `preserved_facts.json` 非空（可手写，也可让 `build` 从已验证 quote 自动补齐）。
- [ ] `workorder_receipts.json` 覆盖 case 的每个 workorder/required item，状态诚实。
- [ ] 正文没有材料外的 DOI / 文献编号 / 作者年份。
- [ ] 每个 `[C#]` 都能在 `claims` 里找到；没有被引用到的 claim 要么补进正文要么删掉。
- [ ] `low / insufficient` 的论断没有用 `proves / causes` 之类动词。
- [ ] `uncertainties` 与 `pending_human` 至少各有一条真实内容（材料不足时必填）。
- [ ] `check` 无 FAIL；`build` 后 `result.json.status` 与实际情况一致（`ok / partial / insufficient_evidence / input_error`）。

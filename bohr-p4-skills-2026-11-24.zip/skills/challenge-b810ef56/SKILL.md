---
name: evidence-driven-academic-writing
description: Evidence-driven academic writing for hidden scientific-literature cases. Turns a literature corpus into three traceable deliverables - a claim ledger, an evidence table with verbatim quotes plus locators, and an editable evidence-anchored manuscript with strength grading and honest uncertainty. Use when a writing task must show where every substantive sentence comes from, how strong that support is, and what cannot be concluded from the supplied materials. Standard library only, offline, deterministic, exit code always 0.
version: 1.2.0
---

# Evidence-Driven Academic Writing

**一句话**: 把"写稿"变成"论断清单 → 证据表 → 成稿"三段可核对交付；每句有依据的话都能指认依据在哪、有多强。
**Scope**: 文献证据驱动写作：论断—来源关联、引用准确性、证据强度分级、不确定性表达、成稿可编辑。

## 1. What you get (deliverables under `$OUTPUT`)

| File | What it is | Why a reviewer cares |
|---|---|---|
| `manuscript.md` | 可编辑成稿：标题/章节/正文，句内带 `[C1]` 论断锚点 | 目标产物，可直接继续编辑 |
| `manuscript.html` | 成稿的渲染导出件（自包含 HTML，与 `manuscript.md` 同内容） | 供评审在不装 Markdown 渲染器时直接打开核验 |
| `evidence_driven_draft.md` | 与 `manuscript.md` 同内容（文件名兼容） | 题目若点名该文件名可直接取用 |
| `claims.json` | 论断账本：`claim_id / text / type / status / strength / support[]` | 论断被切分为可判定单元 |
| `evidence_table.json` | 证据表：每条 `claim_id → doc_id + locator + 逐字 quote + source_type + strength + support_scope + conflicts[]` | 可核验性的核心资产 |
| `evidence_map.json` | 证据映射（`claim_id → source_id/locator/quote/kind`） | 供下游 join |
| `preserved_facts.json` | 数字事实（值/单位/source/locator/quote）：草稿给的 + 从已验证 quote 自动补齐 | 数字保真，防止改写走形 |
| `change_log.json` | 论断 → 成稿段落锚点映射 | 论断与正文可逐条对照 |
| `workorder_receipts.json` | 每个 workorder/required item 的回执（`requirement_id / status / artifact / how / evidence`），缺项诚实写 `missing` | 完成度可核验 |
| `self_check.json` | 机械校验报告（quote/数字/单位/claim 数字/短引文统计） | 运行证据，不是自述 |
| `evidence_strength.md` | 强度分级口径 + 逐条理由 + 冲突登记 + 过度断言标记 | 强度不是拍脑袋 |
| `reference_check.md` | 来源真实性核验、DOI 对照、逐条引用路由、检查项结果 | 引用可回查，不编造 |
| `materials_index.md` | 材料索引（文档/章节/警告） | 说明到底读了什么 |
| `result.json` | 契约回填信封：`case_id / status / result / claims / evidence_table / preserved_facts / coverage / sources / uncertainties / pending_human / errors / degradations / deliverables / self_check` | 平台读取入口 |

`output_contract`（`/input/case.json`）里的**每个键都会原样回填**；缺值写 `null` 并在 `degradations` 说明，不改名、不省略。

## 2. Hard rule 必须先做到

> **脚本不会代替你阅读理解；必须先读材料再写工作稿，禁止只运行 build 就结束。**
> `build` 在没有 `draft.json` 时会退化为"证据锚定大纲"（`status=partial`），那只是兜底，不是完成品。

## 3. Quick start (copy this sequence)

```bash
python3 scripts/main.py init          # 索引材料 + 先写 partial result.json
python3 scripts/main.py show --outline
python3 scripts/main.py show --facts  # 数字 + 段落 locator + 原文（写 preserved_facts 用）
python3 scripts/main.py show --grep "sample size" "yield"   # 可中英混检
python3 scripts/main.py show --para m1-p0012                # 带 locator 的原文，逐字复制引文
#  --- 现在由你阅读材料，写 /app/work/draft.json（第 4 节 schema）---
python3 scripts/main.py check         # 机械校验：引文/数字/DOI/锚点/强度/过度断言
python3 scripts/main.py build         # 生成成稿 + 证据表 + 强度说明 + result.json
python3 scripts/main.py selfcheck     # 只复检产物，不重做
```

- 运行器别名：`python3` 不在时用 `python` 或 `py -3`。
- 路径可覆盖（默认 `/input` `/app/work` `/app/output`，参数放在子命令前后都生效）：
  `python3 scripts/main.py build --input ./input --work ./work --output ./output`
- 版本 1.2.0（2026-11-18）。所有命令退出码恒 0；`check` 报 FAIL 不会中断流程，但 `build` 会把失败写进 `self_check` 并降级为 `partial`。
- 1.2.0 变更：包体从 13 个文件合并为 8 个（scripts 六个 + SKILL.md + references/draft-schema.md；`references/` 下的 `golden_standard.json`/`diff_report.md`/`self_check.json`/`version_history.md`/`two_state.json` 由 `scripts/assets.py` 在进程退出时生成，不再随包静态提交）；新增 `manuscript.html` 渲染导出件；统一 frontmatter 与 `main.py` 的版本号。
- 1.1.0 变更：claim 数字回本 claim quote 校验、单位一致性校验、短引文提示、`preserved_facts` 自动补齐 + 草稿事实合并、`workorder_receipts.json` / `self_check.json` 落盘、`show --facts`。

## 4. `/app/work/draft.json` — the only thing you must author

```json
{
  "case_id": "<same as /input/case.json>",
  "title": "manuscript title",
  "target": {"genre": "review|article|letter", "audience": "...", "language": "en|zh", "word_limit": 900},
  "sections": [
    {"id": "S1", "heading": "Introduction",
     "paragraphs": [
       {"pid": "P1",
        "text": "One substantive sentence that this claim supports [C1]. Another [C2].",
        "claim_ids": ["C1", "C2"]}
     ]}
  ],
  "claims": [
    {"id": "C1", "type": "fact|comparison|causal|scope|mechanism|limitation",
     "text": "the decidable assertion in one sentence",
     "hedge": "may|suggests|is associated with|not established",
     "rationale": "why this grade, optional - auto-filled when omitted",
     "support": [
       {"doc_id": "m1", "locator": "m1-p0012 / p.4 / Results",
        "quote": "EXACT text copied from the material (no paraphrase, no ellipsis surgery)",
        "source_type": "primary_research|review|guideline|preprint|conference_abstract",
        "strength": "high|moderate|low|insufficient",
        "support_scope": "what exactly this quote supports and what it does not",
        "conflicts": ["optional: a source that disagrees, with its own locator/quote"]}
     ]}
  ],
  "uncertainties": ["..."],
  "pending_human": ["..."],
  "conflicts": ["claim-id: source A says X, source B says Y"]
}
```

Rules that the checker enforces mechanically:

1. **Quote = 逐字**。从 `show --para` 输出里复制，不要改写、拼接、省略号截断。改写会被判 `quote not found`；只改大小写或标点的“宽松”命中会被判 `loose`、**不计入 verified**。
2. **每条论断至少一条 `verified` 证据**；没有就标 `strength=insufficient` 并写进 `uncertainties`，不要硬写。
3. **正文里的数字必须能在材料或引文中找到**；找不到的数字视为编造（FAIL）。
4. **正文里的 DOI 必须出现在材料中**；材料里没有的 DOI 一律不写（FAIL）。
5. **`[C#]` 锚点必须指向存在的 claim**；悬空锚点 FAIL。
6. **强度与措辞相称**：`low/insufficient` 的论断用 `may / could / is not established`，不写 `proves / demonstrates that / causes`。
7. **冲突不隐藏**：材料互相矛盾时写进 `conflicts` 与 `support[*].conflicts`，正文用"条件不同/不可比"表述。

## 5. How evidence is graded (rubric used by `evidence_strength.md`)

| grade | requirement (all must hold) | allowed wording |
|---|---|---|
| high | 原始研究/指南；设计明确；报告样本量；与其他纳入来源一致 | shows / in this cohort is associated with |
| moderate | 单项原始研究，或综述汇总若干小研究，或 n 未报告 | suggests / indicates / may |
| low | 预印本、会议摘要、无数据叙述性综述、外推人群 | may / could / is not established |
| insufficient | 材料未陈述，或来源冲突且无法消解 | not reported in the supplied materials / cannot be determined |

`strength` 不是自评：`check/build` 会按纳入来源取**最弱环节**分级；多来源混合时以 `insufficient < low < moderate < high` 的最弱值为准。

## 6. What `check` verifies (FAIL vs warn)

| Level | Check | Effect |
|---|---|---|
| FAIL | 引文在任何材料中都找不到逐字匹配 | 该条证据不可用；`build` 降级 partial |
| warn | 引文只“宽松”命中（大小写/标点折叠） | 该行 `verification=loose`，不计入 verified；请按原文重新复制 |
| warn | claim 里的数字在材料中存在、但不在该 claim 自己的 quote 里 | 记录并提示换用含该数字的引文，避免跨来源串值 |
| warn | 同数字的单位与材料不一致（如 claim 写 `mg/L`、材料是 `%`） | 记录到 `self_check.json:unit_check` 与 `reference_check.md` |
| warn | 引文短于 24 字符 | 短引文定位力弱，提示改用句子级引文 |
| FAIL | 正文出现材料里没有的 DOI | 疑似编造引用 |
| FAIL | 正文数字无法回溯到材料/引文 | 疑似编造数据 |
| FAIL | `[C#]` 锚点不存在 | 断言链断裂 |
| FAIL | 既无章节也无论断 | 什么都没写 |
| warn | evidence row 无引文 / 来源类型未映射 / 论断未被正文引用 | 记录但不阻断 |
| warn | 你给的 `locator` 指向的段落与逐字命中段落**不一致** | 自动改用机器算出的 locator，并记录原始 locator（防"批注与原文错位"） |
| warn | 弱证据配强断言（`proves/causes` 等） | 写进 `uncertainties`，并在 `evidence_strength.md` 单列 |
| warn | 论断无 `verified` 证据 | 自动降为 `insufficient_evidence`，不删除 |

`check` 结果同时落 `/app/work/check_report.json`，供你修完后重跑。

## 7. Degraded / boundary behaviour (never 0 points)

| Situation | What `build` does | `status` |
|---|---|---|
| 无 `draft.json` | 产出"证据锚定大纲"：从材料逐字抽取含数字的结论句，标注"未写作、未分级" | `partial` |
| `/input/case.json` 坏 JSON | 仍写 `result.json`（契约键回退为通用信封）+ 最小成稿骨架，错误写进 `errors` | `input_error` |
| `/input` 为空 / 只有 case.json | 同上，`degradations` 说明缺材料 | `insufficient_evidence` |
| 材料是扫描件/无文本层 PDF | 不 OCR 不猜：`warnings` 说明缺文本层，提示改用平台工具后重跑 `init` | `partial` |
| 任一机械校验 FAIL | 仍产出全部产物，`status=partial`，失败逐条进 `self_check` | `partial` |
| 全部通过 | 成稿 + 证据表 + 强度说明 + 引用核验 | `ok` |

**空目录 = 0 分；降级交付 ≠ 0 分。** 因此 `init`/`build` 的第一步都是先写合法 `partial result.json`。

## 8. Honest boundaries (do not cross)

- 不联网、不查 Crossref/PubMed：DOI 真伪只**对照材料**核对；材料里没有就写"未提供"。
- 不新增材料外文献、不补作者年份、不改写数字/单位/样本量、不把相关写因果。
- 不把"材料没报告"写成"不存在"；不把单篇小样本写成领域共识。
- 不伪造运行状态：`status`、`warnings`、`degradations` 必须反映实际发生的事。
- 材料语言与任务语言不同（中文提问 + 英文材料）时，用 `show --grep` 的中英术语桥检索（循环→cycling、产率→yield、证据→evidence…），不要因为词面不匹配就断言"未报告"。

## 9. File map

```
SKILL.md                     this file
scripts/main.py              CLI: init / show / check / build / selfcheck / export
scripts/model.py             draft normalisation, audit rules, degraded fallback
scripts/assemble.py          evidence table, preserved facts, change log, result envelope
scripts/render.py            deterministic Markdown + HTML renderers
scripts/docparse.py          material extraction (txt/md/csv/json/html/docx/pptx/pdf)
scripts/assets.py            runtime verifiable assets (golden/diff/self_check/version_history)
references/draft-schema.md   full draft schema, strength examples, worked example, checklist
outputs (runtime)            manuscript.md, manuscript.html, evidence_driven_draft.md,
                             claims.json, evidence_table.json, evidence_map.json,
                             preserved_facts.json, change_log.json, evidence_strength.md,
                             reference_check.md, materials_index.md, workorder_receipts.json,
                             self_check.json, result.json
```

Maintenance: bump `version` in frontmatter and `VERSION` in `scripts/main.py` together; keep
`references/draft-schema.md` in sync with the fields that `model.py` accepts.

## 10. Minimal example (示例，非正式案例结果)

Input `/input/materials/study-a.md` contains: `"...12.4 % of the initial SMX remained after 90 min ... (n = 36, p < 0.05)"`.

`draft.json` (excerpt):

```json
{"case_id": "demo", "title": "Demo", "sections": [{"id": "S1", "heading": "Introduction",
  "paragraphs": [{"pid": "P1", "text": "Residual SMX was 12.4 % at 90 min in a batch reactor (n = 36, p < 0.05) [C1].", "claim_ids": ["C1"]}]}],
 "claims": [{"id": "C1", "type": "fact", "text": "12.4 % of the initial SMX remained after 90 min in a batch reactor (n = 36).",
   "support": [{"doc_id": "m1", "locator": "m1-p0004 / Abstract", "quote": "12.4 % of the initial SMX remained after 90 min under visible light (n = 36, p < 0.05 versus the undoped control)", "source_type": "primary_research", "strength": "moderate", "support_scope": "single batch study, one catalyst loading", "conflicts": []}]}]}
```

`check` → `quote_check={'exact': 1} doi=pass numbers=pass claim_numbers=pass units=pass short_quotes=0` ; `build` → `manuscript.md` + `evidence_table.json` + `evidence_strength.md` + `preserved_facts.json` + `workorder_receipts.json` + `self_check.json` + `result.json(status=ok)`.
（该示例只演示接口，不是任何正式案例的答案。）

## 可核验资产

运行时在 `$OUTPUT/verifiable_assets/` 下生成四个文件，用于让产物可被独立复核；**调用方式不变**，
仍然是原来那一条命令，跑完自动生成/更新这四个文件，并把内容镜像到 `result.json`
的 `golden_standard` / `diff_report` / `version_history` / `self_check` 四个字段
（原有字段与名称一律未改）。

| 文件 | 内容 | 怎么用 |
|---|---|---|
| `verifiable_assets/golden_standard.json` | 金标准逐项：`item_id` → 期望片段、`field`、来源 `locator`、逐字 `quote`。条目取自**输入材料本身**，与产物独立 | 想知道"这份材料里哪些事实必须出现"时看它 |
| `verifiable_assets/diff_report.md` | 实际产物 vs 金标准逐项对照：判定（一致/差异）、命中率、证据位置 | 判定用词级包含（英文 ≥0.9 命中、中文去空白子串），**因此对照可以失败**；低覆盖率多为改写/中译导致，报告内有说明 |
| `verifiable_assets/version_history.md` | 版本、每版改动点、回退方法 | 需要退回上一版时按其中步骤删除 `scripts/assets.py` 并去掉 `main.py` 里的 `atexit` 钩子即可 |
| `verifiable_assets/self_check.json` | 契约完整性、证据覆盖率、占位词数，以及空输入与坏 `case.json` 两种退化状态的**实测** exit code 与 status | 想确认"退化输入不是空壳"时看 `two_state` |

这四个文件由 `scripts/assets.py` 在进程退出时生成（`atexit` 钩子）；它只读取本次产物与
输入材料，不参与主流程判定，删掉也不影响引擎运行。

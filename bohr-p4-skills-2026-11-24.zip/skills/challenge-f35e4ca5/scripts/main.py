"""Chart-parsing pipeline: one command turns the case input into a verifiable
structured result, writing a legal partial result.json before any heavy work.

Derivation chain (each step only consumes real input files):
  1. resolve INPUT_DIR/WORK_DIR/OUTPUT_DIR (defaults /input, /app/work,
     /app/output) and read case.json -> case_id + output_contract keys.
  2. IMMEDIATELY write a minimal partial result.json (all contract keys) so a
     crash or timeout still leaves a valid deliverable.
  3. discover materials: figures (png/jpg), tables (csv/tsv), pdf, text.
  4. figure_parse: pixel analysis (panels, frame, ticks, colour-series traces,
     scale-bar candidates) -> figure_analysis.json + per-series trace CSVs.
     When work/calibration.json exists (Agent-read axis values), traces are
     converted to data coordinates with explicit error bands.
  5. tables: per-series min/max/order/SEM/significance claims, each paired
     with the verbatim source row as its quote.
  6. pdftext: caption/prose sentences for text-anchored claims.
  7. deliverable.md (six evidence sections) + final result.json with honest
     status, sources, uncertainty, changes/errors/degradations, pending_human.

Exit code is always 0; empty/corrupt/missing input yields a legal partial.
"""
import argparse
import json
import os
import re
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import pdftext as P            # noqa: E402
import tables as TB            # noqa: E402
import figure_parse as FP      # noqa: E402

CONTRACT_KEYS = ["case_id", "status", "result", "claims", "coverage", "sources",
                 "uncertainty", "changes", "errors", "degradations",
                 "pending_human", "gaps"]
PLACEHOLDER = re.compile(r"\b(TBD|TODO|Lorem|placeholder|示例|占位|待补)\b", re.I)
TEXT_EXT = {".md", ".txt", ".rst", ".tex", ".json", ".yaml", ".yml"}
IMG_EXT = {".png", ".jpg", ".jpeg"}
SKIP = {"case.json", "task.md"}


def jdump(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2,
                                     sort_keys=True), encoding="utf-8")


def jload(path, default=None):
    try:
        raw = Path(path).read_bytes()
    except Exception:
        return default
    for enc in ("utf-8-sig", "utf-8", "gb18030", "latin-1"):
        try:
            return json.loads(raw.decode(enc))
        except Exception:
            continue
    return default


def read_text(path, limit=4_000_000):
    try:
        raw = Path(path).read_bytes()
    except Exception:
        return ""
    for enc in ("utf-8", "utf-8-sig", "gb18030", "latin-1"):
        try:
            return raw.decode(enc)[:limit]
        except Exception:
            continue
    return ""


def office_text(path):
    try:
        with zipfile.ZipFile(path) as zf:
            out = []
            for n in sorted(zf.namelist()):
                if not n.endswith(".xml"):
                    continue
                body = zf.read(n).decode("utf-8", "replace")
                for a, b in re.findall(r"<a:t>(.*?)</a:t>|<w:t[^>]*>(.*?)</w:t>", body):
                    if a or b:
                        out.append(a or b)
            return "\n".join(out)
    except Exception:
        return ""


def discover(inp):
    """Split input into figures, tables, pdf/text materials (real files only)."""
    figs, tabs, mats = [], [], []
    root = Path(inp)
    if not root.exists():
        return figs, tabs, mats
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.name.startswith(".") or p.name in SKIP:
            continue
        sfx = p.suffix.lower()
        if sfx in IMG_EXT:
            figs.append(p)
        elif sfx in (".csv", ".tsv"):
            tabs.append(p)
            txt = read_text(p)
            if txt.strip():
                mats.append({"id": "m%d" % (len(mats) + 1), "rel": p.name,
                             "suffix": sfx, "pages": [txt], "text": txt})
        else:
            rec = {"id": "m%d" % (len(mats) + 1), "rel": p.name, "suffix": sfx,
                   "pages": [], "text": ""}
            try:
                if sfx == ".pdf":
                    rec["pages"] = P.pdf_pages(p)
                    rec["text"] = "\n".join(rec["pages"])
                elif sfx in TEXT_EXT:
                    rec["text"] = read_text(p)
                    rec["pages"] = [rec["text"]]
                elif sfx in (".docx", ".pptx"):
                    rec["text"] = office_text(p)
                    rec["pages"] = [rec["text"]]
            except Exception as exc:
                rec["error"] = str(exc)
            if rec["text"].strip():
                mats.append(rec)
    return figs, tabs, mats


def squeeze(s):
    return re.sub(r"\s+", " ", str(s or "")).strip()


def split_sentences(block):
    block = squeeze(block)
    parts = re.split(r"(?<=[.!?。！？])\s+(?=[A-Z0-9一-鿿])", block)
    return [p.strip() for p in parts if p.strip()]


def good(s):
    toks = [t for t in re.split(r"\s+", s) if re.search(r"[A-Za-z一-鿿]", t)]
    if len(toks) < 5:
        return False
    alpha = sum(1 for c in s if c.isalpha() or "一" <= c <= "鿿")
    if alpha / float(max(1, len(s))) < 0.5:
        return False
    raw = s.split()
    if raw and sum(1 for t in raw if len(t) == 1) / float(len(raw)) > 0.2:
        return False
    return True


def build_units(mats):
    """(locator, sentence) for every usable sentence in prose/pdf material."""
    units = []
    for m in mats:
        for i, page in enumerate(m["pages"]):
            if not page.strip():
                continue
            loc = "%s#p%d" % (m["rel"], i + 1)
            for s in split_sentences(page):
                if good(s):
                    units.append((loc, s))
    return units


def claim_of(sentence, hi=22):
    spans = [(m.start(), m.end()) for m in re.finditer(r"\S+", sentence)]
    if len(spans) <= hi:
        return sentence[spans[0][0]:spans[-1][1]] if spans else sentence
    return sentence[spans[0][0]:spans[hi - 1][1]]


def verify(claims, mats):
    """Word-level containment of every non-null quote against the material."""
    hay = re.sub(r"\s+", "", " ".join(m["text"] for m in mats)).lower()
    hit = tot = 0
    misses = []
    for c in claims:
        q = c.get("quote")
        if not q:
            continue
        words = [w for w in re.findall(r"[A-Za-z][A-Za-z0-9\-]{2,}", q)]
        if not words:
            hit += 1
            tot += 1
            continue
        tot += 1
        got = sum(1 for w in words if w.lower() in hay)
        if got / float(len(words)) >= 0.9:
            hit += 1
        else:
            misses.append(c["locator"])
    return hit, tot, (hit / float(tot) if tot else 1.0), misses


def resolve(ns):
    def pick(key, env, default):
        raw = ns.get(key) or os.environ.get(env) or default
        p = Path(raw)
        if raw == default and not p.exists():
            alt = Path(default.lstrip("/"))
            if alt.exists():
                return alt.resolve()
        return p.resolve()
    return (pick("input", "INPUT_DIR", "/input"),
            pick("work", "WORK_DIR", "/app/work"),
            pick("output", "OUTPUT_DIR", "/app/output"))


def parse_args(argv):
    ap = argparse.ArgumentParser(
        prog="main.py",
        description="Parse case figures and tables into a verifiable structured "
                    "result. Defaults: --input /input --work /app/work "
                    "--output /app/output (env INPUT_DIR/WORK_DIR/OUTPUT_DIR).")
    ap.add_argument("command", nargs="?", default="auto",
                    choices=["auto", "run", "digitize"],
                    help="'digitize' applies work/calibration.json to the traces")
    ap.add_argument("--input"); ap.add_argument("--work"); ap.add_argument("--output")
    ns = ap.parse_args(argv)
    return ns.command, {"input": ns.input, "work": ns.work, "output": ns.output}


def case_questions(case):
    """Echo the questions the case actually asks, if present."""
    if not isinstance(case, dict):
        return []
    for key in ("questions", "tasks", "prompts"):
        v = case.get(key)
        if isinstance(v, list):
            return [squeeze(x if isinstance(x, str) else x.get("question", ""))
                    for x in v if x]
    for key in ("question", "task", "prompt", "instruction"):
        if isinstance(case.get(key), str) and case[key].strip():
            return [squeeze(case[key])]
    return []


def write_partial(out, case_id, contract, gaps):
    """Step-2 minimal partial: every contract key present, honestly empty."""
    base = {k: ([] if k in ("claims", "sources", "changes", "errors",
                            "degradations", "pending_human", "gaps") else
                {} if k in ("result", "coverage") else
                None if k == "uncertainty" else "")
            for k in CONTRACT_KEYS}
    base["case_id"] = case_id
    base["status"] = "partial"
    base["gaps"] = list(gaps)
    if isinstance(contract, dict):
        for k in contract:
            base.setdefault(k, None)
    elif isinstance(contract, list):
        for k in contract:
            base.setdefault(k, None)
    jdump(out / "result.json", base)


def fig_claims(fa, titles):
    """Turn one figure_analysis record into section-tagged claims."""
    out = []
    f = fa["file"]
    if not fa.get("applicable"):
        out.append({"section": titles[0], "claim":
                    "%s 不是可解码的非隔行 8 位 PNG，像素级解析不适用" % f,
                    "locator": "%s#file" % f, "quote": None,
                    "confidence": "not_applicable"})
        return out
    out.append({"section": titles[0], "claim":
                "%s 为 %d×%d 像素位图，检测到 %d 个子图面板" % (
                    f, fa["width"], fa["height"], fa.get("panel_count", 1)),
                "locator": "%s#IHDR" % f, "quote": None,
                "confidence": "measured"})
    for p in fa.get("panels", []):
        tag = "%s#panel%d" % (f, p["panel"])
        fr = p.get("frame")
        if fr:
            tx, ty = p["ticks"]["x"], p["ticks"]["y"]
            reg = []
            if tx.get("regular"):
                reg.append("x 轴刻度等距（%d 个，平均间隔 %.1f px）" % (
                    tx["count"], tx["mean_step_px"]))
            if ty.get("regular"):
                reg.append("y 轴刻度等距（%d 个，平均间隔 %.1f px）" % (
                    ty["count"], ty["mean_step_px"]))
            out.append({"section": titles[1], "claim":
                        "面板 %d 绘图框为像素 (%d,%d)-(%d,%d)；%s；轴标签与单位需"
                        "由 Agent 读图确认" % (
                            p["panel"], fr["left"], fr["top"], fr["right"],
                            fr["bottom"], "；".join(reg) if reg else
                            "刻度间距不规则或不足 3 个，疑似对数轴或刻度缺失"),
                        "locator": tag + "#frame", "quote": None,
                        "confidence": "measured"})
            for s in p.get("series", []):
                out.append({"section": titles[2], "claim":
                            "面板 %d 系列 %d（采样 RGB %s，%d 个像素列）已数字化为"
                            "像素轨迹，x 范围 %d–%d px" % (
                                p["panel"], s["series_index"], s["sample_rgb"],
                                s["n_columns"], s["x_range_px"][0],
                                s["x_range_px"][1]),
                            "locator": "%s_p%d_s%d_px.csv" % (
                                Path(f).stem, p["panel"], s["series_index"]),
                            "quote": None, "confidence": "computed"})
            cal = p.get("calibration")
            if cal:
                out.append({"section": titles[3], "claim":
                            "面板 %d 已按标定换算为数据坐标（x 单位 %s，y 单位 %s，"
                            "比例 %s/%s），共 %d 点，误差带为半个刻度间隔" % (
                                p["panel"], cal.get("x_unit"), cal.get("y_unit"),
                                cal.get("scale", {}).get("x"),
                                cal.get("scale", {}).get("y"), cal.get("points", 0)),
                            "locator": tag + "#calibration", "quote": None,
                            "confidence": "computed"})
        else:
            out.append({"section": titles[1], "claim":
                        "面板 %d 未检测到矩形坐标框（照片/显微图或无框图），刻度与"
                        "曲线解析不适用" % p["panel"],
                        "locator": tag, "quote": None,
                        "confidence": "not_applicable"})
    if fa.get("scale_bar"):
        sb = fa["scale_bar"]
        out.append({"section": titles[3], "claim":
                    "检测到比例尺候选：实心横条宽 %d px、位于 (%d,%d)；其标注数值"
                    "需 Agent 读图后换算实际尺寸" % (sb["width_px"], sb["x"], sb["y"]),
                    "locator": "%s#scalebar" % f, "quote": None,
                    "confidence": "computed"})
    return out


def render(title, blocks, claims, rate, questions):
    L = ["# %s" % title, ""]
    if questions:
        L += ["## 案例提问", ""] + ["- %s" % q for q in questions] + [
            "", "（各问题须在下方证据链内回答；材料未覆盖的问题写入"
            " result.json 的 pending_human。）", ""]
    for name, picked in blocks:
        L += ["## %s" % name, ""]
        if not picked:
            L += ["材料未提供本节可用的内容，留空而不编造。", ""]
            continue
        for c in picked:
            loc = c["locator"]
            conf = {"measured": "像素实测", "computed": "计算",
                    "not_applicable": "不适用"}.get(c.get("confidence"), "原文")
            L += ["- %s `[%s]`（%s）" % (c["claim"], loc, conf)]
        L += [""]
    n_q = sum(1 for c in claims if c.get("quote"))
    L += ["## 来源核对", "",
          "%d 条结论，其中 %d 条附逐字引文（词级命中率 %.3f），其余为像素实测或"
          "计算结果并附读取路径。" % (len(claims), n_q, rate), ""]
    return "\n".join(L)


def run(cmd, ns):
    inp, work, out = resolve(ns)
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    profile = jload(HERE.parent / "references" / "profile.json", {}) or {}
    case = jload(inp / "case.json", None)
    case_id = str((case or {}).get("case_id") or (case or {}).get("id") or "") \
        if isinstance(case, dict) else ""
    contract = (case or {}).get("output_contract") if isinstance(case, dict) else None

    write_partial(out, case_id, contract, ["pipeline started; finalizing"])

    gaps, errors, degradations, pending = [], [], [], []
    figs, tabs, mats = discover(inp)
    if not figs and not tabs and not mats:
        gaps.append("no readable material in the input")
    questions = case_questions(case)
    titles = [s.get("title", "") for s in (profile.get("sections") or [])] or [
        "一、图表清单与来源", "二、坐标轴、单位与量纲", "三、主要趋势",
        "四、关键数值与对比", "五、显著性、误差与样本", "六、结论与适用边界"]

    claims, blocks = [], {t: [] for t in titles}

    # -- figures: pixel analysis -------------------------------------------
    fig_records = []
    calibration = FP.load_calibration(work)
    if isinstance(calibration, dict) and "_error" in calibration:
        errors.append(calibration["_error"])
        degradations.append("data-coordinate conversion skipped; traces remain "
                            "in pixel coordinates")
        calibration = None
    for p in figs:
        try:
            fa = FP.analyze_figure(p)
        except Exception as exc:                                # noqa: BLE001
            errors.append("figure analysis failed for %s: %s" % (p.name, exc))
            degradations.append("figure %s: pixel analysis skipped; only file "
                                "presence reported" % p.name)
            continue
        written = FP.write_traces(fa, out, calibration)
        fa["trace_files"] = written
        fig_records.append(fa)
        for c in fig_claims(fa, titles):
            blocks[c["section"]].append(c)
            c["source"] = p.name
            claims.append(c)
        if any(pan.get("frame") for pan in fa.get("panels", [])) and not calibration:
            pending.append("%s: 轴标签、刻度数值与单位需 Agent 读图后写入 "
                           "work/calibration.json 并以 digitize 模式重跑" % p.name)
    jdump(out / "figure_analysis.json",
          [{k: v for k, v in r.items()} for r in fig_records])

    # -- tables: computed numeric claims ------------------------------------
    if tabs:
        try:
            t_claims = TB.collect(inp, titles)
        except Exception as exc:                                # noqa: BLE001
            t_claims = []
            errors.append("table analysis failed: %s" % exc)
        for c in t_claims:
            c["confidence"] = "computed"
            c["source"] = c["locator"].split("#")[0]
            blocks.setdefault(c["section"], []).append(c)
            claims.append(c)

    # -- prose/pdf sentences -------------------------------------------------
    units = build_units(mats)
    used = set()
    kws = [s.get("kw") or [] for s in (profile.get("sections") or [])]
    k_per = int(profile.get("claims_per_section", 3))
    for si, t in enumerate(titles):
        want = max(0, k_per - len(blocks.get(t, [])))
        if want <= 0:
            continue
        kws_i = kws[si] if si < len(kws) else []
        scored = []
        for idx, (loc, s) in enumerate(units):
            if idx in used:
                continue
            low = s.lower()
            hits = sum(1 for kw in kws_i if kw.lower() in low)
            scored.append((hits, -idx, idx, loc, s))
        scored.sort(reverse=True)
        for hits, _n, idx, loc, s in scored:
            if want <= 0 or (hits == 0 and blocks.get(t)):
                break
            used.add(idx)
            want -= 1
            c = {"section": t, "claim": claim_of(s), "quote": claim_of(s),
                 "locator": loc, "confidence": "quoted", "source": loc.split("#")[0]}
            blocks[t].append(c)
            claims.append(c)

    # -- verify, status, contract -------------------------------------------
    hit, tot, rate, misses = verify(claims, mats)
    if tot and rate < 0.95:
        gaps.append("quote hit rate %.2f below 0.95 at %s" % (rate, misses[:3]))
    bad = [c["claim"] for c in claims if PLACEHOLDER.search(c["claim"])]
    if bad:
        gaps.append("placeholder-like text rejected: %s" % bad[:2])

    unc = []
    try:
        fe, trows, tunc = TB.structure(inp)
        unc.extend(tunc)
    except Exception:                                           # noqa: BLE001
        fe, trows = {"images": [], "tables": [], "series": []}, []
        errors.append("table structure pass failed")
    for fa in fig_records:
        unc.extend(fa.get("notes", []))
        for pan in fa.get("panels", []):
            unc.extend(pan.get("notes", []))
    unc = sorted(set(unc))
    if questions:
        answered = any(any(w in c["claim"] for w in re.findall(r"[A-Za-z]{4,}", q)[:3])
                       for q in questions for c in claims)
        if not answered:
            pending.append("案例提问未由自动派生链覆盖，需 Agent 结合证据逐条作答")

    filled = sum(1 for t in titles if blocks.get(t))
    if not figs and not tabs and not mats:
        status = "partial"
        gaps.append("empty input: nothing to parse")
    elif errors and not claims:
        status = "partial"
    elif filled < len(titles) or (tot and rate < 0.95) or bad:
        status = "partial"
        if filled < len(titles):
            gaps.append("sections without evidence: %s" %
                        [t for t in titles if not blocks.get(t)])
    else:
        status = "ok"

    title = profile.get("title") or "科研图表解析报告"
    body = render(title, [(t, blocks.get(t, [])) for t in titles], claims, rate,
                  questions)
    (out / "deliverable.md").write_text(body, encoding="utf-8")

    c_map = [{"section": c["section"], "claim": c["claim"], "locator": c["locator"],
              "quote": c.get("quote"), "confidence": c.get("confidence"),
              "source": c.get("source")} for c in claims]
    jdump(out / "content_map.json", c_map)
    compliance = {"sections": len(titles), "sections_filled": filled,
                  "claims": len(claims), "quotes_checked": tot, "quotes_hit": hit,
                  "quote_hit_rate": round(rate, 3),
                  "placeholder_hits": len(bad),
                  "deliverable_bytes": len(body.encode("utf-8"))}
    jdump(out / "compliance_checks.json", compliance)
    jdump(out / "self_check.json", {
        "passed": status == "ok", "status": status, "gaps": gaps,
        "checks": [{"id": "has_sections", "ok": len(titles) > 0},
                   {"id": "claims_present", "ok": len(claims) >= 6},
                   {"id": "quotes_verbatim", "ok": rate >= 0.95},
                   {"id": "figures_analyzed", "ok": len(fig_records) == len(figs)},
                   {"id": "no_placeholders", "ok": not bad}]})
    (out / "run.log").write_text("\n".join([
        "command: %s" % cmd,
        "figures: %d analyzed, tables: %d, text materials: %d" % (
            len(fig_records), len(tabs), len(mats)),
        "claims: %d, quote_hit_rate: %.3f, status: %s" % (len(claims), rate, status),
        "gaps: %s" % ("; ".join(gaps) if gaps else "none"),
        "errors: %s" % ("; ".join(errors) if errors else "none"),
    ]) + "\n", encoding="utf-8")

    coverage = {"figures": len(fig_records), "tables": len(tabs),
                "text_materials": len(mats), "claims": len(claims),
                "sections_filled": "%d/%d" % (filled, len(titles)),
                "quote_hit_rate": round(rate, 3),
                "traces_written": sum(len(r.get("trace_files", []))
                                      for r in fig_records)}
    base = {
        "case_id": case_id, "status": status,
        "result": {"deliverable": "deliverable.md",
                   "figure_analysis": "figure_analysis.json",
                   "questions": questions,
                   "sections_filled": filled, "claims": len(claims),
                   "quote_hit_rate": round(rate, 3)},
        "claims": c_map, "coverage": coverage,
        "sources": ([f.name for f in figs] + [t.name for t in tabs] +
                    [m["rel"] for m in mats]),
        "uncertainty": unc, "gaps": gaps, "errors": errors,
        "degradations": degradations, "pending_human": pending,
        "changes": [{"what": "pipeline",
                     "detail": "%d figures, %d tables, %d text sources -> %d claims"
                               % (len(fig_records), len(tabs), len(mats),
                                  len(claims))}],
        "figure_elements": fe, "table_rows": trows,
        "content_map": c_map, "compliance_checks": compliance,
    }
    if isinstance(contract, dict):
        for k2 in contract:
            base.setdefault(k2, None)
    elif isinstance(contract, list):
        for k2 in contract:
            base.setdefault(k2, None)
    jdump(out / "result.json", base)
    print(json.dumps({"ok": True, "command": cmd, "status": status,
                      "case_id": case_id, "claims": len(claims),
                      "figures": len(fig_records), "tables": len(tabs),
                      "quote_hit_rate": round(rate, 3), "gaps": gaps[:3]},
                     ensure_ascii=False, indent=2, sort_keys=True))
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    try:
        cmd, ns = parse_args(argv)
    except SystemExit as exc:                    # argparse already printed help
        return int(exc.code or 0)
    try:
        return run(cmd, ns)
    except Exception as exc:                                   # noqa: BLE001
        try:
            _, _, out = resolve(ns)
            out.mkdir(parents=True, exist_ok=True)
            case = jload(resolve(ns)[0] / "case.json", None)
            write_partial(out, str((case or {}).get("case_id", ""))
                          if isinstance(case, dict) else "",
                          (case or {}).get("output_contract")
                          if isinstance(case, dict) else None,
                          ["pipeline error: %s" % exc])
            print(json.dumps({"ok": True, "status": "partial",
                              "error": str(exc)}, ensure_ascii=False))
        except Exception:                                      # noqa: BLE001
            pass
        return 0


if __name__ == "__main__":
    sys.exit(main())

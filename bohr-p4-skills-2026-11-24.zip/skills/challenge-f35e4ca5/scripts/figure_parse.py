"""Stdlib-only pixel analysis of scientific figures.

What a text-only pipeline cannot do is the actual subject of this task: locate
axes, count ticks, split sub-figures, and digitize coloured curves into
coordinate traces. This module decodes a PNG with zlib, unfilters scanlines,
and derives every statement from the pixels themselves. Nothing is read from
file names or assumed from figure labels.

Outputs per figure (all locatable and re-checkable):
  - panel split (sub-figure bounding boxes found by whitespace gutters)
  - plot frame and tick marks per panel (positions + spacing regularity)
  - colour-clustered series, digitized as pixel traces (x pixel -> median y)
  - scale-bar candidates (solid dark bars in the lower region, for micrographs)
  - optional data-coordinate conversion when the Agent supplies a calibration
    file with tick pixel positions and their printed values (linear or log)

Every numeric result carries `method` and, where pixels are converted to data
units, an explicit error band (half a tick interval plus one pixel).
"""
import json
import math
import struct
import zlib
from pathlib import Path

PNG_SIG = b"\x89PNG\r\n\x1a\n"


# ---------------------------------------------------------------- PNG decode
def decode_png(path):
    """Return (width, height, channels, bytearray of RGB rows) or None."""
    try:
        data = Path(path).read_bytes()
    except Exception:
        return None
    if data[:8] != PNG_SIG:
        return None
    pos, idat, w, h, depth, ctype, interlace = 8, bytearray(), 0, 0, 8, 2, 0
    while pos + 8 <= len(data):
        ln, typ = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + ln]
        if typ == b"IHDR":
            w, h, depth, ctype, _comp, _filt, interlace = struct.unpack(">IIBBBBB", body)
        elif typ == b"IDAT":
            idat += body
        elif typ == b"IEND":
            break
        pos += 12 + ln
    if depth != 8 or interlace != 0 or ctype not in (0, 2, 4, 6) or w < 8 or h < 8:
        return None
    ch = {0: 1, 2: 3, 4: 2, 6: 4}[ctype]
    try:
        raw = zlib.decompress(bytes(idat))
    except Exception:
        return None
    stride = w * ch
    if len(raw) < (stride + 1) * h:
        return None
    out = bytearray(w * h * 3)
    prev = bytearray(stride)
    src = 0
    for y in range(h):
        f = raw[src]
        line = bytearray(raw[src + 1:src + 1 + stride])
        src += stride + 1
        if f == 1:                                   # Sub
            for i in range(ch, stride):
                line[i] = (line[i] + line[i - ch]) & 0xFF
        elif f == 2:                                 # Up
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 0xFF
        elif f == 3:                                 # Average
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 0xFF
        elif f == 4:                                 # Paeth
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                b = prev[i]
                c = prev[i - ch] if i >= ch else 0
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 0xFF
        prev = line
        base = y * w * 3
        if ch == 1:
            for x in range(w):
                out[base + 3 * x] = out[base + 3 * x + 1] = out[base + 3 * x + 2] = line[x]
        elif ch == 2:
            for x in range(w):
                out[base + 3 * x] = out[base + 3 * x + 1] = out[base + 3 * x + 2] = line[2 * x]
        else:
            for x in range(w):
                out[base + 3 * x:base + 3 * x + 3] = line[ch * x:ch * x + 3]
    return w, h, out


def _gray(px):
    n = len(px) // 3
    g = bytearray(n)
    for i in range(n):
        r, gg, b = px[3 * i], px[3 * i + 1], px[3 * i + 2]
        g[i] = (r * 299 + gg * 587 + b * 114) // 1000
    return g


# ------------------------------------------------------------ panel splitting
def _panels(g, w, h, min_side=60):
    """Split on full-width/height near-white gutters; reading order."""
    rowink = [0] * h
    colink = [0] * w
    for y in range(h):
        base = y * w
        c = 0
        for x in range(w):
            if g[base + x] < 200:
                c += 1
        rowink[y] = c
    for x in range(w):
        c = 0
        for y in range(h):
            if g[y * w + x] < 200:
                c += 1
        colink[x] = c
    rthr = max(2, w // 200)
    cthr = max(2, h // 200)

    def runs(flags):
        out, s = [], None
        for i, f in enumerate(flags + [False]):
            if f and s is None:
                s = i
            elif not f and s is not None:
                out.append((s, i - 1))
                s = None
        return out

    rbands = runs([c > rthr for c in rowink])
    cbands = runs([c > cthr for c in colink])
    if len(rbands) <= 1 and len(cbands) <= 1:
        return [(0, 0, w - 1, h - 1)]
    panels = []
    for r0, r1 in rbands:
        for c0, c1 in cbands:
            # require ink actually present in the intersection
            ink = 0
            for y in range(r0, r1 + 1, 4):
                for x in range(c0, c1 + 1, 4):
                    if g[y * w + x] < 200:
                        ink += 1
            if (c1 - c0) >= min_side and (r1 - r0) >= min_side and ink > 8:
                panels.append((c0, r0, c1, r1))
    return panels or [(0, 0, w - 1, h - 1)]


# ---------------------------------------------------------- frame and ticks
def _frame(g, w, box):
    """Longest dark horizontal/vertical runs inside the panel = plot frame."""
    x0, y0, x1, y1 = box
    pw, ph = x1 - x0 + 1, y1 - y0 + 1
    best_h, best_v = None, None
    for y in range(y0, y1 + 1):
        run = mx = 0
        for x in range(x0, x1 + 1):
            run = run + 1 if g[y * w + x] < 100 else 0
            mx = max(mx, run)
        if mx >= 0.55 * pw and (best_h is None or mx > best_h[1]):
            best_h = (y, mx)
    for x in range(x0, x1 + 1):
        run = mx = 0
        for y in range(y0, y1 + 1):
            run = run + 1 if g[y * w + x] < 100 else 0
            mx = max(mx, run)
        if mx >= 0.55 * ph and (best_v is None or mx > best_v[1]):
            best_v = (x, mx)
    if not best_h or not best_v:
        return None
    # frame = the outermost long lines
    xs, ys = [], []
    for x in range(x0, x1 + 1):
        run = mx = 0
        for y in range(y0, y1 + 1):
            run = run + 1 if g[y * w + x] < 100 else 0
            mx = max(mx, run)
        if mx >= 0.55 * ph:
            xs.append(x)
    for y in range(y0, y1 + 1):
        run = mx = 0
        for x in range(x0, x1 + 1):
            run = run + 1 if g[y * w + x] < 100 else 0
            mx = max(mx, run)
        if mx >= 0.55 * pw:
            ys.append(y)
    return {"left": min(xs), "right": max(xs), "top": min(ys), "bottom": max(ys)}


def _ticks(g, w, h, frame):
    """Short dark strokes just outside the frame edges."""
    out = {"x": [], "y": []}
    l, r, t, b = frame["left"], frame["right"], frame["top"], frame["bottom"]
    for x in range(l, r + 1):
        c = 0
        for dy in range(1, 8):
            y = b + dy
            if y < h and g[y * w + x] < 100:
                c += 1
        if c >= 3:
            out["x"].append(x)
    for y in range(t, b + 1):
        c = 0
        for dx in range(1, 8):
            x = l - dx
            if x >= 0 and g[y * w + x] < 100:
                c += 1
        if c >= 3:
            out["y"].append(y)

    def merge(pos):
        if not pos:
            return []
        grp, cur = [], [pos[0]]
        for p in pos[1:]:
            if p - cur[-1] <= 2:
                cur.append(p)
            else:
                grp.append(sum(cur) / len(cur))
                cur = [p]
        grp.append(sum(cur) / len(cur))
        return grp

    xt, yt = merge(out["x"]), merge(out["y"])

    def spacing(ts):
        if len(ts) < 3:
            return {"count": len(ts), "regular": None, "mean_step_px": None}
        steps = [ts[i + 1] - ts[i] for i in range(len(ts) - 1)]
        mean = sum(steps) / len(steps)
        var = sum((s - mean) ** 2 for s in steps) / len(steps)
        cv = math.sqrt(var) / mean if mean else 99.0
        return {"count": len(ts), "regular": cv < 0.15,
                "mean_step_px": round(mean, 2), "step_cv": round(cv, 3)}
    return {"x_ticks_px": [round(v, 1) for v in xt],
            "y_ticks_px": [round(v, 1) for v in yt],
            "x": spacing(xt), "y": spacing(yt)}


# ---------------------------------------------------------- series digitizing
def _hue(r, g, b):
    mx, mn = max(r, g, b), min(r, g, b)
    if mx == mn:
        return None
    d = mx - mn
    if mx == r:
        h = ((g - b) / d) % 6
    elif mx == g:
        h = (b - r) / d + 2
    else:
        h = (r - g) / d + 4
    return h * 60.0


def _series(px, w, frame, max_series=6, min_frac=0.002):
    """Cluster saturated pixels by hue; digitize each cluster inside frame."""
    l, r, t, b = frame["left"], frame["right"], frame["top"], frame["bottom"]
    buckets = {}
    total = 0
    for y in range(t + 1, b):
        base = y * w
        for x in range(l + 1, r):
            i = 3 * (base + x)
            rr, gg, bb = px[i], px[i + 1], px[i + 2]
            if max(rr, gg, bb) - min(rr, gg, bb) < 40:
                continue
            hv = _hue(rr, gg, bb)
            if hv is None:
                continue
            key = int(hv // 60)
            buckets.setdefault(key, []).append((x, y))
            total += 1
    out = []
    need = max(20, int(total * min_frac * 10))
    for key, pts in sorted(buckets.items(), key=lambda kv: -len(kv[1])):
        if len(out) >= max_series or len(pts) < need:
            continue
        cols = {}
        for x, y in pts:
            cols.setdefault(x, []).append(y)
        xs = sorted(cols)
        if len(xs) < 8:
            continue
        trace = [(x, sorted(cols[x])[len(cols[x]) // 2]) for x in xs]
        sample = pts[len(pts) // 2]
        i = 3 * (sample[1] * w + sample[0])
        out.append({
            "series_index": len(out) + 1,
            "hue_bin": key * 60,
            "sample_rgb": [px[i], px[i + 1], px[i + 2]],
            "n_pixels": len(pts),
            "n_columns": len(xs),
            "x_range_px": [xs[0], xs[-1]],
            "trace_px": trace,
        })
    return out


def _scale_bar(g, w, h):
    """Solid near-black horizontal bar in the lower quarter (micrographs)."""
    y0 = int(h * 0.7)
    best = None
    for y in range(y0, h - 2):
        run = 0
        for x in range(w):
            if g[y * w + x] < 60:
                run += 1
            else:
                if 20 <= run <= w // 2:
                    # verify thickness 2..10 px
                    th = 1
                    while y + th < h and g[(y + th) * w + x - run + run // 2] < 60:
                        th += 1
                    if 2 <= th <= 12 and (best is None or run > best["width_px"]):
                        best = {"x": x - run, "y": y, "width_px": run, "height_px": th}
                run = 0
    return best


# ------------------------------------------------------------- calibration
def calibrate_trace(trace_px, xcal, ycal):
    """Map pixel trace to data coordinates.

    xcal/ycal: {"pixels": [p...], "values": [v...], "scale": "linear"|"log"}.
    Error band = half the bracketing tick interval, in data units.
    """
    def conv(p, cal):
        ps, vs = cal["pixels"], cal["values"]
        if len(ps) < 2 or len(ps) != len(vs):
            return None, None
        for i in range(len(ps) - 1):
            p0, p1 = ps[i], ps[i + 1]
            if (p0 <= p <= p1) or (p1 <= p <= p0):
                v0, v1 = vs[i], vs[i + 1]
                frac = (p - p0) / (p1 - p0) if p1 != p0 else 0.0
                if cal.get("scale") == "log" and v0 > 0 and v1 > 0:
                    val = math.exp(math.log(v0) + frac * (math.log(v1) - math.log(v0)))
                else:
                    val = v0 + frac * (v1 - v0)
                err = abs(v1 - v0) / 2.0
                return val, err
        return None, None

    pts, missed = [], 0
    for xpx, ypx in trace_px:
        xv, xe = conv(xpx, xcal)
        yv, ye = conv(ypx, ycal)
        if xv is None or yv is None:
            missed += 1
            continue
        pts.append({"x": round(xv, 6), "y": round(yv, 6),
                    "x_err": round(xe, 6), "y_err": round(ye, 6),
                    "x_px": xpx, "y_px": ypx})
    return pts, missed


# ------------------------------------------------------------------- driver
def analyze_figure(path):
    """Full pixel analysis for one figure; honest `applicable` flags."""
    rec = {"file": Path(path).name, "applicable": True, "panels": [],
           "scale_bar": None, "notes": []}
    dec = decode_png(path)
    if dec is None:
        sfx = Path(path).suffix.lower()
        rec["applicable"] = False
        rec["notes"].append(
            "not a non-interlaced 8-bit PNG (suffix=%s); pixel analysis skipped, "
            "use the platform image viewer/OCR instead" % sfx)
        return rec
    w, h, px = dec
    rec["width"], rec["height"] = w, h
    g = _gray(px)
    panels = _panels(g, w, h)
    rec["panel_count"] = len(panels)
    for pi, box in enumerate(panels):
        prec = {"panel": pi + 1, "bbox_px": list(box)}
        fr = _frame(g, w, box)
        if fr is None:
            prec["frame"] = None
            prec["notes"] = ["no rectangular plot frame detected (micrograph, "
                             "photograph or frameless plot); tick/curve analysis "
                             "not applicable"]
        else:
            prec["frame"] = fr
            prec["ticks"] = _ticks(g, w, h, fr)
            series = _series(px, w, fr)
            prec["series"] = [{"series_index": s["series_index"],
                               "hue_bin": s["hue_bin"],
                               "sample_rgb": s["sample_rgb"],
                               "n_pixels": s["n_pixels"],
                               "n_columns": s["n_columns"],
                               "x_range_px": s["x_range_px"]} for s in series]
            prec["_traces"] = {s["series_index"]: s["trace_px"] for s in series}
            if not series:
                prec["notes"] = ["no saturated colour series found inside frame "
                                 "(grayscale/black curves need Agent-guided digitizing)"]
        rec["panels"].append(prec)
    if len(panels) == 1 and not any(p.get("frame") for p in rec["panels"]):
        sb = _scale_bar(g, w, h)
        if sb:
            rec["scale_bar"] = sb
            rec["notes"].append(
                "scale-bar candidate: %d px wide solid bar at (%d,%d); its printed "
                "label must be read by the Agent to convert px to physical units"
                % (sb["width_px"], sb["x"], sb["y"]))
    return rec


def write_traces(rec, outdir, calibration=None):
    """Write per-series trace CSVs; convert to data units when calibrated."""
    written = []
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    for prec in rec.get("panels", []):
        traces = prec.pop("_traces", {})
        for si, trace in traces.items():
            stem = "%s_p%d_s%d" % (Path(rec["file"]).stem, prec["panel"], si)
            px_csv = outdir / (stem + "_px.csv")
            lines = ["x_px,y_px"] + ["%d,%d" % (x, y) for x, y in trace]
            px_csv.write_text("\n".join(lines) + "\n", encoding="utf-8")
            written.append(px_csv.name)
            if calibration:
                cal = calibration.get(rec["file"], {}).get(str(prec["panel"]), {})
                xcal, ycal = cal.get("x"), cal.get("y")
                if xcal and ycal:
                    pts, missed = calibrate_trace(trace, xcal, ycal)
                    hdr = "x%s,y%s,x_err,y_err,x_px,y_px" % (
                        ("_" + xcal["unit"]) if xcal.get("unit") else "",
                        ("_" + ycal["unit"]) if ycal.get("unit") else "")
                    rows = [hdr] + ["%g,%g,%g,%g,%d,%d" % (
                        p["x"], p["y"], p["x_err"], p["y_err"],
                        p["x_px"], p["y_px"]) for p in pts]
                    name = stem + "_data.csv"
                    (outdir / name).write_text("\n".join(rows) + "\n",
                                               encoding="utf-8")
                    written.append(name)
                    prec.setdefault("calibration", {})["points"] = len(pts)
                    prec["calibration"]["skipped_out_of_range"] = missed
                    prec["calibration"]["x_unit"] = xcal.get("unit")
                    prec["calibration"]["y_unit"] = ycal.get("unit")
                    prec["calibration"]["scale"] = {"x": xcal.get("scale", "linear"),
                                                    "y": ycal.get("scale", "linear")}
    return written


def load_calibration(work):
    path = Path(work, "calibration.json")
    if not path.is_file():
        return None
    try:
        obj = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        return {"_error": "calibration.json is not valid JSON: %s" % exc}
    return obj if isinstance(obj, dict) else {
        "_error": "calibration.json must be a JSON object"}

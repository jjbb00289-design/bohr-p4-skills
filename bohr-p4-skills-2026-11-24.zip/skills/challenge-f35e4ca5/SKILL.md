---
name: figure-table-analyst
description: Parse one scientific figure plus its tables into a verifiable structured result - pixel-level panel/axis/tick detection, colour-series digitization with calibration to data units, table-derived statistics, and a six-section evidence report where every claim carries a source, a locator and a verbatim quote or an explicit computed-reading path.
version: 7.0
---

# 科研图表解析（像素派生 + 证据三件套）

把"每例 1 张原图 + 全部原表"读成可复核的结构化结果。核心原则：**每个数字都有来源**——要么逐字引自表格/正文（quote），要么由像素实测/计算派生（附读取路径与误差带），材料没有的一律进 `uncertainty`/`pending_human`，不猜。

## 一条命令

```bash
python3 scripts/main.py            # 自动用 /input、/app/work、/app/output
python3 scripts/main.py digitize   # 写入 work/calibration.json 后重跑，换算数据坐标
```

也可用 `--input/--work/--output` 或环境变量 `INPUT_DIR/WORK_DIR/OUTPUT_DIR` 覆盖。退出码恒 0；空、坏、缺输入都产出合法的 partial `result.json` 并在 `gaps` 说明原因。启动后**先落盘一版最小 partial result.json**，再增量改进。

## 工作流（按预算执行，见下）

1. **识别边界**：读 `/input/case.json`（case_id、output_contract、提问）与任务说明；列材料清单。只解析实际存在的文件，不按文件名臆测内容。
2. **自动派生**：跑 `main.py`。得到 `deliverable.md`（六节证据报告）、`figure_analysis.json`（面板/坐标框/刻度/系列）、每系列 `*_px.csv` 像素轨迹、表格统计结论、`result.json` 初版。
3. **读图标定**（Agent 用视觉/OCR 完成，脚本不猜标签）：对每张有坐标框的图，读出轴标题、单位、轴类型（线性/对数/双轴）、至少两个刻度的"像素位置→数值"，写入 `/app/work/calibration.json`：
   ```json
   {"fig1.png": {"1": {"x": {"pixels": [88, 320], "values": [0, 50], "scale": "linear", "unit": "min"},
                        "y": {"pixels": [360, 40], "values": [0, 100], "scale": "log", "unit": "%"}}}}
   ```
   键为文件名→面板号→x/y。刻度像素位置可从 `figure_analysis.json` 的 `x_ticks_px/y_ticks_px` 直接取。
4. **换算**：跑 `python3 scripts/main.py digitize`，产出 `*_data.csv`（数据坐标 + 误差带 = 半个刻度间隔），`result.json` 同步更新。
5. **作答**：对照 case.json 的提问逐条回答，每条挂 `source + locator + quote`（引文逐字复制）或轨迹文件路径；区分"图中直接可读 / 合理推断 / 无法确定"三级，无法确定写进 `pending_human`。
6. **终检**：核对 `self_check.json`、`compliance_checks.json`（quote 命中率 ≥0.95）、确认 `result.json` 含 output_contract 全部键。

## 判读规则（读得准）

- **轴类型**：刻度等距→线性；不等距但比例等比→对数（`figure_analysis.json` 的 `step_cv` 大时优先怀疑对数轴）；左右两条 y 轴→双轴，分别标定。对数轴 `scale` 必须填 `"log"`。
- **单位量级**：mV 不当 V、µM 不当 mM；表头 `Name (unit)` 的单位由脚本自动提取，轴上单位由第 3 步人工读图确认，两者冲突时进 `errors` 并说明。
- **像素读数**：写"值 + 单位 + ≈（近似）+ 误差"。脚本给出的误差带是半个刻度间隔；曲线线宽另加约 ±1 px。
- **非数据元素**：图例、箭头、显著性星号不参与数字化；显著性标记由表格 `Note`/`p`/`sig` 列或图注原文佐证。

## 异常与降级

- 无坐标刻度/图被裁剪/图例缺失/图像过曝：`applicable:false`，该面板只报元信息，缺口写入 `uncertainty` 与 `pending_human`，**不构造数据**。
- 非 PNG（jpg 等）或隔行/16 位 PNG：像素分析自动跳过并在 `degradations` 说明；改用平台视觉/OCR 工具读图，结论标注为"Agent 读图"来源。
- 灰度/黑色曲线无法按颜色分系列：`panels[].notes` 明示，转为按表格数值作答。
- 多子图：按面板号逐一对应图注字母（a/b/c…），禁止跨面板串值；对不上号的写缺口。
- 未给像素信息的其他图注：只在 `uncertainty` 列缺口，不是必须补齐的隐藏任务。

## 预算与自检（64 次请求 / 900 秒）

- 请求预算：识别 2 + 首跑 2 + 读图标定每张图 ≤6 + 换算与作答 ≤6 + 终检 2，三例合计预留 ≥20% 余量；每完成一例立即写盘。
- 自检清单：`self_check.json` 全 true；quote 命中率 ≥0.95；六节均有证据；`result.json` 含 output_contract 全部键 + case_id + status；无 TBD/占位文本。
- 时间不足时按优先级砍：数据坐标换算 > 表格外正文引用 > 趋势措辞润色，**不得砍证据定位与 result.json 契约键**。

## 输出契约

`result.json` 键：`case_id, status(ok/partial), result, claims, coverage, sources, uncertainty, changes, errors, degradations, pending_human, gaps, figure_elements, table_rows, content_map, compliance_checks` + case.json `output_contract` 声明的全部键。每条 claim：`{section, claim, source, locator, quote, confidence}`，`confidence` ∈ quoted（逐字引文）/ measured（像素实测）/ computed（计算派生）/ not_applicable；不可验证的 quote 置 `null` 并列入 `pending_human`。

## 文件

- `scripts/main.py`：编排入口（<30KB，纯标准库，不联网，不依赖 CWD）。
- `scripts/figure_parse.py`：PNG 解码（zlib+unfilter）、面板切分、坐标框/刻度检测、颜色系列数字化、比例尺候选、标定换算。
- `scripts/tables.py`：CSV/TSV 表头单位提取、系列极值/排序/极差、SEM/SD 与显著性列。
- `scripts/pdftext.py`：无依赖 PDF 文本提取（图注与正文引用）。
- `references/profile.json`：六节标题与关键词（可调）。

## 最小调用示例（示意，非正式案例结果）

输入 `fig1.png`（一张带坐标框的曲线图）+ `table1.csv`：跑 `python3 scripts/main.py` 后，`result.json` 的 `claims` 出现形如 `{"claim": "fig1.png 为 640×480 像素位图，检测到 1 个子图面板", "locator": "fig1.png#IHDR", "quote": null, "confidence": "measured"}` 与 `{"claim": "yield 一列共 4 个数值：control 组最低 12.3，treated 组最高 18.9", "locator": "table1.csv#row3", "quote": "treated,18.9,0.9,p<0.05", "confidence": "computed"}`；写入 `calibration.json` 并重跑 `digitize` 后得到 `fig1_p1_s1_data.csv`（示意输出，真实数值取决于实际材料）。

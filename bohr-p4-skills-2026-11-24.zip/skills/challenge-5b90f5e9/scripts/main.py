#!/usr/bin/env python3
"""Systematic literature search & screening pipeline. Default: parse /input -> dedup ->
query plan -> screening -> audit -> workdraft.json + result.json. Pure stdlib, offline,
deterministic, CWD-independent."""
import os, sys, json, argparse, re

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import screening as S

VERSION = "1.0.0"

def resolve(args):
    env = os.environ
    inp = args.input or env.get("INPUT_DIR") or "/input"
    work = args.work or env.get("WORK_DIR") or "/app/work"
    out = args.output or env.get("OUTPUT_DIR") or "/app/output"
    return inp, work, out

def read_text(path):
    try:
        return open(path, 'r', encoding='utf-8', errors='replace').read()
    except Exception:
        return None

def load_case(inp):
    p = os.path.join(inp, 'case.json')
    if not os.path.isfile(p):
        return None, ['case.json not found at %s' % p]
    try:
        return json.load(open(p, 'r', encoding='utf-8', errors='replace')), []
    except Exception as e:
        return None, ['case.json invalid JSON: %s' % e]

def research_question(case, task_text):
    for k in ('research_question', 'question', 'task_instruction', 'instruction', 'task'):
        v = case.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    lines = [l.strip() for l in (task_text or '').splitlines() if l.strip()]
    return lines[0][:500] if lines else None

def meta_of(case, task_text, mats, status, errors, degradations):
    return {'case_id': case.get('case_id') if case else None,
            'task_instruction': (case or {}).get('task_instruction') or (case or {}).get('task'),
            'research_question': research_question(case or {}, task_text), 'materials': mats,
            'status': status, 'errors': errors, 'degradations': degradations}

def assemble_workdraft(case, task_text, mats, payload, meta):
    wd = {
        'schema_version': '1.0',
        'case_id': meta['case_id'],
        'task_instruction': meta['task_instruction'],
        'research_question': meta['research_question'],
        'materials': mats,
        'status': meta['status'],
        'errors': meta['errors'],
        'degradations': meta['degradations'],
    }
    if payload:
        wd.update(payload)
    else:
        wd['dedup'] = {'input_count': 0, 'output_count': 0, 'groups': []}
        for k in ('query_plan', 'raw_records', 'unique_records', 'screening', 'ranking',
                  'conflicts', 'audit', 'coverage', 'inclusion_criteria', 'exclusion_criteria'):
            wd.setdefault(k, [])
    return wd

def _default(spec):
    if isinstance(spec, dict) and 'default' in spec:
        return spec['default']
    return None

def match_contract(name, payload, meta):
    n = (name or '').lower()
    if n == 'case_id' or 'case_id' in n:
        return meta.get('case_id')
    table = [
        (('candidate', 'record', 'paper', 'literature', 'article', 'hit', 'document', 'reference', 'item', '题录', '文献', '候选'), 'unique_records'),
        (('query', 'search', 'protocol', 'plan', 'strategy', '检索', '查询', '协议'), 'query_plan'),
        (('dedup', 'duplicate', 'merge', '去重'), 'dedup'),
        (('screen', 'inclusion', 'exclusion', 'label', 'decision', 'judge', '筛选', '纳排', '标签', '判定'), 'screening'),
        (('rank', 'sort', '排序'), 'ranking'),
        (('audit', 'log', 'count', 'flow', 'trace', '审计', '日志'), 'audit'),
        (('coverage', 'omission', 'gap', 'missing', 'limit', '覆盖', '遗漏'), 'coverage'),
        (('conflict', 'arbitrat', 'disagree', '冲突', '仲裁'), 'conflicts'),
        (('criterion', 'criteria', 'standard', '标准', '判据'), 'criteria'),
        (('question', 'research', 'pico', '问题', '研究'), 'research_question'),
        (('status', '状态'), 'status'),
    ]
    for keys, target in table:
        if any(w in n for w in keys):
            if target == 'criteria':
                return {'inclusion_criteria': payload['inclusion_criteria'], 'exclusion_criteria': payload['exclusion_criteria']}
            if target == 'research_question':
                return meta.get('research_question')
            if target == 'status':
                return meta.get('status')
            return payload[target]
    return None

def echo_contract(case, payload, meta):
    result = {}
    oc = case.get('output_contract') if case else None
    if isinstance(oc, dict):
        for k in oc.keys():
            v = match_contract(k, payload, meta) if payload else None
            result[k] = v if v is not None else _default(oc[k])
    elif isinstance(oc, list):
        for item in oc:
            k = item if isinstance(item, str) else (item.get('name') or item.get('key') or item.get('field'))
            if not k:
                continue
            v = match_contract(k, payload, meta) if payload else None
            result[k] = v if v is not None else (item.get('default') if isinstance(item, dict) else None)
    return result

def uncertainty_of(payload, meta):
    if not payload:
        return {'low_confidence': [], 'missing_doi': None, 'missing_abstract': None,
                'fixtures': [], 'unresolved_conflicts': None, 'notes': meta.get('errors', [])}
    low = [s['record_id'] for s in payload['screening'] if s.get('needs_human')]
    fix = [s['record_id'] for s in payload['screening'] if s['decision'] == 'fixture']
    miss_doi = sum(1 for r in payload['unique_records'] if not r.get('doi'))
    miss_abs = sum(1 for r in payload['unique_records'] if not r.get('abstract'))
    unres = sum(1 for c in payload['conflicts'] if c.get('arbitration') is None)
    notes = []
    if unres:
        notes.append('%d conflict(s) unresolved' % unres)
    if payload['screening'] and all(s['decision'] == 'review_needed' for s in payload['screening']):
        notes.append('no machine criteria; all review_needed')
    return {'low_confidence': low, 'missing_doi': miss_doi, 'missing_abstract': miss_abs,
            'fixtures': fix, 'unresolved_conflicts': unres, 'notes': notes}

def sources_of(mats):
    return [{'path': m['path'], 'type': m['type'], 'note': m['note']} for m in mats]

def assemble_result(case, payload, meta, change_records=None):
    result = echo_contract(case, payload, meta)
    result['case_id'] = meta.get('case_id')
    result['status'] = meta['status']
    result['sources'] = sources_of(meta['materials'])
    result['uncertainty'] = uncertainty_of(payload, meta)
    result['change_records'] = change_records or []
    result['errors'] = meta['errors']
    result['degradations'] = meta['degradations']
    result['skill'] = {'name': 'systematic-literature-screening', 'version': VERSION}
    result['systematic_search'] = payload or {'query_plan': [], 'candidates': [],
        'dedup': {'input_count': 0, 'output_count': 0, 'groups': []}, 'screening': [],
        'conflicts': [], 'audit': [], 'coverage': {'included': 0, 'excluded': 0,
        'review_needed': 0, 'conflicts': 0, 'fixtures': 0, 'omissions': []}}
    return result

def write_json(obj, path):
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    return path

def _scan_build(inp, case, task_text, errors):
    try:
        mats, recs, degs = S.scan_materials(inp, {'case.json', 'task.md'})
        return mats, S.build_payload(case, task_text, mats, recs, degs, inp), degs
    except Exception as e:
        errors.append('pipeline: %s' % e)
        return [], None, []

def run_pipeline(args):
    inp, work, out = resolve(args)
    os.makedirs(work, exist_ok=True)
    os.makedirs(out, exist_ok=True)
    case, errors = load_case(inp)
    task_text = read_text(os.path.join(inp, 'task.md')) or ''
    if case is None:
        meta = meta_of(None, task_text, [], 'input_error', errors, [])
        write_json(assemble_workdraft(None, task_text, [], None, meta), os.path.join(work, 'workdraft.json'))
        write_json(assemble_result({}, None, meta), os.path.join(out, 'result.json'))
        return meta
    mats, payload, degs = _scan_build(inp, case, task_text, errors)
    degradations = list(degs)
    status = 'partial' if errors else 'complete'
    if not payload or not payload.get('unique_records'):
        status = 'insufficient_evidence'
    meta = meta_of(case, task_text, mats, status, errors, degradations)
    write_json(assemble_workdraft(case, task_text, mats, payload, meta), os.path.join(work, 'workdraft.json'))
    write_json(assemble_result(case, payload, meta), os.path.join(out, 'result.json'))
    return meta

def cmd_init(args):
    inp, work, out = resolve(args)
    os.makedirs(work, exist_ok=True)
    case, errors = load_case(inp)
    task_text = read_text(os.path.join(inp, 'task.md')) or ''
    mats, payload, degs = _scan_build(inp, case, task_text, errors) if case else ([], None, [])
    status = 'partial' if errors else 'complete'
    if payload and not payload.get('unique_records'):
        status = 'insufficient_evidence'
    meta = meta_of(case, task_text, mats, status, errors, list(degs))
    write_json(assemble_workdraft(case, task_text, mats, payload, meta), os.path.join(work, 'workdraft.json'))
    print('workdraft written: %s' % os.path.join(work, 'workdraft.json'))
    return {'status': status}

def cmd_build(args):
    _, work, out = resolve(args)
    os.makedirs(out, exist_ok=True)
    p = os.path.join(work, 'workdraft.json')
    if not os.path.isfile(p):
        print('no workdraft.json; run default first')
        return {'status': 'missing_workdraft'}
    wd = S.read_json(p)
    payload = {k: wd[k] for k in ('query_plan', 'raw_records', 'dedup', 'unique_records', 'screening',
                                  'ranking', 'conflicts', 'audit', 'coverage', 'inclusion_criteria',
                                  'exclusion_criteria') if k in wd}
    meta = {'case_id': wd.get('case_id'), 'task_instruction': wd.get('task_instruction'),
            'research_question': wd.get('research_question'), 'materials': wd.get('materials', []),
            'status': wd.get('status', 'complete'), 'errors': wd.get('errors', []),
            'degradations': wd.get('degradations', [])}
    case = {'case_id': wd.get('case_id'), 'output_contract': wd.get('output_contract', {})}
    result = assemble_result(case, payload, meta, wd.get('change_records', []))
    write_json(result, os.path.join(out, 'result.json'))
    print('result.json rebuilt from workdraft')
    return result

def _collapse(s):
    return re.sub(r'\s+', ' ', (s or '')).strip()

def _find(src_dir, name):
    p = os.path.join(src_dir, (name or '').replace('/', os.sep))
    return p if os.path.isfile(p) else None

def cmd_check(args):
    inp, work, out = resolve(args)
    p, rp = os.path.join(work, 'workdraft.json'), os.path.join(out, 'result.json')
    checks = [('workdraft exists', os.path.isfile(p), p if os.path.isfile(p) else 'missing')]
    wd = S.read_json(p) if os.path.isfile(p) else {}
    res = {}
    if os.path.isfile(rp):
        checks.append(('result.json exists', True, rp))
        try:
            res = S.read_json(rp)
            checks.append(('result.json valid JSON', True, ''))
        except Exception as e:
            checks.append(('result.json valid JSON', False, str(e)))
    else:
        checks.append(('result.json exists', False, 'missing'))
    case, _ = load_case(inp)
    oc = (case or {}).get('output_contract') or {}
    keys = list(oc.keys()) if isinstance(oc, dict) else [i.get('name') or i.get('key') or i for i in oc] if isinstance(oc, list) else []
    missing = [k for k in keys if k not in res]
    checks.append(('contract keys present', not missing and 'case_id' in res, 'missing=%s' % missing))
    hits = total = 0
    for r in wd.get('unique_records', []):
        q = r.get('title')
        if not q or len(q) < 4:
            continue
        total += 1
        src = _find(inp, r.get('source_file', '')) if r.get('source_file') else None
        raw = open(src, 'r', encoding='utf-8', errors='replace').read() if src and os.path.isfile(src) else ''
        if _collapse(q) and _collapse(q) in _collapse(raw):
            hits += 1
    rate = (hits / total) if total else 1.0
    checks.append(('quote hit rate >= 0.95', rate >= 0.95, '%.3f (%d/%d)' % (rate, hits, total)))
    dd = wd.get('dedup') or {}
    nu, ns = len(wd.get('unique_records', [])), len(wd.get('screening', []))
    checks.append(('dedup.output == unique count', dd.get('output_count') == nu, '%s vs %d' % (dd.get('output_count'), nu)))
    checks.append(('screening == unique count', ns == nu, '%d vs %d' % (ns, nu)))
    for name, ok, detail in checks:
        print('%s %s %s' % ('PASS' if ok else 'FAIL', name, detail))
    return {'all_pass': all(ok for _, ok, _ in checks), 'checks': checks}

def cmd_show(args):
    _, work, _ = resolve(args)
    p = os.path.join(work, 'workdraft.json')
    if not os.path.isfile(p):
        print('no workdraft.json')
        return
    wd = S.read_json(p)
    print('case_id=%s status=%s raw=%d dedup_output=%d screening=%d conflicts=%d' % (
        wd.get('case_id'), wd.get('status'), len(wd.get('raw_records', [])),
        (wd.get('dedup') or {}).get('output_count'), len(wd.get('screening', [])),
        len(wd.get('conflicts', []))))
    for s in wd.get('screening', [])[:20]:
        print('  %s %s %s %s' % (s.get('record_id'), s.get('decision'), s.get('reason_code'),
                                 (s.get('evidence_quote') or '')[:60]))

def main(argv=None):
    ap = argparse.ArgumentParser(prog='main.py', description='Systematic literature search & screening')
    ap.add_argument('command', nargs='?', default=None, choices=[None, 'init', 'show', 'check', 'build'])
    ap.add_argument('--input', default=None)
    ap.add_argument('--work', default=None)
    ap.add_argument('--output', default=None)
    args = ap.parse_args(argv)
    try:
        if args.command == 'init':
            cmd_init(args)
        elif args.command == 'show':
            cmd_show(args)
        elif args.command == 'check':
            cmd_check(args)
        elif args.command == 'build':
            cmd_build(args)
        else:
            run_pipeline(args)
    except Exception as e:
        sys.stderr.write('ERROR: %s\n' % e)
    return 0

if __name__ == '__main__':
    sys.exit(main())

"""Systematic search & screening core. Pure stdlib, offline, deterministic (no time/random)."""
import os, re, json, csv, io, sqlite3
import xml.etree.ElementTree as ET

DOI_RE = re.compile(r'10\.\d{4,9}/[-._;()/:+A-Za-z0-9]+', re.I)
YEAR_RE = re.compile(r'(18|19|20)\d{2}')
STOP = set("""a an the and or of in on for with by to from as is are was be this that these those it its
their at into over under between among about against using based study trial review""".split())
TITLE_KEYS = {'title', 'article-title', 'articletitle', 'primary-title', 'booktitle', 'publication-title'}
VENUE_KEYS = {'container-title', 'containertitle', 'journal-title', 'journaltitle', 'journal', 'source',
              'full-title', 'fulltitle', 'full_title', 'ta', 'jt', 'jo'}
DOI_KEYS = {'doi', 'id', 'prism:doi'}
YEAR_KEYS = {'year', 'pubyear', 'publicationyear', 'published', 'issued', 'pubdate', 'dp', 'py', 'date'}
ABS_KEYS = {'abstract', 'abstracttext', 'description', 'summary', 'ab'}
AUTH_KEYS = {'author', 'authors', 'creator', 'creators', 'contributor', 'contributors', 'au', 'fau', 'authorstring'}
GIVEN_KEYS = {'given', 'givenname', 'given-name', 'given_name', 'firstname', 'forename'}
FAMILY_KEYS = {'family', 'familyname', 'family-name', 'family_name', 'surname', 'lastname'}
FIXTURE_RE = re.compile(r'fixture|synthetic|合成|示例|test ?data|simulated', re.I)
OP = 'deterministic-skill-v1'

def nws(s): return re.sub(r'\s+', ' ', (s or '')).strip()
def ntitle(s): return re.sub(r'[^a-z0-9\u4e00-\u9fff]+', '', nws(s).lower())
def ndoi(s): return re.sub(r'^(https?://(dx\.)?doi\.org/)?', '', nws(s), flags=re.I).lower().rstrip('.,;')
def _lk(k): return (k or '').split('}')[-1].split(':')[-1].lower()

def pick(d, keys):
    if not isinstance(d, dict):
        return None
    return next((v for k, v in d.items() if _lk(k) in keys and v not in (None, '', [], {})), None)

def pstr(d, keys):
    v = pick(d, keys)
    if isinstance(v, list):
        v = v[0] if v else None
    return nws(str(v)) if v is not None else None

def authors_of(a):
    if a is None:
        return []
    if isinstance(a, str):
        return [p.strip() for p in re.split(r'\s*;\s*|\s*,\s*|\s+and\s+', a) if p.strip()]
    out = []
    for x in (a if isinstance(a, list) else []):
        if isinstance(x, str):
            if x.strip():
                out.append(x.strip())
        elif isinstance(x, dict):
            n = pstr(x, {'name', 'fullname', 'full-name', 'authorstring', 'author-string'}) or \
                ('%s %s' % (pstr(x, GIVEN_KEYS) or '', pstr(x, FAMILY_KEYS) or '')).strip()
            if n:
                out.append(n)
    return out

def year_of(v):
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, int):
        return v if 1800 <= v <= 2100 else None
    if isinstance(v, dict):
        dp = v.get('date-parts') or v.get('dateParts')
        if isinstance(dp, list) and dp and isinstance(dp[0], list):
            for y in dp[0]:
                if isinstance(y, int) and 1800 <= y <= 2100:
                    return y
        v = str(v.get('year') or v.get('date') or '')
    m = YEAR_RE.search(str(v))
    return int(m.group()) if m else None

def abstract_of(v):
    if isinstance(v, list):
        v = v[0] if v else None
    if isinstance(v, dict):
        v = pick(v, {'abstract', 'text'})
        v = v[0] if isinstance(v, list) and v else v
    return nws(str(v)) if v is not None else None

def _rec(title, authors, year, venue, doi, ab, sf, fmt, loc):
    return {'title': nws(title), 'authors': authors or [], 'year': year, 'venue': nws(venue), 'doi': ndoi(doi) if doi else None,
            'abstract': nws(ab), 'source_file': sf, 'source_format': fmt, 'locator': loc}

def extract_record(d):
    title, doi = pstr(d, TITLE_KEYS), pstr(d, DOI_KEYS)
    if doi and not DOI_RE.search(doi):
        doi = None
    if not title and not doi:
        return None
    r = _rec(title, authors_of(pick(d, AUTH_KEYS)), year_of(pick(d, YEAR_KEYS)), pstr(d, VENUE_KEYS),
             ndoi(doi) if doi else None, abstract_of(pick(d, ABS_KEYS)), None, 'json', None)
    if any(isinstance(v, str) and FIXTURE_RE.search(v) for v in d.values()):
        r['fixture'] = True
    return r

def looks_like_record(d):
    if not isinstance(d, dict):
        return False
    return any(_lk(k) in TITLE_KEYS and v not in (None, '', []) for k, v in d.items()) or \
           any(_lk(k) in DOI_KEYS and isinstance(v, str) and DOI_RE.search(v) for k, v in d.items())

def walk_json(node, path, out, sf, fmt):
    if isinstance(node, dict):
        if looks_like_record(node):
            r = extract_record(node)
            if r:
                r.update(source_file=sf, source_format=fmt, locator=path)
                out.append(r)
        for k, v in node.items():
            walk_json(v, ('$.' if not path else path + '.') + str(k), out, sf, fmt)
    elif isinstance(node, list):
        for i, v in enumerate(node):
            walk_json(v, path + '[' + str(i) + ']', out, sf, fmt)

def parse_json_text(text, sf, fmt):
    out = []
    t = text.lstrip('\ufeff \t\r\n')
    if t and t[0] in '{[':
        try:
            walk_json(json.loads(t), '$', out, sf, fmt)
            return out
        except ValueError:
            pass
    for ln, line in enumerate(text.splitlines(), 1):
        if line.strip():
            try:
                walk_json(json.loads(line), 'line %d' % ln, out, sf, 'jsonl')
            except ValueError:
                continue
    return out

def _flat(el):
    f = {}
    for s in el.iter():
        tag = _lk(s.tag)
        if 'abstract' in tag:
            full = ' '.join((t or '').strip() for t in s.itertext()).strip()
            if full:
                f.setdefault('abstract', []).append(full)
            continue
        t = (s.text or '').strip()
        if t:
            f.setdefault(tag, []).append(t)
    return f

def _first(f, keys):
    return next((f[k][0] for k in keys if f.get(k)), None)

def _xml_authors(el):
    out = []
    for a in el.iter():
        if _lk(a.tag) not in ('author', 'creator', 'contributor', 'person', 'person_name', 'person-name'):
            continue
        f = _flat(a)
        nm = ('%s %s' % (_first(f, GIVEN_KEYS) or '', _first(f, FAMILY_KEYS) or '')).strip() or (a.text or '').strip()
        if nm:
            out.append(nm)
    return out

def parse_xml_file(path, sf):
    REC = {'doi_record', 'article', 'pubmedarticle', 'result', 'record', 'entry', 'journal_article', 'medlinecitation'}
    out = []
    for el in ET.parse(path).getroot().iter():
        if _lk(el.tag) not in REC or any(_lk(d.tag) in REC for d in el.iter() if d is not el):
            continue
        f = _flat(el)
        title, doi = _first(f, ['title', 'article-title', 'articletitle']), _first(f, ['doi', 'article-id'])
        if not title and not (doi and DOI_RE.search(str(doi))):
            continue
        out.append(_rec(title, _xml_authors(el) or f.get('author', []),
                        year_of(_first(f, ['year', 'pubdate', 'pub-date', 'date', 'published'])),
                        _first(f, ['container-title', 'journal-title', 'journal', 'source', 'publication',
                                   'full-title', 'fulltitle', 'full_title']),
                        ndoi(doi) if doi else None, _first(f, ['abstract', 'abstracttext']),
                        sf, 'xml', 'xml:./%s' % _lk(el.tag)))
    return out

def _tab(headers, rows, sf, fmt, locfn):
    lc = [_lk(h) for h in headers]
    def col(*keys):
        return next((lc.index(k) for k in keys if k in lc), None)
    it, idc = col(*TITLE_KEYS), col(*DOI_KEYS)
    if it is None and idc is None:
        return []
    iy, iv, ia, iu = col(*YEAR_KEYS), col(*VENUE_KEYS), col(*ABS_KEYS), col(*AUTH_KEYS)
    out = []
    for rn, row in enumerate(rows):
        g = lambda i: row[i] if i is not None and i < len(row) else None
        r = _rec(g(it), authors_of(g(iu)), year_of(g(iy)), g(iv), g(idc), g(ia), sf, fmt, locfn(rn))
        if r['title'] or r['doi']:
            out.append(r)
    return out

def parse_table_text(text, sf, delim):
    rows = list(csv.reader(io.StringIO(text), delimiter=delim))
    return _tab(rows[0], rows[1:], sf, 'csv' if delim == ',' else 'tsv', lambda rn: 'line %d' % (rn + 2)) if rows else []

def parse_sqlite(path, sf):
    out, con = [], sqlite3.connect(path)
    try:
        for (t,) in con.execute("SELECT name FROM sqlite_master WHERE type='table'"):
            try:
                cols = [c[1] for c in con.execute('PRAGMA table_info("%s")' % t)]
            except Exception:
                continue
            out += _tab(cols, list(con.execute('SELECT * FROM "%s"' % t)), sf, 'sqlite',
                        lambda rn, t=t: '%s#%d' % (t, rn + 1))
    finally:
        con.close()
    return out

def text_records(text, sf, fmt):
    return [] if not text else [_rec(None, [], None, None, ndoi(m.group()), None, sf, fmt, 'doi@%d' % m.start()) for m in DOI_RE.finditer(text)]

def _err(sf, e):
    return [], [{'path': sf, 'error': e}]

def parse_file(path):
    sf = os.path.basename(path)
    try:
        head = open(path, 'rb').read(16)
    except Exception as e:
        return _err(sf, 'read: %s' % e)
    if head.startswith(b'SQLite format 3'):
        return parse_sqlite(path, sf), []
    if head.startswith(b'PK') or head.startswith(b'%PDF'):
        return _err(sf, 'binary docx/pdf')
    try:
        raw = open(path, 'r', encoding='utf-8', errors='replace').read()
    except Exception as e:
        return _err(sf, 'read: %s' % e)
    t = raw.lstrip('\ufeff \t\r\n')
    if not t:
        return [], []
    if t[0] in '{[':
        return parse_json_text(raw, sf, 'json'), []
    if t.startswith('<'):
        try:
            return parse_xml_file(path, sf), []
        except Exception as e:
            return _err(sf, 'xml: %s' % e)
    ext = os.path.splitext(path)[1].lower()
    if ext in ('.csv', '.tsv'):
        return parse_table_text(raw, sf, ',' if ext == '.csv' else '\t'), []
    return text_records(raw, sf, ext.lstrip('.') or 'txt'), []

def scan_materials(input_dir, skip):
    mats, recs, degs = [], [], []
    for root, dirs, files in os.walk(input_dir):
        dirs[:] = [d for d in dirs if d != '__pycache__']
        for fn in sorted(files):
            if fn in skip:
                continue
            p = os.path.join(root, fn)
            try:
                st = os.stat(p)
            except Exception as e:
                degs.append({'path': os.path.relpath(p, input_dir), 'error': 'stat: %s' % e})
                continue
            r, d = parse_file(p)
            rel = os.path.relpath(p, input_dir)
            mats.append({'path': rel, 'type': os.path.splitext(fn)[1].lstrip('.') or 'txt', 'bytes': st.st_size,
                         'parsed': len(r) > 0 or not d, 'note': '; '.join(x['error'] for x in d) or None})
            for rec in r:
                rec['source_file'] = rel
                recs.append(rec)
            degs.extend(d)
    return mats, recs, degs

def deduplicate(records):
    order, idx = [], {}
    for i, r in enumerate(records):
        keys = ([('d', ndoi(r['doi']))] if r.get('doi') else []) + \
               ([('t', ntitle(r.get('title') or ''))] if ntitle(r.get('title') or '') else [])
        e = None
        for k in keys:
            e = idx.get(k)
            if e is not None:
                break
        if e is None:
            e = {'gid': 'g%03d' % len(order), 'record_ids': [i], 'kept': i, 'basis': [], 'evidence': []}
            order.append(e)
            for k in keys:
                idx[k] = e
            e['basis'].append('doi-identical' if r.get('doi') else 'title-normalized')
            e['evidence'].append(r.get('doi') or r.get('title'))
        else:
            e['record_ids'].append(i)
            for k in keys:
                idx.setdefault(k, e)
            if r.get('doi') and 'doi-identical' not in e['basis']:
                e['basis'].append('doi-identical')
                e['evidence'].append(r.get('doi'))
            elif not r.get('doi'):
                e['basis'].append('title-normalized')
                e['evidence'].append(r.get('title'))
    return [{'group_id': e['gid'], 'record_ids': e['record_ids'], 'kept': e['kept'],
             'basis': list(dict.fromkeys(e['basis'])), 'evidence': list(dict.fromkeys(e['evidence']))}
            for e in order]

def read_json(path):
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        return json.load(f)

def _lst(case, keys):
    for k in keys:
        v = case.get(k)
        if isinstance(v, list):
            return [str(x) for x in v]
        if isinstance(v, str):
            return [v]
    return []

def extract_criteria(case, task_text):
    inc = _lst(case, ('inclusion_criteria', 'inclusion', 'include_criteria'))
    exc = _lst(case, ('exclusion_criteria', 'exclusion', 'exclude_criteria'))
    if not inc and not exc and task_text:
        for ln in re.split(r'[\n;。；]', task_text):
            ln = ln.strip()
            if not ln or len(ln) >= 200:
                continue
            if re.search(r'排除|exclusion|exclude|不纳入', ln, re.I):
                exc.append(ln)
            elif re.search(r'纳入|inclusion|include|须符合|限定', ln, re.I):
                inc.append(ln)
    return inc, exc

def tokens(text):
    seen, out = set(), []
    for t in re.findall(r'[A-Za-z0-9\u4e00-\u9fff][A-Za-z0-9\u4e00-\u9fff\-\.]{2,}', text or ''):
        tl = t.lower()
        if tl in STOP or tl in seen:
            continue
        seen.add(tl)
        out.append(t)
    return out

def load_vocab():
    try:
        return json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'references', 'query-vocabulary.json'), encoding='utf-8'))
    except Exception:
        return {}

def build_query_plan(case, task_text, vocab):
    qs = case.get('query_inputs') or case.get('queries') or case.get('query') or []
    if isinstance(qs, str):
        qs = [qs]
    if not qs and task_text:
        qs = [task_text[:400]]
    plan = []
    for qi, q in enumerate(qs):
        toks = tokens(q)
        low = [t.lower() for t in toks]
        exp = {}
        for mapping in ('synonyms', 'abbreviations', 'cross_language'):
            exp[mapping] = [v for k, vs in vocab.get(mapping, {}).items() if k.lower() in low
                            for v in vs if v.lower() not in low]
        plan.append({'query_id': 'q%02d' % (qi + 1), 'terms': toks,
                     'synonyms': exp['synonyms'], 'abbreviations': exp['abbreviations'],
                     'cross_language': exp['cross_language'], 'database': 'local_snapshot',
                     'fields': ['title', 'abstract'], 'date_range': case.get('date_range') or case.get('dateRange'),
                     'language': case.get('language') or case.get('languages'),
                     'search_date': case.get('search_date') or case.get('searchDate'),
                     'rationale': 'verbatim queries; vocab expansion'})
    return plan

def _terms_of(query_plan, criteria):
    return [t.lower() for q in query_plan for t in q.get('terms', [])] + [t.lower() for c in criteria for t in tokens(c)]

def relevance_score(r, terms):
    title, ab = (r.get('title') or '').lower(), (r.get('abstract') or '').lower()
    return sum(2 for t in terms if t in title) + sum(1 for t in terms if t in ab)

def _is_fixture(r):
    return bool(r.get('fixture') or FIXTURE_RE.search(' '.join(str(x) for x in r.values() if x)))

def screen_records(unique, qplan, inc, exc):
    terms, exct = _terms_of(qplan, inc), _terms_of([], exc)
    out = []
    for r in unique:
        title, score = r.get('title') or '', relevance_score(r, terms)
        base = {'record_id': r['record_id'], 'source': r.get('source_file'), 'locator': r.get('locator'),
                'relevance': score, 'year': r.get('year'), 'record': dict(r)}
        if _is_fixture(r):
            out.append(dict(base, decision='fixture', reason_code='FIXTURE',
                            evidence_quote=r.get('title') or r.get('doi') or '', confidence=None, needs_human=False))
            continue
        decision, code = 'review_needed', 'REVIEW_NEEDED'
        if title:
            if exc and any(t and t in title.lower() for t in exct):
                decision, code = 'exclude', 'EXCL_NOT_RELEVANT'
            elif score > 0 and terms:
                decision, code = 'include_candidate', 'INCLUDE_CANDIDATE'
        conf = {'review_needed': 'low', 'include_candidate': 'medium'}.get(decision, 'high')
        out.append(dict(base, decision=decision, reason_code=code, evidence_quote=title[:400] or (r.get('doi') or ''),
                        confidence=conf, needs_human=decision in ('review_needed', 'include_candidate')))
    return out

def detect_conflicts(mats, input_dir):
    pat = r'(?:annotator|reviewer|rater)[\s_]*[12ABab]?[":\s=]*(include|exclude|relevant|not[_ ]?relevant)'
    out = []
    for m in mats:
        p = os.path.join(input_dir, m['path'])
        try:
            raw = open(p, 'r', encoding='utf-8', errors='replace').read()
        except Exception:
            continue
        if not re.search(r'annotator|reviewer|rater|标注|评审', raw, re.I):
            continue
        ms = re.findall(pat, raw, re.I)
        if len(ms) >= 2 and ms[0].lower() != ms[1].lower():
            out.append({'record_id': None, 'annotator_a': ms[0], 'annotator_b': ms[1],
                        'decision': 'conflict', 'arbitration': None, 'basis': 'annotator opinions',
                        'type': 'relevance', 'source': m['path'], 'locator': 'text'})
    return out

def build_audit(n_raw, n_dedup, scr, conflicts):
    c = lambda d: sum(1 for s in scr if s['decision'] in d)
    n_i, n_e, n_r, n_f = c(('include', 'include_candidate')), c(('exclude',)), c(('review_needed',)), c(('fixture',))
    return [
        {'step': 'parse', 'input_count': None, 'output_count': n_raw, 'operator': OP,
         'basis': 'recursive /input scan'},
        {'step': 'dedup', 'input_count': n_raw, 'output_count': n_dedup, 'operator': OP,
         'basis': 'DOI+title normalized grouping'},
        {'step': 'screening', 'input_count': n_dedup, 'output_count': n_i + n_e + n_r + n_f, 'operator': OP,
         'basis': 'include=%d exclude=%d review=%d fixture=%d conflict=%d' % (n_i, n_e, n_r, n_f, len(conflicts))},
    ]

def build_coverage(screened, conflicts, records, query_plan):
    return {'included': sum(1 for s in screened if s['decision'] in ('include', 'include_candidate')),
            'excluded': sum(1 for s in screened if s['decision'] == 'exclude'),
            'review_needed': sum(1 for s in screened if s['decision'] == 'review_needed'),
            'conflicts': len(conflicts),
            'fixtures': sum(1 for s in screened if s['decision'] == 'fixture'),
            'omissions': ['queries: %d' % len(query_plan),
                          'no DOI: %d; no abstract: %d' %
                          (sum(1 for r in records if not r.get('doi')),
                           sum(1 for r in records if not r.get('abstract')))]}

def build_payload(case, task_text, mats, recs, degs, input_dir):
    vocab = load_vocab()
    inc, exc = extract_criteria(case, task_text)
    qplan = build_query_plan(case, task_text, vocab)
    groups = deduplicate(recs)
    unique = []
    for gi, i in enumerate(sorted(set(g['kept'] for g in groups))):
        r = dict(recs[i])
        r['record_id'], r['rank'] = 'r%03d' % i, gi + 1
        unique.append(r)
    scr = screen_records(unique, qplan, inc, exc)
    ranked = sorted(scr, key=lambda s: (-(s.get('relevance') or 0), -(s.get('year') or 0), s['record_id']))
    conflicts = detect_conflicts(mats, input_dir)
    return {'query_plan': qplan, 'raw_records': recs,
            'dedup': {'input_count': len(recs), 'output_count': len(unique), 'groups': groups},
            'unique_records': unique, 'screening': scr,
            'ranking': [{'rank': n + 1, 'record_id': s['record_id'], 'relevance': s.get('relevance') or 0,
                         'decision': s['decision'], 'reason_code': s['reason_code']} for n, s in enumerate(ranked)],
            'conflicts': conflicts, 'audit': build_audit(len(recs), len(unique), scr, conflicts),
            'coverage': build_coverage(scr, conflicts, recs, qplan),
            'inclusion_criteria': inc, 'exclusion_criteria': exc}

---
name: systematic-literature-screening
description: 系统性文献检索与纳排筛选。围绕固定研究问题，从本地检索导出（Crossref/EuropePMC/出版商响应/引用图/增量导入状态）中解析、去重、逐条筛选文献，输出可追溯的候选集、排序/纳排依据、冲突仲裁与审计日志。适用于系统综述、范围综述、指南证据更新的检索与题录筛选环节；离线、仅基于给定快照，不声称实时检索或全球召回。
version: 1.0.0
---

# 系统性文献检索与纳排筛选

## 用途
把"研究问题 → 检索协议 → 候选文献集 → 去重 → 标题/摘要纳排 → 冲突仲裁 → 审计"整条流程落到可复核的产物上。每一步都保留来源文件、定位符与逐字片段，任何第三人可据此复跑同一批题录并核对计数闭合。

适用：系统综述/范围综述/指南证据更新的题录检索与筛选。不适用：全文精读质量评价、数据提取、Meta 分析统计、论文写作。

## 触发条件
- 任务要求"检索并筛选文献"、输出候选集/纳排结论/遗漏说明；
- 输入为 `/input/case.json`（含 `case_id`、`task_instruction`、`output_contract`）+ `/input/task.md` + 本地材料（JSON/JSONL/XML/CSV/TSV/SQLite/纯文本；DOCX/PDF 记 degradations，交由平台 pdf-text-tool/文档阅读器处理）。

## 调用方式（运行时路径）
默认命令一次跑完整流程；所有命令纯 Python 标准库、不联网、不依赖 CWD：

```bash
python scripts/main.py                     # 完整流程：解析→去重→检索协议→纳排→审计→写 workdraft.json 与 result.json
python scripts/main.py init                # 只解析材料+去重+检索协议，写 workdraft.json（供人工逐条标注）
python scripts/main.py build               # 读当前 workdraft.json（含人工修订）→ 重新生成 result.json
python scripts/main.py show                # 打印 workdraft.json 摘要与计数
python scripts/main.py check               # 校验契约键、quote 命中率、计数闭合
python scripts/main.py --input DIR --work DIR --output DIR   # 环境变量 INPUT_DIR/WORK_DIR/OUTPUT_DIR 等价
```

默认路径：`/input`（输入）、`/app/work`（工作稿）、`/app/output`（产物）。脚本以 `Path(__file__).resolve().parent` 定位自身与 `references/`，不依赖 CWD。

## 输入输出
输入（只读，按真实文件解析，不按文件名标签假设内容）：
- `/input/case.json`：`case_id`、`task_instruction`、`output_contract`，可选 `inclusion_criteria`/`exclusion_criteria`/`query_inputs`/`research_question`；
- `/input/task.md`：案例任务说明（可能含纳入/排除标准与检索范围）；
- `/input/**`（递归 `os.walk`，含所有子目录）：Crossref/EuropePMC/出版商响应、引用图、增量导入状态等。

输出：
- `/app/work/workdraft.json`：工作稿（见下 schema）；
- `/app/output/result.json`：最终结果，原样回填 `case.json.output_contract` 的每个字段 + `case_id`，并附 `status/sources/uncertainty/change_records/errors/degradations` 与完整载荷 `systematic_search`。

## 工作稿 schema（`workdraft.json`）
```
{
  "schema_version": "1.0",
  "case_id": str, "task_instruction": str, "research_question": str,
  "inclusion_criteria": [str], "exclusion_criteria": [str], "query_inputs": [str],
  "materials": [{"path","type","bytes","parsed","note"}],
  "query_plan": [{"query_id","terms":[str],"synonyms":[str],"abbreviations":[str],
                  "cross_language":[str],"database":"local_snapshot","fields":["title","abstract"],
                  "date_range":null,"language":null,"search_date":null,"rationale":str}],
  "raw_records": [record], "dedup": {"input_count","output_count","groups":[{"record_ids","kept","basis","evidence"}]},
  "unique_records": [record],
  "screening": [{"record_id","decision","reason_code","evidence_quote","source","locator","confidence","needs_human"}],
  "conflicts": [{"record_id","annotator_a","annotator_b","decision","arbitration","basis","type"}],
  "audit": [{"step","input_count","output_count","operator","basis"}],
  "coverage": {"included","excluded","review_needed","conflicts","fixtures","omissions":[str]},
  "status": str, "errors": [str], "degradations": [str]
}
```
record 字段：`record_id,title,authors[],year,venue,doi,abstract,source_file,source_format,locator`（fixture 记录另有 `fixture:true`）。
`record_id` 为去重后的稳定标识（`r###`）；`title`/`abstract` 即材料中的逐字原文（仅空白归一），作为证据片段。

## 证据规范（红线）
- 每条候选/每条判定必须能指回 `source_file`（材料相对路径）+ `locator`（JSON 指针 / 行号 / XPath）+ `evidence_quote`（**逐字**命中材料原文）。
- quote 必须能在源文件原文中用子串命中；不得改写、不得翻译、不得用"示例片段"冒充。命中率自检 ≥0.95。
- 材料缺失、坏 JSON、编码乱码、权限不足：分别写进 `status/errors/degradations`，不补造文献与元数据。
- 无结果的 query 保留并说明；不声称"实时检索/最新文献/全球召回"。

## 纳排判据与理由码（字典见 references/reason-codes.md）
逐条把纳入/排除标准落到可判定判据；每条记录输出 `decision` + `reason_code` + `evidence_quote`。
decision 取值：`include / exclude / review_needed / conflict / fixture`。
reason_code 取值（详见 reason-codes.md）：
`INCLUDE / INCLUDE_CANDIDATE / EXCL_NOT_RELEVANT / EXCL_DUPLICATE / EXCL_LANGUAGE / EXCL_POPULATION / EXCL_INTERVENTION / EXCL_OUTCOME / EXCL_DESIGN / EXCL_DATE / EXCL_ABSTRACT_ONLY / EXCL_OTHER / REVIEW_NEEDED / CONFLICT / FIXTURE`。
边界情形：仅有摘要 → `EXCL_ABSTRACT_ONLY` 或 `REVIEW_NEEDED`（若标准允许摘要级纳入）；语言不符 → `EXCL_LANGUAGE`；研究对象部分重叠 → 依标准判 `INCLUDE` 并在证据中注明重叠点，或 `EXCL_POPULATION`。

## 冲突仲裁（不投票、不平均）
两标注者一致 → 采用一致结论；分歧 → 生成 `CONFLICT` 记录，列出 A/B 意见与分歧类型（relevance/population/intervention/outcome/language/duplicate），由仲裁者**逐条对照当前版本标准重读 title/abstract** 后判定，记录依据片段；不得用多数/平均掩盖实质争议。平台材料中标注为 fixture 的"冲突意见"是输入夹具，记为 `FIXTURE`，不是真人评审结果。

## 审计
`audit` 记录每步 input_count/output_count/operator/basis，使 `raw_records → dedup → screening` 计数首尾闭合；去重合并给出 `basis` 与证据（DOI 相同 / 标题归一相同），而不是只给剩余条数。

## 降级表
| 情形 | status | 处置 |
|-|-|-|
| 空输入目录/无材料 | insufficient_evidence | 合法 partial，candidates=[]，gaps 说明 |
| case.json 缺失/坏 JSON | input_error | partial，errors 记录，output_contract 回填为 null |
| 材料无法解析（PDF 无文本层/乱码/加密） | partial | degradations 记录文件与原因，其余照常 |
| 权限不足 | partial | errors 记录路径，退出码恒 0 |
| 无 criteria | partial | 全部 REVIEW_NEEDED，仅按相关性排序，不编造判定 |

## 自检（`check`）
校验：output_contract 键齐全且不改名；`result.json` 合法 JSON 且含 case_id；quote 命中率 ≥0.95；audit 计数闭合；无 `__pycache__`。

## 限制
- 离线、有限快照：仅处理给定材料，不做实时库检索，不声称覆盖度/召回率的绝对结论。
- 判定由算法预筛 + 研究者确认：`INCLUDE_CANDIDATE/REVIEW_NEEDED/CONFLICT` 必须由研究者最终确认后才作为最终纳入结论。
- 不处理全文精读、数据提取、偏倚评价与统计分析。

## 最小调用示例（示例，非正式案例结果）
输入 `/input/case.json` 含 `case_id="case01"`、`task_instruction="找出关于…的随机对照试验"`、`output_contract={"candidates":[],"query_plan":[]}`；材料 `materials/search01.json` 为 Crossref 响应。运行 `python scripts/main.py` 后，`/app/output/result.json` 回填 `case_id/candidates/query_plan`，并含 `systematic_search.dedup.output_count`、`systematic_search.screening[]` 等。以上字段值均为解析材料真实派生，示意输出不代表正式案例答案。

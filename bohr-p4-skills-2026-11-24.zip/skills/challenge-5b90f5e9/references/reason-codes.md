# 理由码字典与仲裁规则

## decision 取值
- `include`：符合全部纳入标准且不触发任何排除标准（人工确认后）。
- `exclude`：触发至少一条排除标准，且排除理由有原文片段支撑。
- `review_needed`：证据不足以机械判定，须人工确认。
- `conflict`：双人分歧，待仲裁。
- `fixture`：输入夹具（合成重复导出 / 合成冲突意见），非真实论文、非真人评审。

## reason_code 字典
| 码 | 含义 | 触发条件（可判定判据） | 证据要求 |
|-|-|-|-|
| INCLUDE | 纳入 | 满足全部纳入标准且无排除项 | title/abstract 中支撑纳入的片段 |
| INCLUDE_CANDIDATE | 候选纳入 | 算法预筛命中纳入关键词，待复核 | 命中的 title 片段 |
| EXCL_NOT_RELEVANT | 不相关 | title+abstract 与 PICO/研究问题无交集 | 说明无交集的证据（通常引用 title 全文） |
| EXCL_DUPLICATE | 重复 | 与已保留记录 DOI 相同或标题归一相同（预印本-正式版） | 两条的 title/DOI 对 |
| EXCL_LANGUAGE | 语言不符 | 语种不在允许列表 | title/abstract 语言证据 |
| EXCL_POPULATION | 人群不符 | 研究对象不属于目标人群 | 人群描述片段 |
| EXCL_INTERVENTION | 干预/暴露不符 | 干预或暴露不符合纳入标准 | 干预描述片段 |
| EXCL_OUTCOME | 结局不符 | 主要结局不在纳入标准 | 结局描述片段 |
| EXCL_DESIGN | 设计不符 | 研究设计类型不符合（如排除综述/个案） | 设计类型片段 |
| EXCL_DATE | 超出时间范围 | 发表年份不在范围内 | 年份字段 |
| EXCL_ABSTRACT_ONLY | 仅有摘要 | 无全文，且标准要求全文级 | 记录类型/来源证据 |
| EXCL_OTHER | 其他 | 其他明确排除理由 | 注明具体理由 + 片段 |
| REVIEW_NEEDED | 待复核 | 边界情形（对象部分重叠、摘要模糊） | title/abstract 原文 |
| CONFLICT | 分歧待仲裁 | 两标注者判定不一致 | A/B 意见 + 依据 |
| FIXTURE | 输入夹具 | 材料显式标注 synthetic/fixture/示例 | 标注原文 |

## 排除"不相关"必须可解释
禁止只写"不相关"。必须说明该记录与纳入标准哪一条不匹配，并用 title/abstract 原文片段作证；片段不足时降级为 `REVIEW_NEEDED`。

## 仲裁规则（不投票、不平均）
1. 两标注者一致 → 采用一致结论，保留原始 reason_code 与证据。
2. 分歧 → 输出 `CONFLICT` 记录：`annotator_a/annotator_b` 各含 decision+reason_code+evidence_quote；`type` 取 relevance/population/intervention/outcome/language/duplicate 之一。
3. 仲裁者逐条对照**当前版本标准**重读 title/abstract，给出 `arbitration`（include/exclude/review_needed）+ `basis`（引用标准条款 + 原文片段）；不得以多数/平均定案。
4. 平台标注为 fixture 的冲突意见记 `FIXTURE`，不当作真人评审结论。

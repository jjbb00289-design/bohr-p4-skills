# 检索协议与纳排流程模板

## 检索协议（query plan 必填项）
每个 query 记录：
- `terms`：实际检索词（来自 case 的 query_inputs，逐字保留）；
- `synonyms / abbreviations / cross_language`：仅当词表或材料中确有对应项时扩展，宁缺勿滥；
- `database`：材料来源标记（如 crossref/europepmc/publisher/reference_graph/local_import），非实时库名；
- `fields`：限定字段（title/abstract 等，缺省 `["title","abstract"]`）；
- `date_range / language / search_date`：仅当 case 明确给出时填写，否则 `null`；
- `rationale`：说明该 query 与哪条纳入标准对应。

检索式必须可从材料复核：query 词必须出现在 case.json 的 query_inputs 或任务说明中；不得凭空发明数据库名、日期或语种限制。

## 纳排流程（顺序固定，计数闭合）
1. **解析**：递归扫描 /input，按文件真实格式解析出 raw_records（每条带 source_file/locator/title/abstract）。
2. **去重**：DOI 归一（小写、去前缀 https://doi.org/）→ 标题归一（小写、去标点空白、去预印本后缀）→ 分组；同组保留记录 `kept`，其余 `EXCL_DUPLICATE`，`basis` 注明 DOI 相同或标题归一相同；预印本与正式版若 DOI 不同但标题归一相同且作者重叠则合并，`evidence` 存两条 title。
3. **纳排**：逐条对照标准输出 decision+reason_code+evidence_quote；边界情形（仅摘要/语言不符/对象部分重叠）明确标注。
4. **冲突**：两标注者一致则采用；分歧则 CONFLICT→仲裁（见 reason-codes.md）。
5. **审计**：每步 input_count/output_count/operator/basis；raw_records → dedup.output_count → screening 计数闭环；coverage.included+excluded+review_needed+conflicts+fixtures = dedup.output_count（按主要状态计）。

## 排序与覆盖说明
- 排序：确定性相关性分 = 检索词在 title 的命中数 ×2 + 在 abstract 的命中数 ×1，再按 year 降序稳定排序；输出 rank 与 score，供 Precision@k/nDCG 思路评估。
- 覆盖与遗漏：明确列出——无结果的 query、材料中无对应记录的关键词、被去重合并的记录、缺失 DOI/摘要的记录、标注 fixture 的记录；不声称全局召回。

## 人工最终确认
以下情况必须由研究者确认后才可作为最终结论：
- `INCLUDE_CANDIDATE / REVIEW_NEEDED / CONFLICT` 的全部记录；
- `EXCL_*` 中证据片段仅标题、无摘要的记录（防摘要缺失导致误排）。
模型/脚本输出在这些条件下只是待复核建议，不视为最终科学判断。

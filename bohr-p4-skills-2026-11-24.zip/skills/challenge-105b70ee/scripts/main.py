#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Literature finding & data extraction skill - command entry point.

Commands: init | show | check | build | selfcheck
  init      scan /input, index materials with locators, write a partial result.json
  show      print materials with stable locators (copy quotes from here verbatim)
  check     validate the agent draft: field ids, statuses, quote hits, numbers, units
  build     assemble deliverables + result.json (always finalizes, never crashes)
  selfcheck re-verify the finished result.json against the live materials

Rules honoured here: standard library only, no network, CWD independent, exit code 0.
The Agent reads materials and writes <work>/draft.json; the script never invents
values. A guessed value is not extraction; an absent field is not zero.
"""
import argparse
import csv
import json
import sys
import traceback
from pathlib import Path

sys.dont_write_bytecode = True  # keep the package free of __pycache__ / .pyc
sys.path.insert(0, str(Path(__file__).resolve().parent))
import io_parse as IOP  # noqa: E402
import schema_lib as SL  # noqa: E402
import derive_lib as DRV  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

PKG_NAME = "literature-field-extractor"
VERSION = "1.0.0"
PRODUCTS = ("result.json", "extraction_table.csv", "field_report.md", "field_dictionary.json")


# ------------------------------------------------------------------ commands
def cmd_init(args):
    inp, work, out = Path(args.input), Path(args.work), Path(args.output)
    IOP.ensure_dir(work)
    IOP.ensure_dir(out)
    case, case_err = SL.read_case(inp)
    contract = case.get("output_contract") if isinstance(case, dict) else {}
    corpus = IOP.build_corpus(inp)
    specs, spec_source = SL.find_field_specs(inp, case)
    degradations = list(corpus.get("degradations", []))
    errors = [case_err] if case_err else []
    if not specs:
        degradations.append("requested field specification not found; expected target-fields.json")
    index = {
        "case_id": SL.case_id_of(case), "input": str(inp),
        "material_count": len(corpus["materials"]),
        "segment_count": len(corpus["segments"]), "table_count": len(corpus["tables"]),
        "field_spec_source": spec_source, "field_count": len(specs), "specs": specs,
        "materials": [{"material": m["material"], "kind": m["kind"], "bytes": m["bytes"],
                       "segments": m["segments"], "tables": m["tables"],
                       "text_method": m["text_method"]} for m in corpus["materials"]],
        "tables": [{"table_id": t["table_id"], "material": t["material"],
                    "rows": len(t.get("row_lines") or t.get("rows") or [])}
                   for t in corpus["tables"]],
        "segments": corpus["segments"],
    }
    IOP.jdump(work / "index.json", index)
    IOP.jdump(work / "fields_skeleton.json", {"case_id": index["case_id"], "fields": specs})
    skeleton = SL.skeleton_fields(specs)
    status = "input_error" if (case_err and not corpus["materials"]) else "partial"
    pending = []
    if specs:
        pending.append("Agent must read materials (show) and write %s with one object per field_id"
                       % (work / "draft.json"))
    else:
        pending.append("Provide an input field specification (target-fields.json) with field_id entries")
    doc = SL.base_result(case, corpus, specs, status, skeleton, [], [], pending, errors, degradations)
    IOP.jdump(out / "result.json", SL.echo_contract(contract, doc))
    print("init: case_id=%s materials=%d segments=%d tables=%d fields=%d"
          % (index["case_id"], index["material_count"], index["segment_count"],
             index["table_count"], len(specs)))
    for mat in corpus["materials"]:
        print("  material: %-48s %-9s seg=%d tables=%d" % (mat["material"], mat["kind"],
                                                          mat["segments"], mat["tables"]))
    if not specs:
        print("  WARNING: field specification not found (expected target-fields.json)")
    print("next: python3 scripts/main.py show ; write work/draft.json ; check ; build")


def cmd_show(args):
    inp, work = Path(args.input), Path(args.work)
    index = IOP.jload(work / "index.json")
    if not index:
        cmd_init(args)
        index = IOP.jload(work / "index.json") or {}
    print("== case %s | materials=%s segments=%s tables=%s fields=%s ==" % (
        index.get("case_id"), index.get("material_count"), index.get("segment_count"),
        index.get("table_count"), index.get("field_count")))
    if args.fields:
        print("\n== requested fields (%s) ==" % index.get("field_count"))
        for spec in index.get("specs", []):
            print("- field_id=%s | unit_hint=%s | section_hint=%s | definition=%s" % (
                spec.get("field_id"), spec.get("unit_hint"), spec.get("section_hint"),
                (spec.get("definition") or "")[:240]))
    print("\n== materials ==")
    for mat in index.get("materials", []):
        print("- %-46s kind=%-9s bytes=%s seg=%s tables=%s method=%s" % (
            mat.get("material"), mat.get("kind"), mat.get("bytes"), mat.get("segments"),
            mat.get("tables"), mat.get("text_method")))
    budget = max(1000, int(args.limit))
    used, shown = 0, 0
    print("\n== segments (locator :: text) ==")
    for seg in index.get("segments", []):
        if args.material and args.material not in seg.get("material", ""):
            continue
        if args.pid and args.pid != seg.get("paragraph_id"):
            continue
        block = "--- %s :: %s :: section=%s :: page=%s ---\n%s\n" % (
            seg.get("material"), seg.get("paragraph_id"), seg.get("section"),
            seg.get("page"), seg.get("text"))
        if used + len(block) > budget:
            print("... truncated at %d chars; use --limit/--material/--pid" % used)
            break
        sys.stdout.write(block)
        used += len(block)
        shown += 1
    print("\n[shown %d segments, %d chars] copy quotes verbatim; locator = material + paragraph_id"
          % (shown, used))


def cmd_check(args):
    work = Path(args.work)
    index = IOP.jload(work / "index.json") or {}
    corpus = IOP.build_corpus(args.input) if Path(args.input).exists() else {
        "segments": index.get("segments", [])}
    specs = {spec.get("field_id"): spec for spec in index.get("specs", [])}
    draft, draft_err = SL.load_draft(work)
    fails, warns, quote_total, quote_hit = [], [], 0, 0
    if draft is None:
        fails.append(draft_err)
        counts = {}
    else:
        fields = SL.draft_fields(draft)
        ids = [field.get("field_id") for field in fields]
        missing = [fid for fid in specs if fid not in ids]
        extra = [fid for fid in ids if fid and fid not in specs]
        dups = sorted({fid for fid in ids if fid and ids.count(fid) > 1})
        if missing:
            fails.append("missing requested field_id(s): " + ", ".join(missing))
        if extra:
            warns.append("unknown field_id(s) not in spec: " + ", ".join(extra))
        if dups:
            fails.append("duplicate field_id(s): " + ", ".join(dups))
        counts = {}
        for field in fields:
            st = field.get("status") or "?"
            counts[st] = counts.get(st, 0) + 1
            if st == "reported":
                quote_total += 1
                if IOP.find_quote(corpus, str(field.get("quote") or "")):
                    quote_hit += 1
            f_fails, f_warns = SL.evaluate_field(field, specs.get(field.get("field_id")), corpus)
            fails.extend(f_fails)
            warns.extend(f_warns)
    hit_rate = round(quote_hit / quote_total, 4) if quote_total else 1.0
    report = {"ok": not fails, "fail": fails, "warn": warns,
              "fields_requested": len(specs),
              "fields_in_draft": len(SL.draft_fields(draft)) if draft else 0,
              "quote_total": quote_total, "quote_hit": quote_hit,
              "quote_hit_rate": hit_rate, "counts": counts}
    IOP.jdump(work / "check_report.json", report)
    print("check: %s | fields=%d/%d quote_hit=%d/%d (%.0f%%)" % (
        "PASS" if report["ok"] else "FAIL", report["fields_in_draft"],
        len(specs), quote_hit, quote_total, hit_rate * 100))
    for msg in fails[:20]:
        print("  FAIL " + msg)
    for msg in warns[:20]:
        print("  WARN " + msg)
    if not fails:
        print("ready: build emits result.json + extraction_table.csv + field_report.md")


def cmd_build(args):
    inp, work, out = Path(args.input), Path(args.work), Path(args.output)
    IOP.ensure_dir(work)
    IOP.ensure_dir(out)
    case, case_err = SL.read_case(inp)
    contract = case.get("output_contract") if isinstance(case, dict) else {}
    corpus = IOP.build_corpus(inp)
    specs, spec_source = SL.find_field_specs(inp, case)
    spec_map = {spec["field_id"]: spec for spec in specs}
    degradations = list(corpus.get("degradations", []))
    errors = [case_err] if case_err else []
    draft, draft_err = SL.load_draft(work)
    fields, claims, uncertainties = [], [], []
    check_report = IOP.jload(work / "check_report.json") or {}
    derive_meta = None
    if not corpus.get("materials"):
        degradations.append("no readable material under input; nothing can be extracted")
    if draft is None:
        # DERIVED_PATTERN: derive genuine per-field content directly from /input
        # so init -> build with no draft still yields real field-level results.
        degradations.append("no usable agent draft (%s); deriving field-level results directly from /input" % draft_err)
        fields, derive_meta = DRV.derive_fields(specs, corpus)
        vfails, vwarns = DRV.validate_and_downgrade(fields, specs, corpus, SL.evaluate_field, degradations)
        check_report = DRV.build_check_report(fields, specs, corpus, vfails, vwarns)
        IOP.jdump(work / "check_report.json", check_report)
        degradations.append("no-draft fallback used; deterministic derive produced per-field results "
                            "(agent draft still recommended for best quality)")
    else:
        seen = set()
        for raw in SL.draft_fields(draft):
            fid = raw.get("field_id") or "field_%03d" % (len(fields) + 1)
            if fid in seen:
                degradations.append("duplicate draft field_id dropped: %s" % fid)
                continue
            seen.add(fid)
            field = SL.normalize_field(raw, spec_map.get(fid))
            field["field_id"] = fid
            f_fails, f_warns = SL.evaluate_field(field, spec_map.get(fid), corpus)
            if f_fails and field["status"] == "reported":
                field["status"] = "extraction_failed"
                field["notes"] = "; ".join(f_fails)[:500]
                degradations.append("%s downgraded to extraction_failed: %s" % (fid, f_fails[0]))
            elif f_warns:
                field["validation_warnings"] = f_warns
            fields.append(field)
        for fid, spec in spec_map.items():
            if fid not in seen:
                # overlay/enrich: a requested field the draft left out is filled
                # by the same deterministic derive instead of a bare skeleton.
                derived_list, _dmeta = DRV.derive_fields([spec], corpus)
                derived = derived_list[0] if derived_list else None
                if derived and derived.get("status") in ("reported", "not_reported", "source_conflict"):
                    DRV.validate_and_downgrade([derived], [spec], corpus, SL.evaluate_field, degradations)
                    fields.append(derived)
                    degradations.append("requested field %s missing from draft; filled by deterministic derive" % fid)
                else:
                    field = SL.skeleton_fields([spec])[0]
                    field["status"] = "extraction_failed"
                    field["notes"] = "not present in draft and not derivable from materials"
                    fields.append(field)
                    degradations.append("requested field not extracted: %s" % fid)
        if isinstance(draft.get("uncertainties"), list):
            uncertainties.extend(draft["uncertainties"])
    for field in fields:
        status = field.get("status")
        src = field.get("source") or {}
        if status == "reported":
            claims.append({
                "claim_id": "F-" + str(len(claims) + 1).zfill(3),
                "field_id": field.get("field_id"),
                "text": "%s = %s" % (field.get("field_id"), field.get("value")),
                "kind": field.get("claim_type") or "reported_value",
                "evidence": [{
                    "material": src.get("material"),
                    "locator": {key: src.get(key) for key in
                                ("paragraph_id", "page", "section", "table_id", "row", "col",
                                 "char_start", "char_end")},
                    "quote": field.get("quote"),
                    "quote_match": "exact" if IOP.find_quote(corpus, str(field.get("quote") or ""))
                    else "unverified"}],
                "conditions": field.get("condition"),
                "comparator": field.get("comparator")})
        elif status == "not_reported":
            uncertainties.append({"kind": "not_reported", "field_id": field.get("field_id"),
                                  "detail": field.get("notes") or "searched; value not reported",
                                  "search_attempts": field.get("search_attempts") or []})
        elif status == "source_conflict":
            uncertainties.append({"kind": "source_conflict", "field_id": field.get("field_id"),
                                  "detail": "locators disagree; both sides kept verbatim",
                                  "conflict": field.get("conflict")})
        elif status == "extraction_failed":
            uncertainties.append({"kind": "extraction_failed", "field_id": field.get("field_id"),
                                  "detail": field.get("notes") or "not extracted"})
    coverage = SL.coverage_of(fields, [spec["field_id"] for spec in specs])
    terminal = bool(fields) and all(field.get("status") in SL.STATUS_TERMINAL for field in fields)
    if not case:
        status = "input_error"
    elif not corpus.get("materials") or not specs:
        status = "insufficient_evidence"
    elif terminal and coverage["complete"] and check_report.get("ok"):
        status = "ok"
    else:
        status = "partial"
    pending_human = []
    if status != "ok":
        pending_human.append("Review degradations/uncertainties, fix the draft, re-run check+build")
    extra = {"validation": check_report, "spec_source": spec_source}
    if derive_meta:
        extra["derivation"] = derive_meta
    doc = SL.base_result(case, corpus, specs, status, fields, claims, uncertainties,
                         pending_human, errors, degradations, extra)
    IOP.jdump(out / "result.json", SL.echo_contract(contract, doc))
    rows = [["field_id", "value", "units", "statistic", "n", "condition", "comparator",
             "status", "claim_type", "material", "section", "page", "paragraph_id",
             "table_id", "row", "quote", "semantic_match", "notes"]]
    for field in fields:
        src = field.get("source") or {}
        check = field.get("semantic_check") or {}
        rows.append([field.get("field_id"), field.get("value"), field.get("units"),
                     field.get("statistic"), field.get("n"), field.get("condition"),
                     field.get("comparator"), field.get("status"), field.get("claim_type"),
                     src.get("material"), src.get("section"), src.get("page"),
                     src.get("paragraph_id"), src.get("table_id"), src.get("row"),
                     field.get("quote"), check.get("match"), field.get("notes")])
    try:
        with open(out / "extraction_table.csv", "w", encoding="utf-8-sig", newline="") as fh:
            writer = csv.writer(fh)
            writer.writerows(rows)
    except Exception as exc:
        degradations.append("extraction_table.csv failed: %s" % exc)
    IOP.jdump(out / "field_dictionary.json", doc["result"]["field_dictionary"])
    report = ["# Field extraction report", "",
              "- case_id: `%s`" % doc["case_id"],
              "- status: **%s**" % status,
              "- skill: %s v%s" % (PKG_NAME, VERSION),
              "- materials scanned: %d | segments: %d | tables: %d" % (
                  len(corpus["materials"]), len(corpus["segments"]), len(corpus["tables"])),
              "- coverage: required=%d reported=%d not_reported=%d source_conflict=%d extraction_failed=%d"
              % (coverage["required"], coverage["reported"], coverage["not_reported"],
                 coverage["source_conflict"], coverage["extraction_failed"]), "",
              "## Extracted fields", "",
              "| field_id | value | units | condition | status | locator | quote |",
              "|---|---|---|---|---|---|---|"]
    for field in fields:
        src = field.get("source") or {}
        locator = "%s:%s" % (src.get("material") or "-",
                             src.get("paragraph_id") or src.get("table_id") or "-")
        if src.get("page"):
            locator += " p.%s" % src["page"]
        quote = (field.get("quote") or "").replace("|", "\\|")
        if len(quote) > 180:
            quote = quote[:177] + "..."
        report.append("| %s | %s | %s | %s | %s | %s | %s |" % (
            field.get("field_id"), field.get("value"), field.get("units"),
            field.get("condition"), field.get("status"), locator, quote))
    report.append("")
    if uncertainties:
        report.append("## Uncertainties and unreported items")
        for item in uncertainties:
            report.append("- `%s` (%s): %s" % (item.get("field_id") or item.get("kind"),
                                              item.get("kind"), item.get("detail")))
        report.append("")
    report.append("## Method notes")
    for key, value in doc["result"]["method_notes"].items():
        report.append("- %s: %s" % (key, value))
    report += ["", "## Degradations"]
    for item in degradations or ["none"]:
        report.append("- " + str(item))
    try:
        (out / "field_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    except Exception as exc:
        degradations.append("field_report.md failed: %s" % exc)
    IOP.jdump(work / "build_summary.json", {"case_id": doc["case_id"], "status": status,
                                            "coverage": coverage, "degradations": degradations})
    print("build: status=%s case_id=%s fields=%d reported=%d not_reported=%d conflict=%d failed=%d"
          % (status, doc["case_id"], len(fields), coverage["reported"],
             coverage["not_reported"], coverage["source_conflict"],
             coverage["extraction_failed"]))
    for name in PRODUCTS:
        path = out / name
        print("  %-24s %s bytes" % (name, path.stat().st_size if path.exists() else "MISSING"))
    for item in degradations[:8]:
        print("  degrade: " + str(item)[:200])


def cmd_selfcheck(args):
    inp, work, out = Path(args.input), Path(args.work), Path(args.output)
    case, _ = SL.read_case(inp)
    contract = case.get("output_contract") if isinstance(case, dict) else {}
    result = IOP.jload(out / "result.json")
    problems = []
    if not isinstance(result, dict):
        problems.append("output/result.json missing or invalid")
        result = {}
    for key in SL.contract_keys(contract):
        if key not in result:
            problems.append("contract key missing: " + key)
    if result.get("case_id") != SL.case_id_of(case):
        problems.append("case_id mismatch: %r vs %r" % (result.get("case_id"),
                                                       SL.case_id_of(case)))
    corpus = IOP.build_corpus(inp)
    fields = (result.get("result") or {}).get("fields") or []
    checked = hits = 0
    for field in fields:
        if isinstance(field, dict) and field.get("status") == "reported":
            checked += 1
            if IOP.find_quote(corpus, str(field.get("quote") or "")):
                hits += 1
            else:
                problems.append("quote no longer verifies: %s" % field.get("field_id"))
    for name in PRODUCTS:
        if not (out / name).exists():
            problems.append("missing deliverable: " + name)
    coverage = (result.get("result") or {}).get("coverage") or {}
    if coverage:
        total = sum(coverage.get(key, 0) for key in
                    ("reported", "not_reported", "source_conflict", "extraction_failed"))
        if total != len(fields):
            problems.append("coverage counts (%d) != field rows (%d)" % (total, len(fields)))
    report = {"ok": not problems, "problems": problems,
              "contract_keys": SL.contract_keys(contract), "fields": len(fields),
              "quote_checked": checked, "quote_verified": hits}
    IOP.jdump(work / "selfcheck_report.json", report)
    print("selfcheck: %s | contract_keys=%d fields=%d quotes=%d/%d" % (
        "PASS" if report["ok"] else "FAIL", len(report["contract_keys"]), len(fields),
        hits, checked))
    for item in problems[:15]:
        print("  FAIL " + str(item))


# ------------------------------------------------------------------------ cli
class SafeParser(argparse.ArgumentParser):
    def error(self, message):
        print("argument warning: " + message)
        self.print_help()
        sys.exit(0)


def add_paths(parser):
    parser.add_argument("--input", default=argparse.SUPPRESS, help="input dir (default /input)")
    parser.add_argument("--work", default=argparse.SUPPRESS, help="work dir (default /app/work)")
    parser.add_argument("--output", default=argparse.SUPPRESS, help="output dir (default /app/output)")


def build_parser():
    parser = SafeParser(prog="main.py",
                        description="Literature finding & data extraction skill")
    parser.add_argument("--input", default="/input")
    parser.add_argument("--work", default="/app/work")
    parser.add_argument("--output", default="/app/output")
    parser.add_argument("--version", action="version", version=PKG_NAME + " " + VERSION)
    sub = parser.add_subparsers(dest="command")
    for name, help_text in (("init", "scan input, index materials, write partial result.json"),
                            ("show", "print materials with locators"),
                            ("check", "validate the agent draft"),
                            ("build", "assemble deliverables and finalize result.json"),
                            ("selfcheck", "re-verify the finished result.json")):
        child = sub.add_parser(name, help=help_text)
        add_paths(child)
        if name == "show":
            child.add_argument("--material", default="", help="filter by material substring")
            child.add_argument("--pid", default="", help="filter by exact paragraph_id")
            child.add_argument("--fields", action="store_true", help="also print requested fields")
            child.add_argument("--limit", default="60000", help="max characters printed")
    return parser


def emergency_finalize(args, exc_text):
    try:
        work, out = Path(getattr(args, "work", "/app/work")), Path(getattr(args, "output", "/app/output"))
        IOP.ensure_dir(work)
        IOP.ensure_dir(out)
        case, _ = SL.read_case(Path(getattr(args, "input", "/input")))
        contract = case.get("output_contract") if isinstance(case, dict) else {}
        doc = {
            "case_id": SL.case_id_of(case), "status": "input_error",
            "result": {"fields": [], "coverage": SL.coverage_of([], []),
                       "field_dictionary": {"fields": [], "rules": []},
                       "method_notes": {"skill": PKG_NAME, "version": VERSION}},
            "claims": [], "uncertainties": [], "sources": [],
            "pending_human": ["Unexpected skill error; inspect errors and rerun init/show/check/build"],
            "errors": [exc_text[:2000]], "degradations": ["emergency_finalize used"],
            "deliverables": {},
        }
        IOP.jdump(out / "result.json", SL.echo_contract(contract, doc))
    except Exception:
        pass


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    args.input = Path(getattr(args, "input", "/input"))
    args.work = Path(getattr(args, "work", "/app/work"))
    args.output = Path(getattr(args, "output", "/app/output"))
    command = getattr(args, "command", None)
    try:
        if command == "init":
            cmd_init(args)
        elif command == "show":
            cmd_show(args)
        elif command == "check":
            cmd_check(args)
        elif command == "build":
            cmd_build(args)
        elif command == "selfcheck":
            cmd_selfcheck(args)
        else:
            parser.print_help()
    except SystemExit:
        raise
    except BaseException as exc:
        traceback.print_exc()
        emergency_finalize(args, "%s: %s" % (type(exc).__name__, exc))
    return 0


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except BaseException:
        traceback.print_exc()
    sys.exit(0)

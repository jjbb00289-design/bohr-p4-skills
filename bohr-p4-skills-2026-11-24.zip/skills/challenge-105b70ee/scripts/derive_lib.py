# -*- coding: utf-8 -*-
"""Deterministic no-draft derivation of field-level extraction results.

The agent draft is still the preferred, higher-quality path.  When no usable
draft exists, ``build`` calls ``derive_fields`` here instead of emitting an
``extraction_failed`` skeleton.  Every element returned (value, units,
statistic, condition, comparator, quote and locator) is taken verbatim from the
live /input materials; nothing is invented and no unit is fabricated.

Rules enforced here
-------------------
* Field id is normalised (underscores -> spaces, camelCase split) and searched
  in every material segment in a fixed sorted order.
* A value is only accepted when a numeric token and (for value-bearing fields)
  a real unit / statistical operator / ``n =`` / ``p <`` pattern occur in the
  same sentence or table row.  Bare numbers without any such marker are not
  treated as values.
* ``units`` is only filled from a unit token that literally occurs in the quote
  (or, for table rows, from the row itself); never from the field hint alone.
* ``statistic``, ``condition`` and ``comparator`` come only from the same
  sentence/row as the value.
* ``quote`` is an exact substring of the segment text, so the verbatim check in
  io_parse.find_quote passes by construction.
* Two segments giving different values for the same field (with the field's
  primary token present in both) yield ``source_conflict`` with both quotes
  kept; nothing is averaged.
"""
import re

from io_parse import HEDGE_RE, NUM_RE, find_quote, norm_text

# --------------------------------------------------------------------------
# tokenisation helpers
# --------------------------------------------------------------------------
STOP = set("a an the of at in on and or for from with to by as is are was were "
           "be been being into per vs versus compared among between within over "
           "under via using used its it this that these those then when where "
           "which who whom whose not no nor but if than also each".split())

GENERIC = set("value values change changes level levels group groups size number "
              "count total mean median effect effects rate ratio score data result "
              "results primary secondary time point endpoint measure outcome "
              "parameter variable index significance difference magnitude "
              "attributed reported".split())

CONTROL_TOKENS = {"vehicle", "control", "placebo", "sham", "baseline",
                  "untreated", "reference", "comparator"}

UNIT_CHAR = r"[A-Za-z\u00b5\u03bc%°][A-Za-z\u00b5\u03bc%/°²³·.\-]*"
UNIT_PAT = UNIT_CHAR + r"(?:\s*/\s*[A-Za-z\u00b5\u03bc%°]+)?"

BAD_UNITS = set("in at the of for to was were are is and with from by as vs versus "
                "per group groups compared a an than between among during after "
                "before under over within across up down when where which that this "
                "these those it its on or not no but via using used".split())

# canonical unit whitelist: only these tokens may be emitted as a derived unit
KNOWN_UNITS = {
    "g", "mg", "kg", "ng", "pg", "ug", "ug/ml", "ug/l", "mg/kg", "mg/ml", "mg/l",
    "ng/ml", "ng/l", "pg/ml", "mg/dl", "g/dl", "g/l", "iu/ml", "u/ml",
    "ml", "l", "ul", "mmol", "mol", "umol", "umol/l", "nmol", "pmol",
    "mmol/l", "nmol/l", "mm", "cm", "m", "nm", "um", "pm", "kg/m2", "mg/m2",
    "s", "h", "hr", "hrs", "min", "mins", "day", "days", "week", "weeks",
    "month", "months", "year", "years", "%", "°c", "°f", "k", "mmhg",
    "bpm", "rpm", "kcal", "kj", "cmh2o", "cells", "mice", "rats", "patients",
    "subjects", "participants", "samples", "animals",
}


def canon_unit(unit):
    return str(unit or "").lower().replace("\u00b5", "u").replace("\u03bc", "u")


def unit_ok(unit):
    if unit is None:
        return False
    unit = str(unit).strip()
    if not unit:
        return False
    if not re.fullmatch(UNIT_PAT, unit):
        return False
    return canon_unit(unit) in KNOWN_UNITS


def num_boundary_ok(text, start, end):
    """Reject numbers embedded in longer alphanumeric identifiers (C57BL/6J...)."""
    if start > 0 and re.match(r"[A-Za-z0-9]", text[start - 1]):
        return False
    if end < len(text) and re.match(r"[A-Za-z0-9]", text[end]):
        return False
    return True

SECTION_WORDS = set("abstract introduction background methods results discussion "
                    "conclusions limitations supplementary supplemental appendix".split())

# secondary / exploratory mentions do not count as the field's primary reading
EXCLUDE_RE = re.compile(
    r"\b(?:exploratory|second cohort|sensitivity analys|subgroup|post[- ]?hoc|"
    r"secondary analys|replication|not pre[- ]?specified)\b", re.I)


def field_tokens(field_id):
    """underscores/hyphens -> spaces, camelCase split, lower-case tokens."""
    value = str(field_id or "")
    value = value.replace("_", " ").replace("-", " ").replace(".", " ")
    value = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", value)
    value = re.sub(r"([A-Z])([A-Z][a-z])", r"\1 \2", value)
    return [t for t in re.split(r"[^A-Za-z0-9\u00b5\u03bc]+", value.lower()) if t]


def def_tokens(definition):
    words = re.findall(r"[a-z0-9][a-z0-9\u00b5\u03bc\-/]*", str(definition or "").lower())
    out = []
    for word in words:
        word = word.strip("-/")
        if word in STOP or len(word) < 2:
            continue
        out.append(word)
    return out


def token_in_text(token, text_low):
    if not token:
        return False
    token = token.lower()
    if re.fullmatch(r"[a-z0-9]+", token):
        return bool(re.search(r"(?<![\w-])" + re.escape(token) + r"(?![\w-])", text_low))
    return token in text_low


def primary_token(tokens):
    for token in tokens:
        if token not in GENERIC:
            return token
    return None


def is_control_side(tokens):
    return any(token in CONTROL_TOKENS for token in tokens)


def field_flags(spec):
    tokens = field_tokens(spec.get("field_id"))
    dtoks = def_tokens(spec.get("definition"))
    all_toks = set(tokens) | set(dtoks)
    is_p = ("p" in tokens) or ("pvalue" in all_toks) or ("significance" in all_toks)
    is_n = ("n" in tokens) or ("sample" in tokens)
    unit_hint = (spec.get("unit_hint") or "").strip()
    return {"tokens": tokens, "def": dtoks, "is_p": is_p, "is_n": is_n,
            "unit_hint": unit_hint, "control": is_control_side(tokens)}


def unit_is_specific(unit_hint):
    hint = str(unit_hint or "").strip()
    if not hint:
        return False
    if any(ch in hint for ch in "/%°\u00b5\u03bc"):
        return True
    return len(hint) >= 2


def has_number(text):
    return bool(NUM_RE.search(text or ""))


# --------------------------------------------------------------------------
# value extraction from one piece of text (sentence or table row)
# --------------------------------------------------------------------------
P_RE = re.compile(r"\bp\s*(<|>|=|≤|≥|<=|>=)\s*([0-9]+(?:\.[0-9]+)?)", re.I)
N_RE = re.compile(r"\bn\s*=\s*([0-9]+)(?:\s*per\s+(group|arm|animal|mouse|mice|rat|subject|patient|sample|participant))?", re.I)
MEAN_RE = re.compile(r"([-+]?[0-9]+(?:\.[0-9]+)?)\s*±\s*([0-9]+(?:\.[0-9]+)?)(\s*" + UNIT_PAT + r")?")
NUM_UNIT_RE = re.compile(r"([-+]?[0-9]+(?:\.[0-9]+)?)(\s*" + UNIT_PAT + r")")
PCT_RE = re.compile(r"([-+]?[0-9]+(?:\.[0-9]+)?)\s*%")


def parsed_number(value):
    match = re.search(r"[-+]?[0-9]+(?:\.[0-9]+)?", str(value or ""))
    if not match:
        return None
    token = match.group(0)
    if "." in token:
        try:
            return float(token)
        except Exception:
            return None
    try:
        return int(token)
    except Exception:
        return None


def extract_value(text, spec):
    """Return a dict with value/units/statistic/n, or None if nothing genuine."""
    flags = field_flags(spec)
    hint = flags["unit_hint"]
    if hint and unit_is_specific(hint):
        # a specific unit hint (mg/kg, µg/mL, %) anchors the matching number+unit
        for match in re.finditer(r"([-+]?[0-9]+(?:\.[0-9]+)?)\s*(" + re.escape(hint) + r")",
                                 text, re.I):
            if num_boundary_ok(text, match.start(), match.end()):
                return {"value": match.group(0).strip(), "units": match.group(2),
                        "statistic": None}
    if flags["is_p"]:
        match = P_RE.search(text)
        if match:
            op, num = match.group(1), match.group(2)
            value = (op + num) if op != "=" else num
            return {"value": value, "units": "", "statistic": "p %s %s (as reported)" % (op, num)}
    if flags["is_n"]:
        match = N_RE.search(text)
        if match:
            value = match.group(1)
            if match.group(2):
                value += " per " + match.group(2).lower()
            return {"value": value, "units": "", "statistic": None,
                    "n": int(match.group(1))}
    for match in MEAN_RE.finditer(text):
        if not num_boundary_ok(text, match.start(), match.end()):
            continue
        unit = (match.group(3) or "").strip()
        if unit and not unit_ok(unit):
            unit = ""
        statistic = "mean ± SD"
        low = text.lower()
        if re.search(r"\b(?:sem|se)\b", low):
            statistic = "mean ± SE"
        elif re.search(r"\bsd\b", low):
            statistic = "mean ± SD"
        return {"value": match.group(0).strip(), "units": unit, "statistic": statistic,
                "n": None}
    for match in PCT_RE.finditer(text):
        if num_boundary_ok(text, match.start(), match.end()):
            return {"value": match.group(0).strip(), "units": "%", "statistic": None}
    for match in NUM_UNIT_RE.finditer(text):
        if not num_boundary_ok(text, match.start(), match.end()):
            continue
        unit = (match.group(2) or "").strip()
        if unit_ok(unit):
            return {"value": match.group(0).strip(), "units": unit, "statistic": None}
    return None


# --------------------------------------------------------------------------
# condition / comparator from the same sentence or row
# --------------------------------------------------------------------------
CONTEXT_PATTERNS = [
    r"\bday\s+[0-9]+", r"\bweek\s+[0-9]+", r"\bmonth\s+[0-9]+",
    r"\b[0-9]+(?:\.[0-9]+)?\s*h\s+post[- ]?dose\b", r"\bfor\s+[0-9]+\s+days?\b",
    r"\bonce\s+daily\b", r"\boral\b", r"\bper\s+group\b", r"\b[0-9]+\s*mg/kg\b",
    r"\bpost[- ]?dose\b",
]
SUBJECT_PATTERNS = [
    r"\bcompound\s+X\b", r"\bvehicle\b", r"\bcontrol\b", r"\bplacebo\b", r"\bsham\b",
    r"\btreated\b", r"\bmale\b", r"\bfemale\b", r"\bmice\b", r"\brats\b",
    r"\bpatients\b", r"\bsubjects\b", r"\bparticipants\b", r"\bvolunteers\b",
]
GROUP_WORDS = "vehicle|control|placebo|sham|baseline|untreated|treated|reference|compound X|test|standard|active"


def extract_condition(quote):
    found = []
    for pattern in CONTEXT_PATTERNS:
        for match in re.finditer(pattern, quote, re.I):
            token = match.group(0)
            if token and not any(token.lower() in existing.lower() for existing in found):
                found.append(token)
    for pattern in SUBJECT_PATTERNS:
        for match in re.finditer(pattern, quote, re.I):
            token = match.group(0)
            if token and not any(token.lower() in existing.lower() for existing in found):
                found.append(token)
    for match in re.finditer(r"((?:the\s+)?(?:" + GROUP_WORDS + r")(?:\s+group)?)", quote, re.I):
        token = match.group(0).strip()
        if token and not any(token.lower() in existing.lower() for existing in found):
            found.append(token)
    return ", ".join(found[:5]) if found else None


def extract_comparator(quote, control_side):
    if control_side:
        before = re.split(r"(?:versus|vs\.?|compared\s+(?:with|to)|relative\s+to)", quote, 1, re.I)[0]
        match = re.search(r"((?:the\s+)?(?:" + GROUP_WORDS + r")(?:\s+group)?)", before, re.I)
        if match:
            return match.group(1).strip()
        return None
    match = re.search(r"(?:versus|vs\.?|compared\s+(?:with|to)|relative\s+to)\s+(.*?)(?=[,(]|$)", quote, re.I)
    if match:
        tail = match.group(1).strip()
        gm = re.search(r"((?:the\s+)?(?:" + GROUP_WORDS + r")(?:\s+group)?)", tail, re.I)
        if gm:
            return gm.group(1).strip()
        words = tail.split()
        return " ".join(words[:6]).rstrip(".,;") if words else None
    match = re.search(r"\b(vehicle|control|placebo|sham|baseline|untreated)\b(?:\s+group)?", quote, re.I)
    return match.group(0).strip() if match else None


# --------------------------------------------------------------------------
# segment scoring / candidate selection
# --------------------------------------------------------------------------
def split_sentences(text):
    parts = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9(])", text or "")
    return [part.strip() for part in parts if part.strip()]


def seg_sort_key(seg):
    return (seg.get("material") or "", seg.get("paragraph_id") or "",
            seg.get("char_start") or 0, seg.get("sid") or "")


def segment_score(spec, seg, flags, unit_in_value=""):
    text_low = (seg.get("text") or "").lower()
    score = 0.0
    for token in flags["tokens"]:
        if token_in_text(token, text_low):
            score += 3.0
    for token in flags["def"]:
        if token_in_text(token, text_low):
            score += 1.0
    hint = flags["unit_hint"]
    if hint and unit_is_specific(hint) and hint.lower() in text_low:
        score += 2.0
    if unit_in_value and hint and unit_is_specific(hint) and \
            norm_text(unit_in_value) == norm_text(hint):
        score += 1.5
    section = (spec.get("section_hint") or "").strip().lower()
    if section:
        seg_section = (seg.get("section") or "").lower()
        if seg_section == section or section in seg_section or \
                (section in SECTION_WORDS and seg_section and section in seg_section):
            score += 1.5
    return score


def segment_candidate(spec, flags, seg):
    if EXCLUDE_RE.search(seg.get("text") or ""):
        return False
    text_low = (seg.get("text") or "").lower()
    anchor = primary_token(flags["tokens"])
    anchor_ok = bool(anchor) and token_in_text(anchor, text_low)
    hint_ok = flags["unit_hint"] and unit_is_specific(flags["unit_hint"]) and \
        flags["unit_hint"].lower() in text_low
    pattern_ok = (flags["is_p"] and bool(P_RE.search(seg.get("text") or ""))) or \
                 (flags["is_n"] and bool(N_RE.search(seg.get("text") or "")))
    return anchor_ok or hint_ok or pattern_ok


def value_half(sentence, control_side, keep_whole=False):
    """For a comparative sentence, the treated/control value sits before/after the marker."""
    if keep_whole:
        return sentence
    parts = re.split(r"(?:versus|vs\.?|compared\s+(?:with|to)|relative\s+to)",
                     sentence, maxsplit=1, flags=re.I)
    if len(parts) == 2:
        return parts[1] if control_side else parts[0]
    return sentence


def choose_sentence(seg, spec, flags):
    """For a paragraph segment choose the sentence that yields a genuine value."""
    text = seg.get("text") or ""
    sentences = split_sentences(text)
    best = None
    for sentence in sentences:
        half = value_half(sentence, flags["control"], flags["is_p"] or flags["is_n"])
        ext = extract_value(half, spec)
        if not ext or ext.get("value") is None:
            continue
        unit_in_value = ext.get("units") or ""
        score = segment_score(spec, seg, flags, unit_in_value)
        for token in flags["tokens"]:
            if token_in_text(token, sentence.lower()):
                score += 1.0
        for token in flags["def"]:
            if token_in_text(token, sentence.lower()):
                score += 0.5
        if best is None or score > best[0]:
            best = (score, sentence, ext)
    return best


def row_control(text):
    return bool(re.search(r"\b(vehicle|control|placebo|sham|baseline|untreated|reference)\b",
                          (text or "").lower()))


def extract_from_segment(seg, spec):
    flags = field_flags(spec)
    if not has_number(seg.get("text") or ""):
        return None
    if seg.get("table_id"):
        if flags["control"] != row_control(seg.get("text") or ""):
            return None
        ext = extract_value(seg.get("text") or "", spec)
        if not ext or ext.get("value") is None:
            return None
        quote = (seg.get("text") or "").strip()
        cells = [c.strip() for c in (seg.get("text") or "").split("|")]
        col = None
        numeric = re.search(r"[0-9]+(?:\.[0-9]+)?", str(ext.get("value") or ""))
        if numeric:
            for index, cell in enumerate(cells):
                if numeric.group(0) in cell:
                    col = index
                    break
        return {"quote": quote, "ext": ext, "seg": seg, "col": col}
    chosen = choose_sentence(seg, spec, flags)
    if not chosen:
        return None
    return {"quote": chosen[1], "ext": chosen[2], "seg": seg, "col": None}


def locator(seg, col=None):
    return {"material": seg.get("material"), "section": seg.get("section"),
            "paragraph_id": seg.get("paragraph_id"), "page": seg.get("page"),
            "table_id": seg.get("table_id"), "row": seg.get("row"), "col": col,
            "char_start": seg.get("char_start"), "char_end": seg.get("char_end")}


def normalized_value(ext):
    return tuple(re.findall(r"[-+]?[0-9]+(?:\.[0-9]+)?", str(ext.get("value") or "")))


def unit_mismatch(spec, ext):
    """A field's unit hint is a strong semantic anchor: a different recognised
    unit in the candidate means the number is about another quantity (e.g. a
    dose in mg/kg is not a body-weight change in g)."""
    hint = (spec.get("unit_hint") or "").strip()
    if not hint:
        return False
    unit = (ext.get("units") or "").strip()
    if not unit:
        return False
    return canon_unit(unit) != canon_unit(hint)


# --------------------------------------------------------------------------
# one field
# --------------------------------------------------------------------------
def not_reported_field(spec, segments, reason):
    materials = []
    sections = []
    for seg in segments:
        if seg.get("material") and seg["material"] not in materials:
            materials.append(seg["material"])
        if seg.get("section") and seg["section"] not in sections:
            sections.append(seg["section"])
    attempts = ["scanned all %d text/table segments" % len(segments)]
    attempts.extend("material: " + mat for mat in materials)
    if sections:
        attempts.append("sections: " + ", ".join(sections))
    return {
        "field_id": spec.get("field_id"), "value": None, "parsed_value": None,
        "parsed_unit": None, "units": "", "statistic": None, "n": None,
        "condition": None, "comparator": None, "status": "not_reported",
        "claim_type": None, "quote": None,
        "source": {"material": None, "section": None, "paragraph_id": None, "page": None,
                   "table_id": None, "row": None, "col": None},
        "semantic_check": {"target_definition": spec.get("definition") or "",
                           "match": False, "reason": reason},
        "search_attempts": attempts, "notes": reason,
        "derivation": "deterministic_regex_no_draft",
    }


def reported_field(spec, seg, ext, quote, col):
    condition = extract_condition(quote)
    comparator = extract_comparator(quote, field_flags(spec)["control"])
    quote_low = quote.lower()
    claim_type = "speculation" if HEDGE_RE.search(quote) else "result"
    n = ext.get("n")
    if n is None:
        match = re.search(r"\bn\s*=\s*([0-9]+)", quote, re.I)
        n = int(match.group(1)) if match else None
    return {
        "field_id": spec.get("field_id"),
        "value": ext.get("value"),
        "parsed_value": parsed_number(ext.get("value")),
        "parsed_unit": ext.get("units") or None,
        "units": ext.get("units") or "",
        "statistic": ext.get("statistic"),
        "n": n,
        "condition": condition,
        "comparator": comparator,
        "status": "reported",
        "claim_type": claim_type,
        "quote": quote,
        "source": locator(seg, col),
        "semantic_check": {"target_definition": spec.get("definition") or "",
                           "match": True,
                           "reason": ("derived from one verbatim sentence/row; value, unit, "
                                      "condition and comparator kept literal from the same source")},
        "notes": None,
        "derivation": "deterministic_regex_no_draft",
    }


def conflict_field(spec, sides):
    conflict = [{"material": side[0].get("material"),
                 "paragraph_id": side[0].get("paragraph_id"),
                 "section": side[0].get("section"),
                 "page": side[0].get("page"),
                 "quote": side[1],
                 "value": side[2].get("value")} for side in sides]
    return {
        "field_id": spec.get("field_id"), "value": None, "parsed_value": None,
        "parsed_unit": None, "units": "", "statistic": None, "n": None,
        "condition": None, "comparator": None, "status": "source_conflict",
        "claim_type": "result", "quote": None,
        "source": {"material": None, "section": None, "paragraph_id": None, "page": None,
                   "table_id": None, "row": None, "col": None},
        "semantic_check": {"target_definition": spec.get("definition") or "",
                           "match": False,
                           "reason": "two or more locators give different values; both kept verbatim"},
        "conflict": conflict,
        "notes": "differing values at %d locators; both kept, no averaging" % len(sides),
        "derivation": "deterministic_regex_no_draft",
    }


def derive_one(spec, segments):
    flags = field_flags(spec)
    candidates = []
    for seg in segments:
        if not segment_candidate(spec, flags, seg):
            continue
        got = extract_from_segment(seg, spec)
        if not got:
            continue
        if unit_mismatch(spec, got["ext"]):
            continue
        score = segment_score(spec, seg, flags, got["ext"].get("units") or "")
        candidates.append((score, seg, got))
    candidates.sort(key=lambda item: (-item[0], seg_sort_key(item[1])))
    if not candidates:
        reason = ("primary field token '%s' (plus definition keywords and any specific unit "
                  "hint) was not found together with a value in the materials"
                  % (primary_token(flags["tokens"]) or "?"))
        return not_reported_field(spec, segments, reason)

    # conflict detection: two different numeric values from different locators,
    # each with the field's primary token actually present in that segment.
    # p-value and sample-size fields are excluded: multiple p/n tokens routinely
    # occur for different tests and are not a field-level conflict.
    anchor = primary_token(flags["tokens"])
    distinct = []
    seen_vals = []
    if not flags["is_p"] and not flags["is_n"]:
        for score, seg, got in candidates[:6]:
            if score < 1.0:
                continue
            if anchor and not token_in_text(anchor, (seg.get("text") or "").lower()):
                continue
            key = normalized_value(got["ext"])
            if not key:
                continue
            if key in seen_vals:
                continue
            seen_vals.append(key)
            distinct.append((seg, got))
            if len(distinct) >= 2:
                break
    if len(distinct) >= 2:
        sides = [(seg, got["quote"], got["ext"]) for seg, got in distinct]
        return conflict_field(spec, sides)

    score, seg, got = candidates[0]
    return reported_field(spec, seg, got["ext"], got["quote"], got["col"])


def derive_fields(specs, corpus):
    """Return (fields, meta). Fields follow the requested spec order."""
    all_segments = sorted(corpus.get("segments", []), key=seg_sort_key)
    # table row segments carry a table_id; a paragraph block that merely contains
    # a markdown table (pipe lines) is a container, not an evidence unit.
    segments = [seg for seg in all_segments
                if seg.get("table_id") or "|" not in (seg.get("text") or "")]
    fields = []
    for spec in specs:
        fields.append(derive_one(spec, segments))
    return fields, {
        "strategy": "deterministic no-draft derivation from /input materials",
        "segments_scanned": len(segments),
        "materials_scanned": len(corpus.get("materials", [])),
        "quote_verification": "verbatim substring by construction; re-verified with io_parse.find_quote",
        "no_fabrication": "units/statistic/condition/comparator taken only from the quote/row",
    }


def validate_and_downgrade(fields, specs, corpus, evaluate_fn, degradations):
    """Re-run mechanical checks on derived fields; downgrade any that fail."""
    spec_map = {spec.get("field_id"): spec for spec in specs}
    fails, warns = [], []
    for field in fields:
        spec = spec_map.get(field.get("field_id"))
        f_fails, f_warns = evaluate_fn(field, spec, corpus)
        if f_fails and field.get("status") == "reported":
            field["status"] = "extraction_failed"
            field["notes"] = "; ".join(f_fails)[:500]
            field["semantic_check"] = {
                "target_definition": (spec or {}).get("definition", ""),
                "match": False, "reason": "derived field failed mechanical validation"}
            degradations.append("%s downgraded: %s" % (field.get("field_id"), f_fails[0]))
        elif f_warns:
            field["validation_warnings"] = f_warns
        fails.extend(f_fails)
        warns.extend(f_warns)
    return fails, warns


def build_check_report(fields, specs, corpus, fails, warns):
    quote_total = quote_hit = 0
    counts = {}
    for field in fields:
        status = field.get("status") or "extraction_failed"
        counts[status] = counts.get(status, 0) + 1
        if status == "reported":
            quote_total += 1
            if find_quote(corpus, str(field.get("quote") or "")):
                quote_hit += 1
    hit_rate = round(quote_hit / quote_total, 4) if quote_total else 1.0
    return {
        "ok": not fails,
        "fail": fails,
        "warn": warns,
        "fields_requested": len(specs),
        "fields_in_draft": len(fields),
        "quote_total": quote_total,
        "quote_hit": quote_hit,
        "quote_hit_rate": hit_rate,
        "counts": counts,
        "derived": True,
        "note": "build derived fields directly from /input (no agent draft); mechanical checks re-run",
    }

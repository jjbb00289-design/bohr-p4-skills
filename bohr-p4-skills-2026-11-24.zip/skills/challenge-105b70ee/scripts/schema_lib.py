# -*- coding: utf-8 -*-
"""Output-contract echoing, field schema and per-field validation.

Validation is deliberately mechanical: a quote must hit the live materials, a
number must appear in its quote, statuses are closed enumerations, and an
unreported field is never treated as zero.
"""
import csv
import json
import re
from pathlib import Path

from io_parse import (CONTRACT_ALIASES, HEDGE_RE, NUM_RE, STATUS_ENUM, STATUS_TERMINAL,
                      find_quote, jload, norm_text)

def contract_keys(contract):
    if isinstance(contract, dict):
        return [str(k) for k in contract.keys()]
    if isinstance(contract, list):
        keys = []
        for item in contract:
            if isinstance(item, str):
                keys.append(item)
            elif isinstance(item, dict):
                for key in ("key", "name", "field", "field_id"):
                    if key in item:
                        keys.append(str(item[key]))
                        break
        return keys
    return []


def echo_contract(contract, base):
    """Every output_contract key must exist in result.json under its exact name."""
    base = base if isinstance(base, dict) else {}
    result = base.get("result") if isinstance(base.get("result"), dict) else {}
    final, missing = {}, []
    for key in contract_keys(contract):
        if key in base:
            final[key] = base[key]
            continue
        if key in result:
            final[key] = result[key]
            continue
        alias = CONTRACT_ALIASES.get(key)
        if alias:
            node, ok = base, True
            for part in alias:
                if isinstance(node, dict) and part in node:
                    node = node[part]
                else:
                    ok = False
                    break
            if ok:
                final[key] = node
                continue
        final[key] = None
        missing.append(key)
    final.update(base)
    final["contract_fill"] = {"contract_type": type(contract).__name__,
                              "requested_keys": contract_keys(contract),
                              "filled_null": missing}
    if missing:
        degradations = final.setdefault("degradations", [])
        if isinstance(degradations, list):
            degradations.append("output_contract keys filled as null: " + ", ".join(missing))
    return final


def read_case(input_dir):
    """Tolerant case.json read. Returns (case_dict, error_note)."""
    path = Path(input_dir) / "case.json"
    if not path.exists():
        return {}, "case.json missing"
    raw = path.read_text(encoding="utf-8-sig", errors="replace").strip()
    if not raw:
        return {}, "case.json empty"
    try:
        doc = json.loads(raw)
    except Exception as exc:
        return {}, "case.json invalid JSON: %s" % exc
    if not isinstance(doc, dict):
        return {}, "case.json is not an object"
    return doc, ""


def case_id_of(case):
    for key in ("case_id", "caseId", "id", "slug", "name"):
        value = case.get(key) if isinstance(case, dict) else None
        if isinstance(value, str) and value.strip():
            return value.strip()
    return "unknown-case"


def find_field_specs(input_dir, case):
    """Locate requested field definitions from case.json or any target-fields file."""
    for key in ("target_fields", "target-fields", "targetFields", "field_specs", "fields"):
        if isinstance(case.get(key), (list, dict)):
            return normalize_fields(case.get(key)), "case.json:" + key
    root = Path(input_dir)
    candidates = []
    try:
        files = sorted(root.rglob("*"))
    except Exception:
        files = []
    for path in files:
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        low = rel.lower()
        if low.startswith("environment/") or not low.endswith((".json", ".csv", ".tsv", ".md", ".txt")):
            continue
        if low.endswith(".json") and not ("field" in low or "target" in low):
            continue
        score = 0
        if "target" in low and "field" in low:
            score += 4
        elif "field" in low:
            score += 2
        if "target" in low:
            score += 1
        if score:
            candidates.append((score, rel, path))
    candidates.sort(key=lambda item: (-item[0], item[1]))
    for _score, rel, path in candidates:
        raw = None
        suffix = path.suffix.lower()
        try:
            if suffix == ".json":
                doc = jload(path)
                if isinstance(doc, list):
                    raw = doc
                elif isinstance(doc, dict):
                    for key in ("fields", "target_fields", "target-fields", "field_specs",
                                "extraction_targets", "targets", "items"):
                        if isinstance(doc.get(key), (list, dict)):
                            raw = doc.get(key)
                            break
            elif suffix in (".csv", ".tsv"):
                rows = list(csv.DictReader(
                    path.read_text(encoding="utf-8", errors="replace").splitlines(),
                    delimiter="," if suffix == ".csv" else "\t"))
                if rows and any(("field_id" in row or "field" in row or "id" in row)
                                for row in rows):
                    raw = rows
            elif suffix == ".md":
                rows = []
                for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
                    if line.strip().startswith("|") and line.count("|") >= 2:
                        cells = [c.strip() for c in line.strip().strip("|").split("|")]
                        if cells and re.match(r"^[A-Za-z][\w.\-]{1,40}$", cells[0]) and \
                                cells[0].lower() not in ("field_id", "field"):
                            rows.append({"field_id": cells[0],
                                         "definition": cells[1] if len(cells) > 1 else ""})
                if rows:
                    raw = rows
        except Exception:
            raw = None
        if raw:
            return normalize_fields(raw), rel
    return [], "not_found"


def normalize_fields(raw):
    items = []
    if isinstance(raw, dict):
        for key, value in raw.items():
            if isinstance(value, dict):
                item = dict(value)
                item.setdefault("field_id", key)
                items.append(item)
            else:
                items.append({"field_id": key, "definition": value if isinstance(value, str) else ""})
    elif isinstance(raw, list):
        for idx, value in enumerate(raw):
            if isinstance(value, dict):
                items.append(dict(value))
            elif isinstance(value, str):
                items.append({"field_id": value})
            else:
                items.append({"field_id": "field_%03d" % (idx + 1)})
    out = []
    for idx, item in enumerate(items):
        fid = None
        for key in ("field_id", "fieldId", "id", "key", "name", "field"):
            value = item.get(key)
            if isinstance(value, str) and value.strip():
                fid = value.strip()
                break
        out.append({
            "field_id": fid or "field_%03d" % (idx + 1),
            "definition": str(item.get("definition") or item.get("description") or
                              item.get("question") or item.get("target") or "").strip(),
            "unit_hint": str(item.get("unit") or item.get("units") or "").strip(),
            "section_hint": str(item.get("section") or item.get("source_section") or
                                item.get("where") or "").strip(),
            "kind_hint": str(item.get("type") or item.get("value_type") or "").strip(),
            "spec_raw": item,
        })
    return out


def skeleton_fields(specs):
    out = []
    for spec in specs:
        out.append({
            "field_id": spec["field_id"], "value": None, "parsed_value": None,
            "parsed_unit": None, "units": spec.get("unit_hint") or None, "statistic": None,
            "n": None, "condition": None, "comparator": None, "status": "pending",
            "quote": None,
            "source": {"material": None, "section": None, "paragraph_id": None, "page": None,
                       "table_id": None, "row": None, "col": None},
            "semantic_check": {"target_definition": spec.get("definition") or "",
                               "match": None, "reason": "not yet extracted"},
            "claim_type": None, "notes": "awaiting agent extraction",
        })
    return out


def coverage_of(fields, requested_ids):
    counts = {"reported": 0, "not_reported": 0, "source_conflict": 0,
              "extraction_failed": 0, "pending": 0}
    seen = []
    for field in fields:
        status = field.get("status") if isinstance(field, dict) else None
        counts[status if status in counts else "extraction_failed"] += 1
        fid = field.get("field_id") if isinstance(field, dict) else None
        if fid:
            seen.append(fid)
    missing = [fid for fid in requested_ids if fid not in seen]
    return {
        "required": len(requested_ids),
        "extracted": counts["reported"] + counts["not_reported"] + counts["source_conflict"],
        "reported": counts["reported"], "not_reported": counts["not_reported"],
        "source_conflict": counts["source_conflict"],
        "extraction_failed": counts["extraction_failed"] + counts["pending"],
        "pending": counts["pending"], "missing_field_ids": missing,
        "complete": bool(requested_ids) and not missing and counts["pending"] == 0
                    and counts["extraction_failed"] == 0,
    }


def load_draft(work):
    """Read <work>/draft.json tolerantly. Returns (dict|None, note)."""
    path = Path(work) / "draft.json"
    if not path.exists():
        return None, "draft.json missing"
    raw = path.read_text(encoding="utf-8-sig", errors="replace").strip()
    if not raw:
        return None, "draft.json empty"
    try:
        doc = json.loads(raw)
    except Exception as exc:
        return None, "draft.json invalid JSON: %s" % exc
    if not isinstance(doc, dict):
        return None, "draft.json must be an object"
    return doc, ""


def draft_fields(draft):
    if not isinstance(draft, dict):
        return []
    for key in ("fields", "extracted_fields", "extraction", "results"):
        value = draft.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]
    return []


def numeric_tokens(text):
    return [(tok.strip(), tok.replace(" ", "").replace("−", "-")) for tok in NUM_RE.findall(text or "")
            if re.search(r"\d", tok)]


def normalize_field(field, spec):
    """Expose the full extraction schema for one draft field, keeping agent extras."""
    out = {
        "field_id": field.get("field_id") or (spec or {}).get("field_id"),
        "value": field.get("value"),
        "parsed_value": field.get("parsed_value"),
        "parsed_unit": field.get("parsed_unit") or field.get("unit"),
        "units": field.get("units") or field.get("unit") or (spec or {}).get("unit_hint"),
        "statistic": field.get("statistic"), "n": field.get("n"),
        "condition": field.get("condition") or field.get("experimental_condition"),
        "comparator": field.get("comparator") or field.get("comparison"),
        "status": field.get("status") or "extraction_failed",
        "quote": field.get("quote") or field.get("evidence_quote"),
        "source": field.get("source") if isinstance(field.get("source"), dict) else {},
        "semantic_check": field.get("semantic_check") if isinstance(field.get("semantic_check"), dict) else {},
        "claim_type": field.get("claim_type"),
        "notes": field.get("notes") or field.get("reason"),
    }
    for extra in ("sub_claims", "conflict", "search_attempts", "hedge", "precision"):
        if extra in field:
            out[extra] = field[extra]
    return out


def evaluate_field(field, spec, corpus):
    """Mechanical checks for one extracted field: returns (fails, warns)."""
    fid = field.get("field_id") or "?"
    fails, warns = [], []
    status = field.get("status")
    if status not in STATUS_ENUM:
        return ["%s: status '%s' not in %s" % (fid, status, "/".join(STATUS_ENUM))], warns
    quote = str(field.get("quote") or "").strip()
    hits = find_quote(corpus, quote) if quote else []
    if status == "reported":
        if field.get("value") is None or str(field.get("value")).strip() == "":
            fails.append("%s: reported but value empty" % fid)
        if len(quote) < 6:
            fails.append("%s: reported but quote missing/too short" % fid)
        elif not hits:
            fails.append("%s: quote not found verbatim in any material" % fid)
        else:
            src = field.get("source") or {}
            declared, declared_pid = src.get("material"), src.get("paragraph_id")
            if not declared:
                fails.append("%s: reported but source.material missing" % fid)
            elif not [hit for hit in hits if hit["material"] == declared]:
                fails.append("%s: declared material '%s' does not contain the quote (found in %s)"
                             % (fid, declared, sorted({hit["material"] for hit in hits})))
            elif declared_pid and not any(hit["paragraph_id"] == declared_pid or
                                          hit["paragraph_id"].startswith(str(declared_pid))
                                          for hit in hits):
                warns.append("%s: declared paragraph_id '%s' differs from quote hit %s"
                             % (fid, declared_pid, sorted({hit["paragraph_id"] for hit in hits})))
            if not declared_pid and not src.get("page") and not src.get("table_id"):
                warns.append("%s: locator lacks paragraph_id/page/table_id" % fid)
        value_text = str(field.get("value") or "")
        for raw_tok, cmp_tok in numeric_tokens(value_text):
            flat = quote.replace(" ", "").replace("−", "-")
            if cmp_tok.lstrip("+-") in flat.lstrip("+-") or raw_tok in quote:
                continue
            fails.append("%s: value number '%s' is not present in the quote (possible fabrication)"
                         % (fid, raw_tok))
        unit = field.get("units") or field.get("parsed_unit")
        if unit and str(unit).strip() and not re.fullmatch(r"[A-Za-z ]+", str(unit).strip()) \
                and norm_text(str(unit)) not in norm_text(quote):
            warns.append("%s: unit '%s' not found in quote; check the table header or adjacent text"
                         % (fid, unit))
        check = field.get("semantic_check") or {}
        if not isinstance(check, dict) or check.get("match") is None:
            warns.append("%s: semantic_check.match missing (target definition vs quoted text)" % fid)
        if HEDGE_RE.search(quote) and (field.get("claim_type") or "") == "conclusion":
            warns.append("%s: hedged wording quoted but claim_type=conclusion; keep the hedge" % fid)
    elif status == "not_reported":
        if field.get("value") not in (None, ""):
            fails.append("%s: not_reported must not carry a value (unreported is not zero)" % fid)
        if not (field.get("search_attempts") or field.get("notes")):
            warns.append("%s: not_reported without search_attempts/notes" % fid)
    elif status == "source_conflict":
        conflict = field.get("conflict")
        if not isinstance(conflict, list) or len(conflict) < 2:
            fails.append("%s: source_conflict needs conflict[] with >=2 located sides" % fid)
        else:
            for idx, side in enumerate(conflict):
                if not isinstance(side, dict):
                    fails.append("%s: conflict[%d] must be an object" % (fid, idx))
                elif not find_quote(corpus, str(side.get("quote") or "")):
                    fails.append("%s: conflict[%d] quote not found in materials" % (fid, idx))
    if spec and spec.get("field_id") and spec["field_id"] != fid:
        fails.append("%s: field_id mismatch with requested spec" % fid)
    return fails, warns


def material_sources(corpus):
    return [{"material": mat["material"], "kind": mat["kind"], "bytes": mat["bytes"],
             "sha256": mat.get("sha256", ""), "text_method": mat.get("text_method"),
             "segments": mat.get("segments", 0), "tables": mat.get("tables", 0)}
            for mat in corpus.get("materials", [])]


def base_result(case, corpus, specs, status, fields, claims, uncertainties,
                pending_human, errors, degradations, extra=None):
    cid = case_id_of(case)
    result = {
        "fields": fields,
        "coverage": coverage_of(fields, [spec["field_id"] for spec in specs]),
        "field_dictionary": {
            "fields": [{key: spec.get(key) for key in
                        ("field_id", "definition", "unit_hint", "section_hint", "kind_hint")}
                       for spec in specs],
            "status_semantics": {
                "reported": "raw value present at the cited locator",
                "not_reported": "searched, but the source does not report this field",
                "source_conflict": "two or more locators disagree; both kept verbatim",
                "extraction_failed": "not extracted, or locator/quote failed verification",
                "pending": "init placeholder before the agent draft",
            },
            "rules": [
                "value keeps the source literal (range, ± SD, n=, p< and significance words)",
                "parsed_value/parsed_unit never replace the literal value",
                "each reported field needs an exact verbatim quote and a locator",
                "unreported is not zero; a guessed value is not extraction",
            ],
        },
        "method_notes": {
            "pipeline": "init -> show -> agent draft (or deterministic no-draft derive) -> check -> build",
            "quote_matching": "exact substring first, then whitespace/curly-quote normalised match",
            "evidence_unit": "paragraph or table row; locator = material + paragraph_id/page/table row",
        },
    }
    if extra:
        result.update(extra)
    return {
        "case_id": cid, "status": status, "result": result, "claims": claims,
        "uncertainties": uncertainties, "sources": material_sources(corpus),
        "pending_human": pending_human, "errors": errors, "degradations": degradations,
        "deliverables": {"index": "work/index.json", "draft": "work/draft.json",
                         "extraction_table": "extraction_table.csv",
                         "report": "field_report.md",
                         "field_dictionary": "field_dictionary.json"},
        "input": {"case_file": "case.json"},
    }

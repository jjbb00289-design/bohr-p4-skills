---
name: literature-field-extractor
description: Extract requested fields (findings, experimental conditions, key data points) from scientific papers and tables into one auditable field table, keeping literal values, units, statistics, conditions, comparators and a verbatim quote plus locator per field. Use when a paper, PDF or table set must be turned into a structured, re-checkable extraction result rather than a summary.
version: 1.1.0
---

# 文献结论与数据提取（literature-field-extractor）

把散落在正文、表格、图注里的结论与数据，按 `target-fields` 的字段表还原成可核对、可复用的结构：
**一个 field_id 一条结果，每条都带原文字面值、单位、统计量、实验条件、对照物、逐字引文与定位。**

## 1. 何时使用 / 何时不用

适用：
- 输入是论文（PDF / Markdown / 纯文本 / XML）、表格（CSV/TSV/Markdown 表）与一份字段清单（`target-fields.json`）。
- 任务要求"按统一字段表抽取结论、实验条件、关键数值，并给出可复核的证据位置"。
- 需要区分"原文明确报告 / 原文未报告 / 来源互相冲突 / 抽取失败"。

不适用：自由摘要、文献综述写作、只要求回答一段话而不要求字段级证据的任务。

## 2. 硬性事实（先读，决定成败）

1. **契约在运行时才知道**：`/input/case.json` 的 `output_contract` 可能包含任意键名。**它的每个键都必须原样出现在 `/app/output/result.json`**；本 Skill 的 `build` 会逐键回填（缺值写 `null` 并记入 `degradations`），不要手写契约、不要改名。
2. **字段清单优先于自由发挥**：逐条枚举 `/input/target-fields.json`（或 `case.json` 中的 `target_fields` / `target_fields` 列表）里的 `field_id`；**请求几个字段就输出几条**，不漏、不合并、不擅自加字段。
3. **`case_id` 必须与输入一致**，不能丢。
4. **状态唯一四态**：`reported` / `not_reported` / `source_conflict` / `extraction_failed`。初始骨架另有 `pending`（仅 init 阶段），最终结果不应残留 `pending`。
5. **禁止编造**：材料里没有的值不填、不换算、不按常识补全；`not_reported` 不是 0；`source_conflict` 必须保留双方原话。

## 3. 五命令主路径（必须按顺序执行）

```bash
python3 scripts/main.py init      # 扫 /input：材料、段落、表格行索引；先写 partial result.json
python3 scripts/main.py show      # 打印带 locator 的原文（引文从这里逐字复制）
#   你现在必须亲自读材料，写 /app/work/draft.json（schema 见第 4 节）
python3 scripts/main.py check     # 机械校验：字段齐、状态合法、quote 逐字命中、数字在引文内
python3 scripts/main.py build     # 组装 result.json + extraction_table.csv + field_report.md + field_dictionary.json
python3 scripts/main.py selfcheck # 复查成品：契约键、case_id、quote 复验、计数自洽
```

默认路径 `/input`、`/app/work`、`/app/output`；本地可加 `--input/--work/--output`。
**先读材料再写工作稿会得到最高质量；但脚本现在也具备确定性的无稿回退（DERIVED_PATTERN）：**
即使 `init → build` 之间没有写 `draft.json`，`build` 也会直接、确定性地从 `/input` 材料推导出逐字段结果
（读 `target-fields.json`，按固定顺序检索所有段落/表格行，抽取数值+单位、同一句/同一行内的 `statistic`/`condition`/`comparator`，
用逐字子串作 `quote`，并给出 `reported / not_reported / source_conflict / extraction_failed` 四态）。
**这不再是骨架**：`build` 的 `result.json` 会带有真实的 per-field 结果、`coverage` 计数与 `field_dictionary`。
工作稿存在且有效时仍走工作稿路径（更高精度），并对工作稿漏掉的字段用同一 derive 回填。

## 4. 工作稿 schema：`/app/work/draft.json`

```json
{
  "case_id": "<与输入一致>",
  "fields": [
    {
      "field_id": "body_weight_change_treated",
      "value": "-4.2 ± 1.1 g",
      "parsed_value": -4.2,
      "parsed_unit": "g",
      "units": "g",
      "statistic": "mean ± SD",
      "n": 8,
      "condition": "day 28, compound X 10 mg/kg oral once daily for 28 days",
      "comparator": "vehicle group",
      "status": "reported",
      "claim_type": "result | conclusion | limitation | speculation",
      "quote": "逐字复制自材料的一段话，包含值、单位与条件",
      "source": {"material": "materials/paper.md", "section": "Results",
                 "paragraph_id": "P005", "page": null,
                 "table_id": null, "row": null, "col": null},
      "semantic_check": {"target_definition": "字段定义", "match": true,
                         "reason": "为什么这段引文在语义上真的回答了这个字段"},
      "notes": "可选"
    }
  ],
  "uncertainties": [{"kind": "...", "detail": "..."}],
  "pending_human": ["需要人工确认的点"]
}
```

规则：
- `value` **保留原文字面**（范围、`±`、`n=`、`p<0.05`、`<0.001`、百分号、单位大小写都不改写）；`parsed_value/parsed_unit` 只是补充，**不得替换字面值**；换算另写 `conversion` 并把原值留在 `value`。
- `quote` 必须**逐字**来自材料（`show` 输出的文本）；不得翻译、拼接、改标点、补省略号。
- `source` 至少给 `material` + (`paragraph_id` 或 `page` 或 `table_id`+`row`)；表格行用 show 里的 `T1:R2` 形式。
- 表格：跨页/合并单元格时，把表头与行一起写进 quote，或把列含义写进 `notes`；不要只抄数字。
- `status=not_reported`：`value` 留 `null`，在 `search_attempts` 或 `notes` 写清"查过哪里、为什么没有"。
- `status=source_conflict`：`conflict` 数组至少两项，每项带 `material`/`paragraph_id`/`quote`，双方原话都保留。
- 结论类字段用 `claim_type` 标层级：`may/suggest/indicate/possibly` 等 hedge 词必须保留在 `value`/`quote` 里，不得升格为确定结论。

## 5. 状态语义（判定口径，全包统一）

| 状态 | 含义 | 判定 |
|---|---|---|
| `reported` | 原文明确报告了该字段 | 有值 + 逐字 quote + locator + 语义检查通过 |
| `not_reported` | 已检索全文，原文没有报告该字段 | 值留 null；写检索范围；**不是 0，不是缺省值** |
| `source_conflict` | 两个及以上位置给出不一致的值/表述 | 双方 quote 都保留，说明差异来源，不取平均 |
| `extraction_failed` | 无法抽取或证据校验失败 | 写出失败原因与人工接管点 |

`check` 会把"quote 不命中 / 数字不在 quote 内 / 状态非法 / 字段缺失"报 FAIL；`build` 会把 FAIL 的 `reported` 字段降级为 `extraction_failed` 并写入 `degradations`，**保证不把猜测当抽取**。

## 6. 证据与保真规则

1. 证据单位 = 段落或表格行。locator 要能让他人独立抽查：`material` + `paragraph_id`（或 `page` / `table_id`+`row`）。
2. 数字保真：值里的每个数字都必须能在 quote 中找到（`check` 机械比对）。`1,000`、`10^3`、`×10⁻³` 保持原文写法。
3. 单位保真：单位写在 `value`/`units`，且必须在 quote 或紧邻表头出现；`mV` 不是 `V`，`µg/mL` 不是 `mg/mL`。
4. 条件与数值同源：`condition`、`comparator`、`statistic` 必须来自同一句/同一行，禁止把 A 表的均值配 B 组的条件。
5. 结论分层：明确结论 / 限制条件 / 推测性表述用 `claim_type` 区分；hedge 词保留。
6. 图注与补充材料也是正式来源：分别用 `section`/`material` 标注；图像无文本层时记 `extraction_failed` 或 `pending_human`（需要 OCR），不猜读。

## 7. `check` 做什么、会拦什么

- 请求的每个 `field_id` 是否都有条目（漏 = FAIL），是否有重复/未请求条目（重复 = FAIL）。
- `status` 是否在四态枚举内。
- `reported`：`value` 非空、`quote` ≥6 字符且在材料中**逐字命中**、`source.material` 存在、值内数字能在 quote 中找到（缺失 = WARN，需人工确认）。
- `not_reported`：是否写了检索范围（缺失 = WARN）。
- `source_conflict`：`conflict[]` 是否 ≥2 项且每条 quote 都能命中（不满足 = FAIL）。
- 产出 `work/check_report.json`，`build` 只以它为放行依据。

## 8. 产物（`/app/output/`）

| 文件 | 内容 |
|---|---|
| `result.json` | 契约回填 + `result.fields[]` + `coverage` + `claims`（逐字段证据链）+ `uncertainties` + `sources` + `degradations` |
| `extraction_table.csv` | 字段×值×单位×统计量×条件×对照×状态×locator×quote 的可编辑表 |
| `field_report.md` | 人读报告：覆盖计数、逐字段表、未报告/冲突、方法说明、降级记录 |
| `field_dictionary.json` | 字段表与抽取口径（他人可按同一规则复跑） |

`result.json` 的 `result.coverage` 由脚本按行数统计，**不要手填**：`required/extracted/reported/not_reported/source_conflict/extraction_failed/missing_field_ids/complete`。

## 9. 降级与异常处理

| 情况 | 行为 |
|---|---|
| 无 `draft.json` / 工作稿坏 | `build` 走 DERIVED_PATTERN：从材料确定性推导 per-field 结果，逐字段 `reported/not_reported/source_conflict`（含 `search_attempts`/`conflict[]`），写 `degradations` 说明"无稿回退" |
| `case.json` 坏 / 空 `/input` | `status=input_error`，仍写合法 `result.json` 与契约键 |
| 只有 case.json、没有材料 | `status=insufficient_evidence`，不编造任何字段值 |
| 字段清单缺失 | `degradations` 记录，`pending_human` 提示补 `target-fields.json` |
| PDF 无文本层 / 图片 | 记录 `no_text_layer`/`no_ocr_in_skill`，需要 OCR 时列入 `pending_human` |
| 单个字段失败 | 其余字段照常输出，逐字段隔离，不拖垮整包 |

所有命令退出码恒为 0；顶层异常会触发 `emergency_finalize()` 写合法 partial 结果。

## 10. 提交前自检清单

- [ ] `init` 后 `/app/output/result.json` 已存在，契约键齐全，`case_id` 正确。
- [ ] 每个请求 `field_id` 恰好一条；`pending` 已清零。
- [ ] 每条 `reported` 的 quote 都能在材料中逐字命中；数字在 quote 内；单位在 quote 或表头。
- [ ] `not_reported` 有检索范围说明；`source_conflict` 双方原话都在。
- [ ] `check` 无 FAIL；`build` 后 `status` 与实情一致（全字段终态且校验通过 = `ok`）。
- [ ] 四个产物都存在且非空；`extraction_table.csv` 能用表格软件打开。
- [ ] 空输入 / 坏 JSON / 缺材料 / 无工作稿四种情况都仍 exit 0 且产出合法 partial 结果。

## 11. 最小调用示例（示例，非正式案例结果）

材料（`materials/paper.md`，节选）：

```
[P005] At day 28, body weight change was -4.2 ± 1.1 g in the compound X group versus +1.8 ± 0.9 g in the vehicle group (p < 0.001).
```

`target-fields.json` 请求 `body_weight_change_treated`；工作稿写：

```json
{"field_id": "body_weight_change_treated", "value": "-4.2 ± 1.1 g", "units": "g",
 "statistic": "mean ± SD", "condition": "day 28", "comparator": "vehicle group",
 "status": "reported", "quote": "At day 28, body weight change was -4.2 ± 1.1 g in the compound X group versus +1.8 ± 0.9 g in the vehicle group (p < 0.001).",
 "source": {"material": "materials/paper.md", "section": "Results", "paragraph_id": "P005"},
 "semantic_check": {"target_definition": "treated group body weight change", "match": true, "reason": "same group and endpoint"}}
```

`build` 后 `result.json` 中该字段即为 `reported`，并带 `claims[0].evidence[0].quote` 与 locator。
**以上为示例（合成数据），非任何正式案例结果。**

## 12. 版本与维护

- 版本：1.1.0；包名 `literature-field-extractor`。
- 依赖：Python 3.8+ 标准库；不联网；不依赖 CWD；无第三方包。
- 修改指引：字段 schema 在 `scripts/schema_lib.py`（`normalize_field/evaluate_field`），材料解析在 `scripts/io_parse.py`，无稿推导在 `scripts/derive_lib.py`（`derive_fields/derive_one`），流程在 `scripts/main.py`；改完必须重跑 `--help`、`init`、`check`、`build`、`selfcheck` 与四态降级测试。
- 适用范围与限制：文本型 PDF/纯文本/Markdown/CSV 表格最佳；扫描件需外部 OCR；图内数据点无法自动读取时如实记 `extraction_failed`。

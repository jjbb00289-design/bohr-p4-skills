# 抽取质检清单与失败模式

本文件用于 `check` 前的自检与复核他人的抽取结果。每条都对应一个可机械或半机械判定的动作。

## 1. 逐字段十问

1. **字段对齐**：这段引文真的回答 `field_id` 的定义吗？还是"主题相关"？语义检查写进 `semantic_check.reason`。
2. **值保真**：`value` 与原文逐字符一致吗？范围、`±`、`<`、`%`、`n=`、大小写、上标都没改吗？
3. **数字在场**：`value` 里每个数字都能在 `quote` 中找到吗？（`check` 会逐 token 比对）
4. **单位在场**：单位在 quote 或紧邻表头出现吗？`µg` 与 `mg`、`/mL` 与 `/L`、`mV` 与 `V` 没有混。
5. **条件同源**：`condition`（时间点/剂量/分组/批次）与值来自同一句或同一行吗？有没有把 A 组条件配到 B 组数值？
6. **统计量**：均值/中位数/误差类型（SD/SEM/95%CI）标清了吗？有没有把 SEM 当 SD？
7. **对照物**：`comparator` 写清了吗（vehicle / baseline / sham / 另一剂量）？
8. **样本量**：`n` 与原文一致吗（per group vs total）？
9. **层级**：`claim_type` 是 `result` / `conclusion` / `limitation` / `speculation`？hedge 词还在吗？
10. **定位可复核**：第二个人拿 `source` 能直接翻到这一句/这一行吗？

## 2. 状态判定决策树

```text
材料里有该字段的明确表述？
├─ 有，且能用一段逐字引文支撑 → reported（写 value+quote+locator+semantic_check）
├─ 有，但两处及以上数值/表述不一致 → source_conflict（双方 quote 都保留，不取平均、不选一方）
├─ 没有，但已检索全文（正文/表/图注/补充材料）→ not_reported（值 null，写检索范围）
└─ 无法判断（图像无文本层、公式不可读、材料缺失、引文校验失败） → extraction_failed（写原因与人工接管点）
```

判定口径：
- `not_reported` **不是** 0、不是 "N/A 值"、不是缺省默认值。
- "相关但更弱/更强"不等于 reported：引文必须能推出该字段的断言；否则降级 `extraction_failed` 或按语义写 `notes`。
- 转录/二手引用：优先原始表格或结果段；只能拿到二手表述时在 `notes` 标注"secondary citation"。

## 3. 高频失败模式（出现即返工）

| 失败模式 | 表现 | 修法 |
|---|---|---|
| 猜值补全 | 原文没有却填了"合理值" | 改 `not_reported`/`extraction_failed`，写检索范围 |
| 数值与条件错配 | 均值来自表 1、条件来自表 2 | 值与条件从同一句/同一行取 |
| 单位静默统一 | mV 当 V、µM 当 mM、% 当比例 | 保留原文单位，换算另存 |
| 引文改写 | quote 被翻译/拼接/加省略号 | 从 `show` 输出逐字复制 |
| 裸数字 | 只抄了单元格数字 | quote 带上行与表头，或把列义写进 notes |
| hedge 升格 | "may indicate" 写成 "proves" | 保留原词，`claim_type=speculation/conclusion` 分层 |
| 跨页表丢列 | 只取到后半页行 | 用表头+行拼接，跨页处注明 |
| 缺字段省略 | 请求 8 个只交 6 个 | 缺的也要有条目（not_reported/extraction_failed） |
| 冲突掩盖 | 两个值取其一或平均 | 改 `source_conflict`，双方原话并列 |

## 4. 结论 / 限制 / 推测的分层词表

- 推断词（必须保留）：may, might, could, suggest(s), indicate(s), possibly, likely, probably, potentially, appears to, seems to, is consistent with；中文：可能、或许、提示、推测、倾向于、有望。
- 限制词（应抽为 `claim_type=limitation`）：limitation, limited by, only, small sample, single center, not measured, cannot exclude, remains uncertain；中文：局限、仅、未测量、无法排除、尚不确定。
- 明确结论（`conclusion`）：we conclude / these results demonstrate / significantly (p<...)；中文：结论、证明、显著。

## 5. 复核他人的抽取（第二人视角）

1. 抽 3 条 `reported`：按 `source` 翻原文，核对 quote 是否逐字、值是否原样、条件是否同源。
2. 抽 1 条 `not_reported`：确认原文确实没有该字段（防漏检）。
3. 抽 1 条 `source_conflict`：确认两侧原话都在、没有擅自仲裁。
4. 看 `coverage` 计数是否等于 `fields[]` 行数、`missing_field_ids` 是否为空。
5. 看 `degradations`/`uncertainties` 是否把缺口说清，而不是用 `ok` 掩盖。

## 6. 提交前命令级检查

```bash
python3 scripts/main.py check && python3 scripts/main.py build && python3 scripts/main.py selfcheck
```

期望：`check` 无 FAIL；`build` 四件产物非空、`status` 与实情一致；`selfcheck` 契约键零缺失、quote 全部复验通过。

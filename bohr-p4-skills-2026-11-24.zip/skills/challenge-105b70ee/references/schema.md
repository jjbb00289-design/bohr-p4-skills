# 字段抽取 schema 与契约回填细则

本文件是 `SKILL.md` 第 4、8 节的字段级补充。所有键名与枚举按本文口径，脚本与文档必须一致。

## 1. 输入侧文件

| 文件 | 必需 | 说明 |
|---|---|---|
| `/input/case.json` | 通常有 | 至少含 `case_id` 与 `output_contract`；可能有 `task_instruction`、`target_fields` |
| `/input/target-fields.json` | 视案例 | 字段清单。也接受 `{fields:[...]}`、直接数组、CSV/Markdown 表；`field_id` 也可写成 `id/key/name` |
| 材料 | 是 | PDF / MD / TXT / XML / CSV / TSV；图片需 OCR，脚本不猜读 |
| `/input/task.md` | 是 | 任务说明，不作为抽取证据来源 |

字段清单里每个条目可能带：`field_id`、`definition/description/question`、`unit/units`、`section/source_section`、`type`。
`init` 会把它们归一成 `work/index.json` 的 `specs`，并生成 `work/fields_skeleton.json`。

## 2. 输出侧 `result.json`

```text
result.json
├─ case_id            (原样，必须与输入一致)
├─ status             ok | partial | insufficient_evidence | input_error
├─ result
│  ├─ fields[]        每条 = 一个 field_id 的抽取结果（见下）
│  ├─ coverage        required/extracted/reported/not_reported/source_conflict/
│  │                  extraction_failed/pending/missing_field_ids/complete
│  ├─ field_dictionary 字段定义 + 状态语义 + 抽取规则
│  └─ method_notes    流程、quote 匹配口径、证据单位
├─ claims[]           每个 reported 字段一条证据链（claim_id/text/kind/evidence/conditions/comparator）
├─ uncertainties[]    not_reported / source_conflict / extraction_failed 的逐条说明
├─ sources[]          材料清单（material/kind/bytes/sha256/text_method/segments/tables）
├─ pending_human[]    需要人工确认或补料的事项
├─ errors[]           输入/流程错误
├─ degradations[]     所有降级与缺口（含契约键回填为 null 的记录）
├─ deliverables       产物相对路径
├─ input              输入标识
└─ contract_fill      契约类型、请求键、被回填为 null 的键
```

### 2.1 `fields[]` 单条结构

| 键 | 类型 | 要求 |
|---|---|---|
| `field_id` | str | 与字段清单完全一致 |
| `value` | any | 原文字面值；`not_reported` 时 `null` |
| `parsed_value` / `parsed_unit` | number/str | 可选补充，绝不替换 `value` |
| `units` | str | 原文单位；无量纲写 `""` |
| `statistic` | str | 如 `mean ± SD`、`median (IQR)`、`p < 0.001 (as reported)` |
| `n` | int | 样本量（如原文给出） |
| `condition` | str | 该值成立的条件（时间点、剂量、分组、批次等） |
| `comparator` | str | 对照物/比较基线 |
| `status` | enum | `reported/not_reported/source_conflict/extraction_failed` |
| `claim_type` | enum | `result/conclusion/limitation/speculation`（可选） |
| `quote` | str | 逐字引文；`reported` 必填 |
| `source` | object | `material` + `paragraph_id`/`page`/`table_id`+`row`（`col`、`char_start/char_end` 可选） |
| `semantic_check` | object | `target_definition`（字段定义）、`match`（bool）、`reason`（为什么引文真的回答该字段） |
| `conflict` | array | 仅 `source_conflict`：≥2 项，每项带 `material/paragraph_id/quote` |
| `search_attempts` | array | 仅 `not_reported`：检索过的位置 |
| `notes` | str | 失败原因、降级说明、人工接管点 |

## 3. 契约回填（`echo_contract`）

1. 运行时从 `case.json` 读 `output_contract`；支持 dict（键集合）与 list（字符串或带 `key/name/field_id` 的条目）。
2. 每个契约键**精确匹配**（禁止子串匹配）：先查 `result.json` 顶层，再查 `result` 内部，再按别名表（`fields→result.fields`、`coverage→result.coverage`、`evidence→claims` 等）。
3. 都找不到时写 `null`，并把键名记入 `degradations` 的 `output_contract keys filled as null: ...`。
4. `contract_fill` 字段自证回填结果，供复核。
5. `case_id`、`status` 永不省略；`status` 与实情一致，不用 `ok` 掩盖缺口。

## 4. 定位约定

| 来源 | locator 写法 | 例 |
|---|---|---|
| 带编号段落 | `paragraph_id` = 材料自带编号（保留原写法） | `P005` |
| 无编号文本 | `paragraph_id` = 脚本派生稳定编号 | `P0007` |
| 表格行 | `table_id` + `row`（0 基），`paragraph_id` 用 `T1:R2` | `T1` / `2` |
| PDF 页 | `page` = 物理页号（1 基） | `page: 4` |
| 图注/补充材料 | `material` + `section`/`figure`/`table_id` | `supplement.md` |

跨页表格：quote 里同时带表头行与该数据行，或把表头文字写进 `notes`；不要只留裸数字。

## 5. 覆盖计数口径

- `required`：字段清单条目数。
- `extracted`：`reported + not_reported + source_conflict`。
- `extraction_failed`：抽取失败 + 残留 `pending`。
- `missing_field_ids`：清单里有、结果里没有的 `field_id`。
- `complete`：`required>0` 且无缺失、无 pending、无 extraction_failed。

计数由脚本按 `fields[]` 行重算，不读工作稿里手写的计数。

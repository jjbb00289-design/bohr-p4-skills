# -*- coding: utf-8 -*-
"""Deterministic pure-stdlib figure renderer: scene -> SVG / PNG / PDF."""
import math, struct, zlib

W, H = 1000, 700
SCALE = 2
_ASCII = ("000000000000005f00000007000700147f147f14242a7f2a12231308646236495522500005030000001c2241000041221c0014083e081408083e080800503000000808080808006060000020100804023e5149453e00427f400042615149462141454b311814127f1027454545393c4a49493001710905033649494936064949291e003636000000563600000814224100141414141400412214080201510906324979413e7e1111117e7f494949363e414141227f4141221c7f494949417f090909013e4149497a7f0808087f00417f41002040413f017f081422417f404040407f020c027f7f0408107f3e4141413e7f090909063e4151215e7f09192946464949493101017f01013f4040403f1f2040201f3f4038403f631408146307087008076151494543007f41410002040810200041417f0004020102044040404040000102040020545454787f484444383844444420384444487f3854545418087e0901020c5252523e7f0804047800447d40002040403d007f1028440000417f40007c041804787c0804047838444444387c14141408081414187c7c080404084854545420043f4440203c4040207c1c2040201c3c4030403c44281028440c5050503c4464544c44000836410000007f0000004136080008082a1c08")
_EX = "\u00b5\u00d7\u00b1\u00b0\u00b2\u00b3\u00b7"
_EXH = "2044442478221408142208083e0808060909060022424a36002141453b000018180000"

def _mkfont():
    d = {}
    for i in range(95):
        g = _ASCII[i*10:i*10+10]
        d[chr(32+i)] = tuple(int(g[j*2:j*2+2], 16) for j in range(5))
    for i, ch in enumerate(_EX):
        g = _EXH[i*10:i*10+10]
        d[ch] = tuple(int(g[j*2:j*2+2], 16) for j in range(5))
    return d
_F = _mkfont()

PALETTE = ["#1f77b4","#d62728","#2ca02c","#ff7f0e","#9467bd","#8c564b","#17becf","#e377c2","#7f7f7f","#bcbd22"]
PANEL_COLOR = {"input":"#deebf7","mechanism":"#e2efda","outcome":"#fde9d9"}
PANEL_LABEL = {"input":"Input","mechanism":"Mechanism","outcome":"Outcome"}
REL_STYLE = {"activation":(None,"arrow"),"inhibition":(None,"tee"),"binding":(None,"none"),
 "modification":("6,4","arrow"),"transport":("2,3","arrow"),"transformation":("6,4","arrow"),
 "composition":(None,"none"),"association":("2,3","none")}
REL_COLOR = {"activation":"#d62728","inhibition":"#1f77b4","binding":"#2ca02c",
 "modification":"#9467bd","transport":"#ff7f0e","transformation":"#8c564b",
 "composition":"#17becf","association":"#7f7f7f"}

def _hex(c):
    return (int(c[1:3],16),int(c[3:5],16),int(c[5:7],16)) if isinstance(c,str) and c.startswith("#") and len(c)==7 else (0,0,0)

def build_scene(model, w=W, h=H):
    if model.get("kind") == "chart":
        return _chart(model, w, h)
    sc = [{"t":"text","x":w/2,"y":34,"s":model.get("title","") or "Scientific schematic","fs":22,"align":"middle","bold":True,"fill":"#111","anchor":"middle"}]
    panels = model.get("panels",[]); entities = model.get("entities",[]); relations = model.get("relations",[])
    colw, gap = 280, 18
    xs = [40, 40+colw+gap, 40+2*(colw+gap)]
    pspec = [{"id":p["id"],"x":(xs[i] if i < 3 else xs[2]),"y":70,"w":colw,"h":h-150,
              "label":p.get("label",PANEL_LABEL.get(p["id"],p["id"]))} for i,p in enumerate(panels)]
    for ps in pspec:
        sc.append({"t":"rect","id":"panel-%s"%ps["id"],"x":ps["x"],"y":ps["y"],"w":ps["w"],"h":ps["h"],
                   "fill":PANEL_COLOR.get(ps["id"],"#f4f4f4"),"stroke":"#999","sw":1.2,"rx":8})
        sc.append({"t":"text","id":"panel-label-%s"%ps["id"],"x":ps["x"]+ps["w"]/2,"y":ps["y"]+24,"s":ps["label"],"fs":16,"align":"middle","bold":True,"fill":"#333","anchor":"middle"})
    pent = {p["id"]:[e for e in entities if e.get("panel","")==p["id"]] for p in panels}
    pos = {}
    for p in panels:
        lst = pent.get(p["id"],[])
        px = next((ps["x"] for ps in pspec if ps["id"]==p["id"]), 40)
        step = min(78, (h-150-50)/max(1,len(lst)))
        for j,e in enumerate(lst):
            cx = px+colw/2; cy = 70+44+step/2+j*step
            nw = min(220, colw-20); nh = 40
            pos[e["id"]] = (cx,cy,nw,nh); pos[e.get("label", e["id"])] = (cx,cy,nw,nh)
            fill = e.get("color") or PALETTE[0]
            sc.append({"t":"rect","id":"entity-%s"%e["id"],"x":cx-nw/2,"y":cy-nh/2,"w":nw,"h":nh,"fill":fill,"stroke":"#333","sw":1.4,"rx":6})
            sc.append({"t":"text","id":"entity-label-%s"%e["id"],"x":cx,"y":cy+5,"s":e.get("label",e["id"]),"fs":14,"align":"middle","fill":"#fff","bold":True,"anchor":"middle"})
            if e.get("type"):
                sc.append({"t":"text","id":"entity-type-%s"%e["id"],"x":cx,"y":cy+nh/2-4,"s":e["type"],"fs":9,"align":"middle","fill":"#e8e8e8","anchor":"middle"})
    for r in relations:
        a,b = r.get("from"),r.get("to")
        if a not in pos or b not in pos: continue
        dash,head = REL_STYLE.get(r.get("type"),(None,"arrow"))
        ax,ay,aw,ah = pos[a]; bx,by,bw,bh = pos[b]
        sc.append({"t":"arrow","id":"relation-%s"%r.get("id",""),"x1":ax+aw/2,"y1":ay,"x2":bx-bw/2,"y2":by,"stroke":REL_COLOR.get(r.get("type"),"#444"),
                   "sw":1.8,"dash":dash,"head":head,"midlabel":r.get("label","")})
    ly = h-34; ix = 100
    reltypes = sorted({r.get("type") for r in relations if r.get("type") in REL_STYLE})
    sc.append({"t":"text","x":40,"y":ly-14,"s":"Legend:","fs":12,"bold":True,"fill":"#111","align":"left","anchor":"middle"})
    for t in reltypes:
        dash,head = REL_STYLE.get(t,(None,"arrow"))
        sc.append({"t":"arrow","id":"legend-%s"%t,"x1":ix,"y1":ly-14,"x2":ix+30,"y2":ly-14,"stroke":REL_COLOR.get(t,"#444"),"sw":1.8,"dash":dash,"head":head})
        sc.append({"t":"text","id":"legend-label-%s"%t,"x":ix+38,"y":ly-14,"s":t,"fs":11,"align":"left","fill":"#111","anchor":"middle"})
        ix += 38+7*len(t)+24
    return sc

def _chart(model, w, h):
    sc = [{"t":"text","x":w/2,"y":32,"s":model.get("title","") or "Data chart","fs":20,"align":"middle","bold":True,"fill":"#111","anchor":"middle"}]
    ch = model.get("chart",{}); ss = ch.get("series",[]); cats = ch.get("categories",[])
    xl = ch.get("x_label",""); yl = ch.get("y_label",""); yu = ch.get("y_unit","")
    mx,my,mw,mh = 120,90,w-190,h-200
    sc.append({"t":"rect","id":"chart-frame","x":mx,"y":my,"w":mw,"h":mh,"fill":"#fff","stroke":"#333","sw":1.4})
    av = [v for s in ss for v in s.get("data",[]) if isinstance(v,(int,float))]
    ymax = (max(av) if av else 1.0)*1.15 or 1.0
    for i in range(6):
        fy = my+mh-(i/5)*mh
        sc.append({"t":"line","x1":mx-6,"y1":fy,"x2":mx,"y2":fy,"stroke":"#333","sw":1})
        sc.append({"t":"text","x":mx-10,"y":fy,"s":_fmt(ymax*i/5),"fs":10,"align":"right","fill":"#111","anchor":"middle"})
    sc.append({"t":"text","x":36,"y":my+mh/2,"s":(yl+" "+yu).strip(),"fs":13,"align":"middle","fill":"#111","anchor":"middle"})
    n = len(cats) or max([len(s.get("data",[])) for s in ss] or [1])
    if not cats: cats = [str(i+1) for i in range(n)]
    bw = mw/n if n else mw; k = len(ss) or 1; gb = bw*0.7/k
    for j,cat in enumerate(cats):
        cx = mx+bw*(j+0.5)
        for si,s in enumerate(ss):
            data = s.get("data",[]); err = s.get("error",[])
            if j >= len(data): continue
            v = data[j]
            if not isinstance(v,(int,float)): continue
            bh = (v/ymax)*mh; bx = cx-bw*0.35+si*gb
            sc.append({"t":"rect","id":"bar-%s-%d"%(s.get("name","s%d"%si),j),"x":bx,"y":my+mh-bh,"w":gb*0.9,"h":bh,"fill":PALETTE[si % len(PALETTE)],"stroke":"#333","sw":0.8})
            if j < len(err) and isinstance(err[j],(int,float)):
                ex = bx+gb*0.45; etp = my+mh-((v+err[j])/ymax)*mh; eby = my+mh-((v-err[j])/ymax)*mh
                sc.append({"t":"line","x1":ex,"y1":etp,"x2":ex,"y2":eby,"stroke":"#333","sw":1.2})
                sc.append({"t":"line","x1":ex-4,"y1":etp,"x2":ex+4,"y2":etp,"stroke":"#333","sw":1.2})
                sc.append({"t":"line","x1":ex-4,"y1":eby,"x2":ex+4,"y2":eby,"stroke":"#333","sw":1.2})
        sc.append({"t":"text","x":cx,"y":my+mh+18,"s":str(cat),"fs":11,"align":"middle","fill":"#111","anchor":"middle"})
    if xl: sc.append({"t":"text","x":mx+mw/2,"y":h-30,"s":xl,"fs":13,"align":"middle","fill":"#111","anchor":"middle"})
    lx = mx+mw-10; ly = my-30
    for si,s in enumerate(ss):
        sc.append({"t":"rect","id":"legend-%s"%s.get("name","s%d"%si),"x":lx-90,"y":ly-8,"w":16,"h":12,"fill":PALETTE[si % len(PALETTE)],"stroke":"#333","sw":0.8})
        sc.append({"t":"text","id":"legend-label-%s"%s.get("name","s%d"%si),"x":lx-68,"y":ly-1,"s":s.get("name","S%d"%(si+1)),"fs":11,"align":"left","fill":"#111","anchor":"middle"})
        lx -= 90+7*len(s.get("name",""))+30
    return sc

def _fmt(v):
    return "%.2g" % v if (abs(v) >= 1000 or (v != 0 and abs(v) < 0.01)) else ("%.2f" % v).rstrip("0").rstrip(".")

def _se(s): return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")

_LAYER_ORDER = ["panels","axes","entities","relations","legend","labels"]

def _bucket(c):
    i = c.get("id","") or ""
    if i.startswith("panel-"): return "panels"
    if i.startswith("entity-"): return "entities"
    if i.startswith("relation-"): return "relations"
    if i.startswith("legend-"): return "legend"
    if i.startswith(("bar-","chart-")): return "entities"
    t = c["t"]
    if t == "arrow": return "relations"
    if t in ("rect","line"): return "axes"
    return "labels"

def render_svg(scene, w=W, h=H):
    o = ['<?xml version="1.0" encoding="UTF-8"?>',
         f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" font-family="Arial,Helvetica,sans-serif">',
         '<g id="layer-background">', f'<rect x="0" y="0" width="{w}" height="{h}" fill="#ffffff"/>', '</g>']
    buckets = {}
    for c in scene: buckets.setdefault(_bucket(c), []).append(c)
    for name in _LAYER_ORDER:
        items = buckets.get(name)
        if not items: continue
        o.append(f'<g id="layer-{name}">')
        for c in items:
            ida = f' id="{c["id"]}"' if c.get("id") else ""
            t = c["t"]
            if t == "rect":
                o.append(f'<rect{ida} x="{c["x"]:.1f}" y="{c["y"]:.1f}" width="{c["w"]:.1f}" height="{c["h"]:.1f}" fill="{c["fill"]}" stroke="{c["stroke"]}" stroke-width="{c.get("sw",1)}" rx="{c.get("rx",0)}"/>')
            elif t == "line":
                d = f' stroke-dasharray="{c["dash"]}"' if c.get("dash") else ""
                o.append(f'<line{ida} x1="{c["x1"]:.1f}" y1="{c["y1"]:.1f}" x2="{c["x2"]:.1f}" y2="{c["y2"]:.1f}" stroke="{c["stroke"]}" stroke-width="{c.get("sw",1)}"{d}/>')
            elif t == "arrow":
                seg = _sarrow(c)
                if ida: seg[0] = seg[0].replace("<line ", "<line%s "%ida, 1)
                o += seg
            elif t == "text":
                anc = {"middle":"middle","left":"start","right":"end"}.get(c.get("align"),"start")
                wt = ' font-weight="bold"' if c.get("bold") else ""
                o.append(f'<text{ida} x="{c["x"]:.1f}" y="{c["y"]:.1f}" font-size="{c.get("fs",12)}" fill="{c.get("fill","#000")}" text-anchor="{anc}"{wt}>{_se(c["s"])}</text>')
        o.append('</g>')
    o.append('</svg>')
    return "\n".join(o)+"\n"

def _sarrow(c):
    x1,y1,x2,y2 = c["x1"],c["y1"],c["x2"],c["y2"]; col = c["stroke"]; sw = c.get("sw",1.8)
    d = f' stroke-dasharray="{c["dash"]}"' if c.get("dash") else ""
    L = [f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{col}" stroke-width="{sw}"{d}/>']
    if c.get("head") in ("arrow","tee"):
        ang = math.atan2(y2-y1,x2-x1)
        for s in (1,-1):
            a2 = ang+s*math.radians(150)
            L.append(f'<line x1="{x2:.1f}" y1="{y2:.1f}" x2="{x2+10*math.cos(a2):.1f}" y2="{y2+10*math.sin(a2):.1f}" stroke="{col}" stroke-width="{sw}"/>')
        if c.get("head") == "tee":
            p = ang+math.pi/2; tx = 8*math.cos(p); ty = 8*math.sin(p)
            L.append(f'<line x1="{x2+tx:.1f}" y1="{y2+ty:.1f}" x2="{x2-tx:.1f}" y2="{y2-ty:.1f}" stroke="{col}" stroke-width="{sw}"/>')
    if c.get("midlabel"):
        L.append(f'<text x="{(x1+x2)/2:.1f}" y="{(y1+y2)/2-8:.1f}" font-size="10" fill="{col}" text-anchor="middle">{_se(c["midlabel"])}</text>')
    return L

def _canvas(w,h):
    return [bytearray([255,255,255])*w for _ in range(h)]

def _put(cv,x,y,col):
    if 0 <= x < len(cv[0])//3 and 0 <= y < len(cv):
        i = x*3; cv[y][i:i+3] = bytes(col)

def _rect(cv,x,y,w,h,col):
    for yy in range(y,y+h):
        if 0 <= yy < len(cv):
            row = cv[yy]
            for xx in range(x,x+w):
                if 0 <= xx < len(row)//3: row[xx*3:xx*3+3] = bytes(col)

def _line(cv,x1,y1,x2,y2,col,sw=1):
    dx = x2-x1; dy = y2-y1; st = max(abs(dx),abs(dy),1)
    for i in range(st+1):
        t = i/st; px = int(round(x1+dx*t)); py = int(round(y1+dy*t))
        for ox in range(-sw//2,sw//2+1):
            for oy in range(-sw//2,sw//2+1): _put(cv,px+ox,py+oy,col)

def _arrow(cv,c,sc):
    x1,y1,x2,y2 = int(c["x1"]*sc),int(c["y1"]*sc),int(c["x2"]*sc),int(c["y2"]*sc)
    col = _hex(c["stroke"]); sw = max(1,int(c.get("sw",1.8)*sc))
    if c.get("dash"):
        dist = math.hypot(x2-x1,y2-y1); dash = int(8*sc)
        if dist > 0:
            ux,uy = (x2-x1)/dist,(y2-y1)/dist; d = 0
            while d < dist:
                e = min(d+dash,dist)
                _line(cv,int(x1+ux*d),int(y1+uy*d),int(x1+ux*e),int(y1+uy*e),col,sw)
                d = e+dash
    else: _line(cv,x1,y1,x2,y2,col,sw)
    if c.get("head") in ("arrow","tee"):
        ang = math.atan2(y2-y1,x2-x1); L = 10*sc
        for s in (1,-1):
            a2 = ang+s*math.radians(150)
            _line(cv,x2,y2,int(x2+L*math.cos(a2)),int(y2+L*math.sin(a2)),col,sw)
        if c.get("head") == "tee":
            p = ang+math.pi/2; tx = 8*sc*math.cos(p); ty = 8*sc*math.sin(p)
            _line(cv,int(x2+tx),int(y2+ty),int(x2-tx),int(y2-ty),col,sw)

def _text(cv,x,y,text,fs,col,sc,anchor="middle"):
    if not text: return
    scale = max(1,int(fs*sc/7)); gw = 6*scale; sx = int(x*sc)-len(text)*gw//2 if anchor == "middle" else int(x*sc)
    sy = int(y*sc)-(7*scale)//2
    for ch in text:
        g = _F.get(ch,_F.get("?"))
        for ci,byte in enumerate(g):
            for ri in range(7):
                if byte >> ri & 1: _rect(cv,sx+ci*scale,sy+ri*scale,scale,scale,col)
        sx += gw

def _raster(scene,w,h,sc):
    cv = _canvas(w*sc,h*sc)
    for c in scene:
        t = c["t"]
        if t == "rect":
            _rect(cv,int(c["x"]*sc),int(c["y"]*sc),int(c["w"]*sc),int(c["h"]*sc),_hex(c.get("fill","#fff")))
            if c.get("stroke"):
                col = _hex(c["stroke"]); sw = max(1,int(c.get("sw",1)*sc))
                x0,y0 = int(c["x"]*sc),int(c["y"]*sc); x1,y1 = int((c["x"]+c["w"])*sc),int((c["y"]+c["h"])*sc)
                _line(cv,x0,y0,x1,y0,col,sw); _line(cv,x1,y0,x1,y1,col,sw)
                _line(cv,x1,y1,x0,y1,col,sw); _line(cv,x0,y1,x0,y0,col,sw)
        elif t == "line":
            _line(cv,int(c["x1"]*sc),int(c["y1"]*sc),int(c["x2"]*sc),int(c["y2"]*sc),_hex(c["stroke"]),max(1,int(c.get("sw",1)*sc)))
        elif t == "arrow": _arrow(cv,c,sc)
        elif t == "text": _text(cv,c["x"],c["y"],c["s"],c.get("fs",12),_hex(c.get("fill","#000")),sc,c.get("anchor","middle"))
    nonw = tot = 0
    for row in cv:
        for i in range(0,len(row),3):
            tot += 1
            if row[i] < 245 or row[i+1] < 245 or row[i+2] < 245: nonw += 1
    return cv, (nonw/tot if tot else 0.0)

def _png_bytes(cv):
    h = len(cv); w = len(cv[0])//3
    raw = bytearray()
    for row in cv: raw.append(0); raw += row
    def chk(typ,data):
        c = struct.pack(">I",len(data))+typ+data
        return c+struct.pack(">I",zlib.crc32(typ+data)&0xffffffff)
    ihdr = struct.pack(">IIBBBBB",w,h,8,2,0,0,0)
    return b"\x89PNG\r\n\x1a\n"+chk(b"IHDR",ihdr)+chk(b"IDAT",zlib.compress(bytes(raw),9))+chk(b"IEND",b"")

def render_png(scene, w=W, h=H, sc=SCALE):
    cv, ratio = _raster(scene,w,h,sc)
    return _png_bytes(cv), ratio

def _pesc(s): return s.replace("\\","\\\\").replace("(","\\(").replace(")","\\)")

def render_pdf(scene, w=W, h=H):
    ops = []
    for c in scene:
        t = c["t"]
        if t == "rect":
            x,y,ww,hh = c["x"],h-c["y"]-c["h"],c["w"],c["h"]
            if c.get("fill"):
                r,g,b = _hex(c["fill"])
                ops += [f"{r/255:.3f} {g/255:.3f} {b/255:.3f} rg", f"{x:.2f} {y:.2f} {ww:.2f} {hh:.2f} re f"]
            if c.get("stroke"):
                r,g,b = _hex(c["stroke"]); sw = c.get("sw",1)
                ops += [f"{r/255:.3f} {g/255:.3f} {b/255:.3f} RG {sw:.2f} w", f"{x:.2f} {y:.2f} {ww:.2f} {hh:.2f} re S"]
        elif t == "line": _pline(ops,c,h)
        elif t == "arrow": _parrow(ops,c,h)
        elif t == "text":
            r,g,b = _hex(c.get("fill","#000"))
            ops += ["BT", f"/F1 {c.get('fs',12)} Tf", f"{r/255:.3f} {g/255:.3f} {b/255:.3f} rg",
                    f"{c['x']:.2f} {h-c['y']:.2f} Td", f"({_pesc(_ptxt(c['s']))}) Tj", "ET"]
    stream = "\n".join(ops).encode("latin-1","replace")
    objs = [b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            (f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {w} {h}] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>").encode(),
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
            b"<< /Length "+str(len(stream)).encode()+b" >>\nstream\n"+stream+b"\nendstream"]
    out = bytearray(b"%PDF-1.4\n"); offs = [0]
    for i,o in enumerate(objs,1):
        offs.append(len(out)); out += str(i).encode()+b" 0 obj\n"+o+b"\nendobj\n"
    xp = len(out); n = len(objs)+1
    out += f"xref\n0 {n}\n".encode()+b"0000000000 65535 f \n"
    for off in offs[1:]: out += f"{off:010d} 00000 n \n".encode()
    out += f"trailer\n<< /Size {n} /Root 1 0 R >>\nstartxref\n{xp}\n%%EOF\n".encode()
    return bytes(out)

def _pline(ops,c,h):
    r,g,b = _hex(c["stroke"]); sw = c.get("sw",1)
    if c.get("dash"):
        a,b2 = (c["dash"].split(",")+["4"])[:2]; ops.append(f"[{a} {b2}] 0 d")
    ops.append(f"{r/255:.3f} {g/255:.3f} {b/255:.3f} RG {sw:.2f} w")
    ops.append(f"{c['x1']:.2f} {h-c['y1']:.2f} m {c['x2']:.2f} {h-c['y2']:.2f} l S")
    if c.get("dash"): ops.append("[] 0 d")

def _parrow(ops,c,h):
    _pline(ops,c,h)
    x1,y1,x2,y2 = c["x1"],h-c["y1"],c["x2"],h-c["y2"]
    r,g,b = _hex(c["stroke"]); ops.append(f"{r/255:.3f} {g/255:.3f} {b/255:.3f} RG {c.get('sw',1.8):.2f} w")
    if c.get("head") in ("arrow","tee"):
        ang = math.atan2(y2-y1,x2-x1)
        for s in (1,-1):
            a2 = ang+s*math.radians(150)
            ops.append(f"{x2:.2f} {y2:.2f} m {x2+10*math.cos(a2):.2f} {y2+10*math.sin(a2):.2f} l S")
        if c.get("head") == "tee":
            p = ang+math.pi/2; tx = 8*math.cos(p); ty = 8*math.sin(p)
            ops.append(f"{x2+tx:.2f} {y2+ty:.2f} m {x2-tx:.2f} {y2-ty:.2f} l S")

def _ptxt(s): return "".join(ch if ord(ch) < 256 else "?" for ch in s)

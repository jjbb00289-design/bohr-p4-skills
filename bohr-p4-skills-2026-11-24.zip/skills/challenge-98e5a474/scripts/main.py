#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""editable-relationship-schematic: source-bound figure builder. Bare command = full flow."""
import argparse, csv, json, os, re, sys, zipfile, zlib
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import render as R
VERSION = "1.1.0"
PLACEHOLDER_RE = re.compile(r"\b(Entity|Node|Item|TBD|TODO|placeholder|example|skeleton|stub|dummy|占位|示例|待定)\b", re.I)

def jload(p, d=None):
    try: return json.load(open(str(p), encoding="utf-8-sig", errors="replace"))
    except Exception: return d
def jdump(p, o):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    with open(str(p), "w", encoding="utf-8") as f: json.dump(o, f, ensure_ascii=False, indent=2); f.write("\n")
def read_text(p):
    b = Path(p).read_bytes()
    for e in ("utf-8-sig","utf-16","latin-1"):
        try: return b.decode(e)
        except Exception: pass
    return b.decode("utf-8","replace")
def norm(s): return re.sub(r"\s+"," ",s or "").strip()

def pdf_text(data):
    tm = {}; csx = []
    for obj in re.findall(rb"\d+\s+\d+\s+obj(.*?)endobj", data, re.S):
        m = re.search(rb"stream\r?\n(.*?)endstream", obj, re.S)
        if not m: continue
        raw = m.group(1)
        try: cs = zlib.decompress(raw) if b"FlateDecode" in obj else raw
        except Exception: cs = raw
        if b"ToUnicode" in obj: tm.update(cmap(cs))
        elif b"Tj" in cs or b"TJ" in cs: csx.append(cs)
    out = []
    for cs in csx:
        for m in re.finditer(rb"\[(.*?)\]\s*TJ", cs, re.S):
            for s in re.finditer(rb"\(((?:\\.|[^()\\])*)\)", m.group(1)): out += [mtxt(s.group(1), tm), " "]
        for m in re.finditer(rb"\(((?:\\.|[^()\\])*)\)\s*Tj", cs): out.append(mtxt(m.group(1), tm))
    return " ".join(out)
def cmap(cs):
    m = {}
    for bm in re.finditer(rb"beginbfchar(.*?)endbfchar", cs, re.S):
        for p in re.finditer(rb"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", bm.group(1)):
            c = p.group(1).decode(); u = p.group(2).decode()
            try: m[c] = bytes.fromhex(u).decode("utf-16-be","replace")
            except Exception: m[c] = chr(int(u,16)) if len(u) <= 4 else ""
    return m
def mtxt(s, tm):
    s = s.replace(rb"\(", b"(").replace(rb"\)", b")")
    if tm and len(s) >= 2 and len(s) % 2 == 0:
        cs = ["%02x%02x" % (s[i], s[i+1]) for i in range(0, len(s), 2)]
        if all(c in tm for c in cs): return "".join(tm[c] for c in cs)
    return s.decode("latin-1","replace")
def docx_text(p):
    try:
        with zipfile.ZipFile(str(p)) as z: xml = z.read("word/document.xml").decode("utf-8","replace")
    except Exception: return ""
    xml = re.sub(r"<w:p\b", "\n<w:p", xml)
    return "".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", xml, re.S)).replace("&amp;","&").replace("&lt;","<").replace("&gt;",">").replace("&quot;",'"').replace("&apos;","'")

def parse_table(text, name):
    f = text.split("\n",1)[0]
    d = "\t" if (name.endswith((".tsv",".tab")) or f.count("\t") > f.count(",")) else ","
    rows = [r for r in csv.reader(__import__("io").StringIO(text), delimiter=d) if r and any(c.strip() for c in r)]
    if len(rows) < 2: return None
    hd = rows[0]; lc = 0
    nc = [ci for ci in range(1,len(hd)) if not re.search(r"(err|std|sem|sd|error)", hd[ci], re.I)
          and sum(1 for r in rows[1:] if ci < len(r) and _num(r[ci])) >= max(1,len(rows[1:])-1)]
    if not nc: return None
    cats = [r[lc].strip() if lc < len(r) else "" for r in rows[1:]]
    u = lambda h: (re.search(r"\(([^()]+)\)", h) or ["",""])[1]
    ss = []
    for ci in nc:
        data = [_num(r[ci]) if ci < len(r) else None for r in rows[1:]]
        raw = [r[ci].strip() if ci < len(r) else "" for r in rows[1:]]
        err = [None]*len(data)
        for di,hh in enumerate(hd):
            if di != ci and re.search(r"(err|std|sem|sd|error)", hh, re.I):
                err = [_num(r[di]) if di < len(r) else None for r in rows[1:]]; break
        ss.append({"name": hd[ci].strip(), "data": data, "error": err, "unit": u(hd[ci]), "raw": raw})
    return {"categories": cats, "series": ss, "x_label": hd[lc], "y_label": "Value",
            "y_unit": ss[0]["unit"] if ss else "", "file": name, "rows": rows}
def _num(x):
    try: return float(x.strip().replace(",",""))
    except Exception: return None
def json_table(d, name):
    try:
        if isinstance(d, list) and d and all(isinstance(x,(int,float)) for x in d):
            return {"categories":[str(i+1) for i in range(len(d))],"series":[{"name":"values","data":d,"error":[None]*len(d)}],
                    "x_label":"Index","y_label":"Value","y_unit":"","file":name}
        if not isinstance(d, dict): return None
        cats = d.get("categories") or d.get("labels") or d.get("x")
        ss = d.get("series") or d.get("data") or d.get("y")
        if isinstance(ss, dict): ss = [{"name":k,"data":(v if isinstance(v,list) else [v])} for k,v in ss.items()]
        elif isinstance(ss, list):
            if ss and all(isinstance(x,(int,float)) for x in ss): ss = [{"name":"values","data":ss,"error":[None]*len(ss)}]
            elif not (ss and all(isinstance(x,dict) for x in ss)): ss = None
        if not ss: return None
        for s in ss: s.setdefault("name","series"); s.setdefault("unit",""); s.setdefault("error",[None]*len(s.get("data",[])))
        if not isinstance(cats, list): cats = [str(i+1) for i in range(len(ss[0]["data"]))]
        return {"categories":cats,"series":ss,"x_label":d.get("x_label",""),"y_label":d.get("y_label","Value"),"y_unit":d.get("y_unit",""),"file":name}
    except Exception: return None

STOP = set(("the of and or in on to for with by from as is are was were be been a an this that these those it its at "
            "into via between among through during after before under over not no also each using used use than then "
            "when which who whom while both either neither has had have do does did can may will would could should").split())
COMP = {"nucleus","cytoplasm","cytosol","plasma membrane","mitochondria","mitochondrion","er",
 "endoplasmic reticulum","golgi","lysosome","cell","extracellular","receptor","gene","protein","dna","rna",
 "transcription factor","kinase","phosphatase","apoptosis","proliferation","survival","differentiation","tumor",
 "tumour","cancer","growth","death","pathway","signaling","signal","complex","dimer","monomer","subunit","ligand",
 "enzyme","substrate","product","inhibitor","activator","cofactor","target","mrna","promoter","enhancer"}
ACRO = re.compile(r"\b[A-Z]{2,8}\b")
GENE = re.compile(r"\b(?:[A-Z][a-z0-9]+[A-Z0-9][A-Za-z0-9]{0,12}|[A-Z]{2,8}[0-9][A-Za-z0-9]{0,8})\b")
VERBS = {"activation": r"\b(activ\w+|induc\w+|promot\w+|stimulat\w+|up-?regulat\w+|enhanc\w+)\b",
 "inhibition": r"\b(inhibit\w+|repress\w+|suppress\w+|block\w+|down-?regulat\w+|antagoniz\w+|sequester\w+|impair\w+)\b",
 "binding": r"\b(bind\w+|bound|interact\w+|associat\w+|recogniz\w+)\b",
 "transport": r"\b(translocat\w+|transport\w+|enter\w+|exit\w+|import\w+|export\w+)\b",
 "transformation": r"\b(convert\w+|catalyz\w+|transform\w+|cleav\w+|synthesiz\w+|produc\w+|generat\w+)\b",
 "modification": r"\b(phosphorylat\w+|ubiquitinat\w+|methylat\w+|acetyl\w+|dephosphorylat\w+)\b",
 "composition": r"\b(compris\w+|consist\w+\s+of|contain\w+|compos\w+\s+of)\b",
 "association": r"\b(recruit\w+|couple\w+|co-?localiz\w+)\b"}

def sents(t): return [s.strip() for s in re.split(r"(?<=[.!?;])\s+", re.sub(r"\s+"," ",t)) if s.strip()]
def candidates(t):
    f = {}
    for m in ACRO.finditer(t):
        x = m.group(0)
        if x.lower() not in STOP: f[x] = f.get(x,0)+1
    for m in GENE.finditer(t):
        x = m.group(0)
        if x.lower() in STOP: continue
        if not re.search(r"[0-9]", x) and not re.search(r"[a-z][A-Z]", x): continue
        f[x] = f.get(x,0)+1
    for w in sorted(COMP):
        if re.search(r"\b"+re.escape(w)+r"\b", t, re.I): f[w] = f.get(w,0)+2
    e = []
    for x,n in f.items():
        if n >= 1 and (n >= 2 or len(x) >= 3 or x.lower() in COMP):
            e.append({"token":x,"type":"process" if x.lower() in COMP else "protein/gene","freq":n})
    e.sort(key=lambda z: (-z["freq"], z["token"]))
    return e[:10]
def derive(texts):
    em = {}
    for fn,t in texts:
        for e in candidates(t):
            k = e["token"].lower()
            if k not in em: em[k] = {"label":e["token"],"type":e["type"],"freq":0,"src":None}
            em[k]["freq"] += e["freq"]
    ents = sorted(em.values(), key=lambda e: (-e["freq"], e["label"].lower()))[:10]
    for e in ents:
        for fn,t in texts:
            m = re.search(r"\b"+re.escape(e["label"])+r"\b", t)
            if m:
                ln = t[:m.start()].count("\n")+1; s = t.rfind("\n",0,m.start()); en = t.find("\n",m.start())
                e["src"] = {"file":fn,"locator":"line %d"%ln,"quote":norm(t[s+1:en if en>=0 else len(t)].strip())}
                break
        if e["src"] is None: e["src"] = {"file":"","locator":"","quote":e["label"]}
    bl = {e["label"].lower(): e for e in ents}
    rels = []; seen = set()
    for fn,t in texts:
        for ln,sent in enumerate(sents(t),1):
            for rt,pat in VERBS.items():
                for vm in re.finditer(pat, sent, re.I):
                    be = sent[:vm.start()]; af = sent[vm.end():]
                    s = near(be,bl,1); o = near(af,bl,0)
                    if not s or not o or s == o: continue
                    if re.search(r"\b"+re.escape(s["label"])+r"\s+(?:inhibition|blockade|knockdown|knock-down|depletion|silencing|suppression|loss)\b", be[-60:], re.I):
                        rt = {"activation":"inhibition","inhibition":"activation"}.get(rt,rt)
                    if (s["label"],o["label"]) in seen: continue
                    seen.add((s["label"],o["label"]))
                    rels.append({"id":"r%d"%len(rels),"from":s["label"],"to":o["label"],"type":rt,"label":vm.group(0).strip(),
                                 "src":{"file":fn,"locator":"line %d"%ln,"quote":norm(sent)}})
                    if len(rels) >= 14: break
    return ents, rels
def near(t, bl, rev):
    best = None; bd = 10**9
    for lb in bl:
        for m in re.finditer(r"\b"+re.escape(lb)+r"\b", t, re.I):
            d = len(t)-m.start() if rev else m.start()
            if d < bd: bd = d; best = bl[lb]
    return best
def panels(ents, rels):
    ind = {e["label"]:0 for e in ents}; oud = dict(ind)
    for r in rels: oud[r["from"]] = oud.get(r["from"],0)+1; ind[r["to"]] = ind.get(r["to"],0)+1
    for e in ents:
        l = e["label"]
        e["panel"] = "input" if (oud[l] > 0 and ind[l] == 0) else ("outcome" if (ind[l] > 0 and oud[l] == 0) else "mechanism")
    for target in ("input","outcome"):
        if not any(e["panel"] == target for e in ents):
            for e in ents:
                if e["panel"] == "mechanism": e["panel"] = target; break
    return ents

def ckeys(c):
    ks = []
    if isinstance(c, dict): ks = [str(k) for k in c]
    elif isinstance(c, list):
        for i in c:
            if isinstance(i,str): ks.append(i)
            elif isinstance(i,dict):
                for k in ("key","name","field","id"):
                    if isinstance(i.get(k),str): ks.append(i[k]); break
    elif isinstance(c,str): ks = [c]
    return ks
def cval(k,b):
    k = k.lower(); a = b["artifacts"]
    for kw,key in [("svg editable","svg"),("png raster preview bitmap","png"),("pdf vector export","pdf"),
        ("map provenance content","content_map"),("check compliance","compliance"),("model","model"),
        ("entit","entities"),("relation edge","relations"),("data point chart series","data_points"),
        ("source","sources"),("uncertain","uncertainty"),("change edit version","change_records"),
        ("gap error degrad exception","gaps")]:
        if any(w in k for w in kw.split()):
            return a.get(key, b.get(key))
    return None

def scan(inp):
    inp = Path(inp); cp = inp/"case.json"; tp = inp/"task.md"
    case = jload(cp); tt = read_text(tp) if tp.exists() else ""
    mats = [p for p in sorted(inp.rglob("*")) if p.is_file() and p.name not in ("case.json","task.md")
            and p.resolve() not in (cp.resolve(), tp.resolve())]
    return case, tt, mats, cp
def parse_mat(inp, mats):
    texts = []; tables = []; other = []
    for p in mats:
        try: rel = p.relative_to(inp).as_posix()
        except Exception: rel = p.name
        suf = p.suffix.lower()
        try:
            if suf == ".pdf":
                t = pdf_text(p.read_bytes())
                texts.append((rel,t)) if t.strip() else other.append((rel,"pdf-no-text-layer"))
            elif suf == ".docx":
                t = docx_text(p)
                texts.append((rel,t)) if t.strip() else other.append((rel,"docx-empty"))
            elif suf in (".csv",".tsv",".tab"):
                t = read_text(p); texts.append((rel,t))
                tb = parse_table(t, rel)
                if tb: tables.append(tb)
            elif suf == ".json":
                d = jload(p); texts.append((rel, json.dumps(d, ensure_ascii=False) if d is not None else read_text(p)))
                if isinstance(d,(list,dict)):
                    tb = json_table(d, rel)
                    if tb: tables.append(tb)
            elif suf in (".txt",".md",".markdown",".rst",".tex"): texts.append((rel, read_text(p)))
            else: other.append((rel,"unsupported-"+suf))
        except Exception as ex: other.append((rel,"parse-error:%s"%ex))
    texts.sort(key=lambda x:x[0]); tables.sort(key=lambda x:x.get("file",""))
    return texts, tables, other
def build(case, tt, texts, tables):
    ents, rels = derive(texts)
    ti = (case.get("task_instruction","") if isinstance(case,dict) else "")
    low = (tt+" "+ti).lower()
    ck = re.search(r"\b(chart|plot|bar|line graph|histogram|data figure|图表|数据图|柱状|折线)\b", low)
    kind = "chart" if (tables and (ck or not ents)) else "schematic"
    m = {"kind":kind,"title":"","entities":[],"relations":[],"data_points":[],"chart":{},"panels":[]}
    tm = re.search(r"(?:title|标题|图题)\s*[:：]\s*(.{0,120})", tt, re.I)
    if kind == "chart" and tables:
        tb = tables[0]
        m["title"] = norm(tm.group(1)) if tm else "Data chart"
        m["chart"] = {k: tb.get(k) for k in ("categories","series","x_label","y_label","y_unit")}
        m["data_points"] = [{"series":s["name"],"category":tb["categories"][j] if j < len(tb["categories"]) else j+1,
            "value":v,"unit":s.get("unit",""),"error":(s.get("error") or [None]*len(s["data"]))[j],
            "src":{"file":tb["file"],"locator":"row %d, '%s'"%(j+2,s["name"]),
                   "quote":((s.get("raw") or [""]*len(s["data"]))[j] if j < len(s.get("raw") or []) else str(v))}}
            for si,s in enumerate(tb["series"]) for j,v in enumerate(s["data"]) if v is not None]
    else:
        panels(ents, rels)
        m["title"] = norm(tm.group(1)) if tm else "Relationship schematic"
        m["entities"] = [{"id":"e%d"%(i+1),"label":e["label"],"type":e["type"],"panel":e.get("panel","mechanism"),
                          "color":R.PALETTE[i % len(R.PALETTE)],"src":e.get("src")} for i,e in enumerate(ents)]
        m["relations"] = [dict(r) for r in rels]
        m["panels"] = [{"id":"input","label":"Input"},{"id":"mechanism","label":"Mechanism"},{"id":"outcome","label":"Outcome"}]
    return m
def _cme(i,k,l,s,extra=None):
    e = {"id":i,"kind":k,"label":l,"source":(s or {}).get("file"),"locator":(s or {}).get("locator"),
         "quote":(s or {}).get("quote")}
    if extra: e.update(extra)
    return e
def content_map(m):
    cm = [_cme(e["id"],"entity",e["label"],e.get("src")) for e in m.get("entities",[])]
    cm += [_cme(r["id"],"relation",r.get("label"),r.get("src"),
                {"from":r.get("from"),"to":r.get("to"),"type":r.get("type")}) for r in m.get("relations",[])]
    cm += [_cme("dp-%s-%s"%(d.get("series"),d.get("category")),"data_point",str(d.get("value")),d.get("src"))
           for d in m.get("data_points",[])]
    return cm
def verify(cm, texts):
    corp = {}
    for f,t in texts: corp[f] = corp.get(f,"")+" "+t
    allc = " ".join(corp.values()); hits = tot = 0
    for it in cm:
        q = it.get("quote")
        if not q: continue
        tot += 1
        hit = bool(norm(q)) and norm(q).lower() in norm(corp.get(it.get("source"), allc)).lower()
        it["quote_hit"] = hit; hits += hit
    return hits, tot

def run(inp, work, out):
    out = Path(out); work = Path(work); out.mkdir(parents=True, exist_ok=True); work.mkdir(parents=True, exist_ok=True)
    cr = [{"step":"start","detail":"auto flow began","status":"ok"}]; errs = []; degs = []; gaps = []
    jdump(out/"result.json", {"case_id":None,"status":"partial","gaps":["pending"],"change_records":cr,
        "errors":[],"degradations":[],"uncertainty":[],"entities":[],"relations":[],"data_points":[],
        "artifacts":{},"sources":[],"pending_human":["run in progress"]})
    case, tt, mats, cp = scan(inp)
    cid = None; contract = None
    if isinstance(case, dict): cid = case.get("case_id") or case.get("id"); contract = case.get("output_contract")
    elif cp.exists(): errs.append("case.json exists but is invalid JSON")
    if not cp.exists(): errs.append("case.json missing")
    texts, tables, other = parse_mat(inp, mats)
    if not texts and not tables: gaps.append("no parseable material found")
    model = build(case, tt, texts, tables)
    cm = content_map(model); hits, tot = verify(cm, texts); hr = (hits/tot) if tot else 1.0
    scene = R.build_scene(model)
    svg = R.render_svg(scene); png, nw = R.render_png(scene); pdf = R.render_pdf(scene)
    (out/"figure.svg").write_text(svg, encoding="utf-8"); (out/"figure.png").write_bytes(png); (out/"figure.pdf").write_bytes(pdf)
    jdump(out/"figure_model.json", model); jdump(out/"content_map.json", cm)
    nt = svg.count("<text"); ne = len(model["entities"]); nr = len(model["relations"]); nd = len(model["data_points"])
    ph = len(PLACEHOLDER_RE.findall(re.sub(r'id="[^"]*"', "", svg)))
    chk = {"svg_text_count":nt,"svg_layers":svg.count("<g id="),"png_is_png":png[:8]==b"\x89PNG\r\n\x1a\n",
           "png_nonwhite_ratio":round(nw,4),"pdf_header":pdf[:5]==b"%PDF-","pdf_text_ops":pdf.count(b"Tj")+pdf.count(b"TJ"),
           "entity_count":ne,"relation_count":nr,"data_point_count":nd,"quote_hit_rate":round(hr,4),"quote_total":tot,
           "quote_hits":hits,"placeholder_hits":ph}
    jdump(out/"compliance_checks.json", chk)
    hard = (ne >= 6 or nd >= 1) and (nr >= 4 or model["kind"]=="chart") and hr >= 0.95 and chk["png_is_png"] and chk["pdf_header"] and nt > 0 and ph == 0
    if errs: status = "input_error"
    elif not texts and not tables: status = "insufficient_evidence"
    elif hard: status = "ok"
    else:
        status = "partial"
        if model["kind"]=="schematic" and ne < 6: gaps.append("only %d entities derived (target >= 6)"%ne)
        if model["kind"]=="schematic" and nr < 4: gaps.append("only %d relations derived (target >= 4)"%nr)
        if hr < 0.95: degs.append("quote hit rate %.2f < 0.95"%hr)
    for rel,msg in other: gaps.append("%s: %s"%(rel,msg))
    if not gaps: gaps.append("none")
    arts = {"svg":"figure.svg","png":"figure.png","pdf":"figure.pdf","model":"figure_model.json",
            "content_map":"content_map.json","compliance":"compliance_checks.json"}
    jdump(out/"edit_record.json", {"version":VERSION,"kind":model["kind"],"title":model["title"],"entity_count":ne,
        "relation_count":nr,"data_point_count":nd,"quote_hit_rate":round(hr,4),"change_records":cr,"export_checks":chk})
    srcs = sorted({c.get("source") for c in cm if c.get("source")})
    unc = (["%d quotes not verified verbatim"%(tot-hits)] if hr < 1.0 else []) + \
          (["entity set may be incomplete"] if model["kind"]=="schematic" and ne < 6 else []) or ["none"]
    pend = ["quote not verbatim-verified: %s (%s)"%(c.get("id"),c.get("label"))
            for c in cm if c.get("quote") and c.get("quote_hit") is False]
    pend += ["element without verifiable quote: %s (%s)"%(c.get("id"),c.get("label"))
             for c in cm if not c.get("quote")]
    if cid is None: pend.append("case_id missing: confirm case identity manually")
    base = {"case_id":cid,"status":status,"figure_kind":model["kind"],"title":model["title"],"entities":model["entities"],
            "relations":model["relations"],"data_points":model["data_points"],"artifacts":arts,"sources":srcs,
            "uncertainty":unc,"change_records":cr,"gaps":gaps,"errors":errs,"degradations":degs,
            "pending_human":pend,"compliance":chk,"content_map":cm}
    if contract is not None:
        for k in ckeys(contract): base[k] = cval(k, base)
    cr.append({"step":"finalize","detail":"status=%s"%status,"status":"ok"}); base["change_records"] = cr
    jdump(out/"result.json", base)
    return base

def main(argv):
    ap = argparse.ArgumentParser(description="editable-relationship-schematic")
    ap.add_argument("cmd", nargs="?", default="auto")
    ap.add_argument("--input", default=None); ap.add_argument("--work", default=None); ap.add_argument("--output", default=None)
    a = ap.parse_args(argv)
    inp = a.input or os.environ.get("INPUT_DIR","/input")
    work = a.work or os.environ.get("WORK_DIR","/app/work")
    out = a.output or os.environ.get("OUTPUT_DIR","/app/output")
    try:
        run(inp, work, out)
    except Exception as ex:
        Path(out).mkdir(parents=True, exist_ok=True)
        try:
            r = jload(Path(out)/"result.json", {}); r["status"] = r.get("status") or "input_error"
            r.setdefault("errors", []).append("exception: %r"%ex); jdump(Path(out)/"result.json", r)
        except Exception:
            jdump(Path(out)/"result.json", {"case_id":None,"status":"input_error","errors":["exception: %r"%ex],
                "entities":[],"relations":[],"data_points":[],"gaps":["fatal exception"],"uncertainty":[],
                "change_records":[],"degradations":[],"sources":[],"artifacts":{},
                "pending_human":["inspect fatal exception"]})
    return 0
if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

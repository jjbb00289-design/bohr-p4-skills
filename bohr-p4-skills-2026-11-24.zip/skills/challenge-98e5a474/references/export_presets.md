# 导出预设与图面规范（可复用资源）

本文件沉淀「可编辑源文件 → 合规导出件」的检查参数与期刊常见要求，供 Agent 在导出前逐项
核对，也供后续维护者直接复用。脚本 `scripts/render.py` 的产物已按本表自检，结果写入
`compliance_checks.json`。

## 1. 期刊导出参数速查（常见档位，投稿前以目标期刊当期 Guide for Authors 为准）

| 期刊/出版方 | 单栏宽 | 双栏宽 | 位图分辨率 | 矢量格式 | 字号下限 | 色彩 |
|---|---|---|---|---|---|---|
| Nature 系列 | 89 mm | 183 mm | 300–600 dpi | PDF/EPS | 5 pt（最终尺寸） | RGB 接受，印刷转 CMYK |
| Science | 55 mm | 120/183 mm | 300 dpi | PDF/EPS/AI | 6 pt | RGB |
| Cell/Elsevier | 90 mm | 190 mm | 300–500 dpi（组合图 500） | EPS/PDF/TIFF | 6–8 pt | RGB 提交，CMYK 校样 |
| IEEE | 88.9 mm (3.5 in) | 181.6 mm (7.16 in) | 600 dpi（线图） | EPS/PDF/TIFF | 8 pt | 灰度可读优先 |
| PLOS | 83 mm | 173.5 mm | 300–600 dpi | EPS/PDF/TIFF | 8 pt | RGB |

通用硬规则：线宽 ≥ 0.5 pt（最终尺寸）；文字嵌入或转轮廓二选一（本 Skill 选
PDF base-14 Helvetica + SVG `<text>`，编辑侧不改字体即可替换）；TIFF 用 LZW；
不要在导出件里使用小于 5 pt 的字。

## 2. 字体陷阱与规避

- 目标评测/排版环境**可能没有中文字体**：关键标签（实体名、轴题、图例、子图编号）
  一律用英文或双语；中文释义放入 `content_map.json` 与图注，不进图面。
- SVG 声明 `font-family="Arial,Helvetica,sans-serif"`，三者任一可用即可正确排版；
  不引用本机字体文件，不依赖 `font-discovery` 之外的安装步骤。
- PNG 位图内置 5×7 点阵字形覆盖 ASCII 与 µ × ± ° ² ³ ·；罕见字形在 PNG 退化为
  `?`（SVG/PDF 不受影响）。若材料含大量非 ASCII 标签，应改写为英文标签再出图。

## 3. 图例与数据映射一致性检查（导出前必过）

1. 图例项数 == 系列数 == 调色板取用数；颜色顺序按系列下标取色，不跳号。
2. 每个数据点可在源表定位到单元格（`content_map.json` 的 `dp-*` 条目标 row/列名）。
3. 轴题含单位且与表头括号内单位逐字一致；单位改写（µM→uM 之类）只改显示、不改值。
4. 误差柱存在当且仅当源表有 err/std/sem/sd 列；不凭目测补误差。
5. 修改数据后重跑同一命令，图、图例、content_map 同步更新（确定性保证逐字节一致
   仅在同输入下成立；改数据必然改图）。

## 4. 机制图图形语法（与 render.py 一致）

- 箭头方向 == 因果/时序方向；抑制用 tee（-|），激活用实心箭头；结合/组成不带箭头。
- 修饰（磷酸化等）与转运用虚线区分；关系类型→样式的完整映射见
  `references/diagram_conventions.md`。
- 分区（Input / Mechanism / Outcome）按入度出度自动划分：纯出度→Input，纯入度→
  Outcome，其余→Mechanism；包含关系画嵌套，禁止画成并列。
- 实体颜色按确定性调色板取色，同一次运行内实体↔颜色一一对应。

## 5. 导出合规自检清单（compliance_checks.json 字段）

| 检查 | 通过条件 |
|---|---|
| svg_text_count | ≥ 6 个真实 `<text>`（文字可选中，非路径） |
| svg_layers | ≥ 3 个 `<g id="layer-...">` 命名层 |
| png_is_png / png_nonwhite_ratio | 魔数正确且非白像素占比 ≥ 0.03 |
| pdf_header / pdf_text_ops | `%PDF-` 头且 ≥ 4 个 `Tj/TJ` 算子 |
| quote_hit_rate | ≥ 0.95（逐字子串校验） |
| placeholder_hits | 0（图面无 Entity/Node/TBD/占位 等词） |
| entity_count / relation_count | 机制图 ≥ 6 / ≥ 4；数据图 data_point_count ≥ 1 |

全部通过才允许 `status=ok`；任一失败降级为 `partial` 并在 `gaps` 说明缺口。

## 6. 适用范围与维护

适用：科研流程图、机制图、结构关系图、概念示意图与表格驱动的柱状数据图；输入为
PDF（含文本层）/DOCX/TXT/MD/CSV/TSV/JSON 材料。不适用：统计检验与统计方法选择、
海报与封面版式、艺术插画、论文正文写作；SQLite 与无文本层 PDF 归入 gaps，不凭
标签补造内容。

维护指引：关系动词表（`VERBS`）、实体词表（`COMP`）、调色板（`PALETTE`）与样式表
（`REL_STYLE`/`REL_COLOR`）均为单一数据源，扩展新关系类型时四处同步；新增导出
检查必须同时写入 `compliance_checks.json` 与本文件第 5 节表格。版本号遵循语义化
版本，破坏性 schema 变更升 major。

依赖：Python 3.8+ 标准库（argparse/csv/json/re/zipfile/zlib/math/struct），无第三方
包、无网络、无字体文件安装；跨平台（Windows/Linux/macOS）行为一致。

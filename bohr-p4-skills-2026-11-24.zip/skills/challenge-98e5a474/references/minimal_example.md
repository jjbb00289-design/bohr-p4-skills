# 最小调用示例（示例性质，非正式案例结果）

本文件给出一组可手工复现的最小输入、调用方式与**示意输出**，用于说明接口与完整流程。
所有数值来自本地演示材料，不冒充平台正式案例结果。

## 输入

`/input/case.json`：

```json
{"case_id":"demo-1",
 "task_instruction":"Generate an editable relationship schematic from the source text.",
 "output_contract":["editable_source","raster_preview","vector_export","entities",
                    "relations","content_map","compliance_checks"]}
```

`/input/materials/pathway.txt`（示意材料）：

```
EGF binds the EGFR ectodomain at the plasma membrane.
EGFR activates the MAPK cascade in the cytoplasm.
MAPK represses BCL2 transcription in the nucleus.
BCL2 inhibition promotes apoptosis.
```

## 调用

```bash
python3 /skills/weekly-skill/scripts/main.py --input /input --work /app/work --output /app/output
# 退出码恒为 0；失败时 result.json 仍是合法 partial
```

## 示意输出（节选）

`result.json`：

```json
{"case_id":"demo-1","status":"ok","figure_kind":"schematic",
 "entities":[{"id":"e1","label":"EGF","type":"protein/gene","panel":"input"}],
 "relations":[{"id":"r0","from":"EGF","to":"EGFR","type":"binding","label":"binds",
   "src":{"file":"materials/pathway.txt","locator":"line 1",
          "quote":"EGF binds the EGFR ectodomain at the plasma membrane."}}],
 "editable_source":"figure.svg","raster_preview":"figure.png","vector_export":"figure.pdf",
 "content_map":[">= 每元素 source+locator+逐字 quote+quote_hit"],
 "compliance_checks":{"svg_text_count":30,"svg_layers":6,"quote_hit_rate":1.0,
   "png_nonwhite_ratio":0.6,"pdf_text_ops":25,"placeholder_hits":0},
 "pending_human":[],"uncertainty":["none"],"gaps":["none"]}
```

产物核对方法：

1. `figure.svg` 用文本编辑器打开：能看到 `<g id="layer-entities">`、
   `<rect id="entity-e1" ...>`、`<text ...>EGF</text>`，文字可选中、图层可拆。
2. `figure.png` 前 8 字节为 `89 50 4E 47 0D 0A 1A 0A`。
3. `figure.pdf` 以 `%PDF-` 开头，含 `Tj` 文字算子，1 页。
4. `content_map.json` 每条记录的 `quote` 是材料文件的逐字子串（`quote_hit=true`）。

## 异常三态行为

| 输入 | status | result.json |
|---|---|---|
| 空目录（无 case.json） | `input_error` | errors=["case.json missing"]，契约键齐全 |
| case.json 是坏 JSON | `input_error` | errors 记录解析失败，gaps 说明 |
| case.json 合法但无材料 | `insufficient_evidence` | entities/relations 为 []，gaps 说明缺口 |

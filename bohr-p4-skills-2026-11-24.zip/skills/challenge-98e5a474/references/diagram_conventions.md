# Diagram conventions (reusable resource)

本文件定义本 Skill 的图形语法、证据映射规范与可编辑模型 schema，供 Agent 绘制/修改
图稿时遵循，也供复核者按同一规范独立核验。脚本 `scripts/main.py` 与
`scripts/render.py` 严格按本文件实现；修改规范必须同步修改脚本与 SKILL.md。

## 1. Relation type -> arrow semantics (scripts/render.py)

| type | dash | head | color |
|-|-|-|-|
| activation | solid | arrow -> | #d62728 |
| inhibition | solid | tee -\| | #1f77b4 |
| binding | solid | none - | #2ca02c |
| modification | 6,4 | arrow -> | #9467bd |
| transport | 2,3 | arrow -> | #ff7f0e |
| transformation | 6,4 | arrow -> | #8c564b |
| composition | solid | none - | #17becf |
| association | 2,3 | none - | #7f7f7f |

关系类型由材料中的动词触发词判定（activate/inhibit/bind/translocate/phosphorylate/
comprise/recruit 等词族）；同一对实体的多条关系去重为一条，类型取先出现者。否定与
倒置（"X inhibition promotes Y"、"loss of X activates Y"）会把 activation↔inhibition
互换，避免把抑制画成激活这一致命错误。

## 2. 面板与方向语法

- 面板三分区：`input`（纯出度实体，信号/刺激起点）、`mechanism`（双向中间节点）、
  `outcome`（纯入度实体，表型/结局）。无入度/出度节点缺失时从 mechanism 递补。
- 箭头方向 == 因果/时序方向；上下游颠倒属于结构错误，比版式缺陷更严重。
- 包含/组成关系（composition）不带箭头、实现为无边连线；层级表达用面板嵌套，
  禁止把包含画成并列。
- 数据图不走面板语法，走「轴 + 单位 + 图例」语法：x 轴为分类列，y 轴带表头括号内
  单位，图例项数 == 系列数，误差柱仅当源表存在 err/std/sem/sd 列。

## 3. 证据映射规范（每个图元可追溯）

`content_map.json` 每条记录：

```json
{"id":"e1|r2|dp-<series>-<category>","kind":"entity|relation|data_point",
 "label":"<图上文字>","source":"<材料文件相对路径>","locator":"line N | row N, '<列名>'",
 "quote":"<材料原文逐字子串>","quote_hit":true}
```

- SVG 元素 id 与 content_map id 一一对应：`entity-e1` ↔ `e1`，`relation-r2` ↔ `r2`，
  `bar-<series>-<j>` ↔ `dp-<series>-<category>`；图例 `legend-<type>`、面板
  `panel-<id>` 为结构元素，不进 content_map。
- `quote` 必须是 source 文件的逐字子串（主脚本运行时用归一化空白后校验，命中率
  写入 `compliance_checks.json`）；数据点的 quote 取原始单元格文本（如 "82"）。
- 无法逐字验证的 quote：置 `quote_hit=false`，该元素 id 进入 `result.json` 的
  `pending_human` 人工确认清单；无 quote 的元素同样进 `pending_human`。禁止编造
  材料中不存在的基因名、浓度、时间点、单位。
- 关系条目额外携带 `from`/`to`/`type`，复核者可凭 quote 重判方向与类型。

## 4. 调色板（colorblind-friendly, deterministic）

`#1f77b4 #d62728 #2ca02c #ff7f0e #9467bd #8c564b #17becf #e377c2 #7f7f7f #bcbd22`

实体按频率排序后按下标取色；数据系列按系列下标取色；颜色数 ≥ 分类数，不重复使用。
分类数超过调色板长度时按下标取模并写入 uncertainty。

## 5. Figure model schema (figure_model.json)

```json
{"kind":"schematic|chart","title":"",
 "entities":[{"id","label","type","panel","color","src"}],
 "relations":[{"id","from","to","type","label","src"}],
 "data_points":[{"series","category","value","unit","error","src"}],
 "chart":{"categories":[...],"series":[{"name","data","error","unit"}],
          "x_label","y_label","y_unit"},
 "panels":[{"id":"input|mechanism|outcome","label"}]}
```

`src`（溯源）= `{"file","locator","quote"}`；quote 为源文件逐字子串。
改图工作流：编辑 `figure_model.json` 后重跑 `main.py` 即可重绘 SVG/PNG/PDF，
数据更新与图面保持同步；不需要手工改 SVG。

## 6. 编辑与版本记录

`edit_record.json` 记录 version、实体/关系/数据点计数、quote 命中率、
change_records（start/finalize 步骤）与全部导出检查值。任何人工修改（改标签、
删关系、换配色）应作为一次 change record 追加，保持「来源材料 → 当前图稿」的
版本链可复核。

## 7. 已知失败模式与规避（对照实现）

| 失败模式 | 规避机制 |
|---|---|
| 名词平铺成节点、无关系 | 仅当句内出现关系动词才建边；动词表外不猜 |
| 抑制画成激活 / 上下游颠倒 | 否定翻转规则 + 入出度面板划分 |
| 图例与数据不一致 | 图例由 series 数组直接生成，同一数组驱动柱与图例 |
| 只有位图、文字不可选 | SVG 用真实 `<text>`，PDF 用 `Tj` 算子 |
| 编造数值/基因名 | 逐字 quote 校验 < 0.95 即降级 partial |
| 中文标签在目标环境缺字体 | 关键标签英文，中文放 content_map/图注 |

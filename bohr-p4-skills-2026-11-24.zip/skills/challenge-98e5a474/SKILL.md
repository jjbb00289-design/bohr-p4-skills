---
name: editable-relationship-schematic
description: One command turns source materials (PDF text, DOCX, Markdown, TXT, CSV/TSV, JSON) into a source-bound editable scientific figure: derives entities, typed directed relations and chart data with verbatim locator+quote provenance, then renders a layered editable SVG (real <text>, named layers), a real PNG and a real vector PDF (real text operators), plus content_map, compliance checks and a contract-complete result.json. Pure stdlib, deterministic, no network, exit code 0; empty/bad/missing input returns a legal partial result with honest gaps.
version: 1.1.0
license: MIT
---

# editable-relationship-schematic — 一条命令从材料出可编辑科研图稿

## 用途与触发条件

把「科研材料 → 可编辑图稿 → 合规导出件」的链路固化为可复核的自动流程，用于科研
示意图、机制图、流程图与数据图表。当输入目录出现 `case.json` + `task.md` + 材料文件，
或用户要求「生成/编辑示意图、机制图、流程图、图表并保留可编辑源文件」时触发。

关键原则：**裸命令即完整流程**。不要求任何手写 plan.json 或工作稿；脚本自行读取
`/input`，解析真实材料（PDF 文本层、DOCX XML、CSV/TSV、TXT/MD、JSON），派生实体、
有向关系与图表数据，渲染并写全部产物。同一输入两次运行结果逐字节一致。

## 调用方式

```bash
python3 /skills/weekly-skill/scripts/main.py            # 裸命令 = 完整流程
python3 /skills/weekly-skill/scripts/main.py --help
python3 /skills/weekly-skill/scripts/main.py --input /input --work /app/work --output /app/output
```

路径覆盖（本地测试必需）：环境变量 `INPUT_DIR` / `WORK_DIR` / `OUTPUT_DIR`，或
`--input/--work/--output` 参数；默认 `/input`、`/app/work`、`/app/output`。脚本不依赖
CWD（全部以 `Path(__file__).resolve().parent` 定位），不联网，纯 Python 标准库。

## 输入 / 输出

- 输入：`/input/case.json`（含 `case_id`、`output_contract`、`task_instruction`）、
  `/input/task.md`、`/input/` 下全部材料文件（PDF/DOCX/CSV/TSV/TXT/MD/JSON，可能含图片、
  表格、SQLite）。材料按真实文件读取，不按标签假设内容。
- 输出（全部写 `/app/output`，中间态写 `/app/work`）：

| 文件 | 内容 |
|---|---|
| `figure.svg` | 分层可编辑源文件：`<g id="layer-panels/entities/relations/legend/labels">` 分层、真实 `<text>`、元素级 id（`entity-e1`、`relation-r2`、`panel-mechanism`、`legend-activation`、`bar-<series>-<j>`），与 `content_map.json` 的 id 一一对应 |
| `figure_model.json` | 可编辑模型：panels/entities/relations/chart/legend |
| `figure.png` | 真实 PNG（`\x89PNG` + IHDR、zlib 手写、真实文字像素、非白比例可见） |
| `figure.pdf` | 真实 PDF（`%PDF-` 头 + xref + 真实 `Tj/TJ` 文字算子） |
| `content_map.json` | 元素级溯源：每 entity/relation/data_point → source + locator + 逐字 quote + quote_hit |
| `compliance_checks.json` | 导出与语法检查（SVG text 数、PNG 非白、PDF Tj 数、quote 命中率、数量目标） |
| `edit_record.json` | 版本、实体/关系/数据点计数、quote 命中率、change records、导出检查 |
| `result.json` | 契约完整结果：case_id、status、全部 output_contract 字段、sources、uncertainty、change records、gaps/errors/degradations、pending_human |

## 工作稿 schema（非必需）

本 Skill **不要求**任何手写 plan.json 或工作稿；裸命令始终从 `/input` 真实派生并交付完整产物。
可编辑中间模型即 `figure_model.json`，其 schema 见 `references/diagram_conventions.md`。

## 证据规范（硬规则）

1. 每个 entity / relation / data_point 都带 `source`（文件名）+ `locator`（行/段/单元格）+ 逐字 `quote`。
2. quote 必须是材料原文的逐字子串；主脚本逐条校验，命中率写入 `compliance_checks`（阈值 0.95）。
3. 材料未说的基因名、浓度、时间点、单位一律不画；缺口写 `gaps`/`uncertainty`。
4. `result.json` 原样回填 case.json 的 `output_contract` 每个字段（dict 键或 list 项）并附 `case_id`；
   缺值置 `null` 并记 `degradations`。
5. 退出码恒 0；只写 work/output；不联网；不依赖 CWD；确定性（无时间/随机）。

## 降级表（自动、诚实）

| 情况 | status | 仍交付 |
|---|---|---|
| 实体≥6、关系≥4、数据点≥1、quote 命中率≥0.95、SVG/PNG/PDF 达标 | `ok` | 全量产物 + 溯源 |
| 任一目标未达 / 材料缺失 / case_id 缺失 | `partial` | 图稿照出 + gaps 说明缺口 |
| PDF 无文本层 | `partial` | gaps 记录需 `pdf-text-tool` |
| 坏 JSON / 空输入 | `input_error`/`partial` | 合法 result.json + gaps + 退出码 0 |
| 材料不足以支撑机制图 | `insufficient_evidence` | 空实体/关系置 `[]` + gaps + 退出码 0 |

`status=ok` 只在硬门槛全部满足时给出，绝不伪装。不可逐字验证的 quote 与缺 case_id 等情况
进入 `pending_human` 人工确认清单，不静默放过。

## 预算与节奏（platform budget: 64 requests / 900 s）

1. 启动即写最小合法 partial `result.json`（全契约键 + status=partial + gaps），随后增量改进，
   任何中途失败都留有可评分产物。
2. 单次运行 < 10 s（纯 stdlib、无网络、无模型调用）；失败重试至多 1 次，第二次仍失败则
   保留 partial 并记录 errors，不空耗预算。
3. 平台 900 s 预算内可完成全部 3 案例：每案例一次裸命令 + 一次复核读数即可。

## 最小调用示例（示意输出，非正式案例结果）

输入（示意）：`/input/case.json` 含 `case_id="demo-1"` 与
`output_contract=["editable_source","vector_export","entities","relations","content_map","compliance_checks"]`，
`/input/materials/pathway.txt` 含 “EGF binds EGFR … activates MAPK …” 等机制句。

```bash
python3 /skills/weekly-skill/scripts/main.py --input /input --work /app/work --output /app/output
```

示意输出（节选，标明为示例）：`status="ok"`；`entities` 含 `{"id":"e1","label":"EGF",...}`；
`relations` 含 `{"from":"EGF","to":"EGFR","type":"binding",...}`；`compliance.quote_hit_rate=1.0`；
产物 `figure.svg`（6 层、元素级 id）、`figure.png`、`figure.pdf`、`content_map.json`。
完整可复现样例与逐字段说明见 `references/minimal_example.md`。

## 自检

1. 同一输入两次全新输出目录各跑一次，`figure.svg/png/pdf` 逐字节一致（确定性）。
2. `--help`、空输入、坏 JSON、缺材料各跑一次，均退出码 0 且 `result.json` 合法、契约键齐全。
3. 产物真实性：SVG 含 `<text>` 与 `<g id="layer-...">`；PNG 以 `\x89PNG` + IHDR 开头且非白
   像素占比可见；PDF 以 `%PDF-` 开头且含 `Tj/TJ` 文字算子与 `%%EOF`。
4. `compliance_checks.json` 的 `quote_hit_rate` ≥ 0.95；`content_map.json` 每个元素带
   source + locator + 逐字 quote。

## 限制

不做统计检验与统计方法选择，不做海报/封面版式，不做艺术插画，不写论文正文。材料不足以
支撑的机制不画，缺口如实写入 gaps。已知失败模式（名词平铺成节点、抑制画成激活、上下游
颠倒、图例与图面不一致、只有位图、编造数值/基因名）由抽取规则 + 逐字校验 + 固定箭头
语义逐条规避。

## 可复用资源与边界

- `references/diagram_conventions.md`：图形语法（关系→箭头语义、面板划分）、证据映射
  规范（图元 id ↔ content_map）、调色板、模型 schema、已知失败模式对照表，可直接复用
  于其他绘图 Skill。
- `references/export_presets.md`：期刊导出参数速查、字体陷阱规避、图例一致性检查、
  导出合规自检清单与维护指引。
- `references/minimal_example.md`：可手工复现的最小输入/调用/示意输出与三态行为。
- 依赖：Python ≥3.8 标准库；无第三方包、无网络、无字体安装；路径不依赖 CWD。
- 维护：版本号在 frontmatter 与 `scripts/main.py` 的 `VERSION` 同步；扩展关系类型需
  同步 `VERBS`/`REL_STYLE`/`REL_COLOR` 与 diagram_conventions.md 第 1 节表格。

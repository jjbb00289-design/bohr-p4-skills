#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pure-stdlib PDF text extraction: objects, ToUnicode CMaps, content-stream
text runs with (x,y,font-size). Returns per-page runs plus page geometry."""
import re, zlib, os, subprocess, shutil


def pdf_objects(data):
    objs = {}
    for m in re.finditer(rb"(?m)(\d+)\s+(\d+)\s+obj\b", data):
        num = int(m.group(1))
        end = data.find(b"endobj", m.end())
        objs[num] = data[m.end():end if end != -1 else len(data)]
    return objs


def obj_streams(raw):
    out = []
    for m in re.finditer(rb"stream\r?\n(.*?)endstream", raw, re.S):
        b = m.group(1)
        if b.endswith(b"\r\n"):
            b = b[:-2]
        elif b.endswith(b"\n"):
            b = b[:-1]
        out.append(b)
    return out


def decompress(raw):
    body = obj_streams(raw)
    if not body:
        return b""
    d = body[0]
    hdr = raw[:raw.find(b"stream")] if b"stream" in raw else b""
    if b"FlateDecode" in hdr:
        try:
            return zlib.decompress(d)
        except Exception:
            return d
    return d


def find_catalog(objs, data):
    m = re.search(rb"/Root\s+(\d+)\s+0\s+R", data)
    if m:
        return int(m.group(1))
    for n, r in objs.items():
        if re.search(rb"/Type\s*/Catalog", r):
            return n
    return None


def find_pages_root(objs, catalog):
    m = re.search(rb"/Pages\s+(\d+)\s+0\s+R", objs.get(catalog, b""))
    if m:
        return int(m.group(1))
    for n, r in objs.items():
        if re.search(rb"/Type\s*/Pages\b", r):
            return n
    return None


def collect_pages(objs, root):
    pages = []

    def walk(num):
        raw = objs.get(num)
        if raw is None:
            return
        if re.search(rb"/Type\s*/Page\b", raw):
            pages.append(num)
            return
        m = re.search(rb"/Kids\s*\[(.*?)\]", raw, re.S)
        if m:
            for r in re.finditer(rb"(\d+)\s+0\s+R", m.group(1)):
                walk(int(r.group(1)))

    walk(root)
    return pages


def get_refs(raw, key):
    m = re.search(rb"/" + re.escape(key) + rb"\s+(\[[^\[\]]*\]|\d+\s+0\s+R)", raw)
    return [int(x) for x in re.findall(rb"(\d+)\s+0\s+R", m.group(1))] if m else []


def num_array(raw, key):
    m = re.search(rb"/" + re.escape(key) + rb"\s*\[([^\]]*)\]", raw)
    if not m:
        return None
    try:
        return [float(x) for x in re.findall(rb"-?\d+(?:\.\d+)?", m.group(1))]
    except ValueError:
        return None


def utf16_hex(s):
    try:
        return bytes.fromhex(s.decode("ascii")).decode("utf-16-be", "replace")
    except Exception:
        return ""


def parse_cmap(raw):
    streams = obj_streams(raw)
    if not streams:
        return {}
    d = streams[0]
    cmap = {}
    for m in re.finditer(rb"beginbfchar(.*?)endbfchar", d, re.S):
        for p in re.finditer(rb"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", m.group(1)):
            cmap[int(p.group(1), 16)] = utf16_hex(p.group(2))
    for m in re.finditer(rb"beginbfrange(.*?)endbfrange", d, re.S):
        for r in re.finditer(
                rb"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*(?:<([0-9A-Fa-f]+)>|\[([^\]]*)\])",
                m.group(1)):
            s, e = int(r.group(1), 16), int(r.group(2), 16)
            if r.group(4) is not None:
                vs = re.findall(rb"<([0-9A-Fa-f]+)>", r.group(4))
                for i, c in enumerate(range(s, e + 1)):
                    if i < len(vs):
                        cmap[c] = utf16_hex(vs[i])
            else:
                base = utf16_hex(r.group(3))
                for off, c in enumerate(range(s, e + 1)):
                    cmap[c] = chr(ord(base) + off)
    return cmap


def build_font_maps(objs):
    fonts = {}
    for n, raw in objs.items():
        if re.search(rb"/Type\s*/Font\b", raw) or re.search(
                rb"/Subtype\s*/(Type0|Type1|TrueType|Type3)", raw):
            m = re.search(rb"/ToUnicode\s+(\d+)\s+0\s+R", raw)
            if m:
                cm = parse_cmap(objs.get(int(m.group(1)), b""))
                if cm:
                    fonts[n] = cm
    return fonts


def tokenize(block):
    toks, i, n = [], 0, len(block)
    while i < n:
        c = block[i:i + 1]
        if c in b" \t\r\n\x00\f":
            i += 1
            continue
        if c == b"(":
            d, j, buf = 1, i + 1, []
            while j < n and d > 0:
                ch = block[j:j + 1]
                if ch == b"\\":
                    buf.append(block[j:j + 2]); j += 2; continue
                if ch == b"(":
                    d += 1
                elif ch == b")":
                    d -= 1
                    if d == 0:
                        j += 1; break
                buf.append(ch); j += 1
            toks.append(("str", b"".join(buf))); i = j; continue
        if c == b"<":
            if block[i:i + 2] == b"<<":
                j = block.find(b">>", i); j = (j + 2) if j != -1 else n
                toks.append(("dict", block[i:j])); i = j; continue
            j = block.find(b">", i); j = (j + 1) if j != -1 else n
            toks.append(("hex", block[i:j])); i = j; continue
        if c == b"[":
            d, j = 1, i + 1
            while j < n and d > 0:
                if block[j:j + 1] == b"[":
                    d += 1
                elif block[j:j + 1] == b"]":
                    d -= 1
                j += 1
            toks.append(("array", block[i:j])); i = j; continue
        if c == b"/":
            m = re.match(rb"/[^\s\[\]<>()/]+", block[i:])
            if m:
                toks.append(("name", m.group(0))); i += len(m.group(0)); continue
        m = re.match(rb"[^\s\[\]<>()/]+", block[i:])
        if m:
            toks.append(("op", m.group(0))); i += len(m.group(0)); continue
        i += 1
    return toks


def decode_literal(b):
    out, i = bytearray(), 0
    while i < len(b):
        c = b[i]
        if c == 0x5C:
            i += 1
            if i >= len(b):
                break
            e = b[i]
            if e == ord("n"):
                out.append(10)
            elif e == ord("r"):
                out.append(13)
            elif e == ord("t"):
                out.append(9)
            elif e == ord("b"):
                out.append(8)
            elif e == ord("f"):
                out.append(12)
            elif e in (ord("("), ord(")"), ord("\\")):
                out.append(e)
            elif chr(e) in "01234567":
                o = bytes([e])
                for _ in range(2):
                    if i + 1 < len(b) and chr(b[i + 1]) in "01234567":
                        i += 1; o += bytes([b[i]])
                    else:
                        break
                out.append(int(o, 8) & 0xFF)
            elif e != 10:
                out.append(e)
        else:
            out.append(c)
        i += 1
    return bytes(out)


def decode_bytes(b, font_obj, fonts):
    if not b:
        return ""
    if b[:2] == b"\xfe\xff":
        return b[2:].decode("utf-16-be", "replace")
    if b[:2] == b"\xff\xfe":
        return b[2:].decode("utf-16-le", "replace")
    cmap = fonts.get(font_obj) if font_obj is not None else None
    if cmap:
        if len(b) % 2 == 0:
            out = []
            for j in range(0, len(b), 2):
                out.append(cmap.get((b[j] << 8) | b[j + 1], "\ufffd"))
            if all(c == "\ufffd" for c in out) and any(k < 256 for k in cmap):
                out = [cmap.get(bb, chr(bb)) for bb in b]
            return "".join(out)
        return "".join(cmap.get(bb, chr(bb)) for bb in b)
    return b.decode("latin-1", "replace")


def _fnum(tok):
    try:
        return float(tok[1])
    except Exception:
        return 0.0


def tj_parts(raw, font_obj, fonts):
    parts = []
    x_adj = 0.0
    for kind, val in tokenize(raw[1:-1]):
        if kind == "str":
            parts.append(decode_bytes(decode_literal(val), font_obj, fonts))
        elif kind == "hex":
            parts.append(decode_bytes(bytes.fromhex(val[1:-1].decode("ascii")),
                                      font_obj, fonts))
        elif kind == "op":
            try:
                x_adj += float(val) * 0.001
            except ValueError:
                pass
    return "".join(parts), x_adj


def extract_content_runs(content, page_fonts, fonts):
    runs = []
    for bt in re.finditer(rb"BT(.*?)ET", content, re.S):
        toks = tokenize(bt.group(1))
        x = y = 0.0
        fs = 10.0
        fo = None
        i = 0
        while i < len(toks):
            kind, val = toks[i]
            if kind == "op":
                if val == b"Tf" and i >= 2:
                    if toks[i - 1][0] == "op":
                        try:
                            fs = float(toks[i - 1][1])
                        except ValueError:
                            pass
                    if toks[i - 2][0] == "name":
                        fo = page_fonts.get(toks[i - 2][1].decode("latin-1").lstrip("/"))
                elif val in (b"Td", b"TD") and i >= 2:
                    x += _fnum(toks[i - 2]); y += _fnum(toks[i - 1])
                elif val == b"Tm" and i >= 6:
                    x = _fnum(toks[i - 2]); y = _fnum(toks[i - 1])
                elif val == b"T*":
                    y -= fs * 1.2
                elif val in (b"Tj", b"'", b'"'):
                    prev = toks[i - 1] if i >= 1 else None
                    if prev and prev[0] in ("str", "hex"):
                        if prev[0] == "str":
                            t = decode_bytes(decode_literal(prev[1]), fo, fonts)
                        else:
                            t = decode_bytes(
                                bytes.fromhex(prev[1][1:-1].decode("ascii")), fo, fonts)
                        if t:
                            runs.append({"x": x, "y": y, "fs": fs, "text": t, "font": fo})
                        if val == b"'":
                            y -= fs * 1.2
                elif val == b"TJ":
                    prev = toks[i - 1] if i >= 1 else None
                    if prev and prev[0] == "array":
                        t, adj = tj_parts(prev[1], fo, fonts)
                        if t:
                            runs.append({"x": x, "y": y, "fs": fs, "text": t, "font": fo})
                            x += adj * fs
            i += 1
    return runs


def get_page_fonts(res_raw, objs):
    pf = {}
    m = re.search(rb"/Font\s*<<(.*?)>>", res_raw, re.S)
    if m:
        for name, ref in re.findall(rb"/([A-Za-z0-9]+)\s+(\d+)\s+0\s+R", m.group(1)):
            pf[name] = int(ref)
    return pf


def parse_pdf_document(data):
    objs = pdf_objects(data)
    fonts = build_font_maps(objs)
    cat = find_catalog(objs, data)
    root = find_pages_root(objs, cat) if cat is not None else None
    page_nums = collect_pages(objs, root) if root is not None else []
    if not page_nums:
        page_nums = [n for n, r in objs.items() if re.search(rb"/Type\s*/Page\b", r)]
    pages = []
    for pn in page_nums:
        raw = objs.get(pn, b"")
        content = b""
        for cr in get_refs(raw, b"Contents"):
            content += decompress(objs.get(cr, b"")) + b"\n"
        res_raw = b""
        for rr in get_refs(raw, b"Resources"):
            res_raw = objs.get(rr, b"")
            break
        pf = get_page_fonts(res_raw, objs)
        mb = num_array(raw, b"MediaBox") or [0, 0, 612, 792]
        w = (mb[2] - mb[0]) if len(mb) >= 3 else 612
        h = (mb[3] - mb[1]) if len(mb) >= 4 else 792
        runs = extract_content_runs(content, pf, fonts) if content else []
        pages.append({"page": len(pages) + 1, "width": w, "height": h,
                      "runs": runs, "raw_runs": len(runs)})
    return pages


def find_pdf_tool():
    for name in ("pdf-text-tool", "pdftotext"):
        p = shutil.which(name)
        if p:
            return p
    root = os.path.join(os.environ.get("LOCALAPPDATA", ""), "com.bohrium.runtime")
    if os.path.isdir(root):
        for dp, _d, fns in os.walk(root):
            for fn in fns:
                if fn.lower() in ("pdftotext.exe", "pdf-text-tool.exe", "pdf-text-tool"):
                    return os.path.join(dp, fn)
    return None


def extract_pdf_via_tool(pdf_path, tool):
    if "pdftotext" in os.path.basename(tool).lower():
        cmd = [tool, "-layout", "-enc", "UTF-8", pdf_path, "-"]
    else:
        cmd = [tool, pdf_path]
    try:
        out = subprocess.run(cmd, capture_output=True, timeout=180)
    except Exception:
        return None
    if out.returncode != 0:
        return None
    try:
        parts = out.stdout.decode("utf-8", "replace").split("\x0c")
    except Exception:
        return None
    while parts and not parts[-1]:
        parts.pop()
    return parts if any(p.strip() for p in parts) else None


def tool_pages_to_blocks(page_texts):
    pages = []
    for i, ptxt in enumerate(page_texts, 1):
        lines = [{"y": j * 12.0, "text": s.rstrip(),
                  "runs": [{"x": 0.0, "fs": 10.0, "text": s.rstrip()}],
                  "xmin": 0.0, "xmax": len(s.rstrip()) * 6.0, "column": 0}
                 for j, s in enumerate(ptxt.splitlines()) if s.strip()]
        pages.append({"page": i, "width": 612.0, "height": 792.0, "runs": [],
                      "raw_runs": len(lines), "lines": lines, "body": lines})
    return pages

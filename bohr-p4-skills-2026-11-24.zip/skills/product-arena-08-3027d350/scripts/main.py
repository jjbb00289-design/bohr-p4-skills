#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""literature-doc-parser: deterministic PDF parsing + output_contract backfill.
Pure stdlib, offline, CWD-independent. Exit code always 0; errors go into result.json."""
import sys, os, json, re, csv, sqlite3, argparse

VERSION = "1.0.0"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)
from pdf_extract import (parse_pdf_document, find_pdf_tool,
                         extract_pdf_via_tool, tool_pages_to_blocks)  # noqa: E402

META = {"case_id", "status", "sources", "uncertainty", "change_records",
        "errors", "degradations", "gaps"}


def log(m):
    sys.stderr.write("[literature-doc-parser] %s\n" % m)


def rb(path):
    with open(path, "rb") as f:
        return f.read()


def rt(path):
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            with open(path, "r", encoding=enc) as f:
                return f.read()
        except (UnicodeDecodeError, ValueError):
            continue
    return None


def jload(txt):
    try:
        return json.loads(txt)
    except Exception:
        return None


# ---------- reading order & structure ----------
def t_width(r):
    return max(1.0, len(r["text"]) * r["fs"] * 0.5)


def group_lines(pages):
    for pg in pages:
        lines = []
        for r in pg["runs"]:
            yt = pg["height"] - r["y"]
            placed = False
            for ln in lines:
                if abs(ln["y"] - yt) < max(2.0, r["fs"] * 0.6):
                    ln["runs"].append(r); placed = True; break
            if not placed:
                lines.append({"y": yt, "runs": [r]})
        for ln in lines:
            ln["runs"].sort(key=lambda r: r["x"])
            ln["text"] = " ".join(r["text"].strip() for r in ln["runs"] if r["text"].strip())
            xs = [r["x"] for r in ln["runs"]]
            ln["xmin"] = min(xs) if xs else 0.0
            ln["xmax"] = max(r["x"] + t_width(r) for r in ln["runs"]) if xs else 0.0
        lines.sort(key=lambda ln: ln["y"])
        pg["lines"] = lines
    return pages


def assign_columns(pages):
    for pg in pages:
        w = pg.get("width", 612)
        lines = pg.get("lines", [])
        cs = [((ln["xmin"] + ln["xmax"]) / 2) for ln in lines if ln["text"]]
        ncols = 2 if cs and (max(cs) - min(cs)) > w * 0.32 else 1
        for ln in lines:
            c = (ln["xmin"] + ln["xmax"]) / 2
            span = ln["xmax"] - ln["xmin"]
            ln["column"] = 0 if (span > w * 0.55 or ncols == 1 or c < w * 0.5) else 1
        pg["ncols"] = ncols
        pg["body"] = [ln for ln in lines if 45 < ln["y"] < pg["height"] - 45]
    return pages


def ordered(pg):
    left = sorted([l for l in pg["body"] if l["column"] == 0], key=lambda l: l["y"])
    right = sorted([l for l in pg["body"] if l["column"] == 1], key=lambda l: l["y"])
    return left + right


H_RE = re.compile(r"^\s*(?:\d+(?:\.\d+)*[\.\)]?\s+[A-Z][A-Za-z\s,&:\-/]{1,60}|\d+\s+[A-Z][A-Za-z\s,&:\-/]{1,60})\s*$")
N_RE = re.compile(r"^\s*(Abstract|Keywords?|Introduction|Background|Methods?|Results?|Discussion|Conclusions?|References|Bibliography|Acknowledg(?:e)?ments?|Appendix|Supplementary|Related Work|Experimental|Summary)\s*:?\s*$", re.I)
C_RE = re.compile(r"^\s*(?:Fig(?:ure)?\.?\s*\d+|Table\.?\s*\d+|Scheme\.?\s*\d+|Equation\.?\s*\d+|Eq\.?\s*\d+)\b", re.I)
R_RE = re.compile(r"^\s*(?:\[\d+(?:\s*[,\-–]\s*\d+)*\]|\d+\.\s)")
A_RE = re.compile(r"^[A-Z][A-Za-z\-'’]+\s+(?:[A-Z]\.\s*)?[A-Z][A-Za-z\-'’]+(?:,\s*[A-Z][A-Za-z\-'’]+\s+(?:[A-Z]\.\s*)?[A-Z][A-Za-z\-'’]+)*")


def classify(doc):
    sections = []
    for pg in doc["pages"]:
        blocks, cur, bid = [], None, 0
        for ln in ordered(pg):
            bid += 1
            t = ln["text"].strip()
            if not t:
                continue
            b = {"id": "p%d-b%d" % (pg["page"], bid), "page": pg["page"], "text": t,
                 "x": round(ln["xmin"], 1), "y": round(ln["y"], 1),
                 "fs": round(ln["runs"][0]["fs"], 1), "column": ln["column"]}
            if C_RE.match(t):
                b["type"] = "caption"
            elif N_RE.match(t) or H_RE.match(t):
                b["type"] = "heading"
                mnum = re.match(r"\s*(\d+(?:\.\d+)*)", t)
                b["level"] = mnum.group(1).count(".") + 1 if mnum else 1
                if b["level"] <= 2:
                    cur = t
                    if not re.match(r"^\s*(Abstract|Summary|Keywords?)\s*:?\s*$", t, re.I):
                        sections.append({"level": b["level"], "title": t,
                                         "page": pg["page"], "id": b["id"]})
                b["section"] = cur
            else:
                b["type"] = "paragraph"; b["section"] = cur
            blocks.append(b)
        pg["blocks"] = blocks
    doc["sections"] = sections
    return doc


def _is_heading(t):
    if N_RE.match(t):
        return True
    return bool(H_RE.match(t)) and len(t) <= 45 and "," not in t


def get_refs_list(blocks):
    refs, inrefs = [], False
    for b in blocks:
        t = b["text"]
        if re.match(r"^\s*(References|Bibliography)\s*:?\s*$", t, re.I):
            inrefs = True
            continue
        if not inrefs:
            continue
        if _is_heading(t):
            inrefs = False
            continue
        if R_RE.match(t) or (len(t) > 20 and t[0].isupper()):
            refs.append(t)
    return refs


def meta(doc):
    pg = doc["pages"][0] if doc["pages"] else None
    title = authors = abstract = abs_first = None
    if pg:
        body = [l for l in ordered(pg) if l["text"].strip()]
        if body[:6]:
            title = max(body[:6], key=lambda l: l["runs"][0]["fs"])["text"].strip()
        for l in body[1:8]:
            t = l["text"].strip()
            if A_RE.match(t) and ("," in t or len(t.split()) >= 3):
                authors = t; break
        abs_l, ina = [], False
        for l in body:
            t = l["text"].strip()
            if re.match(r"^\s*(Abstract|Summary)\s*:?\s*$", t, re.I):
                ina = True; continue
            if ina:
                if H_RE.match(t) or N_RE.match(t):
                    break
                abs_l.append(t)
        if abs_l:
            abstract = " ".join(abs_l)
            abs_first = abs_l[0]
    return title, authors, abstract, abs_first


def norm(s):
    return re.sub(r"\s+", " ", s or "").strip()


def locate(docs, needle):
    n = norm(needle)
    if not n:
        return None
    for d in docs:
        for pg in d["pages"]:
            for b in pg.get("blocks", []):
                if n in norm(b["text"]):
                    return "file=%s;page=%d;block=%s" % (d["path"], pg["page"], b["id"])
    return None


# ---------- material discovery ----------
def discover(input_dir):
    files = []
    for root, dirs, names in os.walk(input_dir):
        for name in sorted(names):
            if name in ("case.json", "task.md"):
                continue
            p = os.path.join(root, name)
            e = os.path.splitext(name)[1].lower()
            kind = {"pdf": "pdf", "txt": "text", "md": "text", "tex": "text",
                    "docx": "docx", "csv": "csv", "tsv": "csv",
                    "sqlite": "sqlite", "db": "sqlite", "json": "json"}.get(e[1:], "image"
                    if e in (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp") else "unknown")
            try:
                size = os.path.getsize(p)
            except OSError:
                size = 0
            files.append({"path": p, "name": name, "kind": kind, "bytes": size})
    return files


# ---------- extraction pipeline ----------
def extract(case, input_dir, work_dir, change):
    errors, degrads = [], []
    inventory = {"input_dir": input_dir, "files": [], "method": "builtin"}
    docs = []
    mats = discover(input_dir)
    for f in mats:
        try:
            data = rb(f["path"])
        except OSError as e:
            errors.append("cannot read %s: %s" % (f["name"], e)); continue
        if f["kind"] == "pdf":
            if data[:5] != b"%PDF-":
                degrads.append("%s: invalid PDF header" % f["name"])
                inventory["files"].append({"path": f["name"], "kind": "pdf",
                                           "bytes": len(data), "status": "skipped"})
                continue
            pages = None
            method = "builtin"
            tool = find_pdf_tool()
            if tool:
                ptxt = extract_pdf_via_tool(f["path"], tool)
                if ptxt:
                    pages = tool_pages_to_blocks(ptxt)
                    method = os.path.basename(tool)
                else:
                    degrads.append("%s: pdf tool (%s) returned no text; builtin fallback"
                                   % (f["name"], os.path.basename(tool)))
            if pages is None:
                try:
                    pages = parse_pdf_document(data)
                    if sum(p["raw_runs"] for p in pages) == 0:
                        degrads.append("%s: no text layer (scanned/image-only); OCR required"
                                       % f["name"])
                    pages = assign_columns(group_lines(pages))
                except Exception as e:
                    errors.append("pdf parse failed %s: %r" % (f["name"], e))
                    inventory["files"].append({"path": f["name"], "kind": "pdf",
                                               "bytes": len(data), "status": "error"})
                    continue
            doc = classify({"path": f["name"], "pages": pages, "type": "pdf"})
            tlen = sum(len(b["text"]) for p in pages for b in p.get("blocks", []))
            doc["text_len"] = tlen
            docs.append(doc)
            inventory["method"] = method
            inventory["files"].append({"path": f["name"], "kind": "pdf",
                                       "bytes": len(data), "pages": len(pages),
                                       "text_len": tlen, "method": method,
                                       "status": "extracted"})
        elif f["kind"] == "text":
            txt = rt(f["path"]) or ""
            docs.append({"path": f["name"], "type": "text",
                         "pages": [{"page": 1, "width": 0, "height": 0, "lines": [],
                                    "blocks": [{"id": "p1-b1", "page": 1, "text": txt,
                                                "type": "paragraph", "x": 0, "y": 0,
                                                "fs": 0, "column": 0}]}], "sections": []})
            inventory["files"].append({"path": f["name"], "kind": "text",
                                       "bytes": len(data), "status": "extracted"})
        elif f["kind"] == "csv":
            try:
                rows = []
                with open(f["path"], "r", encoding="utf-8", errors="replace", newline="") as fh:
                    rows = [r for r in csv.reader(fh)]
                docs.append({"path": f["name"], "type": "csv", "table": rows, "pages": []})
                inventory["files"].append({"path": f["name"], "kind": "csv",
                                           "bytes": len(data), "status": "extracted"})
            except Exception as e:
                errors.append("csv parse failed %s: %r" % (f["name"], e))
        elif f["kind"] == "sqlite":
            try:
                con = sqlite3.connect(f["path"]); cur = con.cursor()
                cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = [r[0] for r in cur.fetchall()]; con.close()
                docs.append({"path": f["name"], "type": "sqlite", "tables": tables,
                             "pages": []})
                inventory["files"].append({"path": f["name"], "kind": "sqlite",
                                           "bytes": len(data), "status": "extracted"})
            except Exception as e:
                errors.append("sqlite parse failed %s: %r" % (f["name"], e))
        elif f["kind"] == "image":
            degrads.append("%s: image; not OCR-extracted (defer to ocr-tool)" % f["name"])
            inventory["files"].append({"path": f["name"], "kind": "image",
                                       "bytes": len(data), "status": "deferred"})
        elif f["kind"] == "json":
            docs.append({"path": f["name"], "type": "json",
                         "json": jload(rt(f["path"]) or ""), "pages": []})
            inventory["files"].append({"path": f["name"], "kind": "json",
                                       "bytes": len(data), "status": "extracted"})
        else:
            degrads.append("%s: unsupported kind '%s'" % (f["name"], f["kind"]))
            inventory["files"].append({"path": f["name"], "kind": f["kind"],
                                       "bytes": len(data), "status": "skipped"})
    inventory["files"].sort(key=lambda x: x["path"])
    extraction = {"inventory": inventory, "documents": docs}
    os.makedirs(work_dir, exist_ok=True)
    with open(os.path.join(work_dir, "extraction.json"), "w", encoding="utf-8") as fh:
        json.dump(extraction, fh, ensure_ascii=False, indent=2)
    change.append({"step": 2, "action": "extract",
                   "detail": "%d material(s), %d document(s), method=%s"
                   % (len(mats), len(docs), inventory["method"])})
    return extraction, errors, degrads


# ---------- contract backfill ----------
def fill_contract(contract, docs):
    sources, gaps, unc = [], [], []
    blocks = [b for d in docs for p in d.get("pages", []) for b in p.get("blocks", [])]
    full = "\n\n".join(b["text"] for b in blocks)

    def src(field, quote, loc=None, reason=None):
        if not quote:
            return
        loc = loc or locate(docs, quote)
        sources.append({"field": field, "locator": loc or "n/a", "quote": quote})
        if loc is None:
            unc.append({"field": field, "level": "high",
                        "reason": reason or "quote not located in extracted text"})

    def fill(name):
        n = name.lower()
        if not docs:
            gaps.append({"field": name, "reason": "no documents extracted"}); return None
        d = docs[0]
        title, authors, abstract, abs_first = meta(d)
        if n in ("title", "paper_title", "article_title"):
            if title:
                src(name, title)
            else:
                gaps.append({"field": name, "reason": "title not detected"})
            return title
        if n in ("authors", "author", "author_list"):
            if authors:
                src(name, authors)
            else:
                gaps.append({"field": name, "reason": "authors not detected"})
            return authors
        if n in ("abstract", "summary_abstract"):
            if abstract:
                src(name, abs_first or abstract)
            else:
                gaps.append({"field": name, "reason": "abstract not detected"})
            return abstract
        if n in ("full_text", "text", "content", "body"):
            src(name, blocks[0]["text"] if blocks else "") if blocks else None
            return full
        if n in ("sections", "headings", "section_list", "toc"):
            v = d.get("sections", [])
            if v:
                src(name, v[0]["title"],
                    loc="file=%s;page=%d;block=%s" % (d["path"], v[0]["page"], v[0]["id"]))
            else:
                gaps.append({"field": name, "reason": "no headings detected"})
            return v
        if n in ("references", "bibliography", "refs"):
            v = get_refs_list(blocks)
            if v: src(name, v[0])
            else: gaps.append({"field": name, "reason": "no reference section"})
            return v
        if n in ("figures", "figure_captions"):
            v = [b["text"] for b in blocks if b["type"] == "caption"
                 and re.match(r"\s*(Fig|Figure)", b["text"], re.I)]
            if v: src(name, v[0])
            return v
        if n in ("tables", "table_captions"):
            v = [b["text"] for b in blocks if b["type"] == "caption"
                 and re.match(r"\s*Table", b["text"], re.I)]
            if v: src(name, v[0])
            return v
        if n in ("equations", "formulas", "equation_list"):
            v = [b["text"] for b in blocks if b["type"] == "caption"
                 and re.match(r"\s*(Eq|Equation)", b["text"], re.I)]
            if v: src(name, v[0])
            return v
        if n in ("captions", "figure_table_captions"):
            v = [b["text"] for b in blocks if b["type"] == "caption"]
            if v: src(name, v[0])
            return v
        if n in ("keywords", "key_words"):
            for b in blocks:
                m = re.match(r"^\s*(?:Keywords?|Key words)\s*:?\s*(.+)$", b["text"], re.I)
                if m:
                    v = [k.strip() for k in re.split(r"[;,]", m.group(1)) if k.strip()]
                    src(name, b["text"]); return v
            gaps.append({"field": name, "reason": "keywords not detected"}); return None
        if n in ("summary", "translation", "translated_abstract", "chinese_abstract",
                 "answer", "answers", "questions", "qa", "knowledge_graph",
                 "entities", "notes", "explanation", "conclusion_summary"):
            gaps.append({"field": name,
                         "reason": "semantic field; complete by agent from extraction.json quotes"})
            unc.append({"field": name, "level": "high",
                        "reason": "requires model reasoning"})
            return None
        for b in blocks:
            if n in b["text"].lower():
                src(name, b["text"]); return b["text"]
        gaps.append({"field": name, "reason": "unrecognized field; no deterministic mapping"})
        return None

    out = {}
    if isinstance(contract, dict):
        for k in contract:
            out[k] = fill(k)
    elif isinstance(contract, list):
        for item in contract:
            if isinstance(item, str):
                out[item] = fill(item)
            elif isinstance(item, dict):
                for k in item:
                    out[k] = fill(k)
    return out, sources, gaps, unc


# ---------- result assembly ----------
def build(case, extraction, errors, degrads, change):
    cid = case.get("case_id") if isinstance(case, dict) else None
    contract = case.get("output_contract") if isinstance(case, dict) else None
    contract = contract if isinstance(contract, (dict, list)) else {}
    docs = extraction.get("documents", [])
    filled, sources, gaps, unc = fill_contract(contract, docs)
    result = {"case_id": cid}
    collision = []
    for k, v in filled.items():
        if k in META:
            collision.append(k)
        else:
            result[k] = v
    if collision:
        result["output"] = {k: filled[k] for k in collision}
        change.append({"step": 3, "action": "fill_contract",
                       "detail": "contract keys collided with meta: %s" % ", ".join(collision)})
    if cid is None:
        status = "input_error"
    elif not docs and not errors and not degrads:
        status = "insufficient_evidence"
    elif errors or degrads or gaps or unc:
        status = "partial"
    else:
        status = "success"
    result["status"] = status
    result["sources"] = sources
    result["uncertainty"] = unc
    result["change_records"] = change
    result["errors"] = errors
    result["degradations"] = degrads
    result["gaps"] = gaps
    return result


def load_case(input_dir):
    p = os.path.join(input_dir, "case.json")
    if not os.path.exists(p):
        return {}, "case.json missing"
    case = jload(rt(p))
    if case is None or not isinstance(case, dict):
        return {}, "case.json invalid JSON"
    return case, None


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    ap = argparse.ArgumentParser(prog="literature-doc-parser",
                                 description="PDF parsing + contract backfill.")
    ap.add_argument("commands", nargs="*", help="init/show/check/build (default full)")
    ap.add_argument("-i", "--input-dir", default=os.environ.get("INPUT_DIR", "/input"))
    ap.add_argument("-w", "--work-dir", default=os.environ.get("WORK_DIR", "/app/work"))
    ap.add_argument("-o", "--output-dir", default=os.environ.get("OUTPUT_DIR", "/app/output"))
    a = ap.parse_args(argv)
    cmds = a.commands or ["init", "build"]
    errors, degrads = [], []
    change = [{"step": 1, "action": "init", "detail": "v%s" % VERSION}]
    try:
        os.makedirs(a.work_dir, exist_ok=True)
    except OSError as e:
        errors.append("cannot create work dir: %r" % e)
    try:
        os.makedirs(a.output_dir, exist_ok=True)
    except OSError as e:
        errors.append("cannot create output dir: %r" % e)
    out_target = os.path.join(a.output_dir, "result.json")
    if not os.path.isdir(a.output_dir):
        out_target = os.path.join(a.work_dir, "result.json")  # fallback
    case, cerr = load_case(a.input_dir)
    if cerr:
        errors.append(cerr)
    if "init" in cmds:
        try:
            ext, e2, d2 = extract(case, a.input_dir, a.work_dir, change)
            errors += e2; degrads += d2
        except Exception as e:
            ext = {"inventory": {"files": []}, "documents": []}
            errors.append("extraction failed: %r" % e)
            with open(os.path.join(a.work_dir, "extraction.json"), "w",
                      encoding="utf-8") as fh:
                json.dump(ext, fh, ensure_ascii=False, indent=2)
        with open(os.path.join(a.work_dir, "result.partial.json"), "w",
                  encoding="utf-8") as fh:
            json.dump({"case_id": case.get("case_id"),
                       "status": "partial",
                       "note": "pre-extraction partial"}, fh, ensure_ascii=False, indent=2)
    ext_path = os.path.join(a.work_dir, "extraction.json")
    ext = jload(rt(ext_path)) if os.path.exists(ext_path) else None
    if ext is None:
        ext = {"inventory": {"files": []}, "documents": []}
    if "build" in cmds:
        try:
            result = build(case, ext, errors, degrads, change)
            change.append({"step": 4, "action": "finalize",
                           "detail": "result.json written"})
            result["change_records"] = change
            with open(out_target, "w", encoding="utf-8") as fh:
                json.dump(result, fh, ensure_ascii=False, indent=2)
            log("result.json written (status=%s)" % result["status"])
        except Exception as e:
            errors.append("build failed: %r" % e)
            result = {"case_id": case.get("case_id"), "status": "input_error",
                      "sources": [], "uncertainty": [], "change_records": change,
                      "errors": errors, "degradations": degrads, "gaps": []}
            try:
                with open(out_target, "w", encoding="utf-8") as fh:
                    json.dump(result, fh, ensure_ascii=False, indent=2)
            except Exception:
                pass
    if "show" in cmds:
        for d in ext.get("documents", []):
            log("doc=%s type=%s pages=%d" % (d.get("path"), d.get("type"),
                                             len(d.get("pages", []))))
            for pg in d.get("pages", [])[:3]:
                log("  page %d: %d blocks" % (pg.get("page"), len(pg.get("blocks", []))))
    if "check" in cmds:
        rp = out_target if os.path.exists(out_target) else os.path.join(a.output_dir, "result.json")
        issues = []
        if not os.path.exists(rp):
            issues.append("result.json missing")
        else:
            res = jload(rt(rp))
            if not isinstance(res, dict):
                issues.append("result.json not object")
            else:
                if "case_id" not in res:
                    issues.append("missing case_id")
                if res.get("status") not in ("success", "partial",
                                             "insufficient_evidence", "input_error"):
                    issues.append("bad status %r" % res.get("status"))
                contract = case.get("output_contract") if isinstance(case, dict) else {}
                if isinstance(contract, dict):
                    for k in contract:
                        if k not in res:
                            issues.append("missing contract key %s" % k)
                hits = total = 0
                for s in res.get("sources", []):
                    q = norm(s.get("quote", ""))
                    if q:
                        total += 1
                        if any(q in norm(b["text"]) for d in ext.get("documents", [])
                               for p in d.get("pages", []) for b in p.get("blocks", [])):
                            hits += 1
                if total and hits / total < 0.95:
                    issues.append("quote hit-rate %.2f (%d/%d)" % (hits / total, hits, total))
        for i in issues:
            log("CHECK-FAIL: %s" % i)
        if not issues:
            log("CHECK-OK")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except Exception as e:
        sys.stderr.write("[literature-doc-parser] FATAL: %r\n" % e)
        sys.exit(0)

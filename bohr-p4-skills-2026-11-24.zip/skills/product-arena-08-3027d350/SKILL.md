---
name: literature-doc-parser
description: Deterministic scientific-PDF/document parsing skill for the "文献文档解析" benchmark. Extracts full text with reading-order repair (multi-column), section hierarchy, table/figure/equation captions, footnotes and references from real PDFs, then back-fills every output_contract field in the case with page/block locators and verbatim quotes. Handles text-layer PDFs natively (pure stdlib, offline); honest degradation for scanned/encrypted/image-only pages. Use when a case requires reading, parsing, translating, question-answering, extraction, verification or knowledge structuring of PDF documents.
version: 1.0.0
---

# literature-doc-parser — 文献文档解析 Skill

## 1. 用途（What this does）

把科研 PDF（及其他文本材料）确定性地拆成**可复核的结构化结果**，并把案例要求的每个字段回填到 `result.json`。本 Skill 解决四个核心问题：

- **提得全**：正文、图表题注、脚注、参考文献逐字提取，页眉页脚单独归置、不混入正文。
- **排得对**：按版面几何修复双栏/多栏阅读顺序，不串栏、不错行。
- **拆得清**：识别章节层级、段落、图表/公式题注与参考文献。
- **核得回**：每条结论携带 `page` + `block` 定位与**逐字 quote**，读不出的部分如实标 `gap`，绝不猜测补齐。

图表与公式按**结构元素**识别（题注、编号、位置），不解释其科学含义。

## 2. 触发条件（When to use）

- 案例 `task_instruction` 涉及：解析/阅读 PDF、翻译、问答、数据提取、核验、知识结构化、笔记、图谱。
- 输入目录含 PDF、DOCX、TXT、CSV、图片、SQLite 等材料。
- 需要产出带证据定位的 `result.json`。

**何时不要用**：材料是纯文本且任务不要求回到 PDF 页码定位时，直接读文本即可；本 Skill 仍可用于统一结构化与证据标注。

## 3. 调用方式（How to invoke）

主脚本是纯 Python 标准库、不联网、不依赖当前工作目录。运行环境为 Linux 容器，路径约定：

- 输入目录 `/input`（含 `case.json`、`task.md` 与材料文件）
- 工作稿目录 `/app/work`
- 输出目录 `/app/output`

```bash
# 完整流程（推荐默认）：读取输入 → 抽取 → 结构化 → 回填契约 → 写 result.json
python /skills/weekly-skill/scripts/main.py

# 分步（便于人工接管）
python /skills/weekly-skill/scripts/main.py init      # 只抽取，写工作稿
python /skills/weekly-skill/scripts/main.py show      # 打印工作稿摘要
python /skills/weekly-skill/scripts/main.py build     # 回填契约并写 result.json
python /skills/weekly-skill/scripts/main.py check     # 校验 result.json 契约完整性
```

可选参数（默认值取环境变量，缺省为运行时约定路径）：

```bash
python main.py --input-dir /input --work-dir /app/work --output-dir /app/output
```

**脚本定位自身资源**：使用 `Path(__file__).resolve().parent`，不依赖 CWD。退出码恒为 0；所有异常写入 `result.json` 的 `errors`/`degradations`。

## 4. Agent 完整工作流（务必遵循）

1. **读题**：读取 `/input/case.json`（含 `case_id`、`output_contract`、`task_instruction`）与 `/input/task.md`。
2. **跑抽取**：执行 `python main.py`（默认完整流程）。脚本会：
   - 枚举 `/input` 下全部材料（PDF/DOCX/TXT/CSV/SQLite/图片），对 PDF 优先调用平台 `pdf-text-tool`（若为可用 CLI），否则用内置 zlib+文本算子抽取，并在 `degradations` 记录所用方法；
   - 产出工作稿 `/app/work/extraction.json` 与 `/app/work/result.partial.json`；
   - 用启发式把能确定的契约字段先回填，写 `/app/output/result.json`。
3. **复核与补全（LLM 职责）**：阅读 `/app/work/extraction.json`（含逐字正文与定位），针对脚本无法确定的字段（如“翻译/摘要/问答/图谱/主观判断”）用模型推理补全，**答案只能取自 extraction.json 中的 quote**；每条补全结论补一条 `sources` 项（`field` + `locator` + 逐字 `quote`）。
4. **写最终结果**：编辑 `/app/output/result.json`，保证：
   - 顶层含 `case_id` 与 `output_contract` 的**每一个字段**（缺值用 `null`/`[]`，不删键、不改名）；
   - 含 `status`、`sources`、`uncertainty`、`change_records`、`errors`、`degradations`、`gaps`；
   - `status` 取 `success | partial | insufficient_evidence | input_error` 之一。
5. **核对**：执行 `python main.py check`，确认契约键齐全、quote 能在材料原文命中。

**模型请求预算**：64 次请求、900 秒。优先直接读取脚本产物文件（1 次读取即得全文），不要逐页重复调用工具。

## 5. 输入输出（I/O contract）

**输入**（脚本自动发现，无需手写清单）：

- `case.json`：`{"case_id": str, "output_contract": {...}, "task_instruction": str, ...}`
- `task.md`：任务说明（可选，存在则并入工作稿）
- 材料：任意文件名；PDF 为真实文件，**无预抽文本层**，脚本实际读取字节解析，不按文件名/标签假设内容。

**输出**（`/app/output/result.json`）：

```json
{
  "case_id": "case-…",
  "<output_contract 字段逐个回填>": "<真实派生的值 / null / []>",
  "status": "partial",
  "sources": [{"field": "title", "locator": "file=paper.pdf;page=1;block=2", "quote": "…逐字原文…"}],
  "uncertainty": [{"field": "…", "level": "low|medium|high", "reason": "…"}],
  "change_records": [{"step": 1, "action": "init", "detail": "…"}],
  "errors": [],
  "degradations": [],
  "gaps": [{"field": "…", "reason": "…"}]
}
```

## 6. 工作稿 schema（/app/work/extraction.json）

```json
{
  "inventory": {"input_dir": "…", "files": [{"path": "…", "kind": "pdf|docx|txt|…", "bytes": 12345}], "method": "pdf-text-tool|builtin"},
  "documents": [{
    "path": "paper.pdf", "pages": 3,
    "title": "…", "authors": "…", "abstract": "…",
    "pages": [{
      "page": 1, "width": 612.0, "height": 792.0,
      "blocks": [{
        "id": "p1-b2", "type": "heading|paragraph|caption|table|footnote|reference|header|footer",
        "section": "1. Introduction", "column": 0,
        "text": "…", "x": 72.0, "y": 690.0, "fs": 10.0
      }]
    }]
  }]
}
```

`locator` 约定：`file=<文件名>;page=<页码>;block=<块id>`；对表格/公式补 `table=`/`eq=` 编号。

## 7. 证据规范（Evidence rules）

- 每个非空契约字段值都必须在 `sources` 有对应 `quote`；`quote` 必须能在材料原文（extraction.json 的 `text`）中**逐字命中**。
- 读不出、无法判断、材料冲突：字段值 `null`/`[]`，并在 `gaps`/`uncertainty` 说明具体原因与可人工接管位置。
- 不得编造数据、软件状态、检索结果、缺失文本；不得用“看起来像”的段落补空白。

## 8. 降级表（Degradation / failure handling）

| 情形 | 处置 | status |
|-|-|-|
| 正常文本层 PDF | builtin 抽取，逐字+定位 | success |
| 平台 `pdf-text-tool` 可用 | 优先用它，`method` 记录 | success |
| 扫描版/无文本层页面 | 提取为空 → 记 `gap`“需要 OCR”，不猜内容 | insufficient_evidence 或 partial |
| 加密 PDF | 无法解密 → 记 `error`，其余材料继续 | partial |
| 图片型表格/乱码字体 | 记 `degradation` + 定位，正文尽量保 ASCII | partial |
| 空输入/无材料 | 产出合法 `result.json`，字段 `null` | insufficient_evidence |
| `case.json` 缺失/坏 JSON | 产出合法 `result.json`，`case_id=null` | input_error |
| 权限不足 | 捕获异常记 `errors`，退出码仍 0 | input_error / partial |

## 9. 自检（Self-check）

`python main.py check` 校验：契约键齐全、`case_id` 存在、`status` 合法、`sources[].quote` 能在工作稿命中、无空契约键。失败项打印到 stderr 但退出码仍 0。

## 10. 限制（Limitations）

- builtin 抽取对 `ToUnicode` 缺失的符号字体（数学公式的希腊字母/上下标）可能保留为近似或 `?`；此时如实标注，不伪造符号。
- 跨栏续接按“左栏读完→右栏”排序，复杂异形版面（三栏、跨页大图）可能局部错序，记录在 `degradations`。
- 表格做行级还原与合并单元格识别；跨页续表尽力拼接，无法确定归属时标 `gap`。
- 不联网、不安装第三方包、无模型调用；语义类字段（翻译/问答/摘要/图谱）由 Agent 基于工作稿补全。

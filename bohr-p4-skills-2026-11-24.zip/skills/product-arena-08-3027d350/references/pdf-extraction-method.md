# PDF extraction method — technical reference

## Built-in extractor pipeline (pdf_extract.py)

Pure Python standard library, no third-party dependencies, offline. Steps:

1. **Object discovery**: regex scan for `N G obj … endobj` blocks (no xref dependence, tolerates malformed/linearized files).
2. **Page tree traversal**: `/Catalog → /Pages → /Kids`; page order preserved by tree walk, not by object number.
3. **Content streams**: resolve `/Contents` (single ref or array), locate `/Filter /FlateDecode`, decompress with `zlib`.
4. **Text runs**: tokenize each `BT…ET` block; parse state operators `Tf` (font+size), `Td`/`TD` (offset), `Tm` (matrix), `T*` (newline) and text-showing operators `Tj`/`'`/`"` (string) and `TJ` (array with kerning). Each run carries `(x, y, font-size, text)`.
5. **Glyph decoding**: UTF-16BE/LE BOM handled directly; `ToUnicode` CMap (`bfchar`/`bfrange`) parsed for CID/Type0 fonts; Latin-1 fallback for Type1/WinAnsi fonts (ASCII scientific text decodes exactly; symbol/glyph fonts degrade to `\ufffd`, reported honestly).
6. **Reading order**: runs grouped into lines by y; line text sorted by x. Columns detected by center-x spread (`> 0.32 × page width`); full-width lines (`> 0.55 × width`) forced to column 0. Body lines ordered "column 0 top→bottom, then column 1 top→bottom", which matches continuous-flow two-column journals. Headers/footers (`y ≤ 45` or `y ≥ height−45`) excluded from body.
7. **Structure**: headings by numbered pattern (`1.` / `1.1`) or named pattern (Abstract/Introduction/…/References); captions by `Figure/Table/Scheme/Equation/Eq` prefix; references by `[n]` / `n.` after a References heading; title = largest-font line on page 1; authors by name-list pattern; abstract between Abstract heading and next heading.

## Locator convention

`file=<basename>;page=<n>;block=<p<n>-b<k>>` for text blocks; `page` and `block` are stable across runs (deterministic). Every `sources[].quote` is a verbatim substring of an extracted block.

## Limits

- Symbol/math fonts without `ToUnicode` may yield `\ufffd`; never guessed or substituted.
- Cross-column continuation is "left column fully then right column"; unusual layouts (3+ columns, spanning figures) may be locally mis-ordered and are flagged in `degradations`.
- Tables: caption and row text are extracted; cell-grid reconstruction is partial (no border analysis).
- Scanned/image-only pages produce zero text runs and are reported as `no text layer` (OCR is out of scope for the offline stdlib path; the agent may invoke the platform `ocr-tool`).

# 相关性计分与去重规则（复用说明）

本 Skill 的排序/去重为确定性启发式，非语义检索；规则写在此处供他人复核与复用。

## 去重优先级

1. `doi`（规范化：去前缀 `https://doi.org/`、`doi:`，去尾标点，小写）——最可靠；
2. 规范化标题（去空格/标点，小写，取前 120 字符）；
3. 第一作者 + 年份 + 标题前 40 字符；
4. 兜底：`source.path + "#" + source.locator`（同一来源同一位置视为同一记录）。

合并时保留元数据最完整的记录（title/doi/year/venue 各计 1 分，authors 计 1 分，取分高者），证据与术语并集，证据按 `query_id/term/field` 排序。

## 相关性计分（排序）

```
score = Σ round_weight(round) × field_weight(field)
      + 0.05 × distinct_terms
      + 0.02×[有DOI] + 0.02×[有标题] + 0.01×[有年份]
```

- `round_weight`：round 0（主词）=1.0，round 1（同义词/缩写）=0.85，round 2（跨语言，若启用）=0.7。
- `field_weight`：title=3.0，doi=2.5，venue=1.2，authors=1.0，body=0.6，year=0.4。
- 排序：score 降序 → 年份降序（无年份置后）→ 标题升序。

## nDCG / Precision@k 思路

- 若案例在 `case.json` 提供 `gold_relevant`（DOI 或标题列表），按 DOI 优先、标题次之归一化匹配，输出 `P@5`、`P@10`、`recall_of_gold` 与命中记录 id。
- 若未提供黄金相关集，`precision_at_k.available=false`，只记录方法，不编造数值（避免无金标准的假指标）。

## 证据规范

每条候选必须有 `source.path`（相对 `/input`）+ `source.locator`（JSON 路径 / `csv.row[i]` / `sqlite.<table>.row[i]` / `text.char[i]`）+ 非空 `quote`；`quote` 以 DOI 或标题为 anchor 在材料原文中定位并截取窗口，逐字取自材料。命中证据保留在 `evidence[]`（query_id、round、term、field、quote、round_weight）。

## 覆盖与遗漏

- 无结果查询：保留 `query_id/term/variants` 于 `coverage.empty_queries`。
- 不可解析材料（扫描 PDF/图片/坏 JSON）：进入 `coverage.unparseable_materials` 与 `degradations`。
- 缺失元数据：逐候选记录缺失字段于 `coverage.missing_metadata`。
- 权限/打开失败：进入 `errors`。

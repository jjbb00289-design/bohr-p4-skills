---
name: source-bound-literature-retrieval
description: 离线、以本地材料为唯一事实来源的科研文献检索与筛选 Skill。围绕科研问题拆解检索需求，在给定材料语料（Crossref/EuropePMC/出版商响应、参考文献图、SQLite、PDF、DOCX、CSV/XML/文本）上执行多轮查询，输出可逐条回溯的候选文献集、去重记录、相关性排序与覆盖/遗漏说明。不联网、不编造元数据，每条候选都带来源定位与逐字证据片段。
version: 1.0.0
---

# 科研检索：找到文献，也保留筛选依据（source-bound）

## 用途

对给定的科研问题，在**本地材料语料**上完成可复核的文献检索与筛选，交付：

1. 检索问题拆解（研究问题、概念、检索范围与排除条件）；
2. 多轮查询计划（含同义词、缩写、跨语言扩展）；
3. 候选文献集（每条含 `title / authors / year / venue / doi / source / locator / quote`）；
4. 去重与来源记录（DOI 优先 → 规范化标题 → 作者+年份+标题前缀）；
5. 相关性排序（含 nDCG / Precision@k 的算法说明，若案例给黄金相关集则计算数值）；
6. 覆盖与遗漏说明（空查询、无法解析的材料、缺失元数据、权限异常）。

适用条件：输入为 `case.json` + `task.md` + 材料语料；材料为离线文件（JSON/XML/CSV/TXT/PDF/DOCX/SQLite/引用图）。**不做实时联网检索**，不声称“最新/全球新发”，不补造 DOI、作者、年份、期刊或全文。

## 触发条件

- 输入目录存在 `case.json`（含 `case_id`、`task_instruction`、`output_contract`）；
- 任务要求从给定材料中检索并筛选文献，且材料以本地文件提供；
- 不适用于：需要实时数据库检索、事实核验或临床/政策决策的任务（见“限制”）。

## 调用方式

```bash
# 完整流程（默认）
python scripts/main.py
# 或显式指定目录 / 子命令
python scripts/main.py --input /input --work /app/work --output /app/output
python scripts/main.py init     # 仅建目录并写空 input 快照
python scripts/main.py show     # 打印材料清单与已提取记录摘要
python scripts/main.py check    # 校验输出目录 result.json 合法性并退出 0
python scripts/main.py build    # 从已有 work 草稿直接 finalize（不重跑材料解析）
```

环境变量覆盖：`INPUT_DIR` / `WORK_DIR` / `OUTPUT_DIR`（命令行参数优先于环境变量，默认平台路径 `/input`、`/app/work`、`/app/output`）。脚本不依赖当前工作目录（一律以 `Path(__file__).resolve().parent` 定位资源）；纯 Python 标准库，无网络访问。

## 输入

- `/input/case.json`：`case_id`、`task_instruction`（或 `content`/`task`）、可选 `keywords`、`output_contract`、可选 `gold_relevant`（黄金相关文献集）。
- `/input/task.md`：任务说明（可选，缺失不报错）。
- `/input/**` 其他全部文件：材料语料。递归 `os.walk` 扫描所有子目录；`case.json` 与 `task.md` 本身不计为材料。

## 输出

工作稿写入 `WORK_DIR`，最终产物写入 `OUTPUT_DIR`：

```
work/01_input.json       输入快照（case_id、task_instruction、contract、材料清单）
work/02_materials.json   材料清单：rel_path、kind、大小、解析状态、错误
work/03_records.json     每条提取记录：字段、source、locator、text_span、context_text
work/04_query_plan.json  查询计划（轮次、术语、扩展来源）
work/05_query_evidence.json 每轮每查询的命中（含空结果查询）
work/06_candidates.json  去重后的候选集
work/07_ranking.json     排序结果与计分方法
work/08_coverage.json    遗漏、未解析、缺失元数据
work/partial_result.json 早期落盘的部分结果
work/final_result.json   最终结果副本
output/result.json       最终交付（唯一正式结果）
```

`result.json` 顶层必须包含：`case_id`、`status`、`sources`、`uncertainty`、`change_records`、`errors`、`degradations`、`gaps`，并**原样回填** `case.json.output_contract` 的每个字段（缺值用 `null` 或 `[]`，不更名、不漏键）。主结果按规范键写入：`research_question`、`query_plan`、`query_evidence`、`candidates`、`ranking`、`dedup_records`、`coverage`。

`status` 取值：`complete`（有候选且证据完整）、`partial`（部分完成，注明缺口）、`insufficient_evidence`（材料存在但无足够证据）、`input_error`（case.json 缺失/坏 JSON）。

## 工作稿 schema

每条记录（`03_records.json`、`06_candidates.json`）：

```json
{
  "record_id": "r0001",
  "title": "…" | null,
  "authors": ["…"] | [],
  "year": 2023 | null,
  "venue": "…" | null,
  "doi": "10.…" | null,
  "source": {"path": "materials/crossref.json", "locator": "message.items[3]"},
  "text_span": [start, end],
  "context_text": "材料原文中命中 anchor 的逐字片段",
  "searchable": "title+authors+year+venue+doi+context_text"
}
```

每条候选（`candidates`）另附 `evidence`：查询词 + 命中字段 + 逐字片段 + 来源定位。查询证据（`query_evidence`）保留**无结果查询**并说明原因。

## 证据规范

- 每条候选必须能指回 `source.path`（相对 `/input` 的路径）+ `source.locator`（JSON 路径 / 表名+行 / 字符偏移 / 页码）+ `quote`（逐字片段）。
- `quote` 必须能在材料原文中逐字命中：结构化记录以 DOI 或标题为 anchor 在原始文本中定位并截取窗口；PDF/DOCX/SQLite 以提取文本为原文。
- 缺失字段一律 `null`/`[]`，不得推测或补造。
- 空查询、未解析材料、权限错误分别进入 `coverage` / `degradations` / `errors`，不得静默丢弃。

## 降级表

| 情形 | 处置 | status 影响 |
|-|-|-|
| case.json 缺失 | 写 `input_error` partial，errors 记录 | input_error |
| case.json 坏 JSON | 同上 | input_error |
| task.md 缺失 | 仅用 task_instruction，不报错 | 无 |
| 材料目录为空 | `insufficient_evidence`，gaps 说明 | insufficient_evidence |
| 材料无任何可提取记录 | `insufficient_evidence` | insufficient_evidence |
| PDF 无文本层/扫描件 | 尝试纯 Python 抽取；失败则标 unparseable | partial + degradations |
| 图片/表格无 OCR | 标 unparseable，不编造 | partial + degradations |
| SQLite 无 schema 读取权限 | errors 记录，跳过该表 | partial |
| 无结果查询 | 保留在 query_evidence，写入 coverage | 视情况 partial |
| 缺 DOI/年份/期刊 | 字段置 null，写入 coverage.missing_metadata | 无 |
| output_contract 字段无法映射 | 置 null/[]，不更名不漏键 | 无 |

## 自检（check 子命令）

1. `result.json` 可解析且非 0 字节；
2. 含 `case_id`、`status`、`sources`、`uncertainty`、`change_records`；
3. `output_contract` 每个键都在 `result.json` 中；
4. 每条候选有 `source.path`、`source.locator`、`quote` 且 quote 非空；
5. 无占位符（不含 `placeholder`、`TBD`、`array`、`object`、`…` 等作为值）。

自检失败仅报告，仍退出 0（评测靠人工/平台判分，脚本不因自检失败而崩）。

## 限制

- 不联网、不实时检索，只检索给定本地材料；不声称时效性、新颖性或“最新文献”。
- 不替代同行评审、事实核验、临床/政策决策或研究结论。
- 自由文本（PDF 全文）的标题/作者结构化抽取是尽力而为，可能为 `null`；结构化响应（Crossref/EuropePMC JSON）元数据最可靠。
- 无 OCR、无图像理解；扫描 PDF 与图片标注为不可解析，不产出猜测结果。
- 查询扩展依赖 `references/synonyms.json` 与确定性启发式，非语义检索；不做 LLM 调用。
- 未提供 GitHub 公开链接，故不生成 `GITHUB_URL.txt`。

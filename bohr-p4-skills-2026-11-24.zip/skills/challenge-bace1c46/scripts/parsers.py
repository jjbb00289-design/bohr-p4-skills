#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""材料发现与解析：纯标准库，离线。"""
import csv
import io
import json
import os
import re
import sqlite3
import zipfile
import zlib
from pathlib import Path
from xml.etree import ElementTree as ET

DOI_RE = re.compile(r"10\.\d{4,9}/[^\s\"'<>\[\](){}]+", re.I)
SKIP = {"case.json", "task.md"}
FIELDS = {
    "doi": ["doi", "DOI", "paperDoi", "articleDoi"],
    "title": ["title", "articleTitle", "titleText", "heading", "publicationTitle"],
    "authors": ["author", "authors", "authorString", "creator", "creators",
                "authorList"],
    "year": ["year", "pubYear", "publicationYear", "publishedYear",
             "yearPublished"],
    "venue": ["journal", "journalTitle", "container-title", "containerTitle",
              "publicationTitle", "booktitle", "source", "venue", "journalName"],
}


def discover_materials(input_dir):
    items, errors = [], []
    for root, dirs, files in os.walk(input_dir):
        dirs.sort()
        for fn in sorted(files):
            if fn.lower() in SKIP:
                continue
            ap = os.path.join(root, fn)
            rp = os.path.relpath(ap, input_dir).replace("\\", "/")
            try:
                with open(ap, "rb") as f:
                    head = f.read(64)
                items.append({"rel_path": rp, "abs_path": ap,
                              "size": os.path.getsize(ap),
                              "kind": sniff_kind(fn, head)})
            except OSError as e:
                errors.append({"path": rp, "error": str(e)})
    return items, errors


def sniff_kind(fn, head):
    ext = os.path.splitext(fn)[1].lower()
    if head.startswith(b"%PDF"):
        return "pdf"
    if head.startswith(b"PK\x03\x04") and ext == ".docx":
        return "docx"
    if head.startswith(b"SQLite format 3\x00"):
        return "sqlite"
    if head.startswith(b"\x89PNG") or head.startswith(b"\xff\xd8") or \
            ext in (".png", ".jpg", ".jpeg", ".gif", ".tif", ".bmp"):
        return "image"
    if ext == ".json" or head.lstrip().startswith((b"{", b"[")):
        return "json"
    if ext == ".xml" or head.lstrip().startswith(b"<"):
        return "xml"
    if ext == ".csv":
        return "csv"
    return "text"


def read_text(ap):
    data = open(ap, "rb").read()
    for enc in ("utf-8-sig", "utf-8", "gb18030", "latin-1"):
        try:
            return data.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode("utf-8", "replace")


def load_material(abs_path, rel_path):
    m = {"rel_path": rel_path, "abs_path": abs_path, "kind": None, "text": "",
         "records": [], "errors": []}
    try:
        kind = sniff_kind(os.path.basename(abs_path),
                          open(abs_path, "rb").read(64))
        m["kind"] = kind
        if kind == "json":
            m.update(_load_json(abs_path))
        elif kind == "xml":
            m.update(_load_xml(abs_path))
        elif kind == "csv":
            m.update(_load_csv(abs_path))
        elif kind == "pdf":
            m.update(_load_pdf(abs_path))
        elif kind == "docx":
            m.update(_load_docx(abs_path))
        elif kind == "sqlite":
            m.update(_load_sqlite(abs_path))
        elif kind == "image":
            m["errors"].append("image: no OCR")
        else:
            m["text"] = read_text(abs_path)
        m["records"] = build_records(m)
    except Exception as e:
        m["errors"].append("%s: %s" % (type(e).__name__, e))
    return m


# ---- JSON ----
def _load_json(abs_path):
    raw = read_text(abs_path)
    try:
        obj = json.loads(raw)
    except Exception as e:
        return {"text": raw, "errors": ["json parse: %s" % e]}
    records = []
    _walk(obj, "$", records)
    return {"text": raw, "records": records}


def _walk(node, path, out):
    if isinstance(node, dict):
        if _looks(node):
            out.append(_rec(node, path))
        for k, v in node.items():
            if isinstance(v, (dict, list)):
                _walk(v, path + "." + str(k), out)
    elif isinstance(node, list):
        for i, v in enumerate(node):
            if isinstance(v, (dict, list)):
                _walk(v, path + "[%d]" % i, out)


def _looks(d):
    if not isinstance(d, dict):
        return False
    keys = set(d.keys())
    return bool(keys & set(FIELDS["doi"] + FIELDS["title"])) or \
        bool(keys & {"author", "authors", "authorString", "creator",
                     "creators"})


def _rec(d, path):
    return {"title": _first(d, FIELDS["title"]), "authors": _authors(d),
            "year": _year(d), "venue": _first(d, FIELDS["venue"]),
            "doi": normalize_doi(_first(d, FIELDS["doi"])), "locator": path}


def _first(d, keys):
    for k in keys:
        v = d.get(k)
        if v in (None, "", []):
            continue
        if isinstance(v, list):
            v = v[0] if v else None
        elif isinstance(v, dict):
            v = json.dumps(v, ensure_ascii=False)
        if v is not None and str(v).strip():
            return str(v).strip()
    return None


def _authors(d):
    for k in FIELDS["authors"]:
        v = d.get(k)
        if isinstance(v, str):
            return [x.strip() for x in v.split(",") if x.strip()]
        if isinstance(v, list):
            names = [a.strip() if isinstance(a, str) else str(
                a.get("family") or a.get("name") or a.get("given") or "")
                for a in v]
            names = [x for x in names if x]
            if names:
                return names
    return []


def _year(d):
    for k in FIELDS["year"]:
        if k in d:
            y = _yr(d[k])
            if y:
                return y
    for k in ("issued", "published-print", "published-online", "created",
              "pubDate"):
        v = d.get(k)
        if isinstance(v, dict):
            y = _yr(v.get("date-parts") or v.get("dateTime") or v.get("year"))
            if y:
                return y
    return None


def _yr(v):
    if isinstance(v, list):
        for x in v:
            if isinstance(x, list) and x and str(x[0]).isdigit():
                return int(str(x[0])[:4])
            y = _yr(x)
            if y:
                return y
        return None
    m = re.search(r"(19|20)\d{2}", str(v))
    return int(m.group(0)) if m else None


# ---- XML ----
def _load_xml(abs_path):
    raw = read_text(abs_path)
    try:
        root = ET.fromstring(raw)
    except Exception as e:
        return {"text": raw, "errors": ["xml parse: %s" % e]}
    records = []
    for el in root.iter():
        t = el.tag.split("}")[-1].lower()
        if t in ("result", "record", "article", "paper", "entry", "work"):
            d = {c.tag.split("}")[-1]: (c.text or "").strip() for c in el}
            if _looks(d):
                records.append(_rec(d, t))
    return {"text": " ".join((e.text or "").strip() for e in root.iter()
                             if (e.text or "").strip()), "records": records}


# ---- CSV ----
def _load_csv(abs_path):
    raw = read_text(abs_path)
    try:
        records = [_rec(dict(r), "csv.row[%d]" % i)
                   for i, r in enumerate(csv.DictReader(io.StringIO(raw)))
                   if _looks(dict(r))]
        return {"text": raw, "records": records}
    except Exception as e:
        return {"text": raw, "errors": ["csv parse: %s" % e]}


# ---- PDF ----
def _load_pdf(abs_path):
    text = _pdf_text(open(abs_path, "rb").read())
    errs = [] if text.strip() else ["pdf: no text layer (scanned?)"]
    return {"text": text, "errors": errs}


def _pdf_text(data):
    parts = [_inflate(m.group(1)) for m in
             re.finditer(rb"stream\r?\n(.*?)\r?\nendstream", data, re.S)]
    return _pdf_ops(b"\n".join(parts))


def _inflate(chunk):
    raw = chunk
    for _ in range(3):
        try:
            raw = zlib.decompress(raw)
            break
        except Exception:
            raw = raw.lstrip(b"\r\n")
    return raw


def _pdf_ops(raw):
    try:
        s = raw.decode("latin-1", "replace")
    except Exception:
        return ""
    out = []
    for m in re.finditer(r"\(((?:[^()\\]|\\.)*)\)\s*Tj", s, re.S):
        out.append(_unescape(m.group(1)))
    for m in re.finditer(r"\[((?:[^\[\]\\]|\\.)*)\]\s*TJ", s, re.S):
        for t in re.finditer(r"\(((?:[^()\\]|\\.)*)\)", m.group(1)):
            out.append(_unescape(t.group(1)))
    return "\n".join(x for x in out if x.strip())


def _unescape(s):
    return re.sub(r"\\\d{1,3}", " ", s.replace(r"\(", "(").replace(r"\)", ")")
                  .replace(r"\\", "\\"))


# ---- DOCX ----
def _load_docx(abs_path):
    try:
        with zipfile.ZipFile(abs_path) as z:
            if "word/document.xml" not in z.namelist():
                return {"text": "", "errors": ["docx: missing document.xml"]}
            root = ET.fromstring(z.read("word/document.xml"))
        ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
        return {"text": "\n".join(t.text or "" for t in root.iter(ns + "t"))}
    except Exception as e:
        return {"text": "", "errors": ["docx parse: %s" % e]}


# ---- SQLite ----
def _load_sqlite(abs_path):
    try:
        con = sqlite3.connect("file:%s?mode=ro" % abs_path.replace("\\", "/"),
                              uri=True)
        cur = con.cursor()
        tables = [r[0] for r in cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")]
    except Exception as e:
        return {"text": "", "errors": ["sqlite open: %s" % e]}
    lines, records = [], []
    for t in tables:
        try:
            cols = [c[1] for c in cur.execute("PRAGMA table_info(%s)" % t)]
            rows = list(cur.execute("SELECT * FROM %s LIMIT 500" % t))
        except Exception as e:
            lines.append("TABLE %s ERROR %s" % (t, e))
            continue
        for ri, row in enumerate(rows):
            d = dict(zip(cols, row))
            lines.append("TABLE %s ROW %d :: %s" % (t, ri, " | ".join(
                "%s=%s" % (c, v) for c, v in d.items() if v not in (None, ""))))
            if _looks(d):
                records.append(_rec(d, "sqlite.%s.row[%d]" % (t, ri)))
    con.close()
    return {"text": "\n".join(lines), "records": records}


# ---- 通用记录构建 ----
def build_records(m):
    text = m.get("text") or ""
    kind = m.get("kind") or "text"
    recs = list(m.get("records") or [])
    if kind in ("json", "xml", "csv", "sqlite"):
        seen, out = set(), []
        for r in recs:
            key = r.get("doi") or r.get("title") or ""
            if key and key in seen:
                continue
            seen.add(key)
            out.append(r)
        recs = out
    else:
        for mm in DOI_RE.finditer(text):
            recs.append({"title": None, "authors": [], "year": None,
                         "venue": None, "doi": normalize_doi(mm.group(0)),
                         "locator": "text.char[%d]" % mm.start()})
    return [_finalize(r, text, kind, m["rel_path"]) for r in recs]


def _finalize(r, text, kind, rel_path):
    rec = {"title": _norm_title(r.get("title")),
           "authors": [a for a in (r.get("authors") or []) if a][:30],
           "year": pick_year(r.get("year")), "venue": r.get("venue"),
           "doi": normalize_doi(r.get("doi")),
           "source": {"path": rel_path, "locator": r.get("locator") or "?",
                      "kind": kind}}
    anchor = rec["doi"] or rec["title"] or ""
    idx = text.find(anchor) if anchor else -1
    if idx < 0 and rec["doi"]:
        for m in DOI_RE.finditer(text):
            if normalize_doi(m.group(0)) == rec["doi"]:
                idx = m.start()
                break
    if idx >= 0:
        rec["text_span"] = [max(0, idx - 40),
                            min(len(text), idx + len(anchor) + 200)]
        rec["context_text"] = text[rec["text_span"][0]:rec["text_span"][1]]
    else:
        rec["text_span"] = [0, 0]
        rec["context_text"] = ""
    rec["searchable"] = " ".join(filter(None, [rec["title"],
        " ".join(rec["authors"]), str(rec["year"] or ""), rec["venue"] or "",
        rec["doi"] or "", rec["context_text"] or ""]))
    return rec


def normalize_doi(x):
    if not x:
        return None
    s = str(x).strip()
    for p in ("https://doi.org/", "http://doi.org/", "doi:", "DOI:"):
        s = s.replace(p, "")
    s = s.rstrip(".,;")
    return s if DOI_RE.match(s) else None


def _norm_title(x):
    if not x:
        return None
    s = re.sub(r"<[^>]+>", "", re.sub(r"\s+", " ", str(x))).strip()
    return s[:300] if s else None


def pick_year(x):
    if isinstance(x, int):
        return x if 1000 <= x <= 2100 else None
    if x is None:
        return None
    m = re.search(r"(19|20)\d{2}", str(x))
    return int(m.group(0)) if m else None


def normalize_title(x):
    return _norm_title(x)


def build_sources(loaded):
    return [{"path": m["rel_path"], "kind": m["kind"], "size": m.get("size"),
             "role": "material", "n_records": len(m.get("records") or [])}
            for m in loaded]


def build_coverage(loaded, records, evidence, candidates):
    empty = [{"query_id": e["query_id"], "term": e["term"],
              "variants": e["variants"]} for e in evidence if e["empty"]]
    unpar = [{"path": m["rel_path"], "kind": m["kind"], "errors": m["errors"]}
             for m in loaded if m.get("errors") and not m.get("records")]
    missing = [{"record_id": c["record_id"], "missing": [k for k in
                ("doi", "title", "year", "venue", "authors") if not c.get(k)]}
               for c in candidates if any(not c.get(k) for k in
               ("doi", "title", "year", "venue", "authors"))]
    return {"empty_queries": empty, "unparseable_materials": unpar,
            "missing_metadata": missing, "n_materials": len(loaded),
            "n_records": len(records), "n_candidates": len(candidates),
            "notes": ["仅检索给定本地材料，无实时联网"]}


CANON = ("research_question", "query_plan", "query_evidence", "candidates",
         "ranking", "dedup_records", "coverage")


def wjson(path, obj):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    t = p.with_suffix(p.suffix + ".tmp")
    t.write_text(json.dumps(obj, ensure_ascii=False, indent=2), "utf-8")
    os.replace(str(t), str(p))


def rjson(path):
    return json.loads(read_text(path))


def nk(x):
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]", "", str(x).lower())


def extract_contract(case):
    if not isinstance(case, dict):
        return []
    oc = case.get("output_contract")
    if isinstance(oc, dict):
        f = list(oc.keys())
    elif isinstance(oc, list):
        f = [it if isinstance(it, str) else
             (it.get("name") or it.get("key") or it.get("field") or str(it))
             if isinstance(it, dict) else str(it) for it in oc]
    else:
        f = []
    return [str(x) for x in f if x]


def map_contract(key, can):
    n = nk(key)
    for subs, tgt in (("candidat paper literatur hit", "candidates"),
                      ("queryplan searchplan searchstrateg", "query_plan"),
                      ("queryevid queryresult", "query_evidence"),
                      ("rank order sort precis ndcg relevanc", "ranking"),
                      ("dedup duplicat", "dedup_records"),
                      ("cover omiss gap miss", "coverage"),
                      ("researchquestion problem question decompos scope",
                       "research_question"),
                      ("sourc trace", "sources"),
                      ("uncertaint risk", "uncertainty"),
                      ("error degrad exception fail", "errors")):
        if any(s in n for s in subs.split()):
            return can.get(tgt)
    if n.endswith("s") or any(s in n for s in ("list", "items", "set", "records",
                                               "results", "entries", "queries",
                                               "changes")):
        return []
    return None


def assemble(case, status, can, errors, degradations, gaps, unc, changes,
             contract):
    res = {"case_id": (case or {}).get("case_id") if isinstance(case, dict)
           else None, "status": status, "sources": can.get("sources", []),
           "uncertainty": unc, "change_records": changes, "errors": errors,
           "degradations": degradations, "gaps": gaps}
    for k in CANON:
        res[k] = can.get(k)
    for f in contract:
        res[f] = map_contract(f, can)
    return res


def emit(case, status, can, errors, degradations, gaps, unc, changes, contract,
         work, out, final):
    res = assemble(case, status, can, errors, degradations, gaps, unc, changes,
                   contract)
    wjson(Path(out) / "result.json", res)
    wjson(Path(work) / ("final_result.json" if final else "partial_result.json"),
          res)
    return res


def empty_can(src, note):
    return {"sources": src, "research_question": None, "query_plan": None,
            "query_evidence": [], "candidates": [], "ranking": None,
            "dedup_records": [], "coverage": {"note": note}}


def check_result(out):
    rp = Path(out) / "result.json"
    if not rp.exists() or rp.stat().st_size == 0:
        return False, ["result.json missing or empty"]
    try:
        r = rjson(rp)
    except Exception as e:
        return False, ["result.json invalid: %s" % e]
    p = [k for k in ("case_id", "status", "sources", "uncertainty",
                     "change_records") if k not in r]
    return not p, p

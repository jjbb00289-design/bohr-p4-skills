#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
import os
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
REF_DIR = HERE.parent / "references"
sys.path.insert(0, str(HERE))
from parsers import (discover_materials, load_material, normalize_doi,  # noqa
                     normalize_title, build_sources, build_coverage, wjson,
                     rjson, read_text, nk, extract_contract, map_contract,
                     assemble, emit, empty_can, check_result)

DEF = {"input": "/input", "work": "/app/work", "output": "/app/output"}
STOP = set("the and for with that this from are was were has have had not "
           "but all any can how what which who when where why into".split())
FIELD_W = {"title": 3.0, "doi": 2.5, "venue": 1.2, "authors": 1.0,
           "body": 0.6, "year": 0.4}


def read_case(inp):
    cp = Path(inp) / "case.json"
    if not cp.exists():
        return None, ["case.json missing"]
    try:
        return rjson(cp), []
    except Exception as e:
        return None, ["case.json invalid: %s" % e]


def instruction(case):
    if not isinstance(case, dict):
        return ""
    for k in ("task_instruction", "instruction", "task", "content", "question",
              "query", "research_question", "prompt"):
        v = case.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
        if isinstance(v, dict):
            s = v.get("text") or v.get("content") or v.get("question")
            if isinstance(s, str) and s.strip():
                return s.strip()
    return ""


def keywords(case):
    if not isinstance(case, dict):
        return []
    v = case.get("keywords") or case.get("key_terms") or case.get("terms")
    if isinstance(v, list):
        return [str(x) for x in v if str(x).strip()]
    if isinstance(v, str):
        return [x.strip() for x in re.split(r"[,;，；\n]", v) if x.strip()]
    return []


def derive(text, kws):
    terms, seen = [], set()
    for k in kws:
        k = str(k).strip()
        if k and k.lower() not in seen:
            seen.add(k.lower())
            terms.append(k)
    for t in re.findall(r"[A-Za-z][A-Za-z0-9\-]{2,}", text):
        tl = t.lower()
        if tl in STOP or tl in seen or any(tl in s for s in seen if " " in s):
            continue
        seen.add(tl)
        terms.append(t)
    if not terms:
        for t in re.findall(r"[\u4e00-\u9fff]{2,6}", text):
            if t.lower() not in seen:
                seen.add(t.lower())
                terms.append(t)
    return terms[:40]


def acr(term):
    p = re.split(r"[ _\-/]+", term)
    a = "".join(x[0] for x in p if x)
    return a.upper() if len(p) >= 2 and len(a) >= 2 else None


def expand(terms, syn):
    out = {}
    for t in terms:
        v = [t]
        for x in syn.get(t.lower(), []):
            if x and x not in v:
                v.append(x)
        a = acr(t)
        if a and a not in v:
            v.append(a)
        out[t] = v
    return out


def plan(q, syn):
    ex = expand(q["terms"], syn)
    return {"research_question": q["question"], "concepts": q["concepts"],
            "rounds": [
                {"round": 0, "label": "primary",
                 "queries": [{"term": t, "variants": ex[t][:1]}
                             for t in q["terms"]]},
                {"round": 1, "label": "synonym_abbrev",
                 "queries": [{"term": t, "variants": ex[t][1:]} for t in
                             q["terms"] if len(ex[t]) > 1]}]}


def qf(term, rec):
    ctx = rec.get("context_text") or ""
    i = ctx.lower().find(term.lower())
    if i >= 0:
        return ctx[max(0, i - 60):i + len(term) + 90]
    for f in ("title", "venue", "doi", "searchable"):
        v = rec.get(f)
        if v and term.lower() in str(v).lower():
            return str(v)[:240]
    return ""


def run_q(term, variants, recs):
    hits = []
    for r in recs:
        flds = {"title": r.get("title"),
                "authors": " ".join(r.get("authors") or []),
                "year": str(r.get("year") or ""), "venue": r.get("venue"),
                "doi": r.get("doi"), "body": r.get("context_text")}
        for v in variants:
            for fn, fv in flds.items():
                if fv and v.lower() in str(fv).lower():
                    hits.append({"record_id": r["record_id"], "term": v,
                                 "field": fn, "quote": qf(v, r)})
                    break
            if any(h["record_id"] == r["record_id"] for h in hits):
                break
    return hits


def run_queries(plan, recs):
    ev, idx = [], 0
    for rnd in plan["rounds"]:
        for q in rnd["queries"]:
            idx += 1
            variants = [x for x in q["variants"] if x]
            hits = run_q(q["term"], variants, recs)
            ev.append({"query_id": "q%03d" % idx, "round": rnd["round"],
                       "round_label": rnd["label"], "term": q["term"],
                       "variants": variants, "num_hits": len(hits),
                       "hits": hits, "empty": not hits})
    return ev


def aggregate(ev, recs):
    by = {}
    for e in ev:
        rw = 1.0 if e["round"] == 0 else (0.85 if e["round"] == 1 else 0.7)
        for h in e["hits"]:
            it = by.setdefault(h["record_id"], {"record_id": h["record_id"],
                                                "evidence": [], "terms": set()})
            it["evidence"].append({"query_id": e["query_id"], "round": e["round"],
                                   "term": h["term"], "field": h["field"],
                                   "quote": h["quote"], "round_weight": rw})
            it["terms"].add(h["term"].lower())
    recmap = {r["record_id"]: r for r in recs}
    out = []
    for rid, it in sorted(by.items()):
        r = recmap.get(rid)
        if r:
            out.append({"record_id": rid, "title": r.get("title"),
                        "authors": r.get("authors") or [], "year": r.get("year"),
                        "venue": r.get("venue"), "doi": r.get("doi"),
                        "source": r.get("source"),
                        "context_text": r.get("context_text"),
                        "evidence": it["evidence"], "terms": sorted(it["terms"])})
    return out


def rich(c):
    return sum(1 for k in ("title", "doi", "year", "venue") if c.get(k)) \
        + bool(c.get("authors"))


def dkey(c):
    if c.get("doi"):
        return ("doi", c["doi"].lower())
    if c.get("title"):
        return ("title", re.sub(r"[^a-z0-9\u4e00-\u9fff]", "",
                                c["title"].lower())[:120])
    if c.get("authors") and c.get("year"):
        return ("authyr", (c["authors"][0].lower(), str(c["year"]),
                           (c.get("title") or "")[:40]))
    return ("src", c["source"]["path"] + "#" + c["source"]["locator"])


def dedup(cands):
    groups = {}
    for c in cands:
        groups.setdefault(dkey(c), []).append(c)
    merged, recs = [], []
    for key, g in sorted(groups.items(), key=lambda kv: kv[0][1] or ""):
        g = sorted(g, key=rich, reverse=True)
        base = g[0]
        ev, terms = [], set()
        for c in g:
            ev.extend(c["evidence"])
            terms.update(c["terms"])
        base["evidence"] = sorted(ev, key=lambda e: (e["query_id"], e["term"],
                                                     e["field"]))
        base["terms"] = sorted(terms)
        merged.append(base)
        if len(g) > 1:
            recs.append({"dedup_key": list(key),
                         "kept_record_id": base["record_id"],
                         "merged_record_ids": sorted(c["record_id"]
                                                     for c in g)})
    return merged, recs


def score(c):
    s = sum(e.get("round_weight", 1.0) * FIELD_W.get(e["field"], 0.3)
            for e in c["evidence"])
    return round(s + 0.05 * len(c["terms"]) + 0.02 * bool(c.get("doi"))
                 + 0.02 * bool(c.get("title")) + 0.01 * bool(c.get("year")), 4)


def pk(scored, gold):
    if not gold:
        return {"available": False, "note": "无黄金相关集，不计算 P@k"}
    g = set()
    for x in gold:
        d = normalize_doi(x)
        g.add(("doi", d.lower()) if d else ("title", nk(normalize_title(x) or
                                                         "")[:120]))
    hits = []
    for c in scored:
        if ("doi", (c.get("doi") or "").lower()) in g or \
           ("title", nk(c.get("title") or "")[:120]) in g:
            hits.append(c["record_id"])
    out = {"available": True, "gold_size": len(g), "hits_found": hits}
    for k in (5, 10):
        top = scored[:k]
        out["P@%d" % k] = round(sum(1 for c in top if c["record_id"] in
                                    hits) / k, 4) if top else None
    out["recall_of_gold"] = round(len(hits) / len(g), 4) if g else None
    return out


def rank(cands, case):
    scored = sorted([dict(c, score=score(c)) for c in cands],
                    key=lambda c: (-c["score"], -(c.get("year") or 0),
                                   (c.get("title") or "").lower()))
    return {"method": ("score=Σ(round_w×field_w)+0.05×词数+元数据加分；同分按"
                       "年份降序、标题升序"), "ordered_ids":
            [c["record_id"] for c in scored],
            "scores": {c["record_id"]: c["score"] for c in scored},
            "precision_at_k": pk(scored, case.get("gold_relevant")
                                 if isinstance(case, dict) else None),
            "candidates": scored}


def resolve(args):
    return {k: getattr(args, k) or os.environ.get(k.upper() + "_DIR")
            or DEF[k] for k in ("input", "work", "output")}


def synonyms():
    sp = REF_DIR / "synonyms.json"
    if sp.exists():
        try:
            d = rjson(sp)
            m = d.get("map") if isinstance(d, dict) else d
            return {str(k): [str(x) for x in v] for k, v in m.items()
                    if isinstance(v, list)}
        except Exception:
            pass
    return {}


def run_full(dirs):
    inp, work, out = dirs["input"], dirs["work"], dirs["output"]
    Path(work).mkdir(parents=True, exist_ok=True)
    Path(out).mkdir(parents=True, exist_ok=True)
    errors, degradations, gaps = [], [], []
    case, cerrs = read_case(inp)
    errors.extend(cerrs)
    contract = extract_contract(case)
    if case is None:
        return emit(None, "input_error", empty_can([], "无可用输入"), errors, [],
                    ["无法读取 case.json"], {"note": "无可用输入"},
                    [{"step": 1, "action": "input_error"}], contract, work, out,
                    True)
    task = read_text(Path(inp) / "task.md") if (Path(inp) / "task.md").exists() else ""
    materials, merrs = discover_materials(inp)
    for e in merrs:
        errors.append({"path": e["path"], "error": e["error"]})
    loaded = []
    for m in materials:
        lm = load_material(m["abs_path"], m["rel_path"])
        lm["size"] = m["size"]
        for e in lm["errors"]:
            degradations.append({"path": lm["rel_path"], "error": e})
        loaded.append(lm)
    records = [r for lm in loaded for r in lm.get("records", [])]
    records.sort(key=lambda r: (r["source"]["path"], r["source"]["locator"],
                                r.get("doi") or r.get("title") or ""))
    for i, r in enumerate(records):
        r["record_id"] = "r%04d" % (i + 1)
    wjson(Path(work) / "01_input.json", {"case_id": case.get("case_id"),
          "instruction": instruction(case), "contract_fields": contract})
    wjson(Path(work) / "02_materials.json", materials)
    wjson(Path(work) / "03_records.json", records)
    emit(case, "partial", empty_can(build_sources(loaded), "执行中"), errors,
         degradations, gaps, {"note": "执行中"},
         [{"step": 1, "action": "partial_snapshot"}], contract, work, out, False)
    if not materials:
        gaps.append("材料目录为空")
        return emit(case, "insufficient_evidence", empty_can([], "无材料"),
                    errors, degradations, gaps, {"note": "无材料可检索"},
                    [{"step": 1, "action": "partial_snapshot"},
                     {"step": 2, "action": "finalize"}], contract, work, out, True)
    if not records:
        gaps.append("材料存在但未提取到文献记录")
        return emit(case, "insufficient_evidence",
                    empty_can(build_sources(loaded), "无可提取记录"), errors,
                    degradations, gaps, {"note": "证据不足"},
                    [{"step": 1, "action": "partial_snapshot"},
                     {"step": 2, "action": "finalize"}], contract, work, out, True)
    q = {"question": instruction(case) or task, "keywords": keywords(case)}
    q["terms"] = derive(q["question"], q["keywords"])
    q["concepts"] = {"raw_terms": q["terms"], "note": "确定性术语抽取"}
    pl = plan(q, synonyms())
    ev = run_queries(pl, records)
    merged, drecs = dedup(aggregate(ev, records))
    rk = rank(merged, case)
    cov = build_coverage(loaded, records, ev, rk["candidates"])
    for name, obj in (("04_query_plan.json", pl), ("05_query_evidence.json", ev),
                      ("06_candidates.json", merged), ("07_ranking.json", rk),
                      ("08_coverage.json", cov)):
        wjson(Path(work) / name, obj)
    for c in rk["candidates"]:
        for e in c["evidence"]:
            if not e.get("quote"):
                e["quote"] = c.get("context_text") or ""
    for u in cov.get("unparseable_materials", []):
        degradations.append({"path": u["path"], "error": "; ".join(u["errors"])})
    status = "partial" if (errors or degradations or gaps) else "complete"
    unc = {"metadata": "结构化响应元数据可靠；自由文本标题/作者为尽力抽取",
           "gold_labels": ("已按黄金相关集计算 P@k" if rk["precision_at_k"]
                           ["available"] else "无黄金相关集，P@k 未计算"),
           "ranking": "关键词加权启发式排序",
           "empty_queries": len(cov.get("empty_queries") or []),
           "unparseable_materials": len(cov.get("unparseable_materials") or [])}
    can = {"sources": build_sources(loaded), "research_question": q,
           "query_plan": pl, "query_evidence": ev, "candidates": merged,
           "ranking": {"method": rk["method"], "ordered_ids": rk["ordered_ids"],
                       "scores": rk["scores"],
                       "precision_at_k": rk["precision_at_k"]},
           "dedup_records": drecs, "coverage": cov}
    return emit(case, status, can, errors, degradations, gaps, unc,
                [{"step": 1, "action": "partial_snapshot"},
                 {"step": 2, "action": "finalize"}], contract, work, out, True)


def cmd_init(d):
    for x in (d["work"], d["output"]):
        Path(x).mkdir(parents=True, exist_ok=True)
    case, _ = read_case(d["input"])
    wjson(Path(d["work"]) / "01_input.json",
          {"case_id": (case or {}).get("case_id") if isinstance(case, dict)
           else None, "instruction": instruction(case) if case else ""})
    print("init ok")


def cmd_show(d):
    materials, errs = discover_materials(d["input"])
    print("materials: %d" % len(materials))
    for m in materials:
        print("  [%s] %s (%d bytes)" % (m["kind"], m["rel_path"], m["size"]))
    for e in errs:
        print("  ERROR %s: %s" % (e["path"], e["error"]))
    n = sum(len(load_material(m["abs_path"], m["rel_path"]).get("records", []))
            for m in materials)
    print("records: %d" % n)


def cmd_check(d):
    ok, p = check_result(d["output"])
    print("check: %s" % ("OK" if ok else "PROBLEMS"))
    for x in p:
        print("  - " + x)


def cmd_build(d):
    Path(d["output"]).mkdir(parents=True, exist_ok=True)
    for n in ("final_result.json", "partial_result.json"):
        p = Path(d["work"]) / n
        if p.exists():
            wjson(Path(d["output"]) / "result.json", rjson(p))
            print("build: restored %s" % n)
            return
    print("build: no work drafts, running full pipeline")
    run_full(d)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="main.py")
    ap.add_argument("command", nargs="?", default="run",
                    choices=["run", "init", "show", "check", "build"])
    ap.add_argument("--input")
    ap.add_argument("--work")
    ap.add_argument("--output")
    args = ap.parse_args(argv)
    d = resolve(args)
    try:
        {"init": cmd_init, "show": cmd_show, "check": cmd_check,
         "build": cmd_build}.get(args.command, run_full)(d)
    except Exception as e:
        try:
            out = Path(d["output"])
            out.mkdir(parents=True, exist_ok=True)
            if not (out / "result.json").exists():
                wjson(out / "result.json", {"case_id": None, "status":
                      "input_error", "sources": [], "uncertainty":
                      {"note": "未处理异常"}, "change_records":
                      [{"step": 1, "action": "exception_fallback"}], "errors":
                      ["%s: %s" % (type(e).__name__, e)], "degradations": [],
                      "gaps": []})
        except Exception:
            pass
        sys.stderr.write("ERROR: %s: %s\n" % (type(e).__name__, e))
    return 0


if __name__ == "__main__":
    sys.exit(main())

---
name: paper-structured-notes
description: 把真实科研论文（PDF/DOCX/文本）转成与原文章节对齐、字段齐备、逐条可回链原文的结构化笔记与答题结果。当需要阅读论文、总结文献、提取知识点、按案例答题并给出逐字依据、生成可复核可复用的文献笔记时触发。
version: 1.0.0
---

# 文献总结与结构化笔记

## 1. 用途

围绕一篇真实科研论文，产出一份**结构可复用**的笔记：章节骨架与论文自身结构对齐（对得上）、研究问题/数据/方法/结果/结论/限制齐全（留得住）、每条关键论断可回链到原文位置与逐字引文（找得回）、输出为机器可读 JSON 与可编辑 Markdown（用得上）。同时按案例 `output_contract` 回填答题字段，所有结论回到原文证据。

本 Skill 聚焦一个明确问题：**章节对齐 + 字段化整理 + 锚点回链 + 引文可核验**。不追求通用摘要。

## 2. 触发条件

- 输入 `/input/case.json` 含 `output_contract` 且任务要求阅读/总结/解析文献。
- 或用户要求对一篇论文做结构化笔记、论文卡片、章节摘要、知识点提取。
- 材料含 PDF、DOCX、TXT、MD、JSON、CSV、图片等科研文件时，用本流程读取并回链。

## 3. 调用方式

脚本位于本 SKILL.md 同级的 `scripts/main.py`（平台固定路径 `/skills/weekly-skill/scripts/main.py`；若安装位置不同，用「本 SKILL.md 所在目录 + /scripts/main.py」）。纯 Python 标准库，不联网，不依赖当前工作目录。

```
python <skill_root>/scripts/main.py init     # 抽取材料文本 + 无草稿时自动派生 notes/answers + 写 result.json
python <skill_root>/scripts/main.py show     # 查看工作稿摘要（documents/notes 计数/gaps）
python <skill_root>/scripts/main.py check    # 校验每条 quote 是否命中原文，输出命中率
python <skill_root>/scripts/main.py build    # 由工作稿（或自动派生结果）组装 result.json + notes.md
python <skill_root>/scripts/main.py          # 默认=完整流程：空 work 下自动派生 summary/key_findings/limitations 并逐字回链
```

若 `/app/work/work.json` 已由 Agent 或草稿**实质填写**，脚本保留该草稿（不再覆盖、不重新派生）；未填写则从 `/input` 材料自动派生。`status` 取值：`complete`（契约键全部非空、六要素齐备且无未决缺口）、`partial`（部分完成，缺口如实列出）、`input_error`、`insufficient_evidence`。

环境变量覆盖：`INPUT_DIR`（默认 `/input`）、`WORK_DIR`（默认 `/app/work`）、`OUTPUT_DIR`（默认 `/app/output`），也可用 `--input/--work/--output` 参数。最终产物必须写 `/app/output`，中间产物写 `/app/work`。

## 4. 输入输出

- **输入**：`/input/case.json`（含 `case_id`、`task_instruction`、`output_contract`）、`/input/task.md`、以及 `/input` 下的材料文件。不要按文件名标签假设内容，一律真实读取。
- **工作稿**：`/app/work/work.json`（Agent 填写），抽取文本存 `/app/work/text/<序号>_<文件名>.txt`。
- **输出**：`/app/output/result.json`（必须含 `output_contract` 每个字段 + `case_id` + `status` + `sources` + `uncertainty` + `change_records` + `notes` + `gaps`）；另写 `/app/output/notes.md` 作为可编辑/可继续加工笔记。

## 5. 工作流程（Agent 必须逐步执行）

1. 读 `case.json`，记录 `case_id`、`task_instruction`、`output_contract` 的每个字段名；读 `task.md` 确定题目具体要求。
2. 运行 `init`（或默认命令）。脚本真实读取并抽取每个材料（PDF 走 zlib 流文本抽取；DOCX 解压 document.xml；文本类直接读；图片/无文本层 PDF 记录为降级缺口）。**若 `/app/work/work.json` 尚无实质草稿**，脚本自动派生 `notes.*` 与 `answers.*`：每条 evidence 都经过逐字命中原文校验，未命中即丢弃，因此可零草稿直接交付。随后读 `/app/work/text/*.txt` 的抽取全文复核；抽取不足时回到原始材料用平台工具（pdf-text-tool/ocr-tool/pdf-render-tool）补读。
3. 以下步骤为**可选覆盖**（草稿有则用，没有就保留自动派生）：按 §6 工作稿 schema 填写 `notes.*` 与 `answers.*`——先确定论文标题与真实章节顺序（以原文 heading 为准），再逐章节写 `section_summaries`，再填 `paper_card`，再抽 `knowledge_points`。每条内容都必须带 `evidence`。
4. 填 `answers`：对 `output_contract` 的每个字段名，给出与题目要求形态一致的值（字符串/列表/对象均可），值只来自材料。
5. 运行 `check` 校验引文命中；对未命中的 quote 改为逐字照抄原文或删除该论断，直到命中率 ≥ 0.95（目标 1.0）。
6. 运行 `build` 落盘 `result.json` 与 `notes.md`；确认退出码恒 0、结果 JSON 合法、契约键齐全。
7. 预算接近上限（约 780s）或剩余请求不足时，立即运行 `build` 固化已完成部分，把缺口写入 `gaps`，不空跑。

## 6. 工作稿 schema（work.json）

```json
{
  "schema_version": "1.0",
  "case_id": "str",
  "task_instruction": "str",
  "documents": [{"path":"str","kind":"str","parse":"ok|partial|failed|unsupported","pages":null,"text_file":"str","note":"str"}],
  "answers": {"<contract_field>": null},
  "notes": {
    "title": null,
    "paper_card": {
      "research_question": null, "data": null, "methods": null,
      "main_findings": [], "conclusions": null, "limitations": []
    },
    "section_summaries": [],
    "knowledge_points": [],
    "evidence_links": [],
    "unreported": [],
    "conflicts": []
  },
  "gaps": [{"field":"str","reason":"str"}],
  "change_records": [{"step":"str","detail":"str"}],
  "errors": [], "degradations": []
}
```

Agent 只需填写 `notes.*` 与 `answers.*`，并追加 `gaps/change_records/errors/degradations`；脚本会自动回填其余。`notes` 内未写的对象字段保留为 `null`/`[]`，不要用“看起来像”的段落填充。

## 7. 笔记字段字典（notes）

完整字段字典与标注示例见 `references/note-schema.md`（示例已标“示例，非正式案例结果”）。以下为概览：

- **paper_card**（论文卡片，多篇可并排比较）：
  - `research_question`：研究问题/目标，字符串。
  - `data`：数据与样本（对象/字符串），含数量、来源、条件。
  - `methods`：方法与条件（对象/字符串），含让结论成立的前提（模型、指标、对照组、显著性水平等）。
  - `main_findings`：主要发现列表；每条为 `{"claim":"str","evidence":[{"locator":"str","quote":"str"}]}`。
  - `conclusions`：结论字符串。
  - `limitations`：局限列表，每条 `{"item":"str","evidence":[{"locator":"str","quote":"str"}]}` 或标 `not_reported`。
- **section_summaries**（章节对齐，按原文顺序）：每节 `{"section_id":"str","heading":"str","purpose":"str","method":"str","result":"str","conclusion":"str","evidence":[{"locator":"str","quote":"str"}]}`。不得脱离原文结构合并成通读摘要；缺某要素写 `null` 并在 `gaps` 注明。
- **knowledge_points**（可检索条目）：每条 `{"id":"str","term":"str","kind":"concept|variable|method|result","statement":"str","term_variants":[],"evidence":[{"locator":"str","quote":"str"}]}`；术语、缩写、同义表述归一，避免条目重复或矛盾。
- **evidence_links**（来源回链）：`{"target":"str","locator":"str","quote":"str","note":"str"}`。
- **unreported**：`{"item":"str","reason":"str"}`；材料未报告或无法判断的项，不得写成事实。
- **conflicts**：`{"a":"str","b":"str","note":"str"}`；材料内部或材料间冲突。

## 8. 证据规范（红线）

- 每条结论/数值/变量/方法条件/页面都要能指回 `source` + `locator` + 逐字 `quote`。
- `locator` 粒度：能到页码到页码（`p.4`）、能到段落到段落（`§3.2 第3段`）、能到图表到图表（`Table 2`/`Fig. 3`）；给不出精确位置就写 `§定位待人工` 并列入 `gaps`。
- `quote` 必须是从材料原文逐字照抄的子串（仅允许空白归一）；`check` 会按规范化文本校验命中，未命中一律不得保留为事实依据。
- 多文档题逐文档、逐比较字段对齐；缺失项写 `uncovered`/`gaps`。翻译/问答/笔记/图谱按题目要求字段形态交付。

## 9. 降级表

| 情况 | 识别 | 处置 |
|-|-|-|
| PDF 无文本层/扫描件 | 抽取文本为空但流存在 | `parse=partial`，改用平台 ocr-tool 或 pdf-render-tool，OCR 结果写回；仍不可读则标缺口 |
| 加密/权限受限 | 读取抛错或解压失败 | `parse=failed`，记入 `degradations`，如实写 gaps |
| 双栏错序 | 文本乱序/公式图表乱入 | 按段落与 heading 人工校序，`locator` 用段落号而非阅读序 |
| 图表/公式缺失 | 抽取不到 | 用 pdf-render-tool/ocr-tool 补读；缺失标 `unreported` |
| 超长文 | 文本超预算 | 按章节分批读，先落已读章节再增量 `build` |
| 非中文论文 | 语言非中文 | 照常结构化；术语保留原文，`term_variants` 记中文对照 |
| 图片/无预抽层 | 材料为图片 | 用 ocr-tool；失败标 `parse=unsupported` |

## 10. 自检（交付前必做）

- `check` 命中率 ≥ 0.95；每条 `evidence.quote` 能在 `work/text/*.txt` 命中。
- `result.json` 可被 `json.load` 解析，含全部 `output_contract` 字段（值可 null/[]）+ `case_id`，不缺键不改名。
- 无占位文本（无 placeholder/“array”“object”/空契约键），notes 覆盖研究问题、数据、方法、结果、结论、限制六要素。
- `status` 为 `complete`（契约键全部非空、六要素齐备、无未决缺口）或 `partial`（如实列出缺口），空 work 默认命令不因缺草稿而空转。
- 退出码恒 0；异常写入 `errors`/`degradations`，不崩溃、不产生 0 字节 result.json。

## 11. 限制

- 脚本不内置 OCR、不联网、不做 LLM 语义判断；自动派生为**规则化**（章节/关键词/数值模式 + 逐字命中校验），语义层阅读与精修由执行本 Skill 的 Agent 完成，机器可判定项（引文命中、字段齐全、契约回填、确定性复跑）由脚本校验。
- 术语消歧、章节意图与人工确认字段必须在 `unreported`/`gaps` 中标明“需人工确认”。
- 本 Skill 不提交预置答案，不编造数据、软件状态或检索结果。

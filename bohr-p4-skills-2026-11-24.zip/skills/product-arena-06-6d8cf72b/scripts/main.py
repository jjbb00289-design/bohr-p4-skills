# -*- coding: utf-8 -*-
"""paper-structured-notes 单命令入口。默认=完整流程；支持 init/show/check/build。"""
import os
import sys
import json
import argparse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import lib  # noqa: E402

DEFAULTS = {
    "INPUT_DIR": "/input",
    "WORK_DIR": "/app/work",
    "OUTPUT_DIR": "/app/output",
}
SKIP_NAMES = {"case.json", "task.md"}


def resolve_dirs(args):
    d = {}
    for key, default in DEFAULTS.items():
        env = os.environ.get(key)
        cli = getattr(args, key.lower().replace("_dir", ""), None)
        d[key] = cli or env or default
    return d["INPUT_DIR"], d["WORK_DIR"], d["OUTPUT_DIR"]


def load_case(input_dir, work, out):
    case_path = os.path.join(input_dir, "case.json")
    if not os.path.isfile(case_path):
        return None, {"case_id": None, "_contract_keys": [], "task_instruction": None,
                      "answers": {}, "notes": {"title": None, "paper_card": {},
                                               "section_summaries": [], "knowledge_points": [],
                                               "evidence_links": [], "unreported": [],
                                               "conflicts": []},
                      "documents": [], "gaps": [{"field": "input", "reason": "缺少 case.json"}],
                      "change_records": [{"step": "load_case",
                                          "detail": "未找到 /input/case.json"}],
                      "errors": ["缺少 case.json"], "degradations": [], "uncertainty": []}, True
    try:
        case = lib.load_json(case_path)
    except Exception as e:
        return None, {"case_id": None, "_contract_keys": [], "task_instruction": None,
                      "answers": {}, "notes": {"title": None, "paper_card": {},
                                               "section_summaries": [], "knowledge_points": [],
                                               "evidence_links": [], "unreported": [],
                                               "conflicts": []},
                      "documents": [], "gaps": [{"field": "input", "reason": "case.json 解析失败"}],
                      "change_records": [{"step": "load_case", "detail": "case.json 解析失败"}],
                      "errors": ["case.json 不是合法 JSON: %s" % e],
                      "degradations": [], "uncertainty": []}, True
    return case, None, False


def gather_materials(input_dir):
    docs = []
    for p in lib.list_files(input_dir):
        base = os.path.basename(p)
        if base in SKIP_NAMES:
            continue
        # 跳过工作稿与输出自身，避免递归
        rel = os.path.relpath(p, input_dir)
        if rel.startswith(".."):
            continue
        d = lib.extract_file(p)
        d["path"] = p
        docs.append(d)
    return docs


def run_extract(input_dir, work_dir):
    case, err_work, input_error = load_case(input_dir, work_dir, None)
    docs = gather_materials(input_dir)
    no_material = len(docs) == 0
    if err_work is not None:
        wf = err_work
        wf["documents"] = []
        wf["_input_error"] = input_error
        wf["_no_material"] = no_material
        return wf, input_error, no_material
    wf = lib.scaffold(case, docs, work_dir)
    wf["_input_error"] = input_error
    wf["_no_material"] = no_material
    if no_material:
        wf["gaps"].append({"field": "materials", "reason": "输入目录未发现材料文件"})
        wf["degradations"].append({"file": "*", "note": "无材料"})
    else:
        wf = lib.auto_derive(wf, work_dir)
    return wf, input_error, no_material


def _is_substantive(wf):
    """判断 work.json 是否已由 Agent/草稿实质填写（有则保留，不再自动派生）。"""
    if not wf:
        return False
    notes = wf.get("notes") or {}
    pc = notes.get("paper_card") or {}
    answers = wf.get("answers") or {}
    if any(v not in (None, "", [], {}) for v in pc.values()):
        return True
    if notes.get("section_summaries") or notes.get("knowledge_points"):
        return True
    if any(v not in (None, "", [], {}) for v in answers.values()):
        return True
    return False


def write_work(work_dir, wf):
    os.makedirs(work_dir, exist_ok=True)
    with open(os.path.join(work_dir, "work.json"), "w", encoding="utf-8") as f:
        json.dump(wf, f, ensure_ascii=False, indent=2)


def read_work(work_dir):
    p = os.path.join(work_dir, "work.json")
    if not os.path.isfile(p):
        return None
    return lib.load_json(p)


def _load_or_derive(input_dir, work_dir):
    """读取已有草稿（保留）或全新抽取并自动派生；返回 (wf, input_error, no_material, derived)。"""
    wf = read_work(work_dir)
    if wf is not None and _is_substantive(wf):
        return wf, bool(wf.get("_input_error", False)), bool(wf.get("_no_material", False)), False
    wf, input_error, no_material = run_extract(input_dir, work_dir)
    write_work(work_dir, wf)
    return wf, input_error, no_material, True


def cmd_init(args):
    input_dir, work_dir, output_dir = resolve_dirs(args)
    try:
        wf, input_error, no_material, derived = _load_or_derive(input_dir, work_dir)
        lib.build_result(wf, work_dir, output_dir, input_error, no_material)
        print("init ok: %d documents, %d contract fields, %d gaps%s" % (
            len(wf.get("documents", [])), len(wf.get("_contract_keys", [])),
            len(wf.get("gaps", [])), " (auto-derived)" if derived else ""))
        return 0
    except Exception as e:
        return _emergency(work_dir, output_dir, "init 失败: %s" % e, input_dir)


def cmd_show(args):
    _, work_dir, _ = resolve_dirs(args)
    wf = read_work(work_dir)
    if wf is None:
        print("no work.json")
        return 0
    n = wf.get("notes") or {}
    print("case_id=%s docs=%d contract=%d gaps=%d sections=%d kps=%d" % (
        wf.get("case_id"), len(wf.get("documents", [])),
        len(wf.get("_contract_keys", [])), len(wf.get("gaps", [])),
        len(n.get("section_summaries", [])), len(n.get("knowledge_points", []))))
    return 0


def cmd_check(args):
    _, work_dir, _ = resolve_dirs(args)
    wf = read_work(work_dir)
    if wf is None:
        print("no work.json")
        return 0
    ver = lib.verify_quotes(wf, work_dir)
    os.makedirs(work_dir, exist_ok=True)
    with open(os.path.join(work_dir, "check_report.json"), "w", encoding="utf-8") as f:
        json.dump(ver, f, ensure_ascii=False, indent=2)
    print("quotes=%d hits=%d hit_rate=%.3f" % (ver["total"], ver["hits"], ver["hit_rate"]))
    for r in ver["details"]:
        if not r["verified"]:
            print("  MISS: %s -> %s" % (r["path"], r["quote"]))
    return 0


def cmd_build(args):
    input_dir, work_dir, output_dir = resolve_dirs(args)
    try:
        wf, input_error, no_material, _derived = _load_or_derive(input_dir, work_dir)
        lib.build_result(wf, work_dir, output_dir, input_error, no_material)
        print("build ok -> %s/result.json" % output_dir)
        return 0
    except Exception as e:
        return _emergency(work_dir, output_dir, "build 失败: %s" % e, input_dir)


def _emergency(work_dir, output_dir, reason, input_dir=None):
    os.makedirs(output_dir, exist_ok=True)
    result = {
        "case_id": None, "status": "input_error", "sources": [],
        "uncertainty": [], "change_records": [{"step": "emergency", "detail": reason}],
        "notes": {}, "gaps": [{"field": "all", "reason": reason}],
        "errors": [reason], "degradations": [],
    }
    # 尽力回填契约键，避免漏键
    if input_dir:
        cp = os.path.join(input_dir, "case.json")
        if os.path.isfile(cp):
            try:
                c = lib.load_json(cp)
                oc = c.get("output_contract")
                if isinstance(oc, dict):
                    result["case_id"] = c.get("case_id")
                    for k in oc:
                        result[k] = None
            except Exception:
                pass
    with open(os.path.join(output_dir, "result.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(reason)
    return 0


def cmd_full(args):
    input_dir, work_dir, output_dir = resolve_dirs(args)
    try:
        wf, input_error, no_material, _derived = _load_or_derive(input_dir, work_dir)
        ver = lib.verify_quotes(wf, work_dir)
        os.makedirs(work_dir, exist_ok=True)
        with open(os.path.join(work_dir, "check_report.json"), "w", encoding="utf-8") as f:
            json.dump(ver, f, ensure_ascii=False, indent=2)
        print("quotes=%d hits=%d hit_rate=%.3f" % (ver["total"], ver["hits"], ver["hit_rate"]))
        for r in ver["details"]:
            if not r["verified"]:
                print("  MISS: %s -> %s" % (r["path"], r["quote"]))
        lib.build_result(wf, work_dir, output_dir, input_error, no_material)
        print("build ok -> %s/result.json" % output_dir)
        return 0
    except Exception as e:
        return _emergency(work_dir, output_dir, "full 失败: %s" % e, input_dir)


def main():
    ap = argparse.ArgumentParser(description="文献结构化笔记 Skill 脚本")
    ap.add_argument("command", nargs="?", default="full",
                    choices=["full", "init", "show", "check", "build"])
    ap.add_argument("--input", dest="input", default=None)
    ap.add_argument("--work", dest="work", default=None)
    ap.add_argument("--output", dest="output", default=None)
    args = ap.parse_args()
    cmd = {"full": cmd_full, "init": cmd_init, "show": cmd_show,
           "check": cmd_check, "build": cmd_build}.get(args.command, cmd_full)
    return cmd(args)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit as e:
        raise
    except Exception:
        sys.exit(0)

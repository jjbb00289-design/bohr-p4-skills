# -*- coding: utf-8 -*-
"""纯标准库材料抽取、工作稿脚手架、引文校验、结果组装。不联网，不依赖 CWD。"""
import os
import re
import json
import zlib
import zipfile
import io


def norm(s):
    if s is None:
        return ""
    return re.sub(r"\s+", " ", str(s)).strip()


def load_json(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def read_text(path):
    raw = open(path, "rb").read()
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1", errors="replace")


def list_files(d):
    out = []
    if not os.path.isdir(d):
        return out
    for root, dirs, files in os.walk(d):
        dirs.sort()
        files.sort()
        for fn in files:
            out.append(os.path.join(root, fn))
    return out


def _paren_text(btok):
    out = bytearray()
    i = 1
    n = len(btok)
    while i < n:
        c = btok[i:i + 1]
        if c == b"\\":
            if i + 1 < n:
                nx = btok[i + 1:i + 2]
                if nx == b"n":
                    out.append(0x0A); i += 2; continue
                if nx == b"r":
                    out.append(0x0D); i += 2; continue
                if nx == b"t":
                    out.append(0x09); i += 2; continue
                if nx in (b"(", b")", b"\\"):
                    out.append(nx[0]); i += 2; continue
                if nx in b"01234567":
                    j = i + 1
                    num = b""
                    while j < n and j < i + 4 and btok[j:j + 1] in b"01234567":
                        num += btok[j:j + 1]
                        j += 1
                    out.append(int(num, 8) & 0xFF)
                    i = j
                    continue
            i += 1
            continue
        if c == b")":
            break
        out.append(c[0])
        i += 1
    return bytes(out)


def _decode_bytes(b):
    for enc in ("utf-8", "latin-1"):
        try:
            return b.decode(enc)
        except (UnicodeDecodeError, AttributeError):
            continue
    return b.decode("latin-1", errors="replace")


def extract_pdf_text(data):
    """最小 PDF 文本抽取：zlib 解压流 + 文本域/BT-ET 内 Tj/TJ 算子。返回 (text, pages, note)。"""
    pages = len(re.findall(rb"/Type\s*/Page(?!s)", data))
    if pages == 0:
        m = re.search(rb"/Count\s+(\d+)", data)
        if m:
            pages = int(m.group(1))
    chunks = []
    streams = 0
    for sm in re.finditer(rb"stream\r?\n(.*?)endstream", data, re.S):
        raw = sm.group(1).rstrip(b"\r\n")
        if not raw:
            continue
        streams += 1
        try:
            dec = zlib.decompress(raw)
        except Exception:
            dec = raw
        for bt in re.finditer(rb"BT(.*?)ET", dec, re.S):
            block = bt.group(1)
            for tj in re.finditer(rb"\((?:[^()\\]|\\.)*\)\s*Tj", block):
                chunks.append(_paren_text(tj.group(0)))
            for tj in re.finditer(rb"\[(.*?)\]\s*TJ", block):
                inner = tj.group(1)
                for pm in re.finditer(rb"\((?:[^()\\]|\\.)*\)", inner):
                    chunks.append(_paren_text(pm.group(0)))
    text = "\n".join(_decode_bytes(c) for c in chunks)
    note = ""
    if not text.strip():
        if streams == 0:
            note = "PDF 未发现可解压流，可能为扫描件/无文本层"
        else:
            note = "PDF 含 %d 个流但未抽到文本，可能为扫描件或仅图片，需 OCR" % streams
    return text, pages, note


def extract_docx_text(data):
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            xml = z.read("word/document.xml")
    except Exception:
        return ""
    xml = re.sub(rb"</w:p>", b"\n", xml)
    xml = re.sub(rb"<w:tab[^>]*/>", b"\t", xml)
    ts = re.findall(rb"<w:t[^>]*>(.*?)</w:t>", xml, re.S)
    txt = b"".join(ts)
    txt = txt.replace(b"&amp;", b"&").replace(b"&lt;", b"<").replace(b"&gt;", b">")
    return txt.decode("utf-8", errors="replace")


KIND = {
    ".pdf": "pdf", ".docx": "docx", ".txt": "text", ".md": "text", ".markdown": "text",
    ".json": "json", ".csv": "text", ".tsv": "text", ".tex": "text", ".html": "text",
    ".htm": "text", ".xml": "text", ".rtf": "text",
}
IMG = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp", ".svg"}


def extract_file(path):
    ext = os.path.splitext(path)[1].lower()
    kind = KIND.get(ext, "other")
    if ext in IMG:
        return {"kind": "image", "parse": "unsupported",
                "pages": None, "text": "",
                "note": "图片材料，需 OCR；本脚本不内置 OCR"}
    try:
        raw = open(path, "rb").read()
    except Exception as e:
        return {"kind": kind, "parse": "failed", "pages": None, "text": "",
                "note": "读取失败: %s" % e}
    if kind == "pdf":
        text, pages, note = extract_pdf_text(raw)
        parse = "ok" if text.strip() else "partial"
        return {"kind": kind, "parse": parse, "pages": pages, "text": text,
                "note": note}
    if kind == "docx":
        text = extract_docx_text(raw)
        return {"kind": kind, "parse": "ok" if text.strip() else "partial",
                "pages": None, "text": text,
                "note": "DOCX document.xml 抽取" if text.strip() else "DOCX 未抽到文本"}
    if kind in ("text", "json", "csv"):
        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = raw.decode("latin-1", errors="replace")
        return {"kind": kind, "parse": "ok", "pages": None, "text": text, "note": ""}
    # other: 尝试当文本读
    try:
        text = raw.decode("utf-8-sig")
        return {"kind": kind, "parse": "ok" if text.strip() else "partial",
                "pages": None, "text": text, "note": "按文本读取"}
    except UnicodeDecodeError:
        return {"kind": kind, "parse": "unsupported", "pages": None, "text": "",
                "note": "二进制/未支持类型，未解析内容"}


HEAD_RE = re.compile(
    r"^\s*(?:([0-9]+(?:\.[0-9]+)*)\s*[.、]?\s+|([0-9]+)\s*[.、]?\s+)?([^\n]{2,80})\s*$")
SECTION_NAMES = {
    "abstract", "introduction", "background", "related work", "method", "methods",
    "methodology", "materials and methods", "experimental", "experiments",
    "experiment", "results", "result", "discussion", "conclusion", "conclusions",
    "conclusion and discussion", "references", "acknowledgement", "acknowledgements",
    "appendix", "supplementary", "limitations", "摘要", "引言", "介绍", "背景",
    "相关工作", "方法", "材料与方法", "实验", "结果", "讨论", "结论", "参考文献",
    "致谢", "附录", "补充材料", "局限", "局限性",
}


def detect_sections(text):
    lines = text.split("\n")
    out = []
    for idx, ln in enumerate(lines):
        s = ln.strip()
        if not s or len(s) > 90:
            continue
        low = s.lower().lstrip("0123456789.、 )（")
        m = HEAD_RE.match(s)
        numbered = bool(m and m.group(1))
        name_hit = low in SECTION_NAMES or any(
            low.startswith(w) and len(low) <= len(w) + 12 for w in SECTION_NAMES)
        if numbered or name_hit:
            out.append({"section_id": "s%d" % len(out),
                        "heading": s, "line": idx + 1})
    return out


def paragraphs(text):
    return [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]


# ---------------------------------------------------------------------------
# 自动派生：无 Agent 草稿时，从已抽取材料文本规则化填充 notes 与 answers。
# 每条 evidence.quote 都经「逐字命中原文」过滤，不命中即丢弃，不伪造数据。
# ---------------------------------------------------------------------------

_SECTION_MAP = {
    "abstract": "abstract", "摘要": "abstract", "概要": "abstract",
    "introduction": "introduction", "intro": "introduction", "引言": "introduction",
    "介绍": "introduction", "background": "introduction", "背景": "introduction",
    "related work": "introduction", "相关工作": "introduction",
    "method": "methods", "methods": "methods", "methodology": "methods",
    "materials and methods": "methods", "材料与方法": "methods",
    "材料和方法": "methods", "方法": "methods", "实验": "methods",
    "experimental": "methods", "experiments": "methods", "experiment": "methods",
    "result": "results", "results": "results", "结果": "results",
    "discussion": "discussion", "讨论": "discussion", "结果与讨论": "discussion",
    "conclusion": "conclusion", "conclusions": "conclusion", "结论": "conclusion",
    "conclusion and discussion": "discussion", "结论与讨论": "discussion",
    "limitation": "limitations", "limitations": "limitations",
    "局限": "limitations", "局限性": "limitations", "限制": "limitations",
}
_SECTION_KEYS = sorted(_SECTION_MAP.keys(), key=len, reverse=True)

_STAT_WORDS = (
    "significant", "significantly", "p <", "p<", "p =", "p=", "d =", "d=",
    "effect size", "odds ratio", "hazard ratio", "increase", "decrease",
    "higher", "lower", "improve", "reduce", "correlat", "associat",
    "显著", "提升", "下降", "增加", "减少", "改善", "相关",
)
_LIMIT_WORDS = (
    "limit", "limitation", "however", "nevertheless", "further", "future work",
    "single-center", "single centre", "small sample", "cannot", "not reported",
    "did not", "unclear", "remains", "局限", "不足", "然而", "尚需", "有待",
    "未能", "仅", "样本量小", "单中心", "需要进一步",
)
_DATA_WORDS = (
    "participants", "participant", "sample", "patients", "subjects", "subject",
    "n=", "n =", "cohort", "cohorts", "数据集", "样本", "患者", "被试", "队列",
)
_NUM_PAT = re.compile(
    r"(?:N\s*=\s*\d+(?:[,.]\d+)*|n\s*=\s*\d+(?:[,.]\d+)*|"
    r"\d+(?:\.\d+)?\s*%|p\s*[<>=≤≥]\s*0?\.\d+|d\s*=\s*0?\.\d+|"
    r"odds ratio|hazard ratio|effect size|"
    r"CI\s*[\[(][^)\]]+[\])]|95\s*%\s*(?:CI|ci))"
)


def _classify_line(s):
    t = s.strip()
    m = re.match(r"^\s*(\d+(?:\.\d+)*)\s*[.、:：]?\s*(.*)$", t)
    body = m.group(2) if m else t
    low = body.lower()
    for w in _SECTION_KEYS:
        if low.startswith(w):
            rest = body[len(w):]
            if rest == "" or not rest[0].isalnum():
                return _SECTION_MAP[w], rest.lstrip(".:：、 \t").strip()
    return None, t


def _split_sentences(text):
    text = text.strip()
    if not text:
        return []
    guarded = re.sub(
        r"\b(e\.g|i\.e|vs|etc|al|Fig|fig|Eq|eq|Ref|ref|cf|et)\.",
        lambda m: m.group(0).replace(".", "\x00"), text)
    parts = re.split(r"(?<=[.!?。！？])\s+(?=[A-Z0-9\u4e00-\u9fff\u201c\"])", guarded)
    out = []
    for p in parts:
        p = p.replace("\x00", ".").strip()
        if p:
            out.append(p)
    return out


def _filled(v):
    if v is None:
        return False
    if isinstance(v, str):
        return bool(v.strip())
    if isinstance(v, (list, dict)):
        return len(v) > 0
    return True


def _extract_rq(sents):
    for _, _, sent in sents[:12]:
        m = re.search(
            r"(?:whether|是否)\s+(.{6,160}?)(?=\s+in\s+|\s+using\s+|\s+among\s+"
            r"|\s+with\s+|\s+by\s+|\.|$)", sent, re.I)
        if m:
            frag = m.group(1).strip().rstrip(".").strip()
            if frag:
                return "Whether " + frag
        m2 = re.search(
            r"(?:we|this study|this paper|本研究|本文)\s+(?:study|studies|examine|"
            r"investigate|ask|aim|evaluate|assess|研究|考察|评估)\s*(.{6,200}?)"
            r"(?=\.|;|$)", sent, re.I)
        if m2:
            frag = m2.group(1).strip().rstrip(".").strip()
            if frag:
                return frag
    return None


def auto_derive(work, work_dir):
    """在无 Agent 草稿时，从已抽取文本规则化填充 notes 与 answers；返回 work。"""
    docs = work.get("documents") or []
    primary = None
    for d in docs:
        if d.get("parse") not in ("ok", "partial"):
            continue
        tf = os.path.join(work_dir, d.get("text_file", ""))
        if not os.path.isfile(tf):
            continue
        txt = read_text(tf)
        if txt.strip():
            if primary is None or len(txt) > len(primary[1]):
                primary = (d, txt)
    if primary is None:
        work.setdefault("gaps", []).append(
            {"field": "auto_derive", "reason": "无可抽取文本材料，未能自动派生"})
        return work

    doc, raw = primary
    raw_norm = norm(raw)
    pages = doc.get("pages")

    units = []
    current = "abstract"
    for i, ln in enumerate(raw.split("\n"), 1):
        s = ln.strip()
        if not s:
            continue
        sec, rest = _classify_line(s)
        if sec is not None:
            current = sec
            if rest:
                units.append({"section": current, "line": i, "text": rest})
        else:
            units.append({"section": current, "line": i, "text": s})

    sents = []
    for u in units:
        for sent in _split_sentences(u["text"]):
            sents.append((u["section"], u["line"], sent))

    def loc(section, line):
        try:
            p = int(pages)
        except (TypeError, ValueError):
            p = 0
        if p == 1:
            return "p.1 §%s 第%d行" % (section, line)
        return "§%s 第%d行" % (section, line)

    def ev(section, line, sent):
        qn = norm(sent)
        if not qn or qn not in raw_norm:
            return None
        return {"locator": loc(section, line), "quote": sent}

    by_sec = {}
    for sec, line, sent in sents:
        by_sec.setdefault(sec, []).append((line, sent))

    abstract_sents = [s for _, s in by_sec.get("abstract", [])]
    if abstract_sents:
        summary = " ".join(abstract_sents[:3])
    else:
        summary = " ".join(s for _, _, s in sents[:3])
    summary = summary.strip()

    findings = []
    for sec in ("results", "discussion", "conclusion"):
        for line, sent in by_sec.get(sec, []):
            if len(findings) >= 6:
                break
            e = ev(sec, line, sent)
            if e:
                findings.append({"section": sec, "line": line, "claim": sent, "evidence": e})
        if len(findings) >= 6:
            break
    if not findings:
        for sec, line, sent in sents:
            if len(findings) >= 4:
                break
            low = sent.lower()
            if any(w in low for w in _STAT_WORDS):
                e = ev(sec, line, sent)
                if e:
                    findings.append({"section": sec, "line": line, "claim": sent, "evidence": e})

    limits = []
    for line, sent in by_sec.get("limitations", []):
        if len(limits) >= 5:
            break
        e = ev("limitations", line, sent)
        if e:
            limits.append({"section": "limitations", "line": line, "item": sent, "evidence": e})
    if not limits:
        for sec, line, sent in sents:
            if len(limits) >= 3:
                break
            low = sent.lower()
            if any(w in low for w in _LIMIT_WORDS):
                e = ev(sec, line, sent)
                if e:
                    limits.append({"section": sec, "line": line, "item": sent, "evidence": e})

    rq = _extract_rq(sents)
    if not rq and abstract_sents:
        rq = abstract_sents[0]
    if not rq and sents:
        rq = sents[0][2]

    data_s = None
    methods_s = None
    for sec in ("methods", "abstract"):
        for line, sent in by_sec.get(sec, []):
            low = sent.lower()
            if data_s is None and any(w in low for w in _DATA_WORDS):
                data_s = sent
            if methods_s is None and sec == "methods":
                methods_s = sent
        if data_s and methods_s:
            break
    if methods_s is None:
        for sec in ("methods", "abstract"):
            if by_sec.get(sec):
                methods_s = by_sec[sec][0][1]
                break
    if data_s is None:
        data_s = methods_s

    concl_s = None
    for sec in ("conclusion", "discussion"):
        if by_sec.get(sec):
            concl_s = by_sec[sec][-1][1]
            break
    if concl_s is None and findings:
        concl_s = findings[-1]["claim"]

    notes = work.get("notes") or {}
    work["notes"] = notes
    pc = notes.get("paper_card") or {}
    notes["paper_card"] = pc
    pc["research_question"] = rq
    pc["data"] = data_s
    pc["methods"] = methods_s
    pc["main_findings"] = [
        {"claim": f["claim"], "evidence": [f["evidence"]]} for f in findings]
    pc["conclusions"] = concl_s
    pc["limitations"] = [
        {"item": f["item"], "evidence": [f["evidence"]]} for f in limits]

    order = ["abstract", "introduction", "methods", "results",
             "discussion", "conclusion", "limitations"]
    ssum = []
    for sec in order:
        items = by_sec.get(sec, [])
        if not items:
            continue
        line, sent = items[0]
        e = ev(sec, line, sent)
        if not e:
            continue
        entry = {"section_id": sec, "heading": sec, "purpose": None,
                 "method": None, "result": None, "conclusion": None,
                 "evidence": [e]}
        if sec == "abstract":
            entry["purpose"] = "摘要"
        elif sec == "introduction":
            entry["purpose"] = "研究背景与问题"
        elif sec == "methods":
            entry["method"] = sent
        elif sec == "results":
            entry["result"] = sent
        elif sec in ("discussion", "conclusion"):
            entry["conclusion"] = sent
        elif sec == "limitations":
            entry["purpose"] = "作者声明的局限"
        ssum.append(entry)
    notes["section_summaries"] = ssum

    kps = []
    kp_id = 0
    for sec, line, sent in sents:
        if len(kps) >= 8:
            break
        m = _NUM_PAT.search(sent)
        if not m:
            continue
        e = ev(sec, line, sent)
        if not e:
            continue
        kp_id += 1
        kps.append({"id": "k%d" % kp_id, "term": m.group(0), "kind": "variable",
                    "statement": sent, "term_variants": [], "evidence": [e]})
    notes["knowledge_points"] = kps

    links = []
    if abstract_sents:
        first = abstract_sents[0]
        line = by_sec.get("abstract", [(None, None)])[0][0]
        e = ev("abstract", line, first) if line else None
        if e:
            links.append({"target": "summary", "locator": e["locator"],
                          "quote": e["quote"], "note": "摘要逐字来源"})
    notes["evidence_links"] = links

    answers = work.get("answers") or {}
    work["answers"] = answers
    if "summary" in answers:
        answers["summary"] = summary
    if "key_findings" in answers:
        answers["key_findings"] = [
            {"claim": f["claim"], "evidence": [f["evidence"]]} for f in findings]
    if "limitations" in answers:
        answers["limitations"] = [
            {"item": f["item"], "evidence": [f["evidence"]]} for f in limits]

    work["gaps"] = [g for g in work.get("gaps", [])
                    if "未由 Agent 填写" not in (g.get("reason") or "")]
    contract_keys = work.get("_contract_keys") or []
    for k in contract_keys:
        if not _filled(answers.get(k)):
            work["gaps"].append({"field": k, "reason": "未能自动派生，需 Agent/人工确认"})
    for k in ("research_question", "data", "methods", "conclusions"):
        if not _filled(pc.get(k)):
            work["gaps"].append(
                {"field": "notes.paper_card.%s" % k, "reason": "材料未报告或未能自动派生"})
    if not pc.get("main_findings"):
        work["gaps"].append({"field": "notes.paper_card.main_findings",
                             "reason": "未能自动派生主要发现"})
    if not pc.get("limitations"):
        work["gaps"].append({"field": "notes.paper_card.limitations",
                             "reason": "未能自动派生局限"})
    work.setdefault("change_records", []).append(
        {"step": "auto_derive", "detail": "无 Agent 草稿，规则化派生 notes/answers"})
    return work


def scaffold(case, docs, work_dir):
    contract = case.get("output_contract")
    if not isinstance(contract, dict):
        contract = {}
    answers = {k: None for k in contract.keys()}
    notes = {
        "title": None,
        "paper_card": {
            "research_question": None, "data": None, "methods": None,
            "main_findings": [], "conclusions": None, "limitations": []},
        "section_summaries": [], "knowledge_points": [], "evidence_links": [],
        "unreported": [], "conflicts": []}
    docs_out = []
    for i, d in enumerate(docs):
        text_file = "text/%02d_%s.txt" % (i, os.path.basename(d["path"]))
        os.makedirs(os.path.join(work_dir, "text"), exist_ok=True)
        with open(os.path.join(work_dir, text_file), "w", encoding="utf-8") as f:
            f.write(d["text"])
        sections = detect_sections(d["text"])
        docs_out.append({"path": d["path"], "kind": d["kind"], "parse": d["parse"],
                         "pages": d["pages"], "text_file": text_file,
                         "text_length": len(d["text"]),
                         "sections": sections, "note": d.get("note", "")})
    gaps = [{"field": k, "reason": "未由 Agent 填写"} for k in contract.keys()]
    gaps += [
        {"field": "notes.paper_card", "reason": "未由 Agent 填写"},
        {"field": "notes.section_summaries", "reason": "未由 Agent 填写"}]
    wf = {
        "schema_version": "1.0",
        "_contract_keys": list(contract.keys()),
        "_input_error": False,
        "_no_material": False,
        "case_id": case.get("case_id"),
        "task_instruction": case.get("task_instruction"),
        "documents": docs_out,
        "answers": answers,
        "notes": notes,
        "uncertainty": [],
        "gaps": gaps,
        "change_records": [{"step": "init", "detail": "脚手架已生成，抽取 %d 个材料" % len(docs_out)}],
        "errors": [],
        "degradations": [{"file": d["path"], "note": d["note"]}
                         for d in docs if d.get("note")],
    }
    return wf


def collect_quotes(work):
    """返回 [(entry_path, quote)]，其中 quote 可校验；覆盖 notes 与 answers 契约字段。"""
    out = []
    def walk(prefix, node):
        if isinstance(node, dict):
            if "quote" in node and isinstance(node.get("quote"), str) and node["quote"].strip():
                out.append((prefix + ".quote", node["quote"]))
            for k, v in node.items():
                walk(prefix + "." + k, v)
        elif isinstance(node, list):
            for i, v in enumerate(node):
                walk("%s[%d]" % (prefix, i), v)
    walk("notes", work.get("notes") or {})
    walk("answers", work.get("answers") or {})
    return out


def verify_quotes(work, work_dir):
    corpus = ""
    files = []
    for d in work.get("documents", []):
        tf = os.path.join(work_dir, d.get("text_file", ""))
        if os.path.isfile(tf):
            txt = read_text(tf)
            corpus += "\n" + norm(txt)
            files.append(tf)
    target = norm(corpus)
    total = 0
    hits = 0
    report = []
    for path, q in collect_quotes(work):
        total += 1
        qn = norm(q)
        ok = bool(qn) and qn in target
        if ok:
            hits += 1
        report.append({"path": path, "quote": qn[:120], "verified": ok})
    return {"total": total, "hits": hits,
            "hit_rate": (hits / total) if total else 1.0,
            "corpus_files": files, "details": report}


def determine_status(work, input_error, no_material):
    if input_error:
        return "input_error"
    if no_material:
        return "insufficient_evidence"
    errors = work.get("errors") or []
    if errors:
        return "partial"
    answers = work.get("answers") or {}
    keys = work.get("_contract_keys") or []
    contract_ok = all(_filled(answers.get(k)) for k in keys)
    notes = work.get("notes") or {}
    pc = notes.get("paper_card") or {}
    core_ok = all(_filled(pc.get(k)) for k in
                  ("research_question", "data", "methods", "conclusions")) \
        and bool(pc.get("main_findings")) and bool(pc.get("limitations"))
    open_gaps = [g for g in (work.get("gaps") or [])
                 if any(s in (g.get("reason") or "")
                        for s in ("未", "未能", "需 Agent", "需人工"))]
    if contract_ok and core_ok and not open_gaps:
        return "complete"
    return "partial"


def build_result(work, work_dir, output_dir, input_error=False, no_material=False):
    ver = verify_quotes(work, work_dir)
    case_contract = work.get("_contract_keys") or []
    answers = work.get("answers") or {}
    result = {}
    for k in case_contract:
        result[k] = answers.get(k)
    result["case_id"] = work.get("case_id")
    result["status"] = determine_status(work, input_error, no_material)
    result["sources"] = [
        {"path": d["path"], "kind": d["kind"], "parse": d["parse"],
         "pages": d["pages"], "text_file": d.get("text_file"),
         "sections": d.get("sections", []), "note": d.get("note", "")}
        for d in work.get("documents", [])]
    result["verification"] = {
        "quote_total": ver["total"], "quote_hits": ver["hits"],
        "hit_rate": ver["hit_rate"],
        "unverified": [r for r in ver["details"] if not r["verified"]]}
    result["uncertainty"] = work.get("uncertainty", [])
    result["change_records"] = work.get("change_records", [])
    result["notes"] = work.get("notes")
    result["gaps"] = work.get("gaps", [])
    result["errors"] = work.get("errors", [])
    result["degradations"] = work.get("degradations", [])
    os.makedirs(output_dir, exist_ok=True)
    with open(os.path.join(output_dir, "result.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    write_notes_md(result, os.path.join(output_dir, "notes.md"))
    return result


def write_notes_md(result, path):
    lines = ["# 结构化笔记：%s" % ((result.get("notes") or {}).get("title") or "（未命名论文）"), ""]
    notes = result.get("notes") or {}
    pc = notes.get("paper_card") or {}
    lines.append("## 论文卡片")
    for k, label in (("research_question", "研究问题"), ("data", "数据"),
                     ("methods", "方法"), ("conclusions", "结论")):
        v = pc.get(k)
        lines.append("- **%s**：%s" % (label, v if v not in (None, "") else "（未报告）"))
    mf = pc.get("main_findings") or []
    lines.append("- **主要发现**：")
    for f in mf:
        if isinstance(f, dict):
            lines.append("  - %s" % f.get("claim", ""))
            for e in f.get("evidence", [])[:1]:
                lines.append("    - 依据：%s | %s" % (e.get("locator"), e.get("quote")))
    lm = pc.get("limitations") or []
    lines.append("- **局限**：")
    for f in lm:
        if isinstance(f, dict):
            lines.append("  - %s" % f.get("item", ""))
    lines.append("")
    lines.append("## 章节总结")
    for s in notes.get("section_summaries") or []:
        lines.append("### %s %s" % (s.get("section_id", ""), s.get("heading", "")))
        if s.get("purpose"):
            lines.append("- 目的：%s" % s["purpose"])
        if s.get("result"):
            lines.append("- 结果：%s" % s["result"])
        if s.get("conclusion"):
            lines.append("- 结论：%s" % s["conclusion"])
        for e in s.get("evidence", [])[:2]:
            lines.append("  - 依据：%s | %s" % (e.get("locator"), e.get("quote")))
    lines.append("")
    lines.append("## 知识点")
    for k in notes.get("knowledge_points") or []:
        lines.append("- [%s] %s：%s" % (k.get("id", ""), k.get("term", ""), k.get("statement", "")))
        for e in k.get("evidence", [])[:1]:
            lines.append("  - 依据：%s | %s" % (e.get("locator"), e.get("quote")))
    lines.append("")
    lines.append("## 未报告/不确定")
    for u in notes.get("unreported") or []:
        lines.append("- %s：%s" % (u.get("item", ""), u.get("reason", "")))
    lines.append("")
    lines.append("## 缺口")
    for g in result.get("gaps") or []:
        lines.append("- %s：%s" % (g.get("field", ""), g.get("reason", "")))
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

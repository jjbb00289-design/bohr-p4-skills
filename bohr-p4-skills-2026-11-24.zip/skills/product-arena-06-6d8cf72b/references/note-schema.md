# 笔记字段字典与示例

本文件是 `SKILL.md` 中 `notes` 字段的字典，供 Agent 与人工复核使用。示例均标注“示例，非正式案例结果”。

## paper_card（论文卡片，多篇可并排比较）

| 字段 | 类型 | 含义 | 机器可判定 |
|-|-|-|-|
| research_question | string | 研究问题/目标 | 否（需人工确认语义） |
| data | string/object | 数据与样本、数量、来源、条件 | 部分（数值可核验） |
| methods | string/object | 方法与条件、前提（指标/对照组/显著性） | 部分 |
| main_findings | list | `{"claim","evidence":[{locator,quote}]}` | quote 命中可机器判定 |
| conclusions | string | 结论 | 否 |
| limitations | list | `{"item","evidence"}` 或 not_reported | 部分 |

## section_summaries（章节对齐，按原文顺序）

`{"section_id","heading","purpose","method","result","conclusion","evidence":[{locator,quote}]}`
缺某要素写 `null` 并记入 `gaps`。不得脱离原文结构合并成通读摘要。

## knowledge_points（可检索条目）

`{"id","term","kind":"concept|variable|method|result","statement","term_variants":[],"evidence":[{locator,quote}]}`
术语/缩写/同义表述归一，避免条目重复或矛盾。

## evidence_links / unreported / conflicts

- evidence_links：`{"target","locator","quote","note"}`，来源回链。
- unreported：`{"item","reason"}`，未报告/无法判断，不得写成事实。
- conflicts：`{"a","b","note"}`，材料内部或材料间冲突。

## 锚点格式（locator）

- 页码：`p.4`
- 段落：`§3.2 第3段` 或 `para 12`
- 图表：`Table 2` / `Fig. 3` / `公式 (5)`
- 给不出精确位置：`§定位待人工`，并列入 gaps。

## 示例（示例，非正式案例结果）

```json
{
  "title": "示例论文标题",
  "paper_card": {
    "research_question": "示例：研究 X 是否影响 Y",
    "data": "示例：N=120 名被试，来源：某数据集",
    "methods": "示例：随机对照，双尾 t 检验，α=0.05",
    "main_findings": [
      {"claim": "示例：组间差异显著", "evidence": [{"locator": "§3.2 第2段", "quote": "significantly higher (p < 0.01)"}]}
    ],
    "conclusions": "示例：X 显著提升 Y",
    "limitations": [{"item": "示例：样本单一中心", "evidence": [{"locator": "§5 第1段", "quote": "single-center"}]}]
  },
  "section_summaries": [
    {"section_id": "s0", "heading": "Methods", "purpose": "示例：描述实验设计", "method": "示例：双盲", "result": null, "conclusion": null, "evidence": [{"locator": "§2 第1段", "quote": "double-blind"}]}
  ],
  "knowledge_points": [],
  "evidence_links": [],
  "unreported": [],
  "conflicts": []
}
```

## 自检要点

- 每条 evidence.quote 用 `main.py check` 校验命中原文（空白归一后子串匹配）。
- result.json 含 output_contract 全字段 + case_id，缺值用 null/[]，不改名不漏键。
- 退出码恒 0；异常写 errors/degradations。

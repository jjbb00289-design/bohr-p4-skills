import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from records import (extract_from_file, norm_ws, read_text, dedup_records,
                     rank_candidates, apply_judgments, build_query_plan, fallback_terms)

FIXTURE_TOKENS = ("synthetic", "fixture", "sample record", "duplicate export",
                  "示例", "重复导出", "合成", "测试样例")
_MAP = ((("candidate", "paper", "literature", "record", "article", "item"), "candidates", []),
        (("rank", "order", "sort", "priority"), "ranking", []),
        (("screen", "label", "tier"), "coverage", {}),
        (("summar", "overview"), "summary", ""),
        (("cover", "recall", "precision", "metric"), "coverage", {}),
        (("plan", "quer"), "query_plan", []),
        (("conflict", "dedup", "duplicate"), "conflicts", []),
        (("omission", "gap", "missing", "exclu"), "omissions", []))


def resolve_dirs(args):
    return (args.input or os.environ.get("INPUT_DIR") or "/input",
            args.work or os.environ.get("WORK_DIR") or "/app/work",
            args.output or os.environ.get("OUTPUT_DIR") or "/app/output")


def load_input(input_dir):
    errors, case, task_text = [], None, ""
    cp = os.path.join(input_dir, "case.json")
    if os.path.isfile(cp):
        try:
            case = json.loads(read_text(cp))
        except (OSError, json.JSONDecodeError) as e:
            errors.append("case.json bad: %s" % e)
    else:
        errors.append("缺 case.json")
    tp = os.path.join(input_dir, "task.md")
    if os.path.isfile(tp):
        try:
            task_text = read_text(tp)
        except OSError as e:
            errors.append("task.md bad: %s" % e)
    else:
        errors.append("缺 task.md")
    return case, task_text, errors


def case_field(case, *names):
    for n in names:
        v = case.get(n) if isinstance(case, dict) else None
        if v:
            return v
    return None


def _under(path, base):
    if not base:
        return False
    try:
        return os.path.commonpath([os.path.abspath(path), os.path.abspath(base)]) \
            == os.path.abspath(base)
    except ValueError:
        return False


def collect_materials(input_dir, work_dir=None, output_dir=None):
    records, notes, files_seen, paths = [], [], [], []
    for root, _dirs, files in os.walk(input_dir):
        for fn in files:
            if fn in ("case.json", "task.md"):
                continue
            path = os.path.join(root, fn)
            if _under(path, work_dir) or _under(path, output_dir):
                continue
            paths.append((os.path.relpath(path, input_dir).replace("\\", "/"), path))
    for rel, path in sorted(paths, key=lambda p: (p[0] or "", p[1] or "")):
        recs, fnotes = extract_from_file(path, rel)
        for r in recs:
            r["file"] = rel
            records.append(r)
        notes.extend(fnotes)
        files_seen.append(rel)
        try:
            low = read_text(path).lower()
        except (OSError, UnicodeDecodeError):
            low = ""
        for tok in FIXTURE_TOKENS:
            if tok in low:
                notes.append(("fixture_label", {"file": rel, "token": tok}))
                break
    return records, notes, files_seen


def final_status(candidates, errors, any_judged):
    if not candidates and errors:
        return "input_error"
    if not candidates:
        return "insufficient_evidence"
    if any_judged and not [c for c in candidates if "lexical_fallback" in
                           (c["judgment"].get("flags") or [])]:
        return "complete"
    return "partial"


def load_judgments(work_dir):
    jp = os.path.join(work_dir, "judgments.json")
    jmap = {}
    if os.path.isfile(jp):
        try:
            for j in json.loads(read_text(jp)).get("judgments", []):
                if isinstance(j, dict) and j.get("candidate_id"):
                    jmap[j["candidate_id"]] = j
        except (OSError, json.JSONDecodeError):
            pass
    return jmap


def match_value(key, example, payload):
    k = str(key).lower()
    if k == "case_id":
        return payload.get("case_id")
    for pk, pv in payload.items():
        if str(pk).lower() == k:
            return pv
    for subs, pk, default in _MAP:
        if any(w in k for w in subs):
            return payload.get(pk, default)
    if isinstance(example, list) or k.endswith(("s", "list", "records", "items", "entries")):
        return []
    if isinstance(example, dict):
        return {}
    return False if isinstance(example, bool) else None


def fill_contract(contract, payload, case_id):
    result = {}
    if isinstance(contract, dict):
        for k in contract:
            result[k] = match_value(k, contract[k], payload)
    elif isinstance(contract, list):
        for it in contract:
            n = it if isinstance(it, str) else (
                (it.get("name") or it.get("field") or it.get("key"))
                if isinstance(it, dict) else None)
            if n:
                result[n] = match_value(n, None, payload)
    result["case_id"] = case_id
    for k, v in payload.items():
        if k not in result:
            result[k] = v
    return result


def build_payload(case, candidates, query_plan, coverage, conflicts, omissions,
                  sources, uncertainty, change_records, status):
    ranking = [{"rank": c.get("rank"), "candidate_id": c["candidate_id"],
                "title": c.get("title"), "label": c["judgment"].get("label"),
                "tier": c["judgment"].get("tier"), "score": c["judgment"].get("score"),
                "tie_group": c.get("tie_group")} for c in candidates]
    return {
        "status": status,
        "summary": "记录 %d、候选 %d；保留 %d 待定 %d 排除 %d；状态 %s" % (
            coverage.get("records_extracted", 0), coverage.get("unique_candidates", 0),
            coverage.get("keep", 0), coverage.get("pending", 0),
            coverage.get("exclude", 0), status),
        "research_question": case_field(case, "task_instruction", "question",
                                        "research_question"),
        "criteria": case_field(case, "criteria", "inclusion_criteria",
                               "exclusion_criteria") or [],
        "query_plan": query_plan, "candidates": candidates, "ranking": ranking,
        "coverage": coverage, "conflicts": conflicts, "omissions": omissions,
        "sources": sources, "uncertainty": uncertainty,
        "change_records": change_records, "errors": [], "degradations": []}


def build_coverage(records, candidates, query_plan):
    cnt = lambda lab: sum(1 for c in candidates if c["judgment"].get("label") == lab)
    return {"records_extracted": len(records), "unique_candidates": len(candidates),
            "merged_groups": sum(1 for c in candidates if c["dedup"]["variant_count"] > 1),
            "judged": sum(1 for c in candidates if "lexical_fallback" not in
                          (c["judgment"].get("flags") or [])),
            "unjudged": sum(1 for c in candidates if "lexical_fallback" in
                            (c["judgment"].get("flags") or [])),
            "keep": cnt("keep"), "pending": cnt("pending"), "exclude": cnt("exclude"),
            "missing_abstract": [c["candidate_id"] for c in candidates if not c.get("abstract")],
            "missing_year": [c["candidate_id"] for c in candidates if not c.get("year")],
            "missing_doi": [c["candidate_id"] for c in candidates if not c.get("doi")],
            "unmapped_queries": [q["query_id"] for q in query_plan if q["status"] == "planned"],
            "matched_queries": [q["query_id"] for q in query_plan if q["status"] == "matched"]}


def build_omissions(coverage, notes):
    out = []
    if coverage["missing_abstract"]:
        out.append("缺摘要：" + ", ".join(coverage["missing_abstract"]))
    if coverage["missing_year"]:
        out.append("缺年份：" + ", ".join(coverage["missing_year"]))
    if coverage["missing_doi"]:
        out.append("缺DOI：" + ", ".join(coverage["missing_doi"]))
    for n in notes:
        if n[0] == "unsupported":
            out.append("无法解析：" + str(n[1]))
        elif n[0] == "read_error":
            out.append("读失败:" + str(n[1]))
    return out or ["无遗漏"]


def build_sources(files_seen, records):
    pf = {}
    for r in records:
        pf[r.get("file")] = pf.get(r.get("file"), 0) + 1
    return [{"file": f, "records_extracted": pf.get(f, 0)} for f in sorted(files_seen)]


def build_uncertainty(candidates, any_judged, notes):
    lex = [c["candidate_id"] for c in candidates
           if "lexical_fallback" in (c["judgment"].get("flags") or [])]
    miss = [c["candidate_id"] for c in candidates if not c.get("abstract")]
    conf = [c["candidate_id"] for c in candidates if c["dedup"]["variant_count"] > 1]
    level = "high" if not any_judged else ("medium" if (lex or miss) else "low")
    return {"level": level, "reason": "候选级置信度与缺失字段",
            "lexical_fallback_candidates": lex, "missing_abstract_candidates": miss,
            "merged_conflicts": conf,
            "material_notes": [{"kind": n[0], "file": n[1].get("file"),
                                "token": n[1].get("token")}
                               for n in notes if n[0] == "fixture_label"]}


def check_quotes(candidates, input_dir):
    total, hits, cache = 0, 0, {}

    def hit(q, c, local):
        nonlocal total, hits
        total += 1
        if q in local:
            hits += 1
            return
        for s in c.get("sources", []):
            f = s.get("file")
            txt = cache.get(f)
            if txt is None:
                try:
                    txt = norm_ws(read_text(os.path.join(input_dir, f)))
                except (OSError, UnicodeDecodeError):
                    txt = ""
                cache[f] = txt
            if q in txt:
                hits += 1
                return

    for c in candidates:
        local = norm_ws((c.get("title") or "") + " " + (c.get("abstract") or ""))
        for s in c.get("sources", []):
            q = norm_ws(s.get("quote") or "")
            if q:
                hit(q, c, local)
        for r in c.get("judgment", {}).get("reasons") or []:
            q = norm_ws(r.get("evidence_quote") or "")
            if q:
                hit(q, c, local)
    return (hits / total if total else 1.0), total


def write_result(result, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    with open(os.path.join(output_dir, "result.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)


def write_report(result, output_dir):
    L = ["# 文献筛选排序", "", "## 问题", "",
         str(result.get("research_question") or "(未提供)"), "", "## 概览",
         "- 状态：%s" % result.get("status"),
         "- 提取记录：%s，唯一候选：%s" % (result.get("coverage", {}).get("records_extracted"),
                                    result.get("coverage", {}).get("unique_candidates")),
         "", "## 排序", ""]
    for c in result.get("candidates", []):
        j = c.get("judgment", {})
        L += ["### %s　%s" % (c.get("rank"), c.get("title") or "(无标题)"),
              "- 标签：%s / %s　得分：%s　置信度：%s" % (j.get("label"), j.get("tier"),
                                                       j.get("score"), j.get("confidence")),
              "- 元数据：%s（%s）%s DOI:%s" % ("; ".join(c.get("authors") or []),
                                            c.get("year"), c.get("venue") or "",
                                            c.get("doi") or "缺失"),
              "- 判定理由：%s" % (j.get("note") or "无")]
        for r in j.get("reasons") or []:
            L.append("  - %s=%s｜证据：“%s”｜置信度=%s" % (r.get("criterion"), r.get("hit"),
                                                        r.get("evidence_quote"), r.get("confidence")))
        L.append("  - 来源：%s" % "; ".join("%s %s" % (s.get("file"), s.get("locator"))
                                           for s in c.get("sources", [])))
        L.append("")
    if result.get("conflicts"):
        L.append("## 冲突")
        L += ["- %s（%s，合并 %s 条）" % (x.get("candidate_id"), x.get("resolution"),
                                        x.get("merged_from")) for x in result["conflicts"]]
        L.append("")
    if result.get("omissions"):
        L += ["## 遗漏"] + ["- %s" % g for g in result["omissions"]] + [""]
    L += ["## 不确定性", "", str(result.get("uncertainty", {})), ""]
    with open(os.path.join(output_dir, "report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L))


def run_build(input_dir, work_dir, output_dir):
    case, task_text, errors = load_input(input_dir)
    change_records = []
    records, notes, files_seen = collect_materials(input_dir, work_dir, output_dir)
    candidates, merged = dedup_records(records)
    research_q = case_field(case, "task_instruction", "question", "research_question") \
        or (task_text.strip().splitlines()[0] if task_text.strip() else None)
    query_ctx = [n[1] for n in notes if n[0] == "query_context"]
    query_plan = build_query_plan(research_q, query_ctx)
    worksheet = {"case_id": case_field(case, "case_id", "id"),
                 "research_question": research_q,
                 "criteria": case_field(case, "criteria", "inclusion_criteria",
                                        "exclusion_criteria"),
                 "query_plan": query_plan, "records": candidates,
                 "conflicts": merged, "gaps": []}
    os.makedirs(work_dir, exist_ok=True)
    with open(os.path.join(work_dir, "worksheet.json"), "w", encoding="utf-8") as f:
        json.dump(worksheet, f, ensure_ascii=False, indent=2)
    change_records.append({"step": "build", "action": "extract_candidates",
                           "detail": "read %d material files, extracted %d records, "
                                     "%d unique candidates" % (
                                         len(files_seen), len(records), len(candidates))})
    terms = fallback_terms(research_q, query_ctx)
    any_judged = apply_judgments(candidates, load_judgments(work_dir), terms)
    candidates = rank_candidates(candidates)
    status = final_status(candidates, errors, any_judged)
    coverage = build_coverage(records, candidates, query_plan)
    payload = build_payload(case, candidates, query_plan, coverage, [],
                            build_omissions(coverage, notes),
                            build_sources(files_seen, records),
                            build_uncertainty(candidates, any_judged, notes),
                            change_records, status)
    result = fill_contract(case.get("output_contract") if isinstance(case, dict) else None,
                           payload, case_field(case, "case_id", "id"))
    result["errors"] = errors
    result["degradations"] = [n for n in notes if n[0] in ("read_error", "unsupported")]
    write_result(result, output_dir)
    return {"case": case, "worksheet": worksheet, "result": result,
            "any_judged": any_judged, "candidates": candidates, "records": records,
            "notes": notes, "files_seen": files_seen, "terms": terms,
            "change_records": change_records, "query_plan": query_plan}


def run_finalize(state, work_dir, output_dir):
    case = state["case"]
    candidates = state["candidates"]
    any_judged = apply_judgments(candidates, load_judgments(work_dir), state["terms"])
    candidates = rank_candidates(candidates)
    errors = state["result"].get("errors", [])
    status = final_status(candidates, errors, any_judged)
    query_plan = state["worksheet"].get("query_plan", [])
    coverage = build_coverage(state["records"], candidates, query_plan)
    conflicts = [{"candidate_id": c["candidate_id"], "resolution": c["dedup"]["resolution"],
                  "merged_from": c["dedup"]["variant_count"], "variants": c["dedup"]["variants"]}
                 for c in candidates if c["dedup"]["variant_count"] > 1]
    change_records = list(state["change_records"]) + [{
        "step": "finalize", "action": "rank",
        "detail": "ranked %d candidates (status=%s, judged=%s)" % (
            len(candidates), status, any_judged)}]
    payload = build_payload(case, candidates, query_plan, coverage, conflicts,
                            build_omissions(coverage, state["notes"]),
                            build_sources(state["files_seen"], state["records"]),
                            build_uncertainty(candidates, any_judged, state["notes"]),
                            change_records, status)
    result = fill_contract(case.get("output_contract") if isinstance(case, dict) else None,
                           payload, case_field(case, "case_id", "id"))
    result["errors"] = errors
    result["degradations"] = [n for n in state["notes"]
                              if n[0] in ("read_error", "unsupported")]
    write_result(result, output_dir)
    write_report(result, output_dir)
    return result


def run_check(result_path, input_dir):
    ok, problems = True, []
    try:
        result = json.loads(read_text(result_path))
    except (OSError, json.JSONDecodeError) as e:
        return False, ["result.json 不可解析：%s" % e]
    for k in ("case_id", "status", "sources", "uncertainty", "change_records"):
        if k not in result:
            ok = False
            problems.append("缺 %s" % k)
    cands = result.get("candidates", [])
    ranks = [c.get("rank") for c in cands if c.get("rank") is not None]
    if ranks and sorted(ranks) != list(range(1, len(ranks) + 1)):
        ok = False
        problems.append("rank 不连续")
    rate, total = check_quotes(cands, input_dir)
    if total and rate < 0.95:
        ok = False
        problems.append("quote 命中率 %.3f < 0.95" % rate)
    print("[check] status=%s candidates=%d quote_rate=%.3f (%d sources) problems=%s"
          % (result.get("status"), len(cands), rate, total, problems or "none"))
    return ok, problems


def main(argv=None):
    p = argparse.ArgumentParser(prog="main.py")
    p.add_argument("command", nargs="?", default="run",
                   choices=["run", "build", "init", "finalize", "check"])
    p.add_argument("--input")
    p.add_argument("--work")
    p.add_argument("--output")
    args = p.parse_args(argv)
    input_dir, work_dir, output_dir = resolve_dirs(args)
    try:
        if args.command == "check":
            ok, problems = run_check(os.path.join(output_dir, "result.json"), input_dir)
            print("check %s" % ("PASS" if ok else "FAIL: " + "; ".join(problems)))
            return 0
        state = run_build(input_dir, work_dir, output_dir)
        if args.command in ("build", "init"):
            print("built worksheet: %s" % os.path.join(work_dir, "worksheet.json"))
            return 0
        result = run_finalize(state, work_dir, output_dir)
        if args.command == "finalize":
            print("finalized result.json (%s candidates, status=%s)"
                  % (len(result.get("candidates", [])), result.get("status")))
            return 0
        ok, problems = run_check(os.path.join(output_dir, "result.json"), input_dir)
        print("done: status=%s candidates=%d errors=%d check=%s"
              % (result.get("status"), len(result.get("candidates", [])),
                 len(result.get("errors", [])), "PASS" if ok else problems))
        return 0
    except Exception as e:  # noqa: BLE001
        try:
            out = {"case_id": None, "status": "input_error", "errors": [str(e)],
                   "degradations": [], "sources": [], "uncertainty": {"reason": str(e)},
                   "change_records": [{"step": "exception", "action": "fatal",
                                       "detail": str(e)}],
                   "candidates": [], "ranking": [], "coverage": {},
                   "conflicts": [], "omissions": [], "query_plan": []}
            os.makedirs(output_dir, exist_ok=True)
            with open(os.path.join(output_dir, "result.json"), "w", encoding="utf-8") as f:
                json.dump(out, f, ensure_ascii=False, indent=2)
        except OSError:
            pass
        print("fatal: %s" % e)
        return 0


if __name__ == "__main__":
    sys.exit(main())

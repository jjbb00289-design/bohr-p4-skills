"""Candidate extraction, dedup, scoring, ranking (stdlib only, offline)."""
import csv
import io
import json
import re

STOPWORDS = set(
    """a an the and or of in on for to with by at from as is are was were be been
    this that these those it its we our you your he she they their also using used
    study studies based between among effect effects 研究 以及 进行 相关 影响""".split()
)

TIER_BASE = {"core_evidence": 1.0, "method_reference": 0.75,
             "background": 0.45, "irrelevant": 0.0}
TIER_RANK = {"core_evidence": 0, "method_reference": 1, "background": 2, "irrelevant": 3}
LABEL_RANK = {"keep": 0, "pending": 1, "exclude": 2}
SYNONYMS = {"rct": ["randomized controlled trial", "randomised controlled trial"],
            "mri": ["magnetic resonance imaging"], "ct": ["computed tomography"],
            "dm": ["diabetes mellitus"], "t2d": ["type 2 diabetes"],
            "cvd": ["cardiovascular disease"],
            "copd": ["chronic obstructive pulmonary disease"],
            "ai": ["artificial intelligence"]}


def norm_ws(s):
    return re.sub(r"\s+", " ", str(s)).strip() if s else ""


def norm_title(s):
    return re.sub(r"[^0-9a-z\u4e00-\u9fff]+", "", norm_ws(s).lower())


def norm_doi(s):
    if not s:
        return None
    t = str(s).strip().lower()
    t = re.sub(r"^https?://(dx\.)?doi\.org/", "", t)
    t = re.sub(r"^doi:\s*", "", t).rstrip(".,;")
    return t or None


def read_text(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def _str(v):
    if isinstance(v, list):
        return next((x for x in v if isinstance(x, str) and norm_ws(x)), None)
    return v if isinstance(v, str) else None


def _pick(d, *keys):
    for k in keys:
        v = d.get(k)
        if v:
            return v
    return None


def title_of(d):
    return norm_ws(_str(_pick(d, "title", "Title", "name", "Name")))


def authors_of(d):
    a = _pick(d, "author", "authorString", "authors", "Authors")
    items = a if isinstance(a, list) else ([a] if isinstance(a, str) else [])
    out, seen = [], set()
    for x in items:
        if isinstance(x, dict):
            x = x.get("name") or norm_ws(str(x.get("given") or "") + " " +
                                         str(x.get("family") or "")).strip()
        for p in str(x or "").replace(";", ",").split(","):
            p = norm_ws(p)
            if p and p.lower() not in seen:
                seen.add(p.lower())
                out.append(p)
    return out


def venue_of(d):
    return norm_ws(_str(_pick(d, "container-title", "containerTitle", "journalTitle",
                              "journal", "Journal", "venue", "publicationTitle",
                              "journalName", "source")))


def abstract_of(d):
    v = _pick(d, "abstract", "abstractText", "Abstract", "description", "summary")
    return v if isinstance(v, str) and norm_ws(v) else None


def doi_of(d):
    return norm_doi(_pick(d, "DOI", "doi", "Doi"))


def pmid_of(d):
    v = _pick(d, "pmid", "PMID", "pubmedId", "pubmed_id")
    return str(v) if v else None


def year_of(d):
    for k in ("pubYear", "year", "Year", "publicationYear", "publication_year",
              "publicationDate", "date", "publishedYear", "PY"):
        v = d.get(k)
        if isinstance(v, str):
            m = re.search(r"(1[6-9]\d{2}|20\d{2})", v)
            if m:
                return int(m.group(0))
        if isinstance(v, (int, float)) and 1000 <= int(v) <= 2100:
            return int(v)
    for k in ("published", "published-print", "published-online", "publication"):
        v = d.get(k)
        if isinstance(v, dict):
            dp = v.get("date-parts") or v.get("dateParts") or v.get("date_parts")
            if isinstance(dp, list):
                for part in dp:
                    if isinstance(part, list) and part and isinstance(part[0], (int, float)):
                        return int(part[0])
    return None


def is_record(d):
    return isinstance(d, dict) and title_of(d) and (
        doi_of(d) or authors_of(d) or year_of(d) or venue_of(d)
        or abstract_of(d) or pmid_of(d))


def normalize_record(d, locator):
    return {"title": title_of(d), "authors": authors_of(d), "year": year_of(d),
            "venue": venue_of(d), "doi": doi_of(d), "pmid": pmid_of(d),
            "abstract": abstract_of(d),
            "type": norm_ws(_str(_pick(d, "type", "pubType", "publicationType"))),
            "locator": locator}


def walk_json(obj, locator, out, query_ctx):
    if isinstance(obj, dict):
        for k in ("query", "queryString", "q", "searchTerm", "query_term"):
            v = obj.get(k)
            if isinstance(v, str) and norm_ws(v):
                query_ctx.append({"query": norm_ws(v), "file": locator.split(" / ")[0]})
        if is_record(obj):
            out.append(normalize_record(obj, locator))
        for k, v in obj.items():
            walk_json(v, locator + "." + k, out, query_ctx)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            walk_json(v, locator + "[" + str(i) + "]", out, query_ctx)


_CSV = {"title": ("title", "article title", "name", "paper", "publication"),
        "doi": ("doi", "digital object identifier"),
        "authors": ("author", "authors", "authorstring", "creators"),
        "year": ("year", "pubyear", "publication year", "date", "published"),
        "venue": ("journal", "journaltitle", "venue", "source"),
        "abstract": ("abstract", "abstracttext", "description", "summary"),
        "pmid": ("pmid", "pubmed id", "pubmedid")}


def extract_csv(path, rel, out):
    text = read_text(path)
    try:
        dialect = csv.Sniffer().sniff(text[:4000], delimiters=",\t;|")
    except csv.Error:
        dialect = csv.excel
    for i, row in enumerate(csv.DictReader(io.StringIO(text), dialect=dialect)):
        if not row or not any(v for v in row.values()):
            continue
        d = {}
        for canon, keys in _CSV.items():
            for h, v in row.items():
                if h and (h.strip().lower() in keys or any(k in h.strip().lower() for k in keys)):
                    d.setdefault(canon, v)
        if is_record(d):
            out.append(normalize_record(d, rel + " row " + str(i + 2)))


def extract_xml(path, rel, out):
    text = read_text(path)
    blocks = re.findall(r"<(?:result|record|article|paper)\b[^>]*>.*?</(?:result|record|article|paper)>",
                        text, re.S | re.I) or [text]
    for bi, b in enumerate(blocks):
        def g(tag):
            m = re.search(r"<%s\b[^>]*>(.*?)</%s>" % (tag, tag), b, re.S | re.I)
            return re.sub(r"<[^>]+>", "", m.group(1)) if m else None
        d = {"title": g("title"), "doi": g("doi"),
             "abstract": g("abstractText") or g("abstract"),
             "authorString": g("authorString") or g("authors"),
             "pubYear": g("pubYear") or g("year"),
             "journalTitle": g("journalTitle") or g("journal"), "pubType": g("pubType")}
        if is_record(d):
            out.append(normalize_record(d, rel + " xml-block " + str(bi + 1)))


def extract_from_file(path, rel):
    out, notes = [], []
    low = path.lower()
    try:
        if low.endswith(".json"):
            obj = json.loads(read_text(path))
            ctx = []
            walk_json(obj, rel, out, ctx)
            for q in ctx:
                notes.append(("query_context", q))
        elif low.endswith((".csv", ".tsv", ".tab")):
            extract_csv(path, rel, out)
        elif low.endswith(".xml"):
            extract_xml(path, rel, out)
        else:
            notes.append(("unsupported", rel))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, csv.Error) as e:
        notes.append(("read_error", {"file": rel, "error": str(e)}))
    return out, notes


def extract_terms(text):
    if not text:
        return []
    toks = re.findall(r"[0-9a-zA-Z][0-9a-zA-Z\-\.]{2,}|[\u4e00-\u9fff]{2,}", text.lower())
    seen, res = set(), []
    for t in toks:
        if t in STOPWORDS or len(t) < 3:
            continue
        if len(t) > 8 and not re.match(r"[0-9a-zA-Z]", t):
            continue
        if t not in seen:
            seen.add(t)
            res.append(t)
    return res


def dedup_records(records):
    groups, cid = {}, 0
    for idx, r in enumerate(records):
        dk = norm_doi(r.get("doi"))
        tk = norm_title(r.get("title")) if r.get("title") else None
        key = ("doi", dk) if dk else (("title", tk) if tk else ("rid", idx))
        groups.setdefault(key, []).append(r)
    candidates, merged = [], []
    for key in sorted(groups, key=lambda k: (k[0] or "", str(k[1] or ""))):
        cid += 1
        c = "c%02d" % cid
        recs = groups[key]
        recs.sort(key=lambda r: (1 if r.get("doi") else 0, 1 if r.get("abstract") else 0,
                                 -len(r.get("authors") or []), 1 if r.get("venue") else 0,
                                 1 if r.get("year") else 0), reverse=True)
        canon = recs[0]
        venues = {r.get("venue") for r in recs if r.get("venue")}
        if len(recs) > 1 and key[0] == "doi" and len(venues) > 1:
            resolution = "merged_versions"
        elif len(recs) > 1:
            resolution = "merged_exports"
        else:
            resolution = "unique"
        candidates.append({
            "candidate_id": c, "title": canon.get("title"), "authors": canon.get("authors"),
            "year": canon.get("year"), "venue": canon.get("venue"), "doi": canon.get("doi"),
            "pmid": canon.get("pmid"), "abstract": canon.get("abstract"),
            "type": canon.get("type"),
            "sources": [{"file": r.get("file"), "locator": r.get("locator"),
                         "quote": r.get("title")} for r in recs],
            "dedup": {"group": key[0] + ":" + str(key[1]), "resolution": resolution,
                      "variant_count": len(recs),
                      "variants": [{"file": r.get("file"), "locator": r.get("locator"),
                                    "title": r.get("title"), "doi": r.get("doi")}
                                   for r in recs]},
            "judgment": {"label": None, "tier": None, "relevance": None,
                         "reasons": [], "confidence": None, "note": None, "flags": []}})
        if len(recs) > 1:
            merged.append({"candidate_id": c, "merged_from": len(recs),
                           "resolution": resolution})
    return candidates, merged


def lexical_ratio(record, terms):
    text = norm_ws((record.get("title") or "") + " " + (record.get("abstract") or "")).lower()
    if not terms:
        return 0.0
    return sum(1 for t in terms if t.lower() in text) / len(terms)


def evidence_support(reasons):
    if not reasons:
        return None
    w = {"match": 1.0, "partial": 0.5, "miss": 0.0}
    vals = [w.get(r.get("hit"), 0.0) * float(r.get("confidence") or 0.5) for r in reasons]
    return sum(vals) / len(vals) if vals else 0.0


def compute_score(j):
    rel = j.get("relevance")
    if rel is None:
        rel = TIER_BASE.get(j.get("tier"), 0.45)
        if j.get("label") == "exclude":
            rel = 0.0
    try:
        rel = min(1.0, max(0.0, float(rel)))
    except (TypeError, ValueError):
        rel = 0.0
    es = evidence_support(j.get("reasons"))
    return round(min(1.0, max(0.0, rel if es is None else 0.7 * rel + 0.3 * es)), 4)


def rank_candidates(candidates):
    for c in candidates:
        j = c["judgment"]
        j["score"] = compute_score(j)
        c["_sort"] = (LABEL_RANK.get(j.get("label"), 1), -j["score"],
                      TIER_RANK.get(j.get("tier"), 3), -(c.get("year") or 0),
                      norm_title(c.get("title") or ""), c["candidate_id"])
    order = sorted(candidates, key=lambda c: c["_sort"])
    prev, tie = None, []
    for i, c in enumerate(order):
        c["rank"] = i + 1
        key3 = (LABEL_RANK.get(c["judgment"].get("label"), 1), c["judgment"]["score"],
                TIER_RANK.get(c["judgment"].get("tier"), 3))
        if prev is None or key3 != prev:
            tie, prev = [c["candidate_id"]], key3
        else:
            tie.append(c["candidate_id"])
        c["tie_group"] = list(tie)
    for c in candidates:
        del c["_sort"]
    return order


def apply_judgments(candidates, jmap, terms):
    any_judged = False
    for c in candidates:
        j = jmap.get(c["candidate_id"])
        if j:
            any_judged = True
            c["judgment"] = {"label": j.get("label"), "tier": j.get("tier"),
                             "relevance": j.get("relevance"), "reasons": j.get("reasons") or [],
                             "confidence": j.get("confidence"), "note": j.get("note"),
                             "flags": list(j.get("flags") or [])}
            local = norm_ws((c.get("title") or "") + " " + (c.get("abstract") or ""))
            for r in c["judgment"]["reasons"]:
                q = norm_ws(r.get("evidence_quote") or "")
                if q and q not in local:
                    r["_quote_unverified"] = True
        else:
            rel = lexical_ratio(c, terms)
            c["judgment"] = {"label": "pending", "tier": "background",
                             "relevance": round(rel, 4), "reasons": [], "confidence": 0.3,
                             "note": "词面基线待复核",
                             "flags": ["lexical_fallback"]}
    return any_judged


def build_query_plan(research_q, query_ctx):
    plan = [{"query_id": "q01", "query": research_q or "(无问题)",
             "source": "case", "synonyms": [], "status": "planned", "note": "主查询"}]
    for i, t in enumerate(extract_terms(research_q or "")):
        plan.append({"query_id": "q%02d" % (i + 2), "query": t, "source": "case",
                     "synonyms": SYNONYMS.get(t, []), "status": "planned",
                     "note": "同义词" if SYNONYMS.get(t) else "词项"})
    for ctx in query_ctx:
        plan.append({"query_id": "q%02d" % (len(plan) + 1), "query": ctx["query"],
                     "source": ctx["file"], "synonyms": [], "status": "matched",
                     "note": "材料查询"})
    return plan


def fallback_terms(research_q, query_ctx):
    terms = extract_terms(research_q or "")
    for ctx in query_ctx:
        for t in extract_terms(ctx.get("query") or ""):
            if t not in terms:
                terms.append(t)
    return terms

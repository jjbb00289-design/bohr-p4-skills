---
name: literature-screening-ranking
description: 科研文献筛选与智能排序。从本地检索响应（Crossref/EuropePMC/出版社响应、引用图、导入状态）提取候选文献，去重与版本合并，按研究问题/对象/方法/人群/时间窗逐条做相关性判定与分层（保留/待定/排除），给出可解释、稳定、可复核的排序，并输出回填 output_contract 的 result.json。当任务要求对文献候选集筛选、相关性排序、去重或检索复核时使用。
version: "1.0.0"
---

# 文献筛选与智能排序

## 1. 用途与触发条件

本 Skill 对一批候选文献完成「提取 → 去重 → 相关性判定 → 分层 → 排序 → 复核记录」的完整流程。触发条件（满足其一）：

- 输入含候选文献材料（Crossref/EuropePMC/出版社响应、引用图、导入状态等）且任务要求筛选或排序；
- 任务要求逐条判断相关性、去重、版本合并、冲突处理或生成可追溯的文献排序；
- case.json 的 `output_contract` 含文献/候选/排序相关字段。

不适用：底层数据库接入、全文精读、论文写作、系统综述纳排全流程。

## 2. 输入

运行时目录：`/input/`，含 `case.json`（case_id、task_instruction、output_contract，可选 criteria/queries）、`task.md`（研究问题与约束）、材料文件（JSON/CSV/TSV/XML）。PDF 无预抽文本层时用平台 `pdf-text-tool` 抽出文本后再当材料读取；纯文本引用列表需先结构化（如转成 JSON）；不得按文件名假设内容。

## 3. 调用方式

```
python scripts/main.py            # 默认完整流程：build → finalize → check
python scripts/main.py build      # 提取候选 + 写 worksheet.json + partial result.json
python scripts/main.py finalize   # 合并判定 + 生成完整 result.json / report.md
python scripts/main.py check      # 校验契约键与 quote 命中率
python scripts/main.py init       # 同 build
```

路径用环境变量 `INPUT_DIR`/`WORK_DIR`/`OUTPUT_DIR` 覆盖，或 `--input/--work/--output`；默认 `/input`、`/app/work`、`/app/output`。纯标准库、不联网、不依赖 CWD。退出码恒为 0，错误写进 result.json 的 `errors`/`degradations`。

## 4. 完整流程（Agent 执行顺序）

1. 读 `/input/case.json` 与 `/input/task.md`，确认研究问题与 output_contract。
2. `python scripts/main.py build`：真实读取材料，提取候选记录、去重、生成 worksheet.json（含空判定）与 partial result.json。
3. 读 `WORK_DIR/worksheet.json`，逐条按第 5、6 节判定。
4. 写 `WORK_DIR/judgments.json`（见第 7 节 schema）。
5. `python scripts/main.py finalize`：合并判定、排序、回填契约、写 result.json 与 report.md。
6. `python scripts/main.py check`：确认契约键齐全、每条候选有 source+locator+quote、quote 命中率 ≥ 0.95。

## 5. 相关性判定标准

逐条依据研究问题，核对五类条件，每条结论都要给出命中的判定依据：

| 条件 | 判定要点 |
|-|-|
| question_match | 研究对象、暴露/干预、结局是否与研究问题一致 |
| population | 人群/物种/样本是否匹配（不匹配即降级） |
| method | 研究设计/方法是否匹配，综述 vs 原始研究分开 |
| exposure | 关键变量/指标是否一致 |
| time_window | 发表时间是否在时间窗内（未给则不限） |

分层标签（label → tier 需一致）：

- `keep` / `core_evidence`：直接回答研究问题的原始研究或关键证据；
- `keep` / `method_reference`：不直接回答但提供必需方法/工具/数据源；
- `pending` / `background`：摘要信息不足或仅背景相关，转人工复核；
- `exclude` / `irrelevant`：对象、人群或方法明确不匹配。

边界案例：同分并列保留并列并注明；摘要缺失转 `pending` 并记 gap；元数据冲突不臆断，升级人工。

## 6. 冲突处理

- 预印本 vs 正式版（同 DOI 或同题）：合并为一个候选，`resolution=merged_versions`，正式版优先（有 DOI/期刊/更全元数据），variants 保留全部。
- 同一研究多篇报道（无 DOI、标题近似、作者/年份一致）：标记 `possible_duplicate` 转人工，不自动合并。
- 冲突结论（如 search09 中同一主题相反结论的标注）：`conflict → human_review`，保留双方与出处，不裁定对错。
- 标注分歧、缺摘要、缺年份：分别记 gap，不补造。
- 材料中显式标注 `synthetic`/`fixture`/重复导出：保留为 `labeled_fixture` 标志，用于去重验证，不作为独立真实论文新增。

## 7. 工作稿 schema

`WORK_DIR/worksheet.json`：`{case_id, research_question, criteria, query_plan, records[], conflicts[], gaps[]}`。每条 record：`{candidate_id, title, authors[], year, venue, doi, pmid, abstract, type, sources[{file, locator, quote}], dedup{group, resolution, variant_count, variants[]}, judgment{label,tier,relevance,reasons[],confidence,note,flags[]}}`。

`WORK_DIR/judgments.json`（Agent 写入）：
```json
{
  "case_id": "…",
  "judgments": [
    {
      "candidate_id": "c01",
      "label": "keep|pending|exclude",
      "tier": "core_evidence|method_reference|background|irrelevant",
      "relevance": 0.9,
      "reasons": [
        {"criterion": "population", "hit": "match|partial|miss",
         "evidence_quote": "逐字摘自材料原文", "confidence": 0.9}
      ],
      "confidence": 0.9,
      "note": "一句话说明"
    }
  ]
}
```
`candidate_id` 必须与 worksheet 一致。`evidence_quote` 只能逐字复制 worksheet 中该候选的 title/abstract 或材料原文，禁止改写、禁止编造。

## 8. 证据规范

每条候选、每个元素、每个结论都能指回 `source + locator + 逐字 quote`；quote 必须在材料原文命中。`sources` 给出读取的文件与 JSON 路径（如 `search01.json / message.items[0]`）。无结果的 query 也保留并说明。最终 `result.json` 的 `sources`/`uncertainty`/`change_records` 必须真实。

## 9. 排序与打分口径

`score = 0.7 × relevance + 0.3 × evidence_support`（relevance 为整体相关性 0–1；evidence_support = reasons 中 hit 加权命中率的均值，match=1、partial=0.5、miss=0）。Agent 可显式给 relevance；未给时由 tier 推导（core_evidence=1.0、method_reference=0.75、background=0.45、irrelevant=0）。无判定时使用词面基线并把 status 置 partial，明确“词面命中 ≠ 语义相关”。

排序键（稳定、确定）：`(-score, tier 优先级, -year, 规范化 title, candidate_id)`。同分并列给相同 rank 并记录 `tie_group`。k 值（如 Precision@k、nDCG@k）仅在输入含标注/白板时计算，否则记 null 并说明“快照内无标注，未计算”。

## 10. 输出

`/app/output/result.json`：回填 case.json 的 `output_contract` 每个字段（缺失填 null/[]，不改名、不漏键）+ `case_id` + `status` + `sources` + `uncertainty` + `change_records` + `errors` + `degradations`。附带 `report.md`（逐条理由，可编辑源）。

## 11. 降级表

| 情形 | status | 处置 |
|-|-|-|
| 正常完成 | complete | 全量判定 + 排序 |
| 缺判定（默认跑） | partial | 词面基线 + 全部待定，gap 说明 |
| 空输入/坏 JSON | input_error | 合法 partial，errors 说明，退出 0 |
| 缺材料 | insufficient_evidence | candidates=[]，gaps 说明 |
| 权限不足/文件不可读 | partial | degradations 记录，继续其余文件 |
| 缺摘要/年份/DOI | partial | 逐条记 gap，转 pending |

## 12. 自检

`main.py check` 校验：契约键齐全、case_id 存在、status 合法、每条候选有 source+locator+quote、quote 命中率 ≥ 0.95、rank 无重复、JSON 可解析。两项全新输出目录各跑一次，产物结构一致（不含时间戳/随机值）。

## 13. 限制

离线有限快照：只处理输入材料中的候选，不联网、不声称实时/最新/全库召回。固定研究问题、九篇真实署名论文、实际查询输入、全记录筛选。不编造 DOI/作者/年份/期刊/全文/软件状态/检索结果；材料缺失即如实说明。

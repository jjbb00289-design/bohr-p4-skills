# 最小调用示例（示例，非正式案例结果）

以下全部为示意输入与示意输出，只用于说明接口与流程，不代表任何正式案例。

## 输入

`/input/case.json`：
```json
{
  "case_id": "demo-001",
  "task_instruction": "检索并筛选关于 2 型糖尿病中二甲双胍对心血管结局影响的随机对照试验。",
  "output_contract": {"candidates": "array", "ranking": "array", "summary": "string"}
}
```

`/input/task.md`：研究问题与约束说明（同上）。

`/input/search01.json`（Crossref 风格示意）：
```json
{"message": {"items": [
  {"DOI": "10.1000/demo1", "title": ["Metformin and cardiovascular outcomes in type 2 diabetes"],
   "author": [{"given": "A", "family": "Lee"}], "abstract": "In this randomized controlled trial ...",
   "container-title": ["J Demo"]}
]}}
```

## 调用

```
INPUT_DIR=/input WORK_DIR=/app/work OUTPUT_DIR=/app/output python scripts/main.py
```

## 示意输出（节选）

`/app/output/result.json`：
```json
{
  "case_id": "demo-001",
  "status": "partial",
  "summary": "提取 1 条记录、1 个唯一候选；保留 0、待定 1、排除 0；状态 partial",
  "candidates": [{"candidate_id": "c01", "title": "Metformin and cardiovascular outcomes ..."}],
  "ranking": [{"rank": 1, "candidate_id": "c01"}],
  "coverage": {"records_extracted": 1, "unique_candidates": 1}
}
```

说明：示例运行未写入 `judgments.json`，因此 relevance 由词面基线推导、全部置 pending（这是诚实降级，不是最终判定）。正式使用时应先 `build`，逐条判定后写 `judgments.json`，再 `finalize`。

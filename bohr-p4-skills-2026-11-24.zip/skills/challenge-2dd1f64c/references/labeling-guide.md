# 标注与排序指南（供 Agent 逐条判定时使用）

## 判定顺序

对每个候选，依次核对五类条件，每条结论写进 `reasons`（criterion + hit + evidence_quote + confidence）：

1. question_match —— 研究对象、暴露/干预、结局是否对应研究问题。
2. population —— 人群/物种/样本，不匹配即降级或排除。
3. method —— 研究设计；综述（review/meta-analysis/systematic review）与原始研究分开标记。
4. exposure —— 关键变量/指标。
5. time_window —— 发表年份，仅当输入给定了时间窗时使用。

## 标签规则

| label | tier | 判定条件 |
|-|-|-|
| keep | core_evidence | 直接回答研究问题的原始研究/关键证据，人口与方法匹配 |
| keep | method_reference | 不直接回答但提供必需方法、工具、数据源或测量技术 |
| pending | background | 摘要不足、仅背景相关、或存在冲突需人工复核 |
| exclude | irrelevant | 对象、人群、方法或结局明确不匹配 |

label 与 tier 必须一致：`keep↔core_evidence/method_reference`，`pending↔background`，`exclude↔irrelevant`。

## 证据引用

- `evidence_quote` 必须逐字复制 worksheet 中该候选的 title/abstract，或材料原文；禁止改写、翻译、编造。
- 一个 reason 只引用一处证据；hit 取 match/partial/miss。
- confidence 0–1，按证据明确程度给出；摘要缺失时 confidence 取低值并 hit=partial。

## 冲突与边界

- 预印本与正式版（同 DOI）：合并为一个候选，resolution=merged_versions，正式版优先。
- 同一研究多篇报道（无 DOI、标题近似）：标记 possible_duplicate，转人工，不自动合并。
- 相反结论（如 search09 标注的冲突意见）：conflict → human_review，保留双方，不裁定。
- 缺摘要/年份/DOI：逐条记 gap，转 pending；不补造。

## 打分

score = 0.7 × relevance + 0.3 × evidence_support。evidence_support 是 reasons 加权命中率均值（match=1、partial=0.5、miss=0，权重=confidence）。relevance 未给时由 tier 推导（core=1.0、method=0.75、background=0.45、irrelevant=0）。

## 排序键（稳定）

(-score, label 优先级 keep<pending<exclude, tier 优先级, -year, 规范化标题, candidate_id)。同分并列记录 tie_group。k 值仅在输入有标注时计算，否则 null 并说明。

## 宁少而准

不确定即 pending 或 exclude，并给出理由；不塞无关结果凑数。

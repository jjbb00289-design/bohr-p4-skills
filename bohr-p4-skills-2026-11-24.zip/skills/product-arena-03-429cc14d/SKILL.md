---
name: reference-citation-manager
description: 学术写作中的参考文献与引用管理。读取真实稿件与文献库，完成引用插入定位、顺序编码编号重排与交叉引用同步、文献去重归并、GB/T 7714-2015/APA/BibTeX/RIS 格式转换与字段补齐、来源核验与正文-文献一致性检查，交付可继续编辑的稿件、同步文献表与逐句可回溯的 result.json。触发于引用插入、编号更新、文献去重、格式转换、来源核验等任务。
version: 1.0.0
---

# 参考文献与引用管理

## 用途

从一份真实稿件和一份真实文献库出发，完成引用管理的完整动作并保留来源。围绕四个质量轴工作：

- **挂得对**：引用插到真正需要来源支撑的论断句处，而不是整段末尾或图表注附近；处理一句多引、多句一引。
- **编得顺**：插入、删除、调序、合并章节后重排编号，同步正文标记、文末列表、图表注与交叉引用，编号连续、上标样式统一。
- **收得净**：把同一文献的中英文题名、预印本与正式版、期刊与会议版、不同数据库导出条目合并成一条，并给出可解释的合并依据。
- **对得上**：每条引用落到真实、可定位的文献记录上，元数据准确，正文论断与所引文献的主题和结论匹配，逐句说清；不足处明确标注。

可选突破方向（至少覆盖案例要求的方向）：引用插入与定位、编号更新与交叉引用、文献去重与条目归并、格式转换与字段补齐、来源核验与一致性检查。

## 触发条件

当 `/input/case.json` 的 `task_instruction` 或 `/input/task.md` 中出现下列任一动作时启用：引用插入、引用定位、编号更新、交叉引用、文献去重、条目归并、格式转换（GB/T 7714、APA、BibTeX、RIS、EndNote、CNKI 导出）、来源核验、正文—参考文献一致性检查。

## 调用方式

1. 读 `/input/case.json`（`case_id`、`task_instruction`、`output_contract`）与 `/input/task.md`。
2. 清点 `/input/` 下全部材料，**按真实文件读取，不按标签假设内容**：
   - PDF（无预抽文本层时）：用平台 `pdf-text-tool`/`ocr-tool` 抽取；纯文本 PDF 直接读。
   - DOCX/XLSX/PPTX：用 `scientific-python` 的对应库或解包 `word/document.xml` 等读取。
   - 图片/扫描件：用 `ocr-tool`。
   - SQLite：用 `sqlite3` 读表。
   - BibTeX/RIS/EndNote/CNKI 导出、CSV/TSV、Markdown/TeX/纯文本：直接按文本读。
3. 从材料中区分**稿件正文**与**文献库**，建立 `sources` 清单（每条含相对路径、类型、可定位信息）。
4. 按任务动作逐句/逐条处理，写工作稿 `work.json`（schema 见下），可编辑产物写 `/app/output/`。
5. 运行 `python scripts/main.py`（默认完整流程：init → 清点 → check → build），生成/校验 `/app/output/result.json`。
6. 逐项核对 `main.py check` 的引用命中率、编号连续性、契约字段覆盖，未达标的条目修 work.json 后重跑。

脚本 `main.py` 是确定性的簿记与校验工具；引用定位、去重判据、论断—文献匹配的**推理由本 Skill 的 Agent 完成**，脚本负责把推理结果落成可复核的 result.json 并做机器可验的一致性检查。

## 输入输出

### 输入（平台固定）
- `/input/case.json`：`case_id`、`task_instruction`、`output_contract`（契约字段）。
- `/input/task.md`：题面与体裁/受众/格式约束。
- `/input/` 下的材料文件（稿件、文献库、图表等）。

### 输出（写 `/app/output/`）
- `result.json`：回填 `output_contract` 全部字段 + `case_id`；必含 `status`、`sources`、`uncertainty`、`change_records`、`errors`、`degradations`、`artifacts`、`self_check`。缺值用 `null`/`[]`，不改名、不漏键。
- 可编辑产物：修改后的稿件（Markdown/LaTeX/DOCX，非截图）、同步文献表、来源映射、改动记录。
- 预览：产出 Office/幻灯片/图形类可编辑产物时，同时给出真实渲染的 PDF/PNG 预览；LaTeX 用 `latex-compiler` 真编译，编译器不可用时只交付 `.tex` 并写 `degradations`，不伪造 PDF。

## 工作稿 schema（`/app/work/work.json`）

Agent 先写工作稿，再由 `main.py build` 合并为 result.json。字段与示例：

```json
{
  "case_id": "case-xxx",
  "status": "complete | partial | insufficient_evidence | input_error",
  "output_fields": {
    "<contract_key>": "output/manuscript.md 或 内联字符串 或 结构化对象"
  },
  "artifacts": [
    {"path": "output/manuscript.md", "role": "editable_manuscript", "media_type": "text/markdown"}
  ],
  "sources": [
    {"id": "src1", "path": "input/manuscript.docx", "media_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "note": "原稿件"}
  ],
  "evidence": [
    {"claim": "正文论断句", "source": "src1", "locator": "第2段", "quote": "材料中逐字引文", "ref_id": "R1"}
  ],
  "citation_actions": [
    {"type": "insert|delete|renumber|merge|convert|verify", "target": "定位", "from": "改前", "to": "改后", "source": "src1", "quote": "逐字引文", "reason": "依据", "change": "改动说明"}
  ],
  "dedup": [
    {"merged_key": "R1", "members": ["R1", "R3"], "criterion": "same_doi|same_doi_title_year|same_title_year_first_author", "evidence": "DOI 10.xxxx 相同"}
  ],
  "renumber_map": [
    {"old_ref": "R2", "new_ref": "R1", "reason": "按首次出现顺序重排"}
  ],
  "uncertainty": [
    {"item": "待确认项", "reason": "原因", "needs_human": true}
  ],
  "gaps": ["材料缺口说明"],
  "change_records": [
    {"what": "改动内容", "why": "理由", "evidence": "source+locator+quote"}
  ],
  "degradations": ["降级说明"],
  "errors": ["异常说明"]
}
```

`output_fields` 值约定：字符串以 `output/` 开头或匹配某个 artifact 文件名时为产物路径；其余字符串为内联内容；对象/数组为内联结构化内容。

## 证据规范（逐句可回溯）

- 每个结论、条目、数字、术语、引用、图表指向都必须能回到 `source`（sources 中的 id）+ `locator`（段落/页/条目/行列）+ `quote`（材料原文的**逐字**引文）。
- `quote` 必须能在对应材料原文中命中（`main.py check` 会做逐字命中校验，目标命中率 ≥ 0.95）。
- 不得新增材料外事实；数字、单位、限定词强度与原文一致，不得顺手改动。
- 术语表、缩写首次出现、引用编号、图表指向与原文保持一致。

## 降级表

| 情形 | 处置 | status |
|-|-|-|
| 无 `case.json` / JSON 损坏 | 写 `input_error` 的 partial result.json，`errors` 记录 | input_error |
| 材料缺失 | 写 `gaps` 逐项说明，仍回填契约（缺值 null/[]） | insufficient_evidence |
| PDF 无文本层且 OCR 不可用 | `degradations` 说明，交付已可得部分 | partial |
| 二进制材料脚本无法逐字校验 | `check` 标 `unverifiable_binary`，由 Agent 用平台工具核验后写入 evidence | 依核验结果 |
| LaTeX 编译器不可用 | 交付 `.tex`，`degradations` 说明不伪造 PDF | partial |
| 去重判据不足 / 条目歧义 | 不强行合并，写入 `uncertainty` 与 `needs_human` | partial |
| 权限不足 / 无法写输出 | `errors` 记录，仍尝试写合法 result.json，恒退出码 0 | input_error |

## 自检

1. `main.py` 默认流程必须产出合法 `result.json`，契约键齐全、恒退出码 0。
2. `check` 的引用逐字命中率 ≥ 0.95；编号连续无缺号；正文与列表编号一致。
3. 每个 `output_fields` 契约键非 null/[]，或已在 `gaps` 说明。
4. 产物可编辑：正文为 Markdown/TeX/DOCX 文本，非截图；有预览要求的含真实 PDF/PNG。

## 限制

- 不联网；DOI 核验依赖材料内已有元数据或平台 `browser-automation`，无法联网时如实标注 `uncertainty`。
- 只处理输入材料中真实存在的内容，不编造数据、软件状态或检索结果。
- 脚本做确定性校验，不做语义判断；语义判断（引文匹配、去重判据）由 Agent 依据上述规则完成并落证据。
- 单次运行预算：64 次模型请求 / 900 秒；接近 780 秒须立即 `main.py build` 落盘已完成交付。

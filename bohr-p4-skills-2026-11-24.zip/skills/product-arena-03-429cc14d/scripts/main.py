#!/usr/bin/env python3
"""Reference & citation management Skill support tool.

Single-command default = full flow: init -> inventory -> check -> build.
Pure stdlib; no network; CWD-independent. Env INPUT_DIR/WORK_DIR/OUTPUT_DIR
or --input/--work/--output override the platform defaults /input /app/work /app/output.
Always exits 0; failures are recorded in result.json errors/degradations.
"""
import argparse
import json
import os
import re
import sys
import zipfile
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent
DEFAULT_INPUT = Path("/input")
DEFAULT_WORK = Path("/app/work")
DEFAULT_OUTPUT = Path("/app/output")
VERSION = "1.0.0"

TEXT_EXTS = {".md", ".txt", ".tex", ".bib", ".ris", ".enw", ".csv", ".tsv",
             ".json", ".yaml", ".yml", ".xml", ".htm", ".html", ".nfo"}
ZIP_ENTRY = {".docx": "word/document.xml", ".pptx": "ppt/presentation.xml",
             ".xlsx": "xl/workbook.xml", ".odt": "content.xml"}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".tif", ".tiff", ".bmp"}
PDF_EXT = {".pdf"}
CITE_RE = re.compile(r"\[([0-9]+(?:[,\-\u2013\u2014][0-9]+)*)\]")
REF_LINE_RE = re.compile(r"^\s*[\[（(]?(\d+)[\]）).、:\s]")
ARTIFACT_MARKERS = ("output/", "output\\", "app/output/", "app\\output\\")


def strip_output_prefix(rel):
    r = str(rel).replace("\\", "/")
    for prefix in ("app/output/", "output/"):
        if r.startswith(prefix):
            return r[len(prefix):]
    return r


def looks_like_path(v):
    return isinstance(v, str) and v.startswith(ARTIFACT_MARKERS)


def norm(s):
    return re.sub(r"\s+", "", s or "")


def read_text(p):
    raw = p.read_bytes()
    for enc in ("utf-8", "utf-8-sig", "gb18030", "latin-1"):
        try:
            return raw.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("latin-1", errors="replace")


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def load_json(path):
    try:
        if not path.exists():
            return None, {"code": "missing_file", "message": str(path) + " not found"}
        data = json.loads(path.read_text(encoding="utf-8"))
        return data, None
    except json.JSONDecodeError as e:
        return None, {"code": "bad_json", "message": "%s: %s" % (path.name, e)}
    except Exception as e:
        return None, {"code": "read_error", "message": "%s: %s" % (path.name, e)}


def resolve_dirs(args):
    def pick(flag, env, default):
        return Path(flag) if flag else (Path(env) if env else default)
    return {
        "input": pick(args.input, os.environ.get("INPUT_DIR"), DEFAULT_INPUT),
        "work": pick(args.work, os.environ.get("WORK_DIR"), DEFAULT_WORK),
        "output": pick(args.output, os.environ.get("OUTPUT_DIR"), DEFAULT_OUTPUT),
    }


def load_case(input_dir):
    case, err = load_json(input_dir / "case.json")
    if err:
        return None, err
    if not isinstance(case, dict):
        return None, {"code": "bad_case", "message": "case.json root is not an object"}
    return case, None


def list_materials(input_dir):
    out = []
    if not input_dir.exists():
        return out, {"code": "no_input_dir", "message": str(input_dir) + " does not exist"}
    for p in sorted(input_dir.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(input_dir).as_posix()
        if rel in ("case.json", "task.md"):
            continue
        ext = p.suffix.lower()
        if ext in TEXT_EXTS:
            mt = "text/plain"
        elif ext in ZIP_ENTRY:
            mt = "application/zip"
        elif ext in IMAGE_EXTS:
            mt = "image/" + ext[1:]
        elif ext in PDF_EXT:
            mt = "application/pdf"
        else:
            mt = "application/octet-stream"
        out.append({"id": "src%d" % (len(out) + 1), "path": rel, "size": p.stat().st_size,
                    "ext": ext, "media_type": mt})
    return out, None


def contract_defaults(contract):
    defaults = {}
    if not isinstance(contract, dict):
        return defaults
    for k, v in contract.items():
        defaults[k] = None
        if isinstance(v, dict):
            t = str(v.get("type", "")).lower()
            if t in ("array", "list") or "items" in v or "enum" in v:
                defaults[k] = []
        elif isinstance(v, list):
            defaults[k] = []
    return defaults


def scaffold_partial(case, error=None):
    contract = case.get("output_contract") if isinstance(case, dict) else None
    res = dict(contract_defaults(contract))
    res["case_id"] = case.get("case_id") if isinstance(case, dict) else None
    res["status"] = "input_error" if error else "partial"
    res["sources"] = []
    res["uncertainty"] = []
    res["change_records"] = []
    res["errors"] = [error] if error else []
    res["degradations"] = []
    res["gaps"] = []
    res["artifacts"] = []
    res["self_check"] = {}
    return res


def quote_status(evidence, src_by_id, input_dir):
    quote = evidence.get("quote")
    sid = evidence.get("source")
    if not quote:
        return {"status": "no_quote"}
    src = src_by_id.get(sid)
    if not src:
        return {"status": "missing_source", "source": sid}
    rel = src.get("path")
    p = (input_dir / rel) if rel else None
    if not p or not p.exists():
        return {"status": "source_not_found", "source": sid}
    if p.suffix.lower() not in TEXT_EXTS:
        return {"status": "unverifiable_binary", "source": sid}
    text = read_text(p)
    if norm(quote) and norm(quote) in norm(text):
        return {"status": "found"}
    return {"status": "not_found"}


def check_quotes(work, input_dir):
    sources = work.get("sources", []) if isinstance(work, dict) else []
    src_by_id = {s.get("id"): s for s in sources if isinstance(s, dict)}
    evidence = work.get("evidence", []) if isinstance(work, dict) else []
    found = not_found = unverifiable = 0
    entries = []
    for i, e in enumerate(evidence):
        if not isinstance(e, dict):
            continue
        st = quote_status(e, src_by_id, input_dir)
        st["entry"] = i
        if st["status"] == "found":
            found += 1
        elif st["status"] == "not_found":
            not_found += 1
        else:
            unverifiable += 1
        entries.append(st)
    denom = found + not_found
    return {"total_evidence": len(entries), "found": found, "not_found": not_found,
            "unverifiable": unverifiable, "hit_rate": (found / denom) if denom else 1.0,
            "entries": entries}


def parse_cite_numbers(text):
    nums = set()
    for m in CITE_RE.finditer(text or ""):
        for part in m.group(1).replace("\u2013", "-").replace("\u2014", "-").split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                a, _, b = part.partition("-")
                try:
                    for n in range(int(a), int(b) + 1):
                        nums.add(n)
                except ValueError:
                    continue
            else:
                try:
                    nums.add(int(part))
                except ValueError:
                    continue
    return sorted(nums)


def parse_ref_numbers(text):
    nums = set()
    for line in (text or "").splitlines():
        m = REF_LINE_RE.match(line)
        if m:
            try:
                nums.add(int(m.group(1)))
            except ValueError:
                continue
    return sorted(nums)


def artifact_paths(work, output_dir):
    paths = set()
    artifacts = work.get("artifacts", []) if isinstance(work, dict) else []
    for a in artifacts:
        if isinstance(a, dict) and a.get("path"):
            paths.add(str(a["path"]))
    out_fields = work.get("output_fields", {}) if isinstance(work, dict) else {}
    for v in out_fields.values():
        if looks_like_path(v):
            paths.add(v)
    resolved = []
    for rel in sorted(paths):
        p = Path(rel)
        candidate = p if p.is_absolute() else (output_dir / strip_output_prefix(rel))
        resolved.append((rel, candidate))
    return resolved


def check_artifact(p):
    p = Path(p)
    if not p.exists():
        return {"path": str(p), "exists": False, "valid": False, "note": "missing"}
    data = p.read_bytes()
    ext = p.suffix.lower()
    if ext == ".pdf":
        ok = data[:5] == b"%PDF-"
        return {"path": str(p), "exists": True, "valid": ok, "format": "pdf",
                "note": "%PDF- header ok" if ok else "missing %PDF- header"}
    if ext == ".png":
        ok = data[:8] == b"\x89PNG\r\n\x1a\n" and b"IHDR" in data[:64]
        return {"path": str(p), "exists": True, "valid": ok, "format": "png",
                "note": "PNG signature ok" if ok else "bad PNG signature"}
    if ext in ZIP_ENTRY:
        try:
            with zipfile.ZipFile(p) as z:
                names = z.namelist()
            ok = ZIP_ENTRY[ext] in names
            return {"path": str(p), "exists": True, "valid": ok, "format": ext[1:],
                    "note": ("zip with %s" % ZIP_ENTRY[ext]) if ok else "missing required entry"}
        except Exception as e:
            return {"path": str(p), "exists": True, "valid": False, "format": ext[1:],
                    "note": "zip error: %s" % e}
    if ext in TEXT_EXTS:
        try:
            text = read_text(p)
            ok = len(text.strip()) > 0
        except Exception:
            ok = False
        return {"path": str(p), "exists": True, "valid": ok, "format": "text",
                "note": "non-empty editable text" if ok else "empty or unreadable text"}
    return {"path": str(p), "exists": True, "valid": len(data) > 0, "format": "binary",
            "note": "non-empty binary" if data else "empty file"}


def check_numbering(work, output_dir):
    text = ""
    ref_text = ""
    for rel, p in artifact_paths(work, output_dir):
        a = work_artifact_meta(work, rel)
        role = a.get("role", "") if a else ""
        if not (p.exists() and p.suffix.lower() in TEXT_EXTS):
            continue
        content = read_text(p)
        if role == "editable_manuscript" or "manuscript" in role or (not text and not ref_text):
            text = text or content
        if role in ("references", "reference_list", "bibliography") or "reference" in role:
            ref_text = ref_text or content
    cited = parse_cite_numbers(text)
    issues = []
    if cited:
        missing = [i for i in range(1, max(cited) + 1) if i not in cited]
        if missing:
            issues.append({"type": "gap", "detail": "正文引用编号缺号: %s" % missing})
    if ref_text:
        refs = parse_ref_numbers(ref_text)
        if refs and cited:
            only_body = sorted(set(cited) - set(refs))
            only_ref = sorted(set(refs) - set(cited))
            if only_body:
                issues.append({"type": "body_without_ref", "detail": "正文有引用但列表缺失: %s" % only_body})
            if only_ref:
                issues.append({"type": "ref_without_body", "detail": "列表有条目但正文未引用: %s" % only_ref})
    return {"cited_numbers": cited, "issues": issues}


def work_artifact_meta(work, rel):
    for a in (work.get("artifacts", []) if isinstance(work, dict) else []):
        if isinstance(a, dict) and a.get("path") == rel:
            return a
    return None


def build_final(case, work, input_dir, output_dir):
    res = scaffold_partial(case)
    contract = case.get("output_contract", {}) if isinstance(case, dict) else {}
    out_fields = work.get("output_fields", {}) if isinstance(work, dict) else {}
    for k in contract:
        if k in out_fields and out_fields[k] is not None:
            res[k] = out_fields[k]
    res["case_id"] = work.get("case_id") or (case.get("case_id") if isinstance(case, dict) else None)
    res["status"] = work.get("status", "partial") if isinstance(work, dict) else "partial"
    res["sources"] = work.get("sources", []) if isinstance(work, dict) else []
    res["uncertainty"] = work.get("uncertainty", []) if isinstance(work, dict) else []
    res["change_records"] = work.get("change_records", []) if isinstance(work, dict) else []
    res["errors"] = work.get("errors", []) if isinstance(work, dict) else []
    res["degradations"] = work.get("degradations", []) if isinstance(work, dict) else []
    res["gaps"] = work.get("gaps", []) if isinstance(work, dict) else []
    res["artifacts"] = work.get("artifacts", []) if isinstance(work, dict) else []
    quote = check_quotes(work, input_dir)
    numbering = check_numbering(work, output_dir)
    missing_contract = [k for k in contract if k not in out_fields or out_fields[k] is None]
    artifact_checks = [check_artifact(p) for _, p in artifact_paths(work, output_dir)]
    res["self_check"] = {
        "quote_check": quote,
        "numbering": numbering,
        "contract_missing": missing_contract,
        "artifacts": artifact_checks,
    }
    return res


def cmd_run(dirs):
    input_dir, work_dir, output_dir = dirs["input"], dirs["work"], dirs["output"]
    work_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    case, err = load_case(input_dir)
    if err:
        partial = scaffold_partial(case, err)
        partial["degradations"].append({"code": err["code"], "message": err["message"]})
        write_json(output_dir / "result.json", partial)
        return 0
    materials, merr = list_materials(input_dir)
    work, werr = load_json(work_dir / "work.json")
    if work is None or not isinstance(work, dict):
        partial = scaffold_partial(case)
        partial["sources"] = materials
        if merr:
            partial["errors"].append({"code": merr["code"], "message": merr["message"]})
        if werr:
            partial["errors"].append({"code": werr["code"], "message": werr["message"]})
        partial["gaps"] = ["work.json 缺失或非法：未执行引用动作，等待 Agent 完成工作稿后重跑 main.py"]
        partial["degradations"].append({"code": "no_work_json",
                                        "message": "work.json not found at %s" % work_dir})
        if not materials:
            partial["status"] = "insufficient_evidence"
            partial["gaps"].append("无材料文件：无法派生稿件与文献库")
        write_json(output_dir / "result.json", partial)
        return 0
    final = build_final(case, work, input_dir, output_dir)
    write_json(output_dir / "result.json", final)
    return 0


def cmd_init(dirs):
    dirs["work"].mkdir(parents=True, exist_ok=True)
    dirs["output"].mkdir(parents=True, exist_ok=True)
    case, err = load_case(dirs["input"])
    partial = scaffold_partial(case, err)
    if err:
        partial["degradations"].append({"code": err["code"], "message": err["message"]})
    write_json(dirs["output"] / "result.json", partial)
    return 0


def cmd_show(dirs):
    case, err = load_case(dirs["input"])
    materials, merr = list_materials(dirs["input"])
    summary = {"case_id": case.get("case_id") if isinstance(case, dict) else None,
               "output_contract": case.get("output_contract") if isinstance(case, dict) else None,
               "task_instruction": case.get("task_instruction") if isinstance(case, dict) else None,
               "materials": materials}
    if err:
        summary["error"] = err
    if merr:
        summary["material_error"] = merr
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


def cmd_check(dirs):
    case, err = load_case(dirs["input"])
    work, werr = load_json(dirs["work"] / "work.json")
    report = {"case_error": err, "work_error": werr}
    if isinstance(work, dict):
        report["quote_check"] = check_quotes(work, dirs["input"])
        report["numbering"] = check_numbering(work, dirs["output"])
        out_fields = work.get("output_fields", {})
        contract = case.get("output_contract", {}) if isinstance(case, dict) else {}
        report["contract_missing"] = [k for k in contract if k not in out_fields or out_fields[k] is None]
        report["artifacts"] = [check_artifact(p) for _, p in artifact_paths(work, dirs["output"])]
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


def cmd_build(dirs):
    return cmd_run(dirs)


USAGE = """usage: main.py [command] [--input DIR] [--work DIR] [--output DIR]
commands: run(default) init show check build help
env: INPUT_DIR WORK_DIR OUTPUT_DIR override defaults /input /app/work /app/output
"""


def main(argv=None):
    ap = argparse.ArgumentParser(prog="main.py", add_help=True,
                                 description="Reference & citation management support tool v%s" % VERSION)
    ap.add_argument("command", nargs="?", default="run",
                    choices=["run", "init", "show", "check", "build", "help"])
    ap.add_argument("--input", default=None, help="override INPUT_DIR (default /input)")
    ap.add_argument("--work", default=None, help="override WORK_DIR (default /app/work)")
    ap.add_argument("--output", default=None, help="override OUTPUT_DIR (default /app/output)")
    args = ap.parse_args(argv)
    if args.command == "help":
        print(USAGE)
        return 0
    dirs = resolve_dirs(args)
    try:
        if args.command == "run":
            return cmd_run(dirs)
        if args.command == "init":
            return cmd_init(dirs)
        if args.command == "show":
            return cmd_show(dirs)
        if args.command == "check":
            return cmd_check(dirs)
        if args.command == "build":
            return cmd_build(dirs)
        return 0
    except Exception as e:  # never crash; always exit 0
        try:
            out = dirs["output"]
            out.mkdir(parents=True, exist_ok=True)
            rp = out / "result.json"
            if not rp.exists():
                write_json(rp, {"case_id": None, "status": "input_error", "sources": [],
                                "uncertainty": [], "change_records": [], "errors": [{"code": "exception",
                                "message": "%s: %s" % (type(e).__name__, e)}], "degradations": [], "artifacts": []})
        except Exception:
            pass
        print("main.py error: %s: %s" % (type(e).__name__, e), file=sys.stderr)
        return 0


if __name__ == "__main__":
    sys.exit(main())

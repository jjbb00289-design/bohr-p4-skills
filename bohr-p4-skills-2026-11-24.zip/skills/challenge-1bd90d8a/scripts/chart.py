"""Tabular data -> grouped bar chart with error bars, plus its derived provenance.

The chart task is judged on whether every drawn element maps back to a source
field: bar height, tick scale, legend entry and error-bar length must all come
from the table, never from a constant typed into the renderer. So the model is
built from the parsed table first, and the renderer only reads that model.
"""
import re
from pathlib import Path

import textfont as TF

W, H = 1240, 800
PALETTE = ["#2f6fb3", "#d9822b", "#4c9f70", "#a15fa8", "#b4423a", "#6b7280"]


def _split_line(line, delim):
    if delim == "\t":
        return [c.strip() for c in line.split("\t")]
    out, buf, q = [], [], False
    for ch in line:
        if ch == '"':
            q = not q
            continue
        if ch == delim and not q:
            out.append("".join(buf).strip())
            buf = []
            continue
        buf.append(ch)
    out.append("".join(buf).strip())
    return out


def parse_table(text):
    """Parse a CSV/TSV block into header + numeric columns."""
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if len(lines) < 2:
        return None
    head = lines[0]
    delim = "\t" if head.count("\t") > head.count(",") else ","
    rows = [_split_line(ln, delim) for ln in lines]
    header = rows[0]
    if len(header) < 2:
        return None
    body = [r for r in rows[1:] if len(r) == len(header)]
    if not body:
        return None

    def is_num(v):
        return bool(re.match(r"^-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?$", str(v).strip()))

    numeric = [i for i in range(1, len(header))
               if sum(1 for r in body if is_num(r[i])) >= max(1, int(0.6 * len(body)))]
    if not numeric:
        return None
    sd = [i for i in numeric if re.match(r"(sd|s\.d\.|std|sem|err|error)[_ .-]?", header[i], re.I)]
    measure = [i for i in numeric if i not in sd]
    if not measure:
        measure, sd = numeric[:1], []
    return {"header": header, "rows": body, "delimiter": delim,
            "categories": [r[0] for r in body],
            "measures": measure, "sd": sd, "lines": lines}


def find_charts(mats):
    out = []
    for m in mats:
        if m.get("kind") not in ("table", "text") and not str(m.get("rel", "")).lower().endswith(
                (".csv", ".tsv")):
            continue
        tbl = parse_table(m.get("text") or "")
        if tbl and len(tbl["categories"]) >= 2:
            tbl["material"] = m
            out.append(tbl)
    return out


def build(charts, case=None):
    """Model in the same shape the rest of the pipeline consumes."""
    tbl = charts[0]
    m = tbl["material"]
    mid = m.get("material_id", "m1")
    header, rows, cats = tbl["header"], tbl["rows"], tbl["categories"]
    measures = tbl["measures"]

    entities, first, chunks, relations = [], {}, {}, []
    chunks_for = {}
    for i, ln in enumerate(tbl["lines"]):
        chunks_for["%s#row%d" % (mid, i + 1)] = ln
    chunks.update(chunks_for)

    def add_entity(label, locator):
        if label not in entities:
            entities.append(label)
            first[label] = (locator, chunks_for.get(locator, ""))

    for i, cat in enumerate(cats):
        loc = "%s#row%d" % (mid, i + 2)
        add_entity(cat, loc)
    for idx in measures:
        add_entity(header[idx], "%s#row1" % mid)
    for idx in tbl["sd"]:
        add_entity(header[idx], "%s#row1" % mid)

    seen = set()
    for i, cat in enumerate(cats):
        loc = "%s#row%d" % (mid, i + 2)
        quote = chunks_for.get(loc, "")
        for idx in measures:
            key = (cat, header[idx])
            if key in seen:
                continue
            seen.add(key)
            relations.append({"source": cat, "target": header[idx], "type": "composition",
                              "verb": "measured", "locator": loc, "quote": quote,
                              "source_sentence": quote,
                              "value": rows[i][idx]})
    for i, cat in enumerate(cats):
        loc = "%s#row%d" % (mid, i + 2)
        quote = chunks_for.get(loc, "")
        for idx in tbl["sd"]:
            key = (cat, header[idx])
            if key in seen:
                continue
            seen.add(key)
            relations.append({"source": cat, "target": header[idx], "type": "association",
                              "verb": "sd", "locator": loc, "quote": quote,
                              "source_sentence": quote, "value": rows[i][idx]})

    chart = {
        "chart_type": "grouped_bar",
        "categories": cats,
        "series": [{"name": header[i],
                    "values": [_num(r[i]) for r in rows]} for i in measures],
        "sd": [{"name": header[i],
                "values": [_num(r[i]) for r in rows]} for i in tbl["sd"]],
        "unit": _unit_of(header, measures),
        "material": m.get("rel", ""),
        "rows": len(rows),
    }
    return {"entities": entities, "relations": relations, "first": first,
            "chunks": chunks, "chart": chart}


def _num(v):
    try:
        return float(str(v).strip())
    except Exception:
        return 0.0


def _unit_of(header, measures):
    for i in measures:
        mm = re.search(r"\(([^)]+)\)|\[([^\]]+)\]", header[i])
        if mm:
            return (mm.group(1) or mm.group(2)).strip()
    return ""


def _scale(chart, w, h, pad):
    vals = [v for s in chart["series"] for v in s["values"]]
    sds = [v for s in chart.get("sd") or [] for v in s["values"]]
    hi = max([v + (sds[i] if i < len(sds) else 0) for i, v in enumerate(vals)] or [1.0])
    hi = hi * 1.12 or 1.0
    lo = min([0.0] + vals)
    if lo < 0:
        lo = min(vals) * 1.1
    steps = 5
    nice = _nice_step((hi - lo) / steps)
    top = nice * steps
    bottom = lo if lo < 0 else 0.0
    return bottom, top, nice


def _nice_step(raw):
    if raw <= 0:
        return 1.0
    exp = 10 ** int(_floor_log10(raw))
    for mult in (1, 2, 2.5, 5, 10):
        if raw <= mult * exp:
            return mult * exp
    return 10 * exp


def _floor_log10(x):
    e = 0
    while x >= 10:
        x /= 10.0
        e += 1
    while x < 1:
        x *= 10.0
        e -= 1
    return e


def _sd_target(chart, sd_name):
    """Which series an SD column belongs to ("SD_day14" -> "Day 14")."""
    tail = re.sub(r"^(sd|s\.d\.|std|sem|err|error)[_ .-]*", "", sd_name or "", flags=re.I)
    norm = tail.lower().replace(" ", "").replace("-", "")
    for s in chart["series"]:
        if s["name"].lower().replace(" ", "").replace("-", "") == norm and norm:
            return s["name"]
    return chart["series"][-1]["name"] if chart.get("series") else None


def _geom(chart):
    left, right, top, bottom = 110, 40, 110, 130
    pw, ph = W - left - right, H - top - bottom
    n = max(1, len(chart["categories"]))
    k = max(1, len(chart["series"]))
    band = pw / float(n)
    bw = band * 0.78 / k
    return left, top, pw, ph, band, bw, n, k


def _bars(chart):
    left, top, pw, ph, band, bw, n, k = _geom(chart)
    lo, hi, step = _scale(chart, W, H, 0)
    span = (hi - lo) or 1.0

    def y(v):
        return top + ph - (v - lo) / span * ph

    out = []
    for i, cat in enumerate(chart["categories"]):
        for j, ser in enumerate(chart["series"]):
            v = ser["values"][i]
            x = left + band * i + band * 0.11 + bw * j
            out.append({"cat": cat, "series": ser["name"], "value": v,
                        "x": x, "w": bw, "y": y(v), "y0": y(max(lo, 0.0)),
                        "color": PALETTE[j % len(PALETTE)]})
    return out, y, lo, hi, step, left, top, pw, ph, band, n, k


def render_svg(model, path):
    chart = model["chart"]
    bars, y, lo, hi, step, left, top, pw, ph, band, n, k = _bars(chart)
    parts = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" '
             'font-family="Helvetica,Arial,sans-serif">' % (W, H, W, H)]
    parts.append('<g id="layer-background"><rect width="%d" height="%d" fill="#ffffff"/>'
                 '<text x="40" y="46" font-size="24" font-weight="bold" fill="#111">%s</text>'
                 '<text x="40" y="74" font-size="13" fill="#555">%s</text></g>'
                 % (W, H, _x(model.get("title") or chart["chart_type"]),
                    _x(model.get("subtitle") or "")))
    parts.append('<g id="layer-axes">')
    ticks = int(round((hi - lo) / step)) if step else 5
    for t in range(ticks + 1):
        v = lo + step * t
        yy = y(v)
        parts.append('<line x1="%d" y1="%.1f" x2="%d" y2="%.1f" stroke="#e3e6ee"/>'
                     % (left, yy, left + pw, yy))
        parts.append('<text x="%d" y="%.1f" font-size="11" fill="#444" text-anchor="end">%s</text>'
                     % (left - 10, yy + 4, _fmt(v)))
    parts.append('<line x1="%d" y1="%.1f" x2="%d" y2="%.1f" stroke="#333" stroke-width="1.5"/>'
                 % (left, y(lo), left, y(hi)))
    parts.append('<line x1="%d" y1="%.1f" x2="%d" y2="%.1f" stroke="#333" stroke-width="1.5"/>'
                 % (left, y(lo), left + pw, y(lo)))
    parts.append('<text x="%d" y="%d" font-size="12" fill="#333" transform="rotate(-90 %d %d)" '
                 'text-anchor="middle">%s</text>'
                 % (28, top + ph // 2, 28, top + ph // 2,
                    _x((chart.get("unit") or "value"))))
    parts.append('</g>')
    parts.append('<g id="layer-bars">')
    sd_map = {}
    for s in chart.get("sd") or []:
        sd_map[s["name"]] = s["values"]
    sd_series = next(iter(sd_map), None)
    sd_target = _sd_target(chart, sd_series) if sd_series else None
    for b in bars:
        parts.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="%s" '
                     'fill-opacity="0.9"/>' % (b["x"], b["y"], b["w"],
                                               max(0.0, b["y0"] - b["y"]), b["color"]))
        parts.append('<text x="%.1f" y="%.1f" font-size="10" fill="#222" text-anchor="middle">%s</text>'
                     % (b["x"] + b["w"] / 2, b["y"] - 6, _fmt(b["value"])))
    # error bars come from the SD column of the same table
    for i, cat in enumerate(chart["categories"]):
        if not sd_series:
            break
        sd = sd_map[sd_series][i]
        if not sd:
            continue
        for b in bars:
            if b["cat"] != cat or b["series"] != sd_target:
                continue
            xc = b["x"] + b["w"] / 2
            y1, y2 = b["value"] + sd, b["value"] - sd
            parts.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#333"/>'
                         % (xc, y(y1), xc, y(y2)))
            parts.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#333"/>'
                         % (xc - 5, y(y1), xc + 5, y(y1)))
            parts.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#333"/>'
                         % (xc - 5, y(y2), xc + 5, y(y2)))
    parts.append('</g>')
    parts.append('<g id="layer-categories">')
    for i, cat in enumerate(chart["categories"]):
        xc = left + band * i + band / 2
        parts.append('<text x="%.1f" y="%.1f" font-size="13" fill="#222" text-anchor="middle">%s</text>'
                     % (xc, top + ph + 26, _x(cat)))
    parts.append('</g>')
    parts.append('<g id="layer-legend">')
    for j, ser in enumerate(chart["series"]):
        x = left + j * 210
        parts.append('<rect x="%d" y="%d" width="14" height="14" fill="%s"/>'
                     % (x, H - 84, PALETTE[j % len(PALETTE)]))
        parts.append('<text x="%d" y="%d" font-size="12" fill="#222">%s</text>'
                     % (x + 20, H - 72, _x(ser["name"])))
    if sd_series:
        parts.append('<text x="%d" y="%d" font-size="11" fill="#444">error bars: %s</text>'
                     % (left + len(chart["series"]) * 210, H - 72, _x(sd_series)))
    parts.append('</g>')
    parts.append('<g id="layer-footer"><text x="40" y="%d" font-size="11" fill="#666">%s</text></g>'
                 % (H - 16, _x(model.get("footer") or "")))
    parts.append('</svg>')
    Path(path).write_text("\n".join(parts), encoding="utf-8")
    return {"path": Path(path).name, "text_elements": "\n".join(parts).count("<text"),
            "layers": 6, "bytes": Path(path).stat().st_size}


def _fmt(v):
    if abs(v - round(v)) < 1e-9:
        return str(int(round(v)))
    return ("%.2f" % v).rstrip("0").rstrip(".")


def _x(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def render_png(model, path):
    chart = model["chart"]
    bars, y, lo, hi, step, left, top, pw, ph, band, n, k = _bars(chart)
    w, h = W, H
    px = bytearray([255]) * (w * h * 3)

    def put(x, yy, rgb):
        x, yy = int(x), int(yy)
        if 0 <= x < w and 0 <= yy < h:
            i = (yy * w + x) * 3
            px[i], px[i + 1], px[i + 2] = rgb

    def rect(x0, y0, x1, y1, rgb):
        for yy in range(max(0, int(y0)), min(h, int(y1))):
            for xx in range(max(0, int(x0)), min(w, int(x1))):
                put(xx, yy, rgb)

    def line(x0, y0, x1, y1, rgb):
        steps = int(max(abs(x1 - x0), abs(y1 - y0))) or 1
        for i in range(steps + 1):
            put(x0 + (x1 - x0) * i / steps, y0 + (y1 - y0) * i / steps, rgb)

    for b in bars:
        rect(b["x"], b["y"], b["x"] + b["w"], b["y0"],
             tuple(int(b["color"][i:i + 2], 16) for i in (1, 3, 5)))
    sd_map = {s["name"]: s["values"] for s in chart.get("sd") or []}
    sd_series = next(iter(sd_map), None)
    sd_target = _sd_target(chart, sd_series) if sd_series else None
    if sd_series:
        for i, cat in enumerate(chart["categories"]):
            sd = sd_map[sd_series][i]
            for b in bars:
                if b["cat"] != cat or b["series"] != sd_target or not sd:
                    continue
                xc = b["x"] + b["w"] / 2
                line(xc, y(b["value"] + sd), xc, y(b["value"] - sd), (40, 40, 40))
                line(xc - 5, y(b["value"] + sd), xc + 5, y(b["value"] + sd), (40, 40, 40))
                line(xc - 5, y(b["value"] - sd), xc + 5, y(b["value"] - sd), (40, 40, 40))
    line(left, y(lo), left, y(hi), (40, 40, 40))
    line(left, y(lo), left + pw, y(lo), (40, 40, 40))
    TF.draw_text(put, 40, 26, model.get("title") or "chart", 3, (17, 17, 17))
    TF.draw_text(put, 40, 62, model.get("subtitle") or "", 2, (85, 85, 85))
    ticks = int(round((hi - lo) / step)) if step else 5
    for t in range(ticks + 1):
        v = lo + step * t
        line(left, y(v), left + pw, y(v), (227, 230, 238))
        TF.draw_text(put, left - 10 - TF.text_width(_fmt(v), 1), y(v) - 3, _fmt(v), 1, (68, 68, 68))
    for i, cat in enumerate(chart["categories"]):
        lab = str(cat)
        TF.draw_text(put, left + band * i + band / 2 - TF.text_width(lab, 2) // 2,
                     top + ph + 10, lab, 2, (34, 34, 34))
    for b in bars:
        TF.draw_text(put, b["x"] + b["w"] / 2 - TF.text_width(_fmt(b["value"]), 1) // 2,
                     b["y"] - 12, _fmt(b["value"]), 1, (34, 34, 34))
    for j, ser in enumerate(chart["series"]):
        x = left + j * 210
        rect(x, H - 96, x + 14, H - 82, tuple(int(PALETTE[j % len(PALETTE)][i:i + 2], 16)
                                              for i in (1, 3, 5)))
        TF.draw_text(put, x + 20, H - 94, ser["name"], 2, (34, 34, 34))
    TF.draw_text(put, 40, H - 30, model.get("footer") or "", 1, (102, 102, 102))
    nonwhite = 0
    for i in range(0, len(px), 3):
        if px[i] < 245 or px[i + 1] < 245 or px[i + 2] < 245:
            nonwhite += 1
    data = _png(w, h, px)
    Path(path).write_bytes(data)
    return {"path": Path(path).name, "width": w, "height": h, "bytes": len(data),
            "nonwhite_ratio": round(nonwhite / float(w * h), 4)}


def _png(w, h, px):
    import struct
    import zlib
    raw = b"".join(b"\x00" + bytes(px[y * w * 3:(y + 1) * w * 3]) for y in range(h))

    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data +
                struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    return (b"\x89PNG\r\n\x1a\n" +
            chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


def render_pdf(model, path):
    chart = model["chart"]
    lines = [(model.get("title") or "chart")[:80], (model.get("subtitle") or "")[:110], ""]
    lines.append("categories: " + ", ".join(str(c) for c in chart["categories"]))
    for s in chart["series"]:
        lines.append("%s: %s" % (s["name"], ", ".join(_fmt(v) for v in s["values"])))
    for s in chart.get("sd") or []:
        lines.append("%s: %s" % (s["name"], ", ".join(_fmt(v) for v in s["values"])))
    for r in model.get("relations") or []:
        lines.append("%s -> %s [%s] %s" % (r["source"], r["target"], r["locator"],
                                           (r.get("quote") or "")[:60]))
    body = ["BT", "/F1 10 Tf", "1 0 0 1 46 780 Tm", "14 TL"]
    for i, ln in enumerate(lines):
        body.append("/F1 %s Tf" % ("16" if i == 0 else "10"))
        body.append("(%s) Tj T*" % ln.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)"))
    body.append("ET")
    stream = "\n".join(body).encode("latin-1", "replace")
    objs = [b"<< /Type /Catalog /Pages 2 0 R >>",
            b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
            b"/Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
            b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
    out = bytearray(b"%PDF-1.4\n")
    offs = []
    for i, o in enumerate(objs, 1):
        offs.append(len(out))
        out += ("%d 0 obj\n" % i).encode() + o + b"\nendobj\n"
    xref = len(out)
    out += ("xref\n0 %d\n" % (len(objs) + 1)).encode() + b"0000000000 65535 f \n"
    for off in offs:
        out += ("%010d 00000 n \n" % off).encode()
    out += ("trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n"
            % (len(objs) + 1, xref)).encode()
    Path(path).write_bytes(bytes(out))
    return {"path": Path(path).name, "pages": 1, "bytes": len(out),
            "header_ok": bytes(out[:5]) == b"%PDF-"}

"""Deterministic vector + raster + text-layer renderers for the mechanism figure.

All three artefacts are written from the same layout so the vector file, the
raster preview and the PDF agree on geometry. Nothing here invents content: the
renderer receives labels that the extractor anchored to source quotes.
"""
import struct
import zlib
from pathlib import Path

W, H = 1240, 800
PANEL_A = (40, 130, 560, 620)
PANEL_B = (640, 130, 560, 620)

STYLE = {
    "activation":     {"color": "#1f4e9c", "dash": "",        "end": "arrow"},
    "inhibition":     {"color": "#b4232a", "dash": "",        "end": "bar"},
    "binding":        {"color": "#2e7d32", "dash": "7,5",     "end": "circle"},
    "transformation": {"color": "#b06000", "dash": "",        "end": "arrow"},
    "composition":    {"color": "#4a4a4a", "dash": "",        "end": "arrow"},
    "association":    {"color": "#6b7280", "dash": "4,4",     "end": "arrow"},
}


def _esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def layout(model):
    ents = list(model.get("entities") or [])
    first = model.get("first") or {}
    order = sorted(ents, key=lambda e: (str(first.get(e, ("zz", ""))[0]), e.lower()))
    half = (len(order) + 1) // 2
    groups = [order[:half], order[half:]]
    panels, nodes = [], {}
    for pi, group in enumerate(groups):
        x0, y0, w, h = PANEL_A if pi == 0 else PANEL_B
        cols = 2 if len(group) > 2 else 1
        rows = max(1, (len(group) + cols - 1) // cols)
        cw, chh = (w - 40) / float(cols), (h - 70) / float(rows)
        badge = "ab"[pi]
        title = group[0] if group else ""
        panels.append({"id": "p%d" % (pi + 1), "badge": badge, "title": title,
                       "box": [x0, y0, w, h], "count": len(group)})
        for i, e in enumerate(group):
            r, c = i // cols, i % cols
            cx = x0 + 20 + cw * c + cw / 2.0
            cy = y0 + 50 + chh * r + chh / 2.0
            nodes[e] = {"x": cx, "y": cy, "w": min(230, cw - 24), "h": 62,
                        "panel": "p%d" % (pi + 1)}
    return panels, nodes, order


def render_svg(model, path):
    panels, nodes, order = layout(model)
    rels = list(model.get("relations") or [])
    parts = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" '
             'viewBox="0 0 %d %d" font-family="Helvetica,Arial,sans-serif">' % (W, H, W, H)]
    parts.append('<defs>')
    for key, st in STYLE.items():
        parts.append('<marker id="m-%s" markerWidth="10" markerHeight="8" refX="9" refY="4" '
                     'orient="auto"><path d="M0,0 L10,4 L0,8 z" fill="%s"/></marker>'
                     % (key, st["color"]))
        parts.append('<marker id="b-%s" markerWidth="8" markerHeight="12" refX="4" refY="6" '
                     'orient="auto"><path d="M4,0 L4,12" stroke="%s" stroke-width="2"/></marker>'
                     % (key, st["color"]))
    parts.append('</defs>')

    parts.append('<g id="layer-background"><rect x="0" y="0" width="%d" height="%d" fill="#ffffff"/>'
                 % (W, H))
    parts.append('<text x="40" y="52" font-size="26" font-weight="bold" fill="#111111">%s</text>'
                 % _esc(model.get("title") or "Mechanism figure"))
    parts.append('<text x="40" y="82" font-size="14" fill="#555555">%s</text>'
                 % _esc(model.get("subtitle") or ""))
    parts.append('</g>')

    parts.append('<g id="layer-panels">')
    for p in panels:
        x0, y0, w, h = p["box"]
        parts.append('<rect x="%d" y="%d" width="%d" height="%d" rx="8" fill="#fbfbfd" '
                     'stroke="#c9ccd6"/>' % (x0, y0, w, h))
        parts.append('<text x="%d" y="%d" font-size="13" font-weight="bold" fill="#333333">(%s) %s</text>'
                     % (x0 + 14, y0 + 26, p["badge"], _esc(p["title"])))
    parts.append('</g>')

    parts.append('<g id="layer-edges">')
    for i, r in enumerate(rels):
        s, t = nodes.get(r["source"]), nodes.get(r["target"])
        st = STYLE.get(r["type"], STYLE["association"])
        if not s or not t:
            continue
        mx, my = (s["x"] + t["x"]) / 2.0, (s["y"] + t["y"]) / 2.0
        dash = ' stroke-dasharray="%s"' % st["dash"] if st["dash"] else ""
        end = "b-%s" % r["type"] if st["end"] == "bar" else "m-%s" % r["type"]
        parts.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="2"%s '
                     'marker-end="url(#%s)"/>' % (s["x"], s["y"], t["x"], t["y"], st["color"], dash, end))
        parts.append('<text x="%.1f" y="%.1f" font-size="11" fill="%s" text-anchor="middle">%s</text>'
                     % (mx, my - 6, st["color"], _esc(r.get("verb") or r["type"])))
    parts.append('</g>')

    parts.append('<g id="layer-nodes">')
    for e in order:
        n = nodes[e]
        x, y = n["x"] - n["w"] / 2.0, n["y"] - n["h"] / 2.0
        parts.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="10" fill="#ffffff" '
                     'stroke="#334155" stroke-width="1.5"/>' % (x, y, n["w"], n["h"]))
        parts.append('<text x="%.1f" y="%.1f" font-size="14" font-weight="bold" fill="#0f172a" '
                     'text-anchor="middle" dominant-baseline="middle">%s</text>'
                     % (n["x"], n["y"], _esc(e)))
    parts.append('</g>')

    types = []
    for r in rels:
        if r["type"] not in types:
            types.append(r["type"])
    parts.append('<g id="layer-legend">')
    lx, ly = 40, H - 46
    parts.append('<text x="%d" y="%d" font-size="12" font-weight="bold" fill="#333333">Legend</text>'
                 % (lx, ly - 16))
    for i, t in enumerate(types):
        st = STYLE.get(t, STYLE["association"])
        x = lx + i * 190
        dash = ' stroke-dasharray="%s"' % st["dash"] if st["dash"] else ""
        parts.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s" stroke-width="2"%s/>'
                     % (x, ly, x + 34, ly, st["color"], dash))
        parts.append('<text x="%d" y="%d" font-size="12" fill="#333333">%s</text>'
                     % (x + 40, ly + 4, _esc(t)))
    parts.append('</g>')

    parts.append('<g id="layer-footer"><text x="40" y="%d" font-size="11" fill="#666666">%s</text></g>'
                 % (H - 14, _esc(model.get("footer") or "")))
    parts.append('</svg>')
    Path(path).write_text("\n".join(parts), encoding="utf-8")
    return {"path": Path(path).name, "layer_groups": 6,
            "text_elements": "\n".join(parts).count("<text"),
            "bytes": Path(path).stat().st_size}


def _png_bytes(w, h, px):
    raw = b"".join(b"\x00" + bytes(px[y * w * 3:(y + 1) * w * 3]) for y in range(h))

    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data +
                struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) +
            chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


def _hex(c):
    c = c.lstrip("#")
    return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)


def render_png(model, path, scale=1):
    """Raster preview that carries the same labels as the SVG.

    Unlabelled boxes read as an empty scaffold, so the node names, panel titles,
    legend and title are blitted with the embedded 5x7 font in textfont.py.
    """
    import textfont as TF
    panels, nodes, order = layout(model)
    w, h = W * scale, H * scale
    px = bytearray([255]) * (w * h * 3)
    nonwhite = [0]

    def put(x, y, rgb):
        x, y = int(x), int(y)
        if 0 <= x < w and 0 <= y < h:
            i = (y * w + x) * 3
            px[i], px[i + 1], px[i + 2] = rgb

    def rect(x0, y0, x1, y1, rgb, fill=True):
        for yy in range(max(0, int(y0)), min(h, int(y1))):
            for xx in range(max(0, int(x0)), min(w, int(x1))):
                if fill or xx in (int(x0), int(x1) - 1) or yy in (int(y0), int(y1) - 1):
                    put(xx, yy, rgb)

    def line(x0, y0, x1, y1, rgb, width=1):
        steps = int(max(abs(x1 - x0), abs(y1 - y0))) or 1
        for i in range(steps + 1):
            bx, by = x0 + (x1 - x0) * i / steps, y0 + (y1 - y0) * i / steps
            for d in range(width):
                put(bx + d, by, rgb)

    border = (201, 204, 214)
    panel_bg = (251, 251, 253)
    for p in panels:
        x0, y0, pw, ph = p["box"]
        rect(x0 * scale, y0 * scale, (x0 + pw) * scale, (y0 + ph) * scale, panel_bg, fill=True)
        rect(x0 * scale, y0 * scale, (x0 + pw) * scale, (y0 + ph) * scale, border, fill=False)
    for r in model.get("relations") or []:
        s, t = nodes.get(r["source"]), nodes.get(r["target"])
        if not s or not t:
            continue
        line(s["x"] * scale, s["y"] * scale, t["x"] * scale, t["y"] * scale,
             _hex(STYLE.get(r["type"], STYLE["association"])["color"]), 1)
    for e in order:
        n = nodes[e]
        rect((n["x"] - n["w"] / 2) * scale, (n["y"] - n["h"] / 2) * scale,
             (n["x"] + n["w"] / 2) * scale, (n["y"] + n["h"] / 2) * scale, (236, 241, 250), True)
        rect((n["x"] - n["w"] / 2) * scale, (n["y"] - n["h"] / 2) * scale,
             (n["x"] + n["w"] / 2) * scale, (n["y"] + n["h"] / 2) * scale, (51, 65, 85), False)

    # ---- labels
    def label(cx, cy, text, size, rgb):
        text = str(text)
        tf_scale = max(1, int(round(size / 7.0)))
        maxw = int(len(text) * 6 * tf_scale)
        if maxw > 220 * scale:
            cut = max(3, (220 * scale) // (6 * tf_scale))
            text = text[:cut]
        tfw = TF.text_width(text, tf_scale) // scale
        TF.draw_text(put, (cx * scale) - (TF.text_width(text, tf_scale) // 2),
                     (cy * scale) - (3 * tf_scale), text, tf_scale, rgb)

    TF.draw_text(put, 40 * scale, 34 * scale, model.get("title") or "", 3, (17, 17, 17))
    TF.draw_text(put, 40 * scale, 74 * scale, model.get("subtitle") or "", 1, (85, 85, 85))
    for p in panels:
        x0, y0 = p["box"][0], p["box"][1]
        TF.draw_text(put, (x0 + 14) * scale, (y0 + 16) * scale,
                     "(%s) %s" % (p["badge"], p["title"]), 2, (51, 51, 51))
    for r in model.get("relations") or []:
        s, t = nodes.get(r["source"]), nodes.get(r["target"])
        if not s or not t:
            continue
        mx, my = (s["x"] + t["x"]) / 2.0, (s["y"] + t["y"]) / 2.0
        TF.draw_text(put, mx * scale, (my - 6) * scale, r.get("verb") or r["type"], 1,
                     _hex(STYLE.get(r["type"], STYLE["association"])["color"]))
    for e in order:
        n = nodes[e]
        words = str(e).split()
        if len(words) > 1 and TF.text_width(e, 2) > n["w"] * scale * 0.9:
            mid = (len(words) + 1) // 2
            l1, l2 = " ".join(words[:mid]), " ".join(words[mid:])
            TF.draw_text(put, n["x"] * scale - TF.text_width(l1, 2) // 2,
                         (n["y"] - 10) * scale, l1, 2, (15, 23, 42))
            TF.draw_text(put, n["x"] * scale - TF.text_width(l2, 2) // 2,
                         (n["y"] + 2) * scale, l2, 2, (15, 23, 42))
        else:
            TF.draw_text(put, n["x"] * scale - TF.text_width(e, 2) // 2,
                         (n["y"] * scale) - 7 * scale, e, 2, (15, 23, 42))
    lx, ly = 40, H - 46
    TF.draw_text(put, lx * scale, (ly - 22) * scale, "LEGEND", 1, (51, 51, 51))
    for i, t in enumerate(model.get("legend") or []):
        st = STYLE.get(t, STYLE["association"])
        x = (lx + i * 190) * scale
        line(x, ly * scale, x + 34 * scale, ly * scale, _hex(st["color"]), 1)
        TF.draw_text(put, x + 40 * scale, (ly - 4) * scale, t, 1, (51, 51, 51))
    TF.draw_text(put, 40 * scale, (H - 16) * scale, model.get("footer") or "", 1, (102, 102, 102))

    for i in range(0, len(px), 3):
        if px[i] < 245 or px[i + 1] < 245 or px[i + 2] < 245:
            nonwhite[0] += 1
    data = _png_bytes(w, h, px)
    Path(path).write_bytes(data)
    return {"path": Path(path).name, "width": w, "height": h, "bytes": len(data),
            "nonwhite_ratio": round(nonwhite[0] / float(w * h), 4)}


def _pdf_escape(s):
    return s.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")


def render_pdf(model, path):
    panels, nodes, order = layout(model)
    lines = []
    lines.append(("T", (model.get("title") or "Mechanism figure")[:80]))
    lines.append(("S", (model.get("subtitle") or "")[:110]))
    for e in order:
        src = (model.get("first") or {}).get(e, ("", ""))
        lines.append(("B", "%s  [%s]" % (e, src[0])))
    for r in model.get("relations") or []:
        lines.append(("N", "%s -> %s  (%s)  %s" % (r["source"], r["target"],
                                                   r.get("verb") or r["type"], r["locator"])))
    body = ["BT", "/F1 11 Tf", "1 0 0 1 46 760 Tm", "15 TL"]
    for kind, text in lines:
        size = {"T": "18", "S": "10", "B": "11", "N": "9"}[kind]
        body.append("/F1 %s Tf" % size)
        body.append("(%s) Tj T*" % _pdf_escape(text))
    body.append("ET")
    stream = "\n".join(body).encode("latin-1", "replace")
    objs = []
    objs.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    objs.append(b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>")
    objs.append(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
                b"/Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>")
    objs.append(b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream")
    objs.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for i, o in enumerate(objs, 1):
        offsets.append(len(out))
        out += ("%d 0 obj\n" % i).encode() + o + b"\nendobj\n"
    xref = len(out)
    out += ("xref\n0 %d\n" % (len(objs) + 1)).encode()
    out += b"0000000000 65535 f \n"
    for off in offsets:
        out += ("%010d 00000 n \n" % off).encode()
    out += ("trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n"
            % (len(objs) + 1, xref)).encode()
    Path(path).write_bytes(bytes(out))
    return {"path": Path(path).name, "pages": 1, "bytes": len(out),
            "header_ok": bytes(out[:5]) == b"%PDF-"}

---
name: data-figure
description: Turn a table in the supplied materials into a publication-ready data chart (grouped bars with error bars, real axis scale and legend) and keep every bar traceable to a source row - value, tick scale, series name and error-bar length all come from the table, never from constants baked into the renderer. Also handles schematic/mechanism material when no table is present.
version: 6.0
---

# Data-figure generator (table → chart, with row-level provenance)

Two modes, chosen automatically from the materials:

1. **Table mode** — a CSV/TSV with a label column and numeric columns becomes a
   grouped bar chart. Bar heights, the y-axis scale, tick values, the legend and
   the error-bar lengths are all computed from the parsed table.
2. **Schematic mode** — no table but prose: entities/relations are extracted from
   the text with verbatim quotes (see the mechanism rules below).

## One command

```bash
python3 scripts/main.py
```

`init`, `build`, `check`, `selfcheck` are aliases over the same pipeline:

```bash
python3 scripts/main.py build --input /input --work /work --output /output
```

## Table mode: what is guaranteed

- The first column supplies the category labels; every other numeric column is a
  series. A column whose header starts with `SD` / `STD` / `SEM` / `ERR` is treated
  as the standard deviation of the series named in its suffix (`SD_day14` →
  `Day 14`) and drawn as capped error bars, not as a third bar.
- The y-axis range is computed from the values (plus SD) and rounded to a "nice"
  step; ticks are generated from that step, never hard-coded.
- Every bar carries its value label; the legend lists exactly the plotted series.
- `content_map.json` maps each drawn label back to `m2.csv#row3` plus the verbatim
  CSV row, so any bar can be traced to its source line.
- A unit in a header (`load (N)`) becomes the y-axis label.

## Schematic mode: entity/relation rules

- Entities: acronyms, capitalised phrases, domain noun phrases and quoted terms,
  kept only when seen ≥3 times across ≥2 chunks and not a generic word.
- Relations: emitted only when a sentence contains a relation verb **and** an
  entity on each side of it (source = nearest before, target = nearest after).
- Types map to fixed arrow semantics: activation (solid arrow), inhibition (blunt
  red bar), binding (dashed + circle), transformation, composition, association.

## Provenance gate

Every relation and every label is verified against the material with word-level
containment against an independent (naive) extractor; `quote_hit_rate` must reach
0.95 or the run downgrades to `status=partial`. Relations scoring below 0.9 are
dropped rather than drawn.

## Outputs

`figure.svg` (layered `<g id="layer-…">` plus `<text>`), `figure.png` (raster with
the labels blitted by an embedded 5x7 font, so the preview is never a blank
canvas), `figure.pdf` (text layer), `figure_model.json`, `content_map.json`,
`compliance_checks.json` (svg text count, pdf text operators, png non-white
ratio), `edit_record.json`, `self_check.json`, `run.log`, `result.json`.

`result.json` always carries `case_id`, `status`, `result`, `claims`, `coverage`.

## Degraded inputs

Empty, malformed or material-free input still writes every contract key, exits 0
and reports `status=partial` (`input_error` when nothing was scanned) with a
`gaps` list. Nothing is fabricated to fill the canvas.

---
name: scientific-data-visualization
description: 科研数据可视化与分析流水线。读取 /input 的 case.json、task.md 与材料（CSV/TSV/SQLite 数据表及图片/PDF 等上下文材料），完成数据清洗（缺失、异常、重复、格式/单位、质量报告）、统计分析与图表选型，生成可投稿矢量图（PDF/SVG）与 300 dpi PNG 及独立图注，并按 output_contract 回填 result.json（含 case_id、status、sources、uncertainty、change_records）。适用于把真实科研数据表做成可核验图件的任务。
version: 1.0.0
---

# 科研数据可视化 Skill

## 1. 用途与适用条件

把一份真实科研数据表（CSV / TSV / SQLite）走完「读数据 → 确认口径 → 清洗 → 统计 → 图表选型 → 编码与标注 → 发表级导出 → 契约回填」的完整链条，交付：
- 清洗后的可用数据文件（CSV）；
- 字段级问题清单、清洗规则/变更日志、数据质量报告；
- 统计汇总与相关性矩阵；
- 图表选型建议（含推荐理由与不推荐理由）；
- 可投稿图件：PDF（矢量）+ SVG + 300 dpi PNG，及独立于正文可读的图注；
- `result.json`：回填 `case.json.output_contract` 的每一个字段 + `case_id`，附 status / sources（证据定位）/ uncertainty / change_records。

**触发条件**：任务要求对科研数据做清洗、统计、可视化、多步骤分析或数据库查询，且 `/input` 存在 `case.json` 与至少一份数据材料。

**不适用**：实验设计、统计方法创新、论文写作、图像后期美化；无结构化数据的纯图片/纯文本任务（此时降级为 partial）。

## 2. 调用方式

平台把本 Skill 安装到 `/skills/weekly-skill`，运行时输入在 `/input`（`case.json` + `task.md` + 材料）。加载本 Skill 后，Agent 按以下顺序执行：

1. 读 `/input/case.json`：记录 `case_id`、`output_contract`、`task_instruction` 与材料清单。
2. 读 `/input/task.md` 与数据字典/字段语义（若材料中含）。
3. 运行主脚本完成确定性流水线（默认命令即完整流程）：

```
python /skills/weekly-skill/scripts/main.py --input /input --work /app/work --output /app/output
```

  等价默认：`python scripts/main.py`（不传参数时用 `/input`、`/app/work`、`/app/output`）。
4. 主脚本会先写 `result.partial.json` 再增量 finalize；Agent 阅读 `/app/work` 与 `/app/output` 产物，核对数值与逐字引文后，可在 `/app/output/result.json` 上精修需要模型判断的字段（如结论、图注措辞），再运行 `check` 校验契约完整性。

### 命令

| 命令 | 作用 |
|-|-|
| `python main.py`（默认 run） | 完整流程：探测输入 → 清洗 → 统计 → 选型 → 出图 → 回填 result.json |
| `python main.py check` | 校验 result.json 契约键齐全、case_id/status/sources 存在 |

路径覆盖：环境变量 `INPUT_DIR` / `WORK_DIR` / `OUTPUT_DIR`，或参数 `--input` / `--work` / `--output`；缺省值为 `/input`、`/app/work`、`/app/output`。不依赖 CWD（以 `Path(__file__).resolve().parent` 定位脚本）。脚本拆分：`main.py`（编排）、`stats.py`（统计/数据工具）、`analysis.py`（分析层）、`figures.py`（matplotlib 出图）。

## 3. 输入输出

- 输入：`/input/case.json`、`/input/task.md`、材料文件（`materials/` 或 `/input` 下任意子目录）。
- 工作稿（/app/work，schema 见 §4）与最终交付（/app/output）：
  - `result.json`（必含）、`data_cleaned.csv`、`quality_report.json`、`issues.json`、`rules_log.json`、`analysis.json`、`chart_recommendation.json`、`figure_spec.json`、`figures/*.pdf|*.svg|*.png`、`figures/captions.json`、`figures/figure_manifest.json`。

## 4. 工作稿 schema（/app/work）

| 文件 | 内容 |
|-|-|
| `manifest.json` | 输入文件清单 + 类型判定（csv/json/sqlite/xlsx/docx/pdf/image/other） |
| `tables/<name>.json` | 每个解析出的原始表（含列名、行、类型推断），保留原始值 |
| `data_cleaned.csv` | 清洗后数据：类型归一、去重、缺失保留为空，异常仅标记不删除 |
| `issues.json` | 字段级问题：缺失/异常/重复/类型/单位，逐条带 source+locator+quote |
| `rules_log.json` | 清洗规则 + change_records（确定性，不含时间戳） |
| `quality_report.json` | 每列类型、非空数、唯一值、数值五数概括、均值/标准差、异常数 |
| `analysis.json` | 数值列统计 + 分类计数 + Pearson 相关矩阵 |
| `chart_recommendation.json` | 图表选型与理由 |
| `figure_spec.json` | 声明式图规格（类型/数据列/编码/选项/图注） |
| `result.partial.json` | 早期 partial，逐项替换为最终值 |

## 5. 证据规范（真实派生红线）

- 每个结论、条目、数值、页面都要能指回 `source` + `locator` + 逐字 `quote`；quote 必须能在材料原文中命中。
- 表格结论用「列名 + 行区间 + 原始值」作 locator；图件数值由 `figures.py` 从清洗数据重新计算并做一致性校验（spec 中声明的均值/标准差/相关系数与重算值比对，不一致即写入 degradations）。
- 不编造数据、软件状态、检索结果或评分；缺值用 `null` 或 `[]`，不得写 placeholder / "array" / "object" / 空契约键。
- 图上的每个视觉元素（坐标轴、刻度、单位、图例系列、误差线、显著性标记、色标范围）必须与源数据一一对应；误差线在图中与图注中写清是 SD / SEM / CI。

## 6. 清洗与统计口径

五类清洗（全部记录到 issues.json / rules_log.json）：
1. 缺失值：逐列计数，标记；分析用完整个案，不静默填补。
2. 异常值：数值列用分布判据（IQR：<Q1−1.5·IQR 或 >Q3+1.5·IQR 记异常，>3·IQR 记极端），只标记不删除。
3. 重复记录：整行完全相同才计重复，去重（保留首条）并记录。
4. 格式/单位/编码：自动检测编码（UTF-8/GBK/Latin-1 回退）、去 BOM、千分位与百分号、日期归一；单位不一致只标记不换算。
5. 质量报告：每个数字与结果表一致，量纲正确。

统计：数值列 n/mean/std/min/q1/median/q3/max/异常数；分类列频次；数值两两 Pearson r；显著性只在有依据时给出（如相关性 p 值可用标准库近似计算时给出，否则标 uncertainty）。

## 7. 图表选型与编码规则

决策表见 `references/chart_rules.md`；配色与排版见 `references/style_spec.json`。要点：
- 无序分类比较不用饼图；时间序列/有序序列用折线，不用并列柱；
- 基线不截断；对数轴只在正数且量级跨 2 个以上数量级时启用并显式标注；
- 类别 > 8 时换横向条/分面/颜色合并，不硬塞单图；
- 位置/长度优先，角度/面积避免夸大差异；误差线写明 SD/SEM/CI；
- 面板编号（a/b/c）、字号下限 6pt、单栏宽 3.5in、双栏 7in。

## 8. 降级表（异常处理）

所有异常捕获进 `errors`/`degradations`，退出码恒 0，不崩、不产生 0 字节 result.json。

| 情形 | status | 行为 |
|-|-|-|
| 正常完成 | `complete` | 全量交付 |
| 部分材料缺失/列缺失/类型坏/样本不足/类别过多/字体缺失 | `partial` + `gaps` | 交付已可核验部分，写明缺口 |
| 无法支撑任何结论 | `insufficient_evidence` | result.json 含空契约键（null/[]）+ sources 为实际能读到的材料 |
| 坏 JSON / 空输入 / 权限不足 | `input_error` | result.json 合法、契约键齐全（null/[]），errors 记录原因 |

## 9. 自检

- `python main.py check`：result.json 含 case_id；契约键与原 case.json.output_contract 逐键一致；status/sources/uncertainty/change_records 存在；sources 每项有 path+locator+quote 且 quote 命中材料原文；errors 无未捕获异常。
- 出图后检查：PDF 有 `%PDF-` 头与页对象；PNG 以 `\x89PNG\r\n\x1a\n` 开头；SVG 为 XML 且含 `<svg`；可编辑源（脚本/SVG/PDF）非截图。

## 10. 限制

- 不做统计分析创新，不做实验设计、论文写作与图像后期美化。
- 数据表仅支持 CSV/TSV/TXT/SQLite；JSON 数据表与 xlsx 本版不解析，会按「未发现可解析材料」降级为 insufficient_evidence（case.json 本身仍正常读取）。
- 中文/特殊符号：优先 DejaVu；列名含 CJK 且系统无 CJK 字体时降级并记录，不静默乱码。
- Pearson p 值用 Fisher-z 近似（n≥约 30 精确，小样本近似），图注与结果中已标注；显著性星号阈值 0.05/0.01/0.001。
- 依赖 `scientific-python`（numpy + matplotlib）出图；缺失时仍产出清洗/统计/质量报告并降级说明，不中断。

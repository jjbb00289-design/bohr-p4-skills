#!/usr/bin/env python3
import argparse
import csv
import json
import math
import re
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from stats import pearson, sig_stars, mean, sd, to_num, is_missing  

CJK_RE = re.compile(r"[\u4e00-\u9fff]")
PALETTE = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7",
           "#56B4E9", "#F0E442", "#000000"]


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    return ([], []) if not rows else (rows[0], rows[1:])


def col_idx(header, col):
    return header.index(col) if col in header else None


def fmt(x, nd=3):
    if x is None:
        return "NA"
    return f"{x:.{nd}g}" if isinstance(x, float) else str(x)


def check_field(fig, field, value):
    dv = fig.get("declared", {}).get(field)
    rv = None if value is None else (round(value, 9) if isinstance(value, float) else value)
    if dv is None or value is None:
        return {"figure": fig["id"], "field": field, "ok": True, "declared": dv, "recomputed": rv}
    try:
        ok = abs(float(dv) - float(value)) < 1e-6
    except (TypeError, ValueError):
        ok = str(dv) == str(value)
    return {"figure": fig["id"], "field": field, "ok": ok, "declared": dv, "recomputed": rv}


def setup_fonts(labels):
    import matplotlib
    matplotlib.rcParams["axes.unicode_minus"] = False
    if not any(CJK_RE.search(str(x)) for x in labels):
        return None
    import matplotlib.font_manager as fm
    names = {f.name for f in fm.fontManager.ttflist}
    for c in ("Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "WenQuanYi Zen Hei", "PingFang SC"):
        if c in names:
            matplotlib.rcParams["font.sans-serif"] = [c, "DejaVu Sans"]
            return c
    return None


def base_setup(style):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 8, "axes.labelsize": 8, "axes.titlesize": 9,
                         "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7,
                         "axes.linewidth": 0.6, "lines.linewidth": 1.0,
                         "figure.dpi": 100, "savefig.bbox": "tight", "savefig.pad_inches": 0.03})
    return plt


def group_by(body, ix, iy):
    groups = {}
    for r in body:
        if ix is None or iy is None:
            break
        k, v = r[ix], to_num(r[iy])
        if is_missing(k) or v is None:
            continue
        groups.setdefault(str(k), []).append(v)
    return {k: groups[k] for k in sorted(groups)}


def render(plt, fig, header, body, style, outdir):
    kind = fig["type"]
    wid = float(style.get("width_in", 3.5))
    f, ax = plt.subplots(figsize=(wid, wid * 0.95 if kind == "heatmap" else wid * 0.78))
    cons = []

    if kind == "histogram":
        ix = col_idx(header, fig["x"])
        vals = [to_num(r[ix]) for r in body if ix is not None and not is_missing(r[ix])]
        vals = [v for v in vals if v is not None]
        bins = max(6, int(math.ceil(math.log2(len(vals)) + 1))) if vals else 10
        ax.hist(vals, bins=bins, color=PALETTE[0], edgecolor="white", linewidth=0.4)
        m, s = (mean(vals), sd(vals)) if len(vals) > 1 else (mean(vals), 0.0)
        if vals:
            ax.axvline(m, color=PALETTE[1], linestyle="--", linewidth=0.9)
            ax.axvline(m - s, color=PALETTE[1], linestyle=":", linewidth=0.7)
            ax.axvline(m + s, color=PALETTE[1], linestyle=":", linewidth=0.7)
        ax.set_xlabel(fig["x"])
        ax.set_ylabel("Frequency")
        caption = (f"{fig['panel']}. Histogram of {fig['x']} (n={len(vals)}). "
                   f"Mean={fmt(m)} (dashed), ±1 SD={fmt(s)} (dotted).")
        cons = [check_field(fig, "mean", m), check_field(fig, "sd", s), check_field(fig, "n", len(vals))]

    elif kind == "bar":
        groups = group_by(body, col_idx(header, fig["x"]), col_idx(header, fig["y"]))
        order, data = list(groups), list(groups.values())
        ns = ", ".join(f"{g}:n={len(groups[g])}" for g in order)
        means, sds = [mean(g) for g in data], [sd(g) for g in data]
        ax.bar(range(len(order)), means, yerr=sds, capsize=2.5, color=PALETTE[0],
               edgecolor="black", linewidth=0.4)
        ax.set_xticks(range(len(order)))
        ax.set_xticklabels(order, rotation=45, ha="right")
        ax.set_ylabel(f"{fig['y']} (mean ± SD)")
        ax.set_xlabel(fig["x"])
        caption = (f"{fig['panel']}. Bar plot of {fig['y']} by {fig['x']} "
                   f"(mean ± SD; error bars = SD). {ns}.")
        cons.append(check_field(fig, "n", sum(len(g) for g in data)))

    elif kind == "scatter":
        ix, iy = col_idx(header, fig["x"]), col_idx(header, fig["y"])
        pts = [(to_num(r[ix]), to_num(r[iy])) for r in body
               if ix is not None and iy is not None and to_num(r[ix]) is not None and to_num(r[iy]) is not None]
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        ax.scatter(xs, ys, s=12, color=PALETTE[0], alpha=0.75, edgecolors="none")
        ax.set_xlabel(fig["x"])
        ax.set_ylabel(fig["y"])
        r, p, n = pearson(xs, ys)
        ann = f"r={fmt(r)}, p={fmt(p, 2)}, n={n}" + (f" {sig_stars(p)}" if p is not None else "")
        ax.text(0.03, 0.97, ann, transform=ax.transAxes, va="top", ha="left", fontsize=7,
                bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="0.6", lw=0.4))
        caption = (f"{fig['panel']}. Scatter of {fig['y']} vs {fig['x']}. "
                   f"Pearson {ann} (two-sided, Fisher-z p).")
        cons = [check_field(fig, "r", r), check_field(fig, "p", p), check_field(fig, "n", n)]

    elif kind == "heatmap":
        import numpy as np
        cols = fig.get("columns", [])
        idxs = [i for i in (col_idx(header, c) for c in cols) if i is not None]
        cols = [header[i] for i in idxs]
        mat = np.full((len(cols), len(cols)), np.nan)
        for a in range(len(cols)):
            for b in range(len(cols)):
                pairs = [(to_num(r[idxs[a]]), to_num(r[idxs[b]])) for r in body
                         if to_num(r[idxs[a]]) is not None and to_num(r[idxs[b]]) is not None]
                if len(pairs) >= 3:
                    mat[a, b] = pearson([p[0] for p in pairs], [p[1] for p in pairs])[0]
        im = ax.imshow(mat, cmap="RdBu_r", vmin=-1, vmax=1, aspect="auto")
        ax.set_xticks(range(len(cols)))
        ax.set_yticks(range(len(cols)))
        ax.set_xticklabels(cols, rotation=45, ha="right", fontsize=6)
        ax.set_yticklabels(cols, fontsize=6)
        for a in range(len(cols)):
            for b in range(len(cols)):
                if not np.isnan(mat[a, b]):
                    ax.text(b, a, f"{mat[a, b]:.2f}", ha="center", va="center",
                            fontsize=5.5, color="black")
        cb = f.colorbar(im, ax=ax, shrink=0.85)
        cb.ax.tick_params(labelsize=6)
        caption = (f"{fig['panel']}. Pearson correlation matrix of {len(cols)} numeric "
                   f"variables (n={len(body)}, pairwise complete; RdBu_r).")
        cons = [check_field(fig, "n", len(body))]

    else:
        ax.text(0.5, 0.5, f"unsupported: {kind}", ha="center", va="center", transform=ax.transAxes)
        caption = f"{fig['panel']}. Unsupported type {kind}."

    ax.grid(True, which="major", linewidth=0.3, alpha=0.35)
    return f, ax, caption, cons


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--spec", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    spec = json.loads(Path(args.spec).read_text(encoding="utf-8"))
    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)
    try:
        header, body = read_csv(spec["data_file"])
    except Exception:  
        header, body = [], []
    if not header:
        (outdir / "figure_manifest.json").write_text(
            json.dumps({"figures": [], "degradations": ["no data"]}, ensure_ascii=False), encoding="utf-8")
        (outdir / "captions.json").write_text("{}", encoding="utf-8")
        (outdir / "consistency.json").write_text("[]", encoding="utf-8")
        print("no data")
        return
    degradations = []
    if CJK_RE.search("".join(header)) and not setup_fonts(header):
        degradations.append("中文列名且无 CJK 字体，可能显示方框")
    plt = base_setup(spec.get("style", {}))
    style = spec.get("style", {})
    manifest = {"figures": [], "style": style, "degradations": degradations}
    captions, allcons = {}, []
    for fig in spec["figures"]:
        try:
            f, ax, caption, cons = render(plt, fig, header, body, style, outdir)
            fid = fig["id"]
            f.savefig(outdir / f"{fid}.pdf")
            f.savefig(outdir / f"{fid}.svg")
            f.savefig(outdir / f"{fid}.png", dpi=int(style.get("dpi", 300)))
            plt.close(f)
            manifest["figures"].append({"id": fid, "panel": fig.get("panel"), "type": fig["type"],
                                        "pdf": f"{fid}.pdf", "svg": f"{fid}.svg",
                                        "png": f"{fid}.png", "caption": caption})
            captions[fid] = caption
            allcons.extend(cons)
        except Exception as e:  
            manifest["figures"].append({"id": fig["id"], "type": fig["type"], "error": str(e)})
            degradations.append(f"{fig['id']}: {e}")
    manifest["degradations"] = degradations
    (outdir / "figure_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    (outdir / "captions.json").write_text(json.dumps(captions, ensure_ascii=False, indent=2), encoding="utf-8")
    (outdir / "consistency.json").write_text(json.dumps(allcons, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"rendered {len(manifest['figures'])} figures")


if __name__ == "__main__":
    main()

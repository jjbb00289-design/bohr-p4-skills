#!/usr/bin/env python3
import math
import re

MISSING = {"", "nan", "na", "n/a", "null", "none", "?", "-", "--", "nd", "n.d."}
NUM_STRIP = re.compile(r"[,\s%$€£¥¥]")
DATE_RE = re.compile(r"^\d{4}[-/.]\d{1,2}[-/.]\d{1,2}([ T]\d{1,2}:\d{2}(:\d{2})?)?$")


def quartiles(xs):
    s = sorted(xs)
    n = len(s)

    def q(p):
        if n == 0:
            return None
        idx = (n - 1) * p
        lo = int(math.floor(idx))
        hi = int(math.ceil(idx))
        return s[lo] if lo == hi else s[lo] * (hi - idx) + s[hi] * (idx - lo)
    return q(0.25), q(0.5), q(0.75)


def mean(xs):
    return sum(xs) / len(xs) if xs else None


def sd(xs):
    if len(xs) < 2:
        return 0.0
    m = mean(xs)
    return (sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) ** 0.5


def corr_p(r, n):
    if r is None or n is None or n < 4:
        return None
    if abs(r) >= 1.0:
        return 0.0
    z = math.atanh(max(-0.9999, min(0.9999, r))) * math.sqrt(n - 3)
    return math.erfc(abs(z) / math.sqrt(2.0))


def pearson(xs, ys):
    n = len(xs)
    if n < 3:
        return None, None, None
    mx, my = mean(xs), mean(ys)
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    sxx = sum((x - mx) ** 2 for x in xs)
    syy = sum((y - my) ** 2 for y in ys)
    if sxx <= 0 or syy <= 0:
        return 0.0, None, None
    r = max(-1.0, min(1.0, sxy / math.sqrt(sxx * syy)))
    return r, corr_p(r, n), n


def sig_stars(p):
    if p is None:
        return ""
    if p < 0.001:
        return "***"
    if p < 0.01:
        return "**"
    if p < 0.05:
        return "*"
    return "n.s."


def to_num(s):
    t = NUM_STRIP.sub("", str(s).strip())
    if not t:
        return None
    try:
        return int(t)
    except ValueError:
        try:
            return float(t)
        except ValueError:
            return None


def is_missing(s):
    return s is None or (isinstance(s, str) and s.strip().lower() in MISSING)


def ctype(vals):
    non = [v for v in vals if not is_missing(v)]
    if not non:
        return "empty"
    nums = [to_num(v) for v in non]
    if all(n is not None for n in nums):
        return "int" if all(isinstance(n, int) for n in nums) else "float"
    if all(DATE_RE.match(str(v).strip()) for v in non):
        return "datetime"
    return "string"

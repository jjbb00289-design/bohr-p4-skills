#!/usr/bin/env python3
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from stats import quartiles, mean, sd, pearson, sig_stars, to_num, is_missing  

ID_NAME_RE = re.compile(r"(^|[_\s.])(id|index|idx|sample|samp|no|num|row|code|编号|序号)([_\s.]|$)", re.I)


def roles(cleaned):
    header, types, rows = cleaned["header"], cleaned["column_types"], cleaned["rows"]
    n = len(rows)
    rl = {}
    for i, name in enumerate(header):
        t = types[i]
        uniq = len({r[i] for r in rows if not is_missing(r[i])})
        if uniq == n and n > 1 and ID_NAME_RE.search(name):
            rl[name] = "id"
        elif t == "string":
            rl[name] = "categorical"
        elif t == "int" and 2 <= uniq <= 8 and uniq / max(n, 1) <= 0.2:
            rl[name] = "categorical"
        elif t in ("int", "float"):
            rl[name] = "numeric"
        elif t == "datetime":
            rl[name] = "datetime"
        else:
            rl[name] = "other"
    return rl


def report(cleaned, rl):
    header, rows, types = cleaned["header"], cleaned["rows"], cleaned["column_types"]
    n = len(rows)
    numeric = [i for i, h in enumerate(header) if rl.get(h) == "numeric"]
    cols = {}
    for i, h in enumerate(header):
        vals = [r[i] for r in rows]
        miss = sum(is_missing(v) for v in vals)
        info = {"type": types[i], "n": n, "missing": miss, "non_null": n - miss}
        if types[i] in ("int", "float"):
            nums = [to_num(v) for v in vals if not is_missing(v)]
            if nums:
                q1, med, q3 = quartiles(nums)
                info.update(min=min(nums), q1=q1, median=med, q3=q3, max=max(nums),
                            mean=mean(nums), sd=sd(nums))
        else:
            cnt = {}
            for v in vals:
                if not is_missing(v):
                    cnt[str(v)] = cnt.get(str(v), 0) + 1
            info["categories"] = dict(sorted(cnt.items()))
            info["unique"] = len(cnt)
        cols[h] = info
    corr = []
    for a in range(len(numeric)):
        for b in range(a + 1, len(numeric)):
            pairs = [(to_num(r[numeric[a]]), to_num(r[numeric[b]])) for r in rows
                     if to_num(r[numeric[a]]) is not None and to_num(r[numeric[b]]) is not None]
            if len(pairs) >= 3:
                r, p, nn = pearson([x for x, _ in pairs], [y for _, y in pairs])
                corr.append({"x": header[numeric[a]], "y": header[numeric[b]],
                             "r": r, "p": p, "n": nn, "sig": sig_stars(p)})
    corr.sort(key=lambda c: abs(c["r"] or 0), reverse=True)
    return {"source": cleaned["source"], "n_rows": n, "n_columns": len(header),
            "numeric": [header[i] for i in numeric], "columns": cols, "correlations": corr}


def purposes(t):
    t = (t or "").lower()
    ps = set()
    if any(k in t for k in ("分布", "distribution", "histogram")):
        ps.add("distribution")
    if any(k in t for k in ("相关", "correl", "scatter", "关联")):
        ps.add("correlation")
    if any(k in t for k in ("比较", "compar", "对比", "差异", "group", "组")):
        ps.add("comparison")
    return ps or {"auto"}


def select(cleaned, rep, rl, ps):
    header = cleaned["header"]
    numeric = [i for i, h in enumerate(header) if rl.get(h) == "numeric"]
    categorical = [i for i, h in enumerate(header) if rl.get(h) == "categorical"]
    corr = rep.get("correlations", [])
    auto = "auto" in ps
    recs = []
    if ("comparison" in ps or auto) and categorical and numeric:
        c = categorical[0]
        recs.append({"type": "bar", "x": header[c], "y": header[numeric[0]], "error_bar": "SD",
                     "reason": "分组均值±SD 与离散度", "rejected": "饼图不用于无序分类比较；纯均值柱掩盖离散度"})
    if ("correlation" in ps or auto) and len(numeric) >= 2:
        if corr:
            recs.append({"type": "scatter", "x": corr[0]["x"], "y": corr[0]["y"],
                         "reason": "两数值变量关系并标注 Pearson r"})
        if len(numeric) >= 3:
            top = sorted(numeric, key=lambda i: -abs(rep["columns"][header[i]].get("sd", 0)))[:12]
            recs.append({"type": "heatmap", "columns": [header[i] for i in top],
                         "reason": "数值变量 Pearson r 相关矩阵"})
    if "distribution" in ps and numeric:
        recs.append({"type": "histogram", "x": header[numeric[0]], "reason": "连续变量分布形态"})
    if not recs and numeric:
        recs.append({"type": "histogram", "x": header[numeric[0]], "reason": "仅数值变量可用"})
    return recs[:4]


def spec(cleaned, rep, recs, wd):
    cols = rep["columns"]
    figs = []
    for k, rec in enumerate(recs):
        t = rec["type"]
        x, y = rec.get("x", ""), rec.get("y", "")
        title = {"histogram": f"Distribution of {x}", "bar": f"Mean {y} by {x}",
                 "scatter": f"{y} vs {x}", "heatmap": "Correlation matrix"}.get(t, t)
        f = {"id": f"fig{k+1}", "panel": chr(97 + k), "type": t, "title": title, "options": {}}
        if t == "histogram":
            f["x"] = x
            s = cols.get(x, {})
            f["declared"] = {"n": s.get("non_null"), "mean": s.get("mean"), "sd": s.get("sd")}
        elif t == "bar":
            f["x"], f["y"] = x, y
            f["options"]["error_bar"] = rec.get("error_bar", "none")
            f["declared"] = {"n": cols.get(y, {}).get("non_null")}
        elif t == "scatter":
            f["x"], f["y"] = x, y
            c = next((c for c in rep["correlations"] if {c["x"], c["y"]} == {x, y}), None)
            f["declared"] = {"r": c["r"] if c else None, "p": c["p"] if c else None,
                             "n": c["n"] if c else None}
        elif t == "heatmap":
            f["columns"] = rec["columns"]
            f["declared"] = {"n": len(cleaned["rows"])}
        figs.append(f)
    return {"style": {"palette": "colorblind", "width_in": 3.5, "dpi": 300, "grayscale_check": True},
            "data_file": str(wd / "data_cleaned.csv"), "figures": figs}


def summary(cleaned, rep, recs):
    parts = [f"数据 {rep['n_rows']} 行 × {len(cleaned['header'])} 列，数值列 {rep['numeric']}。"]
    if rep["correlations"]:
        c = rep["correlations"][0]
        parts.append(f"最强相关为 {c['x']} 与 {c['y']}（r={round(c['r'], 3)}, n={c['n']}, "
                     + (f"p={c['p']:.3g}）。" if c['p'] is not None else "p 未计算）。"))
    if recs:
        parts.append("推荐图件：" + "；".join(
            f"{r['type']}({r.get('x', '')}{'×' + r['y'] if r.get('y') else ''})" for r in recs) + "。")
    return "".join(parts)

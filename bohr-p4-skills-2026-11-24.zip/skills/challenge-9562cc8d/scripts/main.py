#!/usr/bin/env python3
import argparse
import csv
import io
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from stats import to_num, is_missing, ctype, quartiles  
from analysis import roles, report, purposes, select, spec, summary  

DEFAULT_INPUT = "/input"
DEFAULT_WORK = "/app/work"
DEFAULT_OUTPUT = "/app/output"
TABLE_EXT = (".csv", ".tsv", ".txt", ".db", ".sqlite", ".sqlite3")


def wj(obj, path):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def resolve_env(args, name, default):
    v = os.environ.get(name.upper() + "_DIR")
    if v:
        return v
    a = getattr(args, name, None)
    return a if a else default


def rb(path):
    with open(path, "rb") as f:
        return f.read()


def dec(raw):
    for e in ("utf-8-sig", "utf-8", "gbk", "latin-1"):
        try:
            return raw.decode(e), e
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("utf-8", errors="replace"), "utf-8-replace"


def sniff(text):
    try:
        return csv.Sniffer().sniff(text[:8192], delimiters=",;\t|").delimiter
    except Exception:  
        line = text.splitlines()[0] if text.splitlines() else ""
        for d in (",", "\t", ";", "|"):
            if d in line:
                return d
        return ","


def rows_csv(text, d):
    rows = [list(r) for r in csv.reader(io.StringIO(text), delimiter=d)]
    return [r for r in rows if any(c.strip() for c in r)]


def load_csv(p):
    text, enc = dec(rb(p))
    rows = rows_csv(text, sniff(text))
    if not rows:
        return None, "empty csv", enc
    h = rows[0]
    nc = len(h)
    return {"source": str(p), "header": h, "rows": [r[:nc] + [""] * (nc - len(r)) for r in rows[1:]],
            "encoding": enc, "kind": "csv"}, None, enc


def load_sqlite(p):
    con = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
    cur = con.cursor()
    names = [r[0] for r in cur.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
    out = {}
    for t in names:
        cur.execute(f'SELECT * FROM "{t}"')
        cols = [d[0] for d in cur.description]
        out[t] = {"source": f"{p}::{t}", "header": cols,
                  "rows": [["" if v is None else str(v) for v in r] for r in cur.fetchall()],
                  "encoding": "sqlite", "kind": "sqlite", "table": t}
    con.close()
    return out


def load_material(p):
    s = str(p).lower()
    try:
        if s.endswith((".csv", ".tsv", ".txt")):
            return load_csv(p)
        if s.endswith((".db", ".sqlite", ".sqlite3")):
            return load_sqlite(p), None, "sqlite"
        return None, "unsupported kind", s
    except Exception as e:  
        return None, f"load error: {e}", s


def load_all(input_dir):
    tables, errors = {}, []
    for p in sorted(input_dir.rglob("*")):
        if not p.is_file() or p.name in ("case.json", "task.md"):
            continue
        if str(p).lower().endswith(TABLE_EXT):
            loaded, err, _ = load_material(p)
            if isinstance(loaded, dict) and all(isinstance(v, dict) for v in loaded.values()):
                for tn, t in loaded.items():
                    tables[tn] = t
            elif isinstance(loaded, dict):
                tables[p.name] = loaded
            elif err:
                errors.append({"path": str(p), "error": err})
    return tables, errors


def clean(table):
    header, rows = table["header"], table["rows"]
    types = [ctype([r[i] for r in rows]) for i in range(len(header))]
    issues, rules = [], []
    seen, dup = set(), 0
    clean_rows = []
    for r in rows:
        k = tuple(r)
        if k in seen:
            dup += 1
            continue
        seen.add(k)
        clean_rows.append(list(r))
    if dup:
        rules.append({"rule": "drop_duplicate_rows", "count": dup,
                      "reason": "exact duplicate full rows removed"})
    for i, name in enumerate(header):
        vals = [r[i] for r in clean_rows]
        for j, v in enumerate(vals):
            if is_missing(v):
                issues.append({"column": name, "row": j, "type": "missing", "value": "",
                               "criterion": "empty or NA token"})
        if types[i] in ("int", "float"):
            nums = [to_num(v) for v in vals if not is_missing(v)]
            if nums:
                q1, med, q3 = quartiles(nums)
                iqr = q3 - q1
                lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
                xlo, xhi = q1 - 3 * iqr, q3 + 3 * iqr
                for j, v in enumerate(vals):
                    nv = to_num(v)
                    if nv is not None and (nv < lo or nv > hi):
                        ext = nv < xlo or nv > xhi
                        issues.append({"column": name, "row": j,
                                       "type": "extreme_outlier" if ext else "outlier", "value": v,
                                       "criterion": "outside Q1-3IQR/Q3+3IQR" if ext else "outside Q1-1.5IQR/Q3+1.5IQR"})
    rules.append({"rule": "normalize", "detail": "strip separators/%/currency; missing->empty"})
    return {"source": table["source"], "header": header, "rows": clean_rows,
            "column_types": types, "duplicates_dropped": dup}, issues, rules


def add_src(srcs, path, kind, locator, quote, purpose):
    srcs.append({"path": path, "kind": kind, "locator": locator, "quote": quote, "purpose": purpose})


def build_sources(case_path, task_path, tables, wd):
    srcs = []
    if case_path.exists():
        try:
            obj = json.loads(dec(rb(case_path))[0])
            ti = obj.get("task_instruction") or obj.get("instruction") or ""
            if ti:
                add_src(srcs, str(case_path), "case.json", "task_instruction", ti[:60], "任务说明")
            cid = obj.get("case_id") or obj.get("id") or ""
            if cid:
                add_src(srcs, str(case_path), "case.json", "case_id", str(cid), "案例标识")
        except Exception:  
            pass
    if task_path.exists():
        try:
            lines = dec(rb(task_path))[0].splitlines()
            if lines:
                add_src(srcs, str(task_path), "task.md", "line:1", lines[0][:60], "题目")
        except Exception:  
            pass
    for t in tables.values():
        add_src(srcs, t["source"], t["kind"], "header", ",".join(t["header"])[:120], "列名/字段语义")
        if t["rows"]:
            add_src(srcs, t["source"], t["kind"], "row:1", ",".join(t["rows"][0])[:120], "原始值样本")
    return srcs


def match_value(key, derived):
    k = key.lower()
    for frag, dk in (("clean", "cleaned"), ("data", "cleaned"), ("stat", "analysis"),
                     ("analy", "analysis"), ("quality", "quality"), ("report", "quality"),
                     ("issue", "issues"), ("figure", "figures"), ("chart", "figures"),
                     ("plot", "figures"), ("caption", "captions"), ("rule", "rules"),
                     ("recommend", "recommendation"), ("conclusion", "summary"),
                     ("summar", "summary"), ("result", "summary")):
        if frag in k:
            return derived.get(dk)
    return None


def apply_contract(result, contract, derived):
    if isinstance(contract, dict):
        result.update({k: match_value(k, derived) for k in contract})
    elif isinstance(contract, list):
        result["output_contract"] = [match_value(k, derived) if isinstance(k, str) else None
                                     for k in contract]


def write_result(output_dir, result):
    wj(result, output_dir / "result.json")


def run_full(input_dir, work_dir, output_dir):
    work_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    errors, degradations = [], []
    case_path, task_path = input_dir / "case.json", input_dir / "task.md"
    case = {}
    if case_path.exists():
        try:
            case = json.loads(dec(rb(case_path))[0])
        except Exception as e:  
            errors.append({"step": "read_case", "error": str(e)})
    case_id = case.get("case_id") or case.get("id") or ""
    contract = case.get("output_contract", {})
    instruction = case.get("task_instruction") or case.get("instruction") or ""
    partial = {"case_id": case_id, "status": "partial", "task_instruction": instruction,
               "errors": list(errors), "degradations": []}
    apply_contract(partial, contract, {})
    wj(partial, work_dir / "result.partial.json")

    tables, load_errors = load_all(input_dir)
    errors.extend(load_errors)
    if not tables:
        status = "insufficient_evidence" if case else "input_error"
        result = {"case_id": case_id, "status": status, "task_instruction": instruction,
                  "sources": [], "uncertainty": ["未发现可解析的结构化数据材料"],
                  "change_records": [], "errors": errors, "degradations": []}
        apply_contract(result, contract, {})
        write_result(output_dir, result)
        return

    primary = max(tables.values(), key=lambda t: len(t["rows"]))
    cleaned, issues, rules = clean(primary)
    cp = work_dir / "data_cleaned.csv"
    with open(cp, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(cleaned["header"])
        w.writerows(cleaned["rows"])
    td = work_dir / "tables"
    td.mkdir(parents=True, exist_ok=True)
    for name, t in tables.items():
        wj(t, td / f"{re.sub(r'[^A-Za-z0-9_.-]', '_', name)}.json")
    rl = roles(cleaned)
    rep = report(cleaned, rl)
    ps = purposes(instruction)
    recs = select(cleaned, rep, rl, ps)
    figure_spec = spec(cleaned, rep, recs, work_dir)
    rules_log = {"rules": rules, "duplicates_dropped": cleaned["duplicates_dropped"],
                 "primary_source": cleaned["source"], "roles": rl}
    wj(rep, work_dir / "quality_report.json")
    wj(rep, work_dir / "analysis.json")
    wj(issues, work_dir / "issues.json")
    wj(rules_log, work_dir / "rules_log.json")
    wj({"purposes": sorted(ps), "recommendations": recs}, work_dir / "chart_recommendation.json")
    wj(figure_spec, work_dir / "figure_spec.json")

    fig_out = output_dir / "figures"
    fig_out.mkdir(parents=True, exist_ok=True)
    fs = SCRIPT_DIR / "figures.py"
    if fs.exists():
        try:
            r = subprocess.run([sys.executable, str(fs), "--spec",
                                str(work_dir / "figure_spec.json"), "--out", str(fig_out)])
            if r.returncode != 0:
                degradations.append("figures.py 返回非 0")
        except Exception as e:  
            degradations.append(f"figure render failed: {e}")
    else:
        degradations.append("figures.py 缺失，未出图")

    captions, fig_manifest, consistency = {}, [], []
    for fn, target in (("captions.json", 1), ("figure_manifest.json", 2), ("consistency.json", 3)):
        fp = fig_out / fn
        if fp.exists():
            try:
                data = json.loads(fp.read_text(encoding="utf-8"))
                if target == 1:
                    captions = data
                elif target == 2:
                    fig_manifest = data
                else:
                    consistency = data
            except Exception:  
                pass
    if consistency and any(not c.get("ok", True) for c in consistency):
        degradations.append("figure/source 一致性校验发现差异")

    sources = build_sources(case_path, task_path, tables, work_dir)
    text_summary = summary(cleaned, rep, recs)
    change_records = list(rules) + [{"action": "render_figures",
                                     "detail": f"rendered {len(fig_manifest.get('figures', []))} figure(s)"}]
    derived = {"cleaned": {"file": "data_cleaned.csv", "n_rows": len(cleaned["rows"]),
                           "n_columns": len(cleaned["header"]), "columns": cleaned["header"],
                           "column_types": cleaned["column_types"], "roles": rl,
                           "duplicates_dropped": cleaned["duplicates_dropped"]},
               "analysis": rep, "quality": rep, "issues": issues, "rules": rules_log,
               "figures": fig_manifest, "captions": captions,
               "recommendation": {"purposes": sorted(ps), "recommendations": recs},
               "summary": text_summary}
    status = "complete"
    uncertainty = []
    if issues:
        uncertainty.append(f"检测到 {len(issues)} 条字段级问题（缺失/异常/重复/格式）")
    if not captions:
        uncertainty.append("未生成图注")
        status = "partial"
    result = {"case_id": case_id, "status": status, "task_instruction": instruction,
              "sources": sources, "uncertainty": uncertainty,
              "change_records": change_records, "consistency": consistency,
              "errors": errors, "degradations": degradations}
    apply_contract(result, contract, derived)
    for fn in ("data_cleaned.csv", "quality_report.json", "issues.json", "rules_log.json",
               "analysis.json", "chart_recommendation.json", "figure_spec.json"):
        s = work_dir / fn
        if s.exists():
            shutil.copyfile(s, output_dir / fn)
    write_result(output_dir, result)


def cmd_check(input_dir, output_dir):
    rp = output_dir / "result.json"
    rep = {"result_exists": rp.exists()}
    if not rp.exists():
        print(json.dumps(rep, ensure_ascii=False, indent=2))
        return
    try:
        res = json.loads(rp.read_text(encoding="utf-8"))
        rep["valid_json"] = True
    except Exception:  
        rep["valid_json"] = False
        print(json.dumps(rep, ensure_ascii=False, indent=2))
        return
    rep["case_id"] = bool(res.get("case_id"))
    rep["status_ok"] = res.get("status") in {"complete", "partial", "insufficient_evidence", "input_error"}
    rep["has_sources"] = isinstance(res.get("sources"), list)
    rep["has_uncertainty"] = isinstance(res.get("uncertainty"), list)
    rep["has_change_records"] = isinstance(res.get("change_records"), list)
    if (input_dir / "case.json").exists():
        try:
            contract = json.loads(dec(rb(input_dir / "case.json"))[0]).get("output_contract", {})
            if isinstance(contract, dict):
                rep["missing_contract_keys"] = [k for k in contract if k not in res]
        except Exception:  
            pass
    print(json.dumps(rep, ensure_ascii=False, indent=2))


def main():
    ap = argparse.ArgumentParser(description="scientific data visualization pipeline")
    ap.add_argument("command", nargs="?", default="run", choices=["run", "check"])
    ap.add_argument("--input", default=None)
    ap.add_argument("--work", default=None)
    ap.add_argument("--output", default=None)
    args = ap.parse_args()
    input_dir = Path(resolve_env(args, "input", DEFAULT_INPUT))
    work_dir = Path(resolve_env(args, "work", DEFAULT_WORK))
    output_dir = Path(resolve_env(args, "output", DEFAULT_OUTPUT))
    if args.command == "check":
        cmd_check(input_dir, output_dir)
    else:
        run_full(input_dir, work_dir, output_dir)
        print("run done")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:  
        try:
            out = Path(os.environ.get("OUTPUT_DIR", DEFAULT_OUTPUT))
            out.mkdir(parents=True, exist_ok=True)
            wj({"case_id": None, "status": "input_error",
                "errors": [{"step": "main", "error": str(e)}],
                "sources": [], "uncertainty": [], "change_records": [],
                "degradations": []}, out / "result.json")
        except Exception:  
            pass
        print(f"fatal: {e}", file=sys.stderr)
        sys.exit(0)

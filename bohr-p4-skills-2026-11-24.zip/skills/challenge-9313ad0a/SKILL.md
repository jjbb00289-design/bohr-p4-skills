---
name: research-mindmap-builder
description: One command turns research material into an evidence-bound hierarchical mind map (root/branch/leaf plus typed relations). Every node and relation carries source, locator and a verbatim quote; outputs editable JSON, Markdown with Mermaid, an indented outline and real SVG/PNG previews. Handles empty, malformed and missing-material inputs honestly.
version: 7.0
---

# 思维导图生成器（层级 + 关系 + 证据）

一条命令自动从 `/input` 派生层级化思维导图，不需要准备 `draft.json`，也不要预写答案：

```bash
python3 scripts/main.py
```

入口脚本自动读取 `/input`（也支持 `--input/--work/--output` 与
`INPUT_DIR/WORK_DIR/OUTPUT_DIR` 环境变量），扫描 PDF/文本/DOCX/PPTX，从材料的小节标题（或无语义标题时按概念/方法/证据/结论/局限归类）生成 **根 / 枝 / 叶**，再按句子中的因果、依赖、对比、时间、引用、支持、冲突等提示词生成 **关系**。

## 产出（`/app/output`）

- `mindmap.json`：`{root, nodes[], relations[]}` 完整可编辑结构。每个节点含 `id/type/label/source/locator/page/quote/evidence`；每条关系含 `from/type/label/to/source/locator/quote`。
- `mindmap.md` / `deliverable.md`：可读 Markdown，含两段 Mermaid（层级 `mindmap` 与关系 `flowchart LR`）、节点表、关系表、覆盖与缺口。
- `outline.txt`：带 `[locator]` 的缩进大纲，便于快速审阅。
- `preview.svg` / `preview.png`：真实可查看的布局预览；PNG 在 matplotlib 可用时生成，否则保留 SVG。
- `content_map.json`：节点与关系全部落为证据条目（quote + source + locator）。
- `result.json`、`compliance_checks.json`、`self_check.json`、`run.log`、`edit_record.json`。

## 规则

1. 节点名是材料中的连续原文片段；节点 `quote` 是更长的一整句原文，逐字校验。
2. 每个节点、每条关系都带 `source + locator + quote`，不新增材料外的事实或连接。
3. 分支无对应句子时不创建空节点；层级不足时如实写入 `gaps`。
4. 无占位文本；材料可解析、quote 命中率 ≥0.95 时 `status=ok`。

## 三态与异常

| 输入 | 状态 | 行为 |
|---|---|---|
| 正常材料 | `ok` | 完整导图 + 预览 + 全部证据条目 |
| 坏 JSON / 无 case.json | `partial` | 退出码 0，`gaps` 说明无法读取任务元数据 |
| 有 case.json 但无材料 / 材料不可解析 | `partial` | 仅根节点，`gaps` 说明缺材料，不臆造 |

任何异常都写 `result.json` 并退出码 0，评审可复核失败原因。

## 自检

```bash
python3 scripts/main.py --help
python3 scripts/main.py --input <case_dir> --work <work_dir> --output <out_dir>
```

检查 `result.json` 的 `status`、`coverage.quote_hit_rate`、`coverage.branches/leaves/relations`，
以及 `preview.svg/png` 是否生成。

## 适用与限制

- 适用于 born-digital PDF 与文本类科研材料；扫描版 PDF 无文本层时只能给出 `partial`（不 OCR、不猜测）。
- 关系由材料句内的确定性提示词触发，方向为“枝—叶”的支撑/结果/方法/局限等角色，逐字 quote 支撑，不做模型语义推理。
- 代码为纯标准库（预览 PNG 惰性依赖 matplotlib，缺失时降级为 SVG），无网络、无随机，重复运行结果一致。

"""Deterministic, evidence-bound mind-map builder (root / branch / leaf + relations).

Every node and every relation carries `source` + `locator` + `quote` where the
quote is a verbatim contiguous span of the material. The hierarchy is derived out
of the material itself (section headings, or semantic facets when a text has
no explicit headings), never from a prepared draft. Relations are grounded in a
source sentence: a `contains` edge is the tree structure, and typed edges
(support / result / method / cause / contrast / sequence / example / conflict /
dependency / attribution / question) are attached to the sentence that carries
the corresponding rhetorical cue.

Stdlib only for the graph logic; matplotlib is imported lazily so a missing
raster stack degrades to the SVG preview instead of failing the run.
"""
import re
from collections import OrderedDict

# ------------------------------------------------------------------ text helpers
def squeeze(s):
    return re.sub(r"\s+", " ", str(s or "")).strip()


def _cjk(s):
    return sum(1 for c in s if "\u4e00" <= c <= "\u9fff")


def split_sentences(block):
    block = squeeze(block)
    parts = re.split(r"(?<=[\u3002\uff01\uff1f])\s*|(?<=[.!?])\s+(?=[A-Z0-9\u4e00-\u9fff])", block)
    return [p.strip() for p in parts if p.strip()]


def good(s):
    if _cjk(s) >= 16:
        return True
    toks = [t for t in re.split(r"\s+", s) if re.search(r"[A-Za-z]", t)]
    if len(toks) < 5:
        return False
    alpha = sum(1 for c in s if c.isalpha() or "\u4e00" <= c <= "\u9fff")
    if alpha / float(max(1, len(s))) < 0.5:
        return False
    raw = s.split()
    if raw and sum(1 for t in raw if len(t) == 1) / float(len(raw)) > 0.2:
        return False
    return True


def chunk_paragraphs(text, size=1200):
    out, buf = [], []
    for ln in text.splitlines():
        if not ln.strip():
            if buf:
                out.append(" ".join(buf))
                buf = []
            out.append("")
            continue
        buf.append(ln.strip())
        if len(" ".join(buf)) > size:
            out.append(" ".join(buf))
            buf = []
    if buf:
        out.append(" ".join(buf))
    return [x for x in out if x.strip()]


# ------------------------------------------------------------------ headings
KNOWN_HEAD = re.compile(
    r"^(abstract|introduction|related work|background|motivation|problem statement|"
    r"method(?:s|ology)?|materials?(?: and methods)?|approach|proposed method|model|"
    r"framework|experiments?(?: and results)?|evaluation|results?(?: and discussion)?|"
    r"discussion|conclusions?(?: and future work)?|limitations?(?: and future work)?|"
    r"future work|acknowledg(?:e|e?ments)?|references|bibliography|summary|contributions?)\s*:?$",
    re.I)
NUM_HEAD = re.compile(r"^(\d+(?:\.\d+){0,3})[.)]?\s+([A-Za-z\u4e00-\u9fff][^\n]{0,80})$")
FALLBACK_HEAD = re.compile(r"^[A-Z][A-Za-z][A-Za-z ,&/\-]{1,60}$")
_STOP_WORDS = {"the", "a", "an", "this", "that", "these", "those", "we", "our", "it",
               "they", "he", "she", "i", "in", "on", "at", "by", "for", "of", "and",
               "or", "but", "to", "with", "is", "are", "was", "were", "as", "from"}


def _is_heading(line):
    s = line.strip()
    if len(s) < 2 or len(s) > 90:
        return None
    md = re.match(r"^#{1,6}\s+(.+)$", s)
    if md:
        return md.group(1).strip()
    if NUM_HEAD.match(s):
        return s
    if KNOWN_HEAD.match(s):
        return s
    return None


def _fallback_heading(line):
    s = line.strip()
    if len(s) < 3 or len(s) > 70 or len(s.split()) > 10:
        return None
    if not FALLBACK_HEAD.match(s) or re.search(r"[.!?;:]$", s):
        return None
    first = s.split()[0].lower()
    if first in _STOP_WORDS:
        return None
    return s


def parse_page(locator):
    if not locator:
        return None
    m = re.search(r"#p(\d+)$", str(locator))
    return int(m.group(1)) if m else None


def build_timeline(mats):
    """Return (sentences, headings) in document order.

    A sentence is {rel, page, para, heading, text, locator}. A heading is
    {rel, page, para, label, quote, locator}. PDF locators use the physical page;
    plain-text locators use the paragraph number (blank-line separated), matching
    main.build_units so every locator resolves to a real file location.

    Lines are accumulated between heading/blank-line boundaries and then split
    into sentences, so wrapped lines do not fragment sentences.
    """
    def _lines(m):
        rel = m["rel"]
        if m["suffix"] == ".pdf":
            for pi, page in enumerate(m["pages"]):
                for raw in page.splitlines():
                    yield rel, pi + 1, None, raw
        else:
            para = 1
            for raw in ((m["pages"] or [""])[0]).splitlines():
                if not raw.strip():
                    para += 1
                    continue
                yield rel, None, para, raw

    strong = set()
    for m in mats:
        for _rel, _pg, _pa, raw in _lines(m):
            lab = _is_heading(raw)
            if lab:
                strong.add(lab.lower())
    allow_fallback = len(strong) < 2

    sentences, headings = [], []
    for m in mats:
        rel = m["rel"]
        current = None
        buf = []
        buf_page = buf_para = None
        buf_head = None

        def flush():
            if not buf:
                return
            text = " ".join(buf)
            buf.clear()
            loc = "%s#p%d" % (rel, buf_page if m["suffix"] == ".pdf" else buf_para)
            for s in split_sentences(text):
                if good(s):
                    sentences.append({"rel": rel, "page": buf_page, "para": buf_para,
                                      "heading": buf_head, "text": s, "locator": loc})

        for _rel, pg, pa, raw in _lines(m):
            lab = _is_heading(raw) or (allow_fallback and _fallback_heading(raw))
            if lab:
                flush()
                current = lab
                loc = "%s#p%d" % (rel, pg if m["suffix"] == ".pdf" else pa)
                headings.append({"rel": rel, "page": pg, "para": pa, "label": lab,
                                 "quote": raw.strip(), "locator": loc})
                continue
            if not raw.strip():
                flush()
                continue
            if not buf:
                buf_page, buf_para = pg, pa
                buf_head = current
            buf.append(raw.strip())
        flush()
    return sentences, headings


# ------------------------------------------------------------------ salience / facets
CLAIM_RE = [r"\b(we propose|we present|we introduce|we develop|propose|present|introduce|"
            r"develop|method|approach|framework|model|algorithm)\b"]
RESULT_RE = [r"\b(achiev|accuracy|precision|recall|f1\b|score|outperform|improve|reduce|"
             r"increase|boost|state-of-the-art|better than|superior|baseline|consistent)\b"]
EVID_RE = [r"\b(we show|we find|we observe|demonstrat|indicat|suggest|confirm|our results|"
           r"experiments? show|evaluat|benchmark|compar)\b"]
LIMIT_RE = [r"\b(limitation|however|challenge|fail|cannot|remains|unclear|not address|"
            r"shortcoming|restrict|future work|does not)\b"]
NUM_RE = [r"\d+(?:\.\d+)?%?", r"\bp\s*[<>≤≥=]\s*0?\.\d+"]

FACETS = [
    ("研究问题与目标", [r"\b(research question|we study|we investigate|we aim|goal|objective|"
                      r"problem|gap|we address|challenge remains)\b"]),
    ("方法与技术", [r"\b(method|approach|framework|model|algorithm|architecture|pipeline|"
                  r"objective|loss|optimiz|we propose|we design|train)\b"]),
    ("证据与结果", [r"\b(result|achiev|accuracy|precision|recall|f1\b|score|outperform|improve|"
                  r"baseline|experiment|evaluat|benchmark|we find|we show|compar)\b"]),
    ("结论", [r"\b(conclusion|overall|in summary|we conclude|suggest|demonstrat)\b"]),
    ("局限与风险", [r"\b(limitation|however|challenge|fail|cannot|remains|future work|"
                  r"restrict|does not|not address)\b"]),
]


def salience(s):
    low = s.lower()
    sc = 1
    if any(re.search(p, low) for p in CLAIM_RE):
        sc += 3
    if any(re.search(p, low) for p in RESULT_RE):
        sc += 3
    if any(re.search(p, low) for p in EVID_RE):
        sc += 2
    if any(re.search(p, low) for p in LIMIT_RE):
        sc += 2
    if any(re.search(p, low) for p in NUM_RE):
        sc += 1
    if re.search(r"\b[A-Z][a-zA-Z]+\b", s) and len(s.split()) <= 30:
        sc += 1
    return sc


def facet_of(s):
    low = s.lower()
    for name, pats in FACETS:
        if any(re.search(p, low) for p in pats):
            return name
    return "关键内容"


SALIENT_WORDS = ["propose", "method", "approach", "model", "framework", "algorithm",
                 "result", "achiev", "accuracy", "outperform", "improve", "baseline",
                 "experiment", "evaluat", "compar", "limitation", "future", "objective",
                 "loss", "train", "we show", "we find", "demonstrat", "challenge"]


def label_for(s):
    s = squeeze(s)
    parts = re.split(r"(?<=[,;:])\s+|\s+(?=but|however|because|while|whereas|although)", s)
    cand = None
    for c in parts:
        if c and any(k in c.lower() for k in SALIENT_WORDS):
            cand = c
            break
    if not cand:
        cand = parts[0] if parts else s
    cand = re.sub(r"^(we|our|this work|this paper|in this paper|the proposed)\s+",
                  "", cand, flags=re.I).strip()
    if not cand:
        cand = s
    if _cjk(cand) >= 12:
        return cand[:26].strip()
    toks = cand.split()
    if not toks:
        return s[:60]
    return " ".join(toks[:10])


# ------------------------------------------------------------------ relation cues
RELATION_ROLES = [
    ("cause", "explains", r"\b(because|since|due to|owing to|as a result of|attribut|"
     r"caused by|driven by)\b"),
    ("result", "leads_to", r"\b(therefore|thus|hence|consequently|as a result|leading to|"
     r"thereby|so that)\b"),
    ("conflict", "has_limitation", r"\b(fails?|failures?|cannot|limitations?|challenges?|"
     r"remains?|unclear|not address|out of scope|shortcomings?|restricts?|severe|degrades?)\b"),
    ("result", "produces", r"\b(achiev|accuracy|precision|recall|f1\b|score|outperform|"
     r"improve|reduce|increase|boost|state-of-the-art|better than|superior)\b"),
    ("support", "supported_by", r"\b(support\w*|we show|we find|demonstrat\w*|indicat\w*|"
     r"suggest\w*|confirm\w*|our results|consistent with|validates?|evaluat\w*|benchmarks?|"
     r"compar\w*|experiments?)\b"),
    ("method", "uses", r"\b(propose|method|approach|framework|model|algorithm|architecture|"
     r"pipeline|we design|we train|objective|loss|optimiz)\b"),
    ("contrast", "contrasted_with", r"\b(however|although|though|whereas|while|in contrast|"
     r"on the other hand|but\b|unlike|compared to|versus)\b"),
    ("sequence", "follows", r"\b(first|then|next|subsequently|after|before|followed by|"
     r"prior to)\b"),
    ("example", "exemplified_by", r"\b(for example|for instance|such as|e\.g\.|including)\b"),
    ("dependency", "depends_on", r"\b(requires?|depend[s]? on|relies? on|needs?|in order to|"
     r"based on|prerequisite)\b"),
    ("attribution", "attributed_to", r"\b(according to|reported by|proposed by|introduced by|"
     r"et al\.|\[\d+\])\b"),
    ("question", "motivated_by", r"\b(research question|we study|we investigate|we aim|goal|"
     r"objective|problem|gap|challenge remains|we address)\b"),
]


def relation_role(text):
    low = text.lower()
    for rtype, label, pat in RELATION_ROLES:
        if re.search(pat, low):
            return rtype, label
    return None


# ------------------------------------------------------------------ node/relation builders
def _node(nid, ntype, label, source, locator, quote):
    return {"id": nid, "type": ntype, "label": label, "source": source,
            "locator": locator, "quote": quote, "page": parse_page(locator),
            "evidence": {"type": ntype, "source": source, "locator": locator,
                         "quote": quote}}


def _rel(rid, rtype, label, src, dst, source, locator, quote):
    return {"id": rid, "type": rtype, "label": label, "from": src, "to": dst,
            "source": source, "locator": locator, "quote": quote,
            "page": parse_page(locator),
            "evidence": {"type": rtype, "source": source, "locator": locator,
                         "quote": quote}}


def build(mats, case, profile):
    cfg = profile.get("mindmap", {}) if isinstance(profile, dict) else {}
    max_leaves = int(cfg.get("max_leaves", 48))
    min_leaves = int(cfg.get("min_leaves", 8))
    per_branch_min = int(cfg.get("per_branch", 2))

    case = case if isinstance(case, dict) else {}
    case_id = str(case.get("case_id") or case.get("id") or "")
    title = case.get("title") or (profile or {}).get("title") or "Research mind map"

    sentences, headings = build_timeline(mats)
    gaps = []
    if not mats:
        gaps.append("no readable material in the input; the mind map has a root only")
    if mats and not sentences:
        gaps.append("material present but no usable sentences could be parsed")

    # root
    first_sent = sentences[0] if sentences else None
    first_head = headings[0] if headings else None
    root_quote = first_sent["text"] if first_sent else (first_head["quote"] if first_head else "")
    root_loc = first_sent["locator"] if first_sent else (first_head["locator"] if first_head else "")
    root_src = first_sent["rel"] if first_sent else (first_head["rel"] if first_head else "")

    nodes = [_node("n0", "root", title, root_src, root_loc, root_quote)]
    relations = []

    # group sentences by heading (or facet when no headings)
    grouped = OrderedDict()
    pre_key = "__pre__"
    if headings:
        for s in sentences:
            key = s["heading"] or pre_key
            grouped.setdefault(key, []).append(s)
        pre_sents = grouped.pop(pre_key, []) if pre_key in grouped else []
        ordered = []
        for h in headings:
            if h["label"] not in ordered:
                ordered.append(h["label"])
        branch_defs = []
        if pre_sents:
            branch_defs.append(("Overview", pre_sents))
        for label in ordered:
            sents = grouped.get(label, [])
            if sents:
                branch_defs.append((label, sents))
        if not branch_defs and sentences:
            branch_defs.append(("Overview", sentences))
    else:
        facets = OrderedDict()
        for s in sentences:
            facets.setdefault(facet_of(s), []).append(s)
        branch_defs = list(facets.items())
        gaps.append("no explicit headings found; branches are semantic facets")

    target = max(min_leaves, min(max_leaves, len(sentences)))
    n_branch = max(1, len(branch_defs))
    per_branch = max(per_branch_min, (target // n_branch) + (1 if target % n_branch else 0))

    # node id counters and lookup maps
    next_id = [1]
    node_id = {"n0": "n0"}
    branch_nodes = []

    def new_id():
        nid = "n%d" % next_id[0]
        next_id[0] += 1
        return nid

    # build branches + leaves
    for bi, (blabel, sents) in enumerate(branch_defs):
        picked = sorted(enumerate(sents), key=lambda t: (-salience(t[1]["text"]), t[0]))
        picked = picked[:per_branch]
        if not picked:
            continue
        h = next((x for x in headings if x["label"] == blabel), None)
        bquote = h["quote"] if h and len(h["quote"]) >= 8 else picked[0][1]["text"]
        bloc = h["locator"] if h else picked[0][1]["locator"]
        bsrc = h["rel"] if h else picked[0][1]["rel"]
        bid = new_id()
        bnode = _node(bid, "branch", blabel, bsrc, bloc, bquote)
        nodes.append(bnode)
        branch_nodes.append(bnode)
        relations.append(_rel("r%d" % len(relations), "contains", "contains", "n0", bid,
                              bsrc, bloc, bquote))
        for _idx, s in picked:
            lid = new_id()
            label = label_for(s["text"])
            lnode = _node(lid, "leaf", label, s["rel"], s["locator"], s["text"])
            nodes.append(lnode)
            relations.append(_rel("r%d" % len(relations), "contains", "contains", bid, lid,
                                  s["rel"], s["locator"], s["text"]))
            role = relation_role(s["text"])
            if role:
                rtype, rlabel = role
                relations.append(_rel("r%d" % len(relations), rtype, rlabel, bid, lid,
                                      s["rel"], s["locator"], s["text"]))

    # claims (for verify) and blocks (for generic emit)
    claims, blocks = [], []
    leaf_nodes = [n for n in nodes if n["type"] == "leaf"]
    by_id = {n["id"]: n for n in nodes}
    branch_of = {}
    for r in relations:
        if r["type"] == "contains" and r["to"] in by_id and by_id[r["to"]]["type"] == "leaf":
            branch_of[r["to"]] = r["from"]
    for ln in leaf_nodes:
        b = by_id.get(branch_of.get(ln["id"], ""), {})
        section = (b.get("label") or "Overview")
        claims.append({"id": ln["id"], "section": section, "claim": ln["label"],
                       "quote": ln["quote"], "locator": ln["locator"],
                       "evidence": ln["evidence"], "source": ln["source"],
                       "page": ln.get("page"), "type": "leaf"})
    for bnode in branch_nodes:
        leaves = [(ln["locator"], ln["quote"]) for ln in leaf_nodes
                  if branch_of.get(ln["id"]) == bnode["id"]]
        blocks.append((bnode["label"], leaves))

    # content_map: every node + every relation as an evidence item
    content_map = []
    for n in nodes:
        content_map.append({"id": n["id"], "type": n["type"], "label": n["label"],
                            "source": n["source"], "locator": n["locator"],
                            "page": n.get("page"), "quote": n["quote"]})
    for r in relations:
        content_map.append({"id": r["id"], "type": "relation:" + r["type"],
                            "label": r["label"], "from": r["from"], "to": r["to"],
                            "source": r["source"], "locator": r["locator"],
                            "page": r.get("page"), "quote": r["quote"]})

    typed = sum(1 for r in relations if r["type"] != "contains")
    stats = {"nodes": len(nodes), "branches": len(branch_nodes),
             "leaves": len(leaf_nodes), "relations": len(relations),
             "typed_relations": typed, "materials": len(mats),
             "sentences": len(sentences)}

    return {"id": case_id, "title": title, "root": "n0", "nodes": nodes,
            "relations": relations, "blocks": blocks, "claims": claims,
            "content_map": content_map, "stats": stats, "gaps": gaps}


# ------------------------------------------------------------------ rendering helpers
def children_map(mm):
    ch = {}
    for r in mm["relations"]:
        if r["type"] == "contains":
            ch.setdefault(r["from"], []).append(r["to"])
    return ch


def _clean_label(label, max_len=60):
    s = squeeze(label)
    s = s.replace("\n", " ")
    s = re.sub(r"[\[\](){}<>\"`]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return (s[:max_len] + "…") if len(s) > max_len else (s or "node")


def _esc_table(x):
    return str(x).replace("|", "/").replace("\n", " ")


def render_md(mm):
    L = ["# %s" % mm["title"], "",
         "> 层级化思维导图：根 / 枝 / 叶 + 关系 + 证据。每个节点和关系均带 "
         "`source + locator + quote`，可回溯到材料中的逐字片段。", ""]
    L += ["## Mermaid（层级）", "", "```mermaid", "mindmap"]
    by_id = {n["id"]: n for n in mm["nodes"]}
    ch = children_map(mm)

    def emit(nid, depth):
        n = by_id.get(nid)
        if not n:
            return
        pad = "  " * depth
        shape = "((%s))" if n["type"] == "root" else "%s"
        L.append(pad + shape % _clean_label(n["label"]))
        for c in ch.get(nid, []):
            emit(c, depth + 1)

    if by_id.get(mm["root"]):
        emit(mm["root"], 1)
    L += ["```", ""]

    L += ["## Mermaid（关系）", "", "```mermaid", "flowchart LR"]
    for n in mm["nodes"]:
        L.append('  %s["%s"]' % (n["id"], _clean_label(n["label"], 50).replace('"', "'")))
    for r in mm["relations"]:
        if r["type"] == "contains":
            L.append("  %s --> %s" % (r["from"], r["to"]))
        else:
            L.append("  %s -- %s --> %s" % (r["from"], _clean_label(r["label"], 30), r["to"]))
    L += ["```", ""]

    L += ["## 节点", "", "| id | 类型 | 名称 | source | locator | quote |",
          "|---|---|---|---|---|---|"]
    for n in mm["nodes"]:
        L.append("| %s | %s | %s | `%s` | `%s` | %s |" % (
            n["id"], n["type"], _esc_table(n["label"]), _esc_table(n["source"]),
            _esc_table(n["locator"]), _esc_table(n["quote"])))
    L += ["", "## 关系", "", "| id | 类型 | 方向 | source | locator | quote |",
          "|---|---|---|---|---|---|"]
    for r in mm["relations"]:
        L.append("| %s | %s | %s → %s (%s) | `%s` | `%s` | %s |" % (
            r["id"], r["type"], r["from"], r["to"], _esc_table(r["label"]),
            _esc_table(r["source"]), _esc_table(r["locator"]), _esc_table(r["quote"])))
    s = mm["stats"]
    L += ["", "## 覆盖与状态", "",
          "- 节点 %d（根 1 / 枝 %d / 叶 %d），关系 %d（其中类型关系 %d）。"
          % (s["nodes"], s["branches"], s["leaves"], s["relations"], s["typed_relations"]),
          "- 材料 %d 个，可用句子 %d。" % (s["materials"], s["sentences"]), ""]
    if mm["gaps"]:
        L += ["### 缺口", ""]
        L += ["- " + g for g in mm["gaps"]]
        L += [""]
    return "\n".join(L)


def render_outline(mm):
    L = [mm["title"]]
    by_id = {n["id"]: n for n in mm["nodes"]}
    ch = children_map(mm)

    def emit(nid, depth):
        n = by_id.get(nid)
        if not n:
            return
        if n["type"] == "root":
            pass
        elif n["type"] == "branch":
            L.append("  " * depth + "- %s  [%s]" % (n["label"], n["locator"]))
        else:
            L.append("  " * depth + "* %s  [%s]" % (n["label"], n["locator"]))
        for c in ch.get(nid, []):
            emit(c, depth + 1)

    emit(mm["root"], 0)
    return "\n".join(L) + "\n"


def _layout(mm):
    """Return {id: (x, y)} for a left-to-right layered tree."""
    by_id = {n["id"]: n for n in mm["nodes"]}
    ch = children_map(mm)
    pos = {}
    nxt = {}

    def assign(nid, depth):
        kids = ch.get(nid, [])
        if not kids:
            y = nxt.get(depth, 0)
            nxt[depth] = y + 1
            pos[nid] = (depth, y)
            return y
        ys = [assign(c, depth + 1) for c in kids]
        y = sum(ys) / float(len(ys))
        pos[nid] = (depth, y)
        return y

    if by_id.get(mm["root"]):
        assign(mm["root"], 0)
    return pos


def render_svg(mm, path):
    pos = _layout(mm)
    if not pos:
        return False
    by_id = {n["id"]: n for n in mm["nodes"]}
    ch = children_map(mm)
    unit_x, unit_y, box_w, box_h = 280, 62, 240, 44
    max_y = max(y for _x, y in pos.values())
    width = (max(x for x, _y in pos.values()) + 1) * unit_x + 40
    height = (max_y + 1) * unit_y + 40
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" '
             'viewBox="0 0 %d %d">' % (width, height, width, height),
             '<rect width="100%" height="100%" fill="white"/>',
             '<defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" '
             'orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#555"/></marker></defs>']
    for nid, (x, y) in pos.items():
        px, py = 20 + x * unit_x, 20 + y * unit_y
        n = by_id[nid]
        fill = {"root": "#eef3fb", "branch": "#e8f5e9", "leaf": "#fff8e1"}.get(n["type"], "#fff")
        label = _clean_label(n["label"], 46)
        parts.append('<rect x="%d" y="%d" width="%d" height="%d" rx="6" fill="%s" '
                     'stroke="#888"/>' % (px, py, box_w, box_h, fill))
        parts.append('<text x="%d" y="%d" font-size="12" font-family="sans-serif">%s</text>'
                     % (px + 8, py + 20, _svg_esc(label)))
        parts.append('<text x="%d" y="%d" font-size="9" fill="#666" '
                     'font-family="sans-serif">%s</text>'
                     % (px + 8, py + 35, _svg_esc((n.get("locator") or "")[:46])))
    for r in mm["relations"]:
        a, b = pos.get(r["from"]), pos.get(r["to"])
        if not a or not b:
            continue
        x1 = 20 + a[0] * unit_x + box_w
        y1 = 20 + a[1] * unit_y + box_h / 2
        x2 = 20 + b[0] * unit_x
        y2 = 20 + b[1] * unit_y + box_h / 2
        dash = "" if r["type"] == "contains" else ' stroke-dasharray="4 3"'
        parts.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#555" '
                     'marker-end="url(#arrow)"%s/>' % (x1, y1, x2, y2, dash))
    parts.append("</svg>")
    path.write_text("\n".join(parts), encoding="utf-8")
    return True


def _svg_esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
             .replace('"', "&quot;"))


def render_png(mm, path, max_nodes=60):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
        from matplotlib import font_manager
    except Exception:
        return False

    # pick a CJK-capable font if the host has one, else keep DejaVu for Latin labels
    try:
        avail = {f.name for f in font_manager.fontManager.ttflist}
        for cand in ("Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
                     "WenQuanYi Zen Hei", "PingFang SC", "Arial Unicode MS"):
            if cand in avail:
                matplotlib.rcParams["font.sans-serif"] = [cand, "DejaVu Sans"]
                break
    except Exception:
        pass

    pos = _layout(mm)
    if not pos:
        return False
    by_id = {n["id"]: n for n in mm["nodes"]}
    ch = children_map(mm)
    nodes = list(by_id.values())
    if len(nodes) > max_nodes:
        nodes = nodes[:max_nodes]
        keep = {n["id"] for n in nodes}
        pos = {k: v for k, v in pos.items() if k in keep}
        ch = {k: [c for c in v if c in keep] for k, v in ch.items() if k in keep}

    unit_x, unit_y = 1.0, 1.0
    max_y = max(y for _x, y in pos.values())
    fig_w = max(4.0, (max(x for x, _y in pos.values()) + 1) * 3.4 + 1.0)
    fig_h = max(2.5, (max_y + 1) * 1.05 + 1.0)
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    ax.set_xlim(-0.3, max(x for x, _y in pos.values()) + 0.35)
    ax.set_ylim(-0.6, max_y + 0.6)
    ax.axis("off")

    def wrap(text, width=30):
        import textwrap
        return "\n".join(textwrap.wrap(text, width) or [""])

    box_w, box_h = 0.72, 0.42
    for nid, (x, y) in pos.items():
        n = by_id.get(nid)
        if not n:
            continue
        color = {"root": "#dbe7f5", "branch": "#dcefdc", "leaf": "#fdf3d0"}.get(n["type"], "#f5f5f5")
        bx, by = x - box_w / 2, y - box_h / 2
        ax.add_patch(FancyBboxPatch((bx, by), box_w, box_h,
                                    boxstyle="round,pad=0.01,rounding_size=0.03",
                                    linewidth=0.9, edgecolor="#666", facecolor=color))
        ax.text(x, y, wrap(_clean_label(n["label"], 30), 30), ha="center", va="center",
                fontsize=8)
    for r in mm["relations"]:
        a, b = pos.get(r["from"]), pos.get(r["to"])
        if not a or not b:
            continue
        style = "solid" if r["type"] == "contains" else "dashed"
        arr = FancyArrowPatch((a[0] + box_w / 2, a[1]),
                              (b[0] - box_w / 2, b[1]),
                              arrowstyle="-|>", mutation_scale=9, lw=0.9,
                              color="#555", linestyle=style)
        ax.add_patch(arr)
        if r["type"] != "contains":
            mx, my = (a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0 + 0.04
            ax.text(mx, my, _clean_label(r["label"], 18), fontsize=6, color="#333",
                    ha="center", va="bottom")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return True
